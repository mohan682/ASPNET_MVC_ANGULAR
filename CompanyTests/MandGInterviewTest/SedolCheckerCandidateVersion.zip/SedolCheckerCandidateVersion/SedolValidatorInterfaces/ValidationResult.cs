﻿namespace SedolValidatorInterfaces
{
    /// <summary>
    /// SEDOL Validation Result interface.
    /// </summary>
    public class SedolValidationResult : ISedolValidationResult
    {
        readonly string inputString;
        readonly bool isUserDefined;
        readonly bool isValidSedol;
        readonly string validationDetails;

        public SedolValidationResult(string inputStr, bool isUserDefinedVar=false, bool isValidSedolVar=false, string validationDetailsVar=null)
        {
            inputString = inputStr;
            isUserDefined = isUserDefinedVar;
            isValidSedol = isValidSedolVar;
            validationDetails = validationDetailsVar;
        }

        public string InputString    { get { return inputString; }     }

        public bool IsUserDefined
        {
            get { return isUserDefined; }
        }

        public bool IsValidSedol
        {
            get { return isValidSedol; }
        }

        public string ValidationDetails
        {
            get { return validationDetails; }
        }
    }
}
