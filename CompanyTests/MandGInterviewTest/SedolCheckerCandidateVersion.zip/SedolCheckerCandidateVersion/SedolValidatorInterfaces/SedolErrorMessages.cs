﻿namespace SedolValidatorInterfaces
{
    public class SedolErrorMessages
    {
        public const string errorMessageSedolStringWrongFormat = "Input string was not 7 - characters long.";
        public const string errorMessageWrongChecksum = "Checksum digit does not agree with the rest of the input.";
    }
}
