﻿namespace SedolValidatorInterfaces
{
    using System;
    using System.Text.RegularExpressions;

    public class SedolValidator : ISedolValidator
    {
    
        int[] sedolWeights = { 1, 3, 1, 7, 3, 9 };

        public ISedolValidationResult ValidateSedol(string sedol)
        {
            int sum = 0;

            if (InValideSedolInput(sedol))
                return new SedolValidationResult(sedol, validationDetailsVar: SedolErrorMessages.errorMessageSedolStringWrongFormat);

            sedol = sedol.ToUpper();

            for (int i = 0; i < 6; i++)
            {
                sum += sedolWeights[i] * UnicodeCharToInt(sedol[i]);
            }

            int checksum = (10 - (sum % 10)) % 10;

            if (checksum != ((int)sedol[6] - 48))
                return new SedolValidationResult(sedol, validationDetailsVar: SedolErrorMessages.errorMessageWrongChecksum);

            return new SedolValidationResult(sedol, UnicodeCharToInt(sedol[0])==9,true);
        }

        private int UnicodeCharToInt(char sedolSingleChar)
        {
            return ((int)sedolSingleChar - (Char.IsDigit(sedolSingleChar) ? 48 : 55));
        }

        private bool InValideSedolInput(string sedol)
        {
            if (string.IsNullOrEmpty(sedol)) return true;

            int len = sedol.Length;

            if((len > 7) || (len < 7)) return true ;

            return !Regex.IsMatch(sedol.Substring(0,6),"^[0-9BCDFGHJKLMNPQRSTVWXYZ]{6}", RegexOptions.IgnoreCase);
        }
    }
}



