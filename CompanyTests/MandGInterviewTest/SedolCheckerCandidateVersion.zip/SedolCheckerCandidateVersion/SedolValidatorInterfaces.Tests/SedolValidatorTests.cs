﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SedolValidatorInterfaces.Tests
{
    [TestClass]
    public class SedolValidatorTests
    {
        [TestMethod]
        public void SedolValidationWithNull()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol(null);

            Assert.IsFalse(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNotNull(results.ValidationDetails);

            Assert.AreSame(SedolErrorMessages.errorMessageSedolStringWrongFormat, results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithEmpty()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol(""); // or string.Empty

            Assert.IsFalse(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNotNull(results.ValidationDetails);

            Assert.AreSame(SedolErrorMessages.errorMessageSedolStringWrongFormat, results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithInputLessThan7()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("12");

            Assert.IsFalse(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNotNull(results.ValidationDetails);

            Assert.AreSame(SedolErrorMessages.errorMessageSedolStringWrongFormat, results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithInputGreaterThan7()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("123456789");

            Assert.IsFalse(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNotNull(results.ValidationDetails);

            Assert.AreSame(SedolErrorMessages.errorMessageSedolStringWrongFormat, results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithInputHasSpecialStrings()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("12£^789");

            Assert.IsFalse(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNotNull(results.ValidationDetails);

            Assert.AreSame(SedolErrorMessages.errorMessageSedolStringWrongFormat, results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithInputIncorrectChecksumDigit()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("1234567");

            Assert.IsFalse(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNotNull(results.ValidationDetails);

            Assert.AreSame(SedolErrorMessages.errorMessageWrongChecksum, results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithValidInputNotDefinedByEndUser1()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("0709954");

            Assert.IsTrue(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNull(results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithValidInputNotDefinedByEndUser2()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("B0YBKJ7");

            Assert.IsTrue(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNull(results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithValidInputNotDefinedByEndUser3()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("B0Ybkj7");

            Assert.IsTrue(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNull(results.ValidationDetails);
        }

        [TestMethod]
        public void SedolValidationWithValidInputEndUserDefined()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("9123458");

            Assert.IsTrue(results.IsValidSedol);

            Assert.IsTrue(results.IsUserDefined);

            Assert.IsNull(results.ValidationDetails);
        }

        [TestMethod]
        /*
         *While vowels are never used in SEDOLs, 
         */
        public void SedolValidationWithVowel()
        {
            var sedolValidator = new SedolValidator();

            var results = sedolValidator.ValidateSedol("9aBcDe1");

            Assert.IsFalse(results.IsValidSedol);

            Assert.IsFalse(results.IsUserDefined);

            Assert.IsNotNull(results.ValidationDetails);

            Assert.AreSame(SedolErrorMessages.errorMessageSedolStringWrongFormat, results.ValidationDetails);
        }
    }
}

