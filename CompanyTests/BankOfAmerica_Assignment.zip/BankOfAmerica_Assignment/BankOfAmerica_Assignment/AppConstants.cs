﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BankOfAmerica_Assignment
{
    public class AppConstants
    {
        public static readonly string str_BaseUrl = "http://api.openweathermap.org";
        public static readonly string str_AppId = "e1c4424c74b5d37e224ac06585c9feeb";
    }
}