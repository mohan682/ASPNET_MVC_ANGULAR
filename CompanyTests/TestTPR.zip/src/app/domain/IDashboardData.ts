﻿declare module DashboardNamespace {

    export interface IDashboardDataValue {
        $type: string;
        Type: string;
        BusinessDate: Date;
        State: string;
        Comments: string;
        Source: string;
        FileType: string;
        Created: Date;
        CreatedBy: string;
        Updated: any;
        UpdatedBy: string;
        Id: number;  
        ShowDefaultDiv:boolean;
        ShowErrorsDiv:boolean;
         ShowChangesDiv:boolean;
    }

    export interface IDashboardData {
        $type: string;
        $values: IDashboardDataValue[];
    }

    export interface IDataResult {
        $type: string;
        DashboardData: IDashboardData;
    }

    // export interface IRootObject {
    //     $type: string;
    //     ResultType: string;
    //     Result: Result;
    //     Error?: any;
    // }
     export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IDataResult;
        Error?: any;
    }

    export interface ILastCalculatedResult {
        $type: string;
        Name: string;
        DateValue?: any;
        StringValue?: any;
        NumericValue?: any;
        BoolValue?: any;
        DateTimeValue: Date;
        Created: Date;
        CreatedBy: string;
        Updated: Date;
        UpdatedBy: string;
        Id: number;
    }

    export interface ILastCalculatedRootObject {
        $type: string;
        ResultType: string;
        Result: ILastCalculatedResult;
        Error?: any;
    }

    export interface IPublishStatusResult {
        $type: string;
        Name: string;
        DateValue?: any;
        StringValue?: any;
        NumericValue: number;
        BoolValue?: any;
        DateTimeValue?: any;
        Created?: any;
        CreatedBy?: any;
        Updated: Date;
        UpdatedBy: string;
        Id: number;
    }

    export interface IPublishStatusRootObject {
        $type: string;
        ResultType: string;
        Result: IPublishStatusResult;
        Error?: any;
    }
}

