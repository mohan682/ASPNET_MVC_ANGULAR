﻿declare module TagsNameSpace {

    export interface ITagsValue {
        $type: string,
        Name: string,
        IsInUse: boolean,
        Editable: boolean,
        Created: string,
        CreatedBy: string,
        Updated: string,
        UpdatedBy: string,
        Id: number
    }

    export interface ITagsTypes {
        $type: string;
        $values: ITagsValue[];
    }

    export interface ITagsTypeResult {
        $type: string;
        NodeTypes: ITagsTypes;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: ITagsTypeResult;
        Error?: any;
    }

}