﻿declare module RegionNamespace {

    export interface IRegionValue {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Created: Date;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IRegions {
        $type: string;
        $values: IRegionValue[];
    }

    export interface IRegionsResult {
        $type: string;
        Regions: IRegions;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IRegionsResult;
        Error?: any;
    }
}
