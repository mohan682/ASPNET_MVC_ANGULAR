﻿declare module CommonNameSpace {

    export interface IEnvironmentValue {
        Name: string,
        StringValue: string
    }

    export interface ISystemVersionValue {
        ServerVersionInfo: string
    }

    export interface ISystemDateValue {
        DateValue: string,
        Name: string
    }

    export interface IUserRolesValue {
        Name: string,
        Users: IUsersValue[];
    }

    export interface IUserRolesValues {
        $values: IUserRolesValue[];
    }

    export interface IUsersValue {
        LoginName: string,
        Role: string
    }
}