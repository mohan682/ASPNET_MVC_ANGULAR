declare module ViewNamespace {

    export interface IViewValue {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Url: string;
        TargetLocation: string;
        Server: IServer;
        LastRefreshed: any;
        RefreshDuration: any;
        RefreshState: any;
        ViewType: any;
        Created: Date;
        CreatedBy: string;
        Updated: any;
        UpdatedBy: string;
        Id: number;

    }

    export interface ITableauViews {
        $type: string;
        $values: IViewValue[];
    }

    export interface IServer {
        $type: string;
        Name: string;
        Url: string;
        Id: number;
    }

    export interface IViewsResult {
        $type: string;
        TableauViews: ITableauViews;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IViewsResult;
        Error?: any;
    }
}