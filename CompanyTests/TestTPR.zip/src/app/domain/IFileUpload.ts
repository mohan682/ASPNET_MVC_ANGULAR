declare module FileUploadNameSpace {

    export interface IFileUploadValue {
        $type: string;
        SourceName: string;
        SourceType: string;
        SourceCreatedDate: string;
        SourceModifiedDate: string;
        UserName: string;
        Status: string;
        LoadedTime: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IFileUploadTypes {
        $type: string;
        $values: IFileUploadValue[];
    }

    export interface IFileUploadTypeResult {
        $type: string;
        StagingSources: IFileUploadTypes;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IFileUploadTypeResult;
        Error?: any;
    }

    export interface IErrorDetails {
        ErrorDescription: string;
    }

    export interface ICompleteErrorDetails {
        $type: string;
        ErrorMessage: string;
        ErrorType: number;
        Source: any;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IFileUploadModel {
        $type: string;
        FileType: number;
        FileBytes: IFileUploadModel_FileBytes;
        FileName: string;
    }

    export interface IFileUploadModel_FileBytes {
        $type: string;
        $value: string;
    }
}