﻿declare module NodeTypeNamespace {

    export interface INodeTypesValue {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface INodeTypes {
        $type: string;
        $values: INodeTypesValue[];
    }

    export interface INodeTypeResult {
        $type: string;
        NodeTypes: INodeTypes;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: INodeTypeResult;
        Error?: any;
    }
}

