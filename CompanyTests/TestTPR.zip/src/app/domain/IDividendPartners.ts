﻿declare module DividendPartnerNameSpace {

    export interface IDividendPartnerValue {
        $type: string,
        Name: string,
        IsInUse: boolean,
        BusinessSegment: IBusinessSegment,
        Editable: boolean,
        Created: string
        CreatedBy: string,
        Updated: string
        UpdatedBy: string,
        Id: number
    }

    export interface IBusinessSegment {
        $type: string,
        Name: string,
        IsInUse: boolean,
        Editable: boolean,
        Created: string
        CreatedBy: string,
        Updated: string
        UpdatedBy: string,
        Id: number
    }

    export interface IDividendPartnersTypes {
        $type: string;
        $values: IDividendPartnerValue[];
    }

    export interface IDividendPartnersTypeResult {
        $type: string;
        DividendPartners: IDividendPartnersTypes;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IDividendPartnersTypeResult;
        Error?: any;
    }
}