declare module DataSourceNamespace {

    export interface IDataSourceValue {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Server: IServer;
        LastRefreshed: any;
        RefreshDuration: any;
        RefreshState: any;
        Project: string;
        Created: Date;
        CreatedBy: string;
        Updated: any;
        UpdatedBy: string;
        Id: number;

    }

    export interface ITableauDataSources {
        $type: string;
        $values: IDataSourceValue[];
    }

    export interface IServer {
        $type: string;
        Name: string;
        Url: string;
        Id: number;
    }

    export interface IDataSourcesResult {
        $type: string;
        TableauDataSources: ITableauDataSources;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IDataSourcesResult;
        Error?: any;
    }
}