﻿declare module PAGNameSpace {

    export interface IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values {
        $type: string;
        AlertId: number;
        AlertGroupId: number;
        Level: number;
        StartDate: string;
        EndDate: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number
    }

    export interface IProfitAlertGroups_Values_Alerts_Values_ActionAlerts {
        $type: string;
        $values: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values[];
    }

    export interface IProfitAlertGroups_Values_Alerts_Values {
        $type: string;
        ActionAlerts: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts;
        AlertGroupType: number;
        Level: number;
        AlertGroupId: number;
        CurrentActionAlertExpiryDate: string;
        CurrentActionAlertLevel: string;
        Actual: any;
        StatusId: any;
        SystemIsNew: boolean;
        SystemIsTriggered: boolean;
        SystemTriggeredDate: string;
        UserIsNew: boolean;
        UserIsTriggered: boolean;
        UserTriggeredDate: string;
        ReportedIsNew: boolean;
        ReportedIsTriggered: boolean;
        ReportedTriggeredDate: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number
    }

    export interface IProfitAlertGroups_Values_Alerts {
        $type: string;
        $values: IProfitAlertGroups_Values_Alerts_Values[];
    }

    export interface IProfitAlertGroups_Values_Members_Values {
        $type: string;
        Name: string;
        NodeId: number;
        StructureId: number;
        Id: number;
    }

    export interface IProfitAlertGroups_Values_Members {
        $type: string;
        $values: IProfitAlertGroups_Values_Members_Values[];
    }

    export interface IProfitAlertGroupsValues {
        $type: string;
        Alerts: IProfitAlertGroups_Values_Alerts;
        Name: string;
        Members: IProfitAlertGroups_Values_Members;
        IsInUse: boolean;
        UpdateTiming: number;
        TradeDate: string;
        ProfitAlertGroupStatusId: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id:number;
    }

    export interface IProfitAlertGroups {
        $type: string;
        $values: IProfitAlertGroupsValues[];
    }

    export interface IProfitAlertGroupResult {
        $type: string;
        AlertGroups: IProfitAlertGroups;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IProfitAlertGroupResult;
        Error?: any;
    }

    /*Save data starts*/
    export interface IProfitAlertGroups_SaveData {
        $type: string;
        AlertGroups: IProfitAlertGroups_SaveData_AlertGroups[];
        ReportingDate: string;
    }

    export interface IProfitAlertGroups_SaveData_AlertGroups {
        $type: string;
        Alerts: IProfitAlertGroups_SaveData_AlertGroups_Alerts[];
        Name: string;
        Members: IProfitAlertGroups_Values_Members_Values[];
        IsInUse: boolean;
        UpdateTiming: number;
        TradeDate: string;
        ProfitAlertGroupStatusId: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id:number
    }

    export interface IProfitAlertGroups_SaveData_AlertGroups_Alerts{
        $type: string;
        ActionAlerts: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values[];
        AlertGroupType: number;
        Level: number;
        AlertGroupId: number;
        CurrentActionAlertExpiryDate: string;
        CurrentActionAlertLevel: string;
        Actual: any;
        StatusId: any;
        SystemIsNew: boolean;
        SystemIsTriggered: boolean;
        SystemTriggeredDate: string;
        UserIsNew: boolean;
        UserIsTriggered: boolean;
        UserTriggeredDate: string;
        ReportedIsNew: boolean;
        ReportedIsTriggered: boolean;
        ReportedTriggeredDate: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number
    }
    /*Save data ends*/
}