﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import INodeTypesValue = NodeTypeNamespace.INodeTypesValue;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class TPRNodeTypeService {

    constructor(private http: Http, private serviceHelper : ServiceHelper) { }

    getNodeTypesObservable(): Observable<any> {

        let _url =  this.serviceHelper.combineUrl("HierarchyWCFService.svc/NodeTypes");
        console.log("Send request ->", _url);

        return this.http.get(_url, { withCredentials: true })
            .map((res: any) => res.json())
        .catch(this.serviceHelper.handleError);
    }

    updateNodeTypesObservable(nodesArray: INodeTypesValue[]): Observable<any> {

        let _url =  this.serviceHelper.combineUrl("HierarchyWCFService.svc/NodeTypes/update");
        console.log("Send request ->", _url);

        nodesArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeTypeDTO, BP.IST.Finance.TPR.Common.Domain.DTO"
        });

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeTypeCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            NodeTypes: nodesArray
        }
        let body = JSON.stringify(data);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}