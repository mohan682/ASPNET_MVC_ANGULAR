import { Injectable } from '@angular/core';
import {
    CanActivate, Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import { ServiceHelper } from './app.serviceHelper';
import { TPRCommonService } from './app.TPRCommonService';
import 'rxjs/add/operator/map';
import IUserRolesValue = CommonNameSpace.IUserRolesValue;
import IUserRolesValues = CommonNameSpace.IUserRolesValues;
import IUsersValue = CommonNameSpace.IUsersValue;


@Injectable()
export class CanActivateGuard implements CanActivate {
    availableRoles: IUserRolesValues = new UserRolesValues();
    userRoles: string[] = [];
    constants: any;
    isAccessDenied: boolean = true;

    constructor(private http: Http,
        private serviceHelper: ServiceHelper,
        private commonService: TPRCommonService,
        private router: Router) { }

    public getConstants(data: any): void {
        this.constants = data;
    }

    private setUserRolesData(data: any): void {
        this.availableRoles.$values = [];
        this.availableRoles.$values = data.Result.UserRoles.$values;

        this.availableRoles.$values.forEach((role: any) => {
            this.userRoles.push(role.Name);
        });

        console.log("User Role ->", this.userRoles);
        localStorage.setItem("UserRole", JSON.stringify(this.userRoles));
    }

    public isUserAuthorised(): boolean {
        return this.userRoles != undefined && this.constants != undefined &&
            (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                this.userRoles.some(x => x == this.constants.TPRMarginManagement) ||
                this.userRoles.some(x => x == this.constants.TPRRiskManagement) ||
                this.userRoles.some(x => x == this.constants.TPRITSupport));
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {

        return this.serviceHelper.importSettings()
            .map(data => {
                this.getConstants(data);
                console.log('canActivate called');
                if (localStorage.getItem("UserRole")) {
                    this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
                    console.log("User Roles from Local Storage ->", this.userRoles);
                    console.log("Is User Authorized ->", this.isUserAuthorised());

                    if (!this.isUserAuthorised()) {
                        this.router.navigate(['/error']);
                    }

                    return this.isUserAuthorised();
                }
                else {
                    this.commonService.getUserRolesObservable()
                        .map(data => {
                            this.setUserRolesData(data)
                            console.log("Is User Authorized ->", this.isUserAuthorised());

                            if (!this.isUserAuthorised()) {
                                this.router.navigate(['/error']);
                            }

                            return this.isUserAuthorised();
                        });
                }
            });
    }
}

class UserRolesValues implements IUserRolesValues {
    constructor(public $values: IUserRolesValue[] = null) { }
}

class UserRolesValue implements IUserRolesValue {
    constructor(
        public Name: string = null,
        public Users: IUsersValue[] = null) { }
}

class UsersValue implements IUsersValue {
    constructor(
        public LoginName: string = null,
        public Role: string = null) { }
}