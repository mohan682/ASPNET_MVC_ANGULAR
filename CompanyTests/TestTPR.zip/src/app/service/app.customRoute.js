"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var DefaultRouteReuseStrategy = (function () {
    function DefaultRouteReuseStrategy() {
    }
    DefaultRouteReuseStrategy.prototype.shouldDetach = function (route) { return false; };
    DefaultRouteReuseStrategy.prototype.store = function (route, detachedTree) { };
    DefaultRouteReuseStrategy.prototype.shouldAttach = function (route) { return false; };
    DefaultRouteReuseStrategy.prototype.retrieve = function (route) { return null; };
    DefaultRouteReuseStrategy.prototype.shouldReuseRoute = function (future, curr) {
        return future.routeConfig === curr.routeConfig;
    };
    return DefaultRouteReuseStrategy;
}());
var CustomReuseStrategy = (function (_super) {
    __extends(CustomReuseStrategy, _super);
    function CustomReuseStrategy() {
        _super.apply(this, arguments);
    }
    CustomReuseStrategy.prototype.shouldReuseRoute = function (future, curr) {
        // let futureName = future.component && (<any>future.component).name;
        // let currName = curr.component && (<any>curr.component).name;
        var futureName = '';
        var currName = '';
        var refresh = false;
        console.log("*********************************************************");
        console.log("*******************CustomReuseStrategy*******************");
        console.log("*********************************************************");
        console.log("Future Config ->", future);
        console.log("Current Config ->", curr);
        if (future.firstChild && curr.firstChild &&
            future.firstChild.url && curr.firstChild.url) {
            console.log("destination ->", future.firstChild.url[0].path);
            futureName = future.firstChild.url[0].path;
            console.log("source ->", curr.firstChild.url[0].path);
            currName = curr.firstChild.url[0].path;
        }
        else {
            console.log("Future Route ->", future);
            futureName = future.component && future.component.name;
            console.log("Current Route ->", curr);
            currName = curr.component && curr.component.name;
            if (future.routeConfig && curr.routeConfig && future.routeConfig.path && curr.routeConfig.path) {
                console.log("Future Path ->", future.routeConfig.path);
                futureName = future.routeConfig.path;
                console.log("Current Path ->", curr.routeConfig.path);
                currName = curr.routeConfig.path;
            }
        }
        // return super.shouldReuseRoute(future, curr) && name !== 'dashboard';
        if (futureName === currName && currName === 'hierarchy') {
            return true;
        }
        console.log("Should refresh->", refresh);
        return false;
    };
    return CustomReuseStrategy;
}(DefaultRouteReuseStrategy));
exports.CustomReuseStrategy = CustomReuseStrategy;
//# sourceMappingURL=app.customRoute.js.map