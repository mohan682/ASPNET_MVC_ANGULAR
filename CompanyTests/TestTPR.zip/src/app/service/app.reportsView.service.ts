import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { ServiceHelper } from './app.serviceHelper';

import IViewValue = ViewNamespace.IViewValue;

@Injectable()
export class ViewsService {


    constructor(private http: Http, private serviceHelper : ServiceHelper) {}

    getViewsObservable(): Observable<any> {
        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/Views');
        console.log("Send request ->", url);
        return this.http.get( url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

        updateViewsObservable(viewsArray: IViewValue[]): Observable<any> {

        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/Views/update');
        console.log("Send request ->", url);

        viewsArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewDTO, BP.IST.Finance.TPR.Common.Domain.DTO"

            if (item.Server != null) {
                item.Server.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauServerDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            }
        });
                
        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            TableauViews: viewsArray
        }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }
    
    refreshTableauViewsObservable(viewsArray: IViewValue[]): Observable<any> {
        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/Views/refresh');
        console.log("Send request ->", url);
        viewsArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewDTO, BP.IST.Finance.TPR.Common.Domain.DTO"
        });

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewRefreshRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            ViewsToRefresh: viewsArray
        }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);

    }
    
    refreshSelectedTableauViewsObservable(view: IViewValue): Observable<any> {
        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/Views/refresh');
        console.log("Send request ->", url);
        view.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewDTO, BP.IST.Finance.TPR.Common.Domain.DTO"
        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewRefreshRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            ViewsToRefresh: view
        }
        
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);

    }

}