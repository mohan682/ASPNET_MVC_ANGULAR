﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
// import settings from '../../settings/TPRSettings.json';

@Injectable()
export class ServiceHelper {
    constants: any;
    disableSave: boolean;
    userRoles: string[];

    constructor(private http: Http) {
        this.importSettings()
            .subscribe(data => this.getConstants(data));

        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }
    }

    public importSettings(): Observable<any> {
        //console.log("importSettings");
        return this.http.get("./settings/TPRSettings.json")
            .map(res => res.json())
            .catch(this.handleError);
    }

    public combineUrl(serviceName: string): string {
        let strCombinedUrl: string = "";
        strCombinedUrl = localStorage.getItem("WCFServiceAddress") + serviceName;
        console.log("combineUrl ->", strCombinedUrl);
        return strCombinedUrl;
    }

    public handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        console.log("Service Helper - Handle Error -> ", error);
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

    public authorizeUserForSaving(): boolean {
        this.disableSave = !(this.userRoles != undefined && this.constants != undefined &&
            this.userRoles.some(x => x == this.constants.TPRSuperUser));
        localStorage.setItem("disableSave", JSON.stringify(this.disableSave));
        console.log("Is save disabled in Service ->", this.disableSave);
        return this.disableSave;
    }

    public getConstants(data: any): void {
        this.constants = data;
        this.authorizeUserForSaving();
    }
}