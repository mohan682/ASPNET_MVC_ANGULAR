"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var Observable_1 = require('rxjs/Observable');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
// import settings from '../../settings/TPRSettings.json';
var ServiceHelper = (function () {
    function ServiceHelper(http) {
        var _this = this;
        this.http = http;
        this.importSettings()
            .subscribe(function (data) { return _this.getConstants(data); });
        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }
    }
    ServiceHelper.prototype.importSettings = function () {
        //console.log("importSettings");
        return this.http.get("./settings/TPRSettings.json")
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    ServiceHelper.prototype.combineUrl = function (serviceName) {
        var strCombinedUrl = "";
        strCombinedUrl = localStorage.getItem("WCFServiceAddress") + serviceName;
        console.log("combineUrl ->", strCombinedUrl);
        return strCombinedUrl;
    };
    ServiceHelper.prototype.handleError = function (error) {
        // In a real world app, we might use a remote logging infrastructure
        console.log("Service Helper - Handle Error -> ", error);
        var errMsg;
        if (error instanceof http_1.Response) {
            var body = error.json() || '';
            var err = body.error || JSON.stringify(body);
            errMsg = error.status + " - " + (error.statusText || '') + " " + err;
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable_1.Observable.throw(errMsg);
    };
    ServiceHelper.prototype.authorizeUserForSaving = function () {
        var _this = this;
        this.disableSave = !(this.userRoles != undefined && this.constants != undefined &&
            this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }));
        localStorage.setItem("disableSave", JSON.stringify(this.disableSave));
        console.log("Is save disabled in Service ->", this.disableSave);
        return this.disableSave;
    };
    ServiceHelper.prototype.getConstants = function (data) {
        this.constants = data;
        this.authorizeUserForSaving();
    };
    ServiceHelper = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], ServiceHelper);
    return ServiceHelper;
}());
exports.ServiceHelper = ServiceHelper;
//# sourceMappingURL=app.serviceHelper.js.map