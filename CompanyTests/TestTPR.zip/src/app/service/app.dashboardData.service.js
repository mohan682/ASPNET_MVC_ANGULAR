"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var app_serviceHelper_1 = require('./app.serviceHelper');
var DashboardDataService = (function () {
    function DashboardDataService(http, serviceHelper) {
        this.http = http;
        this.serviceHelper = serviceHelper;
    }
    //### Method call where not passing the date to the service ###//
    // getDashboardDataObservable(): Observable<any> {
    //     let url =  this.serviceHelper.combineUrl('DataWCFService.svc/Data/Dashboard?BusinessDate=11Jan2017'); //hard coded here - to be changed
    //     console.log("Send request ->", url);
    //     return this.http.get(url, { withCredentials: true })
    //         .map((res: any) => res.json())
    //         .catch(this.serviceHelper.handleError);
    // }
    //### Method call where passing the date to the service ###//
    DashboardDataService.prototype.getDashboardDataObservable = function (date3) {
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Dashboard?BusinessDate=' + date3);
        console.log("Send request ->", url);
        console.log("Date from within get dashboard data service is " + date3);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getCalculateObservable = function (date) {
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Process');
        console.log("Send request ->", url);
        var data = { "$type": "BP.IST.Finance.TPR.Common.Domain.DTO.Calculation.CalculationRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO", "HierarchyType": "Main", "ReportingDate": date };
        var body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getLastCalculatedObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/LastCalculated');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getResetCalculationFlagObservable = function (date) {
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/ResetCalculationFlag=06Jul2017');
        console.log("Send request ->", url);
        var data = { "$type": "BP.IST.Finance.TPR.Common.Domain.DTO.ResponseDTO, BP.IST.Finance.TPR.Common.Domain.DTO" };
        var body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.rollBusinessDateObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/RollSystemDate');
        console.log("Send request ->", url);
        return this.http.post(url, "", { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getIsCalculatingObservable = function (date) {
        // https://tpr.deva.am.ist.bp.com/TPR/TPR.Services.Host/DataWCFService.svc/IsCalculating?businessDate=22Aug2017&hierarchyType=Main
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Calculation/IsCalculating?businessDate=' + date + '&HierarchyType=Main');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getPublishObservable = function (date) {
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Calculation/Publish?BusinessDate=' + date + '&HierarchyType=Main');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getUnPublishObservable = function (date) {
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Calculation/Unpublish?BusinessDate=' + date + '&HierarchyType=Main');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getPublishStatusObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/DataPublished');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getLockedStatusObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/SystemDateLocked');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getLockedObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/update');
        console.log("Send request ->", url);
        var data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.SystemVariableDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            Name: "SystemDateLocked",
            NumericValue: 1.0
        };
        var body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService.prototype.getUnLockedObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/update');
        console.log("Send request ->", url);
        var data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.SystemVariableDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            Name: "SystemDateLocked",
            NumericValue: 0.0
        };
        var body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DashboardDataService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, app_serviceHelper_1.ServiceHelper])
    ], DashboardDataService);
    return DashboardDataService;
}());
exports.DashboardDataService = DashboardDataService;
//# sourceMappingURL=app.dashboardData.service.js.map