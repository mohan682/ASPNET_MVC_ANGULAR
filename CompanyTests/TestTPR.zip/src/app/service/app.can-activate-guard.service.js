"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var http_1 = require('@angular/http');
var app_serviceHelper_1 = require('./app.serviceHelper');
var app_TPRCommonService_1 = require('./app.TPRCommonService');
require('rxjs/add/operator/map');
var CanActivateGuard = (function () {
    function CanActivateGuard(http, serviceHelper, commonService, router) {
        this.http = http;
        this.serviceHelper = serviceHelper;
        this.commonService = commonService;
        this.router = router;
        this.availableRoles = new UserRolesValues();
        this.userRoles = [];
        this.isAccessDenied = true;
    }
    CanActivateGuard.prototype.getConstants = function (data) {
        this.constants = data;
    };
    CanActivateGuard.prototype.setUserRolesData = function (data) {
        var _this = this;
        this.availableRoles.$values = [];
        this.availableRoles.$values = data.Result.UserRoles.$values;
        this.availableRoles.$values.forEach(function (role) {
            _this.userRoles.push(role.Name);
        });
        console.log("User Role ->", this.userRoles);
        localStorage.setItem("UserRole", JSON.stringify(this.userRoles));
    };
    CanActivateGuard.prototype.isUserAuthorised = function () {
        var _this = this;
        return this.userRoles != undefined && this.constants != undefined &&
            (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                this.userRoles.some(function (x) { return x == _this.constants.TPRMarginManagement; }) ||
                this.userRoles.some(function (x) { return x == _this.constants.TPRRiskManagement; }) ||
                this.userRoles.some(function (x) { return x == _this.constants.TPRITSupport; }));
    };
    CanActivateGuard.prototype.canActivate = function (route, state) {
        var _this = this;
        return this.serviceHelper.importSettings()
            .map(function (data) {
            _this.getConstants(data);
            console.log('canActivate called');
            if (localStorage.getItem("UserRole")) {
                _this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
                console.log("User Roles from Local Storage ->", _this.userRoles);
                console.log("Is User Authorized ->", _this.isUserAuthorised());
                if (!_this.isUserAuthorised()) {
                    _this.router.navigate(['/error']);
                }
                return _this.isUserAuthorised();
            }
            else {
                _this.commonService.getUserRolesObservable()
                    .map(function (data) {
                    _this.setUserRolesData(data);
                    console.log("Is User Authorized ->", _this.isUserAuthorised());
                    if (!_this.isUserAuthorised()) {
                        _this.router.navigate(['/error']);
                    }
                    return _this.isUserAuthorised();
                });
            }
        });
    };
    CanActivateGuard = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, app_serviceHelper_1.ServiceHelper, app_TPRCommonService_1.TPRCommonService, router_1.Router])
    ], CanActivateGuard);
    return CanActivateGuard;
}());
exports.CanActivateGuard = CanActivateGuard;
var UserRolesValues = (function () {
    function UserRolesValues($values) {
        if ($values === void 0) { $values = null; }
        this.$values = $values;
    }
    return UserRolesValues;
}());
var UserRolesValue = (function () {
    function UserRolesValue(Name, Users) {
        if (Name === void 0) { Name = null; }
        if (Users === void 0) { Users = null; }
        this.Name = Name;
        this.Users = Users;
    }
    return UserRolesValue;
}());
var UsersValue = (function () {
    function UsersValue(LoginName, Role) {
        if (LoginName === void 0) { LoginName = null; }
        if (Role === void 0) { Role = null; }
        this.LoginName = LoginName;
        this.Role = Role;
    }
    return UsersValue;
}());
//# sourceMappingURL=app.can-activate-guard.service.js.map