import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { ServiceHelper } from './app.serviceHelper';

import IFileUploadModel = FileUploadNameSpace.IFileUploadModel;

@Injectable()
export class FileUploadService {
    constructor(private http: Http, private serviceHelper: ServiceHelper) { }

    getFileUploadDetails(): Observable<any> {
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/LoadedFiles');
        //console.log("get request ->", url);

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getErrorDetails(id: number): Observable<any> {
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/GetErrors=');

        url = url + id.toString();
        //debugger;
        //console.log("get request ->", url);

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    uploadFile(clsFileUploadModelObj: IFileUploadModel): Observable<any> {
        
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/LoadFile');

        if (clsFileUploadModelObj.FileType == 8) {
            url = this.serviceHelper.combineUrl('HierarchyWCFService.svc/data/updateHierarchyRegionAllocations');
        }

        //console.log("post request ->", url);

        let body = JSON.stringify(clsFileUploadModelObj);

        //console.log("body ->", body);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }
}