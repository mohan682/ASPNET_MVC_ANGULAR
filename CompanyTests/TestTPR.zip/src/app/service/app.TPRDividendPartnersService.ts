﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import IDividendPartnerValue = DividendPartnerNameSpace.IDividendPartnerValue;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class TPRDividendPartnersService {

    constructor(private http: Http, private serviceHelper : ServiceHelper) { }

    getDividendPartnersObservable(): Observable<any> {
        let url =  this.serviceHelper.combineUrl('HierarchyWCFService.svc/DividendPartners');
        console.log("Send request ->", url);

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateDividendPartnersObservable(dpArray: IDividendPartnerValue[]): Observable<any> {
        let url =  this.serviceHelper.combineUrl('HierarchyWCFService.svc/DividendPartners/update');
        console.log("Send request ->", url);

        dpArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerDTO, BP.IST.Finance.TPR.Common.Domain.DTO"

            if (item.BusinessSegment != null) {
                item.BusinessSegment.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.BusinessSegmentDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            }
        });
                
        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            DividendPartners: dpArray
        }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}