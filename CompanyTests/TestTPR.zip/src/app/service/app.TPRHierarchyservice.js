"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var app_serviceHelper_1 = require('./app.serviceHelper');
var TPRHierarchyservice = (function () {
    function TPRHierarchyservice(http, serviceHelper) {
        this.http = http;
        this.serviceHelper = serviceHelper;
    }
    TPRHierarchyservice.prototype.getHierarchyObservable = function () {
        var _url = this.serviceHelper.combineUrl('HierarchyWCFService.svc/Data/LightWeight?HierarchyType=Main');
        //console.log("Send request ->", _url);
        return this.http.get(_url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.getUserPreferenceObservable = function () {
        var _url = this.serviceHelper.combineUrl('UtilWCFService.svc/UserPreferences/Get');
        //console.log("get request ->", _url);
        return this.http.get(_url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.getNodeLevelDataForEdit = function (nodeId, BusinessDate) {
        var _serviceName = "DataWCFService.svc/Data/Structure?BusinessDate=" + BusinessDate + "&HierarchyType=Main&NodeId=" + nodeId;
        var _url = this.serviceHelper.combineUrl(_serviceName);
        //console.log("Send request ->", _url);
        //console.log(_url);
        return this.http.get(_url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.getHierarchyForProfitGroupsObservable = function () {
        var _url = this.serviceHelper.combineUrl('HierarchyWCFService.svc/Data/GetProfitAlertGrpsForNodes?HierarchyType=Main');
        return this.http.get(_url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.updateNodeLevelDataForEdit = function (nodeDataForPostToServer) {
        //debugger;
        //let _url = "https://tpr.deva.am.ist.bp.com/TPR/TPR.Services.Host/HierarchyWCFService.svc/data/updateStructureProperties";
        var _serviceName = "HierarchyWCFService.svc/data/updateStructureProperties";
        var _url = this.serviceHelper.combineUrl(_serviceName);
        var body = JSON.stringify(nodeDataForPostToServer);
        return this.http.post(_url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.updateNodeLevelEnterValueForPost = function (enterValueDataForPostToServer) {
        //debugger;
        //let _url = "https://tpr.deva.am.ist.bp.com/TPR/TPR.Services.Host/DataWCFService.svc/Data/Update";
        var _serviceName = "DataWCFService.svc/Data/Update";
        var _url = this.serviceHelper.combineUrl(_serviceName);
        var body = JSON.stringify(enterValueDataForPostToServer);
        return this.http.post(_url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.updateLightWeight = function (objHierarchyRemoveNodeForPostToServer) {
        //debugger;
        //let _url = "https://tpr.deva.am.ist.bp.com/TPR/TPR.Services.Host/HierarchyWCFService.svc/data/updateLightWeight";  
        var _serviceName = "HierarchyWCFService.svc/data/updateLightWeight";
        var _url = this.serviceHelper.combineUrl(_serviceName);
        //console.log(_url);
        var body = JSON.stringify(objHierarchyRemoveNodeForPostToServer);
        //console.log(body);
        return this.http.post(_url, objHierarchyRemoveNodeForPostToServer, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.updateUserPreferences = function (objclsFavourateNode_Post) {
        //debugger;
        var _serviceName = "UtilWCFService.svc/UserPreferences/Update";
        var _url = this.serviceHelper.combineUrl(_serviceName);
        //console.log(_url);
        var body = JSON.stringify(objclsFavourateNode_Post);
        //console.log(body);
        return this.http.post(_url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRHierarchyservice.prototype.simpleStringify = function (object) {
        var simpleObject = {};
        for (var prop in object) {
            if (!object.hasOwnProperty(prop)) {
                continue;
            }
            if (typeof (object[prop]) == 'object') {
                continue;
            }
            if (typeof (object[prop]) == 'function') {
                continue;
            }
            simpleObject[prop] = object[prop];
        }
        return JSON.stringify(simpleObject); // returns cleaned up JSON
    };
    ;
    TPRHierarchyservice = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, app_serviceHelper_1.ServiceHelper])
    ], TPRHierarchyservice);
    return TPRHierarchyservice;
}());
exports.TPRHierarchyservice = TPRHierarchyservice;
//# sourceMappingURL=app.TPRHierarchyservice.js.map