import { ActivatedRouteSnapshot, DetachedRouteHandle, Params, RouteReuseStrategy } from "@angular/router";
import { Injectable } from '@angular/core';

class DefaultRouteReuseStrategy implements RouteReuseStrategy {
    shouldDetach(route: ActivatedRouteSnapshot): boolean { return false; }
    store(route: ActivatedRouteSnapshot, detachedTree: DetachedRouteHandle): void { }
    shouldAttach(route: ActivatedRouteSnapshot): boolean { return false; }
    retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle | null { return null; }
    shouldReuseRoute(future: ActivatedRouteSnapshot, curr: ActivatedRouteSnapshot): boolean {
        return future.routeConfig === curr.routeConfig;
    }
}

export class CustomReuseStrategy extends DefaultRouteReuseStrategy {
    shouldReuseRoute(future: ActivatedRouteSnapshot, curr: ActivatedRouteSnapshot): boolean {
        // let futureName = future.component && (<any>future.component).name;
        // let currName = curr.component && (<any>curr.component).name;

        let futureName = '';
        let currName = '';
        let refresh = false;

        console.log("*********************************************************");
        console.log("*******************CustomReuseStrategy*******************");
        console.log("*********************************************************");
        console.log("Future Config ->", future);
        console.log("Current Config ->", curr)

        if (future.firstChild && curr.firstChild &&
            future.firstChild.url && curr.firstChild.url) {
            console.log("destination ->", future.firstChild.url[0].path);
            futureName = future.firstChild.url[0].path;
            console.log("source ->", curr.firstChild.url[0].path);
            currName = curr.firstChild.url[0].path;
        }
        else {
            console.log("Future Route ->", future);
            futureName = future.component && (<any>future.component).name;
            console.log("Current Route ->", curr);
            currName = curr.component && (<any>curr.component).name;
            
            if (future.routeConfig && curr.routeConfig && future.routeConfig.path && curr.routeConfig.path) {
                console.log("Future Path ->", future.routeConfig.path);
                futureName = future.routeConfig.path;
                console.log("Current Path ->", curr.routeConfig.path);
                currName = curr.routeConfig.path;
            }
        }
        // return super.shouldReuseRoute(future, curr) && name !== 'dashboard';

        if (futureName === currName && currName === 'hierarchy') {
            return true;
        }

        console.log("Should refresh->", refresh);
        return false;
    }
}
