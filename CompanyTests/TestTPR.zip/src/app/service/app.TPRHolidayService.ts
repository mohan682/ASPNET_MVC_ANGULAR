﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import IHolidayValue = HolidayNamespace.IHolidayValue;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class TPRHolidayService {

    constructor(private http: Http, private serviceHelper : ServiceHelper) { }

    getHolidaysObservable(): Observable<any> {
        let _url =  this.serviceHelper.combineUrl("HierarchyWCFService.svc/Holiday");
        console.log("Send request ->", _url);

        return this.http.get(_url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateHolidayObservable(holiday: IHolidayValue): Observable<any> {
        let _url =  this.serviceHelper.combineUrl("HierarchyWCFService.svc/Holiday/Update");
        console.log("Send request ->", _url);

        holiday.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.HolidayDTO, BP.IST.Finance.TPR.Common.Domain.DTO"

        if (holiday.Region != null) {
            holiday.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        }
        
        let body = JSON.stringify(holiday);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    deleteHolidayObservable(holiday: IHolidayValue): Observable<any> {
        let _url =  this.serviceHelper.combineUrl("HierarchyWCFService.svc/Holiday/Update");
        console.log("Send request ->", _url);

        holiday.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.HolidayDTO, BP.IST.Finance.TPR.Common.Domain.DTO"

        if (holiday.Region != null) {
            holiday.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        }

        let body = JSON.stringify(holiday);                

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}