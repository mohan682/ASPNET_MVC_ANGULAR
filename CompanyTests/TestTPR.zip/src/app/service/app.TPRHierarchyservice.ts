﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import { TreeNode } from 'primeng/components/common/api';
//import IRootObject = HierarchyNamespace.IRootObject;
import IHierarchyNodePostData = HierarchyNamespace.IHierarchyNodePostData;
import IHierarchyNodeEnterValuePostData = HierarchyNamespace.IHierarchyNodeEnterValuePostData;
import IHierarchyRemoveNode_Post = HierarchyNamespace.IHierarchyRemoveNode_Post;
import IFavourateNode_Post = HierarchyNamespace.IFavourateNode_Post;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class TPRHierarchyservice {

    constructor(private http: Http, private serviceHelper: ServiceHelper) { }

    getHierarchyObservable(): Observable<any> {
        let _url = this.serviceHelper.combineUrl('HierarchyWCFService.svc/Data/LightWeight?HierarchyType=Main');
        //console.log("Send request ->", _url);

        return this.http.get(_url, { withCredentials: true })
            //return this.http.get("./app/data/TprTree.json")    
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getUserPreferenceObservable(): Observable<any> {
        let _url = this.serviceHelper.combineUrl('UtilWCFService.svc/UserPreferences/Get');
        //console.log("get request ->", _url);

        return this.http.get(_url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getNodeLevelDataForEdit(nodeId: number, BusinessDate: string): Observable<any> {
        let _serviceName = "DataWCFService.svc/Data/Structure?BusinessDate=" + BusinessDate + "&HierarchyType=Main&NodeId=" + nodeId;
        let _url = this.serviceHelper.combineUrl(_serviceName);
        //console.log("Send request ->", _url);

        //console.log(_url);
        return this.http.get(_url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getHierarchyForProfitGroupsObservable(): Observable<any> {
        let _url = this.serviceHelper.combineUrl('HierarchyWCFService.svc/Data/GetProfitAlertGrpsForNodes?HierarchyType=Main');
        return this.http.get(_url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateNodeLevelDataForEdit(nodeDataForPostToServer: IHierarchyNodePostData): Observable<any> {
        //debugger;
        //let _url = "https://tpr.deva.am.ist.bp.com/TPR/TPR.Services.Host/HierarchyWCFService.svc/data/updateStructureProperties";
        let _serviceName = "HierarchyWCFService.svc/data/updateStructureProperties";
        let _url = this.serviceHelper.combineUrl(_serviceName);

        let body = JSON.stringify(nodeDataForPostToServer);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateNodeLevelEnterValueForPost(enterValueDataForPostToServer: IHierarchyNodeEnterValuePostData): Observable<any> {
        //debugger;
        //let _url = "https://tpr.deva.am.ist.bp.com/TPR/TPR.Services.Host/DataWCFService.svc/Data/Update";
        let _serviceName = "DataWCFService.svc/Data/Update";
        let _url = this.serviceHelper.combineUrl(_serviceName);

        let body = JSON.stringify(enterValueDataForPostToServer);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateLightWeight(objHierarchyRemoveNodeForPostToServer: IHierarchyRemoveNode_Post): Observable<any> {
        //debugger;
        //let _url = "https://tpr.deva.am.ist.bp.com/TPR/TPR.Services.Host/HierarchyWCFService.svc/data/updateLightWeight";  
        let _serviceName = "HierarchyWCFService.svc/data/updateLightWeight";
        let _url = this.serviceHelper.combineUrl(_serviceName);
        //console.log(_url);

        let body = JSON.stringify(objHierarchyRemoveNodeForPostToServer);
        //console.log(body);

        return this.http.post(_url, objHierarchyRemoveNodeForPostToServer, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateUserPreferences(objclsFavourateNode_Post: IFavourateNode_Post): Observable<any> {
        //debugger;
        let _serviceName = "UtilWCFService.svc/UserPreferences/Update";
        let _url = this.serviceHelper.combineUrl(_serviceName);
        //console.log(_url);

        let body = JSON.stringify(objclsFavourateNode_Post);
        //console.log(body);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    simpleStringify(object: any) {
        var simpleObject = {};
        for (var prop in object) {
            if (!object.hasOwnProperty(prop)) {
                continue;
            }
            if (typeof (object[prop]) == 'object') {
                continue;
            }
            if (typeof (object[prop]) == 'function') {
                continue;
            }
            simpleObject[prop] = object[prop];
        }
        return JSON.stringify(simpleObject); // returns cleaned up JSON
    };
}