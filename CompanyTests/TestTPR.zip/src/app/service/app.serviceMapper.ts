﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
// import settings from '../../settings/TPRSettings.json';

@Injectable()
export class ServiceMapper {

    private rl: string;

    constructor(private http: Http) {
    }
}