"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var Observable_1 = require('rxjs/Observable');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var app_serviceHelper_1 = require('./app.serviceHelper');
var DataSourcesService = (function () {
    function DataSourcesService(http, serviceHelper) {
        this.http = http;
        this.serviceHelper = serviceHelper;
    }
    DataSourcesService.prototype.getDataSourcesObservable = function () {
        var url = this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DataSourcesService.prototype.handleError = function (error) {
        // In a real world app, we might use a remote logging infrastructure
        var errMsg;
        if (error instanceof http_1.Response) {
            var body = error.json() || '';
            var err = body.error || JSON.stringify(body);
            errMsg = error.status + " - " + (error.statusText || '') + " " + err;
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable_1.Observable.throw(errMsg);
    };
    DataSourcesService.prototype.updateDataSourcesObservable = function (datasourcesArray) {
        var url = this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources/update');
        console.log("Send request ->", url);
        datasourcesArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            if (item.Server != null) {
                item.Server.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauServerDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            }
        });
        var data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            TableauDataSources: datasourcesArray
        };
        var body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DataSourcesService.prototype.refreshDataSourcesObservable = function (datasourcesArray) {
        var url = this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources/refresh');
        console.log("Send request ->", url);
        datasourcesArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });
        var data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceRefreshRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            DataSourcesToRefresh: datasourcesArray
        };
        var body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DataSourcesService.prototype.refreshSelectedDataSourcesObservable = function (datasource) {
        var url = this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources/refresh');
        console.log("Send request ->", url);
        datasource.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        var data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceRefreshRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            DataSourcesToRefresh: datasource
        };
        var body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    DataSourcesService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, app_serviceHelper_1.ServiceHelper])
    ], DataSourcesService);
    return DataSourcesService;
}());
exports.DataSourcesService = DataSourcesService;
//# sourceMappingURL=app.dataSources.service.js.map