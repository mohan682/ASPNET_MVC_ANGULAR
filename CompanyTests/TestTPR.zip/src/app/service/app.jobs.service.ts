import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { ServiceHelper } from './app.serviceHelper';

import IDataSourceValue = JobsNamespace.IJobValue;

@Injectable()
export class JobService {

    constructor(private http: Http, private serviceHelper: ServiceHelper) { }

    getJobsObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('JobWCFService.svc/Jobs');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateJobRefresh(jobToBeRefreshed: IDataSourceValue): Observable<any> {
        debugger;
        let _url = this.serviceHelper.combineUrl("JobWCFService.svc/ExecuteJob");

        console.log("Send request ->", _url);

        let body = JSON.stringify(jobToBeRefreshed);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }
}