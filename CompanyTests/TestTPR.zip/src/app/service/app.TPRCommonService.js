"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var app_serviceHelper_1 = require('./app.serviceHelper');
var TPRCommonService = (function () {
    function TPRCommonService(http, serviceHelper) {
        this.http = http;
        this.serviceHelper = serviceHelper;
    }
    TPRCommonService.prototype.getEnvironmentObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/Environment');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRCommonService.prototype.getSystemVersionObservable = function () {
        var url = this.serviceHelper.combineUrl('UtilWCFService.svc/SystemVersion');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRCommonService.prototype.getSystemDateObservable = function () {
        var url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/SystemDate');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRCommonService.prototype.getUserRolesObservable = function () {
        var url = this.serviceHelper.combineUrl('SecurityWCFService.svc/UserRoles/LoadAll');
        console.log("Send request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRCommonService.prototype.SetSystemDate = function (updatedSystemDate) {
        //debugger;
        var _serviceName = "SystemVariableWCFService.svc/SysVar/SetSystemDate";
        var _url = this.serviceHelper.combineUrl(_serviceName);
        //console.log(_url);
        var body = JSON.stringify(updatedSystemDate);
        //console.log(body);
        return this.http.post(_url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    TPRCommonService.prototype.getFormattedSystemDate = function (unFormattedDate) {
        //debugger;
        var formattedDateString = "";
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var year = unFormattedDate.getUTCFullYear().toString();
        var month = m_names[(unFormattedDate.getUTCMonth())];
        var day = unFormattedDate.getUTCDate().toString().length > 1 ? unFormattedDate.getUTCDate().toString() : "0" + unFormattedDate.getUTCDate().toString();
        var hours = unFormattedDate.getUTCHours().toString().length > 1 ? unFormattedDate.getUTCHours().toString() : "0" + unFormattedDate.getUTCHours().toString();
        var minutes = unFormattedDate.getUTCMinutes().toString().length > 1 ? unFormattedDate.getUTCMinutes().toString() : "0" + unFormattedDate.getUTCMinutes().toString();
        var seconds = unFormattedDate.getUTCSeconds().toString().length > 1 ? unFormattedDate.getUTCSeconds().toString() : "0" + unFormattedDate.getUTCSeconds().toString();
        formattedDateString = day + " " + month + " " + year + " " + hours + ":" + minutes + ":" + seconds;
        return formattedDateString;
    };
    TPRCommonService.prototype.getFormattedSystemDate_Date = function (unFormattedDate) {
        //debugger;
        var formattedDateString = "";
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var year = unFormattedDate.getUTCFullYear().toString();
        var month = m_names[(unFormattedDate.getUTCMonth())];
        var day = unFormattedDate.getUTCDate().toString().length > 1 ? unFormattedDate.getUTCDate().toString() : "0" + unFormattedDate.getUTCDate().toString();
        formattedDateString = day + " " + month + " " + year;
        return formattedDateString;
    };
    TPRCommonService.prototype.getFormattedSystemDate_NonUTC = function (unFormattedDate) {
        //debugger;
        var formattedDateString = "";
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var year = unFormattedDate.getFullYear().toString();
        var month = m_names[(unFormattedDate.getMonth())];
        var day = unFormattedDate.getDate().toString().length > 1 ? unFormattedDate.getDate().toString() : "0" + unFormattedDate.getDate().toString();
        formattedDateString = day + " " + month + " " + year;
        return formattedDateString;
    };
    TPRCommonService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, app_serviceHelper_1.ServiceHelper])
    ], TPRCommonService);
    return TPRCommonService;
}());
exports.TPRCommonService = TPRCommonService;
//# sourceMappingURL=app.TPRCommonService.js.map