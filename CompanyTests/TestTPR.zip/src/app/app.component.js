"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var primeng_1 = require('primeng/primeng');
var app_TPRCommonService_1 = require('./service/app.TPRCommonService');
var app_TPRHolidayService_1 = require('./service/app.TPRHolidayService');
var app_serviceHelper_1 = require('./service/app.serviceHelper');
var app_workDayService_1 = require('./service/app.workDayService');
var AppComponent = (function () {
    function AppComponent(tPRcommonService, serviceHelper, confirmationService, router, tprHolidayService, workDayService) {
        var _this = this;
        this.tPRcommonService = tPRcommonService;
        this.serviceHelper = serviceHelper;
        this.confirmationService = confirmationService;
        this.router = router;
        this.tprHolidayService = tprHolidayService;
        this.workDayService = workDayService;
        this.strEnvironment = '';
        this.strApplicationVersion = '';
        this.UserRoles = new UserRolesValues();
        this.availableRoles = [];
        this.serviceUrl = '';
        this.blnChangeBusinessDate = false;
        this.holidays = [];
        this.arrGlobalHolidayDates = [];
        this.blnBusinessDateChangeShowDialog = false;
        this.strBusinessDateChangeDialogMessage = "";
        this.disableSave = true;
        this.disableBusinessDate = true;
        this.isAccessDenied = true;
        this.showBusDateMessage = false;
        this.rollDateMessage = "TPR is not yet rolled to the current business date";
        this.router.events.subscribe(function (evt) {
            if (evt instanceof router_1.NavigationEnd) {
                // trick the Router into believing it's last link wasn't previously loaded
                _this.router.navigated = false;
                // if you need to scroll back to top, here is the right place
                window.scrollTo(0, 0);
            }
        });
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        // console.log("date3 from within app component " + this.date3);
        this.blnChangeBusinessDate = false;
        this.hierarchyItems = [
            { label: 'Flat View', icon: 'fa-list-alt', routerLink: ['flatView'] },
            { label: 'Tree View', icon: 'fa-sitemap', routerLink: ['hierarchy'] },
            { label: 'Node Types', icon: 'fa-code-fork', routerLink: ['nodeTypes'] },
            { label: 'Regions', icon: 'fa-globe', routerLink: ['region'] },
            { label: 'Business Segments', icon: 'fa-institution', routerLink: ['businessSegments'] },
            { label: 'Dividend Partners', icon: 'fa-handshake-o', routerLink: ['dividendPartners'] },
            { label: 'Holidays', icon: 'fa-hotel', routerLink: ['holidays'] },
            { label: 'Tags', icon: 'fa-hashtag', routerLink: ['tags'] },
            { label: 'Profit Alert Groups', icon: 'fa-bell-o', routerLink: ['profitAlert'] }
        ];
        this.serviceHelper.importSettings()
            .subscribe(function (data) { return _this.getServiceUrl(data); });
        this.dashboardItems = [
            { label: 'Dashboard', icon: 'fa-tachometer', routerLink: ['dashboard'] }
        ];
        this.menuItems = [
            {
                label: 'Dashboard',
                items: [
                    { label: 'Dashboard', icon: 'fa-tachometer', routerLink: ['dashboard'] }
                ]
            },
            {
                label: 'Hierarchy',
                items: [
                    { label: 'Flat View', icon: 'fa-list-alt', routerLink: ['flatView'] },
                    { label: 'Tree View', icon: 'fa-sitemap', routerLink: ['hierarchy'] },
                    { label: 'Node Types', icon: 'fa-code-fork', routerLink: ['nodeTypes'] },
                    { label: 'Regions', icon: 'fa-globe', routerLink: ['region'] },
                    { label: 'Business Segments', icon: 'fa-institution', routerLink: ['businessSegments'] },
                    { label: 'Dividend Partners', icon: 'fa-handshake-o', routerLink: ['dividendPartners'] },
                    { label: 'Holidays', icon: 'fa-hotel', routerLink: ['holidays'] },
                    { label: 'Tags', icon: 'fa-hashtag', routerLink: ['tags'] },
                    { label: 'Profit Alert Groups', icon: 'fa-bell-o', routerLink: ['profitAlert'] }
                ]
            },
            {
                label: 'Feeds',
                items: [
                    { label: 'File Upload', icon: 'fa-cloud-upload', routerLink: ['fileUpload'] },
                    { label: 'Jobs', icon: 'fa-cogs', routerLink: ['jobs'] }
                ]
            },
            {
                label: 'Reports',
                items: [
                    { label: 'Views', icon: 'fa-pie-chart', routerLink: ['reportsView'] },
                    { label: 'Data Sources', icon: 'fa-database', routerLink: ['dataSources'] }
                ]
            }
        ];
        this.feedsItems = [
            { label: 'File Upload', icon: 'fa-cloud-upload', routerLink: ['fileUpload'] },
            { label: 'Jobs', icon: 'fa-cogs', routerLink: ['jobs'] }
        ];
        this.reportsItems = [
            { label: 'Views', icon: 'fa-pie-chart', routerLink: ['reportsView'] },
            { label: 'Data Sources', icon: 'fa-database', routerLink: ['dataSources'] }
        ];
        this.setCommonData();
    };
    AppComponent.prototype.setCommonData = function () {
        var _this = this;
        this.workDayService.getWorkingDatesObservable()
            .subscribe(function (data) { return _this.getWorkingDates(data); });
        this.tPRcommonService.getEnvironmentObservable()
            .subscribe(function (data) {
            _this.setEnvironmentData(data);
            _this.tPRcommonService.getUserRolesObservable()
                .subscribe(function (data) {
                _this.setUserRolesData(data);
                _this.serviceHelper.importSettings()
                    .subscribe(function (data) { return _this.getConstants(data); });
            });
        });
        this.tPRcommonService.getSystemVersionObservable()
            .subscribe(function (data) { return _this.setSystemVersionData(data); });
    };
    AppComponent.prototype.RefreshEnvironmentData = function () {
        var _this = this;
        console.log("Refresh Header");
        this.rollDateMessage = "TPR is not yet rolled to the current business date";
        this.tPRcommonService.getEnvironmentObservable()
            .subscribe(function (data) { return _this.setEnvironmentData(data); });
    };
    AppComponent.prototype.getConstants = function (data) {
        console.log("Get Constants");
        this.constants = data;
        this.authorizeUser();
    };
    AppComponent.prototype.authorizeUser = function () {
        console.log("Is user authorised ->", this.isUserAuthorised());
        this.isAccessDenied = !this.isUserAuthorised();
        if (this.isUserAuthorised()) {
            this.disableSave = !this.canUserSave();
            this.disableBusinessDate = !this.canUserEditBusinessDate();
            localStorage.setItem("disableSave", JSON.stringify(this.disableSave));
            console.log("Is save disabled in componenet ->", this.disableSave);
        }
        else {
            console.log('unauthorized...');
            this.router.navigate(['/error']);
        }
    };
    AppComponent.prototype.isUserAuthorised = function () {
        var _this = this;
        return this.availableRoles != undefined && this.constants != undefined &&
            (this.availableRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                this.availableRoles.some(function (x) { return x == _this.constants.TPRMarginManagement; }) ||
                this.availableRoles.some(function (x) { return x == _this.constants.TPRRiskManagement; }) ||
                this.availableRoles.some(function (x) { return x == _this.constants.TPRITSupport; }));
    };
    AppComponent.prototype.canUserSave = function () {
        var _this = this;
        return this.availableRoles != undefined && this.constants != undefined &&
            this.availableRoles.some(function (x) { return x == _this.constants.TPRSuperUser; });
    };
    AppComponent.prototype.canUserEditBusinessDate = function () {
        var _this = this;
        return (this.strEnvironment.toUpperCase() === "DEV" ||
            this.strEnvironment.toUpperCase() === "UAT" ||
            this.strEnvironment.toUpperCase() === "SYSTEST" ||
            this.strEnvironment.toUpperCase() === "REGTEST" ||
            this.strEnvironment.toUpperCase() === "ST" ||
            (this.availableRoles != undefined && this.constants != undefined &&
                this.availableRoles.some(function (x) { return x == _this.constants.TPRITSupport; })));
    };
    AppComponent.prototype.getWorkingDates = function (data) {
        this.validDates = data.Result.Range.$values;
        localStorage.setItem("WorkingDates", JSON.stringify(this.validDates));
        console.log("Component Working Dates ->", this.validDates);
    };
    AppComponent.prototype.setEnvironmentData = function (data) {
        var _this = this;
        this.strEnvironment = data.Result.StringValue;
        this.tPRcommonService.getSystemDateObservable()
            .subscribe(function (data) { return _this.setSystemBusinessDateData(data); });
    };
    AppComponent.prototype.setSystemVersionData = function (data) {
        this.strApplicationVersion = data.Result.ServerVersionInfo;
    };
    AppComponent.prototype.getServiceUrl = function (data) {
        //console.log("getServiceUrl");
        this.serviceUrl = JSON.stringify(data.WCFServiceAddress);
        this.serviceUrl = this.serviceUrl.replace('"h', 'h');
        this.serviceUrl = this.serviceUrl.replace('/"', '/');
        //console.log("WCFServiceAddress -> ", this.serviceUrl);
        localStorage.setItem("WCFServiceAddress", this.serviceUrl);
    };
    AppComponent.prototype.setSystemBusinessDateData = function (data) {
        var _this = this;
        var myDate = new Date(data.Result.DateValue);
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var businessDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        localStorage.setItem("BusinessDate", businessDate);
        var output = myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        this.date3 = output;
        this.tprHolidayService.getHolidaysObservable()
            .subscribe(function (data) { return _this.setTPRHolidays(data); });
        var utcDate = this.tPRcommonService.getFormattedSystemDate_Date(new Date());
        console.log("UTC Date ->", utcDate);
        console.log("System Date ->", this.date3);
        this.showBusDateMessage = (this.date3 != utcDate);
        console.log("Is Business Date Rolled ->", this.showBusDateMessage);
    };
    AppComponent.prototype.setUserRolesData = function (data) {
        var _this = this;
        console.log("setUserRolesData");
        this.UserRoles.$values = [];
        this.UserRoles.$values = data.Result.UserRoles.$values;
        this.UserRoles.$values.forEach(function (role) {
            _this.availableRoles.push(role.Name);
        });
        this.strUserRoleName = this.availableRoles[0];
        console.log("User Role ->", this.availableRoles);
        localStorage.setItem("UserRole", JSON.stringify(this.availableRoles));
    };
    AppComponent.prototype.validateBusinessDate = function () {
        return true;
    };
    AppComponent.prototype.changeBusinessDate = function () {
        var _this = this;
        //debugger;
        var messageForConfirmation = "";
        var currentBusinessDate = new Date(localStorage.getItem("BusinessDate"));
        var proposedBusinessDate = new Date(this.date3);
        if (proposedBusinessDate < currentBusinessDate) {
            messageForConfirmation = "Disclaimer: \n\nChanging the reporting date will unpublish all the data from " + this.setFormattedDate(currentBusinessDate.toString()) + " ";
            messageForConfirmation += " to " + this.setFormattedDate(proposedBusinessDate.toString()) + ", thereby making data unavailable in Tableau to report for this duration. \n\n";
            messageForConfirmation += "Pressing 'Yes' confirms TPR Super Users have supported this action and the Reporting Date will be changed.\n";
            messageForConfirmation += "Pressing 'No' will close this request.";
        }
        else if (proposedBusinessDate > currentBusinessDate) {
            messageForConfirmation = "Updating System Reporting Date to " + this.setFormattedDate(this.date3.toString()) + ". Would you like to proceed?";
        }
        else if ((proposedBusinessDate.toString() == currentBusinessDate.toString())) {
            return;
        }
        this.blnChangeBusinessDate = true;
        this.confirmationService.confirm({
            header: "Update Reporting Date",
            message: messageForConfirmation,
            rejectVisible: true,
            acceptVisible: true,
            accept: function () {
                var previousBusinessDateinCaseOfIssue = new Date(localStorage.getItem("BusinessDate"));
                localStorage.setItem("BusinessDate", _this.setFormattedDate(_this.date3));
                console.log("New business date -> ", localStorage.getItem("BusinessDate"));
                _this.tPRcommonService.SetSystemDate(_this.setFormattedDate(_this.date3))
                    .subscribe(function (response) {
                    _this.blnChangeBusinessDate = false;
                    console.log("Response ->", response);
                    if (response.Error) {
                        debugger;
                        console.log("Previous Date ->", _this.setFormattedDate(previousBusinessDateinCaseOfIssue.toString()));
                        console.log("Current Business Date ->", currentBusinessDate);
                        _this.date3 = _this.setFormattedDate(previousBusinessDateinCaseOfIssue.toString());
                        localStorage.setItem("BusinessDate", _this.setFormattedDate(_this.date3));
                        _this.setBusinessDate();
                        _this.blnBusinessDateChangeShowDialog = true;
                        _this.strBusinessDateChangeDialogMessage = response.Error;
                    }
                    else {
                        _this.setBusinessDate();
                        _this.blnBusinessDateChangeShowDialog = true;
                        _this.strBusinessDateChangeDialogMessage = "Reporting Date is now changed to " + _this.setFormattedDate(proposedBusinessDate.toString());
                        _this.RefreshEnvironmentData();
                        _this.router.navigateByUrl('/DummyComponent', { skipLocationChange: true }); //added EH 
                        _this.router.navigate(['/dashboard']);
                    }
                }, function (error) {
                    console.log(error);
                });
            },
            reject: function () {
                _this.date3 = _this.setFormattedDate(localStorage.getItem("BusinessDate"));
            }
        });
    };
    AppComponent.prototype.setFormattedDate = function (data) {
        var myDate = new Date(data);
        var output = "";
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var modifiedDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        output = myDate.getDate().toString().length > 1 ?
            myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear() :
            "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        return output;
    };
    AppComponent.prototype.setTPRHolidays = function (data) {
        var _this = this;
        var utcDate = this.tPRcommonService.getFormattedSystemDate_Date(new Date());
        this.holidays = data.Result.Holidays.$values;
        for (var i = 0; i < this.holidays.length; i++) {
            this.holiday = this.holidays[i];
            if (this.holiday.Region != null) {
                this.holiday.HolidayType = 'Regional';
            }
            else {
                this.holiday.HolidayType = 'Global';
                this.arrGlobalHolidayDates.push(this.setFormattedDate(this.holiday.Date));
            }
        }
        localStorage.setItem("Holidays", JSON.stringify(this.holidays));
        var nextWorkingDay = this.setFormattedDate(this.getPreviousorNextWorkingDay(new Date(utcDate), false).toString());
        console.log("Next Working Day ->", nextWorkingDay);
        if (this.holidays.some(function (d) { return (d.HolidayType == 'Global' &&
            _this.setFormattedDate(d.Date).toString() == utcDate.toString()); })
            && nextWorkingDay == this.date3) {
            console.log("Holiday Roll Message");
            this.showBusDateMessage = true;
            this.rollDateMessage = "TPR is rolled to business date '" + this.date3 + "' as today is a Global holiday '" + this.holiday.Name + "' in TPR.";
        }
        this.setBusinessDate();
    };
    AppComponent.prototype.setBusinessDate = function () {
        if (this.strEnvironment.toLowerCase() == "local" || this.strEnvironment.toLowerCase() == "dev" || this.strEnvironment.toLowerCase() == "test") {
            var currentBusinessDate = new Date(this.date3);
            this.intBusinessDatePositiveIncrement = 5;
            this.intBusinessDateNegativeIncrement = -5;
            // this is to componsate for the 2 weekends i.e. saturday and sunday.
            this.intBusinessDatePositiveIncrement += 2;
            this.intBusinessDateNegativeIncrement += -2;
            var newIncrementDate = currentBusinessDate;
            var _loop_1 = function(count) {
                //debugger;
                newIncrementDate.setDate(currentBusinessDate.getDate() + 1);
                //console.log("New Date increment -> ", newIncrementDate);
                var formattedNewDate = this_1.setFormattedDate(newIncrementDate.toString());
                var isHoliday = this_1.arrGlobalHolidayDates.find(function (holiday) { return holiday == formattedNewDate; }) ? true : false;
                if (isHoliday) {
                    this_1.intBusinessDatePositiveIncrement += 1;
                }
            };
            var this_1 = this;
            for (var count = 1; count <= 7; count++) {
                _loop_1(count);
            }
            //reset the date to set the maximum business date
            currentBusinessDate = new Date(this.date3);
            //set the maximum business date
            this.dtMaxBusinessDate = currentBusinessDate;
            this.dtMaxBusinessDate.setDate(currentBusinessDate.getDate() + this.intBusinessDatePositiveIncrement);
            //console.log("dtMaxBusinessDate ->", this.dtMaxBusinessDate);
            //reset the date for decrement
            currentBusinessDate = new Date(this.date3);
            var newDecrementDate = currentBusinessDate;
            //console.log("newDecrementDate ->", newDecrementDate);
            var _loop_2 = function(count) {
                //debugger;
                newDecrementDate.setDate(currentBusinessDate.getDate() - 1);
                //console.log("New Date decrement -> ", newDecrementDate);
                var formattedNewDate = this_2.setFormattedDate(newDecrementDate.toString());
                var isHoliday = this_2.arrGlobalHolidayDates.find(function (holiday) { return holiday == formattedNewDate; }) ? true : false;
                if (isHoliday) {
                    this_2.intBusinessDateNegativeIncrement += -1;
                }
            };
            var this_2 = this;
            for (var count = 1; count <= 7; count++) {
                _loop_2(count);
            }
            //reset the date to set the minimum business date
            currentBusinessDate = new Date(this.date3);
            this.dtMinBusinessDate = currentBusinessDate;
            this.dtMinBusinessDate.setDate(currentBusinessDate.getDate() + this.intBusinessDateNegativeIncrement);
        }
    };
    AppComponent.prototype.onSelectSystemBusinessDate = function () {
        this.blnChangeBusinessDate = true;
    };
    AppComponent.prototype.getPreviousorNextWorkingDay = function (initialDate, isPrevious) {
        var _this = this;
        console.log("getPreviousorNextWorkingDay - Initial Date ->" + initialDate);
        var days = isPrevious ? -1 : 1;
        initialDate.setHours(0, 0, 0, 0);
        initialDate.setDate(initialDate.getDate() + days);
        if (localStorage.getItem("WorkingDates") && localStorage.getItem("Holidays")) {
            if (JSON.parse(localStorage.getItem("WorkingDates"))) {
                this.validDates = JSON.parse(localStorage.getItem("WorkingDates"));
            }
            if (JSON.parse(localStorage.getItem("Holidays"))) {
                this.holidays = JSON.parse(localStorage.getItem("Holidays"));
            }
            console.log("Working Dates ->", this.validDates);
            while (this.validDates && this.holidays && this.validDates.length > 0 && this.holidays.length > 0) {
                if (this.validDates.some(function (d) { return ((new Date(d)).setHours(0, 0, 0, 0) == initialDate.setHours(0, 0, 0, 0)); })
                    && !this.holidays.some(function (d) { return (d.Region == null && _this.tPRcommonService.getFormattedSystemDate_Date(new Date(d.Date)) == _this.tPRcommonService.getFormattedSystemDate_Date(initialDate)); })) {
                    break;
                }
                initialDate.setDate(initialDate.getDate() + days);
            }
        }
        else {
            console.log("Unable to retrieve holiday and working dates date from local storage");
        }
        return initialDate;
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/app.component.html'
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper, primeng_1.ConfirmationService, router_1.Router, app_TPRHolidayService_1.TPRHolidayService, app_workDayService_1.WorkDayService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
var UserRolesValues = (function () {
    function UserRolesValues($values) {
        if ($values === void 0) { $values = null; }
        this.$values = $values;
    }
    return UserRolesValues;
}());
var UserRolesValue = (function () {
    function UserRolesValue(Name, Users) {
        if (Name === void 0) { Name = null; }
        if (Users === void 0) { Users = null; }
        this.Name = Name;
        this.Users = Users;
    }
    return UserRolesValue;
}());
var UsersValue = (function () {
    function UsersValue(LoginName, Role) {
        if (LoginName === void 0) { LoginName = null; }
        if (Role === void 0) { Role = null; }
        this.LoginName = LoginName;
        this.Role = Role;
    }
    return UsersValue;
}());
//# sourceMappingURL=app.component.js.map