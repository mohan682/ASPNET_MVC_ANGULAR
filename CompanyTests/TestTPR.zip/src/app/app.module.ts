//importing angular modules
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { RouterModule } from '@angular/router'
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import { RouteReuseStrategy } from '@angular/router';

// importing the services
import NodetypeService = require("./service/app.TPRNodeTypeService");
import regionService = require("./service/app.regionService");
import TreeviewService = require("./service/app.TPRHierarchyservice");
import TagService = require("./service/app.TPRTagsService");
import DividendPartnersService = require("./service/app.TPRDividendPartnersService");
import BusinessSegmentsService = require("./service/app.TPRBusinessSegmentsService");
import HolidayService = require("./service/app.TPRHolidayService");
import CommonService = require("./service/app.TPRCommonService");
import CalculateService = require("./service/app.calculate.service");
import { DashboardDataService } from './service/app.dashboardData.service';
import ProfitAlertGroupService = require("./service/app.TPRProfitAlertGroupsService");
import ServiceHelper = require("./service/app.serviceHelper");
import TPRViewService = require("./service/app.reportsView.service");
import TPRDataSourcesService = require("./service/app.dataSources.service");
import TPRJobService = require("./service/app.jobs.service");
import TPRFileUploadService = require("./service/app.fileUpload.service");
import TPRServersService = require("./service/app.server.service");
import WorkDayService = require("./service/app.workDayService");

import { CustomReuseStrategy } from './service/app.customRoute'; 

// Guards
import { CanDeactivateGuard } from './service/app.can-deactivate-guard.service';
import { CanActivateGuard } from './service/app.can-activate-guard.service';

// importing modules from primeng
import {
    DataTableModule,
    AccordionModule,
    CalendarModule,
    CarouselModule,
    GrowlModule,
    ButtonModule,
    DataGridModule,
    PanelMenuModule,
    DialogModule,
    MenuModule,
    TreeModule,
    ContextMenuModule,
    SharedModule,
    DropdownModule,
    CheckboxModule,
    ConfirmDialogModule,
    ConfirmationService,
    AutoCompleteModule,
    RadioButtonModule,
    FieldsetModule,
    FileUploadModule,
    TooltipModule,
    DragDropModule,
    PanelModule,
    InputTextModule,
    LightboxModule,
    InplaceModule
} from 'primeng/primeng';


// importing the components
import { AppComponent } from "../app/app.component";
import TPRNodeTypeComponent = require("./components/nodeTypes/app.nodetypes.component");
import TPRDashboardComponent = require("./components/dashboard/app.dashboard.component");
import TPRRegionComponent = require("./components/regions/app.regions.component");
import TPRHolidayComponent = require("./components/holiday/app.holiday.component");
import TPRBusinessSegmentsComponent = require("./components/BusinessSegments/app.businessSegments.component");
import TPRHierarchyComponent = require("./components/treeView/app.treeView.component");
import AppTprHierarchyEditNodeComponent = require("./components/treeView/app.treeViewEditNode.component");
import AppTprHierarchyAddChildComponent = require("./components/treeView/app.treeViewAddChild.component");
import AppTprHierarchyEnterValueComponent = require("./components/treeView/app.treeViewEnterValue.component")
import TPRTagsComponent = require("./components/Tags/app.tags.component");
import TPRDividendPartnersComponent = require("./components/DividendPartners/app.dividendPartners.component");
import TPRAppReportsViewComponent = require("./components/reportsView/app.reportsView.component");
import TPRAppDataSourcesComponent = require("./components/dataSources/app.dataSources.component");
import TPRAppJobsComponent = require("./components/feeds/app.jobs.component");
import TPRAppFileUploadComponent = require("./components/feeds/app.fileUpload.component");
import TPRAppPageNotFoundComponent = require("./app.PageNotFound.component");
import DialogComponent = require("./components/common/app.dialogComponent");
import SpinnerComponent = require("./components/common/app.spinnerComponent");
import TPRAppProfitAlertGroupComponent = require("./components/ProfitAlertGroup/app.profitAlertGroup.component");
import AppErrorComponent = require("./components/error/app.error.component");

//import TPRFlatViewComponent = require("./components/flatView/app.flatView.component");

//importing various other application javascript modules
import TPRAccordion = require("./components/datagrid/app.TPR.AccordionModule");
import { routes } from '../app/app-routing.module';

@NgModule({
    imports: [
        CalendarModule,
        BrowserModule,
        FormsModule,
        HttpModule,
        JsonpModule,
        CarouselModule,
        GrowlModule,
        ButtonModule,
        MenuModule,
        ContextMenuModule,
        AccordionModule,
        SharedModule,
        routes,
        PanelMenuModule,
        DataTableModule,
        TreeModule,
        DropdownModule,
        DialogModule,
        ConfirmDialogModule,
        CheckboxModule,
        AutoCompleteModule,
        RadioButtonModule,
        FieldsetModule,
        FileUploadModule,
        TooltipModule,
        DragDropModule,
        PanelModule,
        InputTextModule,
        LightboxModule,
        InplaceModule
    ],
    declarations: [
        AppComponent,
        TPRHierarchyComponent.AppTprHierarchyComponent,
        TPRNodeTypeComponent.AppNodeTypeComponent,
        TPRDashboardComponent.AppDashboard,
        TPRRegionComponent.AppRegionComponent,
        TPRHolidayComponent.AppHolidayComponent,
        TPRBusinessSegmentsComponent.AppBusinessSegmentsComponent,
        TPRTagsComponent.AppTagsTypeComponent,
        TPRDividendPartnersComponent.AppDividendPartnersComponent,
        TPRAppReportsViewComponent.AppReportsViewComponent,
        TPRAppDataSourcesComponent.AppDataSourcesComponent,
        TPRAppPageNotFoundComponent.AppPageNotFoundComponent,
        AppTprHierarchyEditNodeComponent.AppTprHierarchyEditNodeComponent,
        AppTprHierarchyEnterValueComponent.AppTprHierarchyEnterValueComponent,
        TPRAppJobsComponent.AppJobsComponent,
        DialogComponent.DialogComponent,
        SpinnerComponent.SpinnerComponent,
        TPRAppFileUploadComponent.AppFileUploadComponent,        
        AppErrorComponent.AppErrorComponent,
        TPRAppProfitAlertGroupComponent.AppProfitAlertGroupComponent,
        AppTprHierarchyAddChildComponent.AppTprHierarchyAddChildComponent
    ],
    providers: [
        TreeviewService.TPRHierarchyservice,
        NodetypeService.TPRNodeTypeService,
        DashboardDataService,
        regionService.RegionsService,
        TagService.TPRTagsService,
        DividendPartnersService.TPRDividendPartnersService,
        BusinessSegmentsService.TPRBusinessSegmentsService,
        HolidayService.TPRHolidayService,
        ServiceHelper.ServiceHelper,
        ProfitAlertGroupService.TPRProfitAlertGroupsService,
        CommonService.TPRCommonService,
        ConfirmationService,
        CanDeactivateGuard,
        CanActivateGuard,
        {provide: RouteReuseStrategy, useClass: CustomReuseStrategy},
        TPRViewService.ViewsService,
        TPRDataSourcesService.DataSourcesService,
        TPRJobService.JobService,
        TPRFileUploadService.FileUploadService,
        TPRServersService.ServerService,
        WorkDayService.WorkDayService
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }

