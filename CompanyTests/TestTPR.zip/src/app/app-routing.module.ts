﻿import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import { AppTprHierarchyComponent } from './components/treeView/app.treeView.component';
import { AppTprHierarchyEditNodeComponent } from './components/treeView/app.treeViewEditNode.component';
import { AppTprHierarchyAddChildComponent } from './components/treeView/app.treeViewAddChild.component';
import { AppTprHierarchyEnterValueComponent } from './components/treeView/app.treeViewEnterValue.component';
import { AppNodeTypeComponent } from './components/nodeTypes/app.nodetypes.component';
import { AppDashboard } from './components/dashboard/app.dashboard.component';
import { AppRegionComponent } from './components/regions/app.regions.component';
import { AppHolidayComponent } from './components/holiday/app.holiday.component';
import { AppBusinessSegmentsComponent } from './components/BusinessSegments/app.businessSegments.component';
import { AppTagsTypeComponent } from './components/Tags/app.tags.component';
import { AppDividendPartnersComponent } from './components/DividendPartners/app.dividendPartners.component';
import { AppReportsViewComponent } from './components/reportsView/app.reportsView.component';
import { AppDataSourcesComponent } from './components/dataSources/app.dataSources.component';
import { AppPageNotFoundComponent } from './app.PageNotFound.component';
import { AppJobsComponent } from './components/feeds/app.jobs.component';
import { AppFileUploadComponent } from "./components/feeds/app.fileUpload.component";
import { CanDeactivateGuard } from './service/app.can-deactivate-guard.service';
import { CanActivateGuard } from './service/app.can-activate-guard.service';
import { AppProfitAlertGroupComponent } from "./components/ProfitAlertGroup/app.profitAlertGroup.component";
import { AppErrorComponent } from "./components/error/app.error.component";

//import { AppFlatViewComponent } from './components/flatView/app.flatView.component';

// route configuration order matters as the design is such that the first-match wins strtegy is used to match the routes.
export const router: Routes = [
    { path: 'error', component: AppErrorComponent },
    {
        path: 'hierarchy',
        component: AppTprHierarchyComponent,
        canActivate: [CanActivateGuard],
        children:
        [
            {
                path: 'editNode/:nodeId', component: AppTprHierarchyEditNodeComponent
            },
            {
                path: 'enterValue/:nodeId', component: AppTprHierarchyEnterValueComponent
            },
            {
                path: 'addChild/:nodeId', component: AppTprHierarchyAddChildComponent
            }
        ]
    },
    { path: 'nodeTypes', component: AppNodeTypeComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'dashboard', component: AppDashboard, canActivate: [CanActivateGuard] },
    { path: 'region', component: AppRegionComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'holidays', component: AppHolidayComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'businessSegments', component: AppBusinessSegmentsComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'tags', component: AppTagsTypeComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'dividendPartners', component: AppDividendPartnersComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'reportsView', component: AppReportsViewComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'dataSources', component: AppDataSourcesComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'jobs', component: AppJobsComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'fileUpload', component: AppFileUploadComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: 'profitAlert', component: AppProfitAlertGroupComponent, canDeactivate: [CanDeactivateGuard], canActivate: [CanActivateGuard] },
    { path: '', redirectTo: '/dashboard', pathMatch: 'full', canActivate: [CanActivateGuard] },

    { path: '**', component: AppPageNotFoundComponent }
    //{ path: 'flatView', component: AppFlatViewComponent }
];

export const routes: ModuleWithProviders = RouterModule.forRoot(router, { useHash: true });