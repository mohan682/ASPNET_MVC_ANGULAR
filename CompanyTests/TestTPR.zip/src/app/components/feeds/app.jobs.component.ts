import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { TooltipModule } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { JobService } from '../../service/app.jobs.service';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { ServiceHelper } from '../../service/app.serviceHelper';

import { SpinnerComponent } from '../common/app.spinnerComponent'

import IJobValue = JobsNamespace.IJobValue;

enum JobStatusEnum {
    None = 0,
    Running = 1,
    Complete = 2,
    Error = 3,
    NoDataLoaded = 4,
    UnknownJob = 5,
    AlreadyRunning = 6,
    AlreadyComplete = 7,
    ScheduledTimeNotReached = 8
}

@Component({
    selector: 'my-app',
    templateUrl: 'app/components/feeds/app.jobs.component.html'
})

export class AppJobsComponent implements OnInit, CanComponentDeactivate {
    jobs: IJobValue[];
    jobType: IJobValue;
    JobStatusEnum: typeof JobStatusEnum = JobStatusEnum;
    blnShowPopUp: boolean = false;
    clsMessage = {};
    Message: string = "";
    isRequesting: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    userRoles: string[] = [];
    constants: any;
    canExecute: boolean = false;

    constructor(
        private jobService: JobService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {        
        this.loadData();
    }

    private loadData() {
        this.isRequesting = true;

        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }

        this.jobService.getJobsObservable()
            .subscribe(data => this.setJobsData(data));

        this.serviceHelper.importSettings()
            .subscribe(data => this.getConstants(data));
    }

    public getConstants(data: any): void {
        this.constants = data;
        this.authorizeUser();
    }

    private authorizeUser(){
        this.canExecute = !this.isUserAuthorised();
    }

    private setJobsData(data: any): void {
        this.jobs = data.Result.Jobs.$values;
        console.log("Number of Jobs ->", this.jobs.length);

        for (let job in this.jobs) {
            //console.log("Status ->", this.jobs[job].Status);
            this.jobs[job].LastExecuted = this.jobs[job].LastExecuted != null ? this.tprCommonService.getFormattedSystemDate(new Date(this.jobs[job].LastExecuted)) : null;
            this.jobs[job].Status = JobStatusEnum[this.jobs[job].Status];
        }

        console.log("Jobs ->", this.jobs);
        this.stopRefreshing();
    }

    public isUserAuthorised(): boolean {
        return this.userRoles != undefined && this.constants != undefined &&
            (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                this.userRoles.some(x => x == this.constants.TPRITSupport));
    }

    canDeactivate(): Observable<boolean> | boolean {
        return true;
    }

    refreshJobs(jobToBeRefreshed: IJobValue) {
        console.log(jobToBeRefreshed);

        //console.log(JobStatusEnum[jobToBeRefreshed.Status]);

        let objJobValue: IJobValue = new JobValue();

        objJobValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Jobs.JobDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        objJobValue.Active = jobToBeRefreshed.Active;
        objJobValue.Hour = jobToBeRefreshed.Hour;
        objJobValue.JobOrder = jobToBeRefreshed.JobOrder;
        objJobValue.LastExecuted = jobToBeRefreshed.LastExecuted;
        objJobValue.Minute = jobToBeRefreshed.Minute;
        objJobValue.Name = jobToBeRefreshed.Name;
        objJobValue.ScheduleType = jobToBeRefreshed.ScheduleType;
        objJobValue.Status = JobStatusEnum[jobToBeRefreshed.Status];

        this.isRequesting = true;
        this.jobService.updateJobRefresh(jobToBeRefreshed)
            .subscribe((response: any) => {
                console.log(response);

                if (response.Error) {
                    this.stopRefreshing();
                    this.Status = "Error";
                    this.ValidationMessage = response.Error;
                    this.blnShowPopUp = true;
                }
                else {
                    let responseJob: IJobValue = response.Result.Job;

                    let selectedJob: IJobValue = responseJob ? this.jobs.find(item => item.Name == responseJob.Name) : null;

                    if (selectedJob) {
                        selectedJob.Status = JobStatusEnum[responseJob.Status];
                        selectedJob.LastExecuted = responseJob.LastExecuted != null ? this.tprCommonService.getFormattedSystemDate(new Date(responseJob.LastExecuted)) : null;

                        let index = this.jobs.indexOf(selectedJob);

                        this.jobs[index] = selectedJob;

                        this.Status = "Success";
                        this.ValidationMessage = "Job refreshed with status - " + selectedJob.Status;
                        this.blnShowPopUp = true;
                        this.stopRefreshing();
                    }
                }
            },
            (error) => {
                this.stopRefreshing();
                this.Status = "Error";
                this.ValidationMessage = error;
                this.blnShowPopUp = true;
            });
    }

    refreshAllJobs(){
        this.loadData();        
    }

    private stopRefreshing() {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }
}

class JobValue implements IJobValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public LastExecuted: string = null,
        public Active: boolean = false,
        public Status: string = null,
        public Hour: number = 0,
        public Minute: number = 0,
        public ScheduleType: string = null,
        public JobOrder: Date = null
    ) { }
}
