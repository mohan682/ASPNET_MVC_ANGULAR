"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_jobs_service_1 = require('../../service/app.jobs.service');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var JobStatusEnum;
(function (JobStatusEnum) {
    JobStatusEnum[JobStatusEnum["None"] = 0] = "None";
    JobStatusEnum[JobStatusEnum["Running"] = 1] = "Running";
    JobStatusEnum[JobStatusEnum["Complete"] = 2] = "Complete";
    JobStatusEnum[JobStatusEnum["Error"] = 3] = "Error";
    JobStatusEnum[JobStatusEnum["NoDataLoaded"] = 4] = "NoDataLoaded";
    JobStatusEnum[JobStatusEnum["UnknownJob"] = 5] = "UnknownJob";
    JobStatusEnum[JobStatusEnum["AlreadyRunning"] = 6] = "AlreadyRunning";
    JobStatusEnum[JobStatusEnum["AlreadyComplete"] = 7] = "AlreadyComplete";
    JobStatusEnum[JobStatusEnum["ScheduledTimeNotReached"] = 8] = "ScheduledTimeNotReached";
})(JobStatusEnum || (JobStatusEnum = {}));
var AppJobsComponent = (function () {
    function AppJobsComponent(jobService, confirmationService, tprCommonService, serviceHelper) {
        this.jobService = jobService;
        this.confirmationService = confirmationService;
        this.tprCommonService = tprCommonService;
        this.serviceHelper = serviceHelper;
        this.JobStatusEnum = JobStatusEnum;
        this.blnShowPopUp = false;
        this.clsMessage = {};
        this.Message = "";
        this.isRequesting = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.userRoles = [];
        this.canExecute = false;
    }
    AppJobsComponent.prototype.ngOnInit = function () {
        this.loadData();
    };
    AppJobsComponent.prototype.loadData = function () {
        var _this = this;
        this.isRequesting = true;
        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }
        this.jobService.getJobsObservable()
            .subscribe(function (data) { return _this.setJobsData(data); });
        this.serviceHelper.importSettings()
            .subscribe(function (data) { return _this.getConstants(data); });
    };
    AppJobsComponent.prototype.getConstants = function (data) {
        this.constants = data;
        this.authorizeUser();
    };
    AppJobsComponent.prototype.authorizeUser = function () {
        this.canExecute = !this.isUserAuthorised();
    };
    AppJobsComponent.prototype.setJobsData = function (data) {
        this.jobs = data.Result.Jobs.$values;
        console.log("Number of Jobs ->", this.jobs.length);
        for (var job in this.jobs) {
            //console.log("Status ->", this.jobs[job].Status);
            this.jobs[job].LastExecuted = this.jobs[job].LastExecuted != null ? this.tprCommonService.getFormattedSystemDate(new Date(this.jobs[job].LastExecuted)) : null;
            this.jobs[job].Status = JobStatusEnum[this.jobs[job].Status];
        }
        console.log("Jobs ->", this.jobs);
        this.stopRefreshing();
    };
    AppJobsComponent.prototype.isUserAuthorised = function () {
        var _this = this;
        return this.userRoles != undefined && this.constants != undefined &&
            (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                this.userRoles.some(function (x) { return x == _this.constants.TPRITSupport; }));
    };
    AppJobsComponent.prototype.canDeactivate = function () {
        return true;
    };
    AppJobsComponent.prototype.refreshJobs = function (jobToBeRefreshed) {
        var _this = this;
        console.log(jobToBeRefreshed);
        //console.log(JobStatusEnum[jobToBeRefreshed.Status]);
        var objJobValue = new JobValue();
        objJobValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Jobs.JobDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        objJobValue.Active = jobToBeRefreshed.Active;
        objJobValue.Hour = jobToBeRefreshed.Hour;
        objJobValue.JobOrder = jobToBeRefreshed.JobOrder;
        objJobValue.LastExecuted = jobToBeRefreshed.LastExecuted;
        objJobValue.Minute = jobToBeRefreshed.Minute;
        objJobValue.Name = jobToBeRefreshed.Name;
        objJobValue.ScheduleType = jobToBeRefreshed.ScheduleType;
        objJobValue.Status = JobStatusEnum[jobToBeRefreshed.Status];
        this.isRequesting = true;
        this.jobService.updateJobRefresh(jobToBeRefreshed)
            .subscribe(function (response) {
            console.log(response);
            if (response.Error) {
                _this.stopRefreshing();
                _this.Status = "Error";
                _this.ValidationMessage = response.Error;
                _this.blnShowPopUp = true;
            }
            else {
                var responseJob_1 = response.Result.Job;
                var selectedJob = responseJob_1 ? _this.jobs.find(function (item) { return item.Name == responseJob_1.Name; }) : null;
                if (selectedJob) {
                    selectedJob.Status = JobStatusEnum[responseJob_1.Status];
                    selectedJob.LastExecuted = responseJob_1.LastExecuted != null ? _this.tprCommonService.getFormattedSystemDate(new Date(responseJob_1.LastExecuted)) : null;
                    var index = _this.jobs.indexOf(selectedJob);
                    _this.jobs[index] = selectedJob;
                    _this.Status = "Success";
                    _this.ValidationMessage = "Job refreshed with status - " + selectedJob.Status;
                    _this.blnShowPopUp = true;
                    _this.stopRefreshing();
                }
            }
        }, function (error) {
            _this.stopRefreshing();
            _this.Status = "Error";
            _this.ValidationMessage = error;
            _this.blnShowPopUp = true;
        });
    };
    AppJobsComponent.prototype.refreshAllJobs = function () {
        this.loadData();
    };
    AppJobsComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppJobsComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/feeds/app.jobs.component.html'
        }), 
        __metadata('design:paramtypes', [app_jobs_service_1.JobService, primeng_1.ConfirmationService, app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper])
    ], AppJobsComponent);
    return AppJobsComponent;
}());
exports.AppJobsComponent = AppJobsComponent;
var JobValue = (function () {
    function JobValue($type, Name, LastExecuted, Active, Status, Hour, Minute, ScheduleType, JobOrder) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (LastExecuted === void 0) { LastExecuted = null; }
        if (Active === void 0) { Active = false; }
        if (Status === void 0) { Status = null; }
        if (Hour === void 0) { Hour = 0; }
        if (Minute === void 0) { Minute = 0; }
        if (ScheduleType === void 0) { ScheduleType = null; }
        if (JobOrder === void 0) { JobOrder = null; }
        this.$type = $type;
        this.Name = Name;
        this.LastExecuted = LastExecuted;
        this.Active = Active;
        this.Status = Status;
        this.Hour = Hour;
        this.Minute = Minute;
        this.ScheduleType = ScheduleType;
        this.JobOrder = JobOrder;
    }
    return JobValue;
}());
//# sourceMappingURL=app.jobs.component.js.map