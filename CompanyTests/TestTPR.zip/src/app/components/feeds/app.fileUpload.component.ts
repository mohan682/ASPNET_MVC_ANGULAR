import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService, InplaceModule } from 'primeng/primeng';

import { FileUploadService } from '../../service/app.fileUpload.service';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';
import { SpinnerComponent } from '../common/app.spinnerComponent'

import IFileUploadValue = FileUploadNameSpace.IFileUploadValue;
import IErrorDetails = FileUploadNameSpace.IErrorDetails;
import ICompleteErrorDetails = FileUploadNameSpace.ICompleteErrorDetails;
import IFileUploadModel = FileUploadNameSpace.IFileUploadModel;
import IFileUploadModel_FileBytes = FileUploadNameSpace.IFileUploadModel_FileBytes;

enum FileUploadStatusEnum {
    None = 0,
    Loaded = 1,
    Reading = 2,
    Processing = 3,
    Complete = 4,
    Errors = 5
}

enum FileTypes {
    PNL = 0,
    MVAR = 1,
    WORKINGCAPITAL = 2,
    MVARLIMIT = 3,
    MVARTEMPORARYLIMIT = 4,
    TRUEUP = 5,
    PNLPPA = 6,
    DIVIDENDPPA = 7,
    REGIONALLOCATION = 8
}

@Component({
    selector: 'my-app',
    templateUrl: 'app/components/feeds/app.fileUpload.component.html'
})
export class AppFileUploadComponent implements OnInit, CanComponentDeactivate {

    isRequesting: boolean;
    filesUploaded: IFileUploadValue[];
    blnShowErrorModal: boolean = false;
    arrErrorDetails: IErrorDetails[] = [];
    arrCompleteErrorDetails: ICompleteErrorDetails[] = [];
    uploadedFiles: any[] = [];
    postURL: string = "";

    blnDisableUpload: boolean = true;
    selectedFileType: string = "";
    fileTypes: SelectItem[] = [];
    fileUploadArray: any;
    fileData: string;
    blnValidFileSelected: boolean = false;
    @ViewChild('myInputFile') myInputVariable: any;
    blnShowDialog: boolean = false;
    invalidFileTypeMessage: string = "";
    documentFileType: number;
    selectedFileUploadName: string;
    fileTypeToUser: [string, string];
    userRoles: string[] = [];
    constants: any;
    fileUploadText: string = "Select File";
    isFileSelected: boolean = false;
    constructor(
        private fileUploadService: FileUploadService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        this.isRequesting = true;

        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }

        this.loadData();

        this.fileTypes.push({ label: "PnL", value: "PnL" });
        this.fileTypes.push({ label: "MVar", value: "MVar" });
        this.fileTypes.push({ label: "WorkingCapital", value: "WorkingCapital" });
        this.fileTypes.push({ label: "MVarLimit", value: "MVarLimit" });
        this.fileTypes.push({ label: "MVarTemporaryLimit", value: "MVarTemporaryLimit" });
        this.fileTypes.push({ label: "PnlPPA", value: "PnlPPA" });
        this.fileTypes.push({ label: "DividendPPA", value: "DividendPPA" });
        this.fileTypes.push({ label: "RegionAllocation", value: "RegionAllocation" });

        this.selectedFileType = this.fileTypes[0].value;
    }

    loadData() {
        this.fileUploadText = "Select File";
        this.isFileSelected = false;

        this.fileUploadService.getFileUploadDetails()
            .subscribe(data => this.setFileUploadData(data));

        this.serviceHelper.importSettings()
            .subscribe(data => this.getConstants(data));
    }

    public getConstants(data: any): void {
        console.log("Constants ->", data);
        this.constants = data;
        this.authorizeUser();
    }

    public MapFileTypeToUserRole(): boolean {
        switch (this.selectedFileType.toUpperCase()) {
            case "PNL":
                return (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                    this.userRoles.some(x => x == this.constants.TPRMarginManagement));
            case "MVAR":
                return (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                    this.userRoles.some(x => x == this.constants.TPRRiskManagement));
            case "WORKINGCAPITAL":
                return (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                    this.userRoles.some(x => x == this.constants.TPRMarginManagement));
            default:
                return this.userRoles.some(x => x == this.constants.TPRSuperUser);
        }
    }

    public isUserAuthorised(): boolean {
        return this.userRoles != undefined && this.constants != undefined &&
            (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                this.userRoles.some(x => x == this.constants.TPRMarginManagement) ||
                this.userRoles.some(x => x == this.constants.TPRRiskManagement));
    }

    public authorizeUser() {
        this.blnDisableUpload = !(this.isUserAuthorised() && this.MapFileTypeToUserRole() && this.isFileSelected);
    }

    setFileUploadData(data: any): void {
        this.filesUploaded = data.Result.StagingSources.$values;
        //console.log("filesUploaded ->", this.filesUploaded);

        this.filesUploaded.forEach(file => {
            file.LoadedTime = file.LoadedTime != null ? this.tprCommonService.getFormattedSystemDate(new Date(file.LoadedTime)) : null;
            file.Status = FileUploadStatusEnum[file.Status];
        });
        this.stopRefreshing();
    }

    private stopRefreshing() {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    canDeactivate(): Observable<boolean> | boolean {
        return true;
    }

    onStatusClick(fileUploadedDetail: IFileUploadValue) {
        //console.log(data);
        this.arrErrorDetails = [];
        this.arrCompleteErrorDetails = [];

        this.fileUploadService.getErrorDetails(fileUploadedDetail.Id)
            .subscribe(data => {
                this.getErrorDetails(data);
                this.blnShowErrorModal = fileUploadedDetail.Status == "Errors" ? true : false;
            });
    }

    getErrorDetails(data: any): void {
        this.arrCompleteErrorDetails = [];
        this.arrErrorDetails = [];
        //debugger;
        this.arrCompleteErrorDetails = data.Result.Errors.$values;
        this.arrCompleteErrorDetails.forEach(error => this.arrErrorDetails.push({ ErrorDescription: error.ErrorMessage }));
    }

    fileChange(event: any) {
        let eventObj: MSInputMethodContext = <MSInputMethodContext>event;
        let target: HTMLInputElement = <HTMLInputElement>eventObj.target;
        let files: FileList = target.files;

        if (files && files.length > 0) {
            let selectedFile: File = files[0];

            let selectedFileName = selectedFile.name;
            this.selectedFileUploadName = selectedFileName;
            // this.fileUploadText = selectedFileName;
            // this.isFileSelected = true;

            let extension = selectedFileName.split(".")[1];

            this.checkFileValidity(selectedFileName, extension);

            if (!this.blnValidFileSelected) {
                this.blnShowDialog = true;
                this.reset();
            }
            else {
                if (files.length > 0) {
                    let uploadedFile: File = files[0];

                    if (uploadedFile) {
                        this.fileUploadText = selectedFileName;
                        this.isFileSelected = true;
                        this.documentFileType = this.setUploadedFileType();
                        var reader = new FileReader();
                        reader.onload = this._handleReaderLoadedArray.bind(this);
                        reader.readAsArrayBuffer(uploadedFile);
                    }
                }
                // this.blnDisableUpload = false;
                this.authorizeUser();
            }
        }
        target.value = '';
    }
    // private _handleReaderLoaded(readerEvt: any) {
    //     debugger;
    //     var binaryString = readerEvt.target.result;
    //     this.fileData = btoa(binaryString);  // Converting binary string data. 

    //     var arrayBuffer = readerEvt.target.result;

    //     var base64ConvertedString = btoa(
    //         new Uint8Array(arrayBuffer)
    //             .reduce((data, byte) => data + String.fromCharCode(byte), '')
    //     );

    //     console.log(base64ConvertedString);
    // }

    private resetFileSelect(event: any) {
        console.log("Reset...");
        this.fileUploadText = "Select File";
        this.isFileSelected = false;
        this.blnDisableUpload = true;
        this.reset();
        this.selectedFileUploadName = null;
    }

    private _handleReaderLoadedArray(readerEvt: any) {
        var arrayBuffer = readerEvt.target.result;

        var base64ConvertedString = btoa(
            new Uint8Array(arrayBuffer)
                .reduce((data, byte) => data + String.fromCharCode(byte), '')
        );
        this.fileData = base64ConvertedString;
        //console.log(base64ConvertedString);
    }

    checkFileValidity(selectedFileName: string, extn: string) {
        extn = extn.toUpperCase();
        selectedFileName = selectedFileName.toUpperCase();
        //debugger;
        switch (this.selectedFileType.toUpperCase()) {
            case "PNL":
                selectedFileName.startsWith("PNL") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVAR":
                selectedFileName.startsWith("MVAR") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "WORKINGCAPITAL":
                selectedFileName.startsWith("WORKINGCAPITAL") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVARLIMIT":
                selectedFileName.startsWith("MVARLIMIT") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVARTEMPORARYLIMIT":
                selectedFileName.startsWith("MVARTEMPORARYLIMIT") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "PNLPPA":
                selectedFileName.startsWith("PNLPPA") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "DIVIDENDPPA":
                selectedFileName.startsWith("DIVIDENDPPA") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "REGIONALLOCATION":
                selectedFileName.startsWith("REGIONALLOCATION") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            default:
                this.blnValidFileSelected = false;
                break;
        }
    }

    reset() {
        //console.log(this.myInputVariable.nativeElement.files);
        this.myInputVariable.nativeElement.value = "";
        //console.log(this.myInputVariable.nativeElement.files);
    }

    submitFile(event: any) {
        //debugger;
        //console.log(event);
        this.blnDisableUpload = true;
        let clsFileUploadModelObj: IFileUploadModel = new clsFileUploadModel();
        clsFileUploadModelObj.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Loading.LoadFileRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        clsFileUploadModelObj.FileName = this.selectedFileUploadName;
        clsFileUploadModelObj.FileType = this.documentFileType;

        let clsFileUploadModel_FileBytesObj: IFileUploadModel_FileBytes = new clsFileUploadModel_FileBytes();
        clsFileUploadModel_FileBytesObj.$type = "System.Byte[], mscorlib";
        clsFileUploadModel_FileBytesObj.$value = this.fileData;

        clsFileUploadModelObj.FileBytes = clsFileUploadModel_FileBytesObj;

        //debugger;
        //console.log("obj in component ->", clsFileUploadModelObj);

        this.isRequesting = true;
        this.fileUploadService.uploadFile(clsFileUploadModelObj)
            .subscribe((response: any) => {
                //console.log(response);
                // this.blnDisableUpload = true;
                this.selectedFileUploadName = null;
                if (response.Error) {
                    alert(response.Error);
                    this.stopRefreshing();
                }
                else {
                    this.loadData();
                    this.reset();
                }
            },
            (error) => {
                // this.blnDisableUpload = true;
                this.selectedFileUploadName = null;
                console.log(error);
                alert(error);
                this.stopRefreshing();
            });
    }

    onFileTypeChange(strFileType: string) {
        //console.log(strFileType);
        debugger
        this.blnDisableUpload = true;
        if (this.selectedFileUploadName) {
            let selectedFileName: string = this.selectedFileUploadName;

            let extension = selectedFileName.split(".")[1];

            this.checkFileValidity(selectedFileName, extension);

            if (!this.blnValidFileSelected) {
                this.blnDisableUpload = true;
                this.blnShowDialog = true;
                this.reset();
            }
            else {
                this.selectedFileType = strFileType;
                this.authorizeUser();
            }
        }
        else {
            this.selectedFileType = strFileType;
        }

       // this.authorizeUser();
    }

    private setUploadedFileType(): number {
        this.documentFileType = FileTypes[this.selectedFileType.toUpperCase()];
        return this.documentFileType ? this.documentFileType : 0;
    }
}

export class clsFileUploadModel implements IFileUploadModel {
    constructor(
        public $type: string = null,
        public FileType: number = 0,
        public FileBytes: IFileUploadModel_FileBytes = null,
        public FileName: string = null
    ) { }
}

export class clsFileUploadModel_FileBytes implements IFileUploadModel_FileBytes {
    constructor(
        public $type: string = null,
        public $value: string = null
    ) { }
}