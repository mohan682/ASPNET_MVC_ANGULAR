"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_fileUpload_service_1 = require('../../service/app.fileUpload.service');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var FileUploadStatusEnum;
(function (FileUploadStatusEnum) {
    FileUploadStatusEnum[FileUploadStatusEnum["None"] = 0] = "None";
    FileUploadStatusEnum[FileUploadStatusEnum["Loaded"] = 1] = "Loaded";
    FileUploadStatusEnum[FileUploadStatusEnum["Reading"] = 2] = "Reading";
    FileUploadStatusEnum[FileUploadStatusEnum["Processing"] = 3] = "Processing";
    FileUploadStatusEnum[FileUploadStatusEnum["Complete"] = 4] = "Complete";
    FileUploadStatusEnum[FileUploadStatusEnum["Errors"] = 5] = "Errors";
})(FileUploadStatusEnum || (FileUploadStatusEnum = {}));
var FileTypes;
(function (FileTypes) {
    FileTypes[FileTypes["PNL"] = 0] = "PNL";
    FileTypes[FileTypes["MVAR"] = 1] = "MVAR";
    FileTypes[FileTypes["WORKINGCAPITAL"] = 2] = "WORKINGCAPITAL";
    FileTypes[FileTypes["MVARLIMIT"] = 3] = "MVARLIMIT";
    FileTypes[FileTypes["MVARTEMPORARYLIMIT"] = 4] = "MVARTEMPORARYLIMIT";
    FileTypes[FileTypes["TRUEUP"] = 5] = "TRUEUP";
    FileTypes[FileTypes["PNLPPA"] = 6] = "PNLPPA";
    FileTypes[FileTypes["DIVIDENDPPA"] = 7] = "DIVIDENDPPA";
    FileTypes[FileTypes["REGIONALLOCATION"] = 8] = "REGIONALLOCATION";
})(FileTypes || (FileTypes = {}));
var AppFileUploadComponent = (function () {
    function AppFileUploadComponent(fileUploadService, confirmationService, tprCommonService, serviceHelper) {
        this.fileUploadService = fileUploadService;
        this.confirmationService = confirmationService;
        this.tprCommonService = tprCommonService;
        this.serviceHelper = serviceHelper;
        this.blnShowErrorModal = false;
        this.arrErrorDetails = [];
        this.arrCompleteErrorDetails = [];
        this.uploadedFiles = [];
        this.postURL = "";
        this.blnDisableUpload = true;
        this.selectedFileType = "";
        this.fileTypes = [];
        this.blnValidFileSelected = false;
        this.blnShowDialog = false;
        this.invalidFileTypeMessage = "";
        this.userRoles = [];
        this.fileUploadText = "Select File";
        this.isFileSelected = false;
    }
    AppFileUploadComponent.prototype.ngOnInit = function () {
        this.isRequesting = true;
        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }
        this.loadData();
        this.fileTypes.push({ label: "PnL", value: "PnL" });
        this.fileTypes.push({ label: "MVar", value: "MVar" });
        this.fileTypes.push({ label: "WorkingCapital", value: "WorkingCapital" });
        this.fileTypes.push({ label: "MVarLimit", value: "MVarLimit" });
        this.fileTypes.push({ label: "MVarTemporaryLimit", value: "MVarTemporaryLimit" });
        this.fileTypes.push({ label: "PnlPPA", value: "PnlPPA" });
        this.fileTypes.push({ label: "DividendPPA", value: "DividendPPA" });
        this.fileTypes.push({ label: "RegionAllocation", value: "RegionAllocation" });
        this.selectedFileType = this.fileTypes[0].value;
    };
    AppFileUploadComponent.prototype.loadData = function () {
        var _this = this;
        this.fileUploadText = "Select File";
        this.isFileSelected = false;
        this.fileUploadService.getFileUploadDetails()
            .subscribe(function (data) { return _this.setFileUploadData(data); });
        this.serviceHelper.importSettings()
            .subscribe(function (data) { return _this.getConstants(data); });
    };
    AppFileUploadComponent.prototype.getConstants = function (data) {
        console.log("Constants ->", data);
        this.constants = data;
        this.authorizeUser();
    };
    AppFileUploadComponent.prototype.MapFileTypeToUserRole = function () {
        var _this = this;
        switch (this.selectedFileType.toUpperCase()) {
            case "PNL":
                return (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                    this.userRoles.some(function (x) { return x == _this.constants.TPRMarginManagement; }));
            case "MVAR":
                return (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                    this.userRoles.some(function (x) { return x == _this.constants.TPRRiskManagement; }));
            case "WORKINGCAPITAL":
                return (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                    this.userRoles.some(function (x) { return x == _this.constants.TPRMarginManagement; }));
            default:
                return this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; });
        }
    };
    AppFileUploadComponent.prototype.isUserAuthorised = function () {
        var _this = this;
        return this.userRoles != undefined && this.constants != undefined &&
            (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                this.userRoles.some(function (x) { return x == _this.constants.TPRMarginManagement; }) ||
                this.userRoles.some(function (x) { return x == _this.constants.TPRRiskManagement; }));
    };
    AppFileUploadComponent.prototype.authorizeUser = function () {
        this.blnDisableUpload = !(this.isUserAuthorised() && this.MapFileTypeToUserRole() && this.isFileSelected);
    };
    AppFileUploadComponent.prototype.setFileUploadData = function (data) {
        var _this = this;
        this.filesUploaded = data.Result.StagingSources.$values;
        //console.log("filesUploaded ->", this.filesUploaded);
        this.filesUploaded.forEach(function (file) {
            file.LoadedTime = file.LoadedTime != null ? _this.tprCommonService.getFormattedSystemDate(new Date(file.LoadedTime)) : null;
            file.Status = FileUploadStatusEnum[file.Status];
        });
        this.stopRefreshing();
    };
    AppFileUploadComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppFileUploadComponent.prototype.canDeactivate = function () {
        return true;
    };
    AppFileUploadComponent.prototype.onStatusClick = function (fileUploadedDetail) {
        var _this = this;
        //console.log(data);
        this.arrErrorDetails = [];
        this.arrCompleteErrorDetails = [];
        this.fileUploadService.getErrorDetails(fileUploadedDetail.Id)
            .subscribe(function (data) {
            _this.getErrorDetails(data);
            _this.blnShowErrorModal = fileUploadedDetail.Status == "Errors" ? true : false;
        });
    };
    AppFileUploadComponent.prototype.getErrorDetails = function (data) {
        var _this = this;
        this.arrCompleteErrorDetails = [];
        this.arrErrorDetails = [];
        //debugger;
        this.arrCompleteErrorDetails = data.Result.Errors.$values;
        this.arrCompleteErrorDetails.forEach(function (error) { return _this.arrErrorDetails.push({ ErrorDescription: error.ErrorMessage }); });
    };
    AppFileUploadComponent.prototype.fileChange = function (event) {
        var eventObj = event;
        var target = eventObj.target;
        var files = target.files;
        if (files && files.length > 0) {
            var selectedFile = files[0];
            var selectedFileName = selectedFile.name;
            this.selectedFileUploadName = selectedFileName;
            // this.fileUploadText = selectedFileName;
            // this.isFileSelected = true;
            var extension = selectedFileName.split(".")[1];
            this.checkFileValidity(selectedFileName, extension);
            if (!this.blnValidFileSelected) {
                this.blnShowDialog = true;
                this.reset();
            }
            else {
                if (files.length > 0) {
                    var uploadedFile = files[0];
                    if (uploadedFile) {
                        this.fileUploadText = selectedFileName;
                        this.isFileSelected = true;
                        this.documentFileType = this.setUploadedFileType();
                        var reader = new FileReader();
                        reader.onload = this._handleReaderLoadedArray.bind(this);
                        reader.readAsArrayBuffer(uploadedFile);
                    }
                }
                // this.blnDisableUpload = false;
                this.authorizeUser();
            }
        }
        target.value = '';
    };
    // private _handleReaderLoaded(readerEvt: any) {
    //     debugger;
    //     var binaryString = readerEvt.target.result;
    //     this.fileData = btoa(binaryString);  // Converting binary string data. 
    //     var arrayBuffer = readerEvt.target.result;
    //     var base64ConvertedString = btoa(
    //         new Uint8Array(arrayBuffer)
    //             .reduce((data, byte) => data + String.fromCharCode(byte), '')
    //     );
    //     console.log(base64ConvertedString);
    // }
    AppFileUploadComponent.prototype.resetFileSelect = function (event) {
        console.log("Reset...");
        this.fileUploadText = "Select File";
        this.isFileSelected = false;
        this.blnDisableUpload = true;
        this.reset();
        this.selectedFileUploadName = null;
    };
    AppFileUploadComponent.prototype._handleReaderLoadedArray = function (readerEvt) {
        var arrayBuffer = readerEvt.target.result;
        var base64ConvertedString = btoa(new Uint8Array(arrayBuffer)
            .reduce(function (data, byte) { return data + String.fromCharCode(byte); }, ''));
        this.fileData = base64ConvertedString;
        //console.log(base64ConvertedString);
    };
    AppFileUploadComponent.prototype.checkFileValidity = function (selectedFileName, extn) {
        extn = extn.toUpperCase();
        selectedFileName = selectedFileName.toUpperCase();
        //debugger;
        switch (this.selectedFileType.toUpperCase()) {
            case "PNL":
                selectedFileName.startsWith("PNL") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVAR":
                selectedFileName.startsWith("MVAR") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "WORKINGCAPITAL":
                selectedFileName.startsWith("WORKINGCAPITAL") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVARLIMIT":
                selectedFileName.startsWith("MVARLIMIT") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVARTEMPORARYLIMIT":
                selectedFileName.startsWith("MVARTEMPORARYLIMIT") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "PNLPPA":
                selectedFileName.startsWith("PNLPPA") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "DIVIDENDPPA":
                selectedFileName.startsWith("DIVIDENDPPA") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "REGIONALLOCATION":
                selectedFileName.startsWith("REGIONALLOCATION") && selectedFileName.endsWith(".CSV") && extn == "CSV" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            default:
                this.blnValidFileSelected = false;
                break;
        }
    };
    AppFileUploadComponent.prototype.reset = function () {
        //console.log(this.myInputVariable.nativeElement.files);
        this.myInputVariable.nativeElement.value = "";
        //console.log(this.myInputVariable.nativeElement.files);
    };
    AppFileUploadComponent.prototype.submitFile = function (event) {
        var _this = this;
        //debugger;
        //console.log(event);
        this.blnDisableUpload = true;
        var clsFileUploadModelObj = new clsFileUploadModel();
        clsFileUploadModelObj.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Loading.LoadFileRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        clsFileUploadModelObj.FileName = this.selectedFileUploadName;
        clsFileUploadModelObj.FileType = this.documentFileType;
        var clsFileUploadModel_FileBytesObj = new clsFileUploadModel_FileBytes();
        clsFileUploadModel_FileBytesObj.$type = "System.Byte[], mscorlib";
        clsFileUploadModel_FileBytesObj.$value = this.fileData;
        clsFileUploadModelObj.FileBytes = clsFileUploadModel_FileBytesObj;
        //debugger;
        //console.log("obj in component ->", clsFileUploadModelObj);
        this.isRequesting = true;
        this.fileUploadService.uploadFile(clsFileUploadModelObj)
            .subscribe(function (response) {
            //console.log(response);
            // this.blnDisableUpload = true;
            _this.selectedFileUploadName = null;
            if (response.Error) {
                alert(response.Error);
                _this.stopRefreshing();
            }
            else {
                _this.loadData();
                _this.reset();
            }
        }, function (error) {
            // this.blnDisableUpload = true;
            _this.selectedFileUploadName = null;
            console.log(error);
            alert(error);
            _this.stopRefreshing();
        });
    };
    AppFileUploadComponent.prototype.onFileTypeChange = function (strFileType) {
        //console.log(strFileType);
        debugger;
        this.blnDisableUpload = true;
        if (this.selectedFileUploadName) {
            var selectedFileName = this.selectedFileUploadName;
            var extension = selectedFileName.split(".")[1];
            this.checkFileValidity(selectedFileName, extension);
            if (!this.blnValidFileSelected) {
                this.blnDisableUpload = true;
                this.blnShowDialog = true;
                this.reset();
            }
            else {
                this.selectedFileType = strFileType;
                this.authorizeUser();
            }
        }
        else {
            this.selectedFileType = strFileType;
        }
        // this.authorizeUser();
    };
    AppFileUploadComponent.prototype.setUploadedFileType = function () {
        this.documentFileType = FileTypes[this.selectedFileType.toUpperCase()];
        return this.documentFileType ? this.documentFileType : 0;
    };
    __decorate([
        core_1.ViewChild('myInputFile'), 
        __metadata('design:type', Object)
    ], AppFileUploadComponent.prototype, "myInputVariable", void 0);
    AppFileUploadComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/feeds/app.fileUpload.component.html'
        }), 
        __metadata('design:paramtypes', [app_fileUpload_service_1.FileUploadService, primeng_1.ConfirmationService, app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper])
    ], AppFileUploadComponent);
    return AppFileUploadComponent;
}());
exports.AppFileUploadComponent = AppFileUploadComponent;
var clsFileUploadModel = (function () {
    function clsFileUploadModel($type, FileType, FileBytes, FileName) {
        if ($type === void 0) { $type = null; }
        if (FileType === void 0) { FileType = 0; }
        if (FileBytes === void 0) { FileBytes = null; }
        if (FileName === void 0) { FileName = null; }
        this.$type = $type;
        this.FileType = FileType;
        this.FileBytes = FileBytes;
        this.FileName = FileName;
    }
    return clsFileUploadModel;
}());
exports.clsFileUploadModel = clsFileUploadModel;
var clsFileUploadModel_FileBytes = (function () {
    function clsFileUploadModel_FileBytes($type, $value) {
        if ($type === void 0) { $type = null; }
        if ($value === void 0) { $value = null; }
        this.$type = $type;
        this.$value = $value;
    }
    return clsFileUploadModel_FileBytes;
}());
exports.clsFileUploadModel_FileBytes = clsFileUploadModel_FileBytes;
//# sourceMappingURL=app.fileUpload.component.js.map