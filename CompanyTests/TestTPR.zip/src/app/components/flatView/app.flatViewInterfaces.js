// PivotTable Typescript definition file
"use strict";
//# sourceMappingURL=app.flatViewInterfaces.js.map