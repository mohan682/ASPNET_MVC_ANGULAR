"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var primeng_2 = require('primeng/primeng');
var app_TPRProfitAlertGroupsService_1 = require('../../service/app.TPRProfitAlertGroupsService');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var AppProfitAlertGroupComponent = (function () {
    function AppProfitAlertGroupComponent(pagService, confirmationService, tprCommonService, serviceHelper) {
        this.pagService = pagService;
        this.confirmationService = confirmationService;
        this.tprCommonService = tprCommonService;
        this.serviceHelper = serviceHelper;
        this.blnShowDialog = false;
        this.strDialogHeaderMessage = "";
        this.strDialogMessage = "";
        this.profitAlertGroups = [];
        this.selectedProfitAlertGroup = new clsProfitAlertGroupsValues();
        this.selectedProfitAlertGroupName = "";
        this.selectedProfitAlertGroupUpdateTiming = "";
        this.lstProfitAlertGroupUpdateTimings = [];
        this.selectedProfitAlertGroupUpdatedBy = "";
        this.selectedProfitAlertGroupUpdatedOn = "";
        this.selectedProfitAlertGroupAlert_Gain = new clsProfitAlertGroups_Values_Alerts_Values();
        this.selectedProfitAlertGroupAlert_Drawdown = new clsProfitAlertGroups_Values_Alerts_Values();
        this.newAlert_Gain = [];
        this.newAlert_Drawdown = [];
        this.triggeredAlert_Gain = [];
        this.triggeredAlert_Drawdown = [];
        this.blnDtTriggeredDateDisabled_Gain = false;
        this.blnDtTriggeredDateDisabled_Drawdown = false;
        this.NewActionAlerts_Gain = [];
        this.NewActionAlerts_Drawdown = [];
        this.blnIsNewGroupAdded = false;
        this.blnShowPopUp = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.disableSave = false;
        this.canEdit = false;
    }
    AppProfitAlertGroupComponent.prototype.ngOnInit = function () {
        this.getProfitAlertGroupDate();
        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);
    };
    AppProfitAlertGroupComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppProfitAlertGroupComponent.prototype.getProfitAlertGroupDate = function () {
        var _this = this;
        this.isRequesting = true;
        this.businessDate = localStorage.getItem("BusinessDate") ? new Date(localStorage.getItem("BusinessDate")) : null;
        this.pagService.getProfitAlertGroupsObservable()
            .subscribe(function (data) { return _this.setProfitAlertGroupData(data); });
    };
    AppProfitAlertGroupComponent.prototype.setProfitAlertGroupData = function (data) {
        this.profitAlertGroups = data.Result.AlertGroups.$values;
        var newDate = new Date(this.businessDate);
        this.minDate = new Date();
        this.minDate = newDate;
        this.lstProfitAlertGroupUpdateTimings = [];
        this.lstProfitAlertGroupUpdateTimings.push({ value: "-1", label: "R-1" });
        this.lstProfitAlertGroupUpdateTimings.push({ value: "-2", label: "R-2" });
        this.setDefaultSelectedProfitAlertGroup();
        this.stopRefreshing();
    };
    AppProfitAlertGroupComponent.prototype.setDefaultSelectedProfitAlertGroup = function () {
        this.profitAlertGroups && this.profitAlertGroups.length > 0 ? this.selectedProfitAlertGroup = this.profitAlertGroups[0] : null;
        this.setDefaultDataForProfitAlertGroup();
    };
    AppProfitAlertGroupComponent.prototype.setDefaultDataForProfitAlertGroup = function () {
        if (this.selectedProfitAlertGroup) {
            this.selectedProfitAlertGroupName = this.selectedProfitAlertGroup.Name;
            this.selectedProfitAlertGroup.UpdateTiming ? this.selectedProfitAlertGroupUpdateTiming = this.selectedProfitAlertGroup.UpdateTiming.toString()
                : this.selectedProfitAlertGroupUpdateTiming = "-1";
            this.selectedProfitAlertGroupUpdatedBy = this.selectedProfitAlertGroup.UpdatedBy;
            this.selectedProfitAlertGroup.Updated != null ? this.selectedProfitAlertGroup.Updated = this.tprCommonService.getFormattedSystemDate(new Date(this.selectedProfitAlertGroup.Updated)) : "";
            this.selectedProfitAlertGroupUpdatedOn = this.selectedProfitAlertGroup.Updated;
            this.selectedProfitAlertGroupAlert_Gain = this.selectedProfitAlertGroup.Alerts.$values.find(function (alert) { return alert.AlertGroupType == 1; });
            if (!this.selectedProfitAlertGroupAlert_Gain) {
                this.selectedProfitAlertGroupAlert_Gain = new clsProfitAlertGroups_Values_Alerts_Values();
            }
            this.selectedProfitAlertGroupAlert_Drawdown = this.selectedProfitAlertGroup.Alerts.$values.find(function (alert) { return alert.AlertGroupType == 0; });
            if (!this.selectedProfitAlertGroupAlert_Drawdown) {
                this.selectedProfitAlertGroupAlert_Drawdown = new clsProfitAlertGroups_Values_Alerts_Values();
            }
            this.selectedProfitAlertGroupTypeLimit_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.Level : null;
            this.selectedProfitAlertGroupTypeLimit_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.Level : null;
            this.newAlert_Gain = [];
            this.newAlert_Gain.push({ value: true, label: "Yes" });
            this.newAlert_Gain.push({ value: false, label: "No" });
            this.newAlert_Gain.push({ value: null, label: "Undefined" });
            this.selectednewAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsNew : null;
            this.newAlert_Drawdown = [];
            this.newAlert_Drawdown.push({ value: true, label: "Yes" });
            this.newAlert_Drawdown.push({ value: false, label: "No" });
            this.newAlert_Drawdown.push({ value: null, label: "Undefined" });
            this.selectednewAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsNew : null;
            this.triggeredAlert_Gain = [];
            this.triggeredAlert_Gain.push({ value: true, label: "Yes" });
            this.triggeredAlert_Gain.push({ value: false, label: "No" });
            this.triggeredAlert_Gain.push({ value: null, label: "Undefined" });
            this.selectedTriggeredAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsTriggered : null;
            this.blnDtTriggeredDateDisabled_Gain = !this.selectedTriggeredAlert_Gain;
            this.triggeredAlert_Drawdown = [];
            this.triggeredAlert_Drawdown.push({ value: true, label: "Yes" });
            this.triggeredAlert_Drawdown.push({ value: false, label: "No" });
            this.triggeredAlert_Drawdown.push({ value: null, label: "Undefined" });
            this.selectedTriggeredAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsTriggered : null;
            this.blnDtTriggeredDateDisabled_Drawdown = !this.selectedTriggeredAlert_Drawdown;
            if (this.selectedProfitAlertGroupAlert_Gain && this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate) {
                this.dtSelectedTriggeredDate_Gain = new Date(this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate);
            }
            else {
                this.dtSelectedTriggeredDate_Gain = null;
            }
            if (this.selectedProfitAlertGroupAlert_Drawdown && this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate) {
                this.dtSelectedTriggeredDate_Drawdown = new Date(this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate);
            }
            else {
                this.dtSelectedTriggeredDate_Drawdown = null;
            }
            this.dtNewActionAlertStartDate_Gain = this.businessDate;
            this.dtNewActionAlertStartDate_Drawdown = this.businessDate;
            this.dtNewActionAlertEndDate_Gain = this.businessDate;
            this.dtNewActionAlertEndDate_Drawdown = this.businessDate;
            this.NewActionAlertLimit_Gain = 0;
            this.NewActionAlertLimit_Drawdown = 0;
            this.NewActionAlerts_Gain = this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values;
            this.NewActionAlerts_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values;
        }
    };
    AppProfitAlertGroupComponent.prototype.onRowSelectForProfitAlertGroup = function (event) {
        //console.log(event);
        this.blnIsNewGroupAdded = false;
        var selectedProfitAlertGroup = event.data;
        this.selectedProfitAlertGroupName = selectedProfitAlertGroup.Name;
        this.selectedProfitAlertGroupUpdateTiming = selectedProfitAlertGroup.UpdateTiming ? selectedProfitAlertGroup.UpdateTiming.toString() : "-1";
        this.selectedProfitAlertGroupUpdatedBy = selectedProfitAlertGroup.UpdatedBy;
        this.selectedProfitAlertGroupUpdatedOn = selectedProfitAlertGroup.Updated;
        this.selectedProfitAlertGroup.Updated != null ? this.selectedProfitAlertGroup.Updated = this.tprCommonService.getFormattedSystemDate(new Date(this.selectedProfitAlertGroup.Updated)) : "";
        this.selectedProfitAlertGroupAlert_Gain = this.selectedProfitAlertGroup.Alerts.$values.find(function (alert) { return alert.AlertGroupType == 1; });
        if (!this.selectedProfitAlertGroupAlert_Gain) {
            this.selectedProfitAlertGroupAlert_Gain = new clsProfitAlertGroups_Values_Alerts_Values();
        }
        this.selectedProfitAlertGroupAlert_Drawdown = this.selectedProfitAlertGroup.Alerts.$values.find(function (alert) { return alert.AlertGroupType == 0; });
        if (!this.selectedProfitAlertGroupAlert_Drawdown) {
            this.selectedProfitAlertGroupAlert_Drawdown = new clsProfitAlertGroups_Values_Alerts_Values();
        }
        this.selectedProfitAlertGroupTypeLimit_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.Level : null;
        this.selectedProfitAlertGroupTypeLimit_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.Level : null;
        this.selectednewAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsNew : null;
        this.selectednewAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsNew : null;
        this.selectedTriggeredAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsTriggered : null;
        this.selectedTriggeredAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsTriggered : null;
        this.blnDtTriggeredDateDisabled_Gain = !this.selectedTriggeredAlert_Gain;
        this.blnDtTriggeredDateDisabled_Drawdown = !this.selectedTriggeredAlert_Drawdown;
        if (this.selectedProfitAlertGroupAlert_Gain && this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate) {
            this.dtSelectedTriggeredDate_Gain = new Date(this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate);
        }
        else {
            this.dtSelectedTriggeredDate_Gain = null;
        }
        if (this.selectedProfitAlertGroupAlert_Drawdown && this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate) {
            this.dtSelectedTriggeredDate_Drawdown = new Date(this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate);
        }
        else {
            this.dtSelectedTriggeredDate_Drawdown = null;
        }
        this.dtNewActionAlertStartDate_Gain = this.businessDate;
        this.dtNewActionAlertStartDate_Drawdown = this.businessDate;
        this.dtNewActionAlertEndDate_Gain = this.businessDate;
        this.dtNewActionAlertEndDate_Drawdown = this.businessDate;
        this.NewActionAlertLimit_Gain = 0;
        this.NewActionAlertLimit_Drawdown = 0;
        this.NewActionAlerts_Gain = this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values;
        this.NewActionAlerts_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values;
    };
    AppProfitAlertGroupComponent.prototype.onProfitAlertGroupUpdateTimingChange = function () {
        console.log(this.selectedProfitAlertGroupUpdateTiming);
    };
    AppProfitAlertGroupComponent.prototype.onselectednewAlert_Gain_Change = function () {
        console.log(this.selectednewAlert_Gain);
    };
    AppProfitAlertGroupComponent.prototype.onselectednewAlert_Drawdown_Change = function () {
        console.log(this.selectednewAlert_Drawdown);
    };
    AppProfitAlertGroupComponent.prototype.onselectednTriggeredAlert_Gain_Change = function () {
        //console.log(this.selectedTriggeredAlert_Gain);
        this.blnDtTriggeredDateDisabled_Gain = !this.selectedTriggeredAlert_Gain;
    };
    AppProfitAlertGroupComponent.prototype.onselectednTriggeredAlert_Drawdown_Change = function () {
        //console.log(this.selectedTriggeredAlert_Drawdown);
        this.blnDtTriggeredDateDisabled_Drawdown = !this.selectedTriggeredAlert_Drawdown;
    };
    AppProfitAlertGroupComponent.prototype.AddProfitAlertGroup = function () {
        var selectedProfitAlertGroupForDelete = new clsProfitAlertGroupsValues();
        this.selectedProfitAlertGroup = selectedProfitAlertGroupForDelete;
        this.setDefaultDataForProfitAlertGroup();
        //console.log(this.selectedProfitAlertGroup);
        this.selectedProfitAlertGroup.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        var Gain_Alert = new clsProfitAlertGroups_Values_Alerts_Values();
        Gain_Alert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        Gain_Alert.AlertGroupType = 1;
        Gain_Alert.ActionAlerts = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts();
        this.selectedProfitAlertGroup.Alerts.$values.push(Gain_Alert);
        this.selectedProfitAlertGroupAlert_Gain = Gain_Alert;
        var Drawdown_Alert = new clsProfitAlertGroups_Values_Alerts_Values();
        Drawdown_Alert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        Drawdown_Alert.AlertGroupType = 0;
        Drawdown_Alert.ActionAlerts = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts();
        this.selectedProfitAlertGroup.Alerts.$values.push(Drawdown_Alert);
        this.selectedProfitAlertGroupAlert_Drawdown = Drawdown_Alert;
        this.blnIsNewGroupAdded = true;
    };
    AppProfitAlertGroupComponent.prototype.SaveProfitAlertGroup = function () {
        var _this = this;
        debugger;
        console.log(this.selectedProfitAlertGroup);
        console.log(this.profitAlertGroups);
        var blnValidationSuccessful = true;
        if (this.selectedProfitAlertGroup) {
            if (this.selectedProfitAlertGroup.Name == null || this.selectedProfitAlertGroup.Name == "") {
                blnValidationSuccessful = false;
                this.blnShowPopUp = true;
                this.Status = "Validation failed";
                this.ValidationMessage = "Error: Name should not be empty.";
                if (this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 1; }).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 0; }).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 1; }).Level.toString() == "" ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 0; }).Level.toString() == "") {
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Name should not be empty.\nError: Profit alert must have alert limit value.";
                }
                else if (isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 1; }).Level) ||
                    isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 0; }).Level)) {
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Name should not be empty.\nError: Profit alert must be numeric.";
                }
            }
            else {
                if (this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 1; }).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 0; }).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 1; }).Level.toString() == "" ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 0; }).Level.toString() == "") {
                    blnValidationSuccessful = false;
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Profit alert must have alert limit value.";
                }
                else if (isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 1; }).Level) ||
                    isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 0; }).Level)) {
                    blnValidationSuccessful = false;
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Profit alert must be numeric.";
                }
            }
        }
        if (blnValidationSuccessful) {
            this.confirmationService.confirm({
                header: "Save",
                message: 'Saving changes to the Profit Alert Groups. Are you sure?',
                rejectVisible: true,
                acceptVisible: true,
                accept: function () {
                    if (_this.blnIsNewGroupAdded) {
                        console.log(_this.selectedProfitAlertGroup);
                        _this.profitAlertGroups.push(_this.selectedProfitAlertGroup);
                    }
                    var objClsProfitAlertGroups_SaveData = new clsProfitAlertGroups_SaveData();
                    objClsProfitAlertGroups_SaveData = _this.setProfitAlertPostDataForSaveAndDelete(objClsProfitAlertGroups_SaveData);
                    debugger;
                    console.log("objclsprofalgroupssave", objClsProfitAlertGroups_SaveData);
                    var blnValidAlertLevelValues = true;
                    if (objClsProfitAlertGroups_SaveData) {
                        objClsProfitAlertGroups_SaveData.AlertGroups.forEach(function (alertGroup) {
                            console.log("Alert Group Name - " + alertGroup.Name, alertGroup);
                            alertGroup.Alerts.forEach(function (alert) {
                                if (alert.Level == null || alert.Level == undefined || alert.Level.toString().length == 0 || isNaN(alert.Level)) {
                                    blnValidAlertLevelValues = false;
                                }
                            });
                        });
                    }
                    if (!blnValidAlertLevelValues) {
                        _this.blnShowPopUp = true;
                        _this.Status = "Error";
                        _this.ValidationMessage = "Profit alert must have valid alert limit value.";
                    }
                    else {
                        _this.isRequesting = true;
                        _this.pagService.updateProfitAlertGroupsObservable(objClsProfitAlertGroups_SaveData)
                            .subscribe(function (response) {
                            //debugger;
                            //console.log(response);
                            if (response.Error) {
                                _this.stopRefreshing();
                                _this.Status = "Error";
                                _this.ValidationMessage = response.Error;
                                _this.blnShowPopUp = true;
                            }
                            else {
                                _this.blnShowPopUp = true;
                                _this.Status = "Success";
                                _this.ValidationMessage = "Data saved successfully";
                                _this.getProfitAlertGroupDate();
                                // this will ensure that the first page will be selected upon save, only if a new record is inserted; 
                                // else, it will be in the same page
                                if (_this.blnIsNewGroupAdded && _this.selectedProfitAlertGroup) {
                                    _this.setCurrentPage(1);
                                }
                            }
                        }, function (error) {
                            console.log(error);
                            _this.stopRefreshing();
                            _this.Status = "Error";
                            _this.ValidationMessage = error;
                            _this.blnShowPopUp = true;
                        });
                    }
                }
            });
        }
    };
    AppProfitAlertGroupComponent.prototype.DeleteProfitAlertGroup = function () {
        var _this = this;
        debugger;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Profit Alert Group?',
            rejectVisible: true,
            acceptVisible: true,
            accept: function () {
                _this.isRequesting = true;
                var selectedProfitAlertGroupForDelete = new clsProfitAlertGroupsValues();
                selectedProfitAlertGroupForDelete = _this.selectedProfitAlertGroup;
                _this.profitAlertGroups.splice(_this.profitAlertGroups.indexOf(selectedProfitAlertGroupForDelete), 1);
                //console.log(this.profitAlertGroups);
                var objClsProfitAlertGroups_SaveData = new clsProfitAlertGroups_SaveData();
                objClsProfitAlertGroups_SaveData = _this.setProfitAlertPostDataForSaveAndDelete(objClsProfitAlertGroups_SaveData);
                //console.log(objClsProfitAlertGroups_SaveData);
                _this.pagService.updateProfitAlertGroupsObservable(objClsProfitAlertGroups_SaveData)
                    .subscribe(function (response) {
                    if (response.Error) {
                        _this.stopRefreshing();
                        _this.Status = "Error";
                        _this.ValidationMessage = response.Error;
                        _this.blnShowPopUp = true;
                    }
                    else {
                        _this.blnShowPopUp = true;
                        _this.Status = "Success";
                        _this.ValidationMessage = "The selected Profit alert group is deleted successfully";
                        _this.getProfitAlertGroupDate();
                        _this.setCurrentPage(1);
                    }
                }, function (error) {
                    console.log(error);
                    _this.stopRefreshing();
                    _this.Status = "Error";
                    _this.ValidationMessage = error;
                    _this.blnShowPopUp = true;
                });
            }
        });
    };
    AppProfitAlertGroupComponent.prototype.setProfitAlertPostDataForSaveAndDelete = function (objClsProfitAlertGroups_SaveData) {
        objClsProfitAlertGroups_SaveData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.AlertGroupStatusCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        objClsProfitAlertGroups_SaveData.ReportingDate = null;
        objClsProfitAlertGroups_SaveData.AlertGroups = [];
        this.profitAlertGroups.forEach(function (alertGroup) {
            var objClsProfitAlertGroups_SaveData_AlertGroups = new clsProfitAlertGroups_SaveData_AlertGroups();
            objClsProfitAlertGroups_SaveData_AlertGroups.$type = alertGroup.$type;
            objClsProfitAlertGroups_SaveData_AlertGroups.Created = alertGroup.Created;
            objClsProfitAlertGroups_SaveData_AlertGroups.CreatedBy = alertGroup.CreatedBy;
            objClsProfitAlertGroups_SaveData_AlertGroups.IsInUse = alertGroup.IsInUse;
            objClsProfitAlertGroups_SaveData_AlertGroups.Members = [];
            objClsProfitAlertGroups_SaveData_AlertGroups.Name = alertGroup.Name;
            objClsProfitAlertGroups_SaveData_AlertGroups.ProfitAlertGroupStatusId = alertGroup.ProfitAlertGroupStatusId;
            objClsProfitAlertGroups_SaveData_AlertGroups.TradeDate = alertGroup.TradeDate;
            objClsProfitAlertGroups_SaveData_AlertGroups.UpdateTiming = alertGroup.UpdateTiming;
            objClsProfitAlertGroups_SaveData_AlertGroups.Updated = alertGroup.Updated;
            objClsProfitAlertGroups_SaveData_AlertGroups.UpdatedBy = alertGroup.UpdatedBy;
            objClsProfitAlertGroups_SaveData_AlertGroups.Id = alertGroup.Id;
            //objClsProfitAlertGroups_SaveData_AlertGroups.Alerts = alertGroup.Alerts.$values;
            alertGroup.Alerts.$values.forEach(function (alert) {
                var objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts = new clsProfitAlertGroups_SaveData_AlertGroups_Alerts();
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.$type = alert.$type;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Actual = alert.Actual;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.AlertGroupId = alert.AlertGroupId;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.AlertGroupType = alert.AlertGroupType;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Created = alert.Created;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.CreatedBy = alert.CreatedBy;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.CurrentActionAlertExpiryDate = alert.CurrentActionAlertExpiryDate;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.CurrentActionAlertLevel = alert.CurrentActionAlertLevel;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Id = alert.Id;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Level = alert.Level;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ReportedIsNew = alert.ReportedIsNew;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ReportedIsTriggered = alert.ReportedIsTriggered;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ReportedTriggeredDate = alert.ReportedTriggeredDate;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.StatusId = alert.StatusId;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.SystemIsNew = alert.SystemIsNew;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.SystemIsTriggered = alert.SystemIsTriggered;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.SystemTriggeredDate = alert.SystemTriggeredDate;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Updated = alert.Updated;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UpdatedBy = alert.UpdatedBy;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UserIsNew = alert.UserIsNew;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UserIsTriggered = alert.UserIsTriggered;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UserTriggeredDate = alert.UserTriggeredDate;
                alert.ActionAlerts.$values.forEach(function (actionAlert) {
                    var objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values();
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.$type = actionAlert.$type;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.AlertGroupId = actionAlert.AlertGroupId;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.AlertId = actionAlert.AlertId;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Created = actionAlert.Created;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.CreatedBy = actionAlert.CreatedBy;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.EndDate = actionAlert.EndDate;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Id = actionAlert.Id;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Level = actionAlert.Level;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.StartDate = actionAlert.StartDate;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Updated = actionAlert.Updated;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.UpdatedBy = actionAlert.UpdatedBy;
                    objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ActionAlerts.push(objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values);
                });
                objClsProfitAlertGroups_SaveData_AlertGroups.Alerts.push(objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts);
            });
            objClsProfitAlertGroups_SaveData.AlertGroups.push(objClsProfitAlertGroups_SaveData_AlertGroups);
        });
        //console.log(objClsProfitAlertGroups_SaveData);
        return objClsProfitAlertGroups_SaveData;
    };
    AppProfitAlertGroupComponent.prototype.setCurrentPage = function (n) {
        //debugger;
        this.dataTable.reset();
        var paging = {
            first: ((n - 1) * this.dataTable.rows),
            rows: this.dataTable.rows
        };
        this.dataTable.paginate(paging);
    };
    AppProfitAlertGroupComponent.prototype.AddNewActionAlertDrawdown = function () {
        var _this = this;
        debugger;
        var blnValidActionAlert = true;
        this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.forEach(function (actionAlert) {
            if ((_this.dtNewActionAlertStartDate_Drawdown >= new Date(actionAlert.StartDate) &&
                _this.dtNewActionAlertStartDate_Drawdown <= new Date(actionAlert.EndDate)) ||
                (_this.dtNewActionAlertEndDate_Drawdown >= new Date(actionAlert.StartDate) &&
                    _this.dtNewActionAlertEndDate_Drawdown <= new Date(actionAlert.EndDate))) {
                blnValidActionAlert = false;
                _this.blnShowPopUp = true;
                _this.Status = "Validation failed";
                _this.ValidationMessage = "Error: New action alert cannot overlap existing alerts.";
            }
        });
        if (this.dtNewActionAlertStartDate_Drawdown > this.dtNewActionAlertEndDate_Drawdown) {
            blnValidActionAlert = false;
            this.blnShowPopUp = true;
            this.Status = "Validation failed";
            this.ValidationMessage = "Error: Start date of alert should be less than end date.";
        }
        if (blnValidActionAlert) {
            if (!isNaN(this.NewActionAlertLimit_Drawdown)) {
                var newActionAlert = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values();
                newActionAlert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ActionAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                newActionAlert.AlertGroupId = this.selectedProfitAlertGroup.Id;
                //newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Drawdown.toLocaleString());
                //newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Drawdown.toLocaleString());
                newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Drawdown.toString());
                newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Drawdown.toString());
                newActionAlert.Level = this.NewActionAlertLimit_Drawdown;
                this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.push(newActionAlert);
            }
            else {
                this.blnShowPopUp = true;
                this.Status = "Validation failed";
                this.ValidationMessage = "Error: Please enter proper value for New Action Alert limit.";
            }
        }
    };
    AppProfitAlertGroupComponent.prototype.AddNewActionAlertGain = function () {
        //debugger;
        var _this = this;
        var blnValidActionAlert = true;
        this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.forEach(function (actionAlert) {
            //debugger;
            if ((_this.dtNewActionAlertStartDate_Gain >= new Date(actionAlert.StartDate) &&
                _this.dtNewActionAlertStartDate_Gain <= new Date(actionAlert.EndDate)) ||
                (_this.dtNewActionAlertEndDate_Gain >= new Date(actionAlert.StartDate) &&
                    _this.dtNewActionAlertEndDate_Gain <= new Date(actionAlert.EndDate))) {
                blnValidActionAlert = false;
                _this.blnShowPopUp = true;
                _this.Status = "Validation failed";
                _this.ValidationMessage = "Error: New action alert cannot overlap existing alerts.";
            }
        });
        //debugger;
        if (this.dtNewActionAlertStartDate_Gain > this.dtNewActionAlertEndDate_Gain) {
            blnValidActionAlert = false;
            this.blnShowPopUp = true;
            this.Status = "Validation failed";
            this.ValidationMessage = "Error: Start date of alert should be less than end date.";
        }
        try {
            if (blnValidActionAlert) {
                //debugger;
                if (!isNaN(this.NewActionAlertLimit_Gain)) {
                    var newActionAlert = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values();
                    newActionAlert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ActionAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    newActionAlert.AlertGroupId = this.selectedProfitAlertGroup.Id;
                    // newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Gain.toLocaleString());
                    // newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Gain.toLocaleString());
                    newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Gain.toString());
                    newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Gain.toString());
                    newActionAlert.Level = this.NewActionAlertLimit_Gain;
                    this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.push(newActionAlert);
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Please enter proper value for New Action Alert limit.";
                }
            }
        }
        catch (e) {
            console.log(e);
        }
    };
    AppProfitAlertGroupComponent.prototype.deleteDrawdownAlerts = function (objDrawDownAlert) {
        var _this = this;
        //console.log(objDrawDownAlert);
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Action Alert?',
            rejectVisible: true,
            acceptVisible: true,
            accept: function () {
                var index = _this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.indexOf(objDrawDownAlert);
                if (index != -1) {
                    _this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.splice(index, 1);
                }
            }
        });
    };
    AppProfitAlertGroupComponent.prototype.deleteGainAlerts = function (objGainAlert) {
        var _this = this;
        //console.log(objGainAlert);
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Action Alert?',
            rejectVisible: true,
            acceptVisible: true,
            accept: function () {
                var index = _this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.indexOf(objGainAlert);
                if (index != -1) {
                    _this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.splice(index, 1);
                }
            }
        });
    };
    AppProfitAlertGroupComponent.prototype.onSelectTriggeredDate_Gain = function (value) {
        var selectedGainObject = this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 1; });
        selectedGainObject.UserTriggeredDate = selectedGainObject ? this.setDate(this.dtSelectedTriggeredDate_Gain.toString()) : null;
    };
    AppProfitAlertGroupComponent.prototype.onSelectTriggeredDate_Drawdown = function (value) {
        var selectedGainObject = this.selectedProfitAlertGroup.Alerts.$values.find(function (x) { return x.AlertGroupType == 0; });
        selectedGainObject.UserTriggeredDate = selectedGainObject ? this.setDate(this.dtSelectedTriggeredDate_Drawdown.toString()) : null;
    };
    AppProfitAlertGroupComponent.prototype.setDate = function (data) {
        var myDate = new Date(data);
        var output = "";
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var modifiedDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        output = myDate.getDate().toString().length > 1 ?
            myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear() :
            "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        return output;
    };
    AppProfitAlertGroupComponent.prototype.onCustomNumericValidationForPositiveandNegativeIntegers = function (event) {
        return (String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null);
    };
    AppProfitAlertGroupComponent.prototype.onCustomNumericValidation = function (event) {
        return (String.fromCharCode(event.charCode).match(/[0-9.]/g) != null);
    };
    __decorate([
        core_1.ViewChild('profitAlertGroupMain'), 
        __metadata('design:type', primeng_1.DataTable)
    ], AppProfitAlertGroupComponent.prototype, "dataTable", void 0);
    AppProfitAlertGroupComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/ProfitAlertGroup/app.profitAlertGroup.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRProfitAlertGroupsService_1.TPRProfitAlertGroupsService, primeng_2.ConfirmationService, app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper])
    ], AppProfitAlertGroupComponent);
    return AppProfitAlertGroupComponent;
}());
exports.AppProfitAlertGroupComponent = AppProfitAlertGroupComponent;
var clsProfitAlertGroupsValues = (function () {
    function clsProfitAlertGroupsValues($type, Alerts, Name, Members, IsInUse, UpdateTiming, TradeDate, ProfitAlertGroupStatusId, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Alerts === void 0) { Alerts = new clsProfitAlertGroups_Values_Alerts(); }
        if (Name === void 0) { Name = null; }
        if (Members === void 0) { Members = new clsProfitAlertGroups_Values_Members(); }
        if (IsInUse === void 0) { IsInUse = false; }
        if (UpdateTiming === void 0) { UpdateTiming = -1; }
        if (TradeDate === void 0) { TradeDate = null; }
        if (ProfitAlertGroupStatusId === void 0) { ProfitAlertGroupStatusId = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Alerts = Alerts;
        this.Name = Name;
        this.Members = Members;
        this.IsInUse = IsInUse;
        this.UpdateTiming = UpdateTiming;
        this.TradeDate = TradeDate;
        this.ProfitAlertGroupStatusId = ProfitAlertGroupStatusId;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsProfitAlertGroupsValues;
}());
var clsProfitAlertGroups_Values_Alerts = (function () {
    function clsProfitAlertGroups_Values_Alerts($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsProfitAlertGroups_Values_Alerts;
}());
var clsProfitAlertGroups_Values_Members = (function () {
    function clsProfitAlertGroups_Values_Members($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsProfitAlertGroups_Values_Members;
}());
var clsProfitAlertGroups_Values_Alerts_Values = (function () {
    function clsProfitAlertGroups_Values_Alerts_Values($type, ActionAlerts, AlertGroupType, Level, AlertGroupId, CurrentActionAlertExpiryDate, CurrentActionAlertLevel, Actual, StatusId, SystemIsNew, SystemIsTriggered, SystemTriggeredDate, UserIsNew, UserIsTriggered, UserTriggeredDate, ReportedIsNew, ReportedIsTriggered, ReportedTriggeredDate, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (ActionAlerts === void 0) { ActionAlerts = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts(); }
        if (AlertGroupType === void 0) { AlertGroupType = 0; }
        if (Level === void 0) { Level = null; }
        if (AlertGroupId === void 0) { AlertGroupId = 0; }
        if (CurrentActionAlertExpiryDate === void 0) { CurrentActionAlertExpiryDate = null; }
        if (CurrentActionAlertLevel === void 0) { CurrentActionAlertLevel = null; }
        if (Actual === void 0) { Actual = null; }
        if (StatusId === void 0) { StatusId = null; }
        if (SystemIsNew === void 0) { SystemIsNew = false; }
        if (SystemIsTriggered === void 0) { SystemIsTriggered = false; }
        if (SystemTriggeredDate === void 0) { SystemTriggeredDate = null; }
        if (UserIsNew === void 0) { UserIsNew = null; }
        if (UserIsTriggered === void 0) { UserIsTriggered = null; }
        if (UserTriggeredDate === void 0) { UserTriggeredDate = null; }
        if (ReportedIsNew === void 0) { ReportedIsNew = false; }
        if (ReportedIsTriggered === void 0) { ReportedIsTriggered = false; }
        if (ReportedTriggeredDate === void 0) { ReportedTriggeredDate = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.ActionAlerts = ActionAlerts;
        this.AlertGroupType = AlertGroupType;
        this.Level = Level;
        this.AlertGroupId = AlertGroupId;
        this.CurrentActionAlertExpiryDate = CurrentActionAlertExpiryDate;
        this.CurrentActionAlertLevel = CurrentActionAlertLevel;
        this.Actual = Actual;
        this.StatusId = StatusId;
        this.SystemIsNew = SystemIsNew;
        this.SystemIsTriggered = SystemIsTriggered;
        this.SystemTriggeredDate = SystemTriggeredDate;
        this.UserIsNew = UserIsNew;
        this.UserIsTriggered = UserIsTriggered;
        this.UserTriggeredDate = UserTriggeredDate;
        this.ReportedIsNew = ReportedIsNew;
        this.ReportedIsTriggered = ReportedIsTriggered;
        this.ReportedTriggeredDate = ReportedTriggeredDate;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsProfitAlertGroups_Values_Alerts_Values;
}());
var clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts = (function () {
    function clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts;
}());
var clsProfitAlertGroups_SaveData = (function () {
    function clsProfitAlertGroups_SaveData($type, AlertGroups, ReportingDate) {
        if ($type === void 0) { $type = null; }
        if (AlertGroups === void 0) { AlertGroups = []; }
        if (ReportingDate === void 0) { ReportingDate = null; }
        this.$type = $type;
        this.AlertGroups = AlertGroups;
        this.ReportingDate = ReportingDate;
    }
    return clsProfitAlertGroups_SaveData;
}());
var clsProfitAlertGroups_SaveData_AlertGroups = (function () {
    function clsProfitAlertGroups_SaveData_AlertGroups($type, Alerts, Name, Members, IsInUse, UpdateTiming, TradeDate, ProfitAlertGroupStatusId, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Alerts === void 0) { Alerts = []; }
        if (Name === void 0) { Name = null; }
        if (Members === void 0) { Members = []; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (UpdateTiming === void 0) { UpdateTiming = 0; }
        if (TradeDate === void 0) { TradeDate = null; }
        if (ProfitAlertGroupStatusId === void 0) { ProfitAlertGroupStatusId = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Alerts = Alerts;
        this.Name = Name;
        this.Members = Members;
        this.IsInUse = IsInUse;
        this.UpdateTiming = UpdateTiming;
        this.TradeDate = TradeDate;
        this.ProfitAlertGroupStatusId = ProfitAlertGroupStatusId;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsProfitAlertGroups_SaveData_AlertGroups;
}());
var clsProfitAlertGroups_SaveData_AlertGroups_Alerts = (function () {
    function clsProfitAlertGroups_SaveData_AlertGroups_Alerts($type, ActionAlerts, AlertGroupType, Level, AlertGroupId, CurrentActionAlertExpiryDate, CurrentActionAlertLevel, Actual, StatusId, SystemIsNew, SystemIsTriggered, SystemTriggeredDate, UserIsNew, UserIsTriggered, UserTriggeredDate, ReportedIsNew, ReportedIsTriggered, ReportedTriggeredDate, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (ActionAlerts === void 0) { ActionAlerts = []; }
        if (AlertGroupType === void 0) { AlertGroupType = 0; }
        if (Level === void 0) { Level = 0; }
        if (AlertGroupId === void 0) { AlertGroupId = 0; }
        if (CurrentActionAlertExpiryDate === void 0) { CurrentActionAlertExpiryDate = null; }
        if (CurrentActionAlertLevel === void 0) { CurrentActionAlertLevel = null; }
        if (Actual === void 0) { Actual = null; }
        if (StatusId === void 0) { StatusId = null; }
        if (SystemIsNew === void 0) { SystemIsNew = false; }
        if (SystemIsTriggered === void 0) { SystemIsTriggered = false; }
        if (SystemTriggeredDate === void 0) { SystemTriggeredDate = null; }
        if (UserIsNew === void 0) { UserIsNew = false; }
        if (UserIsTriggered === void 0) { UserIsTriggered = false; }
        if (UserTriggeredDate === void 0) { UserTriggeredDate = null; }
        if (ReportedIsNew === void 0) { ReportedIsNew = false; }
        if (ReportedIsTriggered === void 0) { ReportedIsTriggered = false; }
        if (ReportedTriggeredDate === void 0) { ReportedTriggeredDate = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.ActionAlerts = ActionAlerts;
        this.AlertGroupType = AlertGroupType;
        this.Level = Level;
        this.AlertGroupId = AlertGroupId;
        this.CurrentActionAlertExpiryDate = CurrentActionAlertExpiryDate;
        this.CurrentActionAlertLevel = CurrentActionAlertLevel;
        this.Actual = Actual;
        this.StatusId = StatusId;
        this.SystemIsNew = SystemIsNew;
        this.SystemIsTriggered = SystemIsTriggered;
        this.SystemTriggeredDate = SystemTriggeredDate;
        this.UserIsNew = UserIsNew;
        this.UserIsTriggered = UserIsTriggered;
        this.UserTriggeredDate = UserTriggeredDate;
        this.ReportedIsNew = ReportedIsNew;
        this.ReportedIsTriggered = ReportedIsTriggered;
        this.ReportedTriggeredDate = ReportedTriggeredDate;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsProfitAlertGroups_SaveData_AlertGroups_Alerts;
}());
var clsProfitAlertGroups_Values_Members_Values = (function () {
    function clsProfitAlertGroups_Values_Members_Values($type, Name, NodeId, StructureId, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (NodeId === void 0) { NodeId = 0; }
        if (StructureId === void 0) { StructureId = 0; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.NodeId = NodeId;
        this.StructureId = StructureId;
        this.Id = Id;
    }
    return clsProfitAlertGroups_Values_Members_Values;
}());
var clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values = (function () {
    function clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values($type, AlertId, AlertGroupId, Level, StartDate, EndDate, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (AlertId === void 0) { AlertId = 0; }
        if (AlertGroupId === void 0) { AlertGroupId = 0; }
        if (Level === void 0) { Level = 0; }
        if (StartDate === void 0) { StartDate = null; }
        if (EndDate === void 0) { EndDate = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.AlertId = AlertId;
        this.AlertGroupId = AlertGroupId;
        this.Level = Level;
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values;
}());
//# sourceMappingURL=app.profitAlertGroup.component.js.map