"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var primeng_1 = require('primeng/primeng');
var app_TPRHierarchyservice_1 = require('../../service/app.TPRHierarchyservice');
var app_workDayService_1 = require('../../service/app.workDayService');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var CircularJSON = require('circular-json');
var AppTprHierarchyComponent = (function () {
    function AppTprHierarchyComponent(tPRHierarchyservice, router, serviceHelper, confirmationService, workDayService, tPRcommonService) {
        this.tPRHierarchyservice = tPRHierarchyservice;
        this.router = router;
        this.serviceHelper = serviceHelper;
        this.confirmationService = confirmationService;
        this.workDayService = workDayService;
        this.tPRcommonService = tPRcommonService;
        this.selectedNode = new RootValue();
        this.blnMoveNode = false;
        this.blnAddToFavourites = false;
        this.searchNodeResults = [];
        this.strSearchNodeText = '';
        this.nodeArrays = [];
        this.inactiveNodes = [];
        this.traversedPathArray = [];
        this.traversedPathArrayForNodeRemoval = [];
        this.isNodeMoved = false;
        this.arrFavouriteNodes = [];
        this.infoMoveNode = [];
        this.displayMessage = false;
        this.isParent = false;
        this.favouriteNodesArray = [];
        this.lastSelectedNode = "";
        this.strFavouriteNodeSelect = "";
        this.userName = "";
        this.selectedFavouriteNode = "";
        this.blnShowInactiveNodes = false;
        // selectedNodeDetails: IHierarchyEditNode = new clsHierarchyEditNode();
        this.businessDate = "";
        this.blnDisableControlsTillPageLoads = true;
        this.moveNodeArrays = [];
        this.updateHierarchyFlag = false;
        this.showUpdateHierarchyFooter = false;
        this.availableRoles = new UserRolesValues();
        this.userRoles = [];
        this.holidays = [];
        this.canEditNode = false;
        this.canEnterValue = false;
        this.canEditHierarchy = false;
        this.node_ProfitAlertMappings = [];
    }
    AppTprHierarchyComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.loadTree();
        this.items = [
            { label: 'Add Child', command: function (event) { return _this.addChildSelectedContextMenu(_this.selectedNode); } },
            { label: 'Edit Node', command: function (event) { return _this.editChildSelectedContextMenu(_this.selectedNode); } },
            { label: 'Remove Node', command: function (event) { return _this.removeNodeSelectedContextMenu(_this.selectedNode); } },
            { label: 'Enter Value', command: function (event) { return _this.enterValueSelectedContextMenu(_this.selectedNode); } },
            { label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } },
            { label: 'Add To Favourites', command: function (event) { return _this.addToFavouritesSelectedContextMenu(_this.selectedNode); } },
        ];
        this.actionItemsForNode = [
            { label: 'Add Child', command: function (event) { return _this.addChildSelectedContextMenu(_this.selectedNode); } },
            { label: 'Edit Node', command: function (event) { return _this.editChildSelectedContextMenu(_this.selectedNode); } },
            { label: 'Remove Node', command: function (event) { return _this.removeNodeSelectedContextMenu(_this.selectedNode); } },
            { label: 'Enter Value', command: function (event) { return _this.enterValueSelectedContextMenu(_this.selectedNode); } },
            { label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } },
            { label: 'Add To Favourites', command: function (event) { return _this.addToFavouritesSelectedContextMenu(_this.selectedNode); } }
        ];
        this.actionItemsForNode.forEach(function (action) {
            if (action.label == "Add Child" || action.label == "Edit Node" || action.label == "Remove Node" || action.label == "Enter Value" ||
                action.label == "Move Node") {
                action.disabled = true;
            }
        });
        this.businessDate = localStorage.getItem("BusinessDate");
    };
    AppTprHierarchyComponent.prototype.loadTree = function () {
        var _this = this;
        console.log("Loading Tree...");
        this.isRequesting = true;
        this.cleanup();
        this.isParent = false;
        this.infoMoveNode = [];
        this.moveNodeArrays = [];
        this.inactiveNodes = [];
        this.nodeArrays = [];
        this.isNodeMoved = false;
        this.displayMessage = false;
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(function (files) { return _this.setNodeData(files); });
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(function (files) { return _this.setTreeData(files); });
    };
    AppTprHierarchyComponent.prototype.cleanup = function () {
        this.showUpdateHierarchyFooter = false;
        this.updateHierarchyFlag = false;
        this.updateHierarchyMessage = null;
        this.updateHierarchyHeader = null;
        this.targetUpdateTimingAncestor = null;
    };
    AppTprHierarchyComponent.prototype.setUserPreferenceData = function (data) {
        this.favouriteNodesArray = data.Result.Favourites.$values;
        this.lastSelectedNode = data.Result.LastSelectedNode;
        this.userName = data.Result.UserName;
        this.blnDisableControlsTillPageLoads = false;
    };
    AppTprHierarchyComponent.prototype.setTreeData = function (data) {
        var _this = this;
        if (data.Result) {
            console.log("Tree Data->", data.Result.Children.$values);
            var hierarchyMain_1 = data.Result.Children.$values;
            // call the service for getting node - profit alert group mapping
            this.tPRHierarchyservice.getHierarchyForProfitGroupsObservable().
                subscribe(function (files) { return _this.updateNodeDataWithTooltip(hierarchyMain_1, files); });
        }
    };
    AppTprHierarchyComponent.prototype.updateNodeDataWithTooltip = function (hierarchyMain, data) {
        var _this = this;
        //debugger;
        this.node_ProfitAlertMappings = data.Result.NodeWithAlertGroups.$values;
        //console.log("node_ProfitAlertMappings=>", this.node_ProfitAlertMappings);
        hierarchyMain.forEach(function (node) {
            _this.updateChildrenPropRecursive(node);
        });
        console.log("hierarchyMain ->", hierarchyMain);
        this.mainListOfTree = hierarchyMain;
    };
    AppTprHierarchyComponent.prototype.updateNodeDataWithTooltipForDisplay = function (hierarchyMain, data) {
        var _this = this;
        //debugger;
        this.node_ProfitAlertMappings = data.Result.NodeWithAlertGroups.$values;
        console.log("node_ProfitAlertMappings=>", this.node_ProfitAlertMappings);
        hierarchyMain.forEach(function (node) {
            _this.updateChildrenPropRecursive(node);
        });
        console.log("Hierarchy->", hierarchyMain);
        this.mainListOfTreeForDisplay = hierarchyMain;
        if (!this.blnShowInactiveNodes) {
            this.mainListOfTreeForDisplay.forEach(function (node) {
                node.icon = "murali mohan";
                _this.removeInactiveNodes(node);
            });
        }
        this.updateNodeProps();
        this.stopRefreshing();
    };
    AppTprHierarchyComponent.prototype.getConstants = function (data) {
        console.log("Constants ->", data);
        this.constants = data;
        this.AuthorizeUser();
    };
    AppTprHierarchyComponent.prototype.setNodeData = function (data) {
        var _this = this;
        //debugger;
        if (data.Result) {
            console.log("Node Data->", data.Result.Children.$values);
            this.hierarchy = data.Result.Children.$values;
            // this.hierarchy.forEach((node: any) => {
            //     this.updateChildrenPropRecursive(node);
            // });
            // call the service for getting node - profit alert group mapping
            this.tPRHierarchyservice.getHierarchyForProfitGroupsObservable().
                subscribe(function (files) { return _this.updateNodeDataWithTooltipForDisplay(_this.hierarchy, files); });
            this.searchNodeResults = data.Result.NodeNames.$values;
            this.mainNodeStartDate = data.Result.StartDate;
            this.mainNodeType = data.Result.Type;
            this.mainNodeId = data.Result.Id;
            this.tPRHierarchyservice.getUserPreferenceObservable()
                .subscribe(function (data) {
                _this.setUserPreferenceData(data);
            });
            this.workDayService.getWorkingDatesObservable()
                .subscribe(function (data) {
                _this.getWorkingDates(data);
            });
            if (localStorage.getItem("UserRole")) {
                this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
                console.log("User Roles from Local Storage ->", this.userRoles);
            }
            else {
                this.tPRcommonService.getUserRolesObservable()
                    .subscribe(function (data) { return _this.setUserRolesData(data); });
            }
            this.serviceHelper.importSettings()
                .subscribe(function (data) { return _this.getConstants(data); });
        }
        else if (data.Error) {
            this.updateHierarchyFlag = true;
            this.updateHierarchyHeader = "Error";
            this.updateHierarchyMessage = data.Error;
            this.showUpdateHierarchyFooter = false;
            this.stopRefreshing();
        }
    };
    AppTprHierarchyComponent.prototype.setUserRolesData = function (data) {
        var _this = this;
        this.availableRoles.$values = [];
        this.availableRoles.$values = data.Result.UserRoles.$values;
        this.availableRoles.$values.forEach(function (role) {
            _this.userRoles.push(role.Name);
        });
        console.log("User Role ->", this.userRoles);
        localStorage.setItem("UserRole", JSON.stringify(this.userRoles));
    };
    AppTprHierarchyComponent.prototype.AuthorizeUser = function () {
        this.canEditNode = this.isUserAuthorised("EditNode");
        this.canEnterValue = this.isUserAuthorised("EnterValue");
        this.canEditHierarchy = this.isUserAuthorised("EditHierarchy");
    };
    AppTprHierarchyComponent.prototype.isUserAuthorised = function (action) {
        var _this = this;
        console.log("Authorize Action ->", action);
        switch (action) {
            case "EditNode":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                        this.userRoles.some(function (x) { return x == _this.constants.TPRITSupport; }));
            case "EnterValue":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                        this.userRoles.some(function (x) { return x == _this.constants.TPRMarginManagement; }) ||
                        this.userRoles.some(function (x) { return x == _this.constants.TPRRiskManagement; }));
            case "EditHierarchy":
                return this.userRoles != undefined && this.constants != undefined &&
                    this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; });
            default: return false;
        }
    };
    AppTprHierarchyComponent.prototype.getWorkingDates = function (data) {
        this.validDates = data.Result.Range.$values;
        localStorage.setItem("WorkingDates", JSON.stringify(this.validDates));
    };
    AppTprHierarchyComponent.prototype.getPreviousorNextWorkingDay = function (initialDate, isPrevious) {
        var _this = this;
        console.log("getPreviousorNextWorkingDay - Initial Date ->" + initialDate);
        var days = isPrevious ? -1 : 1;
        initialDate.setHours(0, 0, 0, 0);
        initialDate.setDate(initialDate.getDate() + days);
        if (localStorage.getItem("WorkingDates") && localStorage.getItem("Holidays")) {
            if (JSON.parse(localStorage.getItem("WorkingDates"))) {
                this.validDates = JSON.parse(localStorage.getItem("WorkingDates"));
            }
            if (JSON.parse(localStorage.getItem("Holidays"))) {
                this.holidays = JSON.parse(localStorage.getItem("Holidays"));
            }
            console.log("Working Dates ->", this.validDates);
            while (this.validDates && this.holidays && this.validDates.length > 0 && this.holidays.length > 0) {
                if (this.validDates.some(function (d) { return ((new Date(d)).setHours(0, 0, 0, 0) == initialDate.setHours(0, 0, 0, 0)); })
                    && !this.holidays.some(function (d) { return (d.Region == null && _this.tPRcommonService.getFormattedSystemDate_Date(new Date(d.Date)) == _this.tPRcommonService.getFormattedSystemDate_Date(initialDate)); })) {
                    break;
                }
                initialDate.setDate(initialDate.getDate() + days);
            }
        }
        else {
            console.log("Unable to retrieve holiday and working dates date from local storage");
        }
        return initialDate;
    };
    AppTprHierarchyComponent.prototype.updateChildrenPropRecursive = function (node) {
        var _this = this;
        node.Children = node.Children.$values;
        node.children = node.Children;
        node.label = node.NodeName;
        node.toolTipText = (" Name: " + node.NodeName + " \n Type: " + node.NodeType);
        if (node.UpdateTiming != null) {
            node.toolTipText += ("\n Update timing:  R" + (node.UpdateTiming));
        }
        if (node.MVarUpdateTiming != null) {
            node.toolTipText += ("\n MVAR update timing:  R" + (node.MVarUpdateTiming));
        }
        var node_Profit_Data = new clsHierarchyEditNode_Node_ProfitAlertGroup_Values();
        node_Profit_Data = this.node_ProfitAlertMappings.find(function (nodePFA) { return nodePFA.NodeId == node.NodeId; });
        if (node_Profit_Data && node_Profit_Data.FormettedAlertGroups && node_Profit_Data.FormettedAlertGroups.length > 0) {
            //debugger;
            node.toolTipText += ("\n Profit Alerts : ");
            // node_Profit_Data.AlertGroups.$values.forEach(alerts => {
            //     node.toolTipText += ((alerts) + ", ");
            // });
            node.toolTipText += node_Profit_Data.FormettedAlertGroups;
        }
        if (node.Children) {
            node.Children.forEach(function (childNode) {
                _this.updateChildrenPropRecursive(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.updateNodeProps = function () {
        var _this = this;
        this.mainListOfTreeForDisplay.forEach(function (node) {
            _this.AddNodeToArray(node);
        });
    };
    AppTprHierarchyComponent.prototype.AddNodeToArray = function (node) {
        var _this = this;
        this.nodeArrays.push({
            label: node.NodeName,
            $type: node.type,
            Children: node.Children,
            HasAnyOutputData: node.HasAnyOutputData,
            HasPlans: node.HasPlans,
            Level: node.Level,
            MVarUpdateTiming: node.MVarUpdateTiming,
            IsActive: node.IsActive,
            IsPnlHolder: node.IsPnlHolder,
            NodeId: node.NodeId,
            NodeType: node.NodeType,
            SplitType: node.SplitType,
            UpdateTiming: node.UpdateTiming,
            children: node.children,
            collapsedIcon: "fa-plus-square",
            data: node.data,
            expanded: node.expanded,
            expandedIcon: "fa-minus-square",
            icon: node.icon,
            id: node.id,
            leaf: node.leaf,
            parent: node.parent,
            Id: node.Id,
            ParentId: node.ParentId,
            NodeName: node.NodeName,
            type: node.type,
            partialSelected: node.partialSelected
        });
        node.children = node.Children;
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.AddNodeToArray(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.expandAll = function () {
        var _this = this;
        debugger;
        this.isRequesting = true;
        // this.stopRefreshing();
        setTimeout(function () {
            _this.mainListOfTreeForDisplay.forEach(function (node) { _this.expandRecursive(node, true); });
            _this.stopRefreshing();
        }, 3000);
    };
    AppTprHierarchyComponent.prototype.collapseAll = function () {
        var _this = this;
        this.isRequesting = true;
        // this.stopRefreshing();
        setTimeout(function () {
            _this.mainListOfTreeForDisplay.forEach(function (node) { _this.expandRecursive(node, false); });
            _this.stopRefreshing();
        }, 3000);
        // this.mainListOfTreeForDisplay.forEach(node => {
        //     this.expandRecursive(node, false);
        // });
    };
    AppTprHierarchyComponent.prototype.reloadAll = function () {
        this.loadTree();
        this.actionItemsForNode.forEach(function (action) {
            if (action.label == "Add Child" || action.label == "Edit Node" || action.label == "Remove Node" || action.label == "Enter Value" ||
                action.label == "Move Node") {
                action.disabled = true;
            }
        });
        this.businessDate = localStorage.getItem("BusinessDate");
    };
    AppTprHierarchyComponent.prototype.expandRecursive = function (node, isExpand) {
        var _this = this;
        node.expanded = isExpand;
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.expandRecursive(childNode, isExpand);
            });
        }
    };
    AppTprHierarchyComponent.prototype.removeInactiveNodes = function (node) {
        var _this = this;
        if (node.children) {
            node.Children.filter(function (c) { return (!c.IsActive); }).forEach(function (inactiveNode) {
                _this.inactiveNodes.push(inactiveNode.NodeName.toUpperCase());
            });
            node.Children = node.Children.filter(function (c) { return c.IsActive; });
            node.children.forEach(function (childNode) {
                _this.removeInactiveNodes(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.expandRecursiveForSearch = function (node, isExpanded) {
        var _this = this;
        node.expanded = this.traversedPathArray.find(function (item) { return item == node.Id; }) ? isExpanded : !isExpanded;
        if (node.NodeName.toUpperCase() == this.strSearchNodeText.toUpperCase()) {
            this.selectedNode = node;
            node.expanded = !isExpanded;
        }
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.expandRecursiveForSearch(childNode, isExpanded);
            });
        }
    };
    AppTprHierarchyComponent.prototype.expandRecursiveForLastEditedNodeSearch = function (node, isExpanded) {
        var _this = this;
        node.expanded = this.traversedPathArray.find(function (item) { return item == node.Id; }) ? isExpanded : !isExpanded;
        if (node.NodeName.toUpperCase() == this.lastSelectedNode.toUpperCase()) {
            this.selectedNode = node;
            node.expanded = !isExpanded;
        }
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.expandRecursiveForLastEditedNodeSearch(childNode, isExpanded);
            });
        }
    };
    AppTprHierarchyComponent.prototype.expandRecursiveForFavouriteNodeSearch = function (node, isExpanded) {
        var _this = this;
        node.expanded = this.traversedPathArray.find(function (item) { return item == node.Id; }) ? isExpanded : !isExpanded;
        if (node.NodeName.toUpperCase() == this.strFavouriteNodeSelect.toUpperCase()) {
            this.selectedNode = node;
            node.expanded = !isExpanded;
        }
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.expandRecursiveForFavouriteNodeSearch(childNode, isExpanded);
            });
        }
    };
    AppTprHierarchyComponent.prototype.getUpdateTimingFromHierarchyForNode = function (Id) {
        var nodeArray;
        nodeArray = this.nodeArrays.find(function (node) { return node.Id == Id; });
        if (nodeArray && this.selectedUpdateTiming == null) {
            if (!nodeArray.UpdateTiming) {
                this.getUpdateTimingFromHierarchyForNode(nodeArray.ParentId);
            }
            else {
                this.selectedUpdateTiming = nodeArray.UpdateTiming;
            }
        }
        return this.selectedUpdateTiming;
    };
    AppTprHierarchyComponent.prototype.setActions = function () {
        this.enableActionsForNode();
        this.setContextMenuItemsForNode();
    };
    /*This method will be called when the user clicks(left click) on any of the node item.*/
    AppTprHierarchyComponent.prototype.nodeSelect = function (event) {
        this.intSelectedNodeID = this.selectedNode.NodeId;
        // this.getSelectedNodeDetails();
        this.setActions();
    };
    /*This method will be called when the user clicks (right click) on any of the node item.*/
    AppTprHierarchyComponent.prototype.nodeContextMenuSelect = function (event) {
        // this.isRequesting = true; //EH
        console.log("is requesting value is", this.isRequesting);
        this.items.forEach(function (item) {
            //item.disabled = false; //EH
            item.disabled = true; //EH 
        });
        this.actionItemsForNode.forEach(function (action) {
            if (action.label == "Add Child" || action.label == "Edit Node" || action.label == "Remove Node" || action.label == "Enter Value" ||
                action.label == "Move Node") {
                action.disabled = true;
            }
        }); //EH
        this.intSelectedNodeID = this.selectedNode.NodeId;
        this.setActions();
        // this.getSelectedNodeDetails();
    };
    // setNodeLevelData(data: any) {
    //     this.selectedNodeDetails = data.Result;
    //     this.enableActionsForNode();
    //     this.setContextMenuItemsForNode();
    // }
    AppTprHierarchyComponent.prototype.filterNodes = function (event) {
        this.filteredSearchNodeResults = [];
        for (var i = 0; i < this.searchNodeResults.length; i++) {
            var node = this.searchNodeResults[i];
            if (node.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
                this.filteredSearchNodeResults.push(node);
            }
        }
    };
    AppTprHierarchyComponent.prototype.handleFilterNodeDropdownClick = function (event) {
        this.filteredSearchNodeResults = [];
        this.filteredSearchNodeResults = this.searchNodeResults;
    };
    AppTprHierarchyComponent.prototype.OnNodeSearch = function () {
        var _this = this;
        console.log("search Node ->", this.strSearchNodeText);
        if (this.strSearchNodeText != null && this.strSearchNodeText.trim().length > 0) {
            this.isRequesting = true;
            this.traversedPathArray = [];
            var nodeSearched = this.nodeArrays.find(function (node) { return node.NodeName.toUpperCase() == _this.strSearchNodeText.toUpperCase(); });
            if (nodeSearched) {
                this.intSelectedNodeID = nodeSearched.NodeId;
                this.appendToTraversedArray(nodeSearched.Id, nodeSearched.ParentId);
                this.mainListOfTreeForDisplay.forEach(function (node) { return _this.expandRecursiveForSearch(node, true); });
                // this.getSelectedNodeDetails();
                this.setActions();
            }
            else if (this.inactiveNodes.some(function (node) { return node == _this.strSearchNodeText.toUpperCase(); }) && !this.blnShowInactiveNodes) {
                console.log('Inactive Node found!');
                this.updateHierarchyHeader = 'Inactive Node!';
                this.updateHierarchyMessage = "The searched Node - " + this.strSearchNodeText + " is inactive. Please enable 'Show Inactive Nodes'.";
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
            else {
                console.log('Node not found!');
                this.updateHierarchyHeader = 'Node not found!';
                this.updateHierarchyMessage = "Node - " + this.strSearchNodeText + " is not found.";
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
        }
    };
    AppTprHierarchyComponent.prototype.OnLastEditedNodeFind = function () {
        var _this = this;
        this.isRequesting = true;
        this.traversedPathArray = [];
        var nodeSearched = this.nodeArrays.find(function (node) { return node.NodeName.toUpperCase() == _this.lastSelectedNode.toUpperCase(); });
        if (nodeSearched) {
            this.intSelectedNodeID = nodeSearched.NodeId;
            this.appendToTraversedArray(nodeSearched.Id, nodeSearched.ParentId);
            this.mainListOfTreeForDisplay.forEach(function (node) { return _this.expandRecursiveForLastEditedNodeSearch(node, true); });
            // this.getSelectedNodeDetails();
            this.setActions();
        }
        else if (this.inactiveNodes.some(function (node) { return node == _this.lastSelectedNode.toUpperCase(); }) && !this.blnShowInactiveNodes) {
            console.log('Inactive Node found!');
            this.updateHierarchyHeader = 'Inactive Node!';
            this.updateHierarchyMessage = "The searched Node - " + this.lastSelectedNode + " is inactive. Please enable 'Show Inactive Nodes'.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            this.stopRefreshing();
        }
        else {
            this.updateHierarchyFlag = true;
            this.updateHierarchyHeader = "Search Results";
            this.updateHierarchyMessage = "The node - " + this.lastSelectedNode + " is not found.";
            this.showUpdateHierarchyFooter = false;
            this.stopRefreshing();
        }
    };
    AppTprHierarchyComponent.prototype.OnFavouriteNodeSelect = function () {
        var _this = this;
        this.isRequesting = true;
        this.traversedPathArray = [];
        if (this.strFavouriteNodeSelect) {
            var nodeSearched = this.nodeArrays.find(function (node) { return node.NodeName.toUpperCase() == _this.strFavouriteNodeSelect.toUpperCase(); });
            if (nodeSearched) {
                this.intSelectedNodeID = nodeSearched.NodeId;
                this.appendToTraversedArray(nodeSearched.Id, nodeSearched.ParentId);
                this.mainListOfTreeForDisplay.forEach(function (node) { return _this.expandRecursiveForFavouriteNodeSearch(node, true); });
                // this.getSelectedNodeDetails();
                this.setActions();
            }
            else if (this.inactiveNodes.some(function (node) { return node == _this.strFavouriteNodeSelect.toUpperCase(); }) && !this.blnShowInactiveNodes) {
                console.log('Inactive Node found!');
                this.updateHierarchyHeader = 'Inactive Node!';
                this.updateHierarchyMessage = "The searched Node - " + this.strFavouriteNodeSelect + " is inactive. Please enable 'Show Inactive Nodes'.";
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
            else {
                this.updateHierarchyFlag = true;
                this.updateHierarchyHeader = "Search Results";
                this.updateHierarchyMessage = "The node - " + this.strFavouriteNodeSelect + " is not found.";
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
        }
    };
    AppTprHierarchyComponent.prototype.appendToTraversedArray = function (Id, parentId) {
        this.traversedPathArray.push(Id);
        var parentNode = this.nodeArrays.find(function (node) { return node.Id == parentId; });
        if (parentNode) {
            this.appendToTraversedArray(parentNode.Id, parentNode.ParentId);
        }
    };
    AppTprHierarchyComponent.prototype.appendToTraversedArrayForNodeRemoval = function (Id, parentId) {
        this.traversedPathArrayForNodeRemoval.push(Id);
        var parentNode = this.nodeArrays.find(function (node) { return node.Id == parentId; });
        if (parentNode) {
            this.appendToTraversedArrayForNodeRemoval(parentNode.Id, parentNode.ParentId);
        }
    };
    AppTprHierarchyComponent.prototype.CheckIfParentAndChild = function (targetNodeId) {
        if (targetNodeId > 0) {
            var childNode = this.nodeArrays.find(function (node) { return node.Id == targetNodeId; });
            if (childNode && childNode.ParentId != null && !this.isParent && childNode.ParentId == this.moveNode.Id) {
                this.isParent = true;
            }
            else {
                this.CheckIfParentAndChild(childNode.ParentId);
            }
        }
    };
    AppTprHierarchyComponent.prototype.OnClearNodeSearch = function () {
        this.strSearchNodeText = '';
    };
    AppTprHierarchyComponent.prototype.addChildSelectedContextMenu = function (SelectedFile) {
        this.lastSelectedNode = SelectedFile.NodeName;
        this.OnFavouriteNodeSave();
        this.router.navigate(['/hierarchy/addChild', this.intSelectedNodeID]);
    };
    AppTprHierarchyComponent.prototype.editChildSelectedContextMenu = function (SelectedFile) {
        this.lastSelectedNode = SelectedFile.NodeName;
        this.OnFavouriteNodeSave();
        this.router.navigate(['/hierarchy/editNode', this.intSelectedNodeID]);
    };
    AppTprHierarchyComponent.prototype.enterValueSelectedContextMenu = function (SelectedFile) {
        this.lastSelectedNode = SelectedFile.NodeName;
        this.OnFavouriteNodeSave();
        this.router.navigate(['/hierarchy/enterValue', this.intSelectedNodeID]);
    };
    AppTprHierarchyComponent.prototype.moveNodeSelectedContextMenu = function (SelectedFile) {
        var _this = this;
        console.log("Begin Moving");
        this.moveNode = SelectedFile;
        console.log("moveNodeSelectedContextMenu->", this.moveNode);
        this.items.push({ label: 'Drop Node', command: function (event) { return _this.dropNodeSelectedContextMenu(_this.selectedNode); } });
        this.actionItemsForNode.push({ label: 'Drop Node', command: function (event) { return _this.dropNodeSelectedContextMenu(_this.selectedNode); } });
        var moveMenuitem = this.items.find(function (x) { return x.label == "Move Node"; });
        this.items.splice(this.items.indexOf(moveMenuitem), 1);
        moveMenuitem = this.actionItemsForNode.find(function (x) { return x.label == "Move Node"; });
        this.actionItemsForNode.splice(this.actionItemsForNode.indexOf(moveMenuitem), 1);
        this.isNodeMoved = true;
        this.infoMoveNode = [];
        this.infoMoveNode.push({ severity: 'info', summary: 'Info Message', detail: "Moving Node: " + this.moveNode.NodeName + ". Select a drop target or use 'Cancel Move' button to cancel the move." });
        this.updateHierarchyFlag = false;
    };
    AppTprHierarchyComponent.prototype.cancelNodeMove = function () {
        var _this = this;
        console.log("Cancel Moving");
        this.infoMoveNode = [];
        this.infoMoveNode.push({ severity: 'info', summary: 'Info Message', detail: "Moving Node: " + this.moveNode.NodeName + " is cancelled." });
        this.moveNode = this.selectedNode;
        var dropMenuitem = this.items.find(function (x) { return x.label == "Drop Node"; });
        this.items.splice(this.items.indexOf(dropMenuitem), 1);
        this.items.push({ label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } });
        dropMenuitem = this.actionItemsForNode.find(function (x) { return x.label == "Drop Node"; });
        this.actionItemsForNode.splice(this.actionItemsForNode.indexOf(dropMenuitem), 1);
        this.actionItemsForNode.push({ label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } });
        this.isNodeMoved = false;
        this.updateHierarchyFlag = false;
        this.updateHierarchyMessage = null;
        this.updateHierarchyHeader = null;
        this.showUpdateHierarchyFooter = false;
    };
    AppTprHierarchyComponent.prototype.updateMoveNodeFromMainTree = function (tempNode) {
        var _this = this;
        if (tempNode) {
            if (tempNode.Id == this.moveNode.Id) {
                console.log("Move Node is updated");
                this.moveNode = tempNode;
            }
            else if (tempNode.Id == this.targetNode.Id) {
                console.log("Target Node is updated");
                this.targetNode = tempNode;
            }
            else if (tempNode.children) {
                tempNode.children.forEach(function (childNode) {
                    _this.updateMoveNodeFromMainTree(childNode);
                });
            }
        }
    };
    AppTprHierarchyComponent.prototype.getChildrenWithPlans = function (selectedNode) {
        var _this = this;
        if (selectedNode.Id > 0) {
            if (selectedNode.children) {
                selectedNode.Children.forEach(function (childNode) {
                    if (_this.moveNodeArrays.indexOf(childNode.NodeName) == -1 && childNode.HasPlans) {
                        _this.moveNodeArrays.push(childNode.NodeName);
                    }
                    _this.getChildrenWithPlans(childNode);
                });
            }
        }
    };
    AppTprHierarchyComponent.prototype.getAncestorWithPlans = function (selectedNode) {
        var currentLevel = selectedNode.Level;
        var newParent = selectedNode.ParentId;
        do {
            var parentNode = this.nodeArrays.find(function (node) { return node.Id == newParent; });
            if (parentNode) {
                if (this.moveNodeArrays.indexOf(parentNode.NodeName) == -1 && parentNode.HasPlans) {
                    this.moveNodeArrays.push(parentNode.NodeName);
                }
                newParent = parentNode.ParentId;
            }
            currentLevel--;
        } while (currentLevel > 0);
    };
    AppTprHierarchyComponent.prototype.getNodesWithPlans = function (selectedNode) {
        this.getChildrenWithPlans(selectedNode);
        this.getAncestorWithPlans(selectedNode);
    };
    AppTprHierarchyComponent.prototype.validateAndDrop = function (targetNode) {
        console.log("Begin Validation");
        var result = true;
        if (targetNode.IsPnlHolder) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + this.moveNode.NodeName + " cannot be moved to node " + targetNode.NodeName + " because the target node is a PNL holder.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }
        if (this.moveNode.ParentId == targetNode.Id) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + targetNode.NodeName + " is already a parent for the node " + this.moveNode.NodeName;
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }
        console.log("parentID->", this.selectedNode.ParentId);
        if (this.selectedNode.ParentId == 0) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + this.moveNode.NodeName + " cannot be moved to the root node.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }
        this.isParent = false;
        this.CheckIfParentAndChild(targetNode.Id);
        if (this.isParent) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + this.moveNode.NodeName + " cannot be moved to node " + targetNode.NodeName + " because the target node is it's child.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }
        return result;
    };
    AppTprHierarchyComponent.prototype.GetUpdateTimingAncestor = function (targetNodeId) {
        var nodeArray;
        nodeArray = this.nodeArrays.find(function (node) { return node.Id == targetNodeId; });
        if (nodeArray && this.targetUpdateTimingAncestor == null) {
            if (!nodeArray.UpdateTiming) {
                this.GetUpdateTimingAncestor(nodeArray.ParentId);
            }
            else {
                this.targetUpdateTimingAncestor = nodeArray;
            }
        }
    };
    AppTprHierarchyComponent.prototype.dropNodeSelectedContextMenu = function (SelectedFile) {
        var _this = this;
        console.log("Begin Drop");
        this.moveNodeArrays = [];
        this.targetNode = SelectedFile;
        console.log("Update Move Node from Main Tree");
        this.mainListOfTree.forEach(function (node) {
            _this.updateMoveNodeFromMainTree(node);
        });
        var result = this.validateAndDrop(this.targetNode);
        console.log("Validation Result ->", result);
        /* if (result == true && SelectedFile.ParentId != null && this.moveNode.ParentId != null) {*/
        if (result == true) {
            this.isNodeMoved = false;
            if (this.moveNodeArrays.indexOf(this.moveNode.NodeName) == -1 && this.moveNode.HasPlans) {
                this.moveNodeArrays.push(this.moveNode.NodeName);
            }
            this.getNodesWithPlans(this.moveNode);
            if (this.moveNodeArrays.indexOf(this.targetNode.NodeName) == -1 && this.targetNode.HasPlans) {
                this.moveNodeArrays.push(SelectedFile.NodeName);
            }
            this.getNodesWithPlans(this.targetNode);
            console.log("dropNodeSelectedContextMenu->", this.targetNode);
            var dropMenuitem = this.items.find(function (x) { return x.label == "Drop Node"; });
            this.items.splice(this.items.indexOf(dropMenuitem), 1);
            this.items.push({ label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } });
            dropMenuitem = this.actionItemsForNode.find(function (x) { return x.label == "Drop Node"; });
            this.actionItemsForNode.splice(this.actionItemsForNode.indexOf(dropMenuitem), 1);
            this.actionItemsForNode.push({ label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } });
            console.log("Plan Nodes ->", this.moveNodeArrays);
            this.targetUpdateTimingAncestor = null;
            this.GetUpdateTimingAncestor(this.targetNode.Id);
            console.log("targetUpdateTimingAncestor->", this.targetUpdateTimingAncestor);
            var moveInfo_1 = "The node " + this.moveNode.NodeName + " will be moved to node " + this.targetNode.NodeName + ".";
            if (this.moveNodeArrays.length > 0) {
                moveInfo_1 = (moveInfo_1 + "\n" + "The target node or the branch contains plan values. The node you are moving also contains a plan. This will cause the plans to overlap. Are you happy to proceed with this move? The following node(s) contain plan values: ");
                this.moveNodeArrays.forEach(function (planNode) {
                    moveInfo_1 = (moveInfo_1 + "\n" + planNode);
                });
            }
            moveInfo_1 = (this.targetNode.UpdateTiming != null || this.targetUpdateTimingAncestor.UpdateTiming != null) ?
                (moveInfo_1 + "\n" + "Please note that by moving this node in the hierarchy, you will change the Update Timing of all children of the parent, overwriting any Update Timing that has previously been set." +
                    "The Update Timing is used to tell TPR for which Trading Dates data in relation to the Reporting Date to expect.")
                : moveInfo_1;
            moveInfo_1 = moveInfo_1 + "\n" + "Saving an update to hierarchy. Would you like to proceed?";
            this.updateHierarchyMessage = moveInfo_1.toString();
            this.updateHierarchyHeader = "Updating Hierarchy";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = true;
        }
        else {
        }
    };
    AppTprHierarchyComponent.prototype.commitDropNodeAtTarget = function () {
        var _this = this;
        this.mainListOfTree.forEach(function (node) { return _this.updateArrayForNodeDrop(node); });
        this.mainListOfTree.forEach(function (node) { return _this.preparePostTreeData(node); });
        this.updateHierarchyMessage = "Moving node " + this.moveNode.NodeName + " to " + this.targetNode.NodeName + "...";
        this.showUpdateHierarchyFooter = false;
        console.log("Updated Hierarchy ->", this.mainListOfTree);
        var objclsHierarchyRemoveNode_Post = new clsHierarchyRemoveNode_Post();
        objclsHierarchyRemoveNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightHierarchyInstanceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        console.log("mainListOfTree ->", this.mainListOfTree);
        objclsHierarchyRemoveNode_Post.Children = this.mainListOfTree;
        objclsHierarchyRemoveNode_Post.NodeNames = this.searchNodeResults;
        objclsHierarchyRemoveNode_Post.Type = this.mainNodeType;
        objclsHierarchyRemoveNode_Post.StartDate = this.mainNodeStartDate;
        objclsHierarchyRemoveNode_Post.Id = this.mainNodeId;
        var postData = CircularJSON.stringify(objclsHierarchyRemoveNode_Post);
        this.tPRHierarchyservice.updateLightWeight(postData)
            .subscribe(function (response) {
            console.log(response);
            if (response.Error) {
                _this.updateHierarchyHeader = 'Error';
                _this.updateHierarchyMessage = response.Error;
                _this.updateHierarchyFlag = true;
                _this.showUpdateHierarchyFooter = false;
                _this.stopRefreshing();
            }
            else {
                console.log('Node ' + _this.moveNode.NodeName + ' is moved successfully to ' + _this.targetNode.NodeName);
                _this.loadTree();
                _this.updateHierarchyHeader = 'Success';
                _this.updateHierarchyMessage = 'Node ' + _this.moveNode.NodeName + ' is moved successfully to ' + _this.targetNode.NodeName;
                _this.updateHierarchyFlag = true;
                _this.isNodeMoved = false;
                console.log("Node Array->", _this.nodeArrays);
            }
        }, function (error) {
            console.log(error);
            _this.updateHierarchyHeader = 'Error';
            _this.updateHierarchyMessage = error;
            _this.updateHierarchyFlag = true;
            _this.showUpdateHierarchyFooter = false;
            _this.isNodeMoved = false;
            _this.stopRefreshing();
        });
    };
    AppTprHierarchyComponent.prototype.addToFavouritesSelectedContextMenu = function (SelectedFile) {
        console.log(SelectedFile);
        var index = this.favouriteNodesArray.indexOf(SelectedFile.NodeName);
        if (index == -1) {
            this.favouriteNodesArray.push(SelectedFile.NodeName);
        }
        this.OnFavouriteNodeSave();
    };
    AppTprHierarchyComponent.prototype.commitRemoveNode = function () {
        var _this = this;
        var nodeTobeRemoved = this.selectedNode.NodeName;
        console.log("Removing Node ->", this.selectedNode);
        this.mainListOfTree.forEach(function (node) { return _this.updateArrayForNodeRemoval(node); });
        console.log("Updated Hierarchy ->", this.mainListOfTree);
        this.updateHierarchyMessage = "Updating Hierarchy...";
        this.showUpdateHierarchyFooter = false;
        var objclsHierarchyRemoveNode_Post = new clsHierarchyRemoveNode_Post();
        objclsHierarchyRemoveNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightHierarchyInstanceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        console.log("mainListOfTree ->", this.mainListOfTree);
        objclsHierarchyRemoveNode_Post.Children = this.mainListOfTree;
        objclsHierarchyRemoveNode_Post.NodeNames = this.searchNodeResults;
        objclsHierarchyRemoveNode_Post.Type = this.mainNodeType;
        objclsHierarchyRemoveNode_Post.StartDate = this.mainNodeStartDate;
        objclsHierarchyRemoveNode_Post.Id = this.mainNodeId;
        var postData = CircularJSON.stringify(objclsHierarchyRemoveNode_Post);
        console.log("Post Data ->", postData);
        this.tPRHierarchyservice.updateLightWeight(postData)
            .subscribe(function (response) {
            console.log(response);
            if (response.Error) {
                _this.updateHierarchyHeader = 'Error';
                _this.updateHierarchyMessage = response.Error;
                _this.updateHierarchyFlag = true;
                _this.showUpdateHierarchyFooter = false;
                _this.stopRefreshing();
            }
            else {
                console.log("The node " + nodeTobeRemoved + " is deleted successfully");
                _this.loadTree();
                _this.lastSelectedNode = null;
                _this.OnFavouriteNodeSave();
                _this.updateHierarchyHeader = 'Success';
                _this.updateHierarchyMessage = "The node " + nodeTobeRemoved + " is deleted successfully";
                _this.updateHierarchyFlag = true;
                _this.showUpdateHierarchyFooter = false;
            }
        }, function (error) {
            console.log(error);
            _this.updateHierarchyHeader = 'Error';
            _this.updateHierarchyMessage = error;
            _this.updateHierarchyFlag = true;
            _this.showUpdateHierarchyFooter = false;
            _this.stopRefreshing();
        });
    };
    AppTprHierarchyComponent.prototype.cancelNodeReMove = function () {
        console.log("Cancel Removing");
        this.updateHierarchyFlag = false;
        this.updateHierarchyMessage = null;
        this.updateHierarchyHeader = null;
        this.showUpdateHierarchyFooter = false;
    };
    AppTprHierarchyComponent.prototype.removeNodeSelectedContextMenu = function (SelectedFile) {
        this.updateHierarchyFlag = true;
        this.updateHierarchyHeader = "Removing Node";
        this.updateHierarchyMessage = "The node " + SelectedFile.NodeName + " will be deleted. Are you sure?";
        this.showUpdateHierarchyFooter = true;
    };
    AppTprHierarchyComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppTprHierarchyComponent.prototype.updateHierarchy = function () {
        console.log("updateHierarchy");
        this.isRequesting = true;
        if (this.updateHierarchyHeader == "Removing Node") {
            this.commitRemoveNode();
        }
        else if (this.updateHierarchyHeader == "Updating Hierarchy") {
            this.commitDropNodeAtTarget();
        }
    };
    AppTprHierarchyComponent.prototype.CancelUpdateHierarchy = function () {
        console.log("CancelUpdateHierarchy");
        if (this.updateHierarchyHeader == "Removing Node") {
            this.cancelNodeReMove();
        }
        else if (this.updateHierarchyHeader == "Updating Hierarchy") {
            this.cancelNodeMove();
        }
    };
    AppTprHierarchyComponent.prototype.updateArrayForNodeRemoval = function (filteredNode) {
        var _this = this;
        filteredNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        if (filteredNode.Id == this.selectedNode.ParentId) {
            filteredNode.Children.splice(filteredNode.Children.indexOf(this.selectedNode), 1);
        }
        delete filteredNode.children;
        delete filteredNode.parent;
        if (filteredNode.Children) {
            filteredNode.Children.forEach(function (childNode) {
                _this.updateArrayForNodeRemoval(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.preparePostTreeData = function (node) {
        var _this = this;
        delete node.children;
        delete node.parent;
        if (node.Children) {
            node.Children.forEach(function (childNode) {
                _this.preparePostTreeData(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.updateArrayForNodeDrop = function (filteredNode) {
        var _this = this;
        filteredNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        if (filteredNode.Id == this.moveNode.ParentId) {
            delete this.moveNode.children;
            delete this.moveNode.parent;
            filteredNode.Children.splice(filteredNode.Children.indexOf(this.moveNode), 1);
            this.moveNode.ParentId = this.targetNode.Id;
            this.targetNode.Children.push(this.moveNode);
        }
        delete filteredNode.children;
        delete filteredNode.parent;
        if (filteredNode.Children) {
            filteredNode.Children.forEach(function (childNode) {
                _this.updateArrayForNodeDrop(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.updateProperties = function (filteredNode) {
        var array = filteredNode.Children;
        if (array.$values.length > 0) {
            var obj = JSON.parse(JSON.stringify(filteredNode));
            delete obj.Children;
            obj.Children = array.$values;
            console.log(obj);
        }
    };
    AppTprHierarchyComponent.prototype.onRowSelectForFavouriteNode = function (event) {
        this.strFavouriteNodeSelect = event.data;
        this.OnFavouriteNodeSelect();
    };
    AppTprHierarchyComponent.prototype.deleteFavouriteNode = function (favouriteNode) {
        this.favouriteNodesArray.splice(this.favouriteNodesArray.indexOf(favouriteNode), 1);
    };
    AppTprHierarchyComponent.prototype.OnFavouriteNodeSave = function () {
        var _this = this;
        var objclsFavourateNode_Post = new clsFavourateNode_Post();
        objclsFavourateNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.UserPreferencesDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        objclsFavourateNode_Post.UserName = this.userName;
        objclsFavourateNode_Post.LastSelectedNode = this.lastSelectedNode;
        objclsFavourateNode_Post.Favourites = this.favouriteNodesArray;
        this.tPRHierarchyservice.updateUserPreferences(objclsFavourateNode_Post)
            .subscribe(function (response) {
            console.log(response);
            if (response.Error) {
                alert(response.Error);
            }
        }, function (error) {
            console.log(error);
            _this.updateHierarchyHeader = 'Error';
            _this.updateHierarchyMessage = error;
            _this.updateHierarchyFlag = true;
            _this.showUpdateHierarchyFooter = false;
        });
    };
    AppTprHierarchyComponent.prototype.enableActionsForNode = function () {
        var that = this;
        this.actionItemsForNode.forEach(function (item, index) {
            item.disabled = true;
            if (item.label == "Add Child" && that.canEditHierarchy) {
                if (!that.selectedNode.IsPnlHolder && that.selectedNode.Level < 13) {
                    item.disabled = false;
                }
            }
            else if (item.label == "Remove Node" && that.canEditHierarchy) {
                // if (!that.selectedNodeDetails.Node.HasPnl
                //     && !that.selectedNodeDetails.Node.HasMVaR
                //     && that.selectedNodeDetails.Node.CanRemove
                //     && that.selectedNodeDetails.ParentId != 0
                //     && that.selectedNode.Children.length == 0) {
                //     item.disabled = false;
                // }  
                if (!that.selectedNode.HasAnyOutputData
                    && that.selectedNode.ParentId != 0
                    && that.selectedNode.Children.length == 0) {
                    item.disabled = false;
                }
                else {
                    item.disabled = true;
                }
            }
            else if (item.label == "Move Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Drop Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Edit Node") {
                item.disabled = !that.canEditNode;
            }
            else if (item.label == "Enter Value") {
                item.disabled = !that.canEnterValue;
            }
            else if (item.label == "Add To Favourites"
                && !that.favouriteNodesArray.some(function (x) { return x == that.selectedNode.NodeName; })) {
                item.disabled = false;
            }
        });
        console.log("Check if node is moved ->", this.isNodeMoved);
        if (this.isNodeMoved) {
            this.actionItemsForNode.forEach(function (item, index) {
                if (!(item.label == "Drop Node" || item.label == "Add To Favourites")) {
                    item.disabled = true;
                }
            });
        }
        this.stopRefreshing(); //EH
    };
    AppTprHierarchyComponent.prototype.setContextMenuItemsForNode = function () {
        var that = this;
        this.items.forEach(function (item, index) {
            item.disabled = true;
            if (item.label == "Add Child" && that.canEditHierarchy) {
                if (!that.selectedNode.IsPnlHolder && that.selectedNode.Level < 13) {
                    item.disabled = false;
                }
            }
            else if (item.label == "Remove Node" && that.canEditHierarchy) {
                // if (!that.selectedNodeDetails.Node.HasPnl
                //     && !that.selectedNodeDetails.Node.HasMVaR
                //     && that.selectedNodeDetails.Node.CanRemove
                //     && that.selectedNodeDetails.ParentId != 0
                //     && that.selectedNode.Children.length == 0) {
                //     item.disabled = false;
                // }
                if (!that.selectedNode.HasAnyOutputData
                    && that.selectedNode.ParentId != 0
                    && that.selectedNode.Children.length == 0) {
                    item.disabled = false;
                }
                else {
                    item.disabled = true;
                }
            }
            else if (item.label == "Move Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Drop Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Edit Node") {
                item.disabled = !that.canEditNode;
            }
            else if (item.label == "Enter Value") {
                item.disabled = !that.canEnterValue;
            }
            else if (item.label == "Add To Favourites"
                && !that.favouriteNodesArray.some(function (x) { return x == that.selectedNode.NodeName; })) {
                item.disabled = false;
            }
        });
        console.log("Check if node is moved ->", this.isNodeMoved);
        if (this.isNodeMoved) {
            this.items.forEach(function (item, index) {
                if (!(item.label == "Drop Node" || item.label == "Add To Favourites")) {
                    item.disabled = true;
                }
            });
        }
    };
    AppTprHierarchyComponent = __decorate([
        core_1.Component({
            selector: 'treeView',
            templateUrl: 'app/components/treeView/app.treeView.component.html'
        }),
        core_1.Injectable(), 
        __metadata('design:paramtypes', [app_TPRHierarchyservice_1.TPRHierarchyservice, router_1.Router, app_serviceHelper_1.ServiceHelper, primeng_1.ConfirmationService, app_workDayService_1.WorkDayService, app_TPRCommonService_1.TPRCommonService])
    ], AppTprHierarchyComponent);
    return AppTprHierarchyComponent;
}());
exports.AppTprHierarchyComponent = AppTprHierarchyComponent;
var RootValue = (function () {
    function RootValue(label, NodeName, id, children, Children, data, icon, expandedIcon, collapsedIcon, leaf, expanded, type, parent, partialSelected, $type, HasAnyOutputData, HasPlans, UpdateTiming, NodeId, NodeType, IsActive, Level, ParentId, IsPnlHolder, MVarUpdateTiming, SplitType, Id) {
        if (label === void 0) { label = null; }
        if (NodeName === void 0) { NodeName = null; }
        if (id === void 0) { id = null; }
        if (children === void 0) { children = null; }
        if (Children === void 0) { Children = null; }
        if (data === void 0) { data = null; }
        if (icon === void 0) { icon = null; }
        if (expandedIcon === void 0) { expandedIcon = null; }
        if (collapsedIcon === void 0) { collapsedIcon = null; }
        if (leaf === void 0) { leaf = null; }
        if (expanded === void 0) { expanded = null; }
        if (type === void 0) { type = null; }
        if (parent === void 0) { parent = null; }
        if (partialSelected === void 0) { partialSelected = null; }
        if ($type === void 0) { $type = null; }
        if (HasAnyOutputData === void 0) { HasAnyOutputData = null; }
        if (HasPlans === void 0) { HasPlans = null; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (NodeId === void 0) { NodeId = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsActive === void 0) { IsActive = null; }
        if (Level === void 0) { Level = null; }
        if (ParentId === void 0) { ParentId = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Id === void 0) { Id = null; }
        this.label = label;
        this.NodeName = NodeName;
        this.id = id;
        this.children = children;
        this.Children = Children;
        this.data = data;
        this.icon = icon;
        this.expandedIcon = expandedIcon;
        this.collapsedIcon = collapsedIcon;
        this.leaf = leaf;
        this.expanded = expanded;
        this.type = type;
        this.parent = parent;
        this.partialSelected = partialSelected;
        this.$type = $type;
        this.HasAnyOutputData = HasAnyOutputData;
        this.HasPlans = HasPlans;
        this.UpdateTiming = UpdateTiming;
        this.NodeId = NodeId;
        this.NodeType = NodeType;
        this.IsActive = IsActive;
        this.Level = Level;
        this.ParentId = ParentId;
        this.IsPnlHolder = IsPnlHolder;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.SplitType = SplitType;
        this.Id = Id;
    }
    return RootValue;
}());
var clsHierarchyRemoveNode_Post = (function () {
    function clsHierarchyRemoveNode_Post($type, Children, NodeNames, Type, StartDate, EndDate, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Children === void 0) { Children = []; }
        if (NodeNames === void 0) { NodeNames = []; }
        if (Type === void 0) { Type = null; }
        if (StartDate === void 0) { StartDate = null; }
        if (EndDate === void 0) { EndDate = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Children = Children;
        this.NodeNames = NodeNames;
        this.Type = Type;
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyRemoveNode_Post;
}());
var clsTransposedRootObject = (function () {
    function clsTransposedRootObject($type, Children, HasAnyOutputData, HasPlans, UpdateTiming, NodeName, NodeId, NodeType, IsActive, Level, ParentId, IsPnlHolder, MVarUpdateTiming, SplitType, Id) {
        if ($type === void 0) { $type = null; }
        if (Children === void 0) { Children = []; }
        if (HasAnyOutputData === void 0) { HasAnyOutputData = false; }
        if (HasPlans === void 0) { HasPlans = false; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (NodeName === void 0) { NodeName = null; }
        if (NodeId === void 0) { NodeId = 0; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsActive === void 0) { IsActive = false; }
        if (Level === void 0) { Level = 0; }
        if (ParentId === void 0) { ParentId = 0; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Children = Children;
        this.HasAnyOutputData = HasAnyOutputData;
        this.HasPlans = HasPlans;
        this.UpdateTiming = UpdateTiming;
        this.NodeName = NodeName;
        this.NodeId = NodeId;
        this.NodeType = NodeType;
        this.IsActive = IsActive;
        this.Level = Level;
        this.ParentId = ParentId;
        this.IsPnlHolder = IsPnlHolder;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.SplitType = SplitType;
        this.Id = Id;
    }
    return clsTransposedRootObject;
}());
var clsFavourateNode_Post = (function () {
    function clsFavourateNode_Post($type, UserName, LastSelectedNode, Favourites, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (UserName === void 0) { UserName = null; }
        if (LastSelectedNode === void 0) { LastSelectedNode = null; }
        if (Favourites === void 0) { Favourites = []; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.UserName = UserName;
        this.LastSelectedNode = LastSelectedNode;
        this.Favourites = Favourites;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsFavourateNode_Post;
}());
var clsHierarchyEditNode = (function () {
    function clsHierarchyEditNode($type, AlertGroups, BusinessSegmentAllocations, Created, CreatedBy, DividendPartnerAllocations, HasChildren, HierarchyInstanceId, Id, IsMarkedForDeletion, LastUpdatedBy, Level, MVarLimit, MVarRegion, MVarTemporaryLimit, MVarTemporaryLimitExpiryDate, MVarUpdateTiming, Node, NodeType, ParentId, ParentNodeId, Plans, PnlSplitValue, RegionalAllocations, SplitType, Tags, Updated, UpdatedBy, UpdateTiming, WorkingCapitalRegion) {
        if ($type === void 0) { $type = null; }
        if (AlertGroups === void 0) { AlertGroups = null; }
        if (BusinessSegmentAllocations === void 0) { BusinessSegmentAllocations = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (DividendPartnerAllocations === void 0) { DividendPartnerAllocations = ''; }
        if (HasChildren === void 0) { HasChildren = false; }
        if (HierarchyInstanceId === void 0) { HierarchyInstanceId = 0; }
        if (Id === void 0) { Id = 0; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (LastUpdatedBy === void 0) { LastUpdatedBy = null; }
        if (Level === void 0) { Level = 0; }
        if (MVarLimit === void 0) { MVarLimit = null; }
        if (MVarRegion === void 0) { MVarRegion = null; }
        if (MVarTemporaryLimit === void 0) { MVarTemporaryLimit = null; }
        if (MVarTemporaryLimitExpiryDate === void 0) { MVarTemporaryLimitExpiryDate = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (Node === void 0) { Node = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (ParentId === void 0) { ParentId = 0; }
        if (ParentNodeId === void 0) { ParentNodeId = 0; }
        if (Plans === void 0) { Plans = null; }
        if (PnlSplitValue === void 0) { PnlSplitValue = null; }
        if (RegionalAllocations === void 0) { RegionalAllocations = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Tags === void 0) { Tags = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (WorkingCapitalRegion === void 0) { WorkingCapitalRegion = null; }
        this.$type = $type;
        this.AlertGroups = AlertGroups;
        this.BusinessSegmentAllocations = BusinessSegmentAllocations;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.DividendPartnerAllocations = DividendPartnerAllocations;
        this.HasChildren = HasChildren;
        this.HierarchyInstanceId = HierarchyInstanceId;
        this.Id = Id;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.LastUpdatedBy = LastUpdatedBy;
        this.Level = Level;
        this.MVarLimit = MVarLimit;
        this.MVarRegion = MVarRegion;
        this.MVarTemporaryLimit = MVarTemporaryLimit;
        this.MVarTemporaryLimitExpiryDate = MVarTemporaryLimitExpiryDate;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.Node = Node;
        this.NodeType = NodeType;
        this.ParentId = ParentId;
        this.ParentNodeId = ParentNodeId;
        this.Plans = Plans;
        this.PnlSplitValue = PnlSplitValue;
        this.RegionalAllocations = RegionalAllocations;
        this.SplitType = SplitType;
        this.Tags = Tags;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.UpdateTiming = UpdateTiming;
        this.WorkingCapitalRegion = WorkingCapitalRegion;
    }
    return clsHierarchyEditNode;
}());
var clsHierarchyEditNode_Node = (function () {
    function clsHierarchyEditNode_Node($type, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = null; }
        if (OutputData === void 0) { OutputData = null; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = null; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = null; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = null; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = null; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node;
}());
var UserRolesValues = (function () {
    function UserRolesValues($values) {
        if ($values === void 0) { $values = null; }
        this.$values = $values;
    }
    return UserRolesValues;
}());
var UserRolesValue = (function () {
    function UserRolesValue(Name, Users) {
        if (Name === void 0) { Name = null; }
        if (Users === void 0) { Users = null; }
        this.Name = Name;
        this.Users = Users;
    }
    return UserRolesValue;
}());
var UsersValue = (function () {
    function UsersValue(LoginName, Role) {
        if (LoginName === void 0) { LoginName = null; }
        if (Role === void 0) { Role = null; }
        this.LoginName = LoginName;
        this.Role = Role;
    }
    return UsersValue;
}());
var clsHierarchyEditNode_Node_ProfitAlertGroup_Values = (function () {
    function clsHierarchyEditNode_Node_ProfitAlertGroup_Values($type, NodeId, FormettedAlertGroups, AlertGroups) {
        if ($type === void 0) { $type = null; }
        if (NodeId === void 0) { NodeId = 0; }
        if (FormettedAlertGroups === void 0) { FormettedAlertGroups = null; }
        if (AlertGroups === void 0) { AlertGroups = null; }
        this.$type = $type;
        this.NodeId = NodeId;
        this.FormettedAlertGroups = FormettedAlertGroups;
        this.AlertGroups = AlertGroups;
    }
    return clsHierarchyEditNode_Node_ProfitAlertGroup_Values;
}());
//# sourceMappingURL=app.treeView.component.js.map