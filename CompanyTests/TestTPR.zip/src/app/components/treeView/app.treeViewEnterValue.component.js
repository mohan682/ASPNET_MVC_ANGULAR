"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
require('rxjs/add/operator/switchMap');
var primeng_1 = require('primeng/primeng');
var app_treeView_component_1 = require('../treeView/app.treeView.component');
var app_dashboardData_service_1 = require('../../service/app.dashboardData.service');
var app_TPRHierarchyservice_1 = require('../../service/app.TPRHierarchyservice');
var app_TPRNodeTypeService_1 = require('../../service/app.TPRNodeTypeService');
var app_regionService_1 = require('../../service/app.regionService');
var app_TPRProfitAlertGroupsService_1 = require('../../service/app.TPRProfitAlertGroupsService');
var app_TPRTagsService_1 = require('../../service/app.TPRTagsService');
var app_TPRDividendPartnersService_1 = require('../../service/app.TPRDividendPartnersService');
var app_TPRBusinessSegmentsService_1 = require('../../service/app.TPRBusinessSegmentsService');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var AppTprHierarchyEnterValueComponent = (function () {
    function AppTprHierarchyEnterValueComponent(tPRHierarchyservice, router, route, tPRNodeTypeService, confirmationService, regionsService, tprPAGService, tPRTagsService, tprDividendPartnersService, tprBusinessSegmentsService, tprCommonService, appTprHierarchyComponent, dashboardDataService) {
        this.tPRHierarchyservice = tPRHierarchyservice;
        this.router = router;
        this.route = route;
        this.tPRNodeTypeService = tPRNodeTypeService;
        this.confirmationService = confirmationService;
        this.regionsService = regionsService;
        this.tprPAGService = tprPAGService;
        this.tPRTagsService = tPRTagsService;
        this.tprDividendPartnersService = tprDividendPartnersService;
        this.tprBusinessSegmentsService = tprBusinessSegmentsService;
        this.tprCommonService = tprCommonService;
        this.appTprHierarchyComponent = appTprHierarchyComponent;
        this.dashboardDataService = dashboardDataService;
        this.blnShowModalPouUp = true;
        this.businessDate = '';
        this.blnEnterValueYTDShow = true;
        this.blnEnterValueDividendTrueUpShow = false;
        this.blnEnterValueMVARShow = false;
        this.blnEnterValueMVARLimitShow = false;
        this.blnEnterValueMVARTemporaryLimitShow = false;
        this.blnEnterValuePnlPPAShow = false;
        this.blnEnterValueDividendPartnerPPAShow = false;
        this.blnIsPnlHolder = false;
        this.ytdValues = [];
        this.objYTDValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.displayDialogForYTD = false;
        this.arrYTDUpdateData = [];
        this.objEnterValuePostData = new clsHierarchyNodeEnterValuePostData();
        this.blnDisableSaveValue = true;
        this.dividendTrueUp = [];
        this.selectedDividendPartnerTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
        this.lstDividendPartnerTrueUp = [];
        this.strSelectedDividendPartnerTrueUpName = "";
        this.strSelectedDividendPartnerPercentage = "0";
        this.blnEnableDividendTrueUp = false;
        this.blnHasDividendAllocations = false;
        this.objDividendPartnerTrueUpValue = new clsHierarchyEnterValue_DividendTrueUp();
        this.displayDialogForDividendTrueUp = false;
        this.arrMVarDataValues = [];
        this.selectedMVarValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objMVarValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.blnHasMVarUpdateTiming = false;
        this.displayDialogForMVar = false;
        this.arrMVarLimitDataValues = [];
        this.selectedMVarLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objMVarLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.blnHasMVarLimitUpdateTiming = false;
        this.displayDialogForMVarLimit = false;
        this.arrMVarTempLimitDataValues = [];
        this.selectedMVarTempLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objMVarTempLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.blnHasMVarTempLimitUpdateTiming = false;
        this.displayDialogForMVarTempLimit = false;
        this.blnDisableMVarTempLimitExpiryDate = true;
        this.arrPnlPPADataValues = [];
        this.selectedPnlPPAValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objPnlPPAValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.strPnlPPAMonthEndDate = "";
        this.strPnlPPAReportedMonthEndYTD = "";
        this.displayDialogForPnlPPA = false;
        this.dividendPPA = [];
        this.selectedDividendPartnerPPA = new clsHierarchyEnterValue_DividendPPA();
        this.lstDividendPartnerPPA = [];
        this.strDividendPPAMonthEndDate = "";
        this.strSelectedDividendPartnerPPAName = "";
        this.strSelectedDividendPartnerPPAPercentage = "0";
        this.strDividendPPAReportedMonthEnd = "0";
        this.blnEnableDividendPPA = false;
        this.objDividendPartnerPPAValue = new clsHierarchyEnterValue_DividendPPA();
        this.displayDialogForDividendPPA = false;
        this.strProjectedDividendPPA = "";
        this.blnShowConfirmation = false;
        this.blnShowPopUp = false;
        this.ValidationStatus = "";
        this.ValidationMessage = "";
        this.blnIsLoadComplete = false;
        this.blnBusinessDateLocked = false;
        this.strDisableDateForDeletionAndModification = "";
        this.holidays = [];
    }
    AppTprHierarchyEnterValueComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.isRequesting = true;
        // To get the selected node ID from the route service
        this.route.params.subscribe(function (params) {
            _this.intSelectedNodeID = +params['nodeId'];
        });
        this.enterValueMenuItems = [
            { label: 'YTD', icon: 'fa fa-table', command: function (event) { return _this.EnterValueYTD(); }, disabled: true },
            { label: 'Dividend True-Up', icon: 'fa fa-table', command: function (event) { return _this.EnterValueDividendTrueUp(); }, disabled: true },
            { label: 'MVAR', icon: 'fa fa-table', command: function (event) { return _this.EnterValueMVAR(); }, disabled: true },
            { label: 'MVAR Limit', icon: 'fa fa-table', command: function (event) { return _this.EnterValueMVARLimit(); }, disabled: true },
            { label: 'MVAR Temporary Limit', icon: 'fa fa-table', command: function (event) { return _this.EnterValueMVARTemporaryLimit(); }, disabled: true },
            { label: 'Pnl PPA', icon: 'fa fa-table', command: function (event) { return _this.EnterValuePnlPPA(); }, disabled: true },
            { label: 'Dividend Partner PPA', icon: 'fa fa-table', command: function (event) { return _this.EnterValueDividendPartnerPPA(); }, disabled: true },
        ];
        this.businessDate = localStorage.getItem("BusinessDate");
        if (!localStorage.getItem("PublishStatus")) {
            this.dashboardDataService.getPublishStatusObservable().subscribe(function (data) { return _this.setPublishStatus(data); });
        }
        else {
            this.publishstatus = localStorage.getItem("PublishStatus");
        }
        console.log("Publish Status ->", this.publishstatus);
        this.dashboardDataService.getLockedStatusObservable().subscribe(function (data) { return _this.setLockedStatus(data); });
        // call the service to fetch the node related data
        this.tPRHierarchyservice.getNodeLevelDataForEdit(this.intSelectedNodeID, this.businessDate)
            .subscribe(function (data) {
            _this.enterValueCompleteData = data.Result;
            console.log("enterValueCompleteData ->", _this.enterValueCompleteData);
            _this.setEnterValueMenuItems();
            if (_this.enterValueCompleteData) {
                _this.strDividendPPAReportedMonthEnd = _this.enterValueCompleteData.Node.ReportedMEYTD ? _this.enterValueCompleteData.Node.ReportedMEYTD : "";
            }
            _this.appTprHierarchyComponent.selectedUpdateTiming = null;
            _this.updateTiming = _this.appTprHierarchyComponent.getUpdateTimingFromHierarchyForNode(_this.enterValueCompleteData.Id);
            console.log("updateTiming->", _this.updateTiming);
            //debugger;
            var newDate = new Date(_this.businessDate);
            _this.minDate = newDate;
            _this.minDate = _this.appTprHierarchyComponent.getPreviousorNextWorkingDay(_this.minDate, true);
            if (_this.updateTiming == -2) {
                _this.minDate = _this.appTprHierarchyComponent.getPreviousorNextWorkingDay(_this.minDate, true);
            }
            //If not published, find the trade date. Otherwise, business date will be the next trade date
            if (_this.publishstatus === "Published" || _this.lockstatus === 1) {
                _this.strDisableDateForDeletionAndModification = _this.setDate(new Date(_this.minDate).toString());
                //localStorage.setItem("dtDisableDateForDeletion", this.tprCommonService.getFormattedSystemDate_Date(dtDisableDateForDeletionAndModification));
                _this.minDate = _this.appTprHierarchyComponent.getPreviousorNextWorkingDay(_this.minDate, false);
                console.log("strDisableDateForDeletionAndModification", _this.strDisableDateForDeletionAndModification);
                console.log(_this.minDate);
            }
            else {
                localStorage.setItem("strDisableDateForDeletionAndModification", "");
            }
            console.log("Trade Date ->", _this.minDate);
            _this.dtTradingDate = _this.minDate;
            _this.dtTradingDateDividendPartnerTrueUp = _this.minDate;
            _this.ytdValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values.filter(function (ytdValues) { return ytdValues.InputDataType == "YTD"; }) : [];
            _this.ytdValues.forEach(function (ytdValue) {
                ytdValue.Updated = ytdValue.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(ytdValue.Updated)) : null;
                ytdValue.BusinessDate = _this.setDate(ytdValue.BusinessDate);
            });
            _this.sortYTDValues();
            //debugger;
            console.log("ytdValues", _this.ytdValues);
            // get the Dividend true up data and assign the values
            if (_this.enterValueCompleteData) {
                _this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendAllocation) {
                    dividendAllocation.DividendPartnerNode.InputData.$values.forEach(function (dividendNodeInput) {
                        if (dividendNodeInput.InputDataTypeEnum == 3) {
                            var objHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
                            objHierarchyEnterValue_DividendTrueUp.BusinessDate = _this.setDate(dividendNodeInput.BusinessDate);
                            objHierarchyEnterValue_DividendTrueUp.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                            objHierarchyEnterValue_DividendTrueUp.InputDataType = "YTD True Up";
                            objHierarchyEnterValue_DividendTrueUp.TrueUp = null;
                            objHierarchyEnterValue_DividendTrueUp.Updated = dividendNodeInput.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(dividendNodeInput.Updated)) : null;
                            objHierarchyEnterValue_DividendTrueUp.UpdatedBy = dividendNodeInput.UpdatedBy;
                            objHierarchyEnterValue_DividendTrueUp.Value = dividendNodeInput.Value;
                            _this.dividendTrueUp.push(objHierarchyEnterValue_DividendTrueUp);
                        }
                        else if (dividendNodeInput.InputDataTypeEnum == 10) {
                            var objHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
                            objHierarchyEnterValue_DividendTrueUp.BusinessDate = _this.setDate(dividendNodeInput.BusinessDate);
                            objHierarchyEnterValue_DividendTrueUp.DateValue = _this.setDate(dividendNodeInput.DateValue);
                            objHierarchyEnterValue_DividendTrueUp.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                            objHierarchyEnterValue_DividendTrueUp.InputDataType = "PPA True Up";
                            objHierarchyEnterValue_DividendTrueUp.TrueUp = dividendNodeInput.Value;
                            objHierarchyEnterValue_DividendTrueUp.Updated = dividendNodeInput.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(dividendNodeInput.Updated)) : null;
                            objHierarchyEnterValue_DividendTrueUp.UpdatedBy = dividendNodeInput.UpdatedBy;
                            objHierarchyEnterValue_DividendTrueUp.Value = null;
                            _this.dividendTrueUp.push(objHierarchyEnterValue_DividendTrueUp);
                        }
                    });
                });
                //console.log(this.dividendTrueUp);
                _this.blnHasDividendAllocations = _this.enterValueCompleteData.DividendPartnerAllocations.$values.length > 0 ? true : false;
                _this.sortDividendTrueUpValues();
            }
            // get the MVar data and assign the values
            _this.arrMVarDataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "MVar"; }) : [];
            _this.arrMVarDataValues.forEach(function (mvar) {
                mvar.Updated = mvar.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(mvar.Updated)) : null;
                mvar.BusinessDate = _this.setDate(mvar.BusinessDate);
            });
            // get the MVarLimit data and assign the values
            _this.arrMVarLimitDataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "MVarLimit"; }) : [];
            _this.arrMVarLimitDataValues.forEach(function (mvarLimit) {
                mvarLimit.Updated = mvarLimit.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(mvarLimit.Updated)) : null;
                mvarLimit.BusinessDate = _this.setDate(mvarLimit.BusinessDate);
            });
            // get the MVarTempLimit data and assign the values
            _this.arrMVarTempLimitDataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "MVarTemporaryLimit"; }) : [];
            _this.arrMVarTempLimitDataValues.forEach(function (mvarTempLimit) {
                mvarTempLimit.Updated = mvarTempLimit.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(mvarTempLimit.Updated)) : null;
                mvarTempLimit.BusinessDate = _this.setDate(mvarTempLimit.BusinessDate);
                mvarTempLimit.DateValue = _this.setDate(mvarTempLimit.DateValue);
            });
            // get the PnlPPA data and assign the values
            _this.arrPnlPPADataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "Prior Period Adjustment"; }) : [];
            _this.arrPnlPPADataValues.forEach(function (pnlPPA) {
                pnlPPA.Updated = pnlPPA.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(pnlPPA.Updated)) : null;
                pnlPPA.BusinessDate = _this.setDate(pnlPPA.BusinessDate);
                pnlPPA.DateValue = _this.setDate(pnlPPA.DateValue);
            });
            // get the Dividend PPA data and assign the values
            if (_this.enterValueCompleteData) {
                _this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendAllocation) {
                    dividendAllocation.DividendPartnerNode.InputData.$values.forEach(function (dividendNodeInput) {
                        if (dividendNodeInput.InputDataTypeEnum == 9) {
                            var objHierarchyEnterValue_DividendPPA = new clsHierarchyEnterValue_DividendPPA();
                            objHierarchyEnterValue_DividendPPA.BusinessDate = _this.setDate(dividendNodeInput.BusinessDate);
                            objHierarchyEnterValue_DividendPPA.RestatedMEDate = _this.setDate(dividendNodeInput.DateValue);
                            objHierarchyEnterValue_DividendPPA.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                            objHierarchyEnterValue_DividendPPA.RestatedMEYTD = dividendNodeInput.Value;
                            //debugger;
                            var obj = dividendAllocation.DividendPartnerNode.OutputData.$values.find(function (x) { return x.Type == "True Up YTD"
                                && _this.setDate(x.BusinessDate) == _this.setDate(dividendNodeInput.BusinessDate)
                                && x.MeasureCalculationType == 2; });
                            if (obj) {
                                objHierarchyEnterValue_DividendPPA.CalculatedPPA =
                                    obj.Value != null ? obj.Value : null;
                            }
                            else {
                                objHierarchyEnterValue_DividendPPA.CalculatedPPA = null;
                            }
                            objHierarchyEnterValue_DividendPPA.Updated = dividendNodeInput.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(dividendNodeInput.Updated)) : null;
                            objHierarchyEnterValue_DividendPPA.UpdatedBy = dividendNodeInput.UpdatedBy;
                            _this.dividendPPA.push(objHierarchyEnterValue_DividendPPA);
                        }
                    });
                });
                _this.sortDividendPPAValues();
            }
            _this.blnIsLoadComplete = true;
            _this.stopRefreshing();
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.setPublishStatus = function (data) {
        var status = data.Result.NumericValue;
        console.log("publish status", status);
        if (status == 0) {
            this.publishstatus = "Unpublished";
        }
        else {
            this.publishstatus = "Published";
        }
        localStorage.setItem("PublishStatus", this.publishstatus);
    };
    AppTprHierarchyEnterValueComponent.prototype.setEnterValueMenuItems = function () {
        this.enterValueMenuItems.forEach(function (menuItem) { return menuItem.disabled = false; });
        if (this.enterValueCompleteData && !this.enterValueCompleteData.Node.IsPnlHolder) {
            this.blnIsPnlHolder = false;
            this.enterValueMenuItems.forEach(function (menuItem) {
                if (menuItem.label == "YTD") {
                    menuItem.disabled = true;
                }
                if (menuItem.label == "Dividend True-Up") {
                    menuItem.disabled = true;
                }
                if (menuItem.label == "Pnl PPA") {
                    menuItem.disabled = true;
                }
                if (menuItem.label == "Dividend Partner PPA") {
                    menuItem.disabled = true;
                }
            });
        }
        else {
            this.blnIsPnlHolder = true;
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.ResetAllTemplate = function () {
        this.blnEnterValueYTDShow = false;
        this.blnEnterValueDividendTrueUpShow = false;
        this.blnEnterValueMVARShow = false;
        this.blnEnterValueMVARLimitShow = false;
        this.blnEnterValueMVARTemporaryLimitShow = false;
        this.blnEnterValuePnlPPAShow = false;
        this.blnEnterValueDividendPartnerPPAShow = false;
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueYTD = function () {
        this.ResetAllTemplate();
        this.blnEnterValueYTDShow = true;
        this.sortYTDValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueDividendTrueUp = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnEnterValueDividendTrueUpShow = true;
        this.blnEnableDividendTrueUp = true;
        this.lstDividendPartnerTrueUp = [];
        this.lstDividendPartnerTrueUp.push({ label: "Not Set", value: "NotSet" });
        this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendPartnerAllocation) {
            _this.lstDividendPartnerTrueUp.push({ label: dividendPartnerAllocation.DividendPartnerNode.Name, value: dividendPartnerAllocation.DividendPartnerNode.Name });
        });
        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(function (data) { return _this.setDividendPartnerData(data); });
        this.sortDividendTrueUpValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueMVAR = function () {
        this.ResetAllTemplate();
        this.blnEnterValueMVARShow = true;
        //console.log(this.arrMVarDataValues);
        this.MVarUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;
        this.blnHasMVarUpdateTiming = this.MVarUpdateTiming ? true : false;
        if (this.MVarUpdateTiming) {
            var newDate = new Date(this.businessDate);
            this.MVarMinDate = newDate;
            this.MVarMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarMinDate, true);
            if (this.MVarUpdateTiming == -2) {
                this.MVarMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarMinDate, true);
            }
            //If not published, find the trade date. Otherwise, business date will be the next trade date
            if (this.publishstatus === "Published" || this.lockstatus === 1) {
                this.MVarMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarMinDate, false);
            }
            console.log("Trade Date ->", this.MVarMinDate);
            this.dtMVarTradingDate = this.MVarMinDate;
        }
        this.sortMVarValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueMVARLimit = function () {
        this.ResetAllTemplate();
        this.blnEnterValueMVARLimitShow = true;
        this.MVarLimitUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;
        this.blnHasMVarLimitUpdateTiming = this.MVarLimitUpdateTiming ? true : false;
        if (this.MVarLimitUpdateTiming) {
            var newDate = new Date(this.businessDate);
            this.MVarLimitMinDate = newDate;
            this.MVarLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarLimitMinDate, true);
            if (this.MVarLimitUpdateTiming == -2) {
                this.MVarLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarLimitMinDate, true);
            }
            //If not published, find the trade date. Otherwise, business date will be the next trade date
            if (this.publishstatus === "Published" || this.lockstatus === 1) {
                this.MVarLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarLimitMinDate, false);
            }
            console.log("Trade Date ->", this.MVarLimitMinDate);
            this.dtMVarLimitTradingDate = this.MVarLimitMinDate;
        }
        this.sortMVarLimitValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueMVARTemporaryLimit = function () {
        this.ResetAllTemplate();
        //debugger;
        this.blnEnterValueMVARTemporaryLimitShow = true;
        this.MVarTempLimitUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;
        this.blnHasMVarTempLimitUpdateTiming = this.MVarTempLimitUpdateTiming ? true : false;
        if (this.MVarTempLimitUpdateTiming) {
            var newDate = new Date(this.businessDate);
            this.MVarTempLimitMinDate = newDate;
            this.MVarTempLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarTempLimitMinDate, true);
            if (this.MVarTempLimitUpdateTiming == -2) {
                this.MVarTempLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarTempLimitMinDate, true);
            }
            //If not published, find the trade date. Otherwise, business date will be the next trade date
            if (this.publishstatus === "Published" || this.lockstatus === 1) {
                this.MVarTempLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarTempLimitMinDate, false);
            }
            console.log("Trade Date ->", this.MVarTempLimitMinDate);
            this.dtMVarTempLimitTradingDate = this.MVarTempLimitMinDate;
            this.setMVarTempLimitExpiryDate();
            this.blnDisableMVarTempLimitExpiryDate = true;
        }
        this.sortMVarTempLimitValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValuePnlPPA = function () {
        this.ResetAllTemplate();
        this.blnEnterValuePnlPPAShow = true;
        this.PnlPPAMinDate = this.minDate;
        this.dtPnlPPATradingDate = this.PnlPPAMinDate;
        this.strPnlPPAMonthEndDate = this.enterValueCompleteData ? this.setDate(this.enterValueCompleteData.Node.PreviousMonthEndDate) : "";
        this.strPnlPPAReportedMonthEndYTD = this.enterValueCompleteData ? this.enterValueCompleteData.Node.ReportedMEYTD : "";
        this.sortPnlPPAValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueDividendPartnerPPA = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnEnterValueDividendPartnerPPAShow = true;
        this.blnEnableDividendPPA = true;
        this.DividendPPAMinDate = this.minDate;
        this.dtTradingDateDividendPartnerPPA = this.DividendPPAMinDate;
        this.strDividendPPAMonthEndDate = this.enterValueCompleteData ? this.setDate(this.enterValueCompleteData.Node.PreviousMonthEndDate) : "";
        this.lstDividendPartnerPPA = [];
        this.lstDividendPartnerPPA.push({ label: "Not Set", value: "NotSet" });
        this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendPartnerAllocation) {
            _this.lstDividendPartnerPPA.push({ label: dividendPartnerAllocation.DividendPartnerNode.Name, value: dividendPartnerAllocation.DividendPartnerNode.Name });
        });
        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(function (data) { return _this.setDividendPartnerData(data); });
        this.sortDividendPPAValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.Cancel = function () {
        this.blnShowModalPouUp = false;
        this.router.navigate(['/hierarchy']);
    };
    AppTprHierarchyEnterValueComponent.prototype.Save = function () {
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Saving changes to node values. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.objEnterValuePostData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.UpdateDataCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                _this.objEnterValuePostData.HierarchyType = "Main";
                _this.objEnterValuePostData.Node = _this.enterValueCompleteData.Node;
                _this.objEnterValuePostData.UpdateData = _this.arrYTDUpdateData;
                _this.isRequesting = true;
                _this.tPRHierarchyservice.updateNodeLevelEnterValueForPost(_this.objEnterValuePostData)
                    .subscribe(function (response) {
                    console.log(response);
                    if (response.Error) {
                        //alert(response.Error);
                        _this.ValidationStatus = "Error";
                        _this.ValidationMessage = response.Error;
                        _this.blnShowPopUp = true;
                        _this.stopRefreshing();
                    }
                    else {
                        _this.stopRefreshing();
                        _this.blnShowModalPouUp = false;
                        _this.router.navigateByUrl('/hierarchy');
                    }
                }, function (error) {
                    console.log(error);
                    _this.ValidationStatus = "Error";
                    _this.ValidationMessage = error;
                    _this.blnShowPopUp = true;
                    _this.stopRefreshing();
                });
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onAddYTDValue = function (txtYTDValue) {
        if (txtYTDValue == undefined || txtYTDValue == null || txtYTDValue.length == 0) {
            //alert("Value cannot be null");
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            //console.log(this.dtTradingDate);
            //console.log(txtYTDValue);
            var selectedYTDDate_1 = this.setDate(this.dtTradingDate.toString());
            //this.ytdValues.forEach(ytdValue => console.log(ytdValue.BusinessDate));
            if (this.ytdValues.findIndex(function (ytdValue) { return ytdValue.BusinessDate == selectedYTDDate_1; }) != -1) {
                //alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                this.blnShowPopUp = true;
            }
            else {
                if (!isNaN(Number(txtYTDValue))) {
                    var ytdSelected = new clsHierarchyEditNode_Node_InputData_Values();
                    ytdSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    ytdSelected.BusinessDate = selectedYTDDate_1;
                    ytdSelected.InputDataTypeEnum = 1;
                    ytdSelected.InputDataType = "YTD";
                    ytdSelected.Published = false;
                    ytdSelected.Value = Number(txtYTDValue);
                    this.ytdValues.push(ytdSelected);
                    this.selectedYTDValue = ytdSelected;
                    //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 1 && item.BusinessDate != selectedYTDDate);
                    var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 1 && item.BusinessDate == selectedYTDDate_1; });
                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var ytdUpdateData = new clsUpdateData();
                    ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    ytdUpdateData.BusinessDate = ytdSelected.BusinessDate;
                    ytdUpdateData.DateValue = null;
                    ytdUpdateData.InputDataType = 1;
                    ytdUpdateData.DividendPartner = null;
                    ytdUpdateData.Value = ytdSelected.Value;
                    this.arrYTDUpdateData.push(ytdUpdateData);
                    this.blnDisableSaveValue = false;
                    this.sortYTDValues();
                }
                else {
                    //alert("Input value is not in a correct format.")
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "Input value is not in a correct format.";
                    this.blnShowPopUp = true;
                }
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.setDate = function (data) {
        var myDate = new Date(data);
        var output = "";
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var modifiedDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        output = myDate.getDate().toString().length > 1 ?
            myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear() :
            "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        return output;
    };
    AppTprHierarchyEnterValueComponent.prototype.sortYTDValues = function () {
        this.ytdValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForYTDValue = function (event) {
        //console.log(event);
        this.objYTDValue = this.cloneYTDValue(event.data);
        this.displayDialogForYTD = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneYTDValue = function (objForClone) {
        var ytdValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            ytdValue[prop] = objForClone[prop];
        }
        return ytdValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteYTDValues = function (ytdValueDeleted) {
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected YTD amount will be deleted. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.ytdValues.splice(_this.ytdValues.indexOf(ytdValueDeleted), 1);
                _this.objYTDValue = null;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 1 && item.BusinessDate != ytdValueDeleted.BusinessDate);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 1 && item.BusinessDate == ytdValueDeleted.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var ytdUpdateData = new clsUpdateData();
                ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ytdUpdateData.BusinessDate = ytdValueDeleted.BusinessDate;
                ytdUpdateData.DateValue = null;
                ytdUpdateData.DividendPartner = null;
                ytdUpdateData.InputDataType = 1;
                ytdUpdateData.Value = null;
                _this.arrYTDUpdateData.push(ytdUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortYTDValues();
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.saveYTDValue = function () {
        var _this = this;
        if (this.objYTDValue.Value == undefined || this.objYTDValue.Value == null || this.objYTDValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objYTDValue.Value)) {
                var ytdValues = this.ytdValues.slice();
                ytdValues[this.findSelectedYTDValueIndex()] = this.objYTDValue;
                this.ytdValues = ytdValues;
                this.arrYTDUpdateData = this.arrYTDUpdateData.filter(function (item) { return item.InputDataType == 1 && item.BusinessDate != _this.objYTDValue.BusinessDate; });
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 1 && item.BusinessDate == _this.objYTDValue.BusinessDate; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                this.selectedYTDValue = this.objYTDValue;
                var ytdUpdateData = new clsUpdateData();
                ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ytdUpdateData.BusinessDate = this.objYTDValue.BusinessDate;
                ytdUpdateData.DateValue = null;
                ytdUpdateData.DividendPartner = null;
                ytdUpdateData.InputDataType = 1;
                ytdUpdateData.Value = this.objYTDValue.Value;
                this.arrYTDUpdateData.push(ytdUpdateData);
                this.objYTDValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForYTD = false;
            }
            else {
                //alert("Input value is not in a correct format.")
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedYTDValueIndex = function () {
        return this.ytdValues.indexOf(this.selectedYTDValue);
    };
    AppTprHierarchyEnterValueComponent.prototype.sortDividendTrueUpValues = function () {
        this.dividendTrueUp.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onDividendPartnerTrueUpChange = function () {
        var _this = this;
        var intPercentageValue = 0;
        var selectedDividendAllocation = new clsHierarchyEditNode_DividendPartnerAllocations_Values();
        var selectedTrueUpTradingDate = this.setDate(this.dtTradingDateDividendPartnerTrueUp.toString());
        //this.dividendTrueUp.forEach(trueUp => console.log(trueUp));
        if (this.dividendTrueUp.findIndex(function (trueUp) { return trueUp.BusinessDate == selectedTrueUpTradingDate
            && trueUp.DividendPartnerName == _this.strSelectedDividendPartnerTrueUpName && trueUp.InputDataType == "YTD True Up"; }) != -1) {
            this.blnEnableDividendTrueUp = true;
        }
        else {
            if (this.strSelectedDividendPartnerTrueUpName && this.strSelectedDividendPartnerTrueUpName.toString() != "NotSet") {
                selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find(function (dividendAllocation) { return dividendAllocation.DividendPartnerNode.Name == _this.strSelectedDividendPartnerTrueUpName; });
                intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                this.blnEnableDividendTrueUp = false;
            }
            else {
                intPercentageValue = 0;
                this.blnEnableDividendTrueUp = true;
            }
        }
        this.strSelectedDividendPartnerPercentage = intPercentageValue.toString();
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendTrueUpAdd = function () {
        if (this.dividendPartnerReportedYTDValue == undefined || this.dividendPartnerReportedYTDValue == null || this.dividendPartnerReportedYTDValue.toString().length == 0) {
            //alert("Value cannot be null");
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value canot be null";
            this.blnShowPopUp = true;
        }
        else {
            // console.log(this.dtTradingDateDividendPartnerTrueUp);
            // console.log(this.strSelectedDividendPartnerTrueUpName);
            // console.log(this.dividendPartnerReportedYTDValue);
            if (!isNaN(this.dividendPartnerReportedYTDValue)) {
                var selectedTrueUpTradingDate_1 = this.setDate(this.dtTradingDateDividendPartnerTrueUp.toString());
                //this.dividendTrueUp.forEach(trueUp => console.log(trueUp));
                var trueUpSelected_1 = new clsHierarchyEnterValue_DividendTrueUp();
                //trueUpSelected.$type = "";
                trueUpSelected_1.BusinessDate = selectedTrueUpTradingDate_1;
                trueUpSelected_1.InputDataType = "YTD True Up";
                trueUpSelected_1.DividendPartnerName = this.strSelectedDividendPartnerTrueUpName;
                trueUpSelected_1.Value = this.dividendPartnerReportedYTDValue;
                this.dividendTrueUp.push(trueUpSelected_1);
                this.selectedDividendPartnerTrueUp = trueUpSelected_1;
                this.strSelectedDividendPartnerTrueUpName = "NotSet";
                this.dividendPartnerReportedYTDValue = null;
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 3 && item.BusinessDate == selectedTrueUpTradingDate_1; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var trueUpUpdateData = new clsUpdateData();
                trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                trueUpUpdateData.BusinessDate = trueUpSelected_1.BusinessDate;
                trueUpUpdateData.DateValue = null;
                trueUpUpdateData.InputDataType = 3;
                trueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == trueUpSelected_1.DividendPartnerName; });
                trueUpUpdateData.Value = trueUpSelected_1.Value;
                this.arrYTDUpdateData.push(trueUpUpdateData);
                this.blnDisableSaveValue = false;
                this.blnEnableDividendTrueUp = true;
                this.sortDividendTrueUpValues();
            }
            else {
                //alert("Input value is not in a correct format.")
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendTrueUpClear = function () {
        this.strSelectedDividendPartnerTrueUpName = "NotSet";
        this.dividendPartnerReportedYTDValue = null;
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForDividendPartnerTrueUp = function (event) {
        //console.log(event);
        this.objDividendPartnerTrueUpValue = this.cloneDividendTrueUpValue(event.data);
        if (this.objDividendPartnerTrueUpValue.InputDataType == "YTD True Up") {
            this.displayDialogForDividendTrueUp = true;
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneDividendTrueUpValue = function (objForClone) {
        var dividendTrueUpValue = new clsHierarchyEnterValue_DividendTrueUp();
        for (var prop in objForClone) {
            dividendTrueUpValue[prop] = objForClone[prop];
        }
        return dividendTrueUpValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteDividendPartnerTrueUp = function (dividendTrueUpRowValue) {
        //console.log(dividendTrueUpRowValue);
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected True Up amount will be deleted. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.dividendTrueUp.splice(_this.dividendTrueUp.indexOf(dividendTrueUpRowValue), 1);
                _this.objDividendPartnerTrueUpValue = null;
                if (dividendTrueUpRowValue.InputDataType == "YTD True Up") {
                    var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 3
                        && item.BusinessDate == dividendTrueUpRowValue.BusinessDate && item.DividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    if (arrData) {
                        _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var trueUpUpdateData = new clsUpdateData();
                    trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    trueUpUpdateData.BusinessDate = dividendTrueUpRowValue.BusinessDate;
                    trueUpUpdateData.DateValue = null;
                    trueUpUpdateData.InputDataType = 3;
                    trueUpUpdateData.DividendPartner = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    trueUpUpdateData.Value = null;
                    _this.arrYTDUpdateData.push(trueUpUpdateData);
                }
                else if (dividendTrueUpRowValue.InputDataType == "PPA True Up") {
                    var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 10
                        && item.BusinessDate == dividendTrueUpRowValue.BusinessDate && item.DividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    if (arrData) {
                        _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var trueUpUpdateData = new clsUpdateData();
                    trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaTrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    trueUpUpdateData.InputDataType = 10;
                    trueUpUpdateData.BusinessDate = dividendTrueUpRowValue.BusinessDate;
                    trueUpUpdateData.DividendPartner = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    trueUpUpdateData.Value = null;
                    trueUpUpdateData.DateValue = dividendTrueUpRowValue.DateValue;
                    _this.arrYTDUpdateData.push(trueUpUpdateData);
                }
                _this.blnDisableSaveValue = false;
                _this.sortDividendTrueUpValues();
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.saveDividendTrueUpValue = function () {
        var _this = this;
        if (this.objDividendPartnerTrueUpValue.Value == undefined || this.objDividendPartnerTrueUpValue.Value == null || this.objDividendPartnerTrueUpValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objDividendPartnerTrueUpValue.Value)) {
                var dividendTrueUpValues = this.dividendTrueUp.slice();
                dividendTrueUpValues[this.findSelectedDividendTrueUpValueIndex()] = this.objDividendPartnerTrueUpValue;
                this.dividendTrueUp = dividendTrueUpValues;
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 3 && item.BusinessDate == _this.objDividendPartnerTrueUpValue.BusinessDate; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                this.selectedDividendPartnerTrueUp = this.objDividendPartnerTrueUpValue;
                var TrueUpUpdateData = new clsUpdateData();
                TrueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                TrueUpUpdateData.BusinessDate = this.objDividendPartnerTrueUpValue.BusinessDate;
                TrueUpUpdateData.DateValue = null;
                TrueUpUpdateData.InputDataType = 3;
                TrueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.objDividendPartnerTrueUpValue.DividendPartnerName; });
                TrueUpUpdateData.Value = this.objDividendPartnerTrueUpValue.Value;
                this.arrYTDUpdateData.push(TrueUpUpdateData);
                this.objDividendPartnerTrueUpValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForDividendTrueUp = false;
            }
            else {
                //alert("Input value is not in a correct format.")
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onSelectDividendTrueUpTradingDate = function () {
        this.strSelectedDividendPartnerTrueUpName = "NotSet";
        this.blnEnableDividendTrueUp = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedDividendTrueUpValueIndex = function () {
        var _this = this;
        var objDividendTrueUpSelected = new clsHierarchyEnterValue_DividendTrueUp();
        objDividendTrueUpSelected = this.dividendTrueUp
            .find(function (x) { return x.BusinessDate == _this.objDividendPartnerTrueUpValue.BusinessDate
            && x.DividendPartnerName == _this.objDividendPartnerTrueUpValue.DividendPartnerName; });
        //console.log(objDividendTrueUpSelected);
        return this.dividendTrueUp.indexOf(objDividendTrueUpSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.setDividendPartnerData = function (data) {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
    };
    AppTprHierarchyEnterValueComponent.prototype.onAddMVarValue = function () {
        //console.log(this.MVarValue);
        //console.log(this.dtMVarTradingDate);
        if (this.MVarValue == undefined || this.MVarValue == null || this.MVarValue.toString().length == 0) {
            //alert("Value cannot be null");
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.MVarValue)) {
                var selectedMVarDate_1 = this.setDate(this.dtMVarTradingDate.toString());
                //this.arrMVarDataValues.forEach(mvarValue => console.log(mvarValue.BusinessDate));
                if (this.arrMVarDataValues.findIndex(function (MVarValue) { return MVarValue.BusinessDate == selectedMVarDate_1; }) != -1) {
                    //alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                    this.blnShowPopUp = true;
                }
                else {
                    var MVarSelected = new clsHierarchyEditNode_Node_InputData_Values();
                    MVarSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    MVarSelected.BusinessDate = selectedMVarDate_1;
                    MVarSelected.DateValue = null;
                    MVarSelected.InputDataTypeEnum = 4;
                    MVarSelected.InputDataType = "MVar";
                    MVarSelected.Published = false;
                    MVarSelected.Value = Number(this.MVarValue);
                    this.arrMVarDataValues.push(MVarSelected);
                    this.selectedMVarValue = MVarSelected;
                    //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 4 && item.BusinessDate != selectedMVarDate);
                    var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 4 && item.BusinessDate == selectedMVarDate_1; });
                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var MVarUpdateData = new clsUpdateData();
                    MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    MVarUpdateData.BusinessDate = MVarSelected.BusinessDate;
                    MVarUpdateData.InputDataType = 4;
                    MVarUpdateData.DividendPartner = null;
                    MVarUpdateData.Value = this.MVarValue;
                    this.arrYTDUpdateData.push(MVarUpdateData);
                    this.MVarValue = null;
                    this.blnDisableSaveValue = false;
                    this.sortMVarValues();
                }
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForMVarValue = function (event) {
        //console.log(event);
        this.objMVarValue = this.cloneMVarValue(event.data);
        this.displayDialogForMVar = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneMVarValue = function (objForClone) {
        var MVarValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            MVarValue[prop] = objForClone[prop];
        }
        return MVarValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveMVarValue = function () {
        var _this = this;
        if (this.objMVarValue.Value == undefined || this.objMVarValue.Value == null || this.objMVarValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objMVarValue.Value)) {
                var MVarValues = this.arrMVarDataValues.slice();
                MVarValues[this.findSelectedMVarValueIndex()] = this.objMVarValue;
                this.arrMVarDataValues = MVarValues;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 4 && item.BusinessDate != this.objMVarValue.BusinessDate);
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 4 && item.BusinessDate == _this.objMVarValue.BusinessDate; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                this.selectedMVarValue = this.objMVarValue;
                var MVarUpdateData = new clsUpdateData();
                MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarUpdateData.BusinessDate = this.objMVarValue.BusinessDate;
                MVarUpdateData.DateValue = null;
                MVarUpdateData.InputDataType = 4;
                MVarUpdateData.DividendPartner = null;
                MVarUpdateData.Value = this.objMVarValue.Value;
                this.arrYTDUpdateData.push(MVarUpdateData);
                this.objMVarValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForMVar = false;
            }
            else {
                //alert('Input is not in a correct format');
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedMVarValueIndex = function () {
        var _this = this;
        var objMVarSelected = new clsHierarchyEditNode_Node_InputData_Values();
        objMVarSelected = this.arrMVarDataValues.find(function (x) { return x.BusinessDate == _this.objMVarValue.BusinessDate; });
        //console.log(objMVarSelected);
        return this.arrMVarDataValues.indexOf(objMVarSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.onCustomNumericValidation = function (event) {
        return (String.fromCharCode(event.charCode).match(/[0-9.]/g) != null);
    };
    AppTprHierarchyEnterValueComponent.prototype.onCustomNumericValidationForPositiveandNegativeIntegers = function (event) {
        return (String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null);
    };
    AppTprHierarchyEnterValueComponent.prototype.onCustomNumericValidationForPositiveandNegativeIntegersForDividendPPA = function (event, value) {
        //debugger;
        // console.log("Charcode", event.charCode);
        // console.log("keyCode", event.keyCode);
        var result;
        // to handle backspace and delete key press, left right, top, bottom arrow, contrl , backspace, shift, home, end
        if (event.keyCode === 8 || event.keyCode === 46 || event.keyCode === 35 || event.keyCode === 36 || event.keyCode === 37 || event.keyCode === 38 || event.keyCode === 39 || event.keyCode === 40
            || event.keyCode === 16 || event.keyCode === 17) {
            result = true;
        }
        else {
            result = event.charCode ? (String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null) : (String.fromCharCode(event.keyCode).match(/[0-9.-]/g) != null);
        }
        if (result) {
            if (!isNaN(value)) {
                //this.strProjectedDividendPPA = (this.DividendPPARestatedMEValue - Number(this.strDividendPPAReportedMonthEnd)).toString();
                var newProjectedValue = Number(value) - Number(this.strDividendPPAReportedMonthEnd);
                this.strProjectedDividendPPA = newProjectedValue ? Number(newProjectedValue).toString() : "";
            }
            else {
                this.DividendPPARestatedMEValue = Number(this.strProjectedDividendPPA);
            }
            return true;
        }
        else {
            return false;
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onCustomNumericValidationMVarTempLimit = function (event) {
        return (String.fromCharCode(event.charCode).match(/[0-9]/g) != null);
    };
    AppTprHierarchyEnterValueComponent.prototype.sortMVarValues = function () {
        this.arrMVarDataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteMVarValues = function (MVarValue) {
        //console.log(MVarValue);
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected MVAR amount will be deleted. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.arrMVarDataValues.splice(_this.arrMVarDataValues.indexOf(MVarValue), 1);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 4 && item.BusinessDate == MVarValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarUpdateData = new clsUpdateData();
                MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarUpdateData.BusinessDate = MVarValue.BusinessDate;
                MVarUpdateData.DateValue = null;
                MVarUpdateData.InputDataType = 4;
                MVarUpdateData.DividendPartner = null;
                MVarUpdateData.Value = null;
                _this.arrYTDUpdateData.push(MVarUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortMVarValues();
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onAddMVarLimitValue = function () {
        //console.log(this.dtMVarLimitTradingDate);
        //console.log(this.MVarLimitValue);
        if (this.MVarLimitValue == undefined || this.MVarLimitValue == null || this.MVarLimitValue.toString().length == 0) {
            //alert("Value cannot be null");
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.MVarLimitValue)) {
                var selectedMVarLimitDate_1 = this.setDate(this.dtMVarLimitTradingDate.toString());
                if (this.arrMVarLimitDataValues.findIndex(function (MVarLimitValue) { return MVarLimitValue.BusinessDate == selectedMVarLimitDate_1; }) != -1) {
                    //alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                    this.blnShowPopUp = true;
                }
                else {
                    var MVarLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
                    MVarLimitSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    MVarLimitSelected.BusinessDate = selectedMVarLimitDate_1;
                    MVarLimitSelected.DateValue = null;
                    MVarLimitSelected.InputDataTypeEnum = 5;
                    MVarLimitSelected.InputDataType = "MVarLimit";
                    MVarLimitSelected.Published = false;
                    MVarLimitSelected.Value = Number(this.MVarLimitValue);
                    this.arrMVarLimitDataValues.push(MVarLimitSelected);
                    this.selectedMVarLimitValue = MVarLimitSelected;
                    //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 5 && item.BusinessDate != selectedMVarLimitDate);
                    var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 5 && item.BusinessDate == selectedMVarLimitDate_1; });
                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var MVarLimitUpdateData = new clsUpdateData();
                    MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    MVarLimitUpdateData.BusinessDate = MVarLimitSelected.BusinessDate;
                    MVarLimitUpdateData.DateValue = null;
                    MVarLimitUpdateData.InputDataType = 5;
                    MVarLimitUpdateData.DividendPartner = null;
                    MVarLimitUpdateData.Value = this.MVarLimitValue;
                    this.arrYTDUpdateData.push(MVarLimitUpdateData);
                    this.MVarLimitValue = null;
                    this.blnDisableSaveValue = false;
                    this.sortMVarLimitValues();
                }
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForMVarLimitValue = function (event) {
        //console.log(event);
        this.objMVarLimitValue = this.cloneMVarLimitValue(event.data);
        this.displayDialogForMVarLimit = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneMVarLimitValue = function (objForClone) {
        var MVarLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            MVarLimitValue[prop] = objForClone[prop];
        }
        return MVarLimitValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveMVarLimitValue = function () {
        var _this = this;
        if (this.objMVarLimitValue.Value == undefined || this.objMVarLimitValue.Value == null || this.objMVarLimitValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objMVarLimitValue.Value)) {
                var MVarLimitValues = this.arrMVarLimitDataValues.slice();
                MVarLimitValues[this.findSelectedMVarLimitValueIndex()] = this.objMVarLimitValue;
                this.arrMVarLimitDataValues = MVarLimitValues;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 5 && item.BusinessDate != this.objMVarLimitValue.BusinessDate);
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 5 && item.BusinessDate == _this.objMVarLimitValue.BusinessDate; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                this.selectedMVarLimitValue = this.objMVarLimitValue;
                var MVarLimitUpdateData = new clsUpdateData();
                MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarLimitUpdateData.BusinessDate = this.objMVarLimitValue.BusinessDate;
                MVarLimitUpdateData.DateValue = null;
                MVarLimitUpdateData.InputDataType = 5;
                MVarLimitUpdateData.DividendPartner = null;
                MVarLimitUpdateData.Value = this.objMVarLimitValue.Value;
                this.arrYTDUpdateData.push(MVarLimitUpdateData);
                this.objMVarLimitValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForMVarLimit = false;
            }
            else {
                //alert('Input is not in a correct format');
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedMVarLimitValueIndex = function () {
        var _this = this;
        var objMVarLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
        objMVarLimitSelected = this.arrMVarLimitDataValues.find(function (x) { return x.BusinessDate == _this.objMVarLimitValue.BusinessDate; });
        //console.log(objMVarLimitSelected);
        return this.arrMVarLimitDataValues.indexOf(objMVarLimitSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteMVarLimitValues = function (MVarLimitValue) {
        //console.log(MVarLimitValue);
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected MVAR Limit will be deleted. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.arrMVarLimitDataValues.splice(_this.arrMVarLimitDataValues.indexOf(MVarLimitValue), 1);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 5 && item.BusinessDate == MVarLimitValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarLimitUpdateData = new clsUpdateData();
                MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarLimitUpdateData.BusinessDate = MVarLimitValue.BusinessDate;
                MVarLimitUpdateData.DateValue = null;
                MVarLimitUpdateData.InputDataType = 5;
                MVarLimitUpdateData.DividendPartner = null;
                MVarLimitUpdateData.Value = null;
                _this.arrYTDUpdateData.push(MVarLimitUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortMVarLimitValues();
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.sortMVarLimitValues = function () {
        this.arrMVarLimitDataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.setMVarTempLimitExpiryDate = function () {
        //debugger;
        var MVarTempLimitTradingDate = this.dtMVarTempLimitTradingDate;
        localStorage.setItem("MVarTempLimitTradingDate", MVarTempLimitTradingDate.toString());
        var selectedTradingDate = localStorage.getItem("MVarTempLimitTradingDate");
        var dayNumber = new Date(selectedTradingDate).getDay();
        this.dtMVarTempLimitExpiryDate = new Date(selectedTradingDate);
        var newExpiryDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.dtMVarTempLimitExpiryDate, false);
        this.dtMVarTempLimitExpiryDate = new Date(newExpiryDate);
        // Monday = 1
        // Tuesday = 2
        // Wednesday = 3
        // Thursday = 4
        // Friday = 5
        // Saturday = 6
        // Sunday = 7      
        // if (dayNumber < 5 || dayNumber == 7) {
        //     this.dtMVarTempLimitExpiryDate.setDate(this.dtMVarTempLimitExpiryDate.getDate() + 1);
        // }
        // else if (dayNumber == 5) {
        //     this.dtMVarTempLimitExpiryDate.setDate(this.dtMVarTempLimitExpiryDate.getDate() + 3);
        // }
        // else if (dayNumber == 6) {
        //     this.dtMVarTempLimitExpiryDate.setDate(this.dtMVarTempLimitExpiryDate.getDate() + 2);
        // }
    };
    AppTprHierarchyEnterValueComponent.prototype.onSelectMVarTempLimitTradingDate = function (value) {
        this.setMVarTempLimitExpiryDate();
    };
    AppTprHierarchyEnterValueComponent.prototype.onMVarTempLimitValueKeyUp = function (event) {
        if (this.MVarTempLimitValue && this.MVarTempLimitValue.toString().length > 0) {
            this.blnDisableMVarTempLimitExpiryDate = false;
        }
        else {
            this.blnDisableMVarTempLimitExpiryDate = true;
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickMVarTempLimitAdd = function () {
        // console.log(this.dtMVarTempLimitTradingDate);
        // console.log(this.MVarTempLimitValue);
        // console.log(this.dtMVarTempLimitExpiryDate);
        var _this = this;
        if (this.MVarTempLimitValue == undefined || this.MVarTempLimitValue == null || this.MVarTempLimitValue.toString().length == 0) {
            //alert("Value cannot be null");
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.MVarTempLimitValue)) {
                var selectedMVarTempLimitDate_1 = this.setDate(this.dtMVarTempLimitTradingDate.toString());
                var selectedMVarTempLimitExpiryDate_1 = this.setDate(this.dtMVarTempLimitExpiryDate.toString());
                if (this.arrMVarTempLimitDataValues.findIndex(function (MVarTempLimitValue) { return MVarTempLimitValue.BusinessDate == selectedMVarTempLimitDate_1; }) != -1) {
                    //alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                    this.blnShowPopUp = true;
                }
                else {
                    //debugger;
                    if (JSON.parse(localStorage.getItem("Holidays"))) {
                        this.holidays = JSON.parse(localStorage.getItem("Holidays"));
                    }
                    if (this.holidays.find(function (holiday) { return holiday.Region == null && _this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                        _this.tprCommonService.getFormattedSystemDate_Date(new Date(selectedMVarTempLimitExpiryDate_1)); })) {
                        var selectedHoliday = this.holidays.find(function (holiday) { return holiday.Region == null &&
                            _this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                                _this.tprCommonService.getFormattedSystemDate_Date(new Date(selectedMVarTempLimitExpiryDate_1)); });
                        var holidayName = selectedHoliday && selectedHoliday.Name ? selectedHoliday.Name : "";
                        this.ValidationStatus = "Validation error";
                        this.ValidationMessage = "Cannot add a MVar Temp Limit value for global holiday \"" + holidayName + "\"";
                        this.blnShowPopUp = true;
                    }
                    else {
                        var MVarTempLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
                        MVarTempLimitSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                        MVarTempLimitSelected.BusinessDate = selectedMVarTempLimitDate_1;
                        MVarTempLimitSelected.DateValue = selectedMVarTempLimitExpiryDate_1;
                        MVarTempLimitSelected.InputDataTypeEnum = 8;
                        MVarTempLimitSelected.InputDataType = "MVarTemporaryLimit";
                        MVarTempLimitSelected.Published = false;
                        MVarTempLimitSelected.Value = Number(this.MVarTempLimitValue);
                        this.arrMVarTempLimitDataValues.push(MVarTempLimitSelected);
                        this.selectedMVarTempLimitValue = MVarTempLimitSelected;
                        var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 8 && item.BusinessDate == _this.objMVarTempLimitValue.BusinessDate; });
                        if (arrData) {
                            this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                        }
                        var MVarTempLimitUpdateData = new clsUpdateData();
                        MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                        MVarTempLimitUpdateData.BusinessDate = MVarTempLimitSelected.BusinessDate;
                        MVarTempLimitUpdateData.DateValue = MVarTempLimitSelected.DateValue;
                        MVarTempLimitUpdateData.InputDataType = 8;
                        MVarTempLimitUpdateData.DividendPartner = null;
                        MVarTempLimitUpdateData.Value = this.MVarTempLimitValue;
                        this.arrYTDUpdateData.push(MVarTempLimitUpdateData);
                        this.MVarLimitValue = null;
                        this.blnDisableSaveValue = false;
                        this.sortMVarTempLimitValues();
                    }
                }
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.sortMVarTempLimitValues = function () {
        this.arrMVarTempLimitDataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForMVarTempLimitValue = function (event) {
        this.objMVarTempLimitValue = this.cloneMVarTempLimitValue(event.data);
        this.displayDialogForMVarTempLimit = true;
        this.minimumSelectableDate = new Date(this.objMVarTempLimitValue.BusinessDate);
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneMVarTempLimitValue = function (objForClone) {
        var MVarTempLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            MVarTempLimitValue[prop] = objForClone[prop];
        }
        return MVarTempLimitValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveMVarTempLimitValue = function () {
        var _this = this;
        if (this.objMVarTempLimitValue.Value == undefined || this.objMVarTempLimitValue.Value == null || this.objMVarTempLimitValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objMVarTempLimitValue.Value)) {
                var MVarTempLimitValues = this.arrMVarTempLimitDataValues.slice();
                MVarTempLimitValues[this.findSelectedMVarTempLimitValueIndex()] = this.objMVarTempLimitValue;
                this.arrMVarTempLimitDataValues = MVarTempLimitValues;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 8 && (item.BusinessDate != this.objMVarTempLimitValue.BusinessDate && item.DateValue != this.objMVarTempLimitValue.DateValue));
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType != 8 && item.BusinessDate == this.objMVarTempLimitValue.BusinessDate);
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 8 && item.BusinessDate == _this.objMVarTempLimitValue.BusinessDate; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                this.selectedMVarTempLimitValue = this.objMVarTempLimitValue;
                var MVarTempLimitUpdateData = new clsUpdateData();
                MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarTempLimitUpdateData.BusinessDate = this.objMVarTempLimitValue.BusinessDate;
                MVarTempLimitUpdateData.DateValue = this.objMVarTempLimitValue.DateValue;
                MVarTempLimitUpdateData.InputDataType = 8;
                MVarTempLimitUpdateData.DividendPartner = null;
                MVarTempLimitUpdateData.Value = this.objMVarTempLimitValue.Value;
                this.arrYTDUpdateData.push(MVarTempLimitUpdateData);
                this.objMVarTempLimitValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForMVarTempLimit = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedMVarTempLimitValueIndex = function () {
        var _this = this;
        var objMVarTempLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
        objMVarTempLimitSelected = this.arrMVarTempLimitDataValues.find(function (x) { return x.BusinessDate == _this.objMVarTempLimitValue.BusinessDate; });
        //console.log(objMVarTempLimitSelected);
        return this.arrMVarTempLimitDataValues.indexOf(objMVarTempLimitSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteMVarTempLimitValues = function (MVarTempLimitValue) {
        //console.log(MVarTempLimitValue);
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected MVAR Temporary Limit will be deleted. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.arrMVarTempLimitDataValues.splice(_this.arrMVarTempLimitDataValues.indexOf(MVarTempLimitValue), 1);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 8 && item.BusinessDate == MVarTempLimitValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarTempLimitUpdateData = new clsUpdateData();
                MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarTempLimitUpdateData.BusinessDate = MVarTempLimitValue.BusinessDate;
                MVarTempLimitUpdateData.DateValue = MVarTempLimitValue.DateValue;
                MVarTempLimitUpdateData.InputDataType = 8;
                MVarTempLimitUpdateData.DividendPartner = null;
                MVarTempLimitUpdateData.Value = null;
                _this.arrYTDUpdateData.push(MVarTempLimitUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortMVarTempLimitValues();
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickPnlPPAAdd = function () {
        if (this.PnlPPARestatedMEYTDValue == undefined || this.PnlPPARestatedMEYTDValue == null || this.PnlPPARestatedMEYTDValue.toString().length == 0) {
            //alert("Value cannot be null");
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            var selectedPnlPPADate_1 = this.setDate(this.dtPnlPPATradingDate.toString());
            var selectedPnlPPAMonthEndDate = this.strPnlPPAMonthEndDate ? this.setDate(this.strPnlPPAMonthEndDate) : "";
            if (this.arrPnlPPADataValues.findIndex(function (pnlPPAValue) { return pnlPPAValue.BusinessDate == selectedPnlPPADate_1; }) != -1) {
                //alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                this.blnShowPopUp = true;
            }
            else {
                if (!isNaN(this.PnlPPARestatedMEYTDValue)) {
                    var PnlPPASelected = new clsHierarchyEditNode_Node_InputData_Values();
                    PnlPPASelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    PnlPPASelected.BusinessDate = selectedPnlPPADate_1;
                    PnlPPASelected.DateValue = selectedPnlPPAMonthEndDate;
                    PnlPPASelected.InputDataTypeEnum = 9;
                    PnlPPASelected.InputDataType = "Prior Period Adjustment";
                    PnlPPASelected.Published = false;
                    PnlPPASelected.Value = Number(this.PnlPPARestatedMEYTDValue);
                    this.arrPnlPPADataValues.push(PnlPPASelected);
                    this.selectedPnlPPAValue = PnlPPASelected;
                    var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 && item.BusinessDate == selectedPnlPPADate_1; });
                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var PnlPPAUpdateData = new clsUpdateData();
                    PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    PnlPPAUpdateData.BusinessDate = PnlPPASelected.BusinessDate;
                    PnlPPAUpdateData.DateValue = PnlPPASelected.DateValue;
                    PnlPPAUpdateData.InputDataType = 9;
                    PnlPPAUpdateData.DividendPartner = null;
                    PnlPPAUpdateData.Value = this.PnlPPARestatedMEYTDValue;
                    this.arrYTDUpdateData.push(PnlPPAUpdateData);
                    this.PnlPPARestatedMEYTDValue = null;
                    this.blnDisableSaveValue = false;
                    this.sortPnlPPAValues();
                }
                else {
                    //alert("Input value is not in a correct format.")
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "Input value is not in a correct format.";
                    this.blnShowPopUp = true;
                }
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickPnlPPAClear = function () {
        this.PnlPPARestatedMEYTDValue = null;
    };
    AppTprHierarchyEnterValueComponent.prototype.sortPnlPPAValues = function () {
        this.arrPnlPPADataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForPnlPPAValue = function (event) {
        //console.log(event);
        this.objPnlPPAValue = this.clonePnlPPAValue(event.data);
        this.displayDialogForPnlPPA = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.clonePnlPPAValue = function (objForClone) {
        var PnlPPAValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            PnlPPAValue[prop] = objForClone[prop];
        }
        return PnlPPAValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.savePnlPPAValue = function () {
        var _this = this;
        if (this.objPnlPPAValue.Value == undefined || this.objPnlPPAValue.Value == null || this.objPnlPPAValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objPnlPPAValue.Value)) {
                var PnlPPAValues = this.arrPnlPPADataValues.slice();
                PnlPPAValues[this.findSelectedPnlPPAValueIndex()] = this.objPnlPPAValue;
                this.arrPnlPPADataValues = PnlPPAValues;
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 && item.BusinessDate == _this.objPnlPPAValue.BusinessDate; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                this.selectedPnlPPAValue = this.objPnlPPAValue;
                var PnlPPAUpdateData = new clsUpdateData();
                PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                PnlPPAUpdateData.BusinessDate = this.objPnlPPAValue.BusinessDate;
                PnlPPAUpdateData.DateValue = this.objPnlPPAValue.DateValue;
                PnlPPAUpdateData.InputDataType = 9;
                PnlPPAUpdateData.DividendPartner = null;
                PnlPPAUpdateData.Value = this.objPnlPPAValue.Value;
                this.arrYTDUpdateData.push(PnlPPAUpdateData);
                this.objPnlPPAValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForPnlPPA = false;
            }
            else {
                //alert("Input value is not in a correct format.")
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedPnlPPAValueIndex = function () {
        var _this = this;
        var objPnlPPASelected = new clsHierarchyEditNode_Node_InputData_Values();
        objPnlPPASelected = this.arrPnlPPADataValues.find(function (x) { return x.BusinessDate == _this.objPnlPPAValue.BusinessDate; });
        //console.log(objPnlPPASelected);
        return this.arrPnlPPADataValues.indexOf(objPnlPPASelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deletePnlPPAValues = function (PnlPPAValue) {
        //console.log(PnlPPAValue);
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected restated month end amount will be deleted. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.arrPnlPPADataValues.splice(_this.arrPnlPPADataValues.indexOf(PnlPPAValue), 1);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 && item.BusinessDate == PnlPPAValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var PnlPPAUpdateData = new clsUpdateData();
                PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                PnlPPAUpdateData.BusinessDate = PnlPPAValue.BusinessDate;
                PnlPPAUpdateData.DateValue = PnlPPAValue.DateValue;
                PnlPPAUpdateData.InputDataType = 9;
                PnlPPAUpdateData.DividendPartner = null;
                PnlPPAUpdateData.Value = null;
                _this.arrYTDUpdateData.push(PnlPPAUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortPnlPPAValues();
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onDividendPartnerPPAChange = function () {
        var _this = this;
        var intPercentageValue = 0;
        var selectedDividendAllocation = new clsHierarchyEditNode_DividendPartnerAllocations_Values();
        var selectedPPATradingDate = this.setDate(this.dtTradingDateDividendPartnerPPA.toString());
        if (this.dividendPPA.findIndex(function (ppa) { return ppa.BusinessDate == selectedPPATradingDate
            && ppa.DividendPartnerName == _this.strSelectedDividendPartnerPPAName; }) != -1) {
            this.blnEnableDividendPPA = true;
        }
        else {
            if (this.strSelectedDividendPartnerPPAName && this.strSelectedDividendPartnerPPAName.toString() != "NotSet") {
                selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find(function (dividendAllocation) { return dividendAllocation.DividendPartnerNode.Name == _this.strSelectedDividendPartnerPPAName; });
                intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                this.blnEnableDividendPPA = false;
            }
            else {
                intPercentageValue = 0;
                this.blnEnableDividendPPA = true;
            }
        }
        this.strSelectedDividendPartnerPPAPercentage = intPercentageValue.toString();
    };
    AppTprHierarchyEnterValueComponent.prototype.sortDividendPPAValues = function () {
        this.dividendPPA.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendPPAAdd = function () {
        var _this = this;
        if (this.DividendPPARestatedMEValue == undefined || this.DividendPPARestatedMEValue == null || this.DividendPPARestatedMEValue.toString().length == 0) {
            //alert("Value cannot be null");
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.DividendPPARestatedMEValue)) {
                var selectedPPATradingDate_1 = this.setDate(this.dtTradingDateDividendPartnerPPA.toString());
                var ppaSelected_1 = new clsHierarchyEnterValue_DividendPPA();
                ppaSelected_1.BusinessDate = selectedPPATradingDate_1;
                ppaSelected_1.DividendPartnerName = this.strSelectedDividendPartnerPPAName;
                ppaSelected_1.RestatedMEDate = this.strDividendPPAMonthEndDate;
                ppaSelected_1.RestatedMEYTD = this.DividendPPARestatedMEValue;
                ppaSelected_1.CalculatedPPA = Number(this.strProjectedDividendPPA);
                this.dividendPPA.push(ppaSelected_1);
                this.selectedDividendPartnerPPA = ppaSelected_1;
                this.strSelectedDividendPartnerPPAName = "NotSet";
                this.DividendPPARestatedMEValue = null;
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 &&
                    item.BusinessDate == selectedPPATradingDate_1 && item.DividendPartner.Name == _this.strSelectedDividendPartnerPPAName; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var ppaUpdateData = new clsUpdateData();
                ppaUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ppaUpdateData.BusinessDate = ppaSelected_1.BusinessDate;
                ppaUpdateData.DateValue = ppaSelected_1.RestatedMEDate;
                ppaUpdateData.InputDataType = 9;
                ppaUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == ppaSelected_1.DividendPartnerName; });
                ppaUpdateData.Value = ppaSelected_1.RestatedMEYTD;
                this.arrYTDUpdateData.push(ppaUpdateData);
                this.blnDisableSaveValue = false;
                this.blnEnableDividendPPA = true;
                this.sortDividendPPAValues();
            }
            else {
                //alert("Input value is not in a correct format.")
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendPPAClear = function () {
        this.strSelectedDividendPartnerPPAName = "NotSet";
        this.DividendPPARestatedMEValue = null;
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForDividendPPAValue = function (event) {
        //console.log(event);
        this.objDividendPartnerPPAValue = this.cloneDividendPPAValue(event.data);
        this.displayDialogForDividendPPA = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneDividendPPAValue = function (objForClone) {
        var dividendPPAValue = new clsHierarchyEnterValue_DividendPPA();
        for (var prop in objForClone) {
            dividendPPAValue[prop] = objForClone[prop];
        }
        return dividendPPAValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveDividendPPAValue = function () {
        var _this = this;
        if (this.objDividendPartnerPPAValue.RestatedMEYTD == undefined || this.objDividendPartnerPPAValue.RestatedMEYTD == null || this.objDividendPartnerPPAValue.RestatedMEYTD.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Value cannot be null";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objDividendPartnerPPAValue.RestatedMEYTD)) {
                var dividendPPAValues = this.dividendPPA.slice();
                dividendPPAValues[this.findSelectedDividendPPAValueIndex()] = this.objDividendPartnerPPAValue;
                this.dividendPPA = dividendPPAValues;
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9
                    && item.BusinessDate == _this.objDividendPartnerPPAValue.BusinessDate && item.DividendPartner.Name == _this.strSelectedDividendPartnerPPAName; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                this.selectedDividendPartnerPPA = this.objDividendPartnerPPAValue;
                var ppaUpdateData = new clsUpdateData();
                ppaUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ppaUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.objDividendPartnerPPAValue.DividendPartnerName; });
                ppaUpdateData.InputDataType = 9;
                ppaUpdateData.BusinessDate = this.objDividendPartnerPPAValue.BusinessDate;
                ppaUpdateData.DateValue = this.objDividendPartnerPPAValue.RestatedMEDate;
                ppaUpdateData.Value = this.objDividendPartnerPPAValue.RestatedMEYTD;
                this.arrYTDUpdateData.push(ppaUpdateData);
                this.objDividendPartnerPPAValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForDividendPPA = false;
            }
            else {
                //alert("Input value is not in a correct format.")
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedDividendPPAValueIndex = function () {
        var _this = this;
        var objDividendPPASelected = new clsHierarchyEnterValue_DividendPPA();
        objDividendPPASelected = this.dividendPPA
            .find(function (x) { return x.BusinessDate == _this.objDividendPartnerPPAValue.BusinessDate
            && x.DividendPartnerName == _this.objDividendPartnerPPAValue.DividendPartnerName; });
        return this.dividendPPA.indexOf(objDividendPPASelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteDividendPartnerPPA = function (dividendPPARowValue) {
        //console.log(dividendPPARowValue);
        var _this = this;
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected restated month end amount will be deleted. Are you sure?',
            accept: function () {
                _this.blnShowConfirmation = false;
                _this.dividendPPA.splice(_this.dividendPPA.indexOf(dividendPPARowValue), 1);
                _this.objDividendPartnerPPAValue = null;
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9
                    && item.BusinessDate == dividendPPARowValue.BusinessDate && item.DividendPartner.Name == dividendPPARowValue.DividendPartnerName; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var trueUpUpdateData = new clsUpdateData();
                trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                trueUpUpdateData.BusinessDate = dividendPPARowValue.BusinessDate;
                trueUpUpdateData.DateValue = dividendPPARowValue.RestatedMEDate;
                trueUpUpdateData.InputDataType = 9;
                trueUpUpdateData.DividendPartner = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendPPARowValue.DividendPartnerName; });
                trueUpUpdateData.Value = null;
                _this.arrYTDUpdateData.push(trueUpUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortDividendPPAValues();
            },
            reject: function () {
                _this.blnShowConfirmation = false;
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onSelectDividendPartnerPPATradingDate = function () {
        this.strSelectedDividendPartnerPPAName = "NotSet";
        this.blnEnableDividendPPA = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.onChangeRestatedMonthEndValue = function (event) {
        //debugger;
        // let blnResult : boolean = this.onCustomNumericValidationForPositiveandNegativeIntegers(event);
        // if (blnResult) {
        //     console.log(event);
        // }
        this.strProjectedDividendPPA = (this.DividendPPARestatedMEValue - Number(this.strDividendPPAReportedMonthEnd)).toString();
    };
    AppTprHierarchyEnterValueComponent.prototype.setLockedStatus = function (data) {
        this.lockstatus = data.Result.NumericValue;
        console.log("set locked status", this.lockstatus);
        if (this.lockstatus == 1) {
            this.blnBusinessDateLocked = true;
        }
        else if (this.lockstatus == 0) {
            this.blnBusinessDateLocked = false;
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppTprHierarchyEnterValueComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/treeView/app.treeViewEnterValue.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRHierarchyservice_1.TPRHierarchyservice, router_1.Router, router_1.ActivatedRoute, app_TPRNodeTypeService_1.TPRNodeTypeService, primeng_1.ConfirmationService, app_regionService_1.RegionsService, app_TPRProfitAlertGroupsService_1.TPRProfitAlertGroupsService, app_TPRTagsService_1.TPRTagsService, app_TPRDividendPartnersService_1.TPRDividendPartnersService, app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService, app_TPRCommonService_1.TPRCommonService, app_treeView_component_1.AppTprHierarchyComponent, app_dashboardData_service_1.DashboardDataService])
    ], AppTprHierarchyEnterValueComponent);
    return AppTprHierarchyEnterValueComponent;
}());
exports.AppTprHierarchyEnterValueComponent = AppTprHierarchyEnterValueComponent;
var clsHierarchyEditNode_Node_InputData_Values = (function () {
    function clsHierarchyEditNode_Node_InputData_Values($type, Value, DateValue, BusinessDate, InputDataType, Published, InputDataTypeEnum, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Value === void 0) { Value = 0; }
        if (DateValue === void 0) { DateValue = null; }
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (InputDataType === void 0) { InputDataType = null; }
        if (Published === void 0) { Published = false; }
        if (InputDataTypeEnum === void 0) { InputDataTypeEnum = 1; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Value = Value;
        this.DateValue = DateValue;
        this.BusinessDate = BusinessDate;
        this.InputDataType = InputDataType;
        this.Published = Published;
        this.InputDataTypeEnum = InputDataTypeEnum;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node_InputData_Values;
}());
exports.clsHierarchyEditNode_Node_InputData_Values = clsHierarchyEditNode_Node_InputData_Values;
var clsUpdateData = (function () {
    function clsUpdateData() {
    }
    return clsUpdateData;
}());
exports.clsUpdateData = clsUpdateData;
var clsHierarchyNodeEnterValuePostData = (function () {
    function clsHierarchyNodeEnterValuePostData($type, Node, HierarchyType, UpdateData) {
        if ($type === void 0) { $type = null; }
        if (Node === void 0) { Node = null; }
        if (HierarchyType === void 0) { HierarchyType = null; }
        if (UpdateData === void 0) { UpdateData = []; }
        this.$type = $type;
        this.Node = Node;
        this.HierarchyType = HierarchyType;
        this.UpdateData = UpdateData;
    }
    return clsHierarchyNodeEnterValuePostData;
}());
exports.clsHierarchyNodeEnterValuePostData = clsHierarchyNodeEnterValuePostData;
var clsHierarchyNodeEnterValuePostData_UpdateData = (function () {
    function clsHierarchyNodeEnterValuePostData_UpdateData($type, DividendPartner, InputDataType, BusinessDate, Value, DateValue) {
        if ($type === void 0) { $type = null; }
        if (DividendPartner === void 0) { DividendPartner = null; }
        if (InputDataType === void 0) { InputDataType = 0; }
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (Value === void 0) { Value = 0; }
        if (DateValue === void 0) { DateValue = null; }
        this.$type = $type;
        this.DividendPartner = DividendPartner;
        this.InputDataType = InputDataType;
        this.BusinessDate = BusinessDate;
        this.Value = Value;
        this.DateValue = DateValue;
    }
    return clsHierarchyNodeEnterValuePostData_UpdateData;
}());
exports.clsHierarchyNodeEnterValuePostData_UpdateData = clsHierarchyNodeEnterValuePostData_UpdateData;
var clsHierarchyEnterValue_DividendTrueUp = (function () {
    function clsHierarchyEnterValue_DividendTrueUp(BusinessDate, DateValue, InputDataType, DividendPartnerName, Value, TrueUp, Updated, UpdatedBy) {
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (DateValue === void 0) { DateValue = null; }
        if (InputDataType === void 0) { InputDataType = null; }
        if (DividendPartnerName === void 0) { DividendPartnerName = null; }
        if (Value === void 0) { Value = 0; }
        if (TrueUp === void 0) { TrueUp = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        this.BusinessDate = BusinessDate;
        this.DateValue = DateValue;
        this.InputDataType = InputDataType;
        this.DividendPartnerName = DividendPartnerName;
        this.Value = Value;
        this.TrueUp = TrueUp;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
    }
    return clsHierarchyEnterValue_DividendTrueUp;
}());
exports.clsHierarchyEnterValue_DividendTrueUp = clsHierarchyEnterValue_DividendTrueUp;
var clsHierarchyEditNode_DividendPartnerAllocations_Values = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values;
}());
exports.clsHierarchyEditNode_DividendPartnerAllocations_Values = clsHierarchyEditNode_DividendPartnerAllocations_Values;
var clsHierarchyEnterValue_DividendPPA = (function () {
    function clsHierarchyEnterValue_DividendPPA(BusinessDate, DividendPartnerName, RestatedMEDate, RestatedMEYTD, CalculatedPPA, Updated, UpdatedBy) {
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (DividendPartnerName === void 0) { DividendPartnerName = null; }
        if (RestatedMEDate === void 0) { RestatedMEDate = null; }
        if (RestatedMEYTD === void 0) { RestatedMEYTD = 0; }
        if (CalculatedPPA === void 0) { CalculatedPPA = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        this.BusinessDate = BusinessDate;
        this.DividendPartnerName = DividendPartnerName;
        this.RestatedMEDate = RestatedMEDate;
        this.RestatedMEYTD = RestatedMEYTD;
        this.CalculatedPPA = CalculatedPPA;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
    }
    return clsHierarchyEnterValue_DividendPPA;
}());
exports.clsHierarchyEnterValue_DividendPPA = clsHierarchyEnterValue_DividendPPA;
//# sourceMappingURL=app.treeViewEnterValue.component.js.map