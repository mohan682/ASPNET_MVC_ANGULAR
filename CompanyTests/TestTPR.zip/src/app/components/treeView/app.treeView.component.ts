﻿import { Component, OnInit, PipeTransform, Pipe, Input, Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Footer } from 'primeng/primeng';
import { TreeModule } from 'primeng/primeng';
import { TreeNode } from 'primeng/primeng';
import { MenuModule, MenuItem } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService, DragDropModule } from 'primeng/primeng';
import { Message } from 'primeng/primeng';
import { TPRHierarchyservice } from '../../service/app.TPRHierarchyservice';
import { WorkDayService } from '../../service/app.workDayService';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';

import IUserRolesValue = CommonNameSpace.IUserRolesValue;
import IUserRolesValues = CommonNameSpace.IUserRolesValues;
import IUsersValue = CommonNameSpace.IUsersValue;
import IHolidayValue = HolidayNamespace.IHolidayValue;

import IRootObject = HierarchyNamespace.IRootObject;
import IHierarchyRemoveNode_Post = HierarchyNamespace.IHierarchyRemoveNode_Post;
import IModifiedRootObject = HierarchyNamespace.IModifiedRootObject;
import ITransposedRootObject = HierarchyNamespace.ITransposedRootObject;
import IFavourateNode_Post = HierarchyNamespace.IFavourateNode_Post;
import Children = HierarchyNamespace.Children;
import IHierarchyEditNode = HierarchyNamespace.IHierarchyEditNode;
import IHierarchyEditNode_Node = HierarchyNamespace.IHierarchyEditNode_Node;
import IHierarchyEditNode_Node_NodeType = HierarchyNamespace.IHierarchyEditNode_Node_NodeType;
import IHierarchyEditNode_Node_InputData = HierarchyNamespace.IHierarchyEditNode_Node_InputData;
import IHierarchyEditNode_Node_OutputData = HierarchyNamespace.IHierarchyEditNode_Node_OutputData;
import IHierarchyEditNode_Node_AllDatesForCurrentReportingDate = HierarchyNamespace.IHierarchyEditNode_Node_AllDatesForCurrentReportingDate;
import IHierarchyEditNode_Node_InputNameMappings = HierarchyNamespace.IHierarchyEditNode_Node_InputNameMappings;

import IHierarchyEditNode_Node_ProfitAlertGroup = HierarchyNamespace.IHierarchyEditNode_Node_ProfitAlertGroup;
import IHierarchyEditNode_Node_ProfitAlertGroup_Values = HierarchyNamespace.IHierarchyEditNode_Node_ProfitAlertGroup_Values;
import IHierarchyEditNode_Node_ProfitAlertGroup_Values_AlertGroups = HierarchyNamespace.IHierarchyEditNode_Node_ProfitAlertGroup_Values_AlertGroups;

var CircularJSON = require('circular-json');

@Component({
    selector: 'treeView',
    templateUrl: 'app/components/treeView/app.treeView.component.html'
})

@Injectable()
export class AppTprHierarchyComponent implements OnInit {
    public isRequesting: boolean;
    selectedNode: IRootObject = new RootValue();
    moveNode: IRootObject;
    targetNode: IRootObject;
    mainListOfTree: IRootObject[];
    mainListOfTreeForDisplay: IRootObject[];
    items: MenuItem[];
    mainNodeType: string;
    mainNodeStartDate: string;
    mainNodeId: number;
    hierarchy: any;
    blnMoveNode: boolean = false;
    blnAddToFavourites: boolean = false;
    intSelectedNodeID: number;
    searchNodeResults: string[] = [];
    filteredSearchNodeResults: string[];
    strSearchNodeText: string = '';
    nodeArrays: IRootObject[] = [];
    inactiveNodes: string[] = [];
    traversedPathArray: number[] = [];
    traversedPathArrayForNodeRemoval: number[] = [];
    isNodeMoved: boolean = false;
    arrFavouriteNodes: IRootObject[] = [];
    infoMoveNode: Message[] = [];
    displayMessage: boolean = false;
    isParent: boolean = false;
    favouriteNodesArray: string[] = [];
    lastSelectedNode: string = "";
    strFavouriteNodeSelect: string = "";
    userName: string = "";
    selectedFavouriteNode: string = "";
    actionItemsForNode: MenuItem[];
    blnShowInactiveNodes: boolean = false;
    // selectedNodeDetails: IHierarchyEditNode = new clsHierarchyEditNode();
    businessDate: string = "";
    blnDisableControlsTillPageLoads: boolean = true;
    moveNodeArrays: string[] = [];
    targetUpdateTimingAncestor: IRootObject;
    updateHierarchyMessage: string;
    updateHierarchyFlag: boolean = false;
    updateHierarchyHeader: string
    showUpdateHierarchyFooter: boolean = false;
    availableRoles: IUserRolesValues = new UserRolesValues();
    userRoles: string[] = [];
    public selectedUpdateTiming: number;
    constants: any;
    validDates: Date[];
    workingDates: Date[];
    holidays: IHolidayValue[] = [];
    canEditNode: boolean = false;
    canEnterValue: boolean = false;
    canEditHierarchy: boolean = false;

    node_ProfitAlertMappings: IHierarchyEditNode_Node_ProfitAlertGroup_Values[] = [];

    constructor(private tPRHierarchyservice: TPRHierarchyservice,
        private router: Router,
        private serviceHelper: ServiceHelper,
        private confirmationService: ConfirmationService,
        private workDayService: WorkDayService,
        private tPRcommonService: TPRCommonService) { }

    ngOnInit() {
        this.loadTree();
        this.items = [
            { label: 'Add Child', command: (event) => this.addChildSelectedContextMenu(this.selectedNode) },
            { label: 'Edit Node', command: (event) => this.editChildSelectedContextMenu(this.selectedNode) },
            { label: 'Remove Node', command: (event) => this.removeNodeSelectedContextMenu(this.selectedNode) },
            { label: 'Enter Value', command: (event) => this.enterValueSelectedContextMenu(this.selectedNode) },
            { label: 'Move Node', command: (event) => this.moveNodeSelectedContextMenu(this.selectedNode) },
            { label: 'Add To Favourites', command: (event) => this.addToFavouritesSelectedContextMenu(this.selectedNode) },
        ];

        this.actionItemsForNode = [
            { label: 'Add Child', command: (event) => this.addChildSelectedContextMenu(this.selectedNode) },
            { label: 'Edit Node', command: (event) => this.editChildSelectedContextMenu(this.selectedNode) },
            { label: 'Remove Node', command: (event) => this.removeNodeSelectedContextMenu(this.selectedNode) },
            { label: 'Enter Value', command: (event) => this.enterValueSelectedContextMenu(this.selectedNode) },
            { label: 'Move Node', command: (event) => this.moveNodeSelectedContextMenu(this.selectedNode) },
            { label: 'Add To Favourites', command: (event) => this.addToFavouritesSelectedContextMenu(this.selectedNode) }
        ];

        this.actionItemsForNode.forEach(action => {
            if (action.label == "Add Child" || action.label == "Edit Node" || action.label == "Remove Node" || action.label == "Enter Value" ||
                action.label == "Move Node") {
                action.disabled = true;
            }
        });

        this.businessDate = localStorage.getItem("BusinessDate");
    }

    public loadTree() {
        console.log("Loading Tree...");
        this.isRequesting = true;
        this.cleanup();
        this.isParent = false;
        this.infoMoveNode = [];
        this.moveNodeArrays = [];
        this.inactiveNodes = [];
        this.nodeArrays = [];
        this.isNodeMoved = false;
        this.displayMessage = false;
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(files => this.setNodeData(files));
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(files => this.setTreeData(files));
    }

    private cleanup() {
        this.showUpdateHierarchyFooter = false;
        this.updateHierarchyFlag = false;
        this.updateHierarchyMessage = null;
        this.updateHierarchyHeader = null;
        this.targetUpdateTimingAncestor = null;
    }

    setUserPreferenceData(data: any) {
        this.favouriteNodesArray = data.Result.Favourites.$values;
        this.lastSelectedNode = data.Result.LastSelectedNode;
        this.userName = data.Result.UserName;
        this.blnDisableControlsTillPageLoads = false;
    }

    private setTreeData(data: any): void {
        if (data.Result) {
            console.log("Tree Data->", data.Result.Children.$values);
            let hierarchyMain = data.Result.Children.$values;

            // call the service for getting node - profit alert group mapping
            this.tPRHierarchyservice.getHierarchyForProfitGroupsObservable().
                subscribe(files => this.updateNodeDataWithTooltip(hierarchyMain, files));
        }
    }

    public updateNodeDataWithTooltip(hierarchyMain: any, data: any) {
        //debugger;
        this.node_ProfitAlertMappings = data.Result.NodeWithAlertGroups.$values;
        //console.log("node_ProfitAlertMappings=>", this.node_ProfitAlertMappings);

        hierarchyMain.forEach((node: any) => {
            this.updateChildrenPropRecursive(node);
        });
        console.log("hierarchyMain ->", hierarchyMain);
        this.mainListOfTree = hierarchyMain;
    }

    public updateNodeDataWithTooltipForDisplay(hierarchyMain: any, data: any) {
        //debugger;
        this.node_ProfitAlertMappings = data.Result.NodeWithAlertGroups.$values;
        console.log("node_ProfitAlertMappings=>", this.node_ProfitAlertMappings);

        hierarchyMain.forEach((node: any) => {
            this.updateChildrenPropRecursive(node);
        });

        console.log("Hierarchy->", hierarchyMain);
        this.mainListOfTreeForDisplay = hierarchyMain;

        if (!this.blnShowInactiveNodes) {
            this.mainListOfTreeForDisplay.forEach(node => {
                node.icon = "murali mohan";
                this.removeInactiveNodes(node);
            });
        }

        this.updateNodeProps();

        this.stopRefreshing();
    }

    public getConstants(data: any): void {
        console.log("Constants ->", data);
        this.constants = data;
        this.AuthorizeUser();
    }

    private setNodeData(data: any): void {
        //debugger;
        if (data.Result) {
            console.log("Node Data->", data.Result.Children.$values);
            this.hierarchy = data.Result.Children.$values;
            // this.hierarchy.forEach((node: any) => {
            //     this.updateChildrenPropRecursive(node);
            // });

            // call the service for getting node - profit alert group mapping
            this.tPRHierarchyservice.getHierarchyForProfitGroupsObservable().
                subscribe(files => this.updateNodeDataWithTooltipForDisplay(this.hierarchy, files));

            this.searchNodeResults = data.Result.NodeNames.$values;
            this.mainNodeStartDate = data.Result.StartDate;
            this.mainNodeType = data.Result.Type;
            this.mainNodeId = data.Result.Id;

            this.tPRHierarchyservice.getUserPreferenceObservable()
                .subscribe(data => {
                    this.setUserPreferenceData(data);
                });

            this.workDayService.getWorkingDatesObservable()
                .subscribe(data => {
                    this.getWorkingDates(data);
                });

            if (localStorage.getItem("UserRole")) {
                this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
                console.log("User Roles from Local Storage ->", this.userRoles);
            }
            else {
                this.tPRcommonService.getUserRolesObservable()
                    .subscribe(data => this.setUserRolesData(data));
            }

            this.serviceHelper.importSettings()
                .subscribe(data => this.getConstants(data));
        }
        else if (data.Error) {
            this.updateHierarchyFlag = true;
            this.updateHierarchyHeader = "Error";
            this.updateHierarchyMessage = data.Error;
            this.showUpdateHierarchyFooter = false;
            this.stopRefreshing();
        }
    }

    private setUserRolesData(data: any): void {
        this.availableRoles.$values = [];
        this.availableRoles.$values = data.Result.UserRoles.$values;

        this.availableRoles.$values.forEach((role: any) => {
            this.userRoles.push(role.Name);
        });

        console.log("User Role ->", this.userRoles);
        localStorage.setItem("UserRole", JSON.stringify(this.userRoles));
    }

    private AuthorizeUser() {
        this.canEditNode = this.isUserAuthorised("EditNode");
        this.canEnterValue = this.isUserAuthorised("EnterValue");
        this.canEditHierarchy = this.isUserAuthorised("EditHierarchy");
    }

    public isUserAuthorised(action: string): boolean {
        console.log("Authorize Action ->", action);
        switch (action) {
            case "EditNode":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        this.userRoles.some(x => x == this.constants.TPRITSupport));
            case "EnterValue":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        this.userRoles.some(x => x == this.constants.TPRMarginManagement) ||
                        this.userRoles.some(x => x == this.constants.TPRRiskManagement));
            case "EditHierarchy":
                return this.userRoles != undefined && this.constants != undefined &&
                    this.userRoles.some(x => x == this.constants.TPRSuperUser);
            default: return false;
        }
    }

    getWorkingDates(data: any) {
        this.validDates = data.Result.Range.$values;
        localStorage.setItem("WorkingDates", JSON.stringify(this.validDates));

    }

    getPreviousorNextWorkingDay(initialDate: Date, isPrevious: boolean): Date {
        console.log("getPreviousorNextWorkingDay - Initial Date ->" + initialDate);
        let days = isPrevious ? -1 : 1;
        initialDate.setHours(0, 0, 0, 0);
        initialDate.setDate(initialDate.getDate() + days);

        if (localStorage.getItem("WorkingDates") && localStorage.getItem("Holidays")) {

            if (JSON.parse(localStorage.getItem("WorkingDates"))) {
                this.validDates = JSON.parse(localStorage.getItem("WorkingDates"));
            }

            if (JSON.parse(localStorage.getItem("Holidays"))) {
                this.holidays = JSON.parse(localStorage.getItem("Holidays"));
            }

            console.log("Working Dates ->", this.validDates);
            while (this.validDates && this.holidays && this.validDates.length > 0 && this.holidays.length > 0) {
                if (this.validDates.some(d => ((new Date(d)).setHours(0, 0, 0, 0) == initialDate.setHours(0, 0, 0, 0)))
                    && !this.holidays.some(d => (d.Region == null && this.tPRcommonService.getFormattedSystemDate_Date(new Date(d.Date)) == this.tPRcommonService.getFormattedSystemDate_Date(initialDate)))) {
                    break;
                }
                initialDate.setDate(initialDate.getDate() + days);
            }
        }
        else {
            console.log("Unable to retrieve holiday and working dates date from local storage");
        }

        return initialDate;
    }

    updateChildrenPropRecursive(node: any) {
        node.Children = node.Children.$values;
        node.children = node.Children;
        node.label = node.NodeName;

        node.toolTipText = (" Name: " + node.NodeName + " \n Type: " + node.NodeType);

        if (node.UpdateTiming != null) {
            node.toolTipText += ("\n Update timing:  R" + (node.UpdateTiming));
        }
        if (node.MVarUpdateTiming != null) {
            node.toolTipText += ("\n MVAR update timing:  R" + (node.MVarUpdateTiming));
        }

        let node_Profit_Data: IHierarchyEditNode_Node_ProfitAlertGroup_Values = new clsHierarchyEditNode_Node_ProfitAlertGroup_Values();
        node_Profit_Data = this.node_ProfitAlertMappings.find(nodePFA => nodePFA.NodeId == node.NodeId);

        if (node_Profit_Data && node_Profit_Data.FormettedAlertGroups && node_Profit_Data.FormettedAlertGroups.length > 0) {
            //debugger;
            node.toolTipText += ("\n Profit Alerts : ");
            // node_Profit_Data.AlertGroups.$values.forEach(alerts => {
            //     node.toolTipText += ((alerts) + ", ");
            // });
            node.toolTipText += node_Profit_Data.FormettedAlertGroups;
        }

        if (node.Children) {
            node.Children.forEach((childNode: any) => {
                this.updateChildrenPropRecursive(childNode);
            });
        }
    }

    updateNodeProps() {
        this.mainListOfTreeForDisplay.forEach(node => {
            this.AddNodeToArray(node);
        });
    }

    private AddNodeToArray(node: IRootObject) {
        this.nodeArrays.push({
            label: node.NodeName,
            $type: node.type,
            Children: node.Children,
            HasAnyOutputData: node.HasAnyOutputData,
            HasPlans: node.HasPlans,
            Level: node.Level,
            MVarUpdateTiming: node.MVarUpdateTiming,
            IsActive: node.IsActive,
            IsPnlHolder: node.IsPnlHolder,
            NodeId: node.NodeId,
            NodeType: node.NodeType,
            SplitType: node.SplitType,
            UpdateTiming: node.UpdateTiming,
            children: node.children,
            collapsedIcon: "fa-plus-square",
            data: node.data,
            expanded: node.expanded,
            expandedIcon: "fa-minus-square",
            icon: node.icon,
            id: node.id,
            leaf: node.leaf,
            parent: node.parent,
            Id: node.Id,
            ParentId: node.ParentId,
            NodeName: node.NodeName,
            type: node.type,
            partialSelected: node.partialSelected
        });

        node.children = node.Children;
        if (node.children) {
            node.children.forEach(childNode => {
                this.AddNodeToArray(childNode);
            });
        }
    }

    expandAll() {
        debugger;
        this.isRequesting = true;
        // this.stopRefreshing();
        setTimeout(() => {
            this.mainListOfTreeForDisplay.forEach(node => { this.expandRecursive(node, true) });
            this.stopRefreshing();
        }, 3000);
    }

    collapseAll() {

        this.isRequesting = true;
        // this.stopRefreshing();
        setTimeout(() => {
            this.mainListOfTreeForDisplay.forEach(node => { this.expandRecursive(node, false) });
            this.stopRefreshing();
        }, 3000);

        // this.mainListOfTreeForDisplay.forEach(node => {
        //     this.expandRecursive(node, false);
        // });
    }

    reloadAll() {
        this.loadTree();
        this.actionItemsForNode.forEach(action => {
            if (action.label == "Add Child" || action.label == "Edit Node" || action.label == "Remove Node" || action.label == "Enter Value" ||
                action.label == "Move Node") {
                action.disabled = true;
            }
        });

        this.businessDate = localStorage.getItem("BusinessDate");
    }

    private expandRecursive(node: IRootObject, isExpand: boolean) {
        node.expanded = isExpand;
        if (node.children) {
            node.children.forEach(childNode => {
                this.expandRecursive(childNode, isExpand);
            });
        }
    }

    private removeInactiveNodes(node: IRootObject) {
        if (node.children) {

            node.Children.filter(c => (!c.IsActive)).forEach(inactiveNode => {
                this.inactiveNodes.push(inactiveNode.NodeName.toUpperCase());
            });

            node.Children = node.Children.filter(c => c.IsActive);
            node.children.forEach(childNode => {
                this.removeInactiveNodes(childNode);
            });
        }
    }

    private expandRecursiveForSearch(node: IRootObject, isExpanded: boolean) {
        node.expanded = this.traversedPathArray.find(item => item == node.Id) ? isExpanded : !isExpanded;

        if (node.NodeName.toUpperCase() == this.strSearchNodeText.toUpperCase()) {
            this.selectedNode = node;
            node.expanded = !isExpanded;
        }

        if (node.children) {
            node.children.forEach(childNode => {
                this.expandRecursiveForSearch(childNode, isExpanded);
            });
        }
    }

    private expandRecursiveForLastEditedNodeSearch(node: IRootObject, isExpanded: boolean) {
        node.expanded = this.traversedPathArray.find(item => item == node.Id) ? isExpanded : !isExpanded;

        if (node.NodeName.toUpperCase() == this.lastSelectedNode.toUpperCase()) {
            this.selectedNode = node;
            node.expanded = !isExpanded;
        }

        if (node.children) {
            node.children.forEach(childNode => {
                this.expandRecursiveForLastEditedNodeSearch(childNode, isExpanded);
            });
        }
    }

    private expandRecursiveForFavouriteNodeSearch(node: IRootObject, isExpanded: boolean) {
        node.expanded = this.traversedPathArray.find(item => item == node.Id) ? isExpanded : !isExpanded;

        if (node.NodeName.toUpperCase() == this.strFavouriteNodeSelect.toUpperCase()) {
            this.selectedNode = node;
            node.expanded = !isExpanded;
        }

        if (node.children) {
            node.children.forEach(childNode => {
                this.expandRecursiveForFavouriteNodeSearch(childNode, isExpanded);
            });
        }
    }

    getUpdateTimingFromHierarchyForNode(Id: number): number {
        let nodeArray: IRootObject;
        nodeArray = this.nodeArrays.find(node => node.Id == Id);

        if (nodeArray && this.selectedUpdateTiming == null) {
            if (!nodeArray.UpdateTiming) {
                this.getUpdateTimingFromHierarchyForNode(nodeArray.ParentId);
            }
            else {
                this.selectedUpdateTiming = nodeArray.UpdateTiming;
            }
        }

        return this.selectedUpdateTiming;
    }

    private setActions() {
        this.enableActionsForNode();
        this.setContextMenuItemsForNode();
    }

    /*This method will be called when the user clicks(left click) on any of the node item.*/
    private nodeSelect(event: any): void {
        this.intSelectedNodeID = this.selectedNode.NodeId;
        // this.getSelectedNodeDetails();
        this.setActions();
    }

    /*This method will be called when the user clicks (right click) on any of the node item.*/
    private nodeContextMenuSelect(event: any): void {
        // this.isRequesting = true; //EH
        console.log("is requesting value is", this.isRequesting);
        this.items.forEach(item => {
            //item.disabled = false; //EH
            item.disabled = true; //EH 
        });
        this.actionItemsForNode.forEach(action => {
            if (action.label == "Add Child" || action.label == "Edit Node" || action.label == "Remove Node" || action.label == "Enter Value" ||
                action.label == "Move Node") {
                action.disabled = true;
            }
        }); //EH

        this.intSelectedNodeID = this.selectedNode.NodeId;
        this.setActions();
        // this.getSelectedNodeDetails();
    }

    // setNodeLevelData(data: any) {
    //     this.selectedNodeDetails = data.Result;
    //     this.enableActionsForNode();
    //     this.setContextMenuItemsForNode();
    // }

    filterNodes(event: any) {
        this.filteredSearchNodeResults = [];
        for (let i = 0; i < this.searchNodeResults.length; i++) {
            let node = this.searchNodeResults[i];
            if (node.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
                this.filteredSearchNodeResults.push(node);
            }
        }
    }

    handleFilterNodeDropdownClick(event: any) {
        this.filteredSearchNodeResults = [];
        this.filteredSearchNodeResults = this.searchNodeResults;
    }

    OnNodeSearch() {
        console.log("search Node ->", this.strSearchNodeText);
        if (this.strSearchNodeText != null && this.strSearchNodeText.trim().length > 0) {
            this.isRequesting = true;
            this.traversedPathArray = [];
            let nodeSearched = this.nodeArrays.find(node => node.NodeName.toUpperCase() == this.strSearchNodeText.toUpperCase());

            if (nodeSearched) {
                this.intSelectedNodeID = nodeSearched.NodeId;
                this.appendToTraversedArray(nodeSearched.Id, nodeSearched.ParentId);
                this.mainListOfTreeForDisplay.forEach(node => this.expandRecursiveForSearch(node, true));
                // this.getSelectedNodeDetails();
                this.setActions();
            }
            else if (this.inactiveNodes.some(node => node == this.strSearchNodeText.toUpperCase()) && !this.blnShowInactiveNodes) {
                console.log('Inactive Node found!');
                this.updateHierarchyHeader = 'Inactive Node!';
                this.updateHierarchyMessage = "The searched Node - " + this.strSearchNodeText + " is inactive. Please enable 'Show Inactive Nodes'.";
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
            else {
                console.log('Node not found!');
                this.updateHierarchyHeader = 'Node not found!';
                this.updateHierarchyMessage = "Node - " + this.strSearchNodeText + " is not found.";
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
        }
    }

    OnLastEditedNodeFind() {
        this.isRequesting = true;
        this.traversedPathArray = [];
        let nodeSearched = this.nodeArrays.find(node => node.NodeName.toUpperCase() == this.lastSelectedNode.toUpperCase());
        if (nodeSearched) {
            this.intSelectedNodeID = nodeSearched.NodeId;
            this.appendToTraversedArray(nodeSearched.Id, nodeSearched.ParentId);
            this.mainListOfTreeForDisplay.forEach(node => this.expandRecursiveForLastEditedNodeSearch(node, true));
            // this.getSelectedNodeDetails();
            this.setActions();
        }
        else if (this.inactiveNodes.some(node => node == this.lastSelectedNode.toUpperCase()) && !this.blnShowInactiveNodes) {
            console.log('Inactive Node found!');
            this.updateHierarchyHeader = 'Inactive Node!';
            this.updateHierarchyMessage = "The searched Node - " + this.lastSelectedNode + " is inactive. Please enable 'Show Inactive Nodes'.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            this.stopRefreshing();
        }
        else {
            this.updateHierarchyFlag = true;
            this.updateHierarchyHeader = "Search Results";
            this.updateHierarchyMessage = "The node - " + this.lastSelectedNode + " is not found.";
            this.showUpdateHierarchyFooter = false;
            this.stopRefreshing();
        }
    }

    OnFavouriteNodeSelect() {
        this.isRequesting = true;
        this.traversedPathArray = [];
        if (this.strFavouriteNodeSelect) {
            let nodeSearched = this.nodeArrays.find(node => node.NodeName.toUpperCase() == this.strFavouriteNodeSelect.toUpperCase());

            if (nodeSearched) {
                this.intSelectedNodeID = nodeSearched.NodeId;
                this.appendToTraversedArray(nodeSearched.Id, nodeSearched.ParentId);
                this.mainListOfTreeForDisplay.forEach(node => this.expandRecursiveForFavouriteNodeSearch(node, true));
                // this.getSelectedNodeDetails();
                this.setActions();
            }
            else if (this.inactiveNodes.some(node => node == this.strFavouriteNodeSelect.toUpperCase()) && !this.blnShowInactiveNodes) {
                console.log('Inactive Node found!');
                this.updateHierarchyHeader = 'Inactive Node!';
                this.updateHierarchyMessage = "The searched Node - " + this.strFavouriteNodeSelect + " is inactive. Please enable 'Show Inactive Nodes'.";
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
            else {
                this.updateHierarchyFlag = true;
                this.updateHierarchyHeader = "Search Results";
                this.updateHierarchyMessage = "The node - " + this.strFavouriteNodeSelect + " is not found.";
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            }
        }
    }

    appendToTraversedArray(Id: number, parentId: number) {
        this.traversedPathArray.push(Id);
        let parentNode = this.nodeArrays.find(node => node.Id == parentId);
        if (parentNode) {
            this.appendToTraversedArray(parentNode.Id, parentNode.ParentId);
        }
    }

    appendToTraversedArrayForNodeRemoval(Id: number, parentId: number) {
        this.traversedPathArrayForNodeRemoval.push(Id);
        let parentNode = this.nodeArrays.find(node => node.Id == parentId);
        if (parentNode) {
            this.appendToTraversedArrayForNodeRemoval(parentNode.Id, parentNode.ParentId);
        }
    }

    CheckIfParentAndChild(targetNodeId: number) {
        if (targetNodeId > 0) {
            let childNode = this.nodeArrays.find(node => node.Id == targetNodeId);
            if (childNode && childNode.ParentId != null && !this.isParent && childNode.ParentId == this.moveNode.Id) {
                this.isParent = true;
            }
            else {
                this.CheckIfParentAndChild(childNode.ParentId);
            }
        }
    }

    OnClearNodeSearch() {
        this.strSearchNodeText = ''
    }

    private addChildSelectedContextMenu(SelectedFile: IRootObject): void {
        this.lastSelectedNode = SelectedFile.NodeName;
        this.OnFavouriteNodeSave();
        this.router.navigate(['/hierarchy/addChild', this.intSelectedNodeID]);
    }

    private editChildSelectedContextMenu(SelectedFile: IRootObject): void {
        this.lastSelectedNode = SelectedFile.NodeName;
        this.OnFavouriteNodeSave();
        this.router.navigate(['/hierarchy/editNode', this.intSelectedNodeID]);
    }

    private enterValueSelectedContextMenu(SelectedFile: IRootObject): void {
        this.lastSelectedNode = SelectedFile.NodeName;
        this.OnFavouriteNodeSave();
        this.router.navigate(['/hierarchy/enterValue', this.intSelectedNodeID]);
    }

    private moveNodeSelectedContextMenu(SelectedFile: IRootObject): void {
        console.log("Begin Moving");
        this.moveNode = SelectedFile;

        console.log("moveNodeSelectedContextMenu->", this.moveNode);
        this.items.push({ label: 'Drop Node', command: (event) => this.dropNodeSelectedContextMenu(this.selectedNode) });
        this.actionItemsForNode.push({ label: 'Drop Node', command: (event) => this.dropNodeSelectedContextMenu(this.selectedNode) });
        let moveMenuitem = this.items.find(x => x.label == "Move Node");
        this.items.splice(this.items.indexOf(moveMenuitem ), 1);

        moveMenuitem = this.actionItemsForNode.find(x => x.label == "Move Node");
        this.actionItemsForNode.splice(this.actionItemsForNode.indexOf(moveMenuitem ), 1);
        this.isNodeMoved = true;
        this.infoMoveNode = [];
        this.infoMoveNode.push({ severity: 'info', summary: 'Info Message', detail: "Moving Node: " + this.moveNode.NodeName + ". Select a drop target or use 'Cancel Move' button to cancel the move." });

        this.updateHierarchyFlag = false;
    }

    private cancelNodeMove() {
        console.log("Cancel Moving");
        this.infoMoveNode = [];
        this.infoMoveNode.push({ severity: 'info', summary: 'Info Message', detail: "Moving Node: " + this.moveNode.NodeName + " is cancelled." });
        this.moveNode = this.selectedNode;
        let dropMenuitem = this.items.find(x => x.label == "Drop Node");
        this.items.splice(this.items.indexOf(dropMenuitem), 1);
        this.items.push({ label: 'Move Node', command: (event) => this.moveNodeSelectedContextMenu(this.selectedNode) });

        dropMenuitem = this.actionItemsForNode.find(x => x.label == "Drop Node");
        this.actionItemsForNode.splice(this.actionItemsForNode.indexOf(dropMenuitem), 1);
        this.actionItemsForNode.push({ label: 'Move Node', command: (event) => this.moveNodeSelectedContextMenu(this.selectedNode) });

        this.isNodeMoved = false;
        this.updateHierarchyFlag = false;
        this.updateHierarchyMessage = null;
        this.updateHierarchyHeader = null;
        this.showUpdateHierarchyFooter = false;
    }

    private updateMoveNodeFromMainTree(tempNode: IRootObject): void {
        if (tempNode) {
            if (tempNode.Id == this.moveNode.Id) {
                console.log("Move Node is updated");
                this.moveNode = tempNode;
            }
            else if (tempNode.Id == this.targetNode.Id) {
                console.log("Target Node is updated");
                this.targetNode = tempNode;
            }
            else if (tempNode.children) {
                tempNode.children.forEach(childNode => {
                    this.updateMoveNodeFromMainTree(childNode);
                });
            }
        }
    }

    private getChildrenWithPlans(selectedNode: IRootObject): void {
        if (selectedNode.Id > 0) {
            if (selectedNode.children) {
                selectedNode.Children.forEach(childNode => {
                    if (this.moveNodeArrays.indexOf(childNode.NodeName) == -1 && childNode.HasPlans) {
                        this.moveNodeArrays.push(childNode.NodeName);
                    }
                    this.getChildrenWithPlans(childNode);
                });
            }
        }
    }

    private getAncestorWithPlans(selectedNode: IRootObject): void {
        let currentLevel = selectedNode.Level;
        let newParent = selectedNode.ParentId;

        do {
            let parentNode = this.nodeArrays.find(node => node.Id == newParent);
            if (parentNode) {
                if (this.moveNodeArrays.indexOf(parentNode.NodeName) == -1 && parentNode.HasPlans) {
                    this.moveNodeArrays.push(parentNode.NodeName);
                }
                newParent = parentNode.ParentId;
            }
            currentLevel--;
        } while (currentLevel > 0);
    }

    public getNodesWithPlans(selectedNode: IRootObject): void {
        this.getChildrenWithPlans(selectedNode);
        this.getAncestorWithPlans(selectedNode);
    }

    private validateAndDrop(targetNode: IRootObject): boolean {
        console.log("Begin Validation");
        let result = true;
        if (targetNode.IsPnlHolder) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + this.moveNode.NodeName + " cannot be moved to node " + targetNode.NodeName + " because the target node is a PNL holder.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }

        if (this.moveNode.ParentId == targetNode.Id) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + targetNode.NodeName + " is already a parent for the node " + this.moveNode.NodeName;
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }

        console.log("parentID->", this.selectedNode.ParentId);
        if (this.selectedNode.ParentId == 0) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + this.moveNode.NodeName + " cannot be moved to the root node.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }

        this.isParent = false;
        this.CheckIfParentAndChild(targetNode.Id);

        if (this.isParent) {
            this.updateHierarchyHeader = 'Validation Error';
            this.updateHierarchyMessage = "The node " + this.moveNode.NodeName + " cannot be moved to node " + targetNode.NodeName + " because the target node is it's child.";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = false;
            result = false;
        }

        return result;
    }

    private GetUpdateTimingAncestor(targetNodeId: number) {
        let nodeArray: IRootObject;
        nodeArray = this.nodeArrays.find(node => node.Id == targetNodeId);

        if (nodeArray && this.targetUpdateTimingAncestor == null) {
            if (!nodeArray.UpdateTiming) {
                this.GetUpdateTimingAncestor(nodeArray.ParentId);
            }
            else {
                this.targetUpdateTimingAncestor = nodeArray;
            }
        }
    }

    private dropNodeSelectedContextMenu(SelectedFile: IRootObject): void {
        console.log("Begin Drop");
        this.moveNodeArrays = [];
        this.targetNode = SelectedFile;

        console.log("Update Move Node from Main Tree");
        this.mainListOfTree.forEach(node => {
            this.updateMoveNodeFromMainTree(node);
        });

        let result = this.validateAndDrop(this.targetNode);
        console.log("Validation Result ->", result);
        /* if (result == true && SelectedFile.ParentId != null && this.moveNode.ParentId != null) {*/
        if (result == true) {
            this.isNodeMoved = false;
            if (this.moveNodeArrays.indexOf(this.moveNode.NodeName) == -1 && this.moveNode.HasPlans) {
                this.moveNodeArrays.push(this.moveNode.NodeName);
            }
            this.getNodesWithPlans(this.moveNode);
            if (this.moveNodeArrays.indexOf(this.targetNode.NodeName) == -1 && this.targetNode.HasPlans) {
                this.moveNodeArrays.push(SelectedFile.NodeName);
            }
            this.getNodesWithPlans(this.targetNode);
            console.log("dropNodeSelectedContextMenu->", this.targetNode);
            let dropMenuitem = this.items.find(x => x.label == "Drop Node");
            this.items.splice(this.items.indexOf(dropMenuitem), 1);
            this.items.push({ label: 'Move Node', command: (event) => this.moveNodeSelectedContextMenu(this.selectedNode) });

            dropMenuitem = this.actionItemsForNode.find(x => x.label == "Drop Node");
            this.actionItemsForNode.splice(this.actionItemsForNode.indexOf(dropMenuitem), 1);
            this.actionItemsForNode.push({ label: 'Move Node', command: (event) => this.moveNodeSelectedContextMenu(this.selectedNode) });
            console.log("Plan Nodes ->", this.moveNodeArrays);

            this.targetUpdateTimingAncestor = null;
            this.GetUpdateTimingAncestor(this.targetNode.Id);
            console.log("targetUpdateTimingAncestor->", this.targetUpdateTimingAncestor);

            let moveInfo = "The node " + this.moveNode.NodeName + " will be moved to node " + this.targetNode.NodeName + ".";

            if (this.moveNodeArrays.length > 0) {
                moveInfo = (moveInfo + "\n" + "The target node or the branch contains plan values. The node you are moving also contains a plan. This will cause the plans to overlap. Are you happy to proceed with this move? The following node(s) contain plan values: ")
                this.moveNodeArrays.forEach(planNode => {
                    moveInfo = (moveInfo + "\n" + planNode);
                });
            }

            moveInfo = (this.targetNode.UpdateTiming != null || this.targetUpdateTimingAncestor.UpdateTiming != null) ?
                (moveInfo + "\n" + "Please note that by moving this node in the hierarchy, you will change the Update Timing of all children of the parent, overwriting any Update Timing that has previously been set." +
                    "The Update Timing is used to tell TPR for which Trading Dates data in relation to the Reporting Date to expect.")
                : moveInfo;

            moveInfo = moveInfo + "\n" + "Saving an update to hierarchy. Would you like to proceed?";

            this.updateHierarchyMessage = moveInfo.toString();
            this.updateHierarchyHeader = "Updating Hierarchy";
            this.updateHierarchyFlag = true;
            this.showUpdateHierarchyFooter = true;
        }
        else {

        }
    }

    private commitDropNodeAtTarget() {

        this.mainListOfTree.forEach(node => this.updateArrayForNodeDrop(node));
        this.mainListOfTree.forEach(node => this.preparePostTreeData(node));
        this.updateHierarchyMessage = "Moving node " + this.moveNode.NodeName + " to " + this.targetNode.NodeName + "...";
        this.showUpdateHierarchyFooter = false;
        console.log("Updated Hierarchy ->", this.mainListOfTree);

        let objclsHierarchyRemoveNode_Post: clsHierarchyRemoveNode_Post = new clsHierarchyRemoveNode_Post();

        objclsHierarchyRemoveNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightHierarchyInstanceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        console.log("mainListOfTree ->", this.mainListOfTree);
        objclsHierarchyRemoveNode_Post.Children = this.mainListOfTree;
        objclsHierarchyRemoveNode_Post.NodeNames = this.searchNodeResults;
        objclsHierarchyRemoveNode_Post.Type = this.mainNodeType;
        objclsHierarchyRemoveNode_Post.StartDate = this.mainNodeStartDate;
        objclsHierarchyRemoveNode_Post.Id = this.mainNodeId;

        var postData = CircularJSON.stringify(objclsHierarchyRemoveNode_Post);

        this.tPRHierarchyservice.updateLightWeight(postData)
            .subscribe((response: any) => {
                console.log(response);
                if (response.Error) {
                    this.updateHierarchyHeader = 'Error';
                    this.updateHierarchyMessage = response.Error;
                    this.updateHierarchyFlag = true;
                    this.showUpdateHierarchyFooter = false;
                    this.stopRefreshing();
                }
                else {
                    console.log('Node ' + this.moveNode.NodeName + ' is moved successfully to ' + this.targetNode.NodeName);
                    this.loadTree();
                    this.updateHierarchyHeader = 'Success';
                    this.updateHierarchyMessage = 'Node ' + this.moveNode.NodeName + ' is moved successfully to ' + this.targetNode.NodeName;
                    this.updateHierarchyFlag = true;
                    this.isNodeMoved = false;
                    console.log("Node Array->", this.nodeArrays);
                }
            },
            (error) => {
                console.log(error);
                this.updateHierarchyHeader = 'Error';
                this.updateHierarchyMessage = error;
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.isNodeMoved = false;
                this.stopRefreshing();
            });
    }

    private addToFavouritesSelectedContextMenu(SelectedFile: IRootObject): void {
        console.log(SelectedFile);
        let index: number = this.favouriteNodesArray.indexOf(SelectedFile.NodeName);
        if (index == -1) {
            this.favouriteNodesArray.push(SelectedFile.NodeName);
        }
        this.OnFavouriteNodeSave();
    }

    private commitRemoveNode() {
        let nodeTobeRemoved = this.selectedNode.NodeName;
        console.log("Removing Node ->", this.selectedNode);
        this.mainListOfTree.forEach(node => this.updateArrayForNodeRemoval(node));
        console.log("Updated Hierarchy ->", this.mainListOfTree);
        this.updateHierarchyMessage = "Updating Hierarchy...";
        this.showUpdateHierarchyFooter = false;
        let objclsHierarchyRemoveNode_Post: clsHierarchyRemoveNode_Post = new clsHierarchyRemoveNode_Post();

        objclsHierarchyRemoveNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightHierarchyInstanceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        console.log("mainListOfTree ->", this.mainListOfTree);
        objclsHierarchyRemoveNode_Post.Children = this.mainListOfTree;
        objclsHierarchyRemoveNode_Post.NodeNames = this.searchNodeResults;
        objclsHierarchyRemoveNode_Post.Type = this.mainNodeType;
        objclsHierarchyRemoveNode_Post.StartDate = this.mainNodeStartDate;
        objclsHierarchyRemoveNode_Post.Id = this.mainNodeId;

        var postData = CircularJSON.stringify(objclsHierarchyRemoveNode_Post);
        console.log("Post Data ->", postData);

        this.tPRHierarchyservice.updateLightWeight(postData)
            .subscribe((response: any) => {
                console.log(response);
                if (response.Error) {
                    this.updateHierarchyHeader = 'Error';
                    this.updateHierarchyMessage = response.Error;
                    this.updateHierarchyFlag = true;
                    this.showUpdateHierarchyFooter = false;
                    this.stopRefreshing();
                }
                else {
                    console.log("The node " + nodeTobeRemoved + " is deleted successfully");
                    this.loadTree();
                    this.lastSelectedNode = null;
                    this.OnFavouriteNodeSave();
                    this.updateHierarchyHeader = 'Success';
                    this.updateHierarchyMessage = "The node " + nodeTobeRemoved + " is deleted successfully";
                    this.updateHierarchyFlag = true;
                    this.showUpdateHierarchyFooter = false;
                }
            },
            (error) => {
                console.log(error);
                this.updateHierarchyHeader = 'Error';
                this.updateHierarchyMessage = error;
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
                this.stopRefreshing();
            });
    }

    private cancelNodeReMove() {
        console.log("Cancel Removing");
        this.updateHierarchyFlag = false;
        this.updateHierarchyMessage = null;
        this.updateHierarchyHeader = null;
        this.showUpdateHierarchyFooter = false;
    }

    private removeNodeSelectedContextMenu(SelectedFile: IRootObject): void {
        this.updateHierarchyFlag = true;
        this.updateHierarchyHeader = "Removing Node";
        this.updateHierarchyMessage = "The node " + SelectedFile.NodeName + " will be deleted. Are you sure?";
        this.showUpdateHierarchyFooter = true;
    }

    private stopRefreshing() {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    updateHierarchy() {
        console.log("updateHierarchy");
        this.isRequesting = true;
        if (this.updateHierarchyHeader == "Removing Node") {
            this.commitRemoveNode();
        }
        else if (this.updateHierarchyHeader == "Updating Hierarchy") {
            this.commitDropNodeAtTarget();
        }
    }

    CancelUpdateHierarchy() {
        console.log("CancelUpdateHierarchy");
        if (this.updateHierarchyHeader == "Removing Node") {
            this.cancelNodeReMove();
        }
        else if (this.updateHierarchyHeader == "Updating Hierarchy") {
            this.cancelNodeMove();
        }
    }

    private updateArrayForNodeRemoval(filteredNode: IRootObject) {
        filteredNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        if (filteredNode.Id == this.selectedNode.ParentId) {
            filteredNode.Children.splice(filteredNode.Children.indexOf(this.selectedNode), 1);
        }
        delete filteredNode.children;
        delete filteredNode.parent;

        if (filteredNode.Children) {
            filteredNode.Children.forEach(childNode => {
                this.updateArrayForNodeRemoval(childNode);
            });
        }
    }

    private preparePostTreeData(node: IRootObject) {
        delete node.children;
        delete node.parent;
        if (node.Children) {
            node.Children.forEach(childNode => {
                this.preparePostTreeData(childNode);
            });
        }
    }

    private updateArrayForNodeDrop(filteredNode: IRootObject) {
        filteredNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

        if (filteredNode.Id == this.moveNode.ParentId) {
            delete this.moveNode.children;
            delete this.moveNode.parent;
            filteredNode.Children.splice(filteredNode.Children.indexOf(this.moveNode), 1);
            this.moveNode.ParentId = this.targetNode.Id;
            this.targetNode.Children.push(this.moveNode);
        }
        delete filteredNode.children;
        delete filteredNode.parent;

        if (filteredNode.Children) {
            filteredNode.Children.forEach(childNode => {
                this.updateArrayForNodeDrop(childNode);
            });
        }
    }

    private updateProperties(filteredNode: any) {
        let array = filteredNode.Children;
        if (array.$values.length > 0) {
            let obj: clsTransposedRootObject = <clsTransposedRootObject>JSON.parse(JSON.stringify(filteredNode));
            delete obj.Children;

            obj.Children = array.$values;
            console.log(obj);
        }
    }

    private onRowSelectForFavouriteNode(event: any) {
        this.strFavouriteNodeSelect = event.data;
        this.OnFavouriteNodeSelect();
    }

    private deleteFavouriteNode(favouriteNode: any) {
        this.favouriteNodesArray.splice(this.favouriteNodesArray.indexOf(favouriteNode), 1);
    }

    private OnFavouriteNodeSave() {
        let objclsFavourateNode_Post: IFavourateNode_Post = new clsFavourateNode_Post();

        objclsFavourateNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.UserPreferencesDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        objclsFavourateNode_Post.UserName = this.userName;
        objclsFavourateNode_Post.LastSelectedNode = this.lastSelectedNode;
        objclsFavourateNode_Post.Favourites = this.favouriteNodesArray;

        this.tPRHierarchyservice.updateUserPreferences(objclsFavourateNode_Post)
            .subscribe((response: any) => {
                console.log(response);
                if (response.Error) {
                    alert(response.Error);
                }
            },
            (error) => {
                console.log(error);
                this.updateHierarchyHeader = 'Error';
                this.updateHierarchyMessage = error;
                this.updateHierarchyFlag = true;
                this.showUpdateHierarchyFooter = false;
            });
    }

    private enableActionsForNode() {
        var that = this;
        this.actionItemsForNode.forEach(function (item, index) {
            item.disabled = true;
            if (item.label == "Add Child" && that.canEditHierarchy) {
                if (!that.selectedNode.IsPnlHolder && that.selectedNode.Level < 13) {
                    item.disabled = false;
                }
            }
            else if (item.label == "Remove Node" && that.canEditHierarchy) {
                // if (!that.selectedNodeDetails.Node.HasPnl
                //     && !that.selectedNodeDetails.Node.HasMVaR
                //     && that.selectedNodeDetails.Node.CanRemove
                //     && that.selectedNodeDetails.ParentId != 0
                //     && that.selectedNode.Children.length == 0) {
                //     item.disabled = false;
                // }  
                if (!that.selectedNode.HasAnyOutputData
                    && that.selectedNode.ParentId != 0
                    && that.selectedNode.Children.length == 0) {
                    item.disabled = false;
                }
                else {
                    item.disabled = true;
                }
            }
            else if (item.label == "Move Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Drop Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Edit Node") {
                item.disabled = !that.canEditNode;
            }
            else if (item.label == "Enter Value") {
                item.disabled = !that.canEnterValue;
            }
            else if (item.label == "Add To Favourites"
                && !that.favouriteNodesArray.some(x => x == that.selectedNode.NodeName)) {
                item.disabled = false;
            }
        });

        console.log("Check if node is moved ->", this.isNodeMoved);
        if (this.isNodeMoved) {
            this.actionItemsForNode.forEach(function (item, index) {
                if (!(item.label == "Drop Node" || item.label == "Add To Favourites")) {
                    item.disabled = true;
                }
            });
        }
        this.stopRefreshing(); //EH
    }

    private setContextMenuItemsForNode() {
        var that = this;
        this.items.forEach(function (item, index) {
            item.disabled = true;
            if (item.label == "Add Child" && that.canEditHierarchy) {
                if (!that.selectedNode.IsPnlHolder && that.selectedNode.Level < 13) {
                    item.disabled = false;
                }
            }
            else if (item.label == "Remove Node" && that.canEditHierarchy) {
                // if (!that.selectedNodeDetails.Node.HasPnl
                //     && !that.selectedNodeDetails.Node.HasMVaR
                //     && that.selectedNodeDetails.Node.CanRemove
                //     && that.selectedNodeDetails.ParentId != 0
                //     && that.selectedNode.Children.length == 0) {
                //     item.disabled = false;
                // }
                if (!that.selectedNode.HasAnyOutputData
                    && that.selectedNode.ParentId != 0
                    && that.selectedNode.Children.length == 0) {
                    item.disabled = false;
                }
                else {
                    item.disabled = true;
                }
            }
            else if (item.label == "Move Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Drop Node" && that.canEditHierarchy) {
                item.disabled = !that.canEditHierarchy;
            }
            else if (item.label == "Edit Node") {
                item.disabled = !that.canEditNode;
            }
            else if (item.label == "Enter Value") {
                item.disabled = !that.canEnterValue;
            }
            else if (item.label == "Add To Favourites"
                && !that.favouriteNodesArray.some(x => x == that.selectedNode.NodeName)) {
                item.disabled = false;
            }
        });

        console.log("Check if node is moved ->", this.isNodeMoved);
        if (this.isNodeMoved) {
            this.items.forEach(function (item, index) {
                if (!(item.label == "Drop Node" || item.label == "Add To Favourites")) {
                    item.disabled = true;
                }
            });
        }
    }

    // private getSelectedNodeDetails() {
    //     this.tPRHierarchyservice.getNodeLevelDataForEdit(this.intSelectedNodeID, this.businessDate)
    //         .subscribe(data => this.setNodeLevelData(data));

    // }
}

class RootValue implements IRootObject {
    constructor(
        public label: string = null,
        public NodeName: string = null,
        public id: number = null,
        public children: IRootObject[] = null,
        public Children: IRootObject[] = null,
        public data: any = null,
        public icon: any = null,
        public expandedIcon: any = null,
        public collapsedIcon: any = null,
        public leaf: boolean = null,
        public expanded: boolean = null,
        public type: string = null,
        public parent: IRootObject = null,
        public partialSelected: boolean = null,
        public $type: string = null,
        public HasAnyOutputData: boolean = null,
        public HasPlans: boolean = null,
        public UpdateTiming: any = null,
        public NodeId: number = null,
        public NodeType: string = null,
        public IsActive: boolean = null,
        public Level: number = null,
        public ParentId: number = null,
        public IsPnlHolder: boolean = null,
        public MVarUpdateTiming: number = null,
        public SplitType: string = null,
        public Id: number = null) { }
}

class clsHierarchyRemoveNode_Post implements IHierarchyRemoveNode_Post {
    constructor(
        public $type: string = null,
        public Children: IModifiedRootObject[] = [],
        public NodeNames: string[] = [],
        public Type: string = null,
        public StartDate: string = null,
        public EndDate: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsTransposedRootObject implements ITransposedRootObject {
    constructor(
        public $type: string = null,
        public Children: ITransposedRootObject[] = [],
        public HasAnyOutputData: boolean = false,
        public HasPlans: boolean = false,
        public UpdateTiming: number = null,
        public NodeName: string = null,
        public NodeId: number = 0,
        public NodeType: string = null,
        public IsActive: boolean = false,
        public Level: number = 0,
        public ParentId: number = 0,
        public IsPnlHolder: boolean = false,
        public MVarUpdateTiming: number = null,
        public SplitType: string = null,
        public Id: number = 0
    ) { }
}

class clsFavourateNode_Post implements IFavourateNode_Post {
    constructor(
        public $type: string = null,
        public UserName: string = null,
        public LastSelectedNode: string = null,
        public Favourites: string[] = [],
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode implements IHierarchyEditNode {
    constructor(
        public $type: string = null,
        public AlertGroups: any = null,
        public BusinessSegmentAllocations: any = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public DividendPartnerAllocations: any = '',
        public HasChildren: boolean = false,
        public HierarchyInstanceId: number = 0,
        public Id: number = 0,
        public IsMarkedForDeletion: boolean = false,
        public LastUpdatedBy: string = null,
        public Level: number = 0,
        public MVarLimit: any = null,
        public MVarRegion: any = null,
        public MVarTemporaryLimit: any = null,
        public MVarTemporaryLimitExpiryDate: any = null,
        public MVarUpdateTiming: any = null,
        public Node: IHierarchyEditNode_Node = null,
        public NodeType: any = null,
        public ParentId: number = 0,
        public ParentNodeId: number = 0,
        public Plans: any = null,
        public PnlSplitValue: any = null,
        public RegionalAllocations: any = null,
        public SplitType: string = null,
        public Tags: any = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public UpdateTiming: any = null,
        public WorkingCapitalRegion: any = null
    ) { }
}

class clsHierarchyEditNode_Node implements IHierarchyEditNode_Node {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public Description: string = null,
        public IsMarkedForDeletion: boolean = false,
        public NodeType: IHierarchyEditNode_Node_NodeType = null,
        public IsPnlHolder: boolean = false,
        public InputYTD: any = null,
        public InputExpectedYTD: any = null,
        public DividendYTD: any = null,
        public ReportedMEYTD: any = null,
        public CanRemove: boolean = false,
        public InputData: IHierarchyEditNode_Node_InputData = null,
        public OutputData: IHierarchyEditNode_Node_OutputData = null,
        public PreviousYTDForTrueUp: any = null,
        public AllDatesForCurrentReportingDate: IHierarchyEditNode_Node_AllDatesForCurrentReportingDate = null,
        public AllMVarDatesForCurrentReportingDate: any = null,
        public HasPnl: boolean = false,
        public HasMVaR: boolean = false,
        public IsActive: boolean = false,
        public InputNameMappings: IHierarchyEditNode_Node_InputNameMappings = null,
        public PreviousMonthEndDate: string = null,
        public PreviousTradeDate: string = null,
        public HasWorkingCapital: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class UserRolesValues implements IUserRolesValues {
    constructor(public $values: IUserRolesValue[] = null) { }
}

class UserRolesValue implements IUserRolesValue {
    constructor(
        public Name: string = null,
        public Users: IUsersValue[] = null) { }
}

class UsersValue implements IUsersValue {
    constructor(
        public LoginName: string = null,
        public Role: string = null) { }
}

class clsHierarchyEditNode_Node_ProfitAlertGroup_Values implements IHierarchyEditNode_Node_ProfitAlertGroup_Values {
    constructor(
        public $type: string = null,
        public NodeId: number = 0,
        public FormettedAlertGroups: string = null,
        public AlertGroups: IHierarchyEditNode_Node_ProfitAlertGroup_Values_AlertGroups = null
    ) { }
}