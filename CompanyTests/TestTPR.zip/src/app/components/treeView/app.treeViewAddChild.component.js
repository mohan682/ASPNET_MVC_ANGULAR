"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
require('rxjs/add/operator/switchMap');
var primeng_1 = require('primeng/primeng');
var app_TPRHierarchyservice_1 = require('../../service/app.TPRHierarchyservice');
var app_TPRNodeTypeService_1 = require('../../service/app.TPRNodeTypeService');
var app_regionService_1 = require('../../service/app.regionService');
var app_TPRProfitAlertGroupsService_1 = require('../../service/app.TPRProfitAlertGroupsService');
var app_TPRTagsService_1 = require('../../service/app.TPRTagsService');
var app_TPRDividendPartnersService_1 = require('../../service/app.TPRDividendPartnersService');
var app_TPRBusinessSegmentsService_1 = require('../../service/app.TPRBusinessSegmentsService');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_treeView_component_1 = require('../treeView/app.treeView.component');
var AppTprHierarchyAddChildComponent = (function () {
    function AppTprHierarchyAddChildComponent(tPRHierarchyservice, router, route, tPRNodeTypeService, confirmationService, regionsService, tprPAGService, tPRTagsService, tprDividendPartnersService, tprBusinessSegmentsService, tprCommonService, appTprHierarchyComponent) {
        this.tPRHierarchyservice = tPRHierarchyservice;
        this.router = router;
        this.route = route;
        this.tPRNodeTypeService = tPRNodeTypeService;
        this.confirmationService = confirmationService;
        this.regionsService = regionsService;
        this.tprPAGService = tprPAGService;
        this.tPRTagsService = tPRTagsService;
        this.tprDividendPartnersService = tprDividendPartnersService;
        this.tprBusinessSegmentsService = tprBusinessSegmentsService;
        this.tprCommonService = tprCommonService;
        this.appTprHierarchyComponent = appTprHierarchyComponent;
        this.blnShowModalPouUp = true;
        this.blnNodePropertiesShow = false;
        this.blnMappingNamesShow = false;
        this.blnRegionAllocationShow = false;
        this.blnTagAllocationShow = false;
        this.blnDividendAllocationShow = false;
        this.blnPnLPlanShow = false;
        this.blnPlanForDividendPartnersShow = false;
        this.blnMVARShow = false;
        this.blnProfitAlertGroupShow = false;
        this.blnWorkingCapitalShow = false;
        this.addChildMenuItems = [];
        this.businessDate = '';
        this.addNodeCompleteData = new clsHierarchyEditNode();
        this.nodeTypes = [];
        this.nodes = [];
        this.updateTimings = [];
        this.blndisableSelectedUpdateTimingField = false;
        this.blnEnableregionAllocation = true;
        this.selectedNode = new RootValue();
        this.mainListOfTree = [];
        this.nodeArrays = [];
        this.blnPnlHolderDisabled = false;
        this.strNodeName = "";
        this.strNodeTypeName = "";
        this.blnIsActive = true;
        this.blnIsPnlHolder = false;
        this.strUpdatedBy = "";
        this.strUpdated = "";
        this.strParentNodeName = "";
        this.ytdValues = [];
        this.mappingName = new clsHierarchyEditNode_Node_InputNameMappings_Value();
        this.mappingNames = [];
        this.mappingNamecols = [];
        this.regions = [];
        this.regionNames = [];
        this.regionAllocations = [];
        this.regionNamesRegionAllocation = [];
        this.strSelectedSplitType = "DM";
        this.strRegionAllocationPercentage = "0";
        this.strRegionAllocationValueCheck = "";
        this.clsRegionAllocationValueCheck = {};
        this.blnMVarHolder = false;
        this.blnMVarHolderDisabled = false;
        this.blnMVarUpdateTiming = false;
        this.MVarUpdateTimings = [];
        this.regionNamesMVar = [];
        this.strMVARLastUpdatedBy = "";
        this.strMVARLastUpdated = "";
        this.tagTypes = [];
        this.tags = [];
        this.tagNames = [];
        this.tag = new clsHierarchyEditNode_Tags_Values();
        this.dividendPartnerTypes = [];
        this.businessSegments = [];
        this.dividendPartnerAllocations = [];
        this.dividendPartnerNames = [];
        this.strDividendAllocationPercentage = "0";
        this.strDividendAllocationValueCheck = "";
        this.clsDividendAllocationValueCheck = {};
        this.regionNamesPlanRegionAllocation = [];
        this.pnlPlans = [];
        this.pnlPlansArray = [];
        this.selectedPnlPlan = new clsPlanDataPerRegion();
        this.pnlPlanYears = [];
        this.completePnlPlanYearToMonthPerRegion = [];
        this.filteredPnlPlanYearToMonthPerRegion = [];
        this.filteredPnLPlanPerRegion = [];
        this.dividendPartnerNamesDividendPlanAllocation = [];
        this.regionNamesDividendPlanAllocation = [];
        this.dividendPlanYears = [];
        this.dividendPlans = [];
        this.dividendPlansArray = [];
        this.selectedDividendPlan = new clsPlanDataPerDividendPartner();
        this.completeDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanPerDividendPartnerAndRegion = [];
        this.cols = [];
        this.profitAlertGroupsValuesMasterData = [];
        this.profitAlertGroupsValues = [];
        this.profitAlertGroupNames = [];
        this.profitAlertGroupArrays = [];
        this.profitAlertGroup = new clsHierarchyEditNode_AlertGroups_Values();
        this.profitAlertGroupcols = [];
        this.blnWorkingCapitalRegion = false;
        this.strSelectedWorkingCapitalRegionName = "NotSet";
        this.strWorkingCapitalUpdatedBy = "";
        this.strWorkingCapitalUpdated = "";
        this.blnDisableControlsTillSaveCompletes = false;
        this.blnShowConfirmDialog = false;
        this.blnShowValidationDialog = false;
        this.strValidationHeader = "";
        this.strValidationMessage = "";
        //post request starts here
        this.nodeDataForPostToServer = new clsHierarchyNodePostData();
        this.nodeAlertGroups = new clsHierarchyNodePostData_Alerts();
        this.moveNodeArrays = [];
        this.blnShowSaveDialog = false;
        this.updateHierarchyHeader = "";
        this.updateHierarchyMessage = "";
        this.showUpdateHierarchyFooter = false;
        this.strLoaderMessage = "";
    }
    AppTprHierarchyAddChildComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.isRequesting = true;
        this.addChildMenuItems = [
            { label: 'Node Properties', icon: 'fa fa-table', command: function (event) { return _this.AddNodeProperties(); }, disabled: true },
            { label: 'Mapping Names', icon: 'fa fa-table', command: function (event) { return _this.AddMappingNames(); }, disabled: true },
            { label: 'Region Allocation', icon: 'fa fa-table', command: function (event) { return _this.AddRegionAllocation(); }, disabled: true },
            { label: 'Tag Allocation', icon: 'fa fa-table', command: function (event) { return _this.AddTagAllocation(); }, disabled: true },
            { label: 'Dividend Allocation', icon: 'fa fa-table', command: function (event) { return _this.AddDividendAllocation(); }, disabled: true },
            { label: 'Pnl Plan', icon: 'fa fa-table', command: function (event) { return _this.AddPnLPlan(); }, disabled: true },
            { label: 'Plan For Dividend Partners', icon: 'fa fa-table', command: function (event) { return _this.AddPlanForDividendPartners(); }, disabled: true },
            { label: 'MVAR', icon: 'fa fa-table', command: function (event) { return _this.AddMVAR(); }, disabled: true },
            { label: 'Profit Alert Groups', icon: 'fa fa-table', command: function (event) { return _this.AddProfitAlertGroups(); }, disabled: true },
            { label: 'Working Capital', icon: 'fa fa-table', command: function (event) { return _this.AddWorkingCapital(); }, disabled: true },
        ];
        // To get the selected node ID from the route service
        this.route.params.subscribe(function (params) {
            _this.intSelectedParentNodeID = +params['nodeId'];
        });
        this.businessDate = localStorage.getItem("BusinessDate");
        this.tPRHierarchyservice.getNodeLevelDataForEdit(this.intSelectedParentNodeID, this.businessDate)
            .subscribe(function (data) {
            _this.editParentNodeCompleteData = data.Result;
        });
        this.tPRNodeTypeService.getNodeTypesObservable()
            .subscribe(function (data) { return _this.setNodeTypeData(data); });
        this.regionsService.getRegionsObservable()
            .subscribe(function (data) {
            _this.setRegionsData(data);
            _this.setRegionsDataForMVar(data);
            _this.setRegionsDataForRegionAllocation(data);
            _this.setRegionsDataForPlanRegionAllocation(data);
            _this.setRegionsDataForDividendPlanRegionAllocation(data);
        });
        this.tPRTagsService.getTagsObservable()
            .subscribe(function (data) {
            _this.setTagTypeData(data);
        });
        // to get the Dividend partners data
        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(function (data) {
            _this.setDividendPartnerData(data);
            _this.setDividendPartnerDataForDividendPlanAllocation(data);
        });
        // to get the business segments data
        this.tprBusinessSegmentsService.getBusinessSegmentsObservable()
            .subscribe(function (data) { return _this.setBusinessSegmentsData(data); });
        //get the profit Alert group master data
        this.tprPAGService.getProfitAlertGroupsObservable()
            .subscribe(function (data) { return _this.setProfitAlertGroupDate(data); });
        // set initial pnlPlan for Region
        this.setPnlPlanForRegion();
        this.getHierarchyData();
        this.updateTimings = [
            { label: "Not Set", value: null },
            { label: "R-1", value: "-1" },
            { label: "R-2", value: "-2" }
        ];
        this.MVarUpdateTimings = [
            { label: "", value: null },
            { label: "R-1", value: "-1" },
            { label: "R-2", value: "-2" }
        ];
        this.mappingNames = [];
        this.profitAlertGroupsValues = [];
        this.regionAllocations = [];
        this.tags = [];
    };
    AppTprHierarchyAddChildComponent.prototype.AddNodeProperties = function () {
        this.ResetAllTemplate();
        this.blnNodePropertiesShow = true;
    };
    AppTprHierarchyAddChildComponent.prototype.AddMappingNames = function () {
        this.ResetAllTemplate();
        this.blnMappingNamesShow = true;
    };
    AppTprHierarchyAddChildComponent.prototype.AddRegionAllocation = function () {
        this.ResetAllTemplate();
        this.blnRegionAllocationShow = true;
    };
    AppTprHierarchyAddChildComponent.prototype.AddTagAllocation = function () {
        this.ResetAllTemplate();
        this.blnTagAllocationShow = true;
    };
    AppTprHierarchyAddChildComponent.prototype.AddDividendAllocation = function () {
    };
    AppTprHierarchyAddChildComponent.prototype.AddPnLPlan = function () {
        this.ResetAllTemplate();
        this.blnPnLPlanShow = true;
        this.setPlanYears();
        this.strSelectedPnlPlanYear = this.pnlPlanYears[0].value;
        // if (this.pnlPlansArray && this.pnlPlansArray.length > 0) {
        //     this.selectedPnlPlan = this.pnlPlansArray[0];
        // }
        // this.filteredPnlPlanYearToMonthPerRegion = [];
        // this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
        //     .filter(plnPlan => plnPlan.strYear == this.strSelectedPnlPlanYear && plnPlan.strRegionName == this.selectedPnlPlan.strRegionName);
    };
    AppTprHierarchyAddChildComponent.prototype.AddPlanForDividendPartners = function () {
        this.ResetAllTemplate();
        this.blnPlanForDividendPartnersShow = true;
        this.cols = [
            { field: 'strRegionName', header: 'Region' },
            { field: 'TotalPlan', header: 'Total Plan' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
        this.setDividendPlanYears();
        this.strSelectedDividendPlanYear = this.dividendPlanYears[0].value;
        // if (this.dividendPlansArray && this.dividendPlansArray.length > 0) {
        //     this.selectedDividendPlan = this.dividendPlansArray[0];
        // }
        // this.filteredDividendPlanYearToMonthPerRegion = [];
        // this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
        //     .filter(dividendPlan => dividendPlan.strYear == this.strSelectedDividendPlanYear
        //         && dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
        //         && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName);
    };
    AppTprHierarchyAddChildComponent.prototype.AddMVAR = function () {
        this.ResetAllTemplate();
        this.blnMVARShow = true;
        this.strSelectedMVarUpdateTiming = null;
        this.strSelectedMVarRegionName = "NotSet";
    };
    AppTprHierarchyAddChildComponent.prototype.AddProfitAlertGroups = function () {
        this.ResetAllTemplate();
        this.blnProfitAlertGroupShow = true;
        this.profitAlertGroupcols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedTiming', header: 'Updated Timing' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
    };
    AppTprHierarchyAddChildComponent.prototype.AddWorkingCapital = function () {
        this.ResetAllTemplate();
        this.blnWorkingCapitalShow = true;
    };
    AppTprHierarchyAddChildComponent.prototype.getHierarchyData = function () {
        var _this = this;
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(function (files) { return _this.setNodeData(files); });
    };
    AppTprHierarchyAddChildComponent.prototype.setNodeData = function (data) {
        var _this = this;
        //this.mainListOfTree = data.Result.Children.$values;
        localStorage.setItem("MainHierarchyData", JSON.stringify(data.Result.Children.$values));
        this.hierarchy = data.Result.Children.$values;
        this.hierarchy.forEach(function (node) {
            _this.updateChildrenPropRecursive(node);
        });
        console.log("hierarchy ->", this.hierarchy);
        this.mainListOfTree = this.hierarchy;
        this.updateNodeProps();
        var parentNode = this.nodeArrays.find(function (node) { return node.NodeId == _this.intSelectedParentNodeID; });
        if (parentNode) {
            this.strParentNodeName = parentNode.NodeName;
        }
        this.setUpdateTimingForNode();
        this.checkDisablePnlHolder();
    };
    AppTprHierarchyAddChildComponent.prototype.ResetAllTemplate = function () {
        this.blnNodePropertiesShow = false;
        this.blnMappingNamesShow = false;
        this.blnRegionAllocationShow = false;
        this.blnTagAllocationShow = false;
        this.blnDividendAllocationShow = false;
        this.blnPnLPlanShow = false;
        this.blnPlanForDividendPartnersShow = false;
        this.blnMVARShow = false;
        this.blnProfitAlertGroupShow = false;
        this.blnWorkingCapitalShow = false;
    };
    AppTprHierarchyAddChildComponent.prototype.IsPnlHolderChange = function (checked) {
        this.addChildMenuItems.find(function (menuItem) { return menuItem.label == "Region Allocation"; }).disabled = !this.blnIsPnlHolder;
        if (!this.blndisableSelectedUpdateTimingField) {
            this.updateTimings = [];
            if (checked) {
                this.updateTimings = [
                    { label: "R-1", value: "-1" },
                    { label: "R-2", value: "-2" }
                ];
                if (!this.addNodeCompleteData.UpdateTiming) {
                    this.selectedUpdateTiming = -1;
                    this.addNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
                }
            }
            else {
                this.updateTimings = [
                    { label: "Not Set", value: null },
                    { label: "R-1", value: "-1" },
                    { label: "R-2", value: "-2" }
                ];
                if (this.addNodeCompleteData.UpdateTiming) {
                    this.selectedUpdateTiming = null;
                    this.addNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
                }
            }
        }
    };
    AppTprHierarchyAddChildComponent.prototype.onNodeUpdateTimingChange = function () {
        this.addNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
    };
    AppTprHierarchyAddChildComponent.prototype.getUpdateTimingFromHierarchyForNode = function (Id) {
        var nodeArray;
        nodeArray = this.nodeArrays.find(function (node) { return node.Id == Id; });
        if (nodeArray && this.selectedUpdateTiming == null) {
            if (!nodeArray.UpdateTiming) {
                this.getUpdateTimingFromHierarchyForNode(nodeArray.ParentId);
            }
            else {
                this.selectedUpdateTiming = nodeArray.UpdateTiming;
                // this will identify whether to disable the field or not. If the node value which came initially was null, 
                //the field will be disabled and will be set to parent level updateTiming; else, it will not be disabled.
                if (this.addNodeCompleteData.UpdateTiming == null) {
                    this.blndisableSelectedUpdateTimingField = true;
                    this.nodeNameCorrespondingToUpdateTiming = nodeArray.NodeName;
                }
            }
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setUpdateTimingForNode = function () {
        var _this = this;
        var parentNode = this.nodeArrays.find(function (node) { return node.NodeId == _this.intSelectedParentNodeID; });
        this.getUpdateTimingFromHierarchyForNode(parentNode.Id);
        this.setAddChildMenuItems();
    };
    AppTprHierarchyAddChildComponent.prototype.setAddChildMenuItems = function () {
        this.addChildMenuItems.forEach(function (menuItem) { return menuItem.disabled = false; });
        this.addChildMenuItems.forEach(function (menuItem) {
            if (menuItem.label == "Region Allocation" || menuItem.label == "Dividend Allocation") {
                menuItem.disabled = true;
            }
        });
        this.blnNodePropertiesShow = true;
        this.stopRefreshing();
    };
    AppTprHierarchyAddChildComponent.prototype.updateNodeProps = function () {
        var _this = this;
        this.mainListOfTree.forEach(function (node) {
            _this.AddNodeToArray(node);
            console.log("nodeArrays -> ", _this.nodeArrays);
        });
    };
    AppTprHierarchyAddChildComponent.prototype.AddNodeToArray = function (node) {
        var _this = this;
        //debugger;
        this.nodeArrays.push({
            label: node.NodeName,
            $type: node.type,
            Children: node.Children,
            HasAnyOutputData: node.HasAnyOutputData,
            HasPlans: node.HasPlans,
            Level: node.Level,
            MVarUpdateTiming: node.MVarUpdateTiming,
            IsActive: node.IsActive,
            IsPnlHolder: node.IsPnlHolder,
            NodeId: node.NodeId,
            NodeType: node.NodeType,
            SplitType: node.SplitType,
            UpdateTiming: node.UpdateTiming,
            children: node.children,
            collapsedIcon: "fa-plus-square",
            data: node.data,
            expanded: node.expanded,
            expandedIcon: "fa-minus-square",
            icon: node.icon,
            id: node.id,
            leaf: node.leaf,
            parent: node.parent,
            Id: node.Id,
            ParentId: node.ParentId,
            NodeName: node.NodeName,
            type: node.type,
            partialSelected: node.partialSelected
        });
        node.children = node.Children;
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.AddNodeToArray(childNode);
            });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.checkDisablePnlHolder = function () {
        //
    };
    AppTprHierarchyAddChildComponent.prototype.updateChildrenPropRecursive = function (node) {
        var _this = this;
        node.Children = node.Children.$values;
        node.children = node.Children;
        node.label = node.NodeName;
        if (node.Children) {
            node.Children.forEach(function (childNode) {
                _this.updateChildrenPropRecursive(childNode);
            });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setNodeTypeData = function (data) {
        //debugger;
        this.nodeTypes = data.Result.NodeTypes.$values;
        localStorage.setItem("systemNodeTypes", JSON.stringify(this.nodeTypes));
        this.nodeTypes = this.nodeTypes.filter(function (nodeType) { return nodeType.Editable == true; });
        this.nodes = [];
        var nodeName = '';
        for (var i = 0; i < this.nodeTypes.length; i++) {
            var node = this.nodeTypes[i];
            nodeName = node.Name;
            this.nodes.push({ label: nodeName, value: nodeName });
        }
        this.strNodeTypeName = this.nodes.length > 0 ? this.nodes[0].value : "";
    };
    AppTprHierarchyAddChildComponent.prototype.setRegionsData = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNames = [];
        this.regionNames.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNames.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setRegionsDataForMVar = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesMVar = [];
        this.regionNamesMVar.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesMVar.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setRegionsDataForRegionAllocation = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesRegionAllocation = [];
        this.regionNamesRegionAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesRegionAllocation.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setRegionsDataForPlanRegionAllocation = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesPlanRegionAllocation = [];
        this.regionNamesPlanRegionAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesPlanRegionAllocation.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setRegionsDataForDividendPlanRegionAllocation = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesDividendPlanAllocation = [];
        this.regionNamesDividendPlanAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesDividendPlanAllocation.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setDividendPartnerData = function (data) {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
        //this.dividendPartnerTypes = this.dividendPartnerTypes.filter(divPartner => divPartner.Editable == true);
        this.dividendPartnerNames = [];
        this.dividendPartnerNames.push({ label: 'Not Set', value: 'NotSet' });
        var dividendPartnerName = '';
        for (var i = 0; i < this.dividendPartnerTypes.length; i++) {
            var dividendPartner = this.dividendPartnerTypes[i];
            dividendPartnerName = dividendPartner.Name;
            this.dividendPartnerNames.push({ label: dividendPartnerName, value: dividendPartnerName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setDividendPartnerDataForDividendPlanAllocation = function (data) {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
        //this.dividendPartnerTypes = this.dividendPartnerTypes.filter(divPartner => divPartner.Editable == true);
        this.dividendPartnerNamesDividendPlanAllocation = [];
        this.dividendPartnerNamesDividendPlanAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var dividendPartnerName = '';
        for (var i = 0; i < this.dividendPartnerTypes.length; i++) {
            var dividendPartner = this.dividendPartnerTypes[i];
            dividendPartnerName = dividendPartner.Name;
            this.dividendPartnerNamesDividendPlanAllocation.push({ label: dividendPartnerName, value: dividendPartnerName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setBusinessSegmentsData = function (data) {
        this.businessSegments = [];
        this.businessSegments = data.Result.BusinessSegments.$values;
    };
    AppTprHierarchyAddChildComponent.prototype.setProfitAlertGroupDate = function (data) {
        this.profitAlertGroupsValuesMasterData = data.Result.AlertGroups.$values;
        this.profitAlertGroupNames = [];
        this.profitAlertGroupNames.push({ label: 'Not Set', value: 'NotSet' });
        for (var i = 0; i < this.profitAlertGroupsValuesMasterData.length; i++) {
            var pfaGroup = this.profitAlertGroupsValuesMasterData[i];
            this.profitAlertGroupNames.push({ label: pfaGroup.Name, value: pfaGroup.Name });
            this.profitAlertGroupArrays.push({
                Name: pfaGroup.Name,
                UpdateTiming: pfaGroup.UpdateTiming,
                Id: pfaGroup.Id,
                IsInUse: pfaGroup.IsInUse,
                TradeDate: pfaGroup.TradeDate,
                ProfitAlertGroupStatusId: pfaGroup.ProfitAlertGroupStatusId,
                Created: pfaGroup.Created,
                CreatedBy: pfaGroup.CreatedBy,
                Updated: pfaGroup.Updated,
                UpdatedBy: pfaGroup.UpdatedBy
            });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setTagTypeData = function (data) {
        this.tagTypes = [];
        this.tagTypes = data.Result.Tags.$values;
        this.tagNames = [];
        var tagName = '';
        this.tagNames.push({ label: 'Not Set', value: 'NotSet' });
        for (var i = 0; i < this.tagTypes.length; i++) {
            var tag = this.tagTypes[i];
            tagName = tag.Name;
            this.tagNames.push({ label: tagName, value: tagName });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.onMappingAddClick = function (txtMappingName, txtMappingSource) {
        if (txtMappingName && txtMappingName.trim() != "") {
            var index = this.mappingNames.indexOf(this.mappingNames.find(function (mappingName) { return mappingName.Name.toLowerCase().trim() == txtMappingName.toLowerCase().trim(); }));
            if (index == -1) {
                var $type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.InputNameMappingDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                this.mappingNames.push(new clsHierarchyEditNode_Node_InputNameMappings_Value($type, txtMappingName, txtMappingSource, '', '', '', '', 0));
            }
            else {
                this.strValidationHeader = "Validation failed";
                this.strValidationMessage = "Error : Mapping names must have unique name value.";
                this.blnShowValidationDialog = true;
            }
        }
        else {
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error : Mapping names must have name value.";
            this.blnShowValidationDialog = true;
        }
    };
    AppTprHierarchyAddChildComponent.prototype.deleteMappingName = function (mappingName) {
        if (mappingName) {
            this.mappingName = mappingName;
            this.mappingNames.splice(this.findmappingNameIndexForDelete(), 1);
        }
    };
    AppTprHierarchyAddChildComponent.prototype.findmappingNameIndexForDelete = function () {
        return this.mappingNames.indexOf(this.mappingName);
    };
    AppTprHierarchyAddChildComponent.prototype.ProfitAlertGroupChange = function (ProfitAlertGroupName) {
        var _this = this;
        var selectedProfitAlertGroupMasterItem = this.profitAlertGroupNames.find(function (x) { return x.value == _this.strSelectedProfitAlertGroupName; });
        var selectedGroup = this.profitAlertGroupArrays.find(function (group) { return group.Name == _this.strSelectedProfitAlertGroupName; });
        if (selectedGroup) {
            this.strSelectedGroupUpdateTiming = selectedGroup.UpdateTiming ? "R" + selectedGroup.UpdateTiming : "";
        }
        else {
            this.strSelectedGroupUpdateTiming = "";
        }
    };
    AppTprHierarchyAddChildComponent.prototype.onAddProfitAlertGroup = function () {
        var _this = this;
        var selectedGroup = this.profitAlertGroupArrays.find(function (group) { return group.Name == _this.strSelectedProfitAlertGroupName; });
        if (selectedGroup) {
            var dtCreated = selectedGroup.Created != null ? this.tprCommonService.getFormattedSystemDate(new Date(selectedGroup.Created)) : "";
            var dtUpdated = selectedGroup.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(selectedGroup.Updated)) : "";
            var $type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            this.profitAlertGroupsValues
                .push({
                $type: $type,
                Alerts: null,
                Name: this.strSelectedProfitAlertGroupName,
                Members: null,
                IsInUse: selectedGroup.IsInUse,
                UpdateTiming: selectedGroup.UpdateTiming,
                TradeDate: selectedGroup.TradeDate,
                ProfitAlertGroupStatusId: selectedGroup.ProfitAlertGroupStatusId,
                Created: dtCreated,
                CreatedBy: selectedGroup.CreatedBy,
                Updated: dtUpdated,
                UpdatedBy: selectedGroup.UpdatedBy,
                Id: selectedGroup.Id
            });
            var selectedProfitAlertGroupMasterItem = this.profitAlertGroupNames.find(function (x) { return x.value == _this.strSelectedProfitAlertGroupName; });
            if (selectedProfitAlertGroupMasterItem) {
                this.profitAlertGroupNames.splice(this.profitAlertGroupNames.indexOf(selectedProfitAlertGroupMasterItem), 1);
            }
            this.strSelectedProfitAlertGroupName = "NotSet";
            this.strSelectedGroupUpdateTiming = null;
        }
    };
    AppTprHierarchyAddChildComponent.prototype.deleteProfitAlertGroup = function (profitAlertGroup) {
        if (profitAlertGroup) {
            this.profitAlertGroup = profitAlertGroup;
            this.profitAlertGroupsValues.splice(this.findProfitAlertGroupForDelete(), 1);
            this.profitAlertGroupNames.push({ label: profitAlertGroup.Name, value: profitAlertGroup.Name });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.findProfitAlertGroupForDelete = function () {
        return this.profitAlertGroupsValues.indexOf(this.profitAlertGroup);
    };
    AppTprHierarchyAddChildComponent.prototype.onRegionAllocationAddClick = function () {
        var _this = this;
        var selectedRegionAllocation = this.regions.find(function (region) { return region.Name == _this.strSelectedRegionAllocationName; });
        if (selectedRegionAllocation) {
            var regionAllocationForSave = new clsHierarchyEditNode_RegionalAllocations_Values();
            regionAllocationForSave.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.AllocationStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            regionAllocationForSave.Percentage = Number(this.strRegionAllocationPercentage);
            regionAllocationForSave.RegionNode = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode();
            regionAllocationForSave.RegionNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            regionAllocationForSave.RegionNode.Region = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region();
            var region = this.regions.find(function (region) { return region.Name == _this.strSelectedRegionAllocationName; });
            if (region) {
                regionAllocationForSave.RegionNode.Region.$type = region.$type;
                regionAllocationForSave.RegionNode.Region.Created = region.Created.toString();
                regionAllocationForSave.RegionNode.Region.CreatedBy = region.CreatedBy;
                regionAllocationForSave.RegionNode.Region.Id = region.Id;
                regionAllocationForSave.RegionNode.Region.IsInUse = region.IsInUse;
                regionAllocationForSave.RegionNode.Region.Name = region.Name;
                regionAllocationForSave.RegionNode.Region.Updated = region.Updated.toString();
                regionAllocationForSave.RegionNode.Region.UpdatedBy = region.UpdatedBy;
            }
            regionAllocationForSave.RegionNode.Name = this.strSelectedRegionAllocationName;
            regionAllocationForSave.RegionNode.Description = null;
            regionAllocationForSave.RegionNode.IsMarkedForDeletion = false;
            regionAllocationForSave.RegionNode.NodeType = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType();
            var systemNodeTypes = JSON.parse(localStorage.getItem("systemNodeTypes"));
            var node = systemNodeTypes.find(function (node) { return node.Name.toLowerCase() == "region allocation"; });
            if (node) {
                regionAllocationForSave.RegionNode.NodeType = node;
            }
            regionAllocationForSave.RegionNode.IsPnlHolder = false;
            regionAllocationForSave.RegionNode.InputYTD = null;
            regionAllocationForSave.RegionNode.InputExpectedYTD = null;
            regionAllocationForSave.RegionNode.DividendYTD = null;
            regionAllocationForSave.RegionNode.ReportedMEYTD = null;
            regionAllocationForSave.RegionNode.CanRemove = false;
            regionAllocationForSave.RegionNode.InputData = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData();
            regionAllocationForSave.RegionNode.InputData.$values = [];
            regionAllocationForSave.RegionNode.OutputData = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData();
            regionAllocationForSave.RegionNode.OutputData.$values = [];
            regionAllocationForSave.RegionNode.PreviousYTDForTrueUp = null;
            regionAllocationForSave.RegionNode.AllDatesForCurrentReportingDate = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate();
            regionAllocationForSave.RegionNode.AllMVarDatesForCurrentReportingDate = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate();
            regionAllocationForSave.RegionNode.HasPnl = false;
            regionAllocationForSave.RegionNode.HasMVaR = false;
            regionAllocationForSave.RegionNode.IsActive = false;
            regionAllocationForSave.RegionNode.PreviousMonthEndDate = "";
            regionAllocationForSave.RegionNode.PreviousTradeDate = "";
            regionAllocationForSave.RegionNode.HasWorkingCapital = false;
            regionAllocationForSave.DividendPartnerNode = null;
            regionAllocationForSave.BusinessSegmentNode = null;
            this.regionAllocations.push(regionAllocationForSave);
            var selectedRegionAllocationItem = this.regionNamesRegionAllocation.find(function (item) { return item.value == _this.strSelectedRegionAllocationName; });
            if (selectedRegionAllocationItem) {
                this.regionNamesRegionAllocation.splice(this.regionNamesRegionAllocation.indexOf(selectedRegionAllocationItem), 1);
            }
            this.strSelectedRegionAllocationName = "NotSet";
            this.strRegionAllocationPercentage = "0";
        }
    };
    AppTprHierarchyAddChildComponent.prototype.calculateRegionGroupTotal = function () {
        var total = 0;
        if (this.regionAllocations) {
            this.regionAllocations.forEach(function (region) {
                total += Number(region.Percentage);
            });
        }
        this.strRegionAllocationValueCheck = total.toString();
        if (total != 100) {
            this.clsRegionAllocationValueCheck = {
                invalidData: true
            };
        }
        else {
            this.clsRegionAllocationValueCheck = {};
        }
        return total;
    };
    AppTprHierarchyAddChildComponent.prototype.onAddTags = function () {
        var _this = this;
        var selectedTag = this.tagTypes.find(function (item) { return item.Name == _this.strSelectedTagName; });
        if (selectedTag) {
            var dtCreated = selectedTag.Created != null ? this.tprCommonService.getFormattedSystemDate(new Date(selectedTag.Created)) : "";
            var dtUpdated = selectedTag.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(selectedTag.Updated)) : "";
            this.tags.push({
                $type: selectedTag.$type,
                Created: dtCreated,
                CreatedBy: selectedTag.CreatedBy,
                Editable: selectedTag.Editable,
                Id: selectedTag.Id,
                IsInUse: selectedTag.IsInUse,
                Name: selectedTag.Name,
                Updated: dtUpdated,
                UpdatedBy: selectedTag.UpdatedBy
            });
            var selectedTagNameMasterItem = this.tagNames.find(function (x) { return x.value == _this.strSelectedTagName; });
            if (selectedTagNameMasterItem) {
                this.tagNames.splice(this.tagNames.indexOf(selectedTagNameMasterItem), 1);
            }
            this.strSelectedTagName = "NotSet";
        }
    };
    AppTprHierarchyAddChildComponent.prototype.deleteTag = function (selectedTagforDelete) {
        if (selectedTagforDelete) {
            this.tag = selectedTagforDelete;
            this.tags.splice(this.findTagForDelete(), 1);
            this.tagNames.push({ label: selectedTagforDelete.Name, value: selectedTagforDelete.Name });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.findTagForDelete = function () {
        return this.tags.indexOf(this.tag);
    };
    AppTprHierarchyAddChildComponent.prototype.IsWorkingCapital = function (checked) {
        if (checked) {
            var index = this.regionNames.findIndex(function (x) { return x.value == "NotSet"; });
            if (index >= 0) {
                this.regionNames.splice(index, 1);
            }
            this.strSelectedWorkingCapitalRegionName = this.regionNames.length > 0 ? this.regionNames[0].value : "";
        }
        else {
            this.strSelectedWorkingCapitalRegionName = "NotSet";
            this.regionNames.unshift({ label: 'Not Set', value: 'NotSet' });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.MVarHolderChecked = function (checked) {
        if (checked) {
            var item = this.MVarUpdateTimings.find(function (updateTiming) { return updateTiming.value == null; });
            if (item) {
                this.MVarUpdateTimings.splice(this.MVarUpdateTimings.indexOf(item), 1);
            }
            this.strSelectedMVarUpdateTiming = "-1";
        }
        else {
            this.strSelectedMVarUpdateTiming = null;
            this.MVarUpdateTimings.unshift({ label: "", value: null });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setPlanYears = function () {
        var currentYear = new Date().getFullYear();
        this.pnlPlanYears = [];
        this.pnlPlanYears.push({ label: currentYear.toString(), value: currentYear.toString() });
        for (var count = 1; count < 10; count++) {
            var nextYear = ++currentYear;
            this.pnlPlanYears.push({ label: nextYear.toString(), value: nextYear.toString() });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setPnlPlanForRegion = function () {
        this.pnlPlans = [];
    };
    AppTprHierarchyAddChildComponent.prototype.onPnlPlanAddClick = function () {
        var _this = this;
        var selectedPnlPlanRegion = this.regions.find(function (region) { return region.Name == _this.strSelectedPnlPlanRegionAllocationName; });
        if (selectedPnlPlanRegion) {
            var newPnlPlanPerRegion = new clsPlanDataPerRegion();
            newPnlPlanPerRegion.strRegionName = this.strSelectedPnlPlanRegionAllocationName;
            newPnlPlanPerRegion.TotalPlan = 0;
            this.pnlPlansArray.push(newPnlPlanPerRegion);
            this.selectedPnlPlan = newPnlPlanPerRegion;
            var currentYear = new Date().getFullYear();
            for (var yearCount = currentYear; yearCount <= (currentYear + 10); yearCount++) {
                for (var monthCount = 1; monthCount <= 12; monthCount++) {
                    var pnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();
                    pnlPlanYearToMonthPerRegion.strYear = yearCount.toString();
                    pnlPlanYearToMonthPerRegion.strPlanValue = "0";
                    pnlPlanYearToMonthPerRegion.strRegionName = this.selectedPnlPlan.strRegionName;
                    pnlPlanYearToMonthPerRegion.strMonthValue = monthCount.toString();
                    switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                        case "1":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "January";
                            break;
                        case "2":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "February";
                            break;
                        case "3":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "March";
                            break;
                        case "4":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "April";
                            break;
                        case "5":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "May";
                            break;
                        case "6":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "June";
                            break;
                        case "7":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "July";
                            break;
                        case "8":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "August";
                            break;
                        case "9":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "September";
                            break;
                        case "10":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "October";
                            break;
                        case "11":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "November";
                            break;
                        case "12":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "December";
                            break;
                        default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                    }
                    this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
                }
            }
            this.filteredPnlPlanYearToMonthPerRegion = [];
            this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
                .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
            this.strSelectedPnlPlanYear = currentYear.toString();
            var selectedPnlPlanRegionName = this.regionNamesPlanRegionAllocation.find(function (pnlPlanRegion) { return pnlPlanRegion.value == _this.strSelectedPnlPlanRegionAllocationName; });
            if (selectedPnlPlanRegionName) {
                this.regionNamesPlanRegionAllocation.splice(this.regionNamesPlanRegionAllocation.indexOf(selectedPnlPlanRegionName), 1);
            }
            this.strSelectedPnlPlanRegionAllocationName = "NotSet";
        }
    };
    AppTprHierarchyAddChildComponent.prototype.pnlPlanYearForRegionChange = function () {
        var _this = this;
        var PnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion.find(function (item) { return item.strRegionName == _this.selectedPnlPlan.strRegionName && item.strYear == _this.strSelectedPnlPlanYear; });
        if (PnlPlanYearToMonthPerRegion == null && this.pnlPlansArray && this.pnlPlansArray.length > 0) {
            for (var count = 1; count <= 12; count++) {
                var pnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();
                pnlPlanYearToMonthPerRegion.strYear = this.strSelectedPnlPlanYear;
                pnlPlanYearToMonthPerRegion.strPlanValue = "0";
                pnlPlanYearToMonthPerRegion.strRegionName = this.selectedPnlPlan.strRegionName;
                pnlPlanYearToMonthPerRegion.strMonthValue = count.toString();
                switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                    case "1":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "January";
                        break;
                    case "2":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "February";
                        break;
                    case "3":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "March";
                        break;
                    case "4":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "April";
                        break;
                    case "5":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "May";
                        break;
                    case "6":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "June";
                        break;
                    case "7":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "July";
                        break;
                    case "8":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "August";
                        break;
                    case "9":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "September";
                        break;
                    case "10":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "October";
                        break;
                    case "11":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "November";
                        break;
                    case "12":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "December";
                        break;
                    default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }
                this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
            }
        }
        this.filteredPnlPlanYearToMonthPerRegion = [];
        this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
            .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
    };
    AppTprHierarchyAddChildComponent.prototype.onPnlPlanRowSelect = function (event) {
        var _this = this;
        this.selectedPnlPlan = event.data;
        this.strSelectedPnlPlanYear = this.pnlPlanYears[0].value;
        if (this.selectedPnlPlan) {
            this.filteredPnlPlanYearToMonthPerRegion = [];
            this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
                .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.deletePnlPlanForRegion = function (pnlPlan) {
        var _this = this;
        this.blnShowConfirmDialog = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected Pnl Plan will be deleted. Are you sure?',
            accept: function () {
                _this.pnlPlansArray.splice(_this.pnlPlansArray.indexOf(pnlPlan), 1);
                _this.regionNamesPlanRegionAllocation.push({ label: pnlPlan.strRegionName, value: pnlPlan.strRegionName });
                // filter the completePnlPlanYearToMonthPerRegion to remove out the items based on the region deleted.
                var filterPnlPlanArray = _this.completePnlPlanYearToMonthPerRegion.filter(function (pnlPlanYearToMonthPerRegion) { return pnlPlanYearToMonthPerRegion.strRegionName != pnlPlan.strRegionName; });
                // reassign the filterred array items list.
                _this.completePnlPlanYearToMonthPerRegion = filterPnlPlanArray;
                _this.selectedPnlPlan = _this.pnlPlansArray && _this.pnlPlansArray.length > 0 ? _this.pnlPlansArray[0] : new clsPlanDataPerRegion();
                _this.filteredPnlPlanYearToMonthPerRegion = [];
                _this.filteredPnlPlanYearToMonthPerRegion = _this.completePnlPlanYearToMonthPerRegion
                    .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
                _this.blnShowConfirmDialog = false;
            },
            reject: function () {
                _this.blnShowConfirmDialog = false;
            }
        });
    };
    AppTprHierarchyAddChildComponent.prototype.calculatePnlPlanTotal = function () {
        var total = 0;
        this.completePnlPlanYearToMonthPerRegion.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyAddChildComponent.prototype.calculateTotalPnlPlanPerRegion = function (event) {
        var _this = this;
        var total = 0;
        var filteredPnlPlanPerRegion = this.completePnlPlanYearToMonthPerRegion
            .filter(function (plan) { return plan.strRegionName == _this.selectedPnlPlan.strRegionName; });
        filteredPnlPlanPerRegion.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        this.selectedPnlPlan.TotalPlan = total;
    };
    AppTprHierarchyAddChildComponent.prototype.calculatePnlPlanPerRegionToYearTotal = function () {
        var _this = this;
        var total = 0;
        var filteredPnlPlanPerRegionPerYear = this.completePnlPlanYearToMonthPerRegion
            .filter(function (plan) { return plan.strRegionName == _this.selectedPnlPlan.strRegionName && plan.strYear == _this.strSelectedPnlPlanYear; });
        filteredPnlPlanPerRegionPerYear.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyAddChildComponent.prototype.setDividendPlanYears = function () {
        var currentYear = new Date().getFullYear();
        this.dividendPlanYears = [];
        this.dividendPlanYears.push({ label: currentYear.toString(), value: currentYear.toString() });
        for (var count = 1; count < 10; count++) {
            var nextYear = ++currentYear;
            this.dividendPlanYears.push({ label: nextYear.toString(), value: nextYear.toString() });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.setDividendPlanForDividendPartner = function () {
        this.dividendPlans = [];
    };
    AppTprHierarchyAddChildComponent.prototype.onDividendPlanAddClick = function () {
        var _this = this;
        var itemToBeAddedIndex = this.completeDividendPlanYearToMonthPerRegion.
            findIndex(function (divPlan) { return divPlan.strDividendPartnerName == _this.strSelectedDividendPlanDividendPartnerName
            && divPlan.strRegionName == _this.strSelectedDividendPlanRegionAllocationName; });
        if (itemToBeAddedIndex != -1) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Duplicate record";
            this.strValidationMessage = "The plan for selected dividend partner already exists.\n\n" +
                "You can modify the plan in the table below or delete the existing record and enter a new value.";
        }
        else {
            var selectedDividendPlanRegion = this.regions.find(function (region) { return region.Name == _this.strSelectedDividendPlanRegionAllocationName; });
            var selectedDividendPlanDividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.strSelectedDividendPlanDividendPartnerName; });
            if (selectedDividendPlanRegion && selectedDividendPlanDividendPartner) {
                var newDividendPlanPerDividendPartner = new clsPlanDataPerDividendPartner();
                newDividendPlanPerDividendPartner.strRegionName = this.strSelectedDividendPlanRegionAllocationName;
                newDividendPlanPerDividendPartner.strDividendPartnerName = this.strSelectedDividendPlanDividendPartnerName;
                newDividendPlanPerDividendPartner.TotalPlan = 0;
                this.dividendPlansArray.push(newDividendPlanPerDividendPartner);
                this.selectedDividendPlan = newDividendPlanPerDividendPartner;
                var currentYear = new Date().getFullYear();
                for (var yearCount = currentYear; yearCount <= (currentYear + 10); yearCount++) {
                    for (var monthCount = 1; monthCount <= 12; monthCount++) {
                        var dividendPlanYearToMonthPerDividendPartnerAndRegion = new clsDividendPlanYearToMonthPerRegion();
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strYear = yearCount.toString();
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strPlanValue = "0";
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strRegionName = this.selectedDividendPlan.strRegionName;
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strDividendPartnerName = this.selectedDividendPlan.strDividendPartnerName;
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthValue = monthCount.toString();
                        switch (dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthValue) {
                            case "1":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "January";
                                break;
                            case "2":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "February";
                                break;
                            case "3":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "March";
                                break;
                            case "4":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "April";
                                break;
                            case "5":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "May";
                                break;
                            case "6":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "June";
                                break;
                            case "7":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "July";
                                break;
                            case "8":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "August";
                                break;
                            case "9":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "September";
                                break;
                            case "10":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "October";
                                break;
                            case "11":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "November";
                                break;
                            case "12":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "December";
                                break;
                            default: dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "Invalid Month";
                        }
                        this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerDividendPartnerAndRegion);
                    }
                }
                this.filteredDividendPlanYearToMonthPerRegion = [];
                this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
                    .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
                    && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
                    && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
                this.strSelectedDividendPlanYear = currentYear.toString();
                this.sortDividendPlanArray();
                this.strSelectedDividendPlanDividendPartnerName = "NotSet";
                this.strSelectedDividendPlanRegionAllocationName = "NotSet";
            }
        }
    };
    AppTprHierarchyAddChildComponent.prototype.sortDividendPlanArray = function () {
        this.dividendPlansArray.sort(function (n1, n2) {
            if (n1.strDividendPartnerName > n2.strDividendPartnerName) {
                return 1;
            }
            if (n1.strDividendPartnerName < n2.strDividendPartnerName) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyAddChildComponent.prototype.dividendPlanYearForDividendPartnerChange = function () {
        var _this = this;
        var dividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .find(function (item) { return item.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName &&
            item.strRegionName == _this.selectedDividendPlan.strRegionName && item.strYear == _this.strSelectedDividendPlanYear; });
        if (dividendPlanYearToMonthPerRegion == null && this.dividendPlansArray && this.dividendPlansArray.length > 0) {
            for (var count = 1; count <= 12; count++) {
                var dividendPlanYearToMonthPerRegion_1 = new clsDividendPlanYearToMonthPerRegion();
                dividendPlanYearToMonthPerRegion_1.strYear = this.strSelectedDividendPlanYear;
                dividendPlanYearToMonthPerRegion_1.strPlanValue = "0";
                dividendPlanYearToMonthPerRegion_1.strDividendPartnerName = this.selectedDividendPlan.strDividendPartnerName;
                dividendPlanYearToMonthPerRegion_1.strRegionName = this.selectedDividendPlan.strRegionName;
                dividendPlanYearToMonthPerRegion_1.strMonthValue = count.toString();
                switch (dividendPlanYearToMonthPerRegion_1.strMonthValue) {
                    case "1":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "January";
                        break;
                    case "2":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "February";
                        break;
                    case "3":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "March";
                        break;
                    case "4":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "April";
                        break;
                    case "5":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "May";
                        break;
                    case "6":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "June";
                        break;
                    case "7":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "July";
                        break;
                    case "8":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "August";
                        break;
                    case "9":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "September";
                        break;
                    case "10":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "October";
                        break;
                    case "11":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "November";
                        break;
                    case "12":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "December";
                        break;
                    default: dividendPlanYearToMonthPerRegion_1.strMonthDesc = "Invalid Month";
                }
                this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerRegion_1);
            }
        }
        this.filteredDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
            && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
            && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
    };
    AppTprHierarchyAddChildComponent.prototype.onDividendPlanRowSelect = function (event) {
        var _this = this;
        this.selectedDividendPlan = event.data;
        this.strSelectedDividendPlanYear = this.dividendPlanYears[0].value;
        if (this.selectedDividendPlan) {
            this.filteredDividendPlanYearToMonthPerRegion = [];
            this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
                .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
                && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
                && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
        }
    };
    AppTprHierarchyAddChildComponent.prototype.calculateDividendPlanTotal = function (strDivPartnerName) {
        var total = 0;
        var filteredPlanPerDividendPartner = [];
        filteredPlanPerDividendPartner = this.completeDividendPlanYearToMonthPerRegion.filter(function (plan) { return plan.strDividendPartnerName == strDivPartnerName; });
        filteredPlanPerDividendPartner.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyAddChildComponent.prototype.deleteDividendPlanForDividendPartnerAndRegion = function (dividendPlan) {
        var _this = this;
        this.blnShowConfirmDialog = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected Dividend Plan will be deleted. Are you sure?',
            accept: function () {
                //debugger;
                _this.dividendPlansArray.splice(_this.dividendPlansArray.indexOf(dividendPlan), 1);
                // filter the completeDividendPlanYearToMonthPerRegion to remove out the items based on the region deleted.
                var filterDividendPlanArray = _this.completeDividendPlanYearToMonthPerRegion
                    .filter(function (dividendPlanYearToMonthPerRegion) { return (dividendPlanYearToMonthPerRegion.strRegionName != dividendPlan.strRegionName
                    || dividendPlanYearToMonthPerRegion.strDividendPartnerName != dividendPlan.strDividendPartnerName); });
                // reassign the filterred array items list.
                _this.completeDividendPlanYearToMonthPerRegion = filterDividendPlanArray;
                _this.selectedDividendPlan = _this.dividendPlansArray && _this.dividendPlansArray.length > 0 ? _this.dividendPlansArray[0] : new clsPlanDataPerDividendPartner();
                _this.filteredDividendPlanYearToMonthPerRegion = [];
                _this.filteredDividendPlanYearToMonthPerRegion = _this.completeDividendPlanYearToMonthPerRegion
                    .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
                    && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
                    && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
                _this.blnShowConfirmDialog = false;
            },
            reject: function () {
                _this.blnShowConfirmDialog = false;
            }
        });
    };
    AppTprHierarchyAddChildComponent.prototype.calculateTotalDividendPlanPerDividendPartner = function (event) {
        var _this = this;
        var total = 0;
        var filteredPlanPerDividendPartner = this.completeDividendPlanYearToMonthPerRegion
            .filter(function (dividendPlan) { return dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
            && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
        filteredPlanPerDividendPartner.forEach(function (dividendPlan) {
            total += Number(dividendPlan.strPlanValue);
        });
        this.selectedDividendPlan.TotalPlan = total;
    };
    AppTprHierarchyAddChildComponent.prototype.calculateDividendPlanPerRegionToYearTotal = function () {
        var _this = this;
        var total = 0;
        var filteredDividendPlanPerRegionPerYear = this.completeDividendPlanYearToMonthPerRegion
            .filter(function (dividendPlan) { return dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
            && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName
            && dividendPlan.strYear == _this.strSelectedDividendPlanYear; });
        filteredDividendPlanPerRegionPerYear.forEach(function (dividendPlan) {
            total += Number(dividendPlan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyAddChildComponent.prototype.calculateDividendPartnerGroupTotal = function () {
        var total = 0;
        if (this.dividendPartnerAllocations) {
            this.dividendPartnerAllocations.forEach(function (dividendPartner) {
                total += Number(dividendPartner.Percentage);
            });
        }
        this.strDividendAllocationValueCheck = total.toString();
        if (total > 100) {
            this.clsDividendAllocationValueCheck = {
                invalidData: true
            };
        }
        else {
            this.clsDividendAllocationValueCheck = {};
        }
        return total;
    };
    AppTprHierarchyAddChildComponent.prototype.onCustomNumericValidation = function (event) {
        return String.fromCharCode(event.charCode).match(/[0-9]/g) != null;
    };
    AppTprHierarchyAddChildComponent.prototype.onCustomNumericValidationForPositiveAndNegativeIntegers = function (event) {
        return String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null;
    };
    AppTprHierarchyAddChildComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppTprHierarchyAddChildComponent.prototype.Save = function () {
        var validationResult = this.ValidateNodeSave();
        if (!validationResult) {
            this.blnDisableControlsTillSaveCompletes = false;
            return false;
        }
        else {
            this.blnShowSaveDialog = true;
            this.updateHierarchyHeader = "Save changes";
            this.updateHierarchyMessage = "Saving changes to the hierarchy. Are you happy to proceed?";
            this.showUpdateHierarchyFooter = true;
        }
    };
    AppTprHierarchyAddChildComponent.prototype.SaveNodeToDatabase = function () {
        var _this = this;
        //debugger;
        // Edit node validations
        this.blnShowSaveDialog = false;
        // The object will be of the type IHierarchyNodePostData.
        this.nodeDataForPostToServer = new clsHierarchyNodePostData();
        // set property data
        this.nodeDataForPostToServer.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.StructurePropertiesDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        this.nodeDataForPostToServer.AlertGroups = [];
        this.profitAlertGroupsValues.forEach(function (pag_Values) {
            _this.nodeAlertGroups = new clsHierarchyNodePostData_Alerts();
            _this.nodeAlertGroups.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            var pag_Alerts = _this.profitAlertGroupsValuesMasterData.find(function (pag) { return pag.Name == pag_Values.Name; });
            if (pag_Alerts) {
                _this.nodeAlertGroups.Alerts = pag_Alerts.Alerts.$values;
                _this.nodeAlertGroups.Members = pag_Alerts.Members.$values;
            }
            else {
                _this.nodeAlertGroups.Alerts = [];
                _this.nodeAlertGroups.Members = [];
            }
            _this.nodeAlertGroups.Name = pag_Values.Name;
            _this.nodeAlertGroups.IsInUse = pag_Values.IsInUse;
            _this.nodeAlertGroups.UpdateTiming = pag_Values.UpdateTiming;
            _this.nodeAlertGroups.TradeDate = pag_Values.TradeDate;
            _this.nodeAlertGroups.ProfitAlertGroupStatusId = pag_Values.ProfitAlertGroupStatusId;
            _this.nodeAlertGroups.Created = pag_Values.Created;
            _this.nodeAlertGroups.CreatedBy = pag_Values.CreatedBy;
            _this.nodeAlertGroups.Updated = pag_Values.Updated;
            _this.nodeAlertGroups.UpdatedBy = pag_Values.UpdatedBy;
            _this.nodeAlertGroups.Id = pag_Values.Id;
            _this.nodeDataForPostToServer.AlertGroups.push(_this.nodeAlertGroups);
        });
        this.nodeDataForPostToServer.BusinessSegmentAllocations = []; // To be changed to proper datatype.
        this.nodeDataForPostToServer.Created = null;
        this.nodeDataForPostToServer.CreatedBy = null;
        this.nodeDataForPostToServer.DividendPartnerAllocations = [];
        this.nodeDataForPostToServer.HasChildren = false;
        this.nodeDataForPostToServer.HierarchyInstanceId = this.editParentNodeCompleteData.HierarchyInstanceId;
        this.nodeDataForPostToServer.Id = 0;
        this.nodeDataForPostToServer.IsMarkedForDeletion = false;
        this.nodeDataForPostToServer.LastUpdatedBy = null;
        this.nodeDataForPostToServer.Level = (this.editParentNodeCompleteData.Level + 1);
        this.nodeDataForPostToServer.MVarLimit = null;
        var selectedMVARRegion = this.regions.find(function (region) { return region.Name == _this.strSelectedMVarRegionName; });
        if (selectedMVARRegion) {
            this.nodeDataForPostToServer.MVarRegion = new clsHierarchyEditNode_MVarRegion();
            this.nodeDataForPostToServer.MVarRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            this.nodeDataForPostToServer.MVarRegion.Name = selectedMVARRegion.Name;
            this.nodeDataForPostToServer.MVarRegion.IsInUse = selectedMVARRegion.IsInUse;
            this.nodeDataForPostToServer.MVarRegion.Created = selectedMVARRegion.Created.toString();
            this.nodeDataForPostToServer.MVarRegion.CreatedBy = selectedMVARRegion.CreatedBy;
            this.nodeDataForPostToServer.MVarRegion.Updated = selectedMVARRegion.Updated.toString();
            this.nodeDataForPostToServer.MVarRegion.UpdatedBy = selectedMVARRegion.UpdatedBy;
            this.nodeDataForPostToServer.MVarRegion.Id = selectedMVARRegion.Id;
        }
        this.nodeDataForPostToServer.MVarTemporaryLimit = null;
        this.nodeDataForPostToServer.MVarTemporaryLimitExpiryDate = null;
        this.nodeDataForPostToServer.MVarUpdateTiming = this.strSelectedMVarUpdateTiming ? Number(this.strSelectedMVarUpdateTiming) : null;
        this.nodeDataForPostToServer.Node = new clsHierarchyNodePostData_Node();
        this.nodeDataForPostToServer.Node.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        this.nodeDataForPostToServer.Node.Name = this.strNodeName;
        this.nodeDataForPostToServer.Node.Description = null;
        this.nodeDataForPostToServer.Node.IsMarkedForDeletion = false;
        //debugger;
        var selectNodeType = this.nodeTypes.find(function (item) { return item.Name == _this.strNodeTypeName; });
        if (selectNodeType) {
            this.nodeDataForPostToServer.Node.NodeType = selectNodeType;
            this.nodeDataForPostToServer.Node.NodeType.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeTypeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        }
        this.nodeDataForPostToServer.Node.IsPnlHolder = this.blnIsPnlHolder;
        this.nodeDataForPostToServer.Node.InputYTD = null;
        this.nodeDataForPostToServer.Node.InputExpectedYTD = null;
        this.nodeDataForPostToServer.Node.DividendYTD = null;
        this.nodeDataForPostToServer.Node.ReportedMEYTD = null;
        this.nodeDataForPostToServer.Node.CanRemove = false;
        this.nodeDataForPostToServer.Node.InputData = [];
        this.nodeDataForPostToServer.Node.OutputData = [];
        this.nodeDataForPostToServer.Node.PreviousYTDForTrueUp = null;
        this.nodeDataForPostToServer.Node.AllDatesForCurrentReportingDate = [];
        this.nodeDataForPostToServer.Node.AllMVarDatesForCurrentReportingDate = [];
        this.nodeDataForPostToServer.Node.HasPnl = false;
        this.nodeDataForPostToServer.Node.HasMVaR = false;
        this.nodeDataForPostToServer.Node.IsActive = this.blnIsActive;
        this.nodeDataForPostToServer.Node.InputNameMappings = this.mappingNames;
        this.nodeDataForPostToServer.Node.InputNameMappings.forEach(function (data) {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.InputNameMappingDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });
        this.nodeDataForPostToServer.Node.PreviousMonthEndDate = null;
        this.nodeDataForPostToServer.Node.PreviousTradeDate = null;
        this.nodeDataForPostToServer.Node.HasWorkingCapital = false;
        this.nodeDataForPostToServer.Node.Created = null;
        this.nodeDataForPostToServer.Node.CreatedBy = null;
        this.nodeDataForPostToServer.Node.Updated = null;
        this.nodeDataForPostToServer.Node.UpdatedBy = null;
        this.nodeDataForPostToServer.Node.Id = 0;
        this.nodeDataForPostToServer.NodeType = null;
        this.nodeDataForPostToServer.ParentId = this.editParentNodeCompleteData.Id;
        this.nodeDataForPostToServer.ParentNodeId = 0;
        //debugger;
        // PnL Plans
        this.nodeDataForPostToServer.Plans = [];
        this.pnlPlansArray.forEach(function (pnlPlanArray) {
            var clsPnlPlan = new clsHierarchyNodePostData_Plans();
            clsPnlPlan.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            clsPnlPlan.DividendPartner = null;
            var pnlRegion = _this.regions.find(function (region) { return region.Name == pnlPlanArray.strRegionName; });
            if (pnlRegion) {
                clsPnlPlan.Region = new clsHierarchyNodePostData_Plans_Region();
                clsPnlPlan.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsPnlPlan.Region.Name = pnlRegion.Name;
                clsPnlPlan.Region.IsInUse = pnlRegion.IsInUse;
                clsPnlPlan.Region.Created = pnlRegion.Created.toString();
                clsPnlPlan.Region.CreatedBy = pnlRegion.CreatedBy.toString();
                clsPnlPlan.Region.Updated = pnlRegion.Updated.toString();
                clsPnlPlan.Region.UpdatedBy = pnlRegion.UpdatedBy.toString();
                clsPnlPlan.Region.Id = pnlRegion.Id;
            }
            clsPnlPlan.PlanValues = [];
            _this.filteredPnLPlanPerRegion = [];
            _this.filteredPnLPlanPerRegion = _this.completePnlPlanYearToMonthPerRegion.filter(function (pnlPlanYearToMonthPerRegion) { return pnlPlanYearToMonthPerRegion.strRegionName == pnlPlanArray.strRegionName; });
            var filteredPnlPlanArrayPerRegionPerYear = [];
            _this.pnlPlanYears.forEach(function (pnlYear) {
                if (pnlYear.value != _this.pnlPlanYears[0].value) {
                    var pnlPlanPerYear = _this.filteredPnLPlanPerRegion.filter(function (yearPlan) { return yearPlan.strYear == pnlYear.value; });
                    //if (pnlPlanPerYear.length > 0 && pnlPlanPerYear.every(arrayItem => arrayItem.strPlanValue != "0" && arrayItem.strPlanValue != null)) {
                    if (pnlPlanPerYear.length > 0 && (pnlPlanPerYear.findIndex(function (arrayItem) { return arrayItem.strPlanValue.toString() != "0"; }) != -1)) {
                        var tempArray = [];
                        tempArray = _this.filteredPnLPlanPerRegion.filter(function (item) { return item.strYear == pnlYear.value; });
                        tempArray.forEach(function (item) { return filteredPnlPlanArrayPerRegionPerYear.push(item); });
                    }
                }
                else {
                    var tempArray = [];
                    tempArray = _this.filteredPnLPlanPerRegion.filter(function (item) { return item.strYear == pnlYear.value; });
                    tempArray.forEach(function (item) { return filteredPnlPlanArrayPerRegionPerYear.push(item); });
                }
            });
            filteredPnlPlanArrayPerRegionPerYear.forEach(function (pnlArrayItem) {
                var pnlPlanValue = new clsHierarchyNodePostData_Plans_PlanValues();
                pnlPlanValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanValueDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                pnlPlanValue.Year = Number(pnlArrayItem.strYear);
                pnlPlanValue.Month = Number(pnlArrayItem.strMonthValue);
                if (pnlArrayItem.strMonthValue != "0" && pnlArrayItem.strMonthValue != null) {
                    pnlPlanValue.Value = Number(pnlArrayItem.strPlanValue);
                }
                else {
                    pnlPlanValue.Value = null;
                }
                clsPnlPlan.PlanValues.push(pnlPlanValue);
            });
            _this.nodeDataForPostToServer.Plans.push(clsPnlPlan);
        });
        // end of PnL plan//
        //debugger;
        // this is for dividend plan
        this.dividendPlansArray.forEach(function (dividendPlanArray) {
            var clsDividendPlan = new clsHierarchyNodePostData_Plans();
            clsDividendPlan.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            var dividendPartnerObj = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendPlanArray.strDividendPartnerName; });
            if (dividendPartnerObj) {
                clsDividendPlan.DividendPartner = new clsHierarchyNodePostData_Plans_DividendPartner();
                clsDividendPlan.DividendPartner.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.DividendPartner.BusinessSegment = new clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment();
                clsDividendPlan.DividendPartner.BusinessSegment = dividendPartnerObj.BusinessSegment;
                clsDividendPlan.DividendPartner.BusinessSegment.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.BusinessSegmentDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.DividendPartner.Created = dividendPartnerObj.Created;
                clsDividendPlan.DividendPartner.CreatedBy = dividendPartnerObj.CreatedBy;
                clsDividendPlan.DividendPartner.Editable = dividendPartnerObj.Editable;
                clsDividendPlan.DividendPartner.Id = dividendPartnerObj.Id;
                clsDividendPlan.DividendPartner.IsInUse = dividendPartnerObj.IsInUse;
                clsDividendPlan.DividendPartner.Name = dividendPartnerObj.Name;
                clsDividendPlan.DividendPartner.Updated = dividendPartnerObj.Updated;
                clsDividendPlan.DividendPartner.UpdatedBy = dividendPartnerObj.UpdatedBy;
            }
            var pnlRegion = _this.regions.find(function (region) { return region.Name == dividendPlanArray.strRegionName; });
            if (pnlRegion) {
                clsDividendPlan.Region = new clsHierarchyNodePostData_Plans_Region();
                clsDividendPlan.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.Region.Name = pnlRegion.Name;
                clsDividendPlan.Region.IsInUse = pnlRegion.IsInUse;
                clsDividendPlan.Region.Created = pnlRegion.Created.toString();
                clsDividendPlan.Region.CreatedBy = pnlRegion.CreatedBy.toString();
                clsDividendPlan.Region.Updated = pnlRegion.Updated.toString();
                clsDividendPlan.Region.UpdatedBy = pnlRegion.UpdatedBy.toString();
                clsDividendPlan.Region.Id = pnlRegion.Id;
            }
            clsDividendPlan.PlanValues = [];
            _this.filteredDividendPlanPerDividendPartnerAndRegion = [];
            _this.filteredDividendPlanPerDividendPartnerAndRegion = _this.completeDividendPlanYearToMonthPerRegion
                .filter(function (dividendPlanYearToMonthPerDividendPartnerAndRegion) {
                return dividendPlanYearToMonthPerDividendPartnerAndRegion.strRegionName == dividendPlanArray.strRegionName &&
                    dividendPlanYearToMonthPerDividendPartnerAndRegion.strDividendPartnerName == dividendPlanArray.strDividendPartnerName;
            });
            //debugger;
            var filteredDividendPlanArrayPerRegionPerYear = [];
            _this.dividendPlanYears.forEach(function (dividendYear) {
                if (dividendYear.value != _this.dividendPlanYears[0].value) {
                    var dividendPlanPerYear = _this.filteredDividendPlanPerDividendPartnerAndRegion.filter(function (yearPlan) { return yearPlan.strYear == dividendYear.value; });
                    if (dividendPlanPerYear.length > 0 && (dividendPlanPerYear.findIndex(function (arrayItem) { return arrayItem.strPlanValue.toString() != "0"; }) != -1)) {
                        var tempArray = [];
                        tempArray = _this.filteredDividendPlanPerDividendPartnerAndRegion.filter(function (item) { return item.strYear == dividendYear.value; });
                        tempArray.forEach(function (item) { return filteredDividendPlanArrayPerRegionPerYear.push(item); });
                    }
                }
                else {
                    var tempArray = [];
                    tempArray = _this.filteredDividendPlanPerDividendPartnerAndRegion.filter(function (item) { return item.strYear == dividendYear.value; });
                    tempArray.forEach(function (item) { return filteredDividendPlanArrayPerRegionPerYear.push(item); });
                }
            });
            filteredDividendPlanArrayPerRegionPerYear.forEach(function (dividendArrayItem) {
                var dividendPlanValue = new clsHierarchyNodePostData_Plans_PlanValues();
                dividendPlanValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanValueDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                dividendPlanValue.Year = Number(dividendArrayItem.strYear);
                dividendPlanValue.Month = Number(dividendArrayItem.strMonthValue);
                if (dividendArrayItem.strMonthValue != "0" && dividendArrayItem.strMonthValue != null) {
                    dividendPlanValue.Value = Number(dividendArrayItem.strPlanValue);
                }
                else {
                    dividendPlanValue.Value = null;
                }
                clsDividendPlan.PlanValues.push(dividendPlanValue);
            });
            _this.nodeDataForPostToServer.Plans.push(clsDividendPlan);
        });
        // end of dividend plan//
        this.nodeDataForPostToServer.PnlSplitValue = null;
        //debugger;
        // region allocation starts
        if (this.blnIsPnlHolder) {
            this.nodeDataForPostToServer.RegionalAllocations = [];
            this.regionAllocations.forEach(function (regionAllocation) {
                var regionAllocationForPost = new clsHierarchyNodePostData_RegionalAllocations();
                regionAllocationForPost.$type = regionAllocation.$type;
                regionAllocationForPost.Percentage = regionAllocation.Percentage;
                regionAllocationForPost.RegionNode = new clsHierarchyNodePostData_RegionalAllocations_RegionNode();
                regionAllocationForPost.RegionNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                regionAllocationForPost.RegionNode.Region = regionAllocation.RegionNode.Region;
                regionAllocationForPost.RegionNode.Name = regionAllocation.RegionNode.Name;
                regionAllocationForPost.RegionNode.Description = regionAllocation.RegionNode.Description;
                regionAllocationForPost.RegionNode.IsMarkedForDeletion = regionAllocation.RegionNode.IsMarkedForDeletion;
                //regionAllocationForPost.RegionNode.NodeType = regionAllocation.RegionNode.NodeType;
                // if (regionAllocation.RegionNode.NodeType.Name != null && regionAllocation.RegionNode.NodeType.Name.trim() != "") {
                //     regionAllocationForPost.RegionNode.NodeType = regionAllocation.RegionNode.NodeType;
                // }
                // else {
                //     let systemNodeTypes: IHierarchyEditNode_Node_NodeType[] = <IHierarchyEditNode_Node_NodeType[]>JSON.parse(localStorage.getItem("systemNodeTypes"));
                //     let nodeType: IHierarchyEditNode_Node_NodeType = this.nodeTypes.find(node => node.Name.toLowerCase().trim() == "region allocation");
                //     if (nodeType) {
                //         regionAllocationForPost.RegionNode.NodeType = nodeType;
                //     }
                // }
                regionAllocationForPost.RegionNode.NodeType = null;
                regionAllocationForPost.RegionNode.IsPnlHolder = regionAllocation.RegionNode.IsPnlHolder;
                regionAllocationForPost.RegionNode.InputYTD = regionAllocation.RegionNode.InputYTD;
                regionAllocationForPost.RegionNode.InputExpectedYTD = regionAllocation.RegionNode.InputExpectedYTD;
                regionAllocationForPost.RegionNode.DividendYTD = regionAllocation.RegionNode.DividendYTD;
                regionAllocationForPost.RegionNode.ReportedMEYTD = regionAllocation.RegionNode.ReportedMEYTD;
                regionAllocationForPost.RegionNode.CanRemove = regionAllocation.RegionNode.CanRemove;
                regionAllocationForPost.RegionNode.InputData = regionAllocation.RegionNode.InputData ? regionAllocation.RegionNode.InputData.$values : [];
                regionAllocationForPost.RegionNode.OutputData = regionAllocation.RegionNode.InputData ? regionAllocation.RegionNode.OutputData.$values : [];
                regionAllocationForPost.RegionNode.PreviousYTDForTrueUp = regionAllocation.RegionNode.PreviousYTDForTrueUp;
                regionAllocationForPost.RegionNode.AllDatesForCurrentReportingDate = regionAllocation.RegionNode.AllDatesForCurrentReportingDate ? regionAllocation.RegionNode.AllDatesForCurrentReportingDate.$values : [];
                regionAllocationForPost.RegionNode.AllMVarDatesForCurrentReportingDate = regionAllocation.RegionNode.AllMVarDatesForCurrentReportingDate ? regionAllocation.RegionNode.AllMVarDatesForCurrentReportingDate.$values : [];
                regionAllocationForPost.RegionNode.HasPnl = regionAllocation.RegionNode.HasPnl;
                regionAllocationForPost.RegionNode.HasMVaR = regionAllocation.RegionNode.HasMVaR;
                regionAllocationForPost.RegionNode.IsActive = regionAllocation.RegionNode.IsActive;
                regionAllocationForPost.RegionNode.InputNameMappings = regionAllocation.RegionNode.InputNameMappings ? regionAllocation.RegionNode.InputNameMappings.$values : [];
                regionAllocationForPost.RegionNode.PreviousMonthEndDate = regionAllocation.RegionNode.PreviousMonthEndDate;
                regionAllocationForPost.RegionNode.PreviousTradeDate = regionAllocation.RegionNode.PreviousTradeDate;
                regionAllocationForPost.RegionNode.HasWorkingCapital = regionAllocation.RegionNode.HasWorkingCapital;
                regionAllocationForPost.RegionNode.Created = regionAllocation.RegionNode.Created;
                regionAllocationForPost.RegionNode.CreatedBy = regionAllocation.RegionNode.CreatedBy;
                regionAllocationForPost.RegionNode.Updated = regionAllocation.RegionNode.Updated;
                regionAllocationForPost.RegionNode.UpdatedBy = regionAllocation.RegionNode.UpdatedBy;
                regionAllocationForPost.RegionNode.Id = 0;
                regionAllocationForPost.DividendPartnerNode = regionAllocation.DividendPartnerNode;
                regionAllocationForPost.BusinessSegmentNode = regionAllocation.BusinessSegmentNode;
                regionAllocationForPost.Created = regionAllocation.Created;
                regionAllocationForPost.CreatedBy = regionAllocation.CreatedBy;
                regionAllocationForPost.Updated = regionAllocation.Updated;
                regionAllocationForPost.UpdatedBy = regionAllocation.UpdatedBy;
                regionAllocationForPost.Id = 0;
                _this.nodeDataForPostToServer.RegionalAllocations.push(regionAllocationForPost);
            });
        }
        else {
            this.nodeDataForPostToServer.RegionalAllocations = null;
        }
        this.nodeDataForPostToServer.SplitType = this.blnIsPnlHolder ? this.strSelectedSplitType : null;
        // region allocation ends
        // tags starts
        this.nodeDataForPostToServer.Tags = this.tags;
        this.nodeDataForPostToServer.Tags.forEach(function (data) {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.TagDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });
        this.nodeDataForPostToServer.Updated = null;
        this.nodeDataForPostToServer.UpdatedBy = null;
        this.nodeDataForPostToServer.UpdateTiming = this.blndisableSelectedUpdateTimingField ? null : this.selectedUpdateTiming;
        if (this.blnWorkingCapitalRegion) {
            this.nodeDataForPostToServer.WorkingCapitalRegion = new clsHierarchyEditNode_WorkingCapital();
            //debugger;
            var workingCapitalRegion = this.regions.find(function (region) { return region.Name == _this.strSelectedWorkingCapitalRegionName; });
            if (workingCapitalRegion) {
                this.nodeDataForPostToServer.WorkingCapitalRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                this.nodeDataForPostToServer.WorkingCapitalRegion.Name = workingCapitalRegion.Name;
                this.nodeDataForPostToServer.WorkingCapitalRegion.IsInUse = workingCapitalRegion.IsInUse;
                this.nodeDataForPostToServer.WorkingCapitalRegion.Created = workingCapitalRegion.Created.toString();
                this.nodeDataForPostToServer.WorkingCapitalRegion.CreatedBy = workingCapitalRegion.CreatedBy;
                this.nodeDataForPostToServer.WorkingCapitalRegion.Updated = workingCapitalRegion.Updated;
                this.nodeDataForPostToServer.WorkingCapitalRegion.UpdatedBy = workingCapitalRegion.UpdatedBy;
                this.nodeDataForPostToServer.WorkingCapitalRegion.Id = workingCapitalRegion.Id;
            }
        }
        else {
            this.nodeDataForPostToServer.WorkingCapitalRegion = null;
        }
        // tags ends
        //debugger;
        //console.log(this.nodeDataForPostToServer);
        this.isRequesting = true;
        this.tPRHierarchyservice.updateNodeLevelDataForEdit(this.nodeDataForPostToServer)
            .subscribe(function (response) {
            //debugger;
            console.log(response);
            if (response.Error) {
                //alert(response.Error);
                _this.stopRefreshing();
                _this.blnShowSaveDialog = false;
                _this.strValidationHeader = "Error";
                _this.strValidationMessage = response.Error;
                _this.blnShowValidationDialog = true;
            }
            else {
                _this.stopRefreshing();
                _this.blnShowModalPouUp = false;
                _this.blnShowSaveDialog = false;
                _this.router.navigateByUrl('/hierarchy');
                _this.appTprHierarchyComponent.loadTree();
            }
        }, function (error) {
            //debugger;
            _this.stopRefreshing();
            console.log(error);
            _this.strValidationHeader = "Error";
            _this.strValidationMessage = error;
            _this.blnShowValidationDialog = true;
        });
    };
    AppTprHierarchyAddChildComponent.prototype.ValidateNodeSave = function () {
        var _this = this;
        //debugger;
        var result = true;
        var uniquenessResult = false;
        // Node name validation for not empty.
        if (this.strNodeName == null || this.strNodeName == undefined || this.strNodeName.length == 0) {
            //alert("Node name should not be empty.");
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Node name should not be empty.";
            result = false;
            return result;
        }
        // Validation for verifying whether the node is active or not.
        if (!this.blnIsActive) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "No changes allowed as node is inactive.";
            result = false;
            return result;
        }
        // Region allocation validation for proper value for a Pnl holder
        if (this.blnIsPnlHolder && this.strRegionAllocationValueCheck != "100") {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "The PNL holder node should have an allocated region. The total of all the region allocaitons has to be 100 percent.";
            result = false;
            return result;
        }
        // Dividend allocation validation for proper value
        if (Number(this.strDividendAllocationValueCheck) > 100) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Dividend allocations for the node must not exceed 100 percent.";
            result = false;
            return result;
        }
        //Mapping Name validation for empty check
        var emptyMappingName = this.mappingNames.find(function (mappingName) { return mappingName.Name.trim() == ""; });
        if (emptyMappingName) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Mapping names must have names value.";
            result = false;
            return result;
        }
        //Mapping Name validation for uniqueness check check        
        var mappingNamesArray = [];
        this.mappingNames.forEach(function (mappingName) { return mappingNamesArray.push(mappingName.Name.toLowerCase().trim()); });
        uniquenessResult = this.checkIfArrayIsUnique(mappingNamesArray);
        if (!uniquenessResult) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Mapping names must have unique name value.";
            result = false;
            return result;
        }
        //debugger;
        var blnInvalidPlanValue = false;
        this.completePnlPlanYearToMonthPerRegion.forEach(function (pnlPlan) {
            if (isNaN(Number(pnlPlan.strPlanValue))) {
                blnInvalidPlanValue = true;
            }
        });
        if (blnInvalidPlanValue) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Invalid plan value. Plan value should be numeric.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        var blnInvalidDividendPlanValue = false;
        this.completeDividendPlanYearToMonthPerRegion.forEach(function (dividendPlan) {
            if (isNaN(Number(dividendPlan.strPlanValue))) {
                blnInvalidDividendPlanValue = true;
            }
        });
        if (blnInvalidDividendPlanValue) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Invalid dividend plan value. Dividend plan value should be numeric.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        // check for node's children with plans
        //debugger;
        this.selectedNode = this.nodeArrays.find(function (node) { return node.NodeId == _this.intSelectedParentNodeID; });
        this.moveNodeArrays = [];
        if (this.selectedNode && (this.completePnlPlanYearToMonthPerRegion.length > 0 || this.completeDividendPlanYearToMonthPerRegion.length > 0)) {
            this.moveNodeArrays.push(this.selectedNode.NodeName);
        }
        console.log("Plan Nodes ->", this.moveNodeArrays);
        if (this.moveNodeArrays.length > 0) {
            this.blnShowSaveDialog = true;
            this.updateHierarchyHeader = "Save changes";
            this.updateHierarchyMessage = "One or more nodes in the hierarchy contains plans. Please review the list below and confirm that you are happy to proceed saving the node.";
            this.updateHierarchyMessage = this.updateHierarchyMessage + "\n";
            this.moveNodeArrays.forEach(function (planNode) {
                _this.updateHierarchyMessage = (_this.updateHierarchyMessage + "\n" + planNode);
            });
            this.updateHierarchyMessage = this.updateHierarchyMessage + "\n\n" + "Saving changes to the hierarchy. Are you happy to proceed?";
            this.showUpdateHierarchyFooter = true;
            result = false;
            return result;
        }
        // If all the validation is successful, then return true.
        result = true;
        return result;
    };
    AppTprHierarchyAddChildComponent.prototype.checkIfArrayIsUnique = function (myArray) {
        return myArray.length === new Set(myArray).size;
    };
    AppTprHierarchyAddChildComponent.prototype.Cancel = function () {
        this.router.navigate(['/hierarchy']);
    };
    AppTprHierarchyAddChildComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/treeView/app.treeViewAddChild.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRHierarchyservice_1.TPRHierarchyservice, router_1.Router, router_1.ActivatedRoute, app_TPRNodeTypeService_1.TPRNodeTypeService, primeng_1.ConfirmationService, app_regionService_1.RegionsService, app_TPRProfitAlertGroupsService_1.TPRProfitAlertGroupsService, app_TPRTagsService_1.TPRTagsService, app_TPRDividendPartnersService_1.TPRDividendPartnersService, app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService, app_TPRCommonService_1.TPRCommonService, app_treeView_component_1.AppTprHierarchyComponent])
    ], AppTprHierarchyAddChildComponent);
    return AppTprHierarchyAddChildComponent;
}());
exports.AppTprHierarchyAddChildComponent = AppTprHierarchyAddChildComponent;
var clsHierarchyEditNode = (function () {
    function clsHierarchyEditNode($type, AlertGroups, BusinessSegmentAllocations, Created, CreatedBy, DividendPartnerAllocations, HasChildren, HierarchyInstanceId, Id, IsMarkedForDeletion, LastUpdatedBy, Level, MVarLimit, MVarRegion, MVarTemporaryLimit, MVarTemporaryLimitExpiryDate, MVarUpdateTiming, Node, NodeType, ParentId, ParentNodeId, Plans, PnlSplitValue, RegionalAllocations, SplitType, Tags, Updated, UpdatedBy, UpdateTiming, WorkingCapitalRegion) {
        if ($type === void 0) { $type = null; }
        if (AlertGroups === void 0) { AlertGroups = null; }
        if (BusinessSegmentAllocations === void 0) { BusinessSegmentAllocations = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (DividendPartnerAllocations === void 0) { DividendPartnerAllocations = ''; }
        if (HasChildren === void 0) { HasChildren = false; }
        if (HierarchyInstanceId === void 0) { HierarchyInstanceId = 0; }
        if (Id === void 0) { Id = 0; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (LastUpdatedBy === void 0) { LastUpdatedBy = null; }
        if (Level === void 0) { Level = 0; }
        if (MVarLimit === void 0) { MVarLimit = null; }
        if (MVarRegion === void 0) { MVarRegion = null; }
        if (MVarTemporaryLimit === void 0) { MVarTemporaryLimit = null; }
        if (MVarTemporaryLimitExpiryDate === void 0) { MVarTemporaryLimitExpiryDate = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (Node === void 0) { Node = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (ParentId === void 0) { ParentId = 0; }
        if (ParentNodeId === void 0) { ParentNodeId = 0; }
        if (Plans === void 0) { Plans = null; }
        if (PnlSplitValue === void 0) { PnlSplitValue = null; }
        if (RegionalAllocations === void 0) { RegionalAllocations = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Tags === void 0) { Tags = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (WorkingCapitalRegion === void 0) { WorkingCapitalRegion = null; }
        this.$type = $type;
        this.AlertGroups = AlertGroups;
        this.BusinessSegmentAllocations = BusinessSegmentAllocations;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.DividendPartnerAllocations = DividendPartnerAllocations;
        this.HasChildren = HasChildren;
        this.HierarchyInstanceId = HierarchyInstanceId;
        this.Id = Id;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.LastUpdatedBy = LastUpdatedBy;
        this.Level = Level;
        this.MVarLimit = MVarLimit;
        this.MVarRegion = MVarRegion;
        this.MVarTemporaryLimit = MVarTemporaryLimit;
        this.MVarTemporaryLimitExpiryDate = MVarTemporaryLimitExpiryDate;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.Node = Node;
        this.NodeType = NodeType;
        this.ParentId = ParentId;
        this.ParentNodeId = ParentNodeId;
        this.Plans = Plans;
        this.PnlSplitValue = PnlSplitValue;
        this.RegionalAllocations = RegionalAllocations;
        this.SplitType = SplitType;
        this.Tags = Tags;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.UpdateTiming = UpdateTiming;
        this.WorkingCapitalRegion = WorkingCapitalRegion;
    }
    return clsHierarchyEditNode;
}());
var clsHierarchyEditNode_Node = (function () {
    function clsHierarchyEditNode_Node($type, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = null; }
        if (OutputData === void 0) { OutputData = null; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = null; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = null; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = null; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = null; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node;
}());
var clsHierarchyEditNode_Node_NodeType = (function () {
    function clsHierarchyEditNode_Node_NodeType($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = ''; }
        if (CreatedBy === void 0) { CreatedBy = ''; }
        if (Updated === void 0) { Updated = ''; }
        if (UpdatedBy === void 0) { UpdatedBy = ''; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node_NodeType;
}());
var clsHierarchyEditNode_Node_InputData = (function () {
    function clsHierarchyEditNode_Node_InputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_InputData;
}());
var clsHierarchyEditNode_Node_OutputData = (function () {
    function clsHierarchyEditNode_Node_OutputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_OutputData;
}());
var clsHierarchyEditNode_Node_AllDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_Node_AllDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_AllDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_Node_InputNameMappings = (function () {
    function clsHierarchyEditNode_Node_InputNameMappings($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_InputNameMappings;
}());
var RootValue = (function () {
    function RootValue(label, NodeName, id, children, Children, data, icon, expandedIcon, collapsedIcon, leaf, expanded, type, parent, partialSelected, $type, HasAnyOutputData, HasPlans, UpdateTiming, NodeId, NodeType, IsActive, Level, ParentId, IsPnlHolder, MVarUpdateTiming, SplitType, Id) {
        if (label === void 0) { label = null; }
        if (NodeName === void 0) { NodeName = null; }
        if (id === void 0) { id = 0; }
        if (children === void 0) { children = null; }
        if (Children === void 0) { Children = null; }
        if (data === void 0) { data = null; }
        if (icon === void 0) { icon = null; }
        if (expandedIcon === void 0) { expandedIcon = null; }
        if (collapsedIcon === void 0) { collapsedIcon = null; }
        if (leaf === void 0) { leaf = null; }
        if (expanded === void 0) { expanded = null; }
        if (type === void 0) { type = null; }
        if (parent === void 0) { parent = null; }
        if (partialSelected === void 0) { partialSelected = null; }
        if ($type === void 0) { $type = null; }
        if (HasAnyOutputData === void 0) { HasAnyOutputData = null; }
        if (HasPlans === void 0) { HasPlans = null; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (NodeId === void 0) { NodeId = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsActive === void 0) { IsActive = null; }
        if (Level === void 0) { Level = null; }
        if (ParentId === void 0) { ParentId = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Id === void 0) { Id = 0; }
        this.label = label;
        this.NodeName = NodeName;
        this.id = id;
        this.children = children;
        this.Children = Children;
        this.data = data;
        this.icon = icon;
        this.expandedIcon = expandedIcon;
        this.collapsedIcon = collapsedIcon;
        this.leaf = leaf;
        this.expanded = expanded;
        this.type = type;
        this.parent = parent;
        this.partialSelected = partialSelected;
        this.$type = $type;
        this.HasAnyOutputData = HasAnyOutputData;
        this.HasPlans = HasPlans;
        this.UpdateTiming = UpdateTiming;
        this.NodeId = NodeId;
        this.NodeType = NodeType;
        this.IsActive = IsActive;
        this.Level = Level;
        this.ParentId = ParentId;
        this.IsPnlHolder = IsPnlHolder;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.SplitType = SplitType;
        this.Id = Id;
    }
    return RootValue;
}());
var clsPlanDataPerRegion = (function () {
    function clsPlanDataPerRegion(strRegionName, TotalPlan, strUpdatedBy, strUpdatedDate) {
        if (strRegionName === void 0) { strRegionName = null; }
        if (TotalPlan === void 0) { TotalPlan = 0; }
        if (strUpdatedBy === void 0) { strUpdatedBy = null; }
        if (strUpdatedDate === void 0) { strUpdatedDate = null; }
        this.strRegionName = strRegionName;
        this.TotalPlan = TotalPlan;
        this.strUpdatedBy = strUpdatedBy;
        this.strUpdatedDate = strUpdatedDate;
    }
    return clsPlanDataPerRegion;
}());
var clsPnlPlanYearToMonthPerRegion = (function () {
    function clsPnlPlanYearToMonthPerRegion(strRegionName, strYear, strMonthDesc, strMonthValue, strPlanValue) {
        if (strRegionName === void 0) { strRegionName = null; }
        if (strYear === void 0) { strYear = null; }
        if (strMonthDesc === void 0) { strMonthDesc = null; }
        if (strMonthValue === void 0) { strMonthValue = null; }
        if (strPlanValue === void 0) { strPlanValue = null; }
        this.strRegionName = strRegionName;
        this.strYear = strYear;
        this.strMonthDesc = strMonthDesc;
        this.strMonthValue = strMonthValue;
        this.strPlanValue = strPlanValue;
    }
    return clsPnlPlanYearToMonthPerRegion;
}());
var clsPlanDataPerDividendPartner = (function () {
    function clsPlanDataPerDividendPartner(strDividendPartnerName, strRegionName, TotalPlan, strUpdatedBy, strUpdatedDate) {
        if (strDividendPartnerName === void 0) { strDividendPartnerName = ''; }
        if (strRegionName === void 0) { strRegionName = ''; }
        if (TotalPlan === void 0) { TotalPlan = 0; }
        if (strUpdatedBy === void 0) { strUpdatedBy = null; }
        if (strUpdatedDate === void 0) { strUpdatedDate = null; }
        this.strDividendPartnerName = strDividendPartnerName;
        this.strRegionName = strRegionName;
        this.TotalPlan = TotalPlan;
        this.strUpdatedBy = strUpdatedBy;
        this.strUpdatedDate = strUpdatedDate;
    }
    return clsPlanDataPerDividendPartner;
}());
var clsDividendPlanYearToMonthPerRegion = (function () {
    function clsDividendPlanYearToMonthPerRegion(strDividendPartnerName, strRegionName, strYear, strMonthDesc, strMonthValue, strPlanValue) {
        if (strDividendPartnerName === void 0) { strDividendPartnerName = null; }
        if (strRegionName === void 0) { strRegionName = null; }
        if (strYear === void 0) { strYear = null; }
        if (strMonthDesc === void 0) { strMonthDesc = null; }
        if (strMonthValue === void 0) { strMonthValue = null; }
        if (strPlanValue === void 0) { strPlanValue = null; }
        this.strDividendPartnerName = strDividendPartnerName;
        this.strRegionName = strRegionName;
        this.strYear = strYear;
        this.strMonthDesc = strMonthDesc;
        this.strMonthValue = strMonthValue;
        this.strPlanValue = strPlanValue;
    }
    return clsDividendPlanYearToMonthPerRegion;
}());
var ProfitAlertGroupArray = (function () {
    function ProfitAlertGroupArray() {
    }
    return ProfitAlertGroupArray;
}());
var clsHierarchyEditNode_AlertGroups_Values = (function () {
    function clsHierarchyEditNode_AlertGroups_Values($type, Alerts, Name, Members, IsInUse, UpdateTiming, TradeDate, ProfitAlertGroupStatusId, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Alerts === void 0) { Alerts = null; }
        if (Name === void 0) { Name = null; }
        if (Members === void 0) { Members = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (UpdateTiming === void 0) { UpdateTiming = 0; }
        if (TradeDate === void 0) { TradeDate = null; }
        if (ProfitAlertGroupStatusId === void 0) { ProfitAlertGroupStatusId = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Alerts = Alerts;
        this.Name = Name;
        this.Members = Members;
        this.IsInUse = IsInUse;
        this.UpdateTiming = UpdateTiming;
        this.TradeDate = TradeDate;
        this.ProfitAlertGroupStatusId = ProfitAlertGroupStatusId;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_AlertGroups_Values;
}());
var clsHierarchyEditNode_Node_InputNameMappings_Value = (function () {
    function clsHierarchyEditNode_Node_InputNameMappings_Value($type, Name, FeedSource, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (FeedSource === void 0) { FeedSource = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.FeedSource = FeedSource;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node_InputNameMappings_Value;
}());
var clsHierarchyEditNode_RegionalAllocations_Values = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode($type, Region, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Region === void 0) { Region = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = null; }
        if (OutputData === void 0) { OutputData = null; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = null; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = null; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = null; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Region = Region;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_Tags_Values = (function () {
    function clsHierarchyEditNode_Tags_Values($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Tags_Values;
}());
var TagsValue = (function () {
    function TagsValue($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return TagsValue;
}());
var clsHierarchyEditNode_WorkingCapital = (function () {
    function clsHierarchyEditNode_WorkingCapital($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_WorkingCapital;
}());
/* Post node data starts here */
var clsHierarchyNodePostData = (function () {
    function clsHierarchyNodePostData($type, AlertGroups, BusinessSegmentAllocations, // change later
        Created, CreatedBy, DividendPartnerAllocations, HasChildren, HierarchyInstanceId, Id, IsMarkedForDeletion, LastUpdatedBy, Level, MVarLimit, // change later
        MVarRegion, MVarTemporaryLimit, // change later
        MVarTemporaryLimitExpiryDate, // change later
        MVarUpdateTiming, Node, NodeType, //change later
        ParentId, ParentNodeId, Plans, PnlSplitValue, // change later
        RegionalAllocations, SplitType, // change later
        Tags, Updated, UpdatedBy, UpdateTiming, WorkingCapitalRegion) {
        if ($type === void 0) { $type = null; }
        if (AlertGroups === void 0) { AlertGroups = []; }
        if (BusinessSegmentAllocations === void 0) { BusinessSegmentAllocations = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (DividendPartnerAllocations === void 0) { DividendPartnerAllocations = []; }
        if (HasChildren === void 0) { HasChildren = false; }
        if (HierarchyInstanceId === void 0) { HierarchyInstanceId = 0; }
        if (Id === void 0) { Id = 0; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (LastUpdatedBy === void 0) { LastUpdatedBy = null; }
        if (Level === void 0) { Level = null; }
        if (MVarLimit === void 0) { MVarLimit = null; }
        if (MVarRegion === void 0) { MVarRegion = null; }
        if (MVarTemporaryLimit === void 0) { MVarTemporaryLimit = null; }
        if (MVarTemporaryLimitExpiryDate === void 0) { MVarTemporaryLimitExpiryDate = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = 0; }
        if (Node === void 0) { Node = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (ParentId === void 0) { ParentId = 0; }
        if (ParentNodeId === void 0) { ParentNodeId = 0; }
        if (Plans === void 0) { Plans = []; }
        if (PnlSplitValue === void 0) { PnlSplitValue = null; }
        if (RegionalAllocations === void 0) { RegionalAllocations = []; }
        if (SplitType === void 0) { SplitType = null; }
        if (Tags === void 0) { Tags = []; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (UpdateTiming === void 0) { UpdateTiming = 0; }
        if (WorkingCapitalRegion === void 0) { WorkingCapitalRegion = null; }
        this.$type = $type;
        this.AlertGroups = AlertGroups;
        this.BusinessSegmentAllocations = BusinessSegmentAllocations;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.DividendPartnerAllocations = DividendPartnerAllocations;
        this.HasChildren = HasChildren;
        this.HierarchyInstanceId = HierarchyInstanceId;
        this.Id = Id;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.LastUpdatedBy = LastUpdatedBy;
        this.Level = Level;
        this.MVarLimit = MVarLimit;
        this.MVarRegion = MVarRegion;
        this.MVarTemporaryLimit = MVarTemporaryLimit;
        this.MVarTemporaryLimitExpiryDate = MVarTemporaryLimitExpiryDate;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.Node = Node;
        this.NodeType = NodeType;
        this.ParentId = ParentId;
        this.ParentNodeId = ParentNodeId;
        this.Plans = Plans;
        this.PnlSplitValue = PnlSplitValue;
        this.RegionalAllocations = RegionalAllocations;
        this.SplitType = SplitType;
        this.Tags = Tags;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.UpdateTiming = UpdateTiming;
        this.WorkingCapitalRegion = WorkingCapitalRegion;
    }
    return clsHierarchyNodePostData;
}());
var clsHierarchyNodePostData_Alerts = (function () {
    function clsHierarchyNodePostData_Alerts($type, Alerts, Name, Members, IsInUse, UpdateTiming, TradeDate, ProfitAlertGroupStatusId, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Alerts === void 0) { Alerts = []; }
        if (Name === void 0) { Name = null; }
        if (Members === void 0) { Members = []; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (UpdateTiming === void 0) { UpdateTiming = 0; }
        if (TradeDate === void 0) { TradeDate = null; }
        if (ProfitAlertGroupStatusId === void 0) { ProfitAlertGroupStatusId = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Alerts = Alerts;
        this.Name = Name;
        this.Members = Members;
        this.IsInUse = IsInUse;
        this.UpdateTiming = UpdateTiming;
        this.TradeDate = TradeDate;
        this.ProfitAlertGroupStatusId = ProfitAlertGroupStatusId;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Alerts;
}());
var clsHierarchyEditNode_MVarRegion = (function () {
    function clsHierarchyEditNode_MVarRegion($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_MVarRegion;
}());
var clsHierarchyNodePostData_Node = (function () {
    function clsHierarchyNodePostData_Node($type, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = 0; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = []; }
        if (OutputData === void 0) { OutputData = []; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = []; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = []; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = []; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Node;
}());
var clsHierarchyNodePostData_Plans = (function () {
    function clsHierarchyNodePostData_Plans($type, DividendPartner, Region, PlanValues, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (DividendPartner === void 0) { DividendPartner = null; }
        if (Region === void 0) { Region = null; }
        if (PlanValues === void 0) { PlanValues = []; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.DividendPartner = DividendPartner;
        this.Region = Region;
        this.PlanValues = PlanValues;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans;
}());
var clsHierarchyNodePostData_Plans_Region = (function () {
    function clsHierarchyNodePostData_Plans_Region($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_Region;
}());
var clsHierarchyNodePostData_Plans_PlanValues = (function () {
    function clsHierarchyNodePostData_Plans_PlanValues($type, Year, Month, Value, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Year === void 0) { Year = 0; }
        if (Month === void 0) { Month = 0; }
        if (Value === void 0) { Value = 0; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Year = Year;
        this.Month = Month;
        this.Value = Value;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_PlanValues;
}());
var clsHierarchyNodePostData_Plans_DividendPartner = (function () {
    function clsHierarchyNodePostData_Plans_DividendPartner($type, Name, IsInUse, BusinessSegment, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (BusinessSegment === void 0) { BusinessSegment = null; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.BusinessSegment = BusinessSegment;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_DividendPartner;
}());
var clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment = (function () {
    function clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment;
}());
var clsHierarchyNodePostData_RegionalAllocations = (function () {
    function clsHierarchyNodePostData_RegionalAllocations($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_RegionalAllocations;
}());
var clsHierarchyNodePostData_RegionalAllocations_RegionNode = (function () {
    function clsHierarchyNodePostData_RegionalAllocations_RegionNode($type, Region, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Region === void 0) { Region = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = []; }
        if (OutputData === void 0) { OutputData = []; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = []; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = []; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = []; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Region = Region;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_RegionalAllocations_RegionNode;
}());
//# sourceMappingURL=app.treeViewAddChild.component.js.map