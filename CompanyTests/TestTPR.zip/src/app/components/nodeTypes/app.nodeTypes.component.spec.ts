﻿import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppNodeTypeComponent } from './app.nodeTypes.component';
import { TPRNodeTypeService } from '../../service/app.TPRNodeTypeService';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { addMatchers, click } from '../../../testing';

import INodeTypesValue = NodeTypeNamespace.INodeTypesValue;


describe('AppNodeTypeComponent test cases', () => {
    let de: DebugElement;
    let comp: AppNodeTypeComponent;
    let fixture: ComponentFixture<AppNodeTypeComponent>;
    let nodeTypeService: TPRNodeTypeService;
    let spy: jasmine.Spy;

    //async before each
    beforeEach(async(() => {
        let tprNodeServiceStub = {
            getNodeTypesObservable: true,
            updateNodeTypesObservable: true
        };

        TestBed.configureTestingModule({
            declarations: [AppNodeTypeComponent],
            imports: [],
            providers: [TPRNodeTypeService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));


    beforeEach(() => {
        fixture = TestBed.createComponent(AppNodeTypeComponent); // creates the fixture of the testing component

        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });

    // test whether the component got successfully initialised
    it('should create component', () => expect(comp).toBeDefined());

    // test for service mockup
    // Tag service actually injected to the component.
    nodeTypeService = fixture.debugElement.injector.get(TPRNodeTypeService);

    // Create test mockup class
    let nodeTypesMockUp: NodeTypesValueTestMockup = new NodeTypesValueTestMockup();
    let nodeTypes: INodeTypesValue[] = [];

    it('should not call the getNodeTypesObservable method before OnInit', () => {
        // Setup spy on the 'getNodeTypesObservable' method
        spy = spyOn(nodeTypeService, 'getNodeTypesObservable')
            .and.returnValue(Promise.resolve(nodeTypesMockUp));

        expect(spy.calls.any()).toBe(false, 'getNodeTypesObservable not yet called');
    });

    it('should call the getNodeTypesObservable method after component initialized', () => {
        // Setup spy on the 'getNodeTypesObservable' method
        spy = spyOn(nodeTypeService, 'getNodeTypesObservable')
            .and.returnValue(Promise.resolve(nodeTypesMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getNodeTypesObservable called');
    });

    it('should raise Add button click event', () => {
        let displayDialog: boolean = true;
        let newNodeType: boolean = true;
        let blnValidationResult: boolean = true;

        de = fixture.debugElement.query(By.css('#btnAdd'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newNodeType).toBe(newNodeType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });

    it('should raise Save button click event', () => {
        let nodeType: INodeTypesValue = new NodeTypesValueTestMockup('', 'Test', false, false, '', '', '', '', 0); // Creating testmockup object
        comp.nodeType = nodeType; // initializing the tagType object with the test mockup object

        de = fixture.debugElement.query(By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.nodeTypes.indexOf(nodeType)).toBeGreaterThan(-1);
    });

    it('should raise SavetoDatabase button click event', () => {
        let blnPushDataToDatabase: boolean = true;
        let blnSavedOrDeleted: boolean = true;
        let strSavedMessage: string = "Data saved successfully";

        de = fixture.debugElement.query(By.css('#btnSaveDataToServer'));

        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(nodeTypeService, 'updateNodeTypesObservable')
            .and.returnValue(Promise.resolve(nodeTypesMockUp));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        fixture.detectChanges();

        expect(spy.calls.any()).toBe(true, 'updateNodeTypesObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});

class NodeTypesValueTestMockup implements INodeTypesValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}