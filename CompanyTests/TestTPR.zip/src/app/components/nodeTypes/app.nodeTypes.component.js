"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var primeng_2 = require('primeng/primeng');
var app_TPRNodeTypeService_1 = require('../../service/app.TPRNodeTypeService');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var AppNodeTypeComponent = (function () {
    function AppNodeTypeComponent(tPRNodeTypeService, confirmationService, tprCommonService, serviceHelper) {
        this.tPRNodeTypeService = tPRNodeTypeService;
        this.confirmationService = confirmationService;
        this.tprCommonService = tprCommonService;
        this.serviceHelper = serviceHelper;
        this.nodeType = new NodeTypesValue();
        this.msgs = [];
        this.blnSavedOrDeleted = false;
        this.successMessage = false;
        this.failureMessage = false;
        this.Message = "";
        this.clsMessage = {};
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.blnPushDataToDatabase = false;
        this.strErrorMessage = "";
        this.blnShowPopUp = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.isRequesting = false;
        this.blnShowDialog = false;
        this.disableSave = false;
        this.canEdit = false;
    }
    AppNodeTypeComponent.prototype.ngOnInit = function () {
        this.isRequesting = true;
        this.loadData();
        console.log("Checking local storage...");
        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);
        console.log("Is Save Disabled ->", this.disableSave);
        this.cols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
    };
    AppNodeTypeComponent.prototype.loadData = function () {
        var _this = this;
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.tPRNodeTypeService.getNodeTypesObservable()
            .subscribe(function (data) { return _this.setNodeTypeData(data); });
    };
    AppNodeTypeComponent.prototype.setNodeTypeData = function (data) {
        var _this = this;
        this.nodeTypes = data.Result.NodeTypes.$values;
        //console.log("nodeTypes->", this.nodeTypes);
        this.nodeTypes = this.nodeTypes.filter(function (nodeType) { return nodeType.Editable == true; });
        this.nodeTypes.forEach(function (node) {
            node.Updated != null ? node.Updated = _this.tprCommonService.getFormattedSystemDate(new Date(node.Updated)) : null;
        });
        this.stopRefreshing();
    };
    AppNodeTypeComponent.prototype.showDialogToAdd = function () {
        this.newNodeType = true;
        this.nodeType = new NodeTypesValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppNodeTypeComponent.prototype.save = function () {
        var _this = this;
        //console.log(this.tagType);
        if (this.nodeType.Name == null || this.nodeType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.strErrorMessage = "'Name' should not be empty.";
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            this.nodeType.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;
            if (this.newNodeType) {
                //this.nodeTypes.push(this.nodeType);
                var index = this.nodeTypes.indexOf(this.nodeTypes.find(function (node) { return node.Name.toLowerCase().trim() == _this.nodeType.Name.toLowerCase().trim(); }));
                if (index == -1) {
                    this.nodeTypes.push(this.nodeType);
                }
                else {
                    this.strErrorMessage = this.nodeType.Name + " already exists. Name should be unique.";
                    this.clsHighlightInvalidData = {};
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };
                    //this.nodeType.Name = "";
                    return false;
                }
            }
            else
                this.nodeTypes[this.findSelectedNodeTypeIndex()] = this.nodeType;
        }
        this.nodeType = null;
        this.displayDialog = false;
    };
    AppNodeTypeComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = false;
        var nodeNamesArray = [];
        var emptyNodeType = this.nodeTypes.find(function (item) { return item.Name.trim() == ""; });
        if (emptyNodeType) {
            this.blnShowPopUp = true;
            this.Status = "Error";
            this.ValidationMessage = "'Name' should not be empty.";
        }
        else {
            this.nodeTypes.forEach(function (node) { return nodeNamesArray.push(node.Name.toLowerCase().trim()); });
            var uniquenessResult = this.checkIfArrayIsUnique(nodeNamesArray);
            if (uniquenessResult) {
                this.SaveDataToDataBase(action);
            }
            else {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = "'Name' should be unique.";
            }
        }
    };
    AppNodeTypeComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentNodeType = event;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Node Type?',
            accept: function () {
                _this.nodeTypes.splice(_this.findNodeTypeIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });
        this.nodeType = null;
    };
    AppNodeTypeComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.isRequesting = true;
        this.tPRNodeTypeService.updateNodeTypesObservable(this.nodeTypes)
            .subscribe(function (response) {
            console.log("Response ->", response);
            if (response.Error) {
                _this.blnShowDialog = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
                _this.stopRefreshing();
            }
            else {
                //this.ShowMessageOnSaveorDeleteData(response, action);
                _this.blnShowDialog = true;
                _this.Status = "Success";
                console.log("Action ->", action);
                if (action == "save") {
                    _this.ValidationMessage = "Node Types Data is saved successfully";
                }
                else if (action == "delete") {
                    _this.ValidationMessage = "The Selected Node Type is deleted successfully";
                }
                _this.loadData();
                _this.blnSavedOrDeleted = true;
            }
        }, function (error) {
            _this.blnShowDialog = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
            _this.stopRefreshing();
        });
    };
    AppNodeTypeComponent.prototype.onRowSelect = function (event) {
        this.newNodeType = false;
        this.nodeType = this.cloneNodeType(event.data);
    };
    AppNodeTypeComponent.prototype.cloneNodeType = function (c) {
        var nodeType = new NodeTypesValue();
        for (var prop in c) {
            nodeType[prop] = c[prop];
        }
        return nodeType;
    };
    AppNodeTypeComponent.prototype.findSelectedNodeTypeIndex = function () {
        return this.nodeTypes.indexOf(this.selectedNodeType);
    };
    AppNodeTypeComponent.prototype.findNodeTypeIndexForDelete = function () {
        return this.nodeTypes.indexOf(this.currentNodeType);
    };
    AppNodeTypeComponent.prototype.checkIfArrayIsUnique = function (myArray) {
        return myArray.length === new Set(myArray).size;
    };
    AppNodeTypeComponent.prototype.refreshData = function (nodeTypeDataTable) {
        this.isRequesting = true;
        this.nodeTypeDataTable.reset();
        this.loadData();
    };
    AppNodeTypeComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    __decorate([
        core_1.ViewChild('nodeTypeDataTable'), 
        __metadata('design:type', primeng_1.DataTable)
    ], AppNodeTypeComponent.prototype, "nodeTypeDataTable", void 0);
    AppNodeTypeComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/nodeTypes/app.nodeTypes.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRNodeTypeService_1.TPRNodeTypeService, primeng_2.ConfirmationService, app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper])
    ], AppNodeTypeComponent);
    return AppNodeTypeComponent;
}());
exports.AppNodeTypeComponent = AppNodeTypeComponent;
var NodeTypesValue = (function () {
    function NodeTypesValue($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return NodeTypesValue;
}());
//# sourceMappingURL=app.nodetypes.component.js.map