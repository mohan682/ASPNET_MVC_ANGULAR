"use strict";
var testing_1 = require('@angular/core/testing');
var platform_browser_1 = require('@angular/platform-browser');
var app_nodeTypes_component_1 = require('./app.nodeTypes.component');
var app_TPRNodeTypeService_1 = require('../../service/app.TPRNodeTypeService');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var testing_2 = require('../../../testing');
describe('AppNodeTypeComponent test cases', function () {
    var de;
    var comp;
    var fixture;
    var nodeTypeService;
    var spy;
    //async before each
    beforeEach(testing_1.async(function () {
        var tprNodeServiceStub = {
            getNodeTypesObservable: true,
            updateNodeTypesObservable: true
        };
        testing_1.TestBed.configureTestingModule({
            declarations: [app_nodeTypes_component_1.AppNodeTypeComponent],
            imports: [],
            providers: [app_TPRNodeTypeService_1.TPRNodeTypeService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(app_nodeTypes_component_1.AppNodeTypeComponent); // creates the fixture of the testing component
        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });
    // test whether the component got successfully initialised
    it('should create component', function () { return expect(comp).toBeDefined(); });
    // test for service mockup
    // Tag service actually injected to the component.
    nodeTypeService = fixture.debugElement.injector.get(app_TPRNodeTypeService_1.TPRNodeTypeService);
    // Create test mockup class
    var nodeTypesMockUp = new NodeTypesValueTestMockup();
    var nodeTypes = [];
    it('should not call the getNodeTypesObservable method before OnInit', function () {
        // Setup spy on the 'getNodeTypesObservable' method
        spy = spyOn(nodeTypeService, 'getNodeTypesObservable')
            .and.returnValue(Promise.resolve(nodeTypesMockUp));
        expect(spy.calls.any()).toBe(false, 'getNodeTypesObservable not yet called');
    });
    it('should call the getNodeTypesObservable method after component initialized', function () {
        // Setup spy on the 'getNodeTypesObservable' method
        spy = spyOn(nodeTypeService, 'getNodeTypesObservable')
            .and.returnValue(Promise.resolve(nodeTypesMockUp));
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getNodeTypesObservable called');
    });
    it('should raise Add button click event', function () {
        var displayDialog = true;
        var newNodeType = true;
        var blnValidationResult = true;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAdd'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newNodeType).toBe(newNodeType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });
    it('should raise Save button click event', function () {
        var nodeType = new NodeTypesValueTestMockup('', 'Test', false, false, '', '', '', '', 0); // Creating testmockup object
        comp.nodeType = nodeType; // initializing the tagType object with the test mockup object
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.nodeTypes.indexOf(nodeType)).toBeGreaterThan(-1);
    });
    it('should raise SavetoDatabase button click event', function () {
        var blnPushDataToDatabase = true;
        var blnSavedOrDeleted = true;
        var strSavedMessage = "Data saved successfully";
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnSaveDataToServer'));
        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(nodeTypeService, 'updateNodeTypesObservable')
            .and.returnValue(Promise.resolve(nodeTypesMockUp));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'updateNodeTypesObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});
var NodeTypesValueTestMockup = (function () {
    function NodeTypesValueTestMockup($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return NodeTypesValueTestMockup;
}());
//# sourceMappingURL=app.nodeTypes.component.spec.js.map