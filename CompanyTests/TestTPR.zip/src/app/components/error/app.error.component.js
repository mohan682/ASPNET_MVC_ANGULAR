"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var AppErrorComponent = (function () {
    function AppErrorComponent(confirmationService, tprCommonService, serviceHelper) {
        this.confirmationService = confirmationService;
        this.tprCommonService = tprCommonService;
        this.serviceHelper = serviceHelper;
    }
    AppErrorComponent.prototype.ngOnInit = function () {
        console.log('customErrorComponent | ngOnInit...');
    };
    AppErrorComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppErrorComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/error/app.error.component.html'
        }), 
        __metadata('design:paramtypes', [primeng_1.ConfirmationService, app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper])
    ], AppErrorComponent);
    return AppErrorComponent;
}());
exports.AppErrorComponent = AppErrorComponent;
//# sourceMappingURL=app.error.component.js.map