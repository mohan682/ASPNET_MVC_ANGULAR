"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var app_dashboardData_service_1 = require('../../service/app.dashboardData.service');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var app_component_1 = require('../../app.component');
var primeng_1 = require('primeng/primeng');
var x2js = require('x2js');
var AppDashboard = (function () {
    function AppDashboard(dashboardDataService, tPRcommonService, confirmationService, serviceHelper, router, appComponent) {
        this.dashboardDataService = dashboardDataService;
        this.tPRcommonService = tPRcommonService;
        this.confirmationService = confirmationService;
        this.serviceHelper = serviceHelper;
        this.router = router;
        this.appComponent = appComponent;
        this.msgs = [];
        this.displayMessage = false;
        this.blnShowPopUp = false;
        this.disabled = false;
        this.reportingdatestatus = "";
        this.isLocked = false;
        this.comments = [];
        this.commentsjson = [];
        this.blnShowErrorModal = false;
        this.arrErrorDetails = [];
        this.blnShowChangesModal = false;
        this.arrChangesDetails = [];
        this.isCalculating = false;
        this.isPublishDisabled = false;
        this.isRollBusinessDateDisabled = false;
        this.isLockBusinessDateDisabled = false;
        this.userRoles = [];
        this.isRequesting = false;
        this.loadLinks = false;
        this.isPublishing = false;
        this.initiateCalc = false;
    }
    AppDashboard.prototype.ngOnInit = function () {
        var _this = this;
        this.dashboardItems1 = [
            { label: 'Calculate PnL', icon: 'fa-calculator', command: function (event) { return _this.processCalculation(); }, disabled: false },
            { label: 'Publish', icon: 'fa-sign-out', command: null, disabled: false },
            { label: 'Roll Business Date', icon: 'fa-calendar-plus-o', disabled: false, command: function (event) { return _this.process("roll"); } },
            { label: 'Lock Business Date', icon: 'fa-lock', disabled: false },
            { label: 'Reset Calculation Flag', icon: 'fa-flag', command: function (event) { return _this.resetCalcFlag(); }, disabled: false }
        ];
        this.cols = [
            { field: 'Source', header: 'Source' },
            { field: 'FileType', header: 'File Type' },
            { field: 'State', header: 'Status' },
            { field: 'Name', header: 'Activity log' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }
        this.serviceHelper.importSettings()
            .subscribe(function (data) { return _this.getConstants(data); });
        this.load();
    };
    AppDashboard.prototype.stopRefreshing = function () {
        this.isRequesting = false;
    };
    AppDashboard.prototype.resetItems = function () {
        var _this = this;
        this.dashboardItems1 = [
            { label: 'Calculate PnL', icon: 'fa-calculator', command: function (event) { return _this.processCalculation(); }, disabled: false },
            { label: 'Publish', icon: 'fa-sign-out', command: null, disabled: false },
            { label: 'Roll Business Date', icon: 'fa-calendar-plus-o', disabled: false, command: function (event) { return _this.process("roll"); } },
            { label: 'Lock Business Date', icon: 'fa-lock', disabled: false },
            { label: 'Reset Calculation Flag', icon: 'fa-flag', command: function (event) { return _this.resetCalcFlag(); }, disabled: false }
        ];
    };
    AppDashboard.prototype.getConstants = function (data) {
        this.constants = data;
    };
    AppDashboard.prototype.authorizeUser = function () {
        this.disableLinks(false);
    };
    AppDashboard.prototype.isUserAuthorised = function (action) {
        var _this = this;
        switch (action) {
            case "calculate":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; }) ||
                        (this.userRoles.some(function (x) { return x == _this.constants.TPRMarginManagement; }) && this.isPublished));
            // ((this.userRoles.some(x => x == this.constants.TPRSuperUser) && !this.isPublished) ||
            //     ((this.userRoles.some(x => x == this.constants.TPRMarginManagement) ||
            //         this.userRoles.some(x => x == this.constants.RoleSystemAdmin)) && this.isPublished))
            case "publish":
            case "lockBusinessDate":
            case "rollBusinessDate":
            case "resetCalculationFlag":
                return this.userRoles != undefined && this.constants != undefined &&
                    this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; });
        }
        return false;
    };
    AppDashboard.prototype.load = function () {
        var _this = this;
        this.isRequesting = true;
        this.loadLinks = true;
        this.resetItems();
        this.tPRcommonService.getSystemDateObservable().subscribe(function (data2) { return _this.setBusinessDate(data2); });
        this.dashboardDataService.getLastCalculatedObservable().subscribe(function (files) { return _this.setLastCalculatedData(files); });
        this.dashboardDataService.getPublishStatusObservable().subscribe(function (data3) { return _this.setPublishStatus(data3); });
        this.dashboardDataService.getLockedStatusObservable().subscribe(function (data) { return _this.setLockedStatus(data); });
    };
    ///Refresh button
    AppDashboard.prototype.refresh = function () {
        var _this = this;
        localStorage.setItem("CalcFlag", this.isCalculating.toString());
        if (!this.isPublished) {
            this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(function (data) {
                _this.checkIfCalculating(data);
                if (localStorage.getItem("CalcFlag") && localStorage.getItem("CalcFlag") == "true" && !_this.isCalculating) {
                    _this.updateStatus = "Calculate PnL";
                    _this.validationMessage = 'Calculation is completed successfully for business date ' + _this.date4s;
                    _this.blnShowPopUp = true;
                    ;
                }
            });
        }
        else {
            this.dashboardDataService.getIsCalculatingObservable(this.date5).subscribe(function (data) {
                _this.checkIfCalculating(data);
                if (localStorage.getItem("CalcFlag") && localStorage.getItem("CalcFlag") == "true" && !_this.isCalculating.toString()) {
                    _this.updateStatus = "Calculate PnL for next reporting day";
                    _this.validationMessage = 'Calculation is completed successfully for business date ' + _this.date5.toString();
                    _this.blnShowPopUp = true;
                }
            });
        }
    };
    AppDashboard.prototype.checkIfCalculating = function (data) {
        this.isCalculating = data.Result;
        console.log("checkIfCalculating ->", this.isCalculating);
        this.disableLinks(this.isCalculating);
    };
    // public checkForNextDayIfCalculating(data: any): void {
    //     this.isCalculating = data.Result;
    //     console.log("checkForNextDayIfCalculating ->", this.isCalculating);
    //     this.disableLinks(this.isCalculating);
    // }
    AppDashboard.prototype.setLockedStatus = function (data) {
        var _this = this;
        this.lockstatus = data.Result.NumericValue;
        console.log("set locked status", this.lockstatus);
        if (this.lockstatus == 1) {
            this.reportingdatestatus = "Locked";
            this.isLocked = true;
            this.dashboardItems1[3].label = "Unlock Business Date";
            this.dashboardItems1[3].command = function (event) { return _this.lockOrUnlock(); };
        }
        else if (this.lockstatus == 0) {
            this.reportingdatestatus = "Unlocked";
            this.isLocked = false;
            this.dashboardItems1[3].label = "Lock Business Date";
            this.dashboardItems1[3].command = function (event) { return _this.lockOrUnlock(); };
        }
        this.authorizeUser();
        this.loadLinks = false;
        this.stopRefreshing();
    };
    AppDashboard.prototype.setBusinessDate = function (data) {
        var _this = this;
        console.log("System Date ->", data.Result.DateValue);
        var myDate = new Date(data.Result.DateValue);
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var businessDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        var output = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        this.date4 = output.toString();
        var outputs = myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        this.date4s = outputs.toString();
        console.log("Business date as being passed to service from inside method is " + this.date4);
        this.dashboardDataService.getDashboardDataObservable(this.date4).subscribe(function (response) {
            if (response.Error) {
                _this.updateStatus = "Error";
                _this.validationMessage = response.Error;
                _this.blnShowPopUp = true;
                console.log(response.Error);
            }
            else {
                _this.setDashboardData(response);
            }
        });
        this.date3 = myDate;
        // this.nextReportingDate = new Date();
        // this.nextReportingDate.setDate(this.date3.getDate() + 1);
        this.nextReportingDate = this.appComponent.getPreviousorNextWorkingDay(this.date3, false);
        var output2 = this.nextReportingDate.getDate() + ' ' + m_names[this.nextReportingDate.getMonth()] + ' ' + this.nextReportingDate.getFullYear();
        this.date5 = output2.toString();
        //Check if any calc is in progress
        this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(function (data) { return _this.checkIfCalculating(data); });
        //check for next day calc
        // if (!this.date5) {
        if (this.date5) {
            this.dashboardDataService.getIsCalculatingObservable(this.date5).subscribe(function (data) { return _this.checkIfCalculating(data); });
        }
    };
    AppDashboard.prototype.setPublishStatus = function (data) {
        var _this = this;
        console.log("publish status", data.Result.NumericValue);
        this.status = data.Result.NumericValue;
        if (this.status == 0) {
            this.isPublished = false;
            this.publishstatus = "Unpublished";
            this.publishButtonText = "Publish";
            this.dashboardItems1[0].label = "Calculate PnL";
            this.dashboardItems1[0].command = function (event) { return _this.processCalculation(); };
        }
        else {
            this.isPublished = true;
            this.publishstatus = "Published";
            this.publishButtonText = "UnPublish";
            this.dashboardItems1[0].label = "Calculate PnL for next reporting day";
            this.dashboardItems1[0].command = function (event) { return _this.processCalculation(); };
        }
        localStorage.setItem("PublishStatus", this.publishstatus);
        this.dashboardItems1[1].label = this.publishButtonText;
        this.dashboardItems1[1].command = function (event) { return _this.process("pub"); };
        this.dashboardItems1[1].icon = 'fa-sign-out';
        this.authorizeUser();
    };
    AppDashboard.prototype.setPublishData = function () {
        var _this = this;
        this.dashboardDataService.getPublishStatusObservable().subscribe(function (data3) { return _this.setPublishStatus(data3); });
    };
    AppDashboard.prototype.setLockedData = function () {
        var _this = this;
        this.dashboardDataService.getLockedStatusObservable().subscribe(function (data3) { return _this.setLockedStatus(data3); });
    };
    AppDashboard.prototype.process = function (action) {
        var _this = this;
        console.log("processCalculation");
        // this.isRequesting = true;
        this.loadLinks = true;
        this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(function (data) {
            _this.checkIfCalculating(data);
            // this.stopRefreshing();
            _this.loadLinks = false;
            if (!_this.isCalculating) {
                switch (action) {
                    case "pub":
                        _this.publishOrUnpublishData();
                        break;
                    case "roll":
                        _this.rollBusinessDate();
                        break;
                }
            }
            else {
                if (!_this.isPublished) {
                    _this.updateStatus = "Calculation Alert";
                    _this.validationMessage = 'Calculation has been initiated by another user for business date ' + _this.date4s + '. Please wait till the calculation is completed.';
                }
                else {
                    _this.updateStatus = "Calculation Alert";
                    _this.validationMessage = 'Calculation has been initiated by another user for business date ' + _this.date5.toString() + '. Please wait till the calculation is completed.';
                }
                _this.blnShowPopUp = true;
            }
        });
    };
    AppDashboard.prototype.lockOrUnlock = function () {
        var _this = this;
        this.displayMessage = true;
        this.disableLinks(true);
        console.log("lock status", this.lockstatus);
        if (this.lockstatus == 1) {
            this.confirmationService.confirm({
                header: 'Unlock Reporting Date',
                message: 'The system reporting date - ' + this.date4s + ' - will be unlocked. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: function () {
                    _this.dashboardDataService.getUnLockedObservable().subscribe(function (response) {
                        if (response.Error) {
                            _this.updateStatus = "Error";
                            _this.validationMessage = response.Error;
                            _this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                        }
                        else {
                            _this.updateStatus = "Unlocked";
                            _this.validationMessage = 'The reporting date ' + _this.date4s + ' has been unlocked.';
                            _this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            _this.setLockedData();
                            _this.disableLinks(false);
                        }
                    });
                },
                reject: function () { _this.disableLinks(false); }
            });
        }
        else if (this.lockstatus == 0) {
            this.confirmationService.confirm({
                header: 'Lock Reporting Date',
                message: 'The system reporting date - ' + this.date4s + ' - will be locked. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: function () {
                    _this.dashboardDataService.getLockedObservable().subscribe(function (response) {
                        if (response.Error) {
                            _this.updateStatus = "Error";
                            _this.validationMessage = response.Error;
                            _this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                        }
                        else {
                            _this.updateStatus = "Locked";
                            _this.validationMessage = 'The reporting date ' + _this.date4s + ' has been successfully locked.';
                            _this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            _this.setLockedData();
                            _this.disableLinks(false);
                        }
                    });
                },
                reject: function () { _this.disableLinks(false); }
            });
        }
    };
    AppDashboard.prototype.publishOrUnpublishData = function () {
        var _this = this;
        this.disableLinks(true);
        this.displayMessage = true;
        if (this.status == 0) {
            this.confirmationService.confirm({
                header: 'Publishing data',
                message: 'The PNL data for reporting date ' + this.date4s + ' will be published. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: function () {
                    _this.isPublishing = true;
                    _this.dashboardDataService.getPublishObservable(_this.date4).subscribe(function (response) {
                        if (response.Error) {
                            _this.updateStatus = "Error";
                            _this.validationMessage = response.Error;
                            _this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                            _this.isPublishing = false;
                        }
                        else {
                            _this.load();
                            _this.updateStatus = "Data Published";
                            _this.validationMessage = 'The PNL data for reporting date ' + _this.date4s + ' has been successfully published.';
                            _this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            _this.setPublishData();
                            _this.disableLinks(false);
                            _this.isPublishing = false;
                        }
                    });
                },
                reject: function () { _this.disableLinks(false); }
            });
        }
        else {
            this.confirmationService.confirm({
                header: 'Unpublishing data',
                message: 'The PNL data for reporting date ' + this.date4s + ' will be unpublished. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: function () {
                    _this.isPublishing = true;
                    _this.dashboardDataService.getUnPublishObservable(_this.date4).subscribe(function (response) {
                        if (response.Error) {
                            _this.updateStatus = "Error";
                            _this.validationMessage = response.Error;
                            _this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                            _this.isPublishing = false;
                        }
                        else {
                            _this.load();
                            _this.updateStatus = "Data unpublished";
                            _this.validationMessage = 'The PNL data for reporting date ' + _this.date4s + ' has been successfully unpublished.';
                            _this.blnShowPopUp = true;
                            _this.setPublishData();
                            _this.disableLinks(false);
                            _this.isPublishing = false;
                        }
                    });
                },
                reject: function () { _this.disableLinks(false); }
            });
        }
    };
    AppDashboard.prototype.rollBusinessDate = function () {
        var _this = this;
        this.confirmationService.confirm({
            header: 'Roll Business Date',
            message: 'The system reporting date - ' + this.date4s + '- will be rolled to the next working date. Would you like to proceed?',
            rejectVisible: true,
            acceptVisible: true,
            accept: function () {
                _this.disableLinks(true);
                _this.dashboardDataService.rollBusinessDateObservable().subscribe(function (response) {
                    if (response.Error) {
                        _this.updateStatus = "Error";
                        _this.validationMessage = response.Error;
                        _this.blnShowPopUp = true;
                        console.log("error", response.Error);
                        _this.disableLinks(false);
                    }
                    else {
                        _this.tPRcommonService.getSystemDateObservable().subscribe(function (data2) { return _this.setBusinessDate(data2); });
                        _this.appComponent.RefreshEnvironmentData();
                        _this.load();
                        _this.updateStatus = 'Roll Business Date';
                        _this.validationMessage = 'The system has been rolled to the next business date';
                        _this.blnShowPopUp = true;
                        console.log("error", response.Error);
                        _this.disableLinks(false);
                    }
                });
            },
            reject: function () { _this.disableLinks(false); }
        });
    };
    AppDashboard.prototype.processCalculation = function () {
        var _this = this;
        // this.isRequesting = true;
        this.loadLinks = true;
        if (!this.isPublished) {
            this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(function (data) {
                _this.checkIfCalculating(data);
                // this.stopRefreshing();
                _this.loadLinks = false;
                if (!_this.isCalculating) {
                    _this.calculatePnL();
                }
                else {
                    _this.updateStatus = "Calculate PnL";
                    _this.validationMessage = 'Calculation has already been initiated by another user for business date ' + _this.date4s;
                    _this.blnShowPopUp = true;
                }
            });
        }
        else {
            this.dashboardDataService.getIsCalculatingObservable(this.date5).subscribe(function (data) {
                _this.checkIfCalculating(data);
                // this.stopRefreshing();
                _this.loadLinks = false;
                if (!_this.isCalculating) {
                    _this.calculateNextDayPnL();
                }
                else {
                    _this.updateStatus = "Calculate PnL for next reporting day";
                    _this.validationMessage = 'Calculation has already been initiated by another user for business date ' + _this.date5.toString();
                    _this.blnShowPopUp = true;
                }
            });
        }
    };
    AppDashboard.prototype.calculatePnL = function () {
        var _this = this;
        console.log("Start Calculating...");
        this.initiateCalc = true;
        this.isCalculating = true;
        this.disableLinks(true);
        this.dashboardDataService.getCalculateObservable(this.date4)
            .subscribe(function (response) {
            if (response.Error) {
                _this.updateStatus = "Error";
                _this.validationMessage = response.Error;
                _this.blnShowPopUp = true;
                _this.disableLinks(false);
                _this.initiateCalc = false;
                console.log(response.Error);
            }
            else {
                _this.load();
                _this.updateStatus = "Calculate PnL";
                _this.validationMessage = 'Calculation is completed successfully for business date ' + _this.date4.toString();
                _this.blnShowPopUp = true;
                _this.initiateCalc = false;
                console.log(response.Error);
                _this.isCalculating = false;
                // this.setLastCalcData();
                _this.disableLinks(false);
            }
        });
    };
    AppDashboard.prototype.calculateNextDayPnL = function () {
        var _this = this;
        this.initiateCalc = true;
        this.isCalculating = true;
        this.disableLinks(true);
        this.dashboardDataService.getCalculateObservable(this.date5)
            .subscribe(function (response) {
            if (response.Error) {
                _this.updateStatus = "Error";
                _this.validationMessage = response.Error;
                _this.blnShowPopUp = true;
                console.log(response.Error);
                _this.initiateCalc = false;
                _this.disableLinks(false);
            }
            else {
                _this.load();
                _this.updateStatus = "Calculate PnL for next reporting day";
                _this.validationMessage = 'Calculation is completed successfully for business date ' + _this.date5.toString();
                _this.blnShowPopUp = true;
                _this.isCalculating = false;
                _this.initiateCalc = false;
                _this.disableLinks(false);
            }
        });
    };
    AppDashboard.prototype.resetCalcFlag = function () {
        var _this = this;
        var msg = "Disclaimer:\
             \n This reset should only be performed after consulting with TPR Support Team.\
              \n The calculation flag for the buisness date " + this.date4s + " will be reset.\
             \n Pressing 'OK' confirms TPR Support Teams have confirmed this action and the calculation flag will be reset.\
             \n Pressing 'Cancel' will close this request.";
        this.confirmationService.confirm({
            header: 'Reset Calculation Flag',
            message: msg,
            rejectVisible: true,
            acceptVisible: true,
            accept: function () {
                _this.dashboardDataService.getResetCalculationFlagObservable(_this.date4).subscribe(function (response) {
                    if (response.Error) {
                        _this.updateStatus = "Error";
                        _this.validationMessage = response.Error;
                        _this.blnShowPopUp = true;
                        console.log(response.Error);
                    }
                    else {
                        _this.setCalcFlag(response);
                        console.log(response);
                    }
                });
            }
        });
    };
    AppDashboard.prototype.doProcessing = function (event) {
        var _this = this;
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var selecteddate = this.date3.getDate() + m_names[this.date3.getMonth()] + this.date3.getFullYear();
        var selecteddate2 = selecteddate.toString();
        this.dashboardDataService.getDashboardDataObservable(selecteddate2).subscribe(function (response) {
            if (response.Error) {
                _this.updateStatus = "Error";
                _this.validationMessage = response.Error;
                _this.blnShowPopUp = true;
                console.log(response.Error);
            }
            else {
                _this.setDashboardData(response);
            }
        });
        // this.tPRcommonService.getSystemDateObservable().subscribe(data2 => this.setBusinessDate(data2));
        this.dashboardDataService.getLastCalculatedObservable().subscribe(function (files) { return _this.setLastCalculatedData(files); });
        this.dashboardDataService.getPublishStatusObservable().subscribe(function (data3) { return _this.setPublishStatus(data3); });
        this.dashboardDataService.getLockedStatusObservable().subscribe(function (data) { return _this.setLockedStatus(data); });
    };
    AppDashboard.prototype.setCalcFlag = function (data) {
        var reset = data.Result;
        console.log("Calc flag reset result = " + reset);
        if (reset == false) {
            this.updateStatus = "Info";
            this.validationMessage = 'No change to calculation flag';
            this.blnShowPopUp = true;
        }
        else if (reset == true) {
            this.updateStatus = "Info";
            this.validationMessage = 'Calculation flag is successfully reset';
            this.blnShowPopUp = true;
        }
    };
    AppDashboard.prototype.setLastCalcData = function () {
        var _this = this;
        this.dashboardDataService.getLastCalculatedObservable().subscribe(function (files) { return _this.setLastCalculatedData(files); });
    };
    ;
    AppDashboard.prototype.onErrorsClick = function (data) {
        this.arrErrorDetails = [];
        this.blnShowErrorModal = true;
        if (Array.isArray(data.Comments.Errors.string))
            this.arrErrorDetails = data.Comments.Errors.string;
        else
            this.arrErrorDetails[0] = data.Comments.Errors.string;
    };
    ;
    AppDashboard.prototype.onChangesClick = function (data) {
        this.arrChangesDetails = [];
        this.blnShowChangesModal = true;
        if (Array.isArray(data.Comments.ActivityLog))
            this.arrChangesDetails = data.Comments.ActivityLog;
        else
            this.arrChangesDetails[0] = data.Comments.ActivityLog;
    };
    ;
    AppDashboard.prototype.setDashboardData = function (data) {
        this.dashboardData = data.Result.DashboardData.$values;
        if (this.dashboardData.length != 0) {
            for (var i = 0; i < this.dashboardData.length; i++) {
                this.dashboardData[i].Updated = this.tPRcommonService.getFormattedSystemDate(new Date(this.dashboardData[i].Updated));
                var inst = new x2js();
                var result = inst.xml2js(this.dashboardData[i].Comments);
                this.dashboardData[i].ShowErrorsDiv = false;
                this.dashboardData[i].ShowDefaultDiv = false;
                this.dashboardData[i].ShowChangesDiv = false;
                if (this.dashboardData[i].Type == "Manual Entry" && this.dashboardData[i].Source != "OilMVarDb") {
                    this.dashboardData[i].ShowChangesDiv = true;
                    this.dashboardData[i].Comments = result.ArrayOfActivityLog;
                }
                else if (this.dashboardData[i].Source == "OilMVarDb") {
                    this.dashboardData[i].Comments = result.FeedLoadedLog;
                    if (result.FeedLoadedLog.Errors)
                        this.dashboardData[i].ShowErrorsDiv = true;
                }
                else {
                    this.dashboardData[i].ShowDefaultDiv = true;
                    this.dashboardData[i].Comments = result.FeedLoadedLog;
                    if (result.FeedLoadedLog.Errors)
                        this.dashboardData[i].ShowErrorsDiv = true;
                }
            }
        }
    };
    AppDashboard.prototype.setLastCalculatedData = function (data) {
        this.lastCalculated = this.tPRcommonService.getFormattedSystemDate(new Date(data.Result.DateTimeValue));
    };
    AppDashboard.prototype.disableLinks = function (bool) {
        console.log("Disable Links ->", bool);
        for (var i = 0; i <= this.dashboardItems1.length - 1; i++) {
            if (bool || this.isCalculating) {
                this.dashboardItems1[i].disabled = true;
                if (this.isCalculating && this.dashboardItems1[i].label == "Reset Calculation Flag") {
                    console.log("Enable Reset Calculation Flag");
                    this.dashboardItems1[i].disabled = !this.isUserAuthorised("resetCalculationFlag");
                }
            }
            else {
                switch (this.dashboardItems1[i].label) {
                    case "Calculate PnL":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("calculate");
                        break;
                    case "Calculate PnL for next reporting day":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("calculate");
                        break;
                    case "Publish":
                    case "UnPublish":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("publish");
                        break;
                    case "Roll Business Date":
                        var utcDate = new Date(this.tPRcommonService.getFormattedSystemDate_Date(new Date()));
                        var busDate = new Date(this.date4s);
                        console.log("Bus Date ->", busDate);
                        console.log("Utc Date ->", utcDate);
                        console.log("result ->", busDate < utcDate);
                        this.dashboardItems1[i].disabled = !(this.isUserAuthorised("rollBusinessDate") && this.isPublished && busDate < utcDate);
                        break;
                    case "Unlock Business Date":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("lockBusinessDate");
                        this.dashboardItems1[i].icon = "fa-unlock";
                        break;
                    case "Lock Business Date":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("lockBusinessDate");
                        this.dashboardItems1[i].icon = "fa-lock";
                        break;
                    case "Reset Calculation Flag":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("lockBusinessDate");
                        break;
                }
            }
        }
    };
    AppDashboard = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/dashboard/app.dashboard.component.html'
        }), 
        __metadata('design:paramtypes', [app_dashboardData_service_1.DashboardDataService, app_TPRCommonService_1.TPRCommonService, primeng_1.ConfirmationService, app_serviceHelper_1.ServiceHelper, router_1.Router, app_component_1.AppComponent])
    ], AppDashboard);
    return AppDashboard;
}());
exports.AppDashboard = AppDashboard;
var SystemDateValue = (function () {
    function SystemDateValue(Name, DateValue, StringValue, numericValue, BoolValue, DateTimeValue, Created, CreatedBy, Updated, UpdatedBy, Id, $type) {
        if (Name === void 0) { Name = null; }
        if (DateValue === void 0) { DateValue = null; }
        if (StringValue === void 0) { StringValue = null; }
        if (numericValue === void 0) { numericValue = null; }
        if (BoolValue === void 0) { BoolValue = null; }
        if (DateTimeValue === void 0) { DateTimeValue = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        if ($type === void 0) { $type = null; }
        this.Name = Name;
        this.DateValue = DateValue;
        this.StringValue = StringValue;
        this.numericValue = numericValue;
        this.BoolValue = BoolValue;
        this.DateTimeValue = DateTimeValue;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
        this.$type = $type;
    }
    return SystemDateValue;
}());
//# sourceMappingURL=app.dashboard.component.js.map