﻿import { Component, OnInit, Input, Output, forwardRef, Injectable, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { Router, ActivatedRoute, Params, RouterModule, NavigationEnd } from '@angular/router';
import { DashboardDataService } from '../../service/app.dashboardData.service';
import { MenuItem } from 'primeng/primeng';
import { Message } from 'primeng/primeng';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';
import ISystemDateValue = CommonNameSpace.ISystemDateValue;
import { AppComponent } from '../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import IDashboardDataValues = DashboardNamespace.IDashboardDataValue;
import CalcResult = Calcnamespace.ICalcResult;
import CalcErrors = Calcnamespace.ICalcErrors;
import IErrorDetails = FileUploadNameSpace.IErrorDetails;

var x2js = require('x2js');

@Component({
    selector: 'my-app',
    templateUrl: 'app/components/dashboard/app.dashboard.component.html'
})
export class AppDashboard {
    date3: Date;
    public date4: any;
    dashboardItems1: MenuItem[];
    dashboardItems2: MenuItem[];
    dashboardData: IDashboardDataValues[];
    cols: any[];
    msgs: Message[] = [];
    lastCalculated: string;
    message: string;
    Businessdate: string;
    publishstatus: string;
    isPublished: boolean;
    status: any;
    date: Date;
    DATE: string;
    dateFromCalendar: Date;
    data: ISystemDateValue[];
    dtMinBusinessDate: Date;
    publishText: boolean;
    publishButtonText: string;
    displayMessage: boolean = false;
    nextReportingDate: Date;
    date5: string;
    date4s: string;
    calcerrors: CalcErrors;
    blnShowPopUp: boolean = false;
    updateStatus: string;
    validationMessage: string;
    disabled: boolean = false;
    reportingdatestatus: string = "";
    lockstatus: number;
    isLocked: boolean = false;
    comments: string[] = [];
    commentsjson: string[] = [];
    blnShowErrorModal: boolean = false;
    arrErrorDetails: IErrorDetails[] = [];
    blnShowChangesModal: boolean = false;
    arrChangesDetails: any[] = [];
    isCalculating: boolean = false;
    isPublishDisabled: boolean = false;
    isRollBusinessDateDisabled: boolean = false;
    isLockBusinessDateDisabled: boolean = false;
    userRoles: string[] = [];
    constants: any;
    isRequesting: boolean = false;
    workingDates: Date[];
    loadLinks: boolean = false;
    isPublishing: boolean = false;
    initiateCalc: boolean = false;

    constructor(private dashboardDataService: DashboardDataService,
        private tPRcommonService: TPRCommonService,
        private confirmationService: ConfirmationService,
        private serviceHelper: ServiceHelper,
        private router: Router,
        private appComponent: AppComponent) {
    }

    ngOnInit() {
        this.dashboardItems1 = [
            { label: 'Calculate PnL', icon: 'fa-calculator', command: (event) => this.processCalculation(), disabled: false },
            { label: 'Publish', icon: 'fa-sign-out', command: null, disabled: false },
            { label: 'Roll Business Date', icon: 'fa-calendar-plus-o', disabled: false, command: (event) => this.process("roll") },
            { label: 'Lock Business Date', icon: 'fa-lock', disabled: false },
            { label: 'Reset Calculation Flag', icon: 'fa-flag', command: (event) => this.resetCalcFlag(), disabled: false }
        ];
        this.cols = [
            { field: 'Source', header: 'Source' },
            { field: 'FileType', header: 'File Type' },
            { field: 'State', header: 'Status' },
            { field: 'Name', header: 'Activity log' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];

        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }

        this.serviceHelper.importSettings()
            .subscribe(data => this.getConstants(data));

        this.load();
    }

    private stopRefreshing() {
        this.isRequesting = false;
    }

    public resetItems() {
        this.dashboardItems1 = [
            { label: 'Calculate PnL', icon: 'fa-calculator', command: (event) => this.processCalculation(), disabled: false },
            { label: 'Publish', icon: 'fa-sign-out', command: null, disabled: false },
            { label: 'Roll Business Date', icon: 'fa-calendar-plus-o', disabled: false, command: (event) => this.process("roll") },
            { label: 'Lock Business Date', icon: 'fa-lock', disabled: false },
            { label: 'Reset Calculation Flag', icon: 'fa-flag', command: (event) => this.resetCalcFlag(), disabled: false }
        ];
    }

    public getConstants(data: any): void {
        this.constants = data;
    }

    private authorizeUser() {
        this.disableLinks(false);
    }

    public isUserAuthorised(action: string): boolean {
        switch (action) {
            case "calculate":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        (this.userRoles.some(x => x == this.constants.TPRMarginManagement) && this.isPublished));
                    // ((this.userRoles.some(x => x == this.constants.TPRSuperUser) && !this.isPublished) ||
                    //     ((this.userRoles.some(x => x == this.constants.TPRMarginManagement) ||
                    //         this.userRoles.some(x => x == this.constants.RoleSystemAdmin)) && this.isPublished))
            case "publish":
            case "lockBusinessDate":
            case "rollBusinessDate":
            case "resetCalculationFlag":
                return this.userRoles != undefined && this.constants != undefined &&
                    this.userRoles.some(x => x == this.constants.TPRSuperUser);
        }
        return false;
    }

    public load() {
        this.isRequesting = true;
        this.loadLinks = true;
        this.resetItems();
        this.tPRcommonService.getSystemDateObservable().subscribe(data2 => this.setBusinessDate(data2));
        this.dashboardDataService.getLastCalculatedObservable().subscribe(files => this.setLastCalculatedData(files));
        this.dashboardDataService.getPublishStatusObservable().subscribe(data3 => this.setPublishStatus(data3));
        this.dashboardDataService.getLockedStatusObservable().subscribe(data => this.setLockedStatus(data));
    }

    ///Refresh button
    public refresh() {
        localStorage.setItem("CalcFlag", this.isCalculating.toString());
        if (!this.isPublished) {
            this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(data => {
                this.checkIfCalculating(data);
                if (localStorage.getItem("CalcFlag") && localStorage.getItem("CalcFlag") == "true" && !this.isCalculating) {
                    this.updateStatus = "Calculate PnL";
                    this.validationMessage = 'Calculation is completed successfully for business date ' + this.date4s;
                    this.blnShowPopUp = true;;
                }
            });
        }
        else {
            this.dashboardDataService.getIsCalculatingObservable(this.date5).subscribe(data => {
                this.checkIfCalculating(data);
                if (localStorage.getItem("CalcFlag") && localStorage.getItem("CalcFlag") == "true" && !this.isCalculating.toString()) {
                    this.updateStatus = "Calculate PnL for next reporting day";
                    this.validationMessage = 'Calculation is completed successfully for business date ' + this.date5.toString();
                    this.blnShowPopUp = true;
                }
            });
        }
    }

    public checkIfCalculating(data: any): void {
        this.isCalculating = data.Result;
        console.log("checkIfCalculating ->", this.isCalculating);
        this.disableLinks(this.isCalculating);
    }

    // public checkForNextDayIfCalculating(data: any): void {
    //     this.isCalculating = data.Result;
    //     console.log("checkForNextDayIfCalculating ->", this.isCalculating);
    //     this.disableLinks(this.isCalculating);
    // }

    public setLockedStatus(data: any): void {
        this.lockstatus = data.Result.NumericValue;
        console.log("set locked status", this.lockstatus);
        if (this.lockstatus == 1) {
            this.reportingdatestatus = "Locked";
            this.isLocked = true;
            this.dashboardItems1[3].label = "Unlock Business Date";
            this.dashboardItems1[3].command = (event) => this.lockOrUnlock();
        }
        else if (this.lockstatus == 0) {
            this.reportingdatestatus = "Unlocked";
            this.isLocked = false;
            this.dashboardItems1[3].label = "Lock Business Date";
            this.dashboardItems1[3].command = (event) => this.lockOrUnlock();
        }

        this.authorizeUser();
        this.loadLinks = false;
        this.stopRefreshing();
    }

    public setBusinessDate(data: any): void {
        console.log("System Date ->", data.Result.DateValue);
        let myDate = new Date(data.Result.DateValue);

        var m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        var businessDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        var output = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        this.date4 = output.toString();
        var outputs = myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        this.date4s = outputs.toString();
        console.log("Business date as being passed to service from inside method is " + this.date4);
        this.dashboardDataService.getDashboardDataObservable(this.date4).subscribe(
            (response: any) => {
                if (response.Error) {
                    this.updateStatus = "Error";
                    this.validationMessage = response.Error;
                    this.blnShowPopUp = true;
                    console.log(response.Error);
                }
                else {
                    this.setDashboardData(response);
                }
            },
        );
        this.date3 = myDate;
        // this.nextReportingDate = new Date();
        // this.nextReportingDate.setDate(this.date3.getDate() + 1);
        this.nextReportingDate = this.appComponent.getPreviousorNextWorkingDay(this.date3, false);
        var output2 = this.nextReportingDate.getDate() + ' ' + m_names[this.nextReportingDate.getMonth()] + ' ' + this.nextReportingDate.getFullYear();
        this.date5 = output2.toString();

        //Check if any calc is in progress
        this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(data => this.checkIfCalculating(data));
        //check for next day calc
        // if (!this.date5) {
        if (this.date5) {
            this.dashboardDataService.getIsCalculatingObservable(this.date5).subscribe(data => this.checkIfCalculating(data));
        }
    }

    public setPublishStatus(data: any): void {
        console.log("publish status", data.Result.NumericValue);
        this.status = data.Result.NumericValue;
        if (this.status == 0) {
            this.isPublished = false;
            this.publishstatus = "Unpublished";
            this.publishButtonText = "Publish";
            this.dashboardItems1[0].label = "Calculate PnL";
            this.dashboardItems1[0].command = (event) => this.processCalculation();
        } else {
            this.isPublished = true;
            this.publishstatus = "Published";
            this.publishButtonText = "UnPublish";
            this.dashboardItems1[0].label = "Calculate PnL for next reporting day";
            this.dashboardItems1[0].command = (event) => this.processCalculation();
        }
        localStorage.setItem("PublishStatus", this.publishstatus);

        this.dashboardItems1[1].label = this.publishButtonText;
        this.dashboardItems1[1].command = (event) => this.process("pub");
        this.dashboardItems1[1].icon = 'fa-sign-out';

        this.authorizeUser();
    }

    private setPublishData(): void {
        this.dashboardDataService.getPublishStatusObservable().subscribe(data3 => this.setPublishStatus(data3));
    }

    private setLockedData(): void {
        this.dashboardDataService.getLockedStatusObservable().subscribe(data3 => this.setLockedStatus(data3));
    }

    private process(action: string) {
        console.log("processCalculation")
        // this.isRequesting = true;
        this.loadLinks = true;
        this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(data => {
            this.checkIfCalculating(data);
            // this.stopRefreshing();
            this.loadLinks = false;
            if (!this.isCalculating) {
                switch (action) {
                    case "pub":
                        this.publishOrUnpublishData();
                        break;
                    case "roll":
                        this.rollBusinessDate();
                        break;
                }
            }
            else {
                if (!this.isPublished) {
                    this.updateStatus = "Calculation Alert";
                    this.validationMessage = 'Calculation has been initiated by another user for business date ' + this.date4s + '. Please wait till the calculation is completed.';
                }
                else {
                    this.updateStatus = "Calculation Alert";
                    this.validationMessage = 'Calculation has been initiated by another user for business date ' + this.date5.toString() + '. Please wait till the calculation is completed.';
                }
                this.blnShowPopUp = true;
            }
        });
    }

    private lockOrUnlock() {
        this.displayMessage = true;
        this.disableLinks(true);
        console.log("lock status", this.lockstatus);
        if (this.lockstatus == 1) {
            this.confirmationService.confirm({
                header: 'Unlock Reporting Date',
                message: 'The system reporting date - ' + this.date4s + ' - will be unlocked. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: () => {
                    this.dashboardDataService.getUnLockedObservable().subscribe(
                        (response: any) => {
                            if (response.Error) {
                                this.updateStatus = "Error";
                                this.validationMessage = response.Error;
                                this.blnShowPopUp = true;
                                console.log("error", response.Error);
                                this.disableLinks(false);
                            }
                            else {
                                this.updateStatus = "Unlocked";
                                this.validationMessage = 'The reporting date ' + this.date4s + ' has been unlocked.';
                                this.blnShowPopUp = true;
                                console.log("error", response.Error);
                                this.setLockedData();
                                this.disableLinks(false);
                            }
                        })
                },
                reject: () => { this.disableLinks(false); }
            });
        }
        else if (this.lockstatus == 0) {
            this.confirmationService.confirm({
                header: 'Lock Reporting Date',
                message: 'The system reporting date - ' + this.date4s + ' - will be locked. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: () => {
                    this.dashboardDataService.getLockedObservable().subscribe(
                        (response: any) => {
                            if (response.Error) {
                                this.updateStatus = "Error";
                                this.validationMessage = response.Error;
                                this.blnShowPopUp = true;
                                console.log("error", response.Error);
                                this.disableLinks(false);
                            }
                            else {
                                this.updateStatus = "Locked";
                                this.validationMessage = 'The reporting date ' + this.date4s + ' has been successfully locked.';
                                this.blnShowPopUp = true;
                                console.log("error", response.Error);
                                this.setLockedData();
                                this.disableLinks(false);
                            }
                        })
                },
                reject: () => { this.disableLinks(false); }
            });

        }
    }

    private publishOrUnpublishData() {
        this.disableLinks(true);
        this.displayMessage = true;
        if (this.status == 0) {
            this.confirmationService.confirm({
                header: 'Publishing data',
                message: 'The PNL data for reporting date ' + this.date4s + ' will be published. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: () => {
                    this.isPublishing = true;
                    this.dashboardDataService.getPublishObservable(this.date4).subscribe(
                        (response: any) => {
                            if (response.Error) {
                                this.updateStatus = "Error";
                                this.validationMessage = response.Error;
                                this.blnShowPopUp = true;
                                console.log("error", response.Error);
                                this.disableLinks(false);
                                this.isPublishing = false;
                            }
                            else {
                                this.load();
                                this.updateStatus = "Data Published";
                                this.validationMessage = 'The PNL data for reporting date ' + this.date4s + ' has been successfully published.';
                                this.blnShowPopUp = true;
                                console.log("error", response.Error);
                                this.setPublishData();
                                this.disableLinks(false);
                                this.isPublishing = false;
                            }
                        })
                },
                reject: () => { this.disableLinks(false); }
            });
        }
        else {
            this.confirmationService.confirm({
                header: 'Unpublishing data',
                message: 'The PNL data for reporting date ' + this.date4s + ' will be unpublished. Would you like to proceed?',
                rejectVisible: true,
                acceptVisible: true,
                accept: () => {
                    this.isPublishing = true;
                    this.dashboardDataService.getUnPublishObservable(this.date4).subscribe(
                        (response: any) => {
                            if (response.Error) {
                                this.updateStatus = "Error";
                                this.validationMessage = response.Error;
                                this.blnShowPopUp = true;
                                console.log("error", response.Error);
                                this.disableLinks(false);
                                this.isPublishing = false;
                            }
                            else {
                                this.load();
                                this.updateStatus = "Data unpublished";
                                this.validationMessage = 'The PNL data for reporting date ' + this.date4s + ' has been successfully unpublished.';
                                this.blnShowPopUp = true;
                                this.setPublishData();
                                this.disableLinks(false);
                                this.isPublishing = false;
                            }
                        })
                },
                reject: () => { this.disableLinks(false); }
            });
        }

    }

    private rollBusinessDate() {
        this.confirmationService.confirm({
            header: 'Roll Business Date',
            message: 'The system reporting date - ' + this.date4s + '- will be rolled to the next working date. Would you like to proceed?',
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                this.disableLinks(true);
                this.dashboardDataService.rollBusinessDateObservable().subscribe(
                    (response: any) => {
                        if (response.Error) {
                            this.updateStatus = "Error";
                            this.validationMessage = response.Error;
                            this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            this.disableLinks(false);
                        }
                        else {
                            this.tPRcommonService.getSystemDateObservable().subscribe(data2 => this.setBusinessDate(data2));
                            this.appComponent.RefreshEnvironmentData();
                            this.load();
                            this.updateStatus = 'Roll Business Date';
                            this.validationMessage = 'The system has been rolled to the next business date';
                            this.blnShowPopUp = true;
                            console.log("error", response.Error);
                            this.disableLinks(false);
                        }
                    })
            },
            reject: () => { this.disableLinks(false); }
        });
    }

    private processCalculation() {
        // this.isRequesting = true;
        this.loadLinks = true;
        if (!this.isPublished) {
            this.dashboardDataService.getIsCalculatingObservable(this.date4).subscribe(data => {
                this.checkIfCalculating(data);
                // this.stopRefreshing();
                this.loadLinks = false;
                if (!this.isCalculating) {
                    this.calculatePnL();
                }
                else {
                    this.updateStatus = "Calculate PnL";
                    this.validationMessage = 'Calculation has already been initiated by another user for business date ' + this.date4s;
                    this.blnShowPopUp = true;
                }
            });
        }
        else {
            this.dashboardDataService.getIsCalculatingObservable(this.date5).subscribe(data => {
                this.checkIfCalculating(data);
                // this.stopRefreshing();
                this.loadLinks = false;
                if (!this.isCalculating) {
                    this.calculateNextDayPnL();
                }
                else {
                    this.updateStatus = "Calculate PnL for next reporting day";
                    this.validationMessage = 'Calculation has already been initiated by another user for business date ' + this.date5.toString();
                    this.blnShowPopUp = true;
                }
            });
        }
    }

    private calculatePnL() {
        console.log("Start Calculating...");
        this.initiateCalc = true;
        this.isCalculating = true;
        this.disableLinks(true);
        this.dashboardDataService.getCalculateObservable(this.date4)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.updateStatus = "Error";
                    this.validationMessage = response.Error;
                    this.blnShowPopUp = true;
                    this.disableLinks(false);
                    this.initiateCalc = false;
                    console.log(response.Error);
                }
                else {
                    this.load();
                    this.updateStatus = "Calculate PnL";
                    this.validationMessage = 'Calculation is completed successfully for business date ' + this.date4.toString();
                    this.blnShowPopUp = true;
                    this.initiateCalc = false;
                    console.log(response.Error);
                    this.isCalculating = false;
                    // this.setLastCalcData();
                    this.disableLinks(false);
                }
            });
    }

    private calculateNextDayPnL() {
        this.initiateCalc = true;
        this.isCalculating = true;
        this.disableLinks(true);
        this.dashboardDataService.getCalculateObservable(this.date5)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.updateStatus = "Error";
                    this.validationMessage = response.Error;
                    this.blnShowPopUp = true;
                    console.log(response.Error);
                    this.initiateCalc = false;
                    this.disableLinks(false); 
                }
                else {
                    this.load();
                    this.updateStatus = "Calculate PnL for next reporting day";
                    this.validationMessage = 'Calculation is completed successfully for business date ' + this.date5.toString();
                    this.blnShowPopUp = true;
                    this.isCalculating = false;
                    this.initiateCalc = false;
                    this.disableLinks(false);
                }
            });
    }

    private resetCalcFlag() {
        let msg = "Disclaimer:\
             \n This reset should only be performed after consulting with TPR Support Team.\
              \n The calculation flag for the buisness date "  + this.date4s + " will be reset.\
             \n Pressing 'OK' confirms TPR Support Teams have confirmed this action and the calculation flag will be reset.\
             \n Pressing 'Cancel' will close this request."
        this.confirmationService.confirm({
            header: 'Reset Calculation Flag',
            message: msg,
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                this.dashboardDataService.getResetCalculationFlagObservable(this.date4).subscribe(
                    (response: any) => {
                        if (response.Error) {
                            this.updateStatus = "Error";
                            this.validationMessage = response.Error;
                            this.blnShowPopUp = true;
                            console.log(response.Error);
                        }
                        else {
                            this.setCalcFlag(response);
                            console.log(response);
                        }
                    }
                );
            }
        });

    }

    private doProcessing(event: any) {
        var m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");
        var selecteddate = this.date3.getDate() + m_names[this.date3.getMonth()] + this.date3.getFullYear();
        let selecteddate2 = selecteddate.toString();
        this.dashboardDataService.getDashboardDataObservable(selecteddate2).subscribe(
            (response: any) => {
                if (response.Error) {
                    this.updateStatus = "Error";
                    this.validationMessage = response.Error;
                    this.blnShowPopUp = true;
                    console.log(response.Error);
                }
                else {
                    this.setDashboardData(response);
                }
            },

        );
        // this.tPRcommonService.getSystemDateObservable().subscribe(data2 => this.setBusinessDate(data2));
        this.dashboardDataService.getLastCalculatedObservable().subscribe(files => this.setLastCalculatedData(files));
        this.dashboardDataService.getPublishStatusObservable().subscribe(data3 => this.setPublishStatus(data3));
        this.dashboardDataService.getLockedStatusObservable().subscribe(data => this.setLockedStatus(data));
    }

    private setCalcFlag(data: any): void {
        let reset = data.Result;
        console.log("Calc flag reset result = " + reset);
        if (reset == false) {
            this.updateStatus = "Info";
            this.validationMessage = 'No change to calculation flag';
            this.blnShowPopUp = true;
        }
        else if (reset == true) {
            this.updateStatus = "Info";
            this.validationMessage = 'Calculation flag is successfully reset';
            this.blnShowPopUp = true;
        }
    }

    private setLastCalcData(): void {
        this.dashboardDataService.getLastCalculatedObservable().subscribe(files => this.setLastCalculatedData(files));
    };

    private onErrorsClick(data: any) {
        this.arrErrorDetails = [];

        this.blnShowErrorModal = true;

        if (Array.isArray(data.Comments.Errors.string))
            this.arrErrorDetails = data.Comments.Errors.string;
        else
            this.arrErrorDetails[0] = data.Comments.Errors.string;
    };

    private onChangesClick(data: any) {
        this.arrChangesDetails = [];
        this.blnShowChangesModal = true;

        if (Array.isArray(data.Comments.ActivityLog))
            this.arrChangesDetails = data.Comments.ActivityLog;
        else
            this.arrChangesDetails[0] = data.Comments.ActivityLog;
    };

    private setDashboardData(data: any): void {
        this.dashboardData = data.Result.DashboardData.$values;
        if (this.dashboardData.length != 0) {
            for (var i = 0; i < this.dashboardData.length; i++) {
                this.dashboardData[i].Updated = this.tPRcommonService.getFormattedSystemDate(new Date(this.dashboardData[i].Updated));

                var inst = new x2js();
                var result = inst.xml2js(this.dashboardData[i].Comments);

                this.dashboardData[i].ShowErrorsDiv = false;
                this.dashboardData[i].ShowDefaultDiv = false;
                this.dashboardData[i].ShowChangesDiv = false;

                if (this.dashboardData[i].Type == "Manual Entry" && this.dashboardData[i].Source != "OilMVarDb") {
                    this.dashboardData[i].ShowChangesDiv = true;
                    this.dashboardData[i].Comments = result.ArrayOfActivityLog;
                }
                else if (this.dashboardData[i].Source == "OilMVarDb") {
                    this.dashboardData[i].Comments = result.FeedLoadedLog;

                    if (result.FeedLoadedLog.Errors)
                        this.dashboardData[i].ShowErrorsDiv = true;
                }
                else {
                    this.dashboardData[i].ShowDefaultDiv = true;
                    this.dashboardData[i].Comments = result.FeedLoadedLog;

                    if (result.FeedLoadedLog.Errors)
                        this.dashboardData[i].ShowErrorsDiv = true;
                }
            }
        }
    }

    private setLastCalculatedData(data: any): void {
        this.lastCalculated = this.tPRcommonService.getFormattedSystemDate(new Date(data.Result.DateTimeValue));
    }

    private disableLinks(bool: boolean) {
        console.log("Disable Links ->", bool);
        for (var i = 0; i <= this.dashboardItems1.length - 1; i++) {
            if (bool || this.isCalculating) {
                this.dashboardItems1[i].disabled = true;
                if (this.isCalculating && this.dashboardItems1[i].label == "Reset Calculation Flag") {
                    console.log("Enable Reset Calculation Flag");
                    this.dashboardItems1[i].disabled = !this.isUserAuthorised("resetCalculationFlag");
                }
            } else {
                switch (this.dashboardItems1[i].label) {
                    case "Calculate PnL":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("calculate");
                        break;
                    case "Calculate PnL for next reporting day":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("calculate");
                        break;
                    case "Publish":
                    case "UnPublish":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("publish");
                        break;
                    case "Roll Business Date":
                        var utcDate = new Date(this.tPRcommonService.getFormattedSystemDate_Date(new Date()));
                        var busDate = new Date(this.date4s);
                        console.log("Bus Date ->", busDate);
                        console.log("Utc Date ->", utcDate);
                        console.log("result ->", busDate < utcDate);
                        this.dashboardItems1[i].disabled = !(this.isUserAuthorised("rollBusinessDate") && this.isPublished && busDate < utcDate);
                        break;
                    case "Unlock Business Date":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("lockBusinessDate");
                        this.dashboardItems1[i].icon = "fa-unlock";
                        break;
                    case "Lock Business Date":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("lockBusinessDate");
                        this.dashboardItems1[i].icon = "fa-lock";
                        break;
                    case "Reset Calculation Flag":
                        this.dashboardItems1[i].disabled = !this.isUserAuthorised("lockBusinessDate");
                        break;
                }
            }
        }
    }
}

class SystemDateValue implements ISystemDateValue {
    constructor(
        public Name: string = null,
        public DateValue: string = null,
        public StringValue: string = null,
        public numericValue: string = null,
        public BoolValue: string = null,
        public DateTimeValue: string = null,
        public Created: Date = null,
        public CreatedBy: string = null,
        public Updated: Date = null,
        public UpdatedBy: string = null,
        public Id: number = 0,
        public $type: string = null) { }
}

