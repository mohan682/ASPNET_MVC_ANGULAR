﻿import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';



//import { INodeTypes } from '../../domain/NodeTypeNamespace.INodeTypesValue';

@
Component({
    selector: 'my-app',
    templateUrl: 'app/components/datagrid/app.TPR.Hierarchy.html'
})
export class AppTprAccordianModule {
    date3: Date;

}