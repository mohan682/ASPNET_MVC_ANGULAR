﻿import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppTagsTypeComponent } from './app.tags.component';
import { TPRTagsService } from '../../service/app.TPRTagsService';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { addMatchers, click } from '../../../testing';

import ITagsValue = TagsNameSpace.ITagsValue;

describe('AppTagsTypeComponent test cases', () => {
    let de: DebugElement;
    let comp: AppTagsTypeComponent;
    let fixture: ComponentFixture<AppTagsTypeComponent>;
    let tagsService: TPRTagsService;
    let spy: jasmine.Spy;

    //async before each
    beforeEach(async(() => {
        // Create Tags service stub which needs to be injected

        //let TPRTagsServiceStub = {
        //    getTagsObservable(): Observable<any>,
        //    updateTagsObservable(tagsArray:ITagsValue[]):Observable<any>
        //};
        let tprTagsServiceStub = {
            getTagsObservable: true,
            updateTagsObservable: true
        };

        TestBed.configureTestingModule({
            declarations: [AppTagsTypeComponent],
            imports: [],
            providers: [TPRTagsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));


    beforeEach(() => {
        fixture = TestBed.createComponent(AppTagsTypeComponent); // creates the fixture of the testing component

        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });

    // test whether the component got successfully initialised
    it('should create component', () => expect(comp).toBeDefined());

    // test for service mockup
    // Tag service actually injected to the component.
    tagsService = fixture.debugElement.injector.get(TPRTagsService);

    // Create test mockup class
    let tagsMockUp: TagsValueTestMockup = new TagsValueTestMockup();
    let tagTypes: ITagsValue[] = [];

    it('should not call the getTagsObservable method before OnInit', () => {
        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(tagsService, 'getTagsObservable')
            .and.returnValue(Promise.resolve(tagsMockUp));

        expect(spy.calls.any()).toBe(false, 'getTagsObservable not yet called');
    });

    it('should call the getTagsObservable method after component initialized', () => {
        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(tagsService, 'getTagsObservable')
            .and.returnValue(Promise.resolve(tagsMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getTagsObservable called');
    });

    it('should raise Add button click event', () => {
        let displayDialog: boolean = true;
        let newTagType: boolean = true;
        let blnValidationResult: boolean = true;

        de = fixture.debugElement.query(By.css('#btnAdd'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newTagType).toBe(newTagType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });

    it('should raise Save button click event', () => {
        let tagType: ITagsValue = new TagsValueTestMockup('', 'Test', false, false, '', '', '', '', 0); // Creating testmockup object
        comp.tagType = tagType; // initializing the tagType object with the test mockup object

        de = fixture.debugElement.query(By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.tagTypes.indexOf(tagType)).toBeGreaterThan(-1);
    });

    it('should raise SavetoDatabase button click event', () => {
        let blnPushDataToDatabase: boolean = true;
        let blnSavedOrDeleted: boolean = true;
        let strSavedMessage: string = "Data saved successfully";

        de = fixture.debugElement.query(By.css('#btnSaveDataToServer'));

        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(tagsService, 'updateTagsObservable')
            .and.returnValue(Promise.resolve(tagsMockUp));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        fixture.detectChanges();

        expect(spy.calls.any()).toBe(true, 'updateTagsObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});

class TagsValueTestMockup implements ITagsValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}