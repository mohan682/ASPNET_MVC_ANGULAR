"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var primeng_1 = require('primeng/primeng');
var primeng_2 = require('primeng/primeng');
var app_TPRTagsService_1 = require('../../service/app.TPRTagsService');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var AppTagsTypeComponent = (function () {
    function AppTagsTypeComponent(tPRTagsService, confirmationService, router, tprCommonService) {
        this.tPRTagsService = tPRTagsService;
        this.confirmationService = confirmationService;
        this.router = router;
        this.tprCommonService = tprCommonService;
        this.tagType = new TagsValue();
        this.msgs = [];
        this.blnSavedOrDeleted = false;
        this.successMessage = false;
        this.failureMessage = false;
        this.Message = "";
        this.clsMessage = {};
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.blnPushDataToDatabase = false;
        this.strMessage = "";
        this.blnShowPopUp = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.disableSave = false;
    }
    AppTagsTypeComponent.prototype.ngOnInit = function () {
        this.isRequesting = true;
        this.loadData();
        this.cols = [
            { field: 'Name', header: 'Tag Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
    };
    AppTagsTypeComponent.prototype.loadData = function () {
        var _this = this;
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.tPRTagsService.getTagsObservable()
            .subscribe(function (data) { return _this.setTagTypeData(data); });
    };
    AppTagsTypeComponent.prototype.setTagTypeData = function (data) {
        var _this = this;
        this.tagTypes = [];
        this.tagTypes = data.Result.Tags.$values;
        this.tagTypes.forEach(function (tagType) {
            tagType.Updated != null ? tagType.Updated = _this.tprCommonService.getFormattedSystemDate(new Date(tagType.Updated)) : null;
        });
        this.stopRefreshing();
    };
    AppTagsTypeComponent.prototype.showDialogToAdd = function () {
        this.newTagType = true;
        this.tagType = new TagsValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppTagsTypeComponent.prototype.save = function () {
        var _this = this;
        //console.log(this.tagType);
        if (this.tagType.Name == null || this.tagType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.strMessage = "Please provide valid data.";
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            this.tagType.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;
            if (this.newTagType) {
                //debugger;
                var index = this.tagTypes.indexOf(this.tagTypes.find(function (tag) { return tag.Name.toLowerCase().trim() == _this.tagType.Name.toLowerCase().trim(); }));
                if (index == -1) {
                    this.tagTypes.push(this.tagType);
                }
                else {
                    this.strMessage = "Tag Name should be unique.";
                    this.clsHighlightInvalidData = {};
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };
                    //this.tagType.Name = "";
                    return false;
                }
            }
            else
                this.tagTypes[this.findSelectedTagIndex()] = this.tagType;
        }
        this.tagType = null;
        this.displayDialog = false;
    };
    AppTagsTypeComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = true;
        this.SaveDataToDataBase(action);
    };
    AppTagsTypeComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentTagType = event;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Tag?',
            accept: function () {
                _this.tagTypes.splice(_this.findTagIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });
        this.tagType = null;
    };
    AppTagsTypeComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.isRequesting = true;
        this.tPRTagsService.updateTagsObservable(this.tagTypes)
            .subscribe(function (response) {
            if (response.Error) {
                _this.stopRefreshing();
                _this.Status = "Error";
                _this.ValidationMessage = response.Error;
                _this.blnShowPopUp = true;
            }
            else {
                _this.blnShowPopUp = true;
                _this.Status = "Success";
                console.log("Action ->", action);
                if (action == "save") {
                    _this.ValidationMessage = "Tags Data is saved successfully";
                }
                else if (action == "delete") {
                    _this.ValidationMessage = "The Selected Tag is deleted successfully";
                }
                _this.loadData();
                _this.blnSavedOrDeleted = true;
            }
        }, function (error) {
            _this.stopRefreshing();
            _this.Status = "Error";
            _this.ValidationMessage = error;
            _this.blnShowPopUp = true;
        });
    };
    AppTagsTypeComponent.prototype.onRowSelect = function (event) {
        this.newTagType = false;
        this.tagType = this.cloneTagType(event.data);
    };
    AppTagsTypeComponent.prototype.cloneTagType = function (c) {
        var tagType = new TagsValue();
        for (var prop in c) {
            tagType[prop] = c[prop];
        }
        return tagType;
    };
    AppTagsTypeComponent.prototype.findSelectedTagIndex = function () {
        return this.tagTypes.indexOf(this.selectedTagType);
    };
    AppTagsTypeComponent.prototype.findTagIndexForDelete = function () {
        return this.tagTypes.indexOf(this.currentTagType);
    };
    AppTagsTypeComponent.prototype.refreshData = function (tagTypeDataTable) {
        this.isRequesting = true;
        this.tagTypeDataTable.reset();
        this.loadData();
    };
    AppTagsTypeComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    __decorate([
        core_1.ViewChild('tagTypeDataTable'), 
        __metadata('design:type', primeng_1.DataTable)
    ], AppTagsTypeComponent.prototype, "tagTypeDataTable", void 0);
    AppTagsTypeComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/Tags/app.tags.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRTagsService_1.TPRTagsService, primeng_2.ConfirmationService, router_1.Router, app_TPRCommonService_1.TPRCommonService])
    ], AppTagsTypeComponent);
    return AppTagsTypeComponent;
}());
exports.AppTagsTypeComponent = AppTagsTypeComponent;
var TagsValue = (function () {
    function TagsValue($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return TagsValue;
}());
//# sourceMappingURL=app.tags.component.js.map