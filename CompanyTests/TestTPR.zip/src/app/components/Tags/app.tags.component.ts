﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { DataTable } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { TPRTagsService } from '../../service/app.TPRTagsService';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { TPRCommonService } from '../../service/app.TPRCommonService';

import ITagsValue = TagsNameSpace.ITagsValue;

@Component({
    selector: 'my-app',
    templateUrl: 'app/components/Tags/app.tags.component.html'
})
export class AppTagsTypeComponent implements OnInit {

    tagTypes: ITagsValue[];
    newTagType: boolean;
    displayDialog: boolean;
    tagType: ITagsValue = new TagsValue();
    cols: any[];
    selectedTagType: ITagsValue;
    currentTagType: ITagsValue;
    msgs: Message[] = [];
    blnSavedOrDeleted: boolean = false;
    successMessage: boolean = false;
    failureMessage: boolean = false;
    Message: string = "";
    clsMessage = {};
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true;
    blnPushDataToDatabase: boolean = false;
    strMessage: string = "";
    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    isRequesting: boolean;
    disableSave: boolean = false;

    @ViewChild('tagTypeDataTable') tagTypeDataTable: DataTable;

    constructor(
        private tPRTagsService: TPRTagsService,
        private confirmationService: ConfirmationService,
        private router: Router,
        private tprCommonService: TPRCommonService
    ) { }

    ngOnInit() {
        this.isRequesting = true;
        this.loadData();

        this.cols = [
            { field: 'Name', header: 'Tag Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];

        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
    }

    loadData() {
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.tPRTagsService.getTagsObservable()
            .subscribe(data => this.setTagTypeData(data));
    }

    private setTagTypeData(data: any): void {
        this.tagTypes = [];
        this.tagTypes = data.Result.Tags.$values;

        this.tagTypes.forEach(tagType => {
            tagType.Updated != null ? tagType.Updated = this.tprCommonService.getFormattedSystemDate(new Date(tagType.Updated)) : null;
        });

        this.stopRefreshing();
    }

    showDialogToAdd() {
        this.newTagType = true;
        this.tagType = new TagsValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    }

    save() {
        //console.log(this.tagType);
        if (this.tagType.Name == null || this.tagType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.strMessage = "Please provide valid data.";
            this.clsHighlightInvalidData = {};

            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };

            this.tagType.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;

            if (this.newTagType) {
                //debugger;
                let index: number = this.tagTypes.indexOf(this.tagTypes.find(tag => tag.Name.toLowerCase().trim() == this.tagType.Name.toLowerCase().trim()));
                if (index == -1) {
                    this.tagTypes.push(this.tagType);
                }
                else {
                    this.strMessage = "Tag Name should be unique."
                    this.clsHighlightInvalidData = {};

                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };

                    //this.tagType.Name = "";
                    return false;
                }
            }
            else
                this.tagTypes[this.findSelectedTagIndex()] = this.tagType;
        }
        this.tagType = null;
        this.displayDialog = false;
    }

    saveDataToServer() {
        let action: string = "save";
        this.blnPushDataToDatabase = true;
        this.SaveDataToDataBase(action);
    }

    delete(event: ITagsValue) {
        this.currentTagType = event;
        this.confirmationService.confirm({
            header: "Delete", 
            message: 'Are you sure that you want to delete the selected Tag?',
            accept: () => {
                this.tagTypes.splice(this.findTagIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });
        this.tagType = null;
    }

    SaveDataToDataBase(action: string) {
        this.isRequesting = true;
        this.tPRTagsService.updateTagsObservable(this.tagTypes)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.stopRefreshing();
                    this.Status = "Error";
                    this.ValidationMessage = response.Error;
                    this.blnShowPopUp = true;
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    console.log("Action ->", action);
                    if (action == "save") {
                        this.ValidationMessage = "Tags Data is saved successfully";
                    }
                    else if (action == "delete") {
                        this.ValidationMessage = "The Selected Tag is deleted successfully";
                    }
                    this.loadData();
                    this.blnSavedOrDeleted = true;
                }
            },
            (error: any) => {
                this.stopRefreshing();
                this.Status = "Error";
                this.ValidationMessage = error;
                this.blnShowPopUp = true;
            }
            );
    }

    onRowSelect(event: any) {
        this.newTagType = false;
        this.tagType = this.cloneTagType(event.data);
    }

    cloneTagType(c: ITagsValue): ITagsValue {
        let tagType = new TagsValue();
        for (let prop in c) {
            tagType[prop] = c[prop];
        }
        return tagType;
    }

    findSelectedTagIndex(): number {
        return this.tagTypes.indexOf(this.selectedTagType);
    }

    findTagIndexForDelete(): number {
        return this.tagTypes.indexOf(this.currentTagType);
    }


    refreshData(tagTypeDataTable: DataTable) {
        this.isRequesting = true;
        this.tagTypeDataTable.reset();
        this.loadData();
    }

    private stopRefreshing() {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }
}

class TagsValue implements ITagsValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}