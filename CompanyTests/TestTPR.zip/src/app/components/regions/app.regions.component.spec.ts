﻿import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppRegionComponent } from './app.regions.component';
import { RegionsService } from '../../service/app.regionService';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { addMatchers, click } from '../../../testing';

import IRegionsValue = RegionNamespace.IRegionValue;


describe('AppRegionComponent test cases', () => {
    let de: DebugElement;
    let comp: AppRegionComponent;
    let fixture: ComponentFixture<AppRegionComponent>;
    let regionsService: RegionsService;
    let spy: jasmine.Spy;

    //async before each
    beforeEach(async(() => {
        let tprRegionsServiceStub = {
            getRegionsObservable: true,
            updateRegionsObservable: true
        };

        TestBed.configureTestingModule({
            declarations: [AppRegionComponent],
            imports: [],
            providers: [RegionsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));


    beforeEach(() => {
        fixture = TestBed.createComponent(AppRegionComponent); // creates the fixture of the testing component

        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });

    // test whether the component got successfully initialised
    it('should create component', () => expect(comp).toBeDefined());

    // test for service mockup
    // Tag service actually injected to the component.
    regionsService = fixture.debugElement.injector.get(RegionsService);

    // Create test mockup class
    let regionsMockUp: RegionsValueTestMockup = new RegionsValueTestMockup();
    let regionTypes: IRegionsValue[] = [];

    it('should not call the getRegionsObservable method before OnInit', () => {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionsMockUp));

        expect(spy.calls.any()).toBe(false, 'getRegionsObservable not yet called');
    });

    it('should call the getRegionsObservable method after component initialized', () => {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionsMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getRegionsObservable called');
    });

    it('should raise Add button click event', () => {
        let displayDialog: boolean = true;
        let newTagType: boolean = true;
        let blnValidationResult: boolean = true;

        de = fixture.debugElement.query(By.css('#btnAdd'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newRegionType).toBe(newTagType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });

    it('should raise Save button click event', () => {
        let regionType: IRegionsValue = new RegionsValueTestMockup('Test', '', '', false, new Date(), '', 0, ''); // Creating testmockup object
        comp.region = regionType; // initializing the tagType object with the test mockup object

        de = fixture.debugElement.query(By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.regions.indexOf(regionType)).toBeGreaterThan(-1);
    });

    it('should raise SavetoDatabase button click event', () => {
        let blnPushDataToDatabase: boolean = true;
        let blnSavedOrDeleted: boolean = true;
        let strSavedMessage: string = "Data saved successfully";

        de = fixture.debugElement.query(By.css('#btnSaveDataToServer'));

        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'updateRegionsObservable')
            .and.returnValue(Promise.resolve(regionsMockUp));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        fixture.detectChanges();

        expect(spy.calls.any()).toBe(true, 'updateRegionsObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});

class RegionsValueTestMockup implements IRegionsValue {
    constructor(public Name: string = null,
        public UpdatedBy: string = null,
        public Updated: string = null,
        public IsInUse: boolean = false,
        public Created: Date = null,
        public CreatedBy: string = null,
        public Id: number = 0,
        public $type: string = null) { }
}