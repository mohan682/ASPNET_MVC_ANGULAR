"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var primeng_1 = require('primeng/primeng');
var app_reportsView_service_1 = require('../../service/app.reportsView.service');
var app_server_service_1 = require('../../service/app.server.service');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var RefreshStatusEnum;
(function (RefreshStatusEnum) {
    RefreshStatusEnum[RefreshStatusEnum["None"] = 0] = "None";
    RefreshStatusEnum[RefreshStatusEnum["Complete"] = 1] = "Complete";
    RefreshStatusEnum[RefreshStatusEnum["Error"] = 2] = "Error";
    RefreshStatusEnum[RefreshStatusEnum["Refreshing"] = 3] = "Refreshing";
    RefreshStatusEnum[RefreshStatusEnum["NotDoneDueToDataSourceErrors"] = 4] = "NotDoneDueToDataSourceErrors";
})(RefreshStatusEnum || (RefreshStatusEnum = {}));
var ViewTypeEnum;
(function (ViewTypeEnum) {
    ViewTypeEnum[ViewTypeEnum["WorkBook"] = 0] = "WorkBook";
    ViewTypeEnum[ViewTypeEnum["View"] = 1] = "View";
})(ViewTypeEnum || (ViewTypeEnum = {}));
var AppReportsViewComponent = (function () {
    function AppReportsViewComponent(viewsService, serverService, confirmationService, tPRcommonService, serviceHelper) {
        this.viewsService = viewsService;
        this.serverService = serverService;
        this.confirmationService = confirmationService;
        this.tPRcommonService = tPRcommonService;
        this.serviceHelper = serviceHelper;
        this.view = new ViewsValue();
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.msgs = [];
        this.selectedViewType = new ViewsValue();
        this.selectedViewTypeValue = "";
        this.Message = "";
        this.blnPushDataToDatabase = false;
        this.blnSavedOrDeleted = false;
        this.clsMessage = {};
        this.selectedServerValue = '';
        this.validationErrorMessage = "";
        this.selectedViewTypeName = '';
        this.refviews = [];
        this.blnname = false;
        this.blnserver = false;
        this.blnurl = false;
        this.blntarget = false;
        this.submitAttempt = false;
        this.header = '';
        this.add = false;
        this.blnShowPopUp = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.canEdit = false;
        this.userRoles = [];
        this.isRequesting = false;
        this.RefreshStatusEnum = RefreshStatusEnum;
        this.ViewTypeEnum = ViewTypeEnum;
    }
    AppReportsViewComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }
        this.serviceHelper.importSettings()
            .subscribe(function (data) { return _this.getConstants(data); });
        this.load();
    };
    AppReportsViewComponent.prototype.load = function () {
        var _this = this;
        this.isRequesting = true;
        this.viewsService.getViewsObservable()
            .subscribe(function (data) { return _this.setViewsData(data); });
        this.serverService.getServersObservable()
            .subscribe(function (data) { return _this.setServersData(data); });
    };
    AppReportsViewComponent.prototype.getConstants = function (data) {
        this.constants = data;
        this.authorizeUser();
    };
    AppReportsViewComponent.prototype.authorizeUser = function () {
        console.log("Is User Authorized->", this.isUserAuthorised());
        this.canEdit = !this.isUserAuthorised();
    };
    AppReportsViewComponent.prototype.isUserAuthorised = function () {
        var _this = this;
        return this.userRoles != undefined && this.constants != undefined &&
            this.userRoles.some(function (x) { return x == _this.constants.TPRSuperUser; });
    };
    AppReportsViewComponent.prototype.setViewsData = function (data) {
        this.views = data.Result.TableauViews.$values;
        for (var i in this.views) {
            this.views[i].RefreshState = RefreshStatusEnum[this.views[i].RefreshState];
            this.views[i].ViewType = ViewTypeEnum[this.views[i].ViewType];
            if (this.views[i].LastRefreshed != null) {
                this.views[i].LastRefreshed = this.tPRcommonService.getFormattedSystemDate(new Date(this.views[i].LastRefreshed));
            }
        }
        this.viewtypes = [ViewTypeEnum.WorkBook, ViewTypeEnum.View];
        console.log("view type enum = ", ViewTypeEnum);
        this.ViewTypes = [];
        this.ViewTypes.push({ label: ViewTypeEnum[0], value: ViewTypeEnum.WorkBook });
        this.ViewTypes.push({ label: ViewTypeEnum[1], value: ViewTypeEnum.View });
        console.log("ViewTypes value", this.ViewTypes[0].value, "ViewTypes lablel", this.ViewTypes[0].label);
        console.log("Views->", this.views);
    };
    AppReportsViewComponent.prototype.setServersData = function (data) {
        this.servers = [];
        this.servers = data.Result.TableauServers.$values;
        this.serverValues = [];
        this.serverValues.push({ label: 'Select a server', value: '' });
        var serverData = '';
        for (var i = 0; i < this.servers.length; i++) {
            var server = this.servers[i];
            serverData = server.Name;
            this.serverValues.push({ label: serverData, value: serverData });
        }
        this.stopRefreshing();
    };
    AppReportsViewComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    AppReportsViewComponent.prototype.showDialogToAdd = function () {
        this.header = "Add a new Tableau view";
        this.add = true;
        this.submitAttempt = false;
        if (this.MyForm != undefined && this.MyForm != null) {
            this.MyForm.controls['Name'].markAsPristine();
            this.MyForm.controls['Name'].markAsUntouched();
            this.MyForm.controls['Url'].markAsPristine();
            this.MyForm.controls['Url'].markAsUntouched();
            this.MyForm.controls['TargetLocation'].markAsPristine();
            this.MyForm.controls['TargetLocation'].markAsUntouched();
            this.MyForm.controls['Server'].markAsPristine();
            this.MyForm.controls['Server'].markAsUntouched();
        }
        this.newViewType = true;
        this.view = new ViewsValue();
        this.selectedServerValue = '';
        this.selectedViewTypeValue = '';
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppReportsViewComponent.prototype.isinvalid = function (input) {
        if (input == null || input.trim() == "") {
            return true;
        }
        else {
            return false;
        }
    };
    AppReportsViewComponent.prototype.save = function () {
        this.submitAttempt = true;
        console.log("Try submit" + this.submitAttempt);
        this.blnname = this.isinvalid(this.view.Name);
        this.blnurl = this.isinvalid(this.view.Url);
        this.blntarget = this.isinvalid(this.view.TargetLocation);
        this.blnserver = this.isinvalid(this.selectedServerValue);
        if (this.blnname || this.blnurl || this.blntarget || this.blnserver) {
            this.validationErrorMessage = "Please complete all fields.";
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            return false;
        }
        else {
            if (this.newViewType) {
                this.view.Server = new ServersValue();
                var serverType_1 = new ServersValue();
                var serverTypeSelected_1 = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    var serverTypes = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected_1) {
                        serverType_1 = serverTypes;
                    }
                });
                this.view.Server = serverType_1;
                console.log("saved");
                this.view.RefreshState = RefreshStatusEnum[this.view.RefreshState];
                this.view.ViewType = ViewTypeEnum[this.view.ViewType];
                this.views.push(this.view);
                this.displayDialog = false;
            }
            else {
                this.view.Server = new ServersValue();
                var serverType_2 = new ServersValue();
                var serverTypeSelected_2 = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    var serverTypes = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected_2) {
                        serverType_2 = serverTypes;
                    }
                });
                this.view.Server = serverType_2;
                this.view.ViewType = this.selectedViewTypeValue;
                this.view.ViewType = ViewTypeEnum[this.view.ViewType];
                console.log("view type being saved is " + this.view.ViewType);
                this.views[this.findSelectedViewTypeIndex()] = this.view;
            }
        }
        this.view = null;
        this.displayDialog = false;
        console.log(this.views);
    };
    AppReportsViewComponent.prototype.findSelectedViewTypeIndex = function () {
        var ViewName = this.selectedViewTypeName;
        var indexOut;
        var tempView;
        this.views.forEach(function (item, index) {
            if (ViewName == item.Name) {
                tempView = item;
            }
        });
        indexOut = this.views.indexOf(tempView);
        return indexOut;
    };
    AppReportsViewComponent.prototype.findViewTypeIndexForDelete = function () {
        return this.views.indexOf(this.currentViewType);
    };
    AppReportsViewComponent.prototype.findViewTypeIndexForRefresh = function () {
        return this.views.indexOf(this.currentViewType);
    };
    AppReportsViewComponent.prototype.refreshViews = function () {
        var _this = this;
        var action = "refresh";
        this.viewsService.refreshTableauViewsObservable(this.views)
            .subscribe(function (response) {
            if (response.Error) {
                _this.blnShowPopUp = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
            }
            else {
                _this.blnShowPopUp = true;
                _this.Status = "Refreshing";
                _this.ValidationMessage = "Views are being refreshed";
            }
        }, function (error) {
            _this.blnShowPopUp = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
        });
        console.log(this.views);
        console.log("refresh views method called");
        console.log(this.views[0].RefreshState);
    };
    AppReportsViewComponent.prototype.refreshSelectedView = function (event) {
        var _this = this;
        console.log("refresh views clicked");
        var action = "refresh";
        this.refviews = [];
        this.currentViewType = event;
        this.refviews.push(event);
        var index = this.findViewTypeIndexForRefresh();
        this.blnShowPopUp = true;
        this.Status = "Refreshing";
        this.ValidationMessage = "View is being refreshed";
        this.viewsService.refreshTableauViewsObservable(this.refviews)
            .subscribe(function (response) {
            debugger;
            console.log(response);
            if (response.Error) {
                _this.blnShowPopUp = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
            }
            else {
                // this.blnShowPopUp = true;
                // this.Status = "Refresh Complete";
                // this.ValidationMessage = "View refreshed successfully";
                _this.load();
            }
        }, function (error) {
            _this.blnShowPopUp = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
        });
        // (response: Response) => this.ShowRefreshMessage(response, action)
        // );
    };
    AppReportsViewComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentViewType = event;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Report?',
            rejectVisible: true,
            acceptVisible: true,
            accept: function () {
                _this.views.splice(_this.findViewTypeIndexForDelete(), 1);
            }
        });
        this.view = null;
        console.log(this.views);
    };
    AppReportsViewComponent.prototype.onRowSelect = function (event) {
        this.add = false;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.validationErrorMessage = '';
        this.newViewType = false;
        this.view = new ViewsValue();
        this.view = this.cloneView(event.data);
        this.selectedViewType = this.view;
        this.selectedViewTypeName = this.selectedViewType.Name;
        if (this.view.Server != null) {
            this.selectedServerValue = this.view.Server.Name;
        }
        else {
            this.selectedServerValue = '';
        }
        this.selectedViewTypeValue = this.view.ViewType;
        this.selectedViewTypeValue = ViewTypeEnum[this.view.ViewType];
        this.header = "Edit " + this.selectedViewTypeName + " configuration";
        console.log("SELECTED SERVER VALUE = " + this.selectedServerValue);
        console.log("SELECTED VIEW TYPE VALUE = " + this.selectedViewTypeValue);
        console.log("row selected");
        this.displayDialog = true;
    };
    AppReportsViewComponent.prototype.cloneView = function (c) {
        var viewsval = new ViewsValue();
        for (var prop in c) {
            viewsval[prop] = c[prop];
        }
        console.log("row select");
        console.log(viewsval);
        return viewsval;
    };
    AppReportsViewComponent.prototype.saveDataToServer = function () {
        this.isRequesting = true;
        var action = "save";
        this.blnPushDataToDatabase = true;
        console.log("Save to server");
        this.SaveDataToDataBase();
    };
    AppReportsViewComponent.prototype.SaveDataToDataBase = function () {
        var _this = this;
        this.newViews = this.views;
        this.viewsService.updateViewsObservable(this.newViews)
            .subscribe(function (response) {
            if (response.Error) {
                _this.blnShowPopUp = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
                _this.stopRefreshing();
            }
            else {
                _this.blnShowPopUp = true;
                _this.Status = "Success";
                _this.ValidationMessage = "Data is saved successfully";
                _this.blnSavedOrDeleted = true;
                _this.load();
            }
        }, function (error) {
            _this.blnShowPopUp = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
            _this.stopRefreshing();
        });
        this.newViews = null;
    };
    // ShowMessageOnSaveorDeleteData(data: any, action: string) {
    //     console.log("showmessageonsaveordelete");
    //     console.log(data);
    //     this.blnSavedOrDeleted = true;
    //     this.clsMessage = {};
    //     this.clsMessage = {
    //         successMessage: true,
    //         failureMessage: false
    //     }
    //     this.msgs = [];
    //     if (action == "save") {
    //         this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
    //         this.Message = "Data saved successfully";
    //     }
    //     else if (action == "delete") {
    //         this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' })
    //         this.Message = "Data deleted successfully";
    //     }
    //     else {
    //         this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Error' });
    //     }
    // }
    // ShowRefreshMessage(data: any, action: string) {
    //     console.log("showrefreshmessage");
    //     console.log(data);
    //     this.blnSavedOrDeleted = true;
    //     this.clsMessage = {};
    //     this.clsMessage = {
    //         successMessage: true,
    //         failureMessage: false
    //     }
    //     if (data.Error) {
    //         this.blnShowPopUp = true;
    //         this.Status = "Error";
    //         this.ValidationMessage = data.Error.toString();
    //     }
    //     else {
    //         this.blnShowPopUp = true;
    //         this.Status = "Success";
    //         this.ValidationMessage = "Refresh completed";
    //         this.blnSavedOrDeleted = true;
    //     }
    //     // this.msgs = [];
    //     // if (action == "refresh") {
    //     //     this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Refreshing' });
    //     //     this.Message = "Refreshing";
    //     // }
    //     // else {
    //     //     this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Error' });
    //     // }
    // }
    AppReportsViewComponent.prototype.cloneViewType = function (c) {
        var view = new ViewsValue();
        for (var prop in c) {
            view[prop] = c[prop];
        }
        return view;
    };
    __decorate([
        core_1.ViewChild('MyForm'), 
        __metadata('design:type', forms_1.NgForm)
    ], AppReportsViewComponent.prototype, "MyForm", void 0);
    AppReportsViewComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/reportsView/app.reportsView.component.html'
        }), 
        __metadata('design:paramtypes', [app_reportsView_service_1.ViewsService, app_server_service_1.ServerService, primeng_1.ConfirmationService, app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper])
    ], AppReportsViewComponent);
    return AppReportsViewComponent;
}());
exports.AppReportsViewComponent = AppReportsViewComponent;
var ViewsValue = (function () {
    function ViewsValue(Name, IsInUse, Url, TargetLocation, Server, LastRefreshed, RefreshDuration, 
        //public RefreshDuration: any = '',
        RefreshState, ViewType, Created, CreatedBy, Updated, UpdatedBy, Id, $type) {
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Url === void 0) { Url = null; }
        if (TargetLocation === void 0) { TargetLocation = null; }
        if (Server === void 0) { Server = null; }
        if (LastRefreshed === void 0) { LastRefreshed = null; }
        if (RefreshDuration === void 0) { RefreshDuration = '00:00:00'; }
        if (RefreshState === void 0) { RefreshState = 0; }
        if (ViewType === void 0) { ViewType = 0; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        if ($type === void 0) { $type = null; }
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Url = Url;
        this.TargetLocation = TargetLocation;
        this.Server = Server;
        this.LastRefreshed = LastRefreshed;
        this.RefreshDuration = RefreshDuration;
        this.RefreshState = RefreshState;
        this.ViewType = ViewType;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
        this.$type = $type;
    }
    return ViewsValue;
}());
var ServersValue = (function () {
    function ServersValue(Name, Url, $type, Id) {
        if (Name === void 0) { Name = null; }
        if (Url === void 0) { Url = null; }
        if ($type === void 0) { $type = null; }
        if (Id === void 0) { Id = 0; }
        this.Name = Name;
        this.Url = Url;
        this.$type = $type;
        this.Id = Id;
    }
    return ServersValue;
}());
//# sourceMappingURL=app.reportsView.component.js.map