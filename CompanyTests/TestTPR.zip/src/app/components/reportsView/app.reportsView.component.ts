import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, FormsModule } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import { TooltipModule } from 'primeng/primeng';
import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';


import { ViewsService } from '../../service/app.reportsView.service';
import { ServerService } from '../../service/app.server.service';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';

import IViewsValue = ViewNamespace.IViewValue;
import IServer = ViewNamespace.IServer;

enum RefreshStatusEnum {
    None = 0,
    Complete = 1,
    Error = 2,
    Refreshing = 3,
    NotDoneDueToDataSourceErrors = 4
}
enum ViewTypeEnum {
    WorkBook = 0,
    View = 1
}

@Component({
    selector: 'my-app',
    templateUrl: 'app/components/reportsView/app.reportsView.component.html'
})
export class AppReportsViewComponent implements OnInit {
    views: IViewsValue[];
    newViews: IViewsValue[];
    servers: IServer[];
    servername: string;
    newViewType: boolean;
    displayDialog: boolean;
    view: IViewsValue = new ViewsValue();
    viewtorefresh: IViewsValue[];
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true
    msgs: Message[] = [];
    selectedViewType: IViewsValue = new ViewsValue();
    selectedViewTypeValue: string = "";
    ViewTypes: SelectItem[];
    currentViewType: IViewsValue;
    Message: string = "";
    blnPushDataToDatabase: boolean = false;
    blnSavedOrDeleted: boolean = false;
    clsMessage = {};
    serverValues: SelectItem[];
    selectedServerValue: string = '';
    viewtypes: any[];
    validationErrorMessage: string = "";
    newView: boolean;
    selectedViewTypeName: string = '';
    tempView: IViewsValue;
    refviews: IViewsValue[] = [];
    blnname: boolean = false;
    blnserver: boolean = false;
    blnurl: boolean = false;
    blntarget: boolean = false;
    @ViewChild('MyForm') public MyForm: NgForm;
    submitAttempt: boolean = false;
    header: string = '';
    add: boolean = false;
    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    canEdit: boolean = false;
    userRoles: string[] = [];
    constants: any;
    isRequesting: boolean = false;

    RefreshStatusEnum: typeof RefreshStatusEnum = RefreshStatusEnum;
    ViewTypeEnum: typeof ViewTypeEnum = ViewTypeEnum;

    constructor(private viewsService: ViewsService,
        private serverService: ServerService,
        private confirmationService: ConfirmationService,
        private tPRcommonService: TPRCommonService,
        private serviceHelper: ServiceHelper) { }

    ngOnInit() {

        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            console.log("User Roles from Local Storage ->", this.userRoles);
        }

        this.serviceHelper.importSettings()
            .subscribe(data => this.getConstants(data));

        this.load();
    }

    private load() {
        this.isRequesting = true;
        this.viewsService.getViewsObservable()
            .subscribe(data => this.setViewsData(data));

        this.serverService.getServersObservable()
            .subscribe(data => this.setServersData(data));
    }

    public getConstants(data: any): void {
        this.constants = data;
        this.authorizeUser();
    }

    private authorizeUser() {
        console.log("Is User Authorized->", this.isUserAuthorised());
        this.canEdit = !this.isUserAuthorised();
    }

    public isUserAuthorised(): boolean {
        return this.userRoles != undefined && this.constants != undefined &&
            this.userRoles.some(x => x == this.constants.TPRSuperUser);
    }

    private setViewsData(data: any): void {
        this.views = data.Result.TableauViews.$values;
        for (let i in this.views) {
            this.views[i].RefreshState = RefreshStatusEnum[this.views[i].RefreshState];
            this.views[i].ViewType = ViewTypeEnum[this.views[i].ViewType];
            if (this.views[i].LastRefreshed != null) {
                this.views[i].LastRefreshed = this.tPRcommonService.getFormattedSystemDate(new Date(this.views[i].LastRefreshed));
            }
        }
        this.viewtypes = [ViewTypeEnum.WorkBook, ViewTypeEnum.View];
        console.log("view type enum = ", ViewTypeEnum);

        this.ViewTypes = [];
        this.ViewTypes.push({ label: ViewTypeEnum[0], value: ViewTypeEnum.WorkBook });
        this.ViewTypes.push({ label: ViewTypeEnum[1], value: ViewTypeEnum.View });
        console.log("ViewTypes value", this.ViewTypes[0].value, "ViewTypes lablel", this.ViewTypes[0].label);

        console.log("Views->", this.views);
    }


    private setServersData(data: any): void {
        this.servers = [];
        this.servers = data.Result.TableauServers.$values;

        this.serverValues = [];
        this.serverValues.push({ label: 'Select a server', value: '' });
        let serverData: string = '';

        for (var i = 0; i < this.servers.length; i++) {
            let server = this.servers[i];
            serverData = server.Name;

            this.serverValues.push({ label: serverData, value: serverData });
        }

        this.stopRefreshing();
    }

    private stopRefreshing() {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    showDialogToAdd() {
        this.header = "Add a new Tableau view";
        this.add = true;
        this.submitAttempt = false;
        if (this.MyForm != undefined && this.MyForm != null) {
            this.MyForm.controls['Name'].markAsPristine();
            this.MyForm.controls['Name'].markAsUntouched();
            this.MyForm.controls['Url'].markAsPristine();
            this.MyForm.controls['Url'].markAsUntouched();
            this.MyForm.controls['TargetLocation'].markAsPristine();
            this.MyForm.controls['TargetLocation'].markAsUntouched();
            this.MyForm.controls['Server'].markAsPristine();
            this.MyForm.controls['Server'].markAsUntouched();
        }
        this.newViewType = true;
        this.view = new ViewsValue();
        this.selectedServerValue = '';
        this.selectedViewTypeValue = '';
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    }

    isinvalid(input: string) {
        if (input == null || input.trim() == "") {
            return true;
        }
        else {
            return false;
        }
    }

    save() {
        this.submitAttempt = true;
        console.log("Try submit" + this.submitAttempt);

        this.blnname = this.isinvalid(this.view.Name);
        this.blnurl = this.isinvalid(this.view.Url);
        this.blntarget = this.isinvalid(this.view.TargetLocation);
        this.blnserver = this.isinvalid(this.selectedServerValue);

        if (this.blnname || this.blnurl || this.blntarget || this.blnserver) {

            this.validationErrorMessage = "Please complete all fields.";
            this.clsHighlightInvalidData = {};

            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            return false;
        }
        else {
            if (this.newViewType) {
                this.view.Server = new ServersValue();
                let serverType = new ServersValue();
                let serverTypeSelected: string = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    let serverTypes: IServer = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected) {
                        serverType = serverTypes;
                    }
                });

                this.view.Server = serverType;
                console.log("saved");
                this.view.RefreshState = RefreshStatusEnum[this.view.RefreshState];
                this.view.ViewType = ViewTypeEnum[this.view.ViewType];
                this.views.push(this.view);
                this.displayDialog = false;
            }
            else {
                this.view.Server = new ServersValue();
                let serverType = new ServersValue();
                let serverTypeSelected: string = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    let serverTypes: IServer = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected) {
                        serverType = serverTypes;
                    }
                });
                this.view.Server = serverType;
                this.view.ViewType = this.selectedViewTypeValue;
                this.view.ViewType = ViewTypeEnum[this.view.ViewType];
                console.log("view type being saved is " + this.view.ViewType);
                this.views[this.findSelectedViewTypeIndex()] = this.view;
            }
        }
        this.view = null;
        this.displayDialog = false;
        console.log(this.views);
    }


    findSelectedViewTypeIndex(): number {
        let ViewName: string = this.selectedViewTypeName;
        let indexOut: number;
        let tempView: any;
        this.views.forEach(function (item, index) {
            if (ViewName == item.Name) {
                tempView = item;
            }
        });
        indexOut = this.views.indexOf(tempView);
        return indexOut;
    }

    findViewTypeIndexForDelete(): number {
        return this.views.indexOf(this.currentViewType);
    }

    findViewTypeIndexForRefresh(): number {
        return this.views.indexOf(this.currentViewType);
    }

    refreshViews() {
        let action: string = "refresh";
        this.viewsService.refreshTableauViewsObservable(this.views)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Refreshing";
                    this.ValidationMessage = "Views are being refreshed";
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
            });

        console.log(this.views);
        console.log("refresh views method called");
        console.log(this.views[0].RefreshState);
    }


    refreshSelectedView(event: IViewsValue) {
        console.log("refresh views clicked");
        let action: string = "refresh";
        this.refviews = [];
        this.currentViewType = event;
        this.refviews.push(event);
        let index: number = this.findViewTypeIndexForRefresh();
        this.blnShowPopUp = true;
        this.Status = "Refreshing";
        this.ValidationMessage = "View is being refreshed";
        this.viewsService.refreshTableauViewsObservable(this.refviews)
            .subscribe(
            (response: any) => {
                debugger;
                console.log(response);
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                }
                else {
                    // this.blnShowPopUp = true;
                    // this.Status = "Refresh Complete";
                    // this.ValidationMessage = "View refreshed successfully";
                    this.load();
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
            });
        // (response: Response) => this.ShowRefreshMessage(response, action)
        // );
    }

    delete(event: IViewsValue) {
        this.currentViewType = event;

        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Report?',
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                this.views.splice(this.findViewTypeIndexForDelete(), 1);
            }
        });
        this.view = null;
        console.log(this.views);
    }

    onRowSelect(event: any) {

        this.add = false;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.validationErrorMessage = '';
        this.newViewType = false;
        this.view = new ViewsValue();
        this.view = this.cloneView(event.data);
        this.selectedViewType = this.view;
        this.selectedViewTypeName = this.selectedViewType.Name;


        if (this.view.Server != null) {
            this.selectedServerValue = this.view.Server.Name;
        }
        else {
            this.selectedServerValue = ''
        }
        this.selectedViewTypeValue = this.view.ViewType;
        this.selectedViewTypeValue = ViewTypeEnum[this.view.ViewType];
        this.header = "Edit " + this.selectedViewTypeName + " configuration";
        console.log("SELECTED SERVER VALUE = " + this.selectedServerValue);
        console.log("SELECTED VIEW TYPE VALUE = " + this.selectedViewTypeValue);
        console.log("row selected");
        this.displayDialog = true;
    }

    cloneView(c: IViewsValue): IViewsValue {
        let viewsval = new ViewsValue();
        for (let prop in c) {
            viewsval[prop] = c[prop];
        }
        console.log("row select");
        console.log(viewsval);
        return viewsval;

    }

    saveDataToServer() {
        this.isRequesting = true;
        let action: string = "save";
        this.blnPushDataToDatabase = true;
        console.log("Save to server");
        this.SaveDataToDataBase();
    }

    SaveDataToDataBase() {
        this.newViews = this.views;
        this.viewsService.updateViewsObservable(this.newViews)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                    this.stopRefreshing();
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    this.ValidationMessage = "Data is saved successfully";
                    this.blnSavedOrDeleted = true;
                    this.load();
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
                this.stopRefreshing();
            });
        this.newViews = null;
    }

    // ShowMessageOnSaveorDeleteData(data: any, action: string) {
    //     console.log("showmessageonsaveordelete");
    //     console.log(data);
    //     this.blnSavedOrDeleted = true;
    //     this.clsMessage = {};
    //     this.clsMessage = {
    //         successMessage: true,
    //         failureMessage: false
    //     }

    //     this.msgs = [];
    //     if (action == "save") {
    //         this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
    //         this.Message = "Data saved successfully";
    //     }
    //     else if (action == "delete") {
    //         this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' })
    //         this.Message = "Data deleted successfully";
    //     }
    //     else {
    //         this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Error' });
    //     }
    // }

    // ShowRefreshMessage(data: any, action: string) {
    //     console.log("showrefreshmessage");
    //     console.log(data);
    //     this.blnSavedOrDeleted = true;
    //     this.clsMessage = {};
    //     this.clsMessage = {
    //         successMessage: true,
    //         failureMessage: false
    //     }

    //     if (data.Error) {
    //         this.blnShowPopUp = true;
    //         this.Status = "Error";
    //         this.ValidationMessage = data.Error.toString();
    //     }
    //     else {
    //         this.blnShowPopUp = true;
    //         this.Status = "Success";
    //         this.ValidationMessage = "Refresh completed";
    //         this.blnSavedOrDeleted = true;
    //     }
    //     // this.msgs = [];
    //     // if (action == "refresh") {
    //     //     this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Refreshing' });
    //     //     this.Message = "Refreshing";
    //     // }
    //     // else {
    //     //     this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Error' });
    //     // }
    // }

    cloneViewType(c: IViewsValue): IViewsValue {
        let view = new ViewsValue();
        for (let prop in c) {
            view[prop] = c[prop];
        }
        return view;
    }
}

class ViewsValue implements IViewsValue {
    constructor(
        public Name: string = null,
        public IsInUse: boolean = false,
        public Url: string = null,
        public TargetLocation: string = null,
        public Server: IServer = null,
        public LastRefreshed: Date = null,
        public RefreshDuration: any = '00:00:00',
        //public RefreshDuration: any = '',
        public RefreshState: number = 0,
        public ViewType: number = 0,
        public Created: Date = null,
        public CreatedBy: string = null,
        public Updated: Date = null,
        public UpdatedBy: string = null,
        public Id: number = 0,
        public $type: string = null) { }
}

class ServersValue implements IServer {
    constructor(
        public Name: string = null,
        public Url: string = null,
        public $type: string = null,
        public Id: number = 0
    ) { }
}

