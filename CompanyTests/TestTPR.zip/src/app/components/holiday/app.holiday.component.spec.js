"use strict";
var testing_1 = require('@angular/core/testing');
var platform_browser_1 = require('@angular/platform-browser');
var app_holiday_component_1 = require('./app.holiday.component');
var app_TPRHolidayService_1 = require('../../service/app.TPRHolidayService');
var app_regionService_1 = require('../../service/app.regionService');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var testing_2 = require('../../../testing');
describe('AppHolidayComponent test cases', function () {
    var de;
    var comp;
    var fixture;
    var holidayService;
    var regionsService;
    var spy;
    //async before each
    beforeEach(testing_1.async(function () {
        //Configure testing bed
        testing_1.TestBed.configureTestingModule({
            declarations: [app_holiday_component_1.AppHolidayComponent],
            imports: [],
            providers: [app_TPRHolidayService_1.TPRHolidayService, app_regionService_1.RegionsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(app_holiday_component_1.AppHolidayComponent); // creates the fixture of the testing component
        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });
    // test whether the component got successfully initialised
    it('should create component', function () { return expect(comp).toBeDefined(); });
    // test for service mockup
    // Holiday service actually injected to the component.
    holidayService = fixture.debugElement.injector.get(app_TPRHolidayService_1.TPRHolidayService);
    // Regions service actually injected to the component.
    regionsService = fixture.debugElement.injector.get(app_regionService_1.RegionsService);
    // Create test mockup class
    var holidayMockUp = new HolidayTypesValueTestMockup();
    var regionMockUp = new RegionTypeTestMockup();
    var holidays;
    var regions;
    it('should not call the getHolidaysObservable method before OnInit', function () {
        // Setup spy on the 'getHolidaysObservable' method
        spy = spyOn(holidayService, 'getHolidaysObservable')
            .and.returnValue(Promise.resolve(holidayMockUp));
        expect(spy.calls.any()).toBe(false, 'getHolidaysObservable not yet called');
    });
    it('should not call the getRegionsObservable method before OnInit', function () {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionMockUp));
        expect(spy.calls.any()).toBe(false, 'getRegionsObservable not yet called');
    });
    it('should call the getHolidaysObservable method after component initialized', function () {
        // Setup spy on the 'getHolidaysObservable' method
        spy = spyOn(holidayService, 'getHolidaysObservable')
            .and.returnValue(Promise.resolve(holidayMockUp));
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getHolidaysObservable called');
    });
    it('should call the getRegionsObservable method after component initialized', function () {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionMockUp));
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getRegionsObservable called');
    });
    it('Check for properness of the validateHolidayData for date validation (false condition)', function () {
        var dateSelected = '';
        comp.date3 = dateSelected;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAddHoliday'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Empty date provided for date variable.');
        // setup some junk data for test
        dateSelected = "TestDate";
        comp.date3 = dateSelected;
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper date provided for date variable.');
    });
    it('Check for properness of the validateHolidayData for holiday Type validation (false condition)', function () {
        var date = new Date();
        var dateSelected = '';
        var holidayType = '';
        // setup proper date
        comp.date3 = date.toDateString();
        // setup improper holiday type
        // check for holiday Type
        comp.selectedHolidayType = holidayType;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAddHoliday'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday type provided.');
        holidayType = "select holiday";
        comp.selectedHolidayType = holidayType;
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday type provided.');
    });
    it('Check for properness of the validateHolidayData for region Type validation (false condition)', function () {
        var date = new Date();
        var dateSelected = '';
        var holidayType = '';
        var regionType = '';
        // setup proper date
        comp.date3 = date.toDateString();
        // setup proper holiday type
        holidayType = "Test Holiday";
        // setup improper region type
        // check for region Type
        comp.selectedRegion = regionType;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAddHoliday'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper region type provided.');
        regionType = "select region";
        comp.selectedRegion = regionType;
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper region type provided.');
    });
    it('Check for properness of the validateHolidayData for holiday Description validation (false condition)', function () {
        var date = new Date();
        var dateSelected = '';
        var holidayType = '';
        var regionType = '';
        var holidayDescription = '';
        // setup proper date
        comp.date3 = date.toDateString();
        // setup proper holiday type
        holidayType = "Test Holiday";
        // setup proper region type
        regionType = "Test Region";
        // setup improper holiday description
        // check for holiday description
        comp.holidayDescription = holidayDescription;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAddHoliday'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday desctiption provided.');
        comp.holidayDescription = null;
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday desctiption provided.');
    });
    it('Check for properness of the validateHolidayData (complete true condition)', function () {
        var date = new Date();
        var holidayType = "Test Holiday Type";
        var regionType = "Test Region Type";
        var holidayDescription = "Test Description";
        comp.date3 = date.toDateString();
        comp.selectedHolidayType = holidayType;
        comp.selectedRegion = regionType;
        comp.holidayDescription = holidayDescription;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAddHoliday'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(true, 'Success return for validateHolidayData method call.');
    });
    it('should raise AddHoliday button click event', function () {
        var date = new Date();
        var holidayType = "Test Holiday Type";
        var regionType = "Test Region Type";
        var holidayDescription = "Test Description";
        comp.date3 = date.toDateString();
        comp.selectedHolidayType = holidayType;
        comp.selectedRegion = regionType;
        comp.holidayDescription = holidayDescription;
        // create mockup objects to be passed to service
        var regionTypeMockup = new RegionTypeTestMockup('', 'Test region', false, '', '', '', '', 0);
        var holidayTypeMockup = new HolidayTypesValueTestMockup(false, 'Test holiday Type', '', '', regionTypeMockup, false, 'Test Holiday', false, '', '', '', '', 0);
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAddHoliday'));
        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(holidayService, 'updateHolidayObservable')
            .and.returnValue(Promise.resolve(holidayTypeMockup));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'updateHolidayObservable called');
        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.holidays.indexOf(holidayTypeMockup)).toBeGreaterThan(-1);
    });
});
var HolidayTypesValueTestMockup = (function () {
    function HolidayTypesValueTestMockup(IsDeletable, HolidayType, $type, Date, Region, MarkAsDeleted, Name, IsUpdateTimingException, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if (IsDeletable === void 0) { IsDeletable = false; }
        if (HolidayType === void 0) { HolidayType = null; }
        if ($type === void 0) { $type = null; }
        if (Date === void 0) { Date = null; }
        if (Region === void 0) { Region = null; }
        if (MarkAsDeleted === void 0) { MarkAsDeleted = false; }
        if (Name === void 0) { Name = null; }
        if (IsUpdateTimingException === void 0) { IsUpdateTimingException = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.IsDeletable = IsDeletable;
        this.HolidayType = HolidayType;
        this.$type = $type;
        this.Date = Date;
        this.Region = Region;
        this.MarkAsDeleted = MarkAsDeleted;
        this.Name = Name;
        this.IsUpdateTimingException = IsUpdateTimingException;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return HolidayTypesValueTestMockup;
}());
var RegionTypeTestMockup = (function () {
    function RegionTypeTestMockup($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return RegionTypeTestMockup;
}());
//# sourceMappingURL=app.holiday.component.spec.js.map