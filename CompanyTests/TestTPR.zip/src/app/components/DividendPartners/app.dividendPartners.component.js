"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var primeng_2 = require('primeng/primeng');
var app_TPRDividendPartnersService_1 = require('../../service/app.TPRDividendPartnersService');
var app_TPRBusinessSegmentsService_1 = require('../../service/app.TPRBusinessSegmentsService');
var app_serviceHelper_1 = require('../../service/app.serviceHelper');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var AppDividendPartnersComponent = (function () {
    function AppDividendPartnersComponent(tPRDividendPartnersService, tPRBusinessSegmentsService, confirmationService, tprCommonService, serviceHelper) {
        this.tPRDividendPartnersService = tPRDividendPartnersService;
        this.tPRBusinessSegmentsService = tPRBusinessSegmentsService;
        this.confirmationService = confirmationService;
        this.tprCommonService = tprCommonService;
        this.serviceHelper = serviceHelper;
        this.selectedDividendPartnerTypeName = '';
        this.selectedDividendPartnerType = new DividendPartnerTypesValue();
        this.currentDividendPartnerType = new DividendPartnerTypesValue();
        this.selectedSegmentValue = '';
        this.msgs = [];
        this.blnSavedOrDeleted = false;
        this.successMessage = false;
        this.failureMessage = false;
        this.Message = "";
        this.clsMessage = {};
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.blnPushDataToDatabase = false;
        this.validationErrorMessage = "";
        this.strErrorMessage = "";
        this.blnShowPopUp = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.isRequesting = false;
        this.disableSave = false;
        this.canEdit = false;
    }
    ;
    AppDividendPartnersComponent.prototype.ngOnInit = function () {
        this.loadData();
        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);
    };
    AppDividendPartnersComponent.prototype.loadData = function () {
        var _this = this;
        this.isRequesting = true;
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.tPRDividendPartnersService.getDividendPartnersObservable()
            .subscribe(function (data) { return _this.setDividendPartnerData(data); });
        this.tPRBusinessSegmentsService.getBusinessSegmentsObservable()
            .subscribe(function (data) { return _this.setBusinessSegmentsData(data); });
    };
    AppDividendPartnersComponent.prototype.setDividendPartnerData = function (data) {
        var _this = this;
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
        this.dividendPartnerTypes = this.dividendPartnerTypes.filter(function (divPartner) { return divPartner.Editable == true; });
        this.dividendPartnerTypes.forEach(function (dividendPartner) {
            dividendPartner.Updated != null ? dividendPartner.Updated = _this.tprCommonService.getFormattedSystemDate(new Date(dividendPartner.Updated)) : null;
        });
        this.stopRefreshing();
    };
    AppDividendPartnersComponent.prototype.setBusinessSegmentsData = function (data) {
        this.businessSegments = [];
        this.businessSegments = data.Result.BusinessSegments.$values;
        this.segments = [];
        this.segments.push({ label: 'Select Segments', value: 'Select Segments' });
        var segmentData = '';
        for (var i = 0; i < this.businessSegments.length; i++) {
            var segment = this.businessSegments[i];
            segmentData = segment.Name;
            this.segments.push({ label: segmentData, value: segmentData });
        }
    };
    AppDividendPartnersComponent.prototype.showDialogToAdd = function () {
        this.newDividendPartnerType = true;
        this.dividendPartnersType = new DividendPartnerTypesValue();
        this.displayDialog = true;
        this.selectedSegmentValue = '';
        this.validationErrorMessage = '';
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppDividendPartnersComponent.prototype.save = function () {
        var _this = this;
        //debugger;
        if (this.dividendPartnersType.Name == null || this.dividendPartnersType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.validationErrorMessage = "Please enter a valid 'Name'.";
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            this.dividendPartnersType.Name = "";
            return false;
        }
        else {
            if (this.newDividendPartnerType) {
                if (this.selectedSegmentValue.trim() == "" || this.selectedSegmentValue.toUpperCase() == "SELECT SEGMENTS") {
                    //alert("Please select business segment.");
                    this.validationErrorMessage = "Please select a Business Segment.";
                    this.clsHighlightInvalidData = {};
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };
                    this.selectedSegmentValue = '';
                    return false;
                }
                else {
                    this.dividendPartnersType.BusinessSegment = new BusinessSegmentType();
                    var businessSegmentType_1 = new BusinessSegmentType();
                    var businessSegmentSelected_1 = this.selectedSegmentValue;
                    this.businessSegments.forEach(function (item) {
                        var businessSegment = new BusinessSegmentType();
                        businessSegment = item;
                        if (businessSegment.Name == businessSegmentSelected_1) {
                            businessSegmentType_1 = businessSegment;
                        }
                    });
                    this.dividendPartnersType.BusinessSegment = businessSegmentType_1;
                }
                //console.log("new dividendPartnersType ->", this.dividendPartnersType);
                var index = this.dividendPartnerTypes.indexOf(this.dividendPartnerTypes.find(function (divPartner) { return divPartner.Name.toLowerCase().trim() == _this.dividendPartnersType.Name.toLowerCase().trim(); }));
                if (index == -1) {
                    this.dividendPartnerTypes.push(this.dividendPartnersType);
                }
                else {
                    this.validationErrorMessage = "Dividend Partner Name should be unique.";
                    this.clsHighlightInvalidData = {};
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };
                    return false;
                }
            }
            else {
                if (this.selectedSegmentValue.trim() == "" || this.selectedSegmentValue.toUpperCase() == "SELECT SEGMENTS") {
                    //alert("Please select business segment.");
                    this.validationErrorMessage = "Please select a Business Segment.";
                    this.clsHighlightInvalidData = {};
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };
                    this.selectedSegmentValue = '';
                    return false;
                }
                else {
                    this.dividendPartnersType.BusinessSegment = new BusinessSegmentType();
                    var businessSegmentType_2 = new BusinessSegmentType();
                    var businessSegmentSelected_2 = this.selectedSegmentValue;
                    this.businessSegments.forEach(function (item) {
                        var businessSegment = new BusinessSegmentType();
                        businessSegment = item;
                        if (businessSegment.Name == businessSegmentSelected_2) {
                            businessSegmentType_2 = businessSegment;
                        }
                    });
                    this.dividendPartnersType.BusinessSegment = businessSegmentType_2;
                    this.dividendPartnerTypes[this.findSelectedDividendPartnerIndex()] = this.dividendPartnersType;
                }
            }
        }
        this.dividendPartnersType = null;
        this.displayDialog = false;
    };
    AppDividendPartnersComponent.prototype.Cancel = function () {
        this.displayDialog = false;
    };
    AppDividendPartnersComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = true;
        var divPartnersArray = [];
        this.dividendPartnerTypes.forEach(function (divPartner) { return divPartnersArray.push(divPartner.Name.toLowerCase().trim()); });
        var uniquenessResult = this.checkIfArrayIsUnique(divPartnersArray);
        if (uniquenessResult) {
            this.SaveDataToDataBase(action);
        }
        else {
            this.blnShowPopUp = true;
            this.Status = "Validation error!";
            this.ValidationMessage = "Dividend Partner Name should be unique.";
        }
        //this.SaveDataToDataBase(action);
    };
    AppDividendPartnersComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentDividendPartnerType = event;
        //console.log(this.currentDividendPartnerType);
        //alert(this.currentDividendPartnerType.Name + "," + this.currentDividendPartnerType.Segment);
        //this.dividendPartnerTypes.splice(this.findDividendPartnerIndexForDelete(), 1);
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Dividend Partner?',
            accept: function () {
                _this.dividendPartnerTypes.splice(_this.findDividendPartnerIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });
        this.dividendPartnersType = null;
        this.displayDialog = false;
    };
    AppDividendPartnersComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.isRequesting = true;
        this.tPRDividendPartnersService.updateDividendPartnersObservable(this.dividendPartnerTypes)
            .subscribe(function (response) {
            if (response.Error) {
                _this.blnShowPopUp = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
                _this.stopRefreshing();
            }
            else {
                //this.ShowMessageOnSaveorDeleteData(response, action);
                _this.blnShowPopUp = true;
                _this.Status = "Success";
                console.log("Action ->", action);
                if (action == "save") {
                    _this.ValidationMessage = "Dividend Partner Data is saved successfully";
                }
                else if (action == "delete") {
                    _this.ValidationMessage = "The Selected Dividend Partner is deleted successfully";
                }
                _this.loadData();
                _this.blnSavedOrDeleted = true;
            }
        }, function (error) {
            _this.blnShowPopUp = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
            _this.stopRefreshing();
        });
        //console.log(this.dividendPartnerTypes);
    };
    AppDividendPartnersComponent.prototype.onRowSelect = function (event) {
        //console.log(event);
        if (!this.disableSave) {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;
            this.validationErrorMessage = '';
            this.newDividendPartnerType = false;
            this.dividendPartnersType = new DividendPartnerTypesValue();
            this.dividendPartnersType = this.cloneDividendPartner(event.data);
            this.selectedDividendPartnerType = this.dividendPartnersType;
            this.selectedDividendPartnerTypeName = this.selectedDividendPartnerType.Name;
            //console.log(this.dividendPartnersType);        
            if (this.dividendPartnersType.BusinessSegment != null) {
                this.selectedSegmentValue = this.dividendPartnersType.BusinessSegment.Name;
            }
            else {
                this.selectedSegmentValue = '';
            }
            this.displayDialog = true;
        }
    };
    AppDividendPartnersComponent.prototype.cloneDividendPartner = function (c) {
        var dividendPartner = new DividendPartnerTypesValue();
        for (var prop in c) {
            dividendPartner[prop] = c[prop];
        }
        return dividendPartner;
    };
    AppDividendPartnersComponent.prototype.findSelectedDividendPartnerIndex = function () {
        var DividendPartnerName = this.selectedDividendPartnerTypeName;
        var indexOut;
        var tempDivPartner;
        this.dividendPartnerTypes.forEach(function (item, index) {
            if (DividendPartnerName == item.Name) {
                tempDivPartner = item;
            }
        });
        //return this.dividendPartnerTypes.indexOf(this.selectedDividendPartnerType);
        //console.log(tempDivPartner);
        indexOut = this.dividendPartnerTypes.indexOf(tempDivPartner);
        //console.log(indexOut);
        return indexOut;
    };
    AppDividendPartnersComponent.prototype.findDividendPartnerIndexForDelete = function () {
        return this.dividendPartnerTypes.indexOf(this.currentDividendPartnerType);
    };
    AppDividendPartnersComponent.prototype.checkIfArrayIsUnique = function (myArray) {
        return myArray.length === new Set(myArray).size;
    };
    AppDividendPartnersComponent.prototype.refreshData = function (divPartnerTypeDataTable) {
        this.isRequesting = true;
        this.divPartnerTypeDataTable.reset();
        this.loadData();
    };
    AppDividendPartnersComponent.prototype.stopRefreshing = function () {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    };
    __decorate([
        core_1.ViewChild('divPartnerTypeDataTable'), 
        __metadata('design:type', primeng_1.DataTable)
    ], AppDividendPartnersComponent.prototype, "divPartnerTypeDataTable", void 0);
    AppDividendPartnersComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/DividendPartners/app.dividendPartners.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRDividendPartnersService_1.TPRDividendPartnersService, app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService, primeng_2.ConfirmationService, app_TPRCommonService_1.TPRCommonService, app_serviceHelper_1.ServiceHelper])
    ], AppDividendPartnersComponent);
    return AppDividendPartnersComponent;
}());
exports.AppDividendPartnersComponent = AppDividendPartnersComponent;
var DividendPartnerTypesValue = (function () {
    function DividendPartnerTypesValue($type, Name, IsInUse, BusinessSegment, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (BusinessSegment === void 0) { BusinessSegment = null; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.BusinessSegment = BusinessSegment;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return DividendPartnerTypesValue;
}());
var BusinessSegmentType = (function () {
    function BusinessSegmentType($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return BusinessSegmentType;
}());
//# sourceMappingURL=app.dividendPartners.component.js.map