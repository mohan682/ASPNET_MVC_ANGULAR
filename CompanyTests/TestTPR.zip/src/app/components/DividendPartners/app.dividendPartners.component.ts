﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { DataTable } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { TPRDividendPartnersService } from '../../service/app.TPRDividendPartnersService';
import { TPRBusinessSegmentsService } from '../../service/app.TPRBusinessSegmentsService';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { ServiceHelper } from '../../service/app.serviceHelper';
import { TPRCommonService } from '../../service/app.TPRCommonService';

import IDividendPartnerValue = DividendPartnerNameSpace.IDividendPartnerValue;
import IBusinessSegment = DividendPartnerNameSpace.IBusinessSegment;

@Component({
    selector: 'my-app',
    templateUrl: 'app/components/DividendPartners/app.dividendPartners.component.html'
})
export class AppDividendPartnersComponent implements OnInit {

    dividendPartnerTypes: IDividendPartnerValue[];
    businessSegments: IBusinessSegment[];
    newDividendPartnerType: boolean;
    displayDialog: boolean;
    dividendPartnersType: IDividendPartnerValue;
    cols: any[];
    selectedDividendPartnerTypeName: string = '';
    selectedDividendPartnerType: IDividendPartnerValue = new DividendPartnerTypesValue();
    currentDividendPartnerType: IDividendPartnerValue = new DividendPartnerTypesValue();
    segments: SelectItem[];
    selectedSegmentValue: string = '';
    msgs: Message[] = [];
    blnSavedOrDeleted: boolean = false;
    successMessage: boolean = false;
    failureMessage: boolean = false;
    Message: string = "";
    clsMessage = {};
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true;
    blnPushDataToDatabase = false;
    validationErrorMessage: string = "";
    strErrorMessage: string = "";
    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    isRequesting: boolean = false;;
    disableSave: boolean = false;
    canEdit: boolean = false;

    @ViewChild('divPartnerTypeDataTable') divPartnerTypeDataTable: DataTable;

    constructor(
        private tPRDividendPartnersService: TPRDividendPartnersService,
        private tPRBusinessSegmentsService: TPRBusinessSegmentsService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        this.loadData();

        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);
    }

    loadData() {
        this.isRequesting = true;
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.tPRDividendPartnersService.getDividendPartnersObservable()
            .subscribe(data => this.setDividendPartnerData(data));

        this.tPRBusinessSegmentsService.getBusinessSegmentsObservable()
            .subscribe(data => this.setBusinessSegmentsData(data));
    }

    private setDividendPartnerData(data: any): void {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;

        this.dividendPartnerTypes = this.dividendPartnerTypes.filter(divPartner => divPartner.Editable == true);

        this.dividendPartnerTypes.forEach(dividendPartner => {
            dividendPartner.Updated != null ? dividendPartner.Updated = this.tprCommonService.getFormattedSystemDate(new Date(dividendPartner.Updated)) : null;
        });

        this.stopRefreshing();
    }

    private setBusinessSegmentsData(data: any): void {
        this.businessSegments = [];
        this.businessSegments = data.Result.BusinessSegments.$values;

        this.segments = [];
        this.segments.push({ label: 'Select Segments', value: 'Select Segments' });
        let segmentData: string = ''

        for (var i = 0; i < this.businessSegments.length; i++) {
            let segment = this.businessSegments[i];
            segmentData = segment.Name;

            this.segments.push({ label: segmentData, value: segmentData });
        }
    }

    showDialogToAdd() {
        this.newDividendPartnerType = true;
        this.dividendPartnersType = new DividendPartnerTypesValue();
        this.displayDialog = true;
        this.selectedSegmentValue = '';
        this.validationErrorMessage = '';
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    }

    save() {
        //debugger;
        if (this.dividendPartnersType.Name == null || this.dividendPartnersType.Name.trim() == "") {
            //alert("Please provide valid data.");

            this.validationErrorMessage = "Please enter a valid 'Name'.";
            this.clsHighlightInvalidData = {};

            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };

            this.dividendPartnersType.Name = "";
            return false;
        }
        else {
            if (this.newDividendPartnerType) {
                if (this.selectedSegmentValue.trim() == "" || this.selectedSegmentValue.toUpperCase() == "SELECT SEGMENTS") {
                    //alert("Please select business segment.");

                    this.validationErrorMessage = "Please select a Business Segment.";
                    this.clsHighlightInvalidData = {};

                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };

                    this.selectedSegmentValue = '';
                    return false;
                }
                else {
                    this.dividendPartnersType.BusinessSegment = new BusinessSegmentType();
                    let businessSegmentType = new BusinessSegmentType();

                    let businessSegmentSelected: string = this.selectedSegmentValue;

                    this.businessSegments.forEach(function (item) {
                        let businessSegment: IBusinessSegment = new BusinessSegmentType();

                        businessSegment = item;

                        if (businessSegment.Name == businessSegmentSelected) {
                            businessSegmentType = businessSegment;
                        }
                    });

                    this.dividendPartnersType.BusinessSegment = businessSegmentType;
                }
                //console.log("new dividendPartnersType ->", this.dividendPartnersType);
                let index: number = this.dividendPartnerTypes.indexOf(this.dividendPartnerTypes.find(divPartner => divPartner.Name.toLowerCase().trim() == this.dividendPartnersType.Name.toLowerCase().trim()));
                if (index == -1) {
                    this.dividendPartnerTypes.push(this.dividendPartnersType);
                }
                else {
                    this.validationErrorMessage = "Dividend Partner Name should be unique."
                    this.clsHighlightInvalidData = {};

                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };
                    return false;
                }
                //this.dividendPartnerTypes.push(this.dividendPartnersType);
                //console.log(this.dividendPartnersType);
            }
            else {
                if (this.selectedSegmentValue.trim() == "" || this.selectedSegmentValue.toUpperCase() == "SELECT SEGMENTS") {
                    //alert("Please select business segment.");

                    this.validationErrorMessage = "Please select a Business Segment.";
                    this.clsHighlightInvalidData = {};

                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };

                    this.selectedSegmentValue = '';
                    return false;
                }
                else {
                    this.dividendPartnersType.BusinessSegment = new BusinessSegmentType();
                    let businessSegmentType = new BusinessSegmentType();

                    let businessSegmentSelected: string = this.selectedSegmentValue;

                    this.businessSegments.forEach(function (item) {
                        let businessSegment: IBusinessSegment = new BusinessSegmentType();

                        businessSegment = item;

                        if (businessSegment.Name == businessSegmentSelected) {
                            businessSegmentType = businessSegment;
                        }
                    });

                    this.dividendPartnersType.BusinessSegment = businessSegmentType;

                    this.dividendPartnerTypes[this.findSelectedDividendPartnerIndex()] = this.dividendPartnersType;
                }
            }
        }
        this.dividendPartnersType = null;
        this.displayDialog = false;
    }

    Cancel(){
        this.displayDialog = false;        
    }

    saveDataToServer() {
        let action: string = "save";
        this.blnPushDataToDatabase = true;

        let divPartnersArray: string[] = [];
        this.dividendPartnerTypes.forEach(divPartner => divPartnersArray.push(divPartner.Name.toLowerCase().trim()));

        let uniquenessResult: boolean = this.checkIfArrayIsUnique(divPartnersArray);

        if (uniquenessResult) {
            this.SaveDataToDataBase(action);
        }
        else {
            this.blnShowPopUp = true;
            this.Status = "Validation error!";
            this.ValidationMessage = "Dividend Partner Name should be unique.";
        }

        //this.SaveDataToDataBase(action);
    }

    delete(event: IDividendPartnerValue) {
        this.currentDividendPartnerType = event;
        //console.log(this.currentDividendPartnerType);
        //alert(this.currentDividendPartnerType.Name + "," + this.currentDividendPartnerType.Segment);
        //this.dividendPartnerTypes.splice(this.findDividendPartnerIndexForDelete(), 1);

        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Dividend Partner?',
            accept: () => {
                this.dividendPartnerTypes.splice(this.findDividendPartnerIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });

        this.dividendPartnersType = null;
        this.displayDialog = false;
    }

    SaveDataToDataBase(action: string) {
        this.isRequesting = true;
        this.tPRDividendPartnersService.updateDividendPartnersObservable(this.dividendPartnerTypes)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                    this.stopRefreshing();
                }
                else {
                    //this.ShowMessageOnSaveorDeleteData(response, action);
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    console.log("Action ->", action);
                    if (action == "save") {
                        this.ValidationMessage = "Dividend Partner Data is saved successfully";
                    }
                    else if (action == "delete") {
                        this.ValidationMessage = "The Selected Dividend Partner is deleted successfully";
                    }
                    this.loadData();
                    this.blnSavedOrDeleted = true;
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
                this.stopRefreshing();
            });
        //console.log(this.dividendPartnerTypes);
    }

    onRowSelect(event: any) {
        //console.log(event);
        if (!this.disableSave) {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;
            this.validationErrorMessage = '';
            this.newDividendPartnerType = false;
            this.dividendPartnersType = new DividendPartnerTypesValue();
            this.dividendPartnersType = this.cloneDividendPartner(event.data);
            this.selectedDividendPartnerType = this.dividendPartnersType;
            this.selectedDividendPartnerTypeName = this.selectedDividendPartnerType.Name;
            //console.log(this.dividendPartnersType);        

            if (this.dividendPartnersType.BusinessSegment != null) {
                this.selectedSegmentValue = this.dividendPartnersType.BusinessSegment.Name;
                //console.log(this.dividendPartnersType.BusinessSegment.Name);
                //this.selectedSegmentValue = '';
            }
            else {
                this.selectedSegmentValue = ''
            }

            this.displayDialog = true;
        }
    }

    cloneDividendPartner(c: IDividendPartnerValue): IDividendPartnerValue {
        let dividendPartner = new DividendPartnerTypesValue();
        for (let prop in c) {
            dividendPartner[prop] = c[prop];
        }
        return dividendPartner;
    }

    findSelectedDividendPartnerIndex(): number {
        let DividendPartnerName: string = this.selectedDividendPartnerTypeName;
        let indexOut: number;
        let tempDivPartner: any;
        this.dividendPartnerTypes.forEach(function (item, index) {
            if (DividendPartnerName == item.Name) {
                tempDivPartner = item;
            }
        });

        //return this.dividendPartnerTypes.indexOf(this.selectedDividendPartnerType);
        //console.log(tempDivPartner);
        indexOut = this.dividendPartnerTypes.indexOf(tempDivPartner);
        //console.log(indexOut);
        return indexOut;
    }

    findDividendPartnerIndexForDelete(): number {
        return this.dividendPartnerTypes.indexOf(this.currentDividendPartnerType);
    }

    checkIfArrayIsUnique(myArray: string[]): boolean {
        return myArray.length === new Set(myArray).size;
    }

    refreshData(divPartnerTypeDataTable: DataTable) {
        this.isRequesting = true;
        this.divPartnerTypeDataTable.reset();
        this.loadData();
    }

    private stopRefreshing() {
        console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }
}

class DividendPartnerTypesValue implements IDividendPartnerValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public BusinessSegment: IBusinessSegment = null,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class BusinessSegmentType implements IBusinessSegment {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}