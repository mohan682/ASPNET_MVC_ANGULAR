﻿using System;
using System.Collections.Generic;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessCore.Modelling;

namespace Dcorum.BusinessLayer.Bundles
{
    public static class BundledContactHistory
    {
        /// <summary>
        /// 1
        /// </summary>
        public const string ContactHistoryCallAutoUpdate = "1";
        
        /// <summary>
        /// 6
        /// </summary>
        public const string ContactHistoryCallTargetPlanUpdate = "6";

        public const string ContactHistoryActionWebUserManagement = "44";
        public const string ContactHistoryActionMessageCentre = "40";
        public const string ContactHistoryActionBankDetail = "3";

        public sealed class BLContactHistory
        {
            private readonly ContactHistory _husk = new ContactHistory();
            private readonly string _defaultActionType;

            /// <summary>
            /// Note: non-zero nameId value takes precedence over any subsequently supplied case_mbr_key.
            /// </summary>
            public BLContactHistory(int userId, int? nameId, string defaultActionType, string callType = ContactHistoryCallAutoUpdate)
            {
                _husk.UserId = userId;
                _husk.CallType = callType;

                if (nameId.HasValue) _husk.NameId = nameId.Value;

                _defaultActionType = defaultActionType;
            }


            public bool Save(int caseMbrKey, string description, string actionType = null, IRemarksContainer remarks = null)
            {
                if (caseMbrKey > 0)
                {
                    _husk.CaseMbrKey = caseMbrKey;
                }

                _husk.ActionType = actionType ?? _defaultActionType;

                //handle optional timestamp suffix...
                if (!description.Contains("{0}"))
                {
                    _husk.Description = description;
                }
                else
                {
                    string textualTimestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                    string desc = String.Format(description, textualTimestamp);
                    _husk.Description = desc;
                }

                bool success = DLContactHistory.Insert(_husk) > 0;

                if (!success && remarks != null)
                {
                    remarks.AddCode(Constants.ValidationErrorCodes.DBOperationContactHistoryFailure);
                }

                return success;
            }
        }


        private static class DLContactHistory
        {
            public static int Insert(ContactHistory contactHistory)
            {
                string sql1 = SqlActor.YieldInsertionSql(contactHistory).IntoWellFormedSql();
                return DataAccessHelp.SimpleExecuteNonQuery(sql1);
            }
        }


        private class SqlActor
        {
            public static IEnumerable<string> YieldInsertionSql(ContactHistory model)
            {
                string sql1 = @"
INSERT INTO 
    CONTACT_HISTORY
    (HISTORY_ID, SESSION_ID, USER_ID, NAMEID, CASE_MBR_KEY, CASE_KEY, DATE_TIME, CALL_TYPE_CD, ACTION_TYPE_CD, DESCRIPTION)
";

                string sql2a =@"
    select
        CONTACT_HISTORY_SEQ.nextval, 0, {0}, v.NAMEID, {2}, v.CASE_KEY, sysdate, {3}, {4}, {5}
    from
        vemployees v 
    where
        v.case_mbr_key = {2}
";

                string sql2b = @"
VALUES
    (CONTACT_HISTORY_SEQ.nextval, 0, {0}, {1}, null, null, sysdate, {3}, {4}, {5})
";

                string fullTemplate1 =sql1 + ((model.NameId > 0) ? sql2b : sql2a);
                string result = String.Format(
                    fullTemplate1,
                    model.UserId, 
                    model.NameId, 
                    model.CaseMbrKey.IntoSqlValue(),
                    model.CallType.SqlQuotify(),
                    model.ActionType.SqlQuotify(),
                    model.Description.SqlQuotify()
                    );

                yield return result;
            }

        }
    }
}
