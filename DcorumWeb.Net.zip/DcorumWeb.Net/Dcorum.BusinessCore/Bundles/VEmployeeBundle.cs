﻿using System;
using System.Collections.Generic;
using Dcorum.Utilities.DataAccess;
using Dcorum.BusinessCore.Modelling;
using System.Linq;

namespace Dcorum.BusinessLayer.Bundles
{
    public static class BundledEmployee
    {

        public sealed class BLEmployee
        {

            /// <summary>
            /// [CONSTRUCTOR]
            /// </summary>
            internal BLEmployee(DataAccess dataAccess)
            {
                DataAccess1 = dataAccess;
            }

            private readonly DataAccess DataAccess1;


            public VEmployee[] GetMany(int[] caseMemberKeys)
            {
                if (caseMemberKeys?.Any() != true) return Enumerable.Empty<VEmployee>().ToArray();
                var results = DataAccess1.GetMany(caseMemberKeys);
                return results;
            }
        }


        public class DataAccess
        {
            internal DataAccess(SqlMaker sqlMaker)
            {
                SqlMaker1 = sqlMaker;
            }

            private readonly SqlMaker SqlMaker1;

            public VEmployee[] GetMany(int[] caseMemberKeys)
            {
                string sql1 = SqlMaker1.SelectMany(caseMemberKeys).IntoWellFormedSql();
                return DataAccessHelp.GetMany<VEmployee>(sql1, @reader => new VEmployee(@reader));
            }
        }



        public class SqlMaker
        {
            internal SqlMaker()
            {
            }

            public IEnumerable<string> SelectMany(int[] caseMemberKeys)
            {
                string sql1 = @"
Select * 
from vemployees
where {0}
";
                string result = string.Format(sql1, caseMemberKeys.IntoSqlInClause("case_mbr_key") );

                yield return result;
            }

        }
    }
}
