﻿using Dcorum.BusinessCore.Modelling;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Dcorum.BusinessCore.Bundles
{
    public static class ProductBundle
    {
        public class Controller
        {
            internal Controller(DataAccess dataAccess, Func<Product,Product> conversionTechnique)
            {
                DataAccess1 = dataAccess ;
            }


            private DataAccess DataAccess1 {get;}
            private Func<Product, Product> ConversionTechnique1 { get; }

            public IEnumerable<Product> GetProducts()
            {
                return DataAccess1.GetAll().Select( @dataModel => ConversionTechnique1?.Invoke(@dataModel) ?? dataModel ) ;
            }

        }


        public class DataAccess
        {
            internal DataAccess(SqlMaker sqlMaker, IDbFetcherProxy dbProxy, Func<IDataReader,Product> creationTechnique)
            {
                SqlMaker1 = sqlMaker;
                DbProxy1 = dbProxy;
                CreationTechnique1 = creationTechnique;
            }
        

            private SqlMaker SqlMaker1 { get; }
            private IDbFetcherProxy DbProxy1 { get; }
            private Func<IDataReader, Product> CreationTechnique1 { get; }

            public Product[] GetAll()
            {
                var sql1 = SqlMaker1.SelectAllSql();
                var results = DbProxy1.GetMany(sql1, @CreationTechnique1);
                return results;
            }

        }

        public class SqlMaker
        {
            internal SqlMaker()
            {

            }

            public string SelectAllSql()
            {
                return @"select P.PROD_TYP_CD, P.PROD_DESC from Compass.products P";
            }
        }
    }
}
