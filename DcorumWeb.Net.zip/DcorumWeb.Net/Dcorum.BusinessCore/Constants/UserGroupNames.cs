﻿namespace Dcorum.BusinessLayer.Constants
{
    public static class UserGroupNames
    {
        //These groups are deleted from here as its not been referenced/used in application may be need to be addded when its required.
        //  public const string ContentAdmin = "Content admin";
        //  public const string ContentApprover = "Content approver";
        public const string TargetPlanUserDeregistration = "DeregisterTargetPlanUser";
        public const string ContentCreator = "ContentCreator";
        public const string ContentApprover = "ContentApprover";
        public const string Security = "Security";

        public const string SchemeSummaryEdit = "Scheme summary edit";

        ////Fund Removal Groups
        //public const string Administrators = "Administrators";
        //public const string Internal_Users = "Internal users";
        //public const string Investment_Only = "Investment Only";
        //public const string Internal_Users_With_Staff_Scheme = "Internal users with staff scheme access";
    }
}
