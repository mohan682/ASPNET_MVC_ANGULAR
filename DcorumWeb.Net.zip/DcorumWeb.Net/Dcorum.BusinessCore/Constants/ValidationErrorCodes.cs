﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Constants
{
    public static class ValidationErrorCodes
    {
        public const string DBOperationRecordAlreadyExists = "6000";
        public const string DBOperationTamperedData = "6001";
        public const string DBOperationInternalError = "6002";
        public const string DBOperationAuditFailure = "6003";
        public const string DBOperationContactHistoryFailure = "6004";

        public const string InvalidPDIMessageSelected = "6005";
        public const string RangeNotProvidedForBetweenValidation = "6006";
        public const string ValueNotProvidedForValidation = "6007";

        public const string BothSchemeAndMbrGroupEmpty = "6008";
        public const string InvalidSchemeSelected = "6009";
        public const string InvalidMemberGroupSelected = "6010";
        public const string ExpiryDtGreaterThanEffectiveDt = "6011";

        public const string FundMixTotalPercentageError = "6012";

        public const string MbrGrpBenefitFieldsNotAllowed = "6013";
        public const string MbrGrpSwitchRuleFieldsNotAllowed = "6014";
        public const string MbrGrpAVCContribBasisbNotAllowed = "6015";

        [Description("User is a already registered!")]
        public const string TPUserRegUserAlreadyRegistered = "6016";
        public const string TPUserRegNoEmailAddressAvailable = "6017";
    }
}
