﻿using System.ComponentModel;

namespace Dcorum.Configuration.Contractual
{
    /// <summary>
    /// groups
    /// </summary>
    public static class GroupId
    {
        ///<summary>1</summary>
        [Description("Allows maintenance and creation of new security groups, this one needs a full review as it looks odd looking at each of the resources in it.")]
        public const string AdministrGroupId = "Administrators";

        ///<summary>4</summary>
        [Description("Group given to all dcorum/sps users to give access to the standard functions")]
        public const string InternalUsrGroupId = "Internal users";

        ///<summary>35</summary>
        [Description("Allows users access to the security screens within dcorum which are used to set up/amend users and link them to security groups")]
        public const string SecurityGroupId = "Security";

        ///<summary>55</summary>
        [Description("Allows users access to the fund maintenance and money type grouping screens")]
        public const string SystemMaintGroupId = "System maintenance";

        ///<summary>96</summary>
        [Description("Investment Only Finance Users")]
        public const string InvestmentOnly = "Investment Only";

        ///<summary>1219</summary>
        [Description("Allows users to edit details in the scheme summary screen")]
        public const string SchmSmryEditGroupId = "Scheme summary edit";

        ///<summary>210887</summary>
        [Description("Group given to all dcorum/sps users to give access to the standard functionsgroup for dcorum users who are allowed access to the blackrock staff pension scheme")]
        public const string IntlUsrStffGroupId = "Internal users with staff scheme access";

        ///<summary>210067</summary>
        [Description("Allows users to access the new screens within dcorum that allow auto enrolment settings to be configured")]
        public const string AeAdmin = "Ae admin";

        ///<summary>216931</summary>
        [Description("Gives access to the content screen")]
        public const string ContentAdmin = "ContentAdmin";

        ///<summary>218169</summary>
        [Description("Group to manage service-task_queue items")]
        public const string TaskQueueEditing = "ServiceTaskQueueEditing";

        ///<summary>218170</summary>
        [Description("Group to view service-task_queue items")]
        public const string TaskQueueViewing = "ServiceTaskQueueViewing";

        [Description("Group to edit Retirement Benefits Edit")]
        public const string RetirementBenefitsEdit = "Retirement Benefits Edit";

        ///<summary>219891</summary>
        [Description("Group to manage Freeze Configurations")]
        public const string FreezeConfigurationEdit = "FreezeConfigurationEdit";

        ///<summary>219892</summary>
        [Description("Group to view Freeze Configurations")]
        public const string FreezeConfigurationView = "FreezeConfigurationView";

        ///<summary>219893</summary>
        [Description("Group to configure transfer details")]
        public const string TVDetailsEditUsers = "TVDetailsEditUsers";

        /////<summary>?</summary>
        //[Description("Group to manage event-trigger-suppression items")]
        //public const string TriggerSuppressionEditing = "TriggerSuppressionEditing";

        /////<summary>?</summary>
        //[Description("Group to view event-trigger-suppression items")]
        //public const string TriggerSuppressionViewing = "TriggerSuppressionViewing";

        ///<summary>218169</summary>
        [Description("Group to manage IO Clients")]
        public const string IOClientEdit = "IO Client Edit";

        ///<summary>218170</summary>
        [Description("Group to view IO Clients")]
        public const string IOClientView = "IO Client View";


        ///<summary>???</summary>
        [Description("Users allowed to edit Letter of Authority data.")]
        public const string LoaEdit = "LOA Edit";

    }
}
