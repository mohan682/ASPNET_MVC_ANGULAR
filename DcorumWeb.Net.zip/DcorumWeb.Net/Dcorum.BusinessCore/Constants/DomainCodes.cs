﻿using System.ComponentModel;
using Dcorum.BusinessLayer.Contractual;
using DCorum.BusinessFoundation.Auditing.Constants;

namespace Dcorum.BusinessLayer.Constants
{
    /// <summary>
    /// Controller Categories
    /// </summary>
    [RefCodeConstraint(AuditingDomainNames.SWApplicationComponent)]
    public static class DomainCodes
    {  
        public const string DCorumComponentPDIMessage = "PM";
        public const string DCorumComponentContStruct = "ST";
        public const string DCorumComponentContScale = "SC";
        public const string DCorumComponentScheme = "SH";
        public const string DCorumComponentMaintenanceMessage = "MM";
        public const string DcorumComponentMemberGroup = "MG";
        public const string DcorumComponentUFundMix = "FM";
        public const string DcorumComponentValidationRule = "VR";
        public const string DcorumComponentContent = "CT";
        public const string DcorumComponentAssetClassGrowthRate= "AR";
        public const string DcorumComponentImpersonate = "IM";
        public const string DcorumComponentGuestLogin = "GU";
        //public const string DcorumComponentPDIRole = "PR";
        //public const string DcorumComponentPDISchemeRole = "SR";
        //public const string DcorumComponentPDIMemberGroupRole = "MR";      
        public const string DcorumComponentSSOConfig = "SS";
        public const string DcorumComponentMoneyType = "MT";
        public const string DcorumComponentDemoParam = "DP";

        [Description("Fund Class")]
        public const string DcorumComponentFundClass = "FC";

        public const string DCorumComponentLifePath = "LP";

        [Description("Dcorum AE NiNo Screen")]     
        public const string DcorumComponentNino = "NI";

        public const string DcorumComponentOCPOptions = "OO";
        public const string DcorumComponentBillingGroup = "BG";

        [Description("Admin User")]
        public const string DCorumComponentAdminUser = "AU";

        [Description("Role Group")]
        public const string DCorumComponentRoleGroup = "RG";

        [Description("User Role")]
        public const string DCorumComponentUserAccountRole = "UR";

        [Description("Scheme Contact")]
        public const string DCorumComponentMiscSchemeContact = "MC";

        [Description("Direct Reports")]
        public const string DCorumComponentDirectReport = "DR";


        [Description("AE Settings")]
        public const string DCorumComponentAeSettings = "A0";

        [Description("AE Contribution Tiers")]
        public const string DCorumComponentAeContribTier = "A1";

        [Description("AE Earnings")]
        public const string DCorumComponentAeEarnings = "A2";

        [Description("AE Employer Overrides")]
        public const string DCorumComponentAeEmployerOverride = "A3";

        [Description("AE Milestones")]
        public const string DCorumComponentAeMilestone = "A4";

        [Description("Phase Periods")]
        public const string DCorumComponentPhasePeriod = "A5";

        [Description("Scheme Contribution Tiers")]
        public const string DCorumComponentAeSchemeContribTier = "A6";

        [Description("AE Tax Years")]
        public const string DCorumComponentAeTaxYear = "A7";

        [Description("AE Assessment")]
        public const string DCorumComponentAeAssessment = "A9";

        [Description("AE Cyclical History")]
        public const string DCorumComponentAeCyclicalHistory = "A8";


        [Description("AE Cyclical History")]
        public const string DCorumComponentUnexpected = "ZZ";

        [Description("Service Task Queue")]
        public const string DCorumServiceTaskQueue = "SQ";

        [Description("Event Trigger Suppression")]
        public const string DCorumEventTriggerSuppression = "TS";

        [Description("Transfer Flags")]
        public const string DCorumTransferFlag = "TF";

        [Description("Retirement Benefits")]
        public const string DCorumRetirementBenefits = "RB";

        [Description("Freeze Event")]
        public const string DCorumFreezeEvent = "FE";

        [Description("Retirement Risk Warning Questions")]
        public const string DCorumRrwq = "WQ";

        [Description("Retirement Risk Warning Question Headers")]
        public const string DCorumRrwqh = "QH";

        [Description("IO Client Maintenance")]
        public const string DCorumIoclient = "IO";

        [Description("Letter of Authority")]
        public const string DCorumLetterOfAuthority = "LA";
    }

}
