﻿namespace Dcorum.BusinessLayer.Constants
{
    public static class DomainNames
    {
        public const string PDIUserMessageLevels = "PDI_USR_MSG_LEVELS";
        public const string PDIContribStructVariationCodes = "PDI_CONT_STRUCT_VAR_CODES";
        public const string PDITargetPlanAccessLevels = "PDI_TARGETPLAN_ACCESS_LEVELS";
        //public const string UserMessageCategory = "MSG CATEGORY CD";
        //public const string UserMessagePriority = "MSG PRIORITY CD";
        //public const string UserMessageType = "MSG TYPE CD";
        public const string PDI_Maintenance_Message_Type = "PDI_MAINTENANCE_MESSAGE_TYPE";
        public const string PDI_Maintenance_Message_Permission = "PDI_MAINTENANCE_MESSAGE_PERM";
        public const string PDI_Content_Type = "PDI_CONTENT_TYPES";
        public const string PDI_Content_Component = "PDI_CONTENT_COMPONENTS";
        public const string UEXT_Provider_Code = "UEXT PROV CD";
        public const string PDI_Lookup_types = "PDI_LOOKUP_TYPES";
        //public const string DataAuditIdentifierTypes = "DATA_AUDIT_IDENTIFIER_TYPES";
        //public const string PDIScreenOperations = "PDI_SCREEN_OPRN_TYPES";
        //public const string ESSCApplicationNames = "ESSC_APP_NAMES";
        //public const string SWApplicationComponent = "SW_APP_COMPONENTS";
        public const string Member_Group_Type = "MBGP GRP TYP CD";
        public const string PDIActiveDeferredMbrs = "PDI_ACT_DEF_IND";
        public const string PDIContribBasis = "UEXT CASE CONT";
        public const string PDIContribBasisAVC = "UEXT AVC CASE CONT";
        public const string PDIContribFrequency = "UEXT CASE CONT FREQ";
        public const string PDIIllustrationIncType = "UEXT CAP INC TYPE";
        public const string CompassYesNoValues = "ZZYESNO NUM";
        //public const string YouPopulateMore = "VALUE TO ENTER AS SAME AS IN DB";
        public const string UEXT_Product_Code = "UEXT_PRODUCT_CD";
        public const string UEXT_PlanType = "PLAN TYPE CODE";
        public const string RedirectFrequency = "REDIRECT_FREQUENCY";
        public const string PDIVariationCodes = "PDI_CONT_STRUCT_VAR_CODES";
        public const string BankValidationComments = "BANK_VALIDATION_COMMENT";

        public const string Gender = "PERNSEXCD";
        public const string PersonTitle = "PERS NAMEPREFIX";
        public const string UEXT_ActiveFundClass = "UEXT ACTIVE FUND CLASS";
        public const string UEXT_FundChargeMetBy = "UEXT FUND CHARGE MET BY";

        public const string DatesInMonth = "DATES IN MONTH";

        public const string AssetClass = "FND UNDRLY ASSET CLS";

        public const string AeFrequency = "BGRP PYRL FREQ CD";
        public const string AeWorkeTypes = "UEXT_AE_WORKER_TYPES";
        public const string AeRecommendationStatus = "UEXT AE STATUS CD RECOMDTNS";
        public const string AeSalaryFrequency = "ZZFREQUENCY";

        public const string MemberStatuses = "MBR PART STAT CD";

        public const string FundChangeAmtTypes = "FUND_CHANGE_AMOUNT_TYPE";

        public const string NotionalFundGlidepaths = "LP_NOTIONAL_FUND_GLIDES";

        public const string LifePathConfigpaths = "LIFEPATH_TYPE";


        public const string FundNumbers = "TMAP MKEY FD NUM";

        public const string LifepathPhase = "LP_PHASE";
        public const string LifepathType = "LIFEPATH_TYPE";
        public const string LifepathNotionalFundType= "LP_NOTIONAL_FUND_TYPE";
        public const string IoPortalMicrosites = "IO_PORTAL_MICROSITES";

        public const string IoPortalSettings = "PDI_PORTAL_CONTENT" ;

        public const string LetterAuthorites = "LOA_TYPE";
    }

    /// <summary>
    /// Includes disabled definitions
    /// </summary>
    public static class SpecialDomainNames
    {
        public const string DemoParamKeys = "TARGETPLAN_DEMO_PARAM_NAME";
        public const string TransferFlagKeys = "UEXT_TRANS_DTL_FLAGS";
    }
}
