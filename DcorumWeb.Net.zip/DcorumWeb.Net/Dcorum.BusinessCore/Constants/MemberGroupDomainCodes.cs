﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Constants
{
    public static class MemberGroupDomainCodes
    {
        public const string BenefitMemberGroupType = "12";
        public const string InvestmentMemberGroupType = "15";

        public const string AVCContribBasisNone = "1";
        public const string ContribFrequencyMonthly = "4";
        public const string IncreaseTypeValueNAE = "1";
        public const string IncreaseTypeValueOTHER = "3";

        public const string MoneyPurchaseSchemeProductGroup = "34";

        public const string InvestmentAvailableToDefer = "DF";
    }
}
