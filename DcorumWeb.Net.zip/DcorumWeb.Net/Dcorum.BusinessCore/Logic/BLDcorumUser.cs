﻿using System;
using System.Diagnostics;
using System.Linq;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessCore.Creational;

namespace Dcorum.BusinessLayer.Logic
{
    public class BLDcorumUser
    {
        public static BLDcorumUser Singleton = new BLDcorumUser( BusinessCoreFactoryMethods.CreateDcorumUserSearcher() );

        private BLDcorumUser(DLDcorumUser dataAccess)
        {
            _dataRetriever = dataAccess;
        }


        private readonly DLDcorumUser _dataRetriever ;


        public DcorumUser GetUserById(int userId)
        {
            var result = _dataRetriever.GetUserById(userId);

            if (result != null)
            {
                var editor1 = new DcorumUser.Editor(result);
                editor1.SetGroupNames(@GetGroupIdsForUser);
            }

            return result ??  new DcorumUser(userId);
        }


        private string[] GetGroupIdsForUser(int filterByUserId)
        {
            Tuple<int, string>[] userGroups = _dataRetriever.GetInternalUsersAndTheirGroups(filterByUserId);

            Debug.Assert(userGroups.Any( _ => _.Item1 != filterByUserId)==false, "Other user group data has been fetched from the DB!");

            var results = userGroups.Where(p => p.Item1 == filterByUserId).Select( _ => _.Item2).ToArray();
            return results;
        }


        //private static IDictionary<int, string[]> GetUsersAndTheirGroups(int? filterByUserId = null)
        //{
        //    Tuple<int, string>[] userGroups = _dataRetriever.GetInternalUsersAndTheirGroups(filterByUserId);

        //    var grouped1 = userGroups.GroupBy(_ => _.Item1, _ => _.Item2);
        //    var keyedCollections1 = grouped1.IntoDictionaryUngrouped();

        //    return keyedCollections1;
        //}
    }
}
