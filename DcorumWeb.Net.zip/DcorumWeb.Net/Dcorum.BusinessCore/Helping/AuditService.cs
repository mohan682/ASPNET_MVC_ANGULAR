﻿using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Dcorum.BusinessLayer.BusinesObjects
{
    public class AuditService : IAuditService
    {
        public List<PDIMessage> Audit<T>(bool success, string category, T current1, T existing1,
            int? userId = null, Func<object, Tuple<RefCode, string>> howToGetAuditIdentity = null)
            where T : class
        {
            int finalUserId = userId ?? ((current1 ?? existing1) as IAuditingArgumentsReadOnly).SafeFuncN(_ => _.UserId) ?? -1;

            RemarksVessel remarkVessel = new RemarksVessel();

            var auditor = BusinessCoreFactoryMethods.CreateAuditor(category, finalUserId, remarkVessel, 1, @howToGetAuditIdentity);

            auditor.AuditChanges(success, current1, existing1, null);

            return remarkVessel.PullAllMessages<PDIMessage>().ToList();
        }
    }
}
