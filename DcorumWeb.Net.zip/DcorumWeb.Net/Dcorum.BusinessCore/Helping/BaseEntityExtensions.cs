﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Auditing.Constants;

namespace Dcorum.BusinessLayer.Logic.Helping
{
    public static class BaseEntityExtensions
    {
        /// <summary>
        /// [SETUP]
        /// </summary>
        public static IEnumerable<Type> SpecialAuditTypes = null;

        /// <summary>
        /// Will always copy over UserId and conditionally case and member keys if the existing value are null.
        /// [CODESMELL] modifying extension methed!!! Justification: These properties should be in the BL agents instead but those class are currently STATIC.
        /// </summary>
        public static T CopyBaseEntityValuesFrom<T>(this T existingModel, IAuditingArgumentsReadOnly model)
            where T : class, IAuditingArguments
        {
            if (existingModel != null)
            {
                existingModel.UserId = model.UserId;
                existingModel.MbGpKey = existingModel.MbGpKey ?? model.MbGpKey;
                existingModel.CaseKey = existingModel.CaseKey ?? model.CaseKey;

                Contract.Assert(existingModel.MbGpKey == model.MbGpKey);
                Contract.Assert(existingModel.CaseKey == model.CaseKey);
            }

            return existingModel;
        }

        [Obsolete("Use CopyBaseEntityValuesFrom instead!")]
        public static T PreventMissingAuditArguments<T>(this T existingModel, IAuditingArgumentsReadOnly model)
            where T : class, IAuditingArguments
        {
            if (existingModel == null) return null;

            existingModel.MbGpKey = existingModel.MbGpKey ?? model.MbGpKey;
            existingModel.CaseKey = existingModel.CaseKey ?? model.CaseKey;

            Contract.Assert(existingModel.MbGpKey == model.MbGpKey);
            Contract.Assert(existingModel.CaseKey == model.CaseKey);

            return existingModel;
        }


        /// <summary>
        /// Audit model help for non-primary key auditing. (i.e. membergroup or casekey)
        /// </summary>
        public static Tuple<RefCode, string> GetAuditFriendlyIdentity(this object preCastSource, Func<string> howToGetPrimaryId = null)
        {
            if (preCastSource == null) return null;

            var source = preCastSource as IAuditingArgumentsReadOnly;

            bool simpleAuditMode = source == null || (SpecialAuditTypes ?? Enumerable.Empty<Type>()).Contains(source.GetType());

            howToGetPrimaryId = howToGetPrimaryId ?? (() => MetaDataHelper.GetTextualIdentity(preCastSource));

            if (simpleAuditMode)
            {
                return GetAuditFriendlyIdentity(null, null, @howToGetPrimaryId);
            }
            else
            {
                return GetAuditFriendlyIdentity(source.MbGpKey, source.CaseKey, @howToGetPrimaryId);
            }

        }

        /// <summary>
        /// Audit model help for non-primary key auditing. (i.e. membergroup or casekey)
        /// </summary>
        public static Tuple<RefCode, string> GetAuditFriendlyIdentity(int? mbGpKey, int? caseKey, Func<string> howToGetPrimaryId)
        {
            if (mbGpKey > 0)
            {
                return Tuple.Create(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeMbrGrp),
                    mbGpKey.ToString());
            }
            else if (caseKey > 0)
            {
                return Tuple.Create(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeScheme),
                    caseKey.ToString());
            }
            else
            {
                string id1 = howToGetPrimaryId();

                Debug.Assert(!String.IsNullOrWhiteSpace(id1),
                    "Attempted to audit an entity that doesn't have a primary key!");

                return Tuple.Create((RefCode) null, id1);
            }
        }
    }
}
