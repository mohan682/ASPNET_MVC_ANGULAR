﻿using System;
using System.Collections.Generic;

namespace Dcorum.BusinessCore.Helping
{
    /// <summary>
    /// [INJECTION] ensure you have defined behaviour during configuration.
    /// </summary>
    public static class CoreInjectedMechanics
    {
        //note: Would be internal if config was handled in the correct project!!!

        /// <summary>
        /// WARNING! Set only once as part of configuration. Do no use in normal code!!!
        /// </summary>
        public static Func<string,int?> caseKeyExtractionTechnique = _ => { throw new NotImplementedException();};

        //note: Would be internal if config was handled in the correct project!!!
        /// <summary>
        /// WARNING! Set only once as part of configuration. Do no use in normal code!!!
        /// </summary>
        public static Func<int?,string> caseKeyDisplaynameTechnique = _ => { throw new NotImplementedException(); };

        public static Func<int?,string, KeyValuePair<int,string>?> ioClientExtractTechnique = (id,reference) => { throw new NotImplementedException(); };        

        //static InjectedMechanics() {}

        /// <summary>
        /// Warning! Will throw 'NotImplementedException' unless behaviour has been injected as part of configuration!
        /// </summary>
        public static int? ConvertSchemeDisplayNameToCaseKey(string toExamine)
        {
            return caseKeyExtractionTechnique(toExamine);
        }

        /// <summary>
        /// Warning! Will throw 'NotImplementedException' unless behaviour has been injected as part of configuration!
        /// </summary>
        public static string IntoSchemeDisplayName(int? caseKey)
        {
            return caseKeyDisplaynameTechnique(caseKey);
        }

        /// <summary>
        /// Warning! Will throw 'NotImplementedException' unless behaviour has been injected as part of configuration!
        /// </summary>
        public static int? ConvertIOClientReferenceToIOClientId(string toExamine)
        {
            var result = ioClientExtractTechnique(null, toExamine);
            if (result.HasValue) return result.Value.Key;

            return null;
        }

        /// <summary>
        /// Warning! Will throw 'NotImplementedException' unless behaviour has been injected as part of configuration!
        /// </summary>
        public static string IntoIOClientDisplayText(int? ioClientId)
        {
            var result = ioClientExtractTechnique(ioClientId, null);
            if (result.HasValue) return result.Value.Value;

            return null;
        }
    }
}
