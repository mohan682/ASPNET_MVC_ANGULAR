﻿using DCorum.BusinessFoundation.Contractual;

namespace Dcorum.BusinessLayer.Contractual
{
    public interface ICrudOut<out TModel>
    : ICrudOut<TModel, int>
    {
    }

    public interface ICrudFull<TModel>
    : ICrudFull<TModel, int>
    {
    }
}
