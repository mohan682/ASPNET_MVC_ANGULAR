﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Contractual
{
    public interface IAuditingTarnisher
    {
        AuditingMode TarnishMode { get; }
        Action<IAuditingArguments> HowToTarnish { set; }
    }
}
