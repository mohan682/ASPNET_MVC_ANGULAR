﻿namespace Dcorum.BusinessLayer.Contractual
{
    public interface IAuditingArgumentsReadOnly2 : IAuditingArgumentsReadOnly
    {
        /// <summary>
        /// when temporary storage of a model is necessary this flag helps determine whether to put or get that model.
        /// </summary>
        bool IsNewEncounter { get; }
    }


        public interface IAuditingArgumentsReadOnly
    {
        int UserId { get; }
        int? CaseKey { get; }
        int? MbGpKey { get; }
    }

    public interface IAuditingArguments 
    {
        int UserId { get; set; }
        int? CaseKey { get; set; }
        int? MbGpKey { get; set; }
    }
}
