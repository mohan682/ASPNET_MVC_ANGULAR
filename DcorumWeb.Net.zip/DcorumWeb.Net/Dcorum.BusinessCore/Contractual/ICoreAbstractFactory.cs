﻿using Dcorum.Utilities.Contractual;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;

namespace Dcorum.BusinessCore.Contractual
{
    public interface ICoreAbstractFactory
    {
        IDbProxy CreateDbProxy();

        IDcorumUser FetchDcorumUser(int userId);

        IRemarksActor CreateRemarksVessel();

        IConfigSource CreateConfigSource();

        IAuditor CreateAuditor<TModel>(string category, int userId, IRemarksActor remarksVessel, int maxDepth = 1, Func<TModel, string> howToGetAuditIdentity = null);
    }
}
