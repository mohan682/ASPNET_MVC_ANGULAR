﻿//using Dcorum.BusinessLayer.Entities;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Dcorum.BusinessCore.Contractual
//{
//    public interface IDcorumUserDal
//    {
//        DcorumUser Get(int userId);
//    }
//}
