﻿namespace Dcorum.BusinessCore.Contractual
{
    public interface IDcorumUser
    {
        int Id { get; }

        bool IsInSecurityGroup { get; }
      

        bool IsAdministrator { get; }

        bool CanCreateContent { get; }

        bool CanApproveContent { get; }

        bool CanDeregisterTargetPlanUser { get; }

        bool CanEditSchemeSummary { get; }


        string UserName { get; }

        //[METHOD]
        bool IsInGroup(string groupName);
    }
}
