﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessCore.Contractual
{
    /// <summary>
    /// Interface to allow abstraction between pure compass scheme or ones with that join with uext_case_data
    /// </summary>
    public interface ISchemeThinFetcher
    {
        ISchemeThinReadOnly FetchLightScheme(int caseKey);

        ISchemeThinReadOnly FetchLightScheme(string schemeExternalId);
    }
}
