﻿using Dcorum.BusinessLayer.BusinesObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCorum.BusinessFoundation.Contractual
{
    public interface IAuditService
    {
        List<Dcorum.BusinessLayer.Entities.PDIMessage> Audit<T>(bool success, string category, T current1, T existing1,
            int? userId = null, Func<object, Tuple<RefCode, string>> howToGetAuditIdentity = null)
            where T : class;
    }
}
