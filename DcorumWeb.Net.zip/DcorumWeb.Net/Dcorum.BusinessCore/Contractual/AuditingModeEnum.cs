﻿namespace Dcorum.BusinessLayer.Contractual
{
    public enum AuditingMode
    {
        Undefined = 0,
        //ByPrimaryKey,
        ByScheme,
        ByMemberGroup
    }
}
