﻿namespace Dcorum.BusinessCore.Contractual
{
    public interface ISchemeThinReadOnly
    {
        int? CaseKey { get;  }
        string DisplayText { get; }
        string ExternalId { get; }
        string Name { get; }
        string PlanCode { get; }
        int ProductCode { get; }
        string ProviderCode { get; }
    }
}