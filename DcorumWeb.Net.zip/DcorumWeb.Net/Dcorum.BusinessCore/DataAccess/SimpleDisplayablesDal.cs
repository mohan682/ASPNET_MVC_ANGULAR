﻿using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessCore.DataAccess.Sql;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities.Extensions;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;

namespace Dcorum.BusinessCore.DataAccess
{
    /// <summary>
    /// Returns collections indented for UI display in some form of dropdown.
    /// </summary>
    public sealed class SimpleDisplayablesDal
    {
        public static readonly SimpleDisplayablesDal Singleton = new SimpleDisplayablesDal( new DataAccessContext() );

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        private SimpleDisplayablesDal(IDbFetcherProxy dbIn)
        {
            KeyedMemberGroupTypes = new Dictionary<bool, string>
            {   {true, $@"t1.GRP_TYP_CD = { MemberGroupDomainCodes.InvestmentMemberGroupType.SqlQuotify() }" }
            ,   {false, $@"t1.GRP_TYP_CD = { MemberGroupDomainCodes.BenefitMemberGroupType.SqlQuotify() }" }
            };

            db = dbIn;
            if (db == null) throw new ArgumentNullException(nameof(dbIn));
        }

        /// <summary>
        /// boolean keyed MemberGroup Types 
        /// </summary>
        private Dictionary<bool, string> KeyedMemberGroupTypes { get; }

        private IDbFetcherProxy db { get; }


        public IDictionary<int, IDictionary<int, string>> FetchMemberGroupDisplayables(int[] parentValues, bool? investmentModeOn = null)
        {
            string[] columnNames = new[] { "CASE_KEY", "MBGP_KEY", "DESCRIPT" } ;

            string groupTypeCode = null ;

            if (investmentModeOn.HasValue)
            {
                bool success1 = investmentModeOn.HasValue ? KeyedMemberGroupTypes.TryGetValue(investmentModeOn.Value, out groupTypeCode) : false;
                Debug.Assert(success1 == true);
            }

            string selectSql1 = TripletHelp.MakeSelectSql("mbr_grp", "t1", columnNames, 0, parentValues, groupTypeCode);

            var results = TripletHelp.FetchGroupedPairs(db, selectSql1, columnNames);
            return results;
        }


        public IDictionary<int, string> FetchMemberGroupDisplayablesSubset(params int[] primaryKeys)
        {
            const string sqlTemplate1 = @"
                SELECT * FROM mbr_grp t1
                WHERE ({0})
                ";

            string sql1 = string.Format(sqlTemplate1, primaryKeys.IntoSqlInClause("t1.MBGP_KEY", 1000));

            var results = db.GetMany(sql1, _ => TripletHelp.FetchPair(_, "MBGP_KEY", "DESCRIPT"));

            return results.IntoDictionary();
        }



        public IDictionary<int, IDictionary<int, string>> FetchEmployerDisplayables(int[] caseKeys)
        {
            string[] columnNames = new[] { "CASE_KEY", "EMPR_KEY", "SHORTNAME" } ;
            string selectSql1 = TripletHelp.MakeSelectSql("V_EMPLOYERS", "t1", columnNames, 0, caseKeys ) ;
            var results = TripletHelp.FetchGroupedPairs(db, selectSql1, columnNames);
            return results;
        }


        public IDictionary<int, string> FetchEmployerDisplayablesSubset(params int[] primaryKeys)
        {
            const string sqlTemplate1 = @"
                SELECT * FROM V_EMPLOYERS t1
                WHERE ({0})
                ";

            string sql1 = string.Format(sqlTemplate1, primaryKeys.IntoSqlInClause("t1.EMPR_KEY", 1000));

            var results = db.GetMany(sql1, _ => TripletHelp.FetchPair( _, "EMPR_KEY", "SHORTNAME"));

            return results.IntoDictionary();
        }


        public IDictionary<int,IDictionary<int,string>> FetchBillingGroupDisplayables(int[] caseKeys)
        {
            string[] columnNames = new[] { "CASE_KEY", "BGRP_KEY", "DESCRIPT" };
            string selectSql1 = TripletHelp.MakeSelectSql("BILL_GRP", "t1", columnNames, 0, caseKeys);
            var results = TripletHelp.FetchGroupedPairs(db, selectSql1, columnNames);
            return results;
        }


        public IDictionary<int, string> FetchBillingGroupDisplayablesSubset(params int[] primaryKeys)
        {
            const string sqlTemplate1 = @"
                SELECT * FROM BILL_GRP t1
                WHERE ({0})
                ";

            string sql1 = string.Format(sqlTemplate1, primaryKeys.IntoSqlInClause("t1.BGRP_KEY", 1000));

            var results = db.GetMany(sql1, _ => TripletHelp.FetchPair(_, "BGRP_KEY", "DESCRIPT"));

            return results.IntoDictionary();
        }


        public IDictionary<string, string> FetchFreezableSchemeDisplayables(string providerCode, string productTypeCode, string planTypeCode)
        {
            string sql1 = string.Format(CommonSqlSelectStatements.SqlSelect6ColsCaseDataAndPlanTypeTemplateWhereUnexpiredStatus );
            var tooMany = db.GetMany(sql1, ThinSchemeFactoryMethods.Singleton.@MakeScheme );

            var filtered1 = tooMany
                .Where(_ => string.IsNullOrEmpty(providerCode)    || string.Equals(_.ProviderCode, providerCode, StringComparison.OrdinalIgnoreCase))
                .Where(_ => string.IsNullOrEmpty(productTypeCode) || string.Equals(_.ProductCode.ToString(), productTypeCode, StringComparison.OrdinalIgnoreCase))
                .Where(_ => string.IsNullOrEmpty(planTypeCode)    || string.Equals(_.PlanCode, planTypeCode, StringComparison.OrdinalIgnoreCase))
                .ToArray();

            var results = filtered1.ToDictionary( _ => _.ExternalId, _ => _.Name) ;

            return results ;
        }


        public IDictionary<int, string> FetchSchemeDisplayablesSubset(params int[] primaryKeys)
        {
            const string sqlTemplate1 = @"
                SELECT * FROM CASE_DATA t1
                WHERE ({0})
                ";

            string sql1 = string.Format(sqlTemplate1, primaryKeys.IntoSqlInClause("t1.CASE_KEY", 1000));

            var results = db.GetMany(sql1, _ => TripletHelp.FetchPair(_, "CASE_KEY", "PLAN_NM"));

            return results.IntoDictionary();
        }
    }


    //------------------------


    public static class TripletHelp
    {
        internal static Tuple<int, string> FetchPair(IDataRecord reader, string keyColumnName, string valueColumnName)
        {
            var result = Tuple.Create(
                reader.FetchAsValue<int>(keyColumnName),
                reader.FetchAsString(valueColumnName)
                );

            return result;
        }


        /// <summary>
        /// Note: Assumes parent and child keys are of type 'int'
        /// </summary>
        /// <returns></returns>
        public static string
            MakeSelectSql(string tableName, string tableAlias, string[] columnNames, int parentColumnIndex, int[] parentKeys, params string[] extraWhereClauses)
        {
            string qualified1 = null ;
            if (string.IsNullOrWhiteSpace(tableAlias) == false)
                qualified1 = (tableAlias.EndsWith(".")) ? tableAlias : tableAlias + "."
                ;

            string sql1 = $@"
                SELECT {string.Join(",", columnNames.Select(now1 => qualified1 + now1))}
                FROM {tableName} {tableAlias}
                WHERE ( {parentKeys.IntoSqlInClause(qualified1 + columnNames[parentColumnIndex], 1000)} )
                ";

            string selectSql1 = string.Join(" AND ", new string[] { sql1 }.Concat( extraWhereClauses.Where(_ => !string.IsNullOrEmpty(_))));
            return selectSql1;
        }

        /// <summary>
        /// Note: Assumes parent and child keys are of type 'int'
        /// </summary>
        /// <returns></returns>
        public static IDictionary<int, IDictionary<int, string>>
            FetchGroupedPairs(IDbFetcherProxy db, string selectSql1, string[] columnNames)
        {
            var fetched1 = db.GetMany(selectSql1, reader => Tuple.Create(
                reader.FetchAsValue<int>(columnNames[0]),
                reader.FetchAsValue<int>(columnNames[1]),
                reader.FetchAsString(columnNames[2])
                ));

            var result = fetched1
                .GroupBy(gb => gb.Item1, gb => Tuple.Create(gb.Item2, gb.Item3))
                .ToDictionary(td => td.Key, td => td.Select(_ => _).IntoDictionary())
                ;

            return result;
        }

    }
}
