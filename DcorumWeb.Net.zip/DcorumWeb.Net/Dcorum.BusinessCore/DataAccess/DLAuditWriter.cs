﻿using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessCore.DataAccess
{
    public class DLAuditWriter
    {
        internal DLAuditWriter() { }

        public int Add(StandingDataAudit auditRecordToSave)
        {
            string sql1 = InsertDataAuditSql(auditRecordToSave);
            int result = DataAccessHelp.SimpleExecuteNonQuery(sql1);
            return result;
        }

        private string InsertDataAuditSql(StandingDataAudit rec)
        {
            const string sql = @"INSERT INTO Standing_Data_Audit
                                (   STANDING_DATA_AUDIT_ID,                USER_ID, ACTION_DATE,    COMPONENT,  OPERATION_TYPE, EXISTING_VALUE, NEW_VALUE,  SOURCE, AUDIT_IDENTIFIER,   IDENTIFIER_TYPE) VALUES
                                (   Standing_Data_Audit_Id_Seq.nextval,    {0},     SysDate,        {1},        {2},            strOldVal,      strNewVal,  {3},    {4},                {5})";

            string innerSql = string.Format(sql, rec.UserId, rec.AuditComponent.IntoSqlValue(), rec.OperationType.IntoSqlValue(), rec.SourceSystem.IntoSqlValue(), rec.AuditIdentifier.SqlQuotify(), rec.IdentifierType.IntoSqlValue());


            var keyedClobItems = new Dictionary<string, string>()
            {
                {"strOldVal",  rec.ExistingValue },
                {"strNewVal", rec.NewValue }
            };

            var sqlbuilder1 = new OracleClobBuilder() ;

            string result = sqlbuilder1.MakeClobSql(innerSql, keyedClobItems, null);

            return result ;
        }
    }
}
