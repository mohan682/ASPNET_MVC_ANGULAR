﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessCore.DataAccess.Sql
{
    public class ThinCompassSchemeSql
    {
        internal ThinCompassSchemeSql() { }

        public const string ThinSqlSelectTemplate = CommonSqlSelectStatements.SqlSelect6ColsCaseDataAndPlanTypeTemplate;


        public string GetLightSchemeSettingSql(int caseKey)
        {
            string sqlTemplate = String.Format(ThinSqlSelectTemplate, "where CD.CASE_KEY= {0}");
            return string.Format(sqlTemplate, caseKey);
        }

        /// <summary>
        /// Used for scheme freeze
        /// </summary>
        public string GetLightSchemeSettingSql(string externalId)
        {
            string sqlTemplate = String.Format(ThinSqlSelectTemplate, "where CD.CONT_NO= '{0}'");
            return string.Format(sqlTemplate, externalId);
        }
    }
}
