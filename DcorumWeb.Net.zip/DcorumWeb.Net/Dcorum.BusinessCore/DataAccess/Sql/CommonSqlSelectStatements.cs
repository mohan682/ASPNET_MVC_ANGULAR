﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessCore.DataAccess.Sql
{
    public static class CommonSqlSelectStatements
    {
        /// <summary>
        /// Compass centric 6 column select + plan_typ_cd
        /// </summary>
        public const string SqlSelect6ColsCaseDataAndPlanTypeTemplate = @"
    SELECT DISTINCT CD.CASE_KEY, CD.PLAN_NM, CD.CONT_NO, CD.OVRD_CO_CD, CD.PROD_TYP_CD, J1.plan_typ_cd 
    FROM CASE_DATA CD
    LEFT JOIN Plan_Type_Hist j1 on j1.case_key = CD.case_key
        and trunc(j1.eff_dt)<=sysdate AND NVL(j1.XPIR_DT,sysdate) >= sysdate
    {0}
    ORDER BY CD.PLAN_NM
    ";

        /// <summary>
        /// Compass centric 6 column select + plan_typ_cd
        /// </summary>
        public const string SqlSelect6ColsCaseDataAndPlanTypeTemplateWhereUnexpiredStatus = @"
    SELECT DISTINCT CD.CASE_KEY, CD.PLAN_NM, CD.CONT_NO, CD.OVRD_CO_CD, CD.PROD_TYP_CD, J1.plan_typ_cd 
    FROM CASE_DATA CD
    LEFT JOIN Plan_Type_Hist j1 on j1.case_key = CD.case_key
        and trunc(j1.eff_dt)<=sysdate AND NVL(j1.XPIR_DT,sysdate) >= sysdate
    inner join case_statuses j2
        on j2.Case_key = CD.Case_Key
    WHERE 
        j2.xpir_dt is null or j2.rec_stat_cd = 0
    ORDER BY CD.PLAN_NM
    ";



    }
}
