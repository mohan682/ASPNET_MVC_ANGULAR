﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessCore.DataAccess.Sql;
using Dcorum.BusinessLayer.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Data;

namespace Dcorum.BusinessCore.DataAccess
{
    /// <summary>
    /// [CLOSED_TYPE]
    /// </summary>
    public class DLThinCompassScheme : SchemeFetcherDAL<Scheme>, ISchemeThinFetcher
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal DLThinCompassScheme(ThinCompassSchemeSql sqlMaker, IDbFetcherProxy dbProxy)
            :base(sqlMaker, dbProxy, ThinSchemeFactoryMethods.Singleton.@MakeScheme)
        {
        }

        ISchemeThinReadOnly ISchemeThinFetcher.FetchLightScheme(string schemeExternalId)
        {
            return this.FetchLightScheme(schemeExternalId);
        }

        ISchemeThinReadOnly ISchemeThinFetcher.FetchLightScheme(int caseKey)
        {
            return this.FetchLightScheme(caseKey);
        }
    }


    public abstract class SchemeFetcherDAL<TScheme>
        where TScheme : ISchemeThinReadOnly
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        protected SchemeFetcherDAL(ThinCompassSchemeSql sqlMaker, IDbFetcherProxy dbProxy, Func<IDataReader, TScheme> schemeCreationTechnique)
        {
            SqlMaker1 = sqlMaker;
            DbProxy = dbProxy ;
            SchemeCreationTechnique = schemeCreationTechnique;

            if (SqlMaker1 == null) throw new ArgumentNullException(nameof(sqlMaker));
            if (DbProxy == null) throw new ArgumentNullException(nameof(dbProxy));
            if (SchemeCreationTechnique == null) throw new ArgumentNullException(nameof(schemeCreationTechnique));
        }

        private ThinCompassSchemeSql SqlMaker1 { get; }
        private IDbFetcherProxy DbProxy { get; }

        private Func<IDataReader, TScheme> SchemeCreationTechnique { get; }

        public TScheme FetchLightScheme(int caseKey)
        {
            string sql1 = SqlMaker1.GetLightSchemeSettingSql(caseKey);
            return DbProxy.GetSingle(sql1, @SchemeCreationTechnique);
        }

        public TScheme FetchLightScheme(string schemeExternalId)
        {
            string sql1 = SqlMaker1.GetLightSchemeSettingSql(schemeExternalId);
            return DbProxy.GetSingle(sql1, @SchemeCreationTechnique);
        }
    }
}
