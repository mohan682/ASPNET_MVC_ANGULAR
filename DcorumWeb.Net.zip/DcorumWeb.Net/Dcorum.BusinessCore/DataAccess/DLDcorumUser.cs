﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Dcorum.BusinessCore.Contractual;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLDcorumUser //: IDcorumUserDal
    {
        internal DLDcorumUser(DcorumUserSQL sqlMaker, IDbFetcherProxy dbProxy)
        {
            _textualSqlActor = sqlMaker;
            DbProxy1 = dbProxy;
            if (DbProxy1 == null) throw new ArgumentNullException(nameof(dbProxy));
        }

        private readonly DcorumUserSQL _textualSqlActor ;
        private IDbFetcherProxy DbProxy1 ;

        internal DcorumUser GetUserById(int userId)
        {
            string sql1 = _textualSqlActor.GetUserById(userId);
            var result = DbProxy1.GetSingle(sql1, @reader => new DcorumUser(@reader, false), () => new object[] { userId });
            return result;
        }


        public DcorumUser[] GetInternalUsers()
        {
            string sql1 = _textualSqlActor.GeInternalUserSQL();
            var results = DataAccessHelp.GetMany(sql1, @reader => new DcorumUser(@reader, true));
            return results;
        }

        public DcorumUser[] GetDCorUsersForImpersonation(string fName, string mName, string lName)
        {
            string sql1 = _textualSqlActor.GeDCorUserForImpersonationSQL(fName, mName, lName);
            var results = DataAccessHelp.GetMany(sql1, @reader => new DcorumUser(@reader, true));
            return results;
        }

        internal Tuple<int, string>[] GetInternalUsersAndTheirGroups(int? filterByUserId)
        {
            string sql1 = _textualSqlActor.GeInternalUserAndTheirGroupsSQL(filterByUserId);
            var results = DbProxy1.GetMany(
                sql1, @reader => Tuple.Create(
                    DBHelper.GetIDataReaderInt(reader, "User_Id"),
                    DBHelper.GetIDataReaderString(reader, "Name")
                    )
                    , () => new object[] { filterByUserId }
                );
            return results;
        }


    }
}
