﻿using System;
using Dcorum.BusinessLayer.Contractual;
using DCorum.BusinessFoundation.Contractual;

namespace DCorum.BusinessFoundation.Bases
{
    /// <summary>
    /// Resolves TKey argument as an int
    /// </summary>
    public class BLRetrieverTemplate<TModel>
        : BLRetrieverTemplate<TModel, int, int>, IRetriever<TModel>
    {
        public BLRetrieverTemplate(ICrudOut<TModel, int> crudOut)
            : base(crudOut)
        {
        }
    }
}
