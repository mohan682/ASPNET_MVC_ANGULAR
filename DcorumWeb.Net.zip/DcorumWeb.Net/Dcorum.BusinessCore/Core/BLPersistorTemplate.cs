﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Logic.Helping;
using DCorum.BusinessFoundation.Bases;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.Practices;
using Dcorum.BusinessCore.Creational;

namespace Dcorum.BusinessLayer.Core
{
    /// <summary>
    /// supports IPersistor&lt;TModel&gt;
    /// </summary>
    [Obsolete]
    public class BLPersistorTemplate<TModel>
    : BLPersistorTemplate<TModel, int, int>, IAuditingTarnisher
        where TModel : class, IAuditingArguments, IAuditingArgumentsReadOnly, new() 
    {
        protected BLPersistorTemplate(ICrudFull<TModel, int> crudFull)
            : this(null, crudFull)
        {
        }

        protected BLPersistorTemplate(IAuditingArgumentsReadOnly tarnishSource, ICrudFull<TModel, int> crudFull)
            : base(null, crudFull)
        {
            _sourceOfTarnish = tarnishSource;
        }


        public override bool IsAnActualId(int toCompare)
        {
            return toCompare > AmbientValue;
        }


        protected override void TarnishModel(TModel toModify)
        {
            if (HowToTarnish != null) HowToTarnish(toModify);
            bool success = AuditingTarnishingStrategies.TryStrategy(toModify, _sourceOfTarnish, TarnishMode);
        }


        private IAuditingArgumentsReadOnly _sourceOfTarnish;


        public virtual AuditingMode TarnishMode
        {
            get { return AuditingMode.Undefined; }
        }


        public Action<IAuditingArguments> HowToTarnish { set; private get; }
    }



    public abstract class BLPersistorTemplate<TModel, TKey, TParentKey>
        : BLPersistorTemplate<TModel, TKey, TParentKey, TKey, TParentKey>
        where TModel : class, new()
    {
        protected BLPersistorTemplate(IAuditingArgumentsReadOnly caller, IOpenCrudFull<TModel, TKey, TParentKey> crudFull)
            : base(caller, new RemarksVessel(), crudFull)
        {
        }

        protected override TKey ConvertToDataKey(TKey key)
        {
            return key;
        }

        protected override TParentKey ConvertToParentDataKey(TParentKey key)
        {
            return key;
        }
    }



    public abstract class BLPersistorTemplate<TModel, TKey, TParentKey, TDataKey, TParentDataKey>
        : PersistorTemplate<TModel, TKey, TParentKey, TDataKey, TParentDataKey>
        where TModel : class, new()
    {

        protected BLPersistorTemplate(IAuditingArgumentsReadOnly tarnishSource, IRemarksActor remarksVessel, IOpenCrudFull<TModel, TDataKey, TParentDataKey> crudFull)
            : base(remarksVessel, crudFull)
        {
            _sourceOfTarnish = tarnishSource;
        }

        private readonly IAuditingArgumentsReadOnly _sourceOfTarnish;

        protected int MaxAuditDepth = 1;
        protected int MinExpectedAffectedRows = 1;
        protected int MaxExpectedAffectedRows = 1;


        protected IAuditingArgumentsReadOnly Caller
        {
            get
            {
                return _sourceOfTarnish;
            }
        }


        public override TModel GetUnique(TKey primaryId)
        {
            var result = base.GetUnique(primaryId) ?? Create() ;

            TarnishModel(result);
            return result;
        }

        /// <summary>
        /// [POLYMORPHIC] Typically used by base members {Insert,Update,Delete} as their core implementation.
        /// </summary>
        protected sealed override void Persist(TModel toPersist, Func<TModel,int> howToPersist, bool deleteModeOn)
        {
            if (toPersist == null) //unhapy
            {
                RemarksVessel.RemarkNoItemSpecified = true;
                return ;
            }

            PersistInner(toPersist, howToPersist, BeforeAuditing, deleteModeOn);
        }


        private TModel CopyAcrossAuditIdentityArguments(TModel toModify, TModel source)
        {
            var cast1 = toModify as IAuditingArguments;
            var cast2 = source as IAuditingArgumentsReadOnly;

            if (cast1 != null && cast2 != null)
            {
                cast1.CopyBaseEntityValuesFrom(cast2);
            }

            return toModify;
        }


        /// <summary>
        /// [POLYMORPHIC] Occasionally overridden
        /// </summary>
        protected virtual TModel GetUniqueForAuditing(TKey id)
        {
            return GetUnique(id);
        }


        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual void PersistInner(TModel toPersist, Func<TModel, int> howToPersist, Func<TModel, int?, bool> afterPersistButBeforeAudit, bool deleteModeOn)
        {
            TarnishModel(toPersist);
            Func<TKey, TModel> howToGetModel = (@keyArg => CopyAcrossAuditIdentityArguments(GetUniqueForAuditing(@keyArg), toPersist));

            int? userId = (toPersist as IAuditingArguments).SafeFuncN( _ => _.UserId) ?? _sourceOfTarnish.SafeFuncN( _ => _.UserId) ;

            var auditor = BusinessCoreFactoryMethods.CreateAuditor(Category, userId.Value, RemarksVessel, MaxAuditDepth, _ => GetAuditFriendlyId(toPersist));

            auditor.PersistThenAudit(toPersist, @howToPersist, @howToGetModel, @GetPrimaryId, afterPersistButBeforeAudit, deleteModeOn, null, AmbientValue);
        }


        /// <summary>
        /// [POLYMORPHIC] Provides an opportunity to remark on the number of rows affected or to change the model after persistence but before auditing. 
        /// This is usual for masking/hiding sensitive values such as passwords.
        /// <returns>Returns a flag to indicate if the amount of affected rows is as expected.</returns>
        /// </summary>
        protected virtual bool BeforeAuditing(TModel model, int? rowsAffected)
        {
            return RemarksVessel.RemarkUponRowsAffected(rowsAffected, MinExpectedAffectedRows, MaxExpectedAffectedRows);
        }


        protected virtual Tuple<RefCode, string> GetAuditFriendlyId(TModel toUse)
        {
            return BaseEntityExtensions.GetAuditFriendlyIdentity(toUse, () => GetTextualIdentityOf(toUse));
        }

        /// <summary>
        /// note: if null is specified in constructor then this method should be overridden.
        /// </summary>
        protected virtual void TarnishModel(TModel toModify)
        {
            Debug.Assert(_sourceOfTarnish != null);
            bool success = AuditingTarnishingStrategies.TryStrategy(toModify as IAuditingArguments, _sourceOfTarnish);
        }


        protected override TModel Create()
        {
            return new TModel();
        }

        /// <summary>
        /// Standard extra persistance command pattern with injectable bespoke behaviour.
        /// Used only in derived classes.
        /// </summary>
        protected IEnumerable<IOutcomeItem> PersistWrapper(TModel modelRoot, Func<TModel, int> howToPerist)
        {
            int prevMaxAuditDepth = MaxAuditDepth;
            int prevMinExpectedAffectedRows = MinExpectedAffectedRows;
            int prevMaxExpectedAffectedRows = MaxExpectedAffectedRows;

            try
            {
                Persist(modelRoot, howToPerist, false);
                return RemarksVessel.YieldAndPurgeAll();
            }
            finally
            {
                MaxAuditDepth = prevMaxAuditDepth ;
                MinExpectedAffectedRows = prevMinExpectedAffectedRows ;
                MaxExpectedAffectedRows = prevMaxExpectedAffectedRows ;
            }
        }
    }
}
