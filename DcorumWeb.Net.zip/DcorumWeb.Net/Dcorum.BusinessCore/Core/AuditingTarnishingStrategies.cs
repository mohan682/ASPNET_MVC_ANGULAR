﻿using System;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Core
{
    public static class AuditingTarnishingStrategies
    {
        public static void AssignStrategyTo(IAuditingTarnisher controller, IAuditingArgumentsReadOnly tarnish)
        {
            if (controller == null) return;
            var strategy = GetStrategy(controller.TarnishMode);
            controller.HowToTarnish = _ => strategy(_, tarnish);
        }


        public static bool TryStrategy(IAuditingArguments tarnishable, IAuditingArgumentsReadOnly sourceOfTarnish,
            AuditingMode tarnishMode = AuditingMode.Undefined)
        {
            if (tarnishable == null) return false;
            if (sourceOfTarnish == null) return false;

            var strategy = GetStrategy(tarnishMode);

            if (strategy == null) return false;

            strategy(tarnishable, sourceOfTarnish);

            return true;
        }


        public static Action<IAuditingArguments, IAuditingArgumentsReadOnly> GetStrategy(AuditingMode mode = AuditingMode.Undefined)
        {
            switch (mode)
            {
                case AuditingMode.ByMemberGroup:
                    return ApplyTarnish3;
                case AuditingMode.ByScheme:
                    return ApplyTarnish2;
                default:
                    return ApplyTarnish1;
            }
        }

        private static void ApplyTarnish1(IAuditingArguments toModify, IAuditingArgumentsReadOnly tarnish)
        {
            toModify.UserId = tarnish.UserId;
        }

        private static void ApplyTarnish2(IAuditingArguments toModify, IAuditingArgumentsReadOnly tarnish)
        {
            toModify.UserId = tarnish.UserId;
            toModify.CaseKey = tarnish.CaseKey;
        }

        private static void ApplyTarnish3(IAuditingArguments toModify, IAuditingArgumentsReadOnly tarnish)
        {
            toModify.UserId = tarnish.UserId;
            toModify.CaseKey = tarnish.CaseKey;
            toModify.MbGpKey = tarnish.MbGpKey;
        }
    }
}
