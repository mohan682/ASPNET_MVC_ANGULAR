﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using DCorum.BusinessFoundation.Contractual;
using System;

namespace Dcorum.BusinessLayer.Core
{
    /// <summary>
    /// 
    /// </summary>
    public class RemarksVessel :IRemarksActor
    {
        public const string NoModelRemark = "No item was specified!";
        public const string ZeroAffectedRowsRemark   = "Warning! Zero records were affected by this action!";
        public const string ManyAffectedRowsRemark   = "Warning! Multiple records were affected by this action!";
        public const string LessAffectedRowsRemark   = "Warning! Not enough records were affected by this action!";
        public const string UnavailableCommandRemark = "Warning! This action cannot be attempted!";
        public const string UnpermittedCommandRemark = "Warning! This action is not permitted!";

        public RemarksVessel(Func<IRemarksContainer> containerEmptyingTechnique = null)
        {
            _injectedContainerEmptyingTechnique = containerEmptyingTechnique ?? DefaultInjectedContainerEmptyingTechnique;
            Debug.Assert(_injectedContainerEmptyingTechnique != null);
            _container = ResetContainer();
        }

        /// <summary>
        /// [CONFIG]
        /// </summary>
        public static Func<IRemarksContainer> DefaultInjectedContainerEmptyingTechnique;

        private readonly Func<IRemarksContainer> _injectedContainerEmptyingTechnique;


        private IRemarksContainer _container;


        public bool IsEmpty
        {
            get
            {
                return _container.Any() == false;
            }
        }


        public void IncludeCustomRemarks(params string[] remarks)
        {
            foreach (var remarkNow in remarks.ToArray())
            {
                _container.AddCustomMessage(remarkNow);
            }
        }


        public bool RemarkUnavailableCommand
        {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage(UnavailableCommandRemark);
            }
        }

        public bool RemarkUnpermittedCommand
        {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage(UnpermittedCommandRemark);
            }
        }


        public bool RemarkActionAffectedMoreThanExpected 
                    {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage(ManyAffectedRowsRemark);
            }
        }

        public bool RemarkActionAffectedLessThanExpected
                    {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage(LessAffectedRowsRemark);
            }
        }

        public bool RemarkActionAppearedToAffectNothing
        {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage(ZeroAffectedRowsRemark);
            }
        }



        public bool RemarkNoItemSpecified
        {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage(NoModelRemark);
            }
        }

        public bool DuplicatesDetected
        {
            set
            {
                if (value == false) return;
                _container.AddCode(Constants.ValidationErrorCodes.DBOperationRecordAlreadyExists);
            }
        }

        public bool DependanciesDetected
        {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage("The item has existing dependencies preventing deletion!");
            }
        }

        public bool RemarkInvalidIdentityDetected
        {
            set
            {
                if (value == false) return;
                _container.AddCustomMessage("The identity of this item is not valid!");
            }
        }


        public bool AuditFailure
        {
            set
            {
                if (value == false) return;
                _container.AddCode(Constants.ValidationErrorCodes.DBOperationAuditFailure);
            }
        }

        public bool DbOperationError
        {
            set
            {
                if (value == false) return;
                _container.AddCode(Constants.ValidationErrorCodes.DBOperationInternalError);
            }
        }


        public bool DbOperationTamperedData
        {
            set
            {
                if (value == false) return;
                _container.AddCode(Constants.ValidationErrorCodes.DBOperationTamperedData);
            }
        }


        public TMessage[] PullAllMessages<TMessage>()
            where TMessage :IOutcomeItem
        {
            var results = _container.OfType<TMessage>().ToArray();
            _container = ResetContainer();
            return results;
        }


        public IEnumerable<IOutcomeItem> YieldAndPurgeAll()
        {
            IOutcomeItem[] results = _container.ToArray();
            _container = ResetContainer();
            return results;
        }

        private IRemarksContainer ResetContainer()
        {
            var creation1 = _injectedContainerEmptyingTechnique() ;
            Debug.Assert(creation1.Any() == false);
            return creation1 ;
        }


        public bool RemarkUponRowsAffected(int? actualRowsAffected, int minExpectedRowsAffected = 1, int maxExpectedRowsAffected = 1)
        {
            Debug.Assert(minExpectedRowsAffected <= maxExpectedRowsAffected);

            if (actualRowsAffected == null || actualRowsAffected <= 0)
            {
                //note: will add warning even if it is within the expected range.
                RemarkActionAppearedToAffectNothing = true; 
            }

            if (actualRowsAffected < minExpectedRowsAffected)
            {
                RemarkActionAffectedLessThanExpected = true;
                return false;
            }
            else if (actualRowsAffected > maxExpectedRowsAffected)
            {
                RemarkActionAffectedMoreThanExpected = true;
                return false;
            }

            return true;
        }
    }
}
