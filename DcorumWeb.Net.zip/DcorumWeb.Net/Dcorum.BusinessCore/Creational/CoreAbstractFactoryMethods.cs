﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.Logic;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessCore.Creational
{
    /// <summary>
    /// [SINGLETON|STATELESS]
    /// </summary>
    public class CoreAbstractFactoryMethods : ICoreAbstractFactory
    {
        public static readonly ICoreAbstractFactory Singleton = new CoreAbstractFactoryMethods();

        private CoreAbstractFactoryMethods() { }


        public IDcorumUser FetchDcorumUser(int userId)
        {
            return BLDcorumUser.Singleton.GetUserById(userId);
        }

        public IDbProxy CreateDbProxy()
        {
            return new DataAccessContext();
        }

        public IRemarksActor CreateRemarksVessel()
        {
            return new RemarksVessel();
        }

        public IConfigSource CreateConfigSource()
        {
            return ConfigHelp.Singleton;
        }

        public IAuditor CreateAuditor<TModel>(string category, int userId, IRemarksActor remarksVessel, int maxDepth = 1, Func<TModel, string> howToGetAuditIdentity = null)
        {
            Func<object, Tuple<RefCode, string>> auditIdTechniqe
                = model => Tuple.Create<RefCode, string>(null, howToGetAuditIdentity((TModel)model))
                ;

            return BusinessCoreFactoryMethods.CreateAuditor(category, userId, remarksVessel, maxDepth, auditIdTechniqe);
        }
    }
}
