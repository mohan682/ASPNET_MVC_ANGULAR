﻿using Dcorum.BusinessCore.DataAccess;
using Dcorum.BusinessCore.DataAccess.Sql;
using Dcorum.BusinessLayer.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using System.Data;
using System.Linq;

namespace Dcorum.BusinessCore.Creational
{
    public class ThinSchemeFactoryMethods
    {
        public static readonly ThinSchemeFactoryMethods Singleton = new ThinSchemeFactoryMethods();

        private ThinSchemeFactoryMethods() {}

        //-------

        /// <summary>
        /// [CREATIONAL]
        /// </summary>
        public Scheme MakeScheme(IDataReader reader)
        {
            var creation1 = new Scheme(@reader, false, ColumnNames6);
            return creation1;
        }

        /// <summary>
        /// Basic 6 column names
        /// </summary>
        public string[] ColumnNames6
        {
            get
            {
                return _default6ColumnNames.ToArray();
            }
        }


        /// <summary>
        /// Basic 6 column names
        /// </summary>
        public string[] ColumnNames3
        {
            get
            {
                return _default3ColumnNames.ToArray();
            }
        }


        public DLThinCompassScheme CreateCompassSchemeReader()
        {
            var creation1 = new DLThinCompassScheme(new ThinCompassSchemeSql(), new DataAccessContext());
            return creation1;
        }


        private static readonly string[] _default3ColumnNames = { "CASE_KEY", "CONT_NO", "PLAN_NM" };
        private static readonly string[] _default6ColumnNames = { "CASE_KEY", "CONT_NO", "PLAN_NM", "OVRD_CO_CD", "PROD_TYP_CD", "PLAN_TYP_CD" };

    }
}
