﻿using Dcorum.BusinessCore.Bundles;
using Dcorum.BusinessCore.DataAccess;
using Dcorum.BusinessCore.Modelling;
using Dcorum.BusinessLayer.Bundles;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.DataAccess.SQL;
using DCorum.BusinessFoundation.Auditing;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;

namespace Dcorum.BusinessCore.Creational
{
    public static class BusinessCoreFactoryMethods
    {
        private static readonly AuditTypeMap _ourAuditTypeMap = AuditTypeMap.Singleton;

        public static Auditor CreateAuditor(string category, int userId, IRemarksActor remarksVessel, int maxDepth = 1, Func<object, Tuple<RefCode, string>> howToGetAuditIdentity = null)
        {
            StandingDataAuditCreator auditingModelMaker = new StandingDataAuditCreator(userId, maxDepth, @howToGetAuditIdentity);

            var auditor = new Auditor(remarksVessel, auditingModelMaker, category, new DLAuditWriter().@Add);
            return auditor;
        }


        public static DLDcorumUser CreateDcorumUserSearcher()
        {
            var creation1 = new DLDcorumUser(new DcorumUserSQL(), new DataAccessContext());
            return creation1;
        }


        public static BundledEmployee.BLEmployee CreateEmployeeController()
        {
            var result = new BundledEmployee.BLEmployee(new BundledEmployee.DataAccess(new BundledEmployee.SqlMaker()));
            return result;
        }

        public static ProductBundle.Controller CreationProductController()
        {
            var creation1 = new ProductBundle.Controller(
                new ProductBundle.DataAccess(
                    new ProductBundle.SqlMaker(), new DataAccessContext(), @reader => new Product(@reader)
                    ), null
                );
            return creation1;
        }
    }
}
