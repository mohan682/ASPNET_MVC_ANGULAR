﻿namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class DcorumUserSQL
    {
        internal DcorumUserSQL() {}

        public string GetUserById(int userId)
        {
            return string.Format("SELECT USER_ID,USER_NAME,LASTNAME,FIRSTNAME FROM USERS WHERE USER_ID={0}", userId);
        }

        public string GeInternalUserSQL()
        {
            return string.Format("SELECT User_Id, User_Name FROM Users WHERE  User_Type_Cd = '1' ORDER BY User_Name ");
        }

        public string GeDCorUserForImpersonationSQL(string fName, string mName, string lName)
        {
            const string sql = @"
                                SELECT US.User_Id, US.User_Name 
                                FROM
	                                Users		    US
                                WHERE
	                                US.User_Type_Cd = '1'
                                AND LOWER(NVL(US.FirstName, ' ')) = LOWER(NVL('{0}', NVL(US.FirstName, ' ')))
                                AND LOWER(NVL(US.MidName, ' '))   = LOWER(NVL('{1}', NVL(US.MidName, ' ')))
                                AND LOWER(NVL(US.LastName, ' '))  = LOWER(NVL('{2}', NVL(US.LastName, ' ')))";

            return string.Format(sql, fName, mName, lName);
        }

        public string GeInternalUserAndTheirGroupsSQL(int? filterByUserId)
        {
            const string template1 = @"
SELECT 
    US.User_Id, GP.Group_Id, GP.Name 
FROM
	Users		    US,
	Users_Groups	UG,
    Groups		    GP
WHERE
	US.User_Id      = UG.User_Id
    AND	UG.Group_Id     = GP.Group_Id
    AND	US.User_Type_Cd = '1'
";

            string extraClause1 = ((filterByUserId.HasValue) ? "AND US.User_Id = " + filterByUserId.Value : null);
            string sql1 = template1 + extraClause1 ;

            return sql1 + extraClause1;
        }
    }
}
