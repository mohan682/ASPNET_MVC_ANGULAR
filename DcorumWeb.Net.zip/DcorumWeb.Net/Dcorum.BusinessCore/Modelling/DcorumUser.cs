﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.BusinessLayer.Constants;
using Dcorum.Utilities;
using Dcorum.Configuration.Contractual;
using Dcorum.BusinessCore.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    /// <summary>
    /// IMPLEMENTS IDocrumUser
    /// </summary>
    public class DcorumUser : IDcorumUser
    {
        /// <summary>
        /// Only use for development!!!!
        /// </summary>
        public DcorumUser(int userId)
        {
            Id = userId;
            UserName = String.Format("Unknown:{0}", Id);
            _groupNames = new Lazy<string[]>(() => Enumerable.Empty<string>().ToArray());
        }

        public DcorumUser(IDataReader reader, bool partialModeOn)
        {
            Build(this, reader, partialModeOn);
        }

        [Key]
        public int Id { get; private set; }
        public int ExternalUserId { get; private set; }
        public string UserName { get; private set; }
        public string LastName { get; private set; }
        public string FirstName { get; private set; }


        private Lazy<string[]> _groupNames; 

        public bool IsInGroup(string groupName)
        {
            if (_groupNames == null) return false;
            bool result = _groupNames.Value.Any(x => String.Compare(x, groupName, true) == 0);
            return result;
        }


        public bool IsInSecurityGroup
        {
            get
            {
                return IsInGroup(UserGroupNames.Security);
            }
        }

        public bool IsAdministrator
        {
            get
            {
                return IsInGroup(GroupId.AdministrGroupId);
            }
        }


        public bool CanCreateContent
        {
            get
            {
                return IsInGroup(UserGroupNames.ContentCreator);
            }
        }


        public bool CanApproveContent
        {
            get
            {
                return IsInGroup(UserGroupNames.ContentApprover);
            }
        }


        public bool CanDeregisterTargetPlanUser
        {
            get
            {
                return IsInGroup(UserGroupNames.TargetPlanUserDeregistration);
            }
        }

        public bool CanEditSchemeSummary
        {
            get
            {
                return IsInGroup(UserGroupNames.SchemeSummaryEdit);
            }
        }



        public override string ToString()
        {
            return string.Format("{0} {1}", FirstName, LastName);
        }

        private static void Build(DcorumUser dcorumUser, IDataReader reader, bool partialModeOn)
        {
            if (reader == null) return;
            dcorumUser.Id = DBHelper.GetIDataReaderInt(reader, "USER_ID");
            dcorumUser.UserName = DBHelper.GetIDataReaderString(reader, "USER_NAME");

            if (!partialModeOn)
            {
                dcorumUser.LastName = DBHelper.GetIDataReaderString(reader, "LASTNAME");
                dcorumUser.FirstName = DBHelper.GetIDataReaderString(reader, "FIRSTNAME");
            }
        }

        public class Editor :IDisposable
        {
            public Editor(DcorumUser toEdit)
            {
                Contract.Assert(toEdit != null);
                _toEdit = toEdit;
            }

            private DcorumUser _toEdit;


            public void SetGroupNames(Func<int,string[]> groupNames)
            {
                _toEdit._groupNames = new Lazy<string[]>(() => groupNames(_toEdit.Id)) ;
            }


            public void Dispose()
            {
                _toEdit = null;
            }
        }
    }
}
