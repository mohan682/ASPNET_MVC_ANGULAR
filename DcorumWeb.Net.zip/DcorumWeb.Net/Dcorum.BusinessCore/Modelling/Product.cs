﻿using Dcorum.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessCore.Modelling
{
    public class Product
    {
        internal Product(IDataReader source)
        {
            if (source!=null) Build(this, source);
            IsFromData = source != null;
        }

        public bool IsFromData { get; }


        [Key]
        public int TypeCode
        {
            get; private set;
        }

        public string Description
        {
            get; private set;
        }


        public static void Build(Product model, IDataReader dataReader)
        {
            model.TypeCode = DBHelper.GetIDataReaderInt(dataReader, "PROD_TYP_CD");
            model.Description = DBHelper.GetIDataReaderString(dataReader, "PROD_DESC");
        }
    }
}
