﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessCore.Modelling
{
    internal class ContactHistory
    {
        public int UserId { get; set; }
        public int NameId { get; set; }

        public int? CaseMbrKey { get; set; }

        public string CallType { get; set; }
        public string ActionType { get; set; }

        public string Description { get; set; }
    }
}
