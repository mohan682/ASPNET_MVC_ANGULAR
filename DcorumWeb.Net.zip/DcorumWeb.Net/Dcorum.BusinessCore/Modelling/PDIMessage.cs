﻿using System.ComponentModel.DataAnnotations;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    public class PDIMessage : BaseEntity, IOutcomeItem
    {
        [Key]
        [UIHint("txtMessageNumber")]
        [Required]
        [Range(6000,9000, ErrorMessage = "Message number field must be between 6000 and 9999.")]
        [RegularExpression(@"\d*", ErrorMessage = "Message number should be a 4 digit number.")]
        public int MessageId   { get; set; }

        [RefCodeConstraint(DomainNames.PDIUserMessageLevels)]
        [UIHint("ddlMessageType")]
        //[Required]
        public RefCode MessageType { get; set; }

        [UIHint("txtMessageText")]
        [RegularExpression(@"(.|\n|\r){0,2000}")]
        [UiBypassXssDefence]
        public string MessageText   { get; set; }

        [UIHint("txtMessageCode")]
        [RegularExpression(@"^\w+$")]
        public string MessageCode   { get; set; }

        /// <summary>
        /// Create an instance with only the MessageText property set. Useful for BL persistance methods where non-standard errors can occur.
        /// </summary>
        public static PDIMessage CreateIncomplete(string messageText)
        {
            return new PDIMessage {MessageText = messageText};
        }
    }
}
