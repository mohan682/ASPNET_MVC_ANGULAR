﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessCore.Creational;
using Dcorum.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public class Scheme : ISchemeThinReadOnly
    {
        public Scheme()
        {
        }

        public Scheme(int? caseKey)
        {
            CaseKey = caseKey;
        }

        public Scheme(IDataReader reader, bool obsolete, string[] columnNames = null)
        {
            BuildBasic(this, reader, columnNames ?? ThinSchemeFactoryMethods.Singleton.ColumnNames3);
        }


        [Key]
        public int? CaseKey { get; set; }

        //public int SchemeId { get; set; }
        [UIHint("lblSchemeId")]
        public string ExternalId { get; set; }

        [UIHint("lblSchemeName")]
        public string Name { get; set; }

        [IgnoreDataMember]
        //[RefCodeConstraint(DomainNames.UEXT_Provider_Code)]
        public string ProviderCode { get; private set; }

        [IgnoreDataMember]
        //[RefCodeConstraint(DomainNames.UEXT_Product_Code)]
        public int ProductCode { get; private set; }

        //[RefCodeConstraint(DomainNames.UEXT_PlanType)]
        public string PlanCode { get; private set; }

        [IgnoreDataMember]
        public string DisplayText
        {
            get { return string.Format("[{0}] {1}", this.ExternalId, this.Name); }
        }

        protected static void BuildBasic(Scheme schemeRec, IDataReader reader, string[] columnNames)
        {
            schemeRec.CaseKey = DBHelper.GetIDataReaderInt(reader, columnNames[0]);
            schemeRec.ExternalId = DBHelper.GetIDataReaderString(reader, columnNames[1]);
            schemeRec.Name = DBHelper.GetIDataReaderString(reader, columnNames[2]);

            if (columnNames.Length == 3) return; //data column name collection is already exhausted!

            schemeRec.ProviderCode = DBHelper.GetIDataReaderString(reader, columnNames[3]);
            schemeRec.ProductCode = DBHelper.GetIDataReaderInt(reader, columnNames[4]);

            schemeRec.PlanCode = reader.FetchAsString(columnNames[5]);
        }
    }
}
