﻿using Dcorum.Utilities;
using System.Data;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace Dcorum.BusinessCore.Modelling
{
    public class VEmployee
    {
        public VEmployee()
        {
            DataReadModeOn = false;
        }

        internal VEmployee(IDataReader source)
            :this()
        {
            DataReadModeOn = true;
            Build(this, source);       
        }

        [XmlIgnore]
        [IgnoreDataMember]
        public bool DataReadModeOn { get; }

        public int CaseKey { get; set; }
        public int CaseMemberKey { get; set; }

        public string CatNo { get; set; }
        public string ContNo { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string PlanName { get; set; }

        public string NatlIdNo { get; set; }

        public string MemberTypeCode { get; set; }

        private static void Build(VEmployee model, IDataReader source)
        {
            model.CaseKey = source.FetchAsValue<int>("CASE_KEY");
            model.CaseMemberKey = source.FetchAsValue<int>("CASE_MBR_KEY");

            model.CatNo = source.FetchAsString("CAT_NO");
            model.ContNo = source.FetchAsString("CONT_NO");
            model.FirstName = source.FetchAsString("FIRSTNAME");
            model.LastName = source.FetchAsString("LASTNAME");
            model.PlanName = source.FetchAsString("PLAN_NM");
            model.NatlIdNo = source.FetchAsString("NATLIDNO");
            model.MemberTypeCode = source.FetchAsString("MBR_TYP_CD");
        }
    }
}
