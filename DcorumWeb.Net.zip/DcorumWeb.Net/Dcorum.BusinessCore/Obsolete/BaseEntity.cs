﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    //[Serializable]
    //public abstract class BaseEntityWithScheme : BaseEntity
    //{
    //    [IgnoreDataMember]
    //    public Scheme SchemeLinked { get; set; }

    //    public override int? CaseKey
    //    {
    //        get { return SchemeLinked.CaseKey; }
    //        //WARNING: set value via SchemeLinked!
    //        set
    //        {
    //            if (SchemeLinked == null) throw new InvalidOperationException();
    //            SchemeLinked.CaseKey = value;
    //        }
    //    }
    //}


    [Serializable]
    public abstract class BaseEntity : IAuditingArguments, IAuditingArgumentsReadOnly
    {
        [IgnoreDataMember]
        public List<PDIMessage> errorList { set; get; }

        [IgnoreDataMember]
        public int UserId { get; set; }

        virtual public int? CaseKey { get; set; }

        virtual public int? MbGpKey { get; set; }

        [IgnoreDataMember]
        public bool IsValid { get; set; }

        //internal virtual bool Validate() { return true; }
    }

}
