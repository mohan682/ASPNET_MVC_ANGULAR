﻿using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.DataAccess.SQL;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.Creational
{

    public class DcorumBusinessDalFactoryMethods
    {
        public static readonly DcorumBusinessDalFactoryMethods Singleton = new DcorumBusinessDalFactoryMethods();
        private DcorumBusinessDalFactoryMethods() { }

        public DLBillingGroup CreateBillingGroupDal()
        {
            return new DLBillingGroup( new BillingGroupSQL() ) ; 
        }

        public DLOCPOptions CreateOCPOptionsDal()
        {
            return new DLOCPOptions(new OCPOptionsSQL());
        }

        //public DLOCPOptionsReadOnly CreateOCPOptionsReadOnlyDal()
        //{
        //    return new DLOCPOptionsReadOnly(new OCPOptionsReadOnlySQL());
        //}

        public DLContent CreateContentDal()
        {
            IDbProxy db1 = new DataAccessContext();

            DLContentData otherDAL = new DLContentData(new ContentDataSqlMaker(), db1);

            var creation1 = new DLContent(new ContentSQL(), otherDAL, db1);

            return creation1;
        }

        public DLDataAudit CreateDataAuditDal()
        {
            var creation1 = new DLDataAudit(new DataAuditSQL());
            return creation1;
        }

        public DLAdviserChargingQueries CreateAdviserChargingDal()
        {
            var creation1 = new DLAdviserChargingQueries(new AdviserChargingQuerySql(), new DataAccessContext());
            return creation1 ;
        }

        public DLLetterOfAuthority CreateLetterOfAuthorityDal(IRemarksActor remarksVessel)
        {
            var creation = new DLLetterOfAuthority(new LetterOfAuthoritySqlMaker(), remarksVessel) ;
            return creation;
        }
    }
}
