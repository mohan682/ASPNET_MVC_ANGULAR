﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;

namespace Dcorum.BusinessLayer.Creational
{
    public class DcorumBusinessFactoryMethods
    {
        public static readonly  DcorumBusinessFactoryMethods Singleton = new DcorumBusinessFactoryMethods(DcorumBusinessDalFactoryMethods.Singleton, CoreAbstractFactoryMethods.Singleton);

        private DcorumBusinessFactoryMethods(DcorumBusinessDalFactoryMethods myDalFactory1, ICoreAbstractFactory coreAbstractFactory)
        {
            MyDalFactory1 = myDalFactory1 ;
            if (MyDalFactory1 == null) throw new ArgumentNullException(nameof(myDalFactory1));

            CoreAbstractFactory = coreAbstractFactory;
            if (CoreAbstractFactory == null) throw new ArgumentNullException(nameof(coreAbstractFactory));
        }

        private DcorumBusinessDalFactoryMethods MyDalFactory1 { get; }
        private ICoreAbstractFactory CoreAbstractFactory { get; }

        public BLAdminUser CreateAdminUserController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLAdminUser(caller, new DLAdminUser(new AdminUserSQL()));
            return creation1;
        }

        public BLDemoUser CreateDemoUserController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLDemoUser(caller, new DLDemoUser(new DemoUserSQL()), CreateDemoUserResponseGroupController(caller));
            return creation1;
        }

        public BLDemoUserResponseGroup CreateDemoUserResponseGroupController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLDemoUserResponseGroup(caller, new DLDemoUserResponseGroup(new DemoUserResponseGroupSqlMaker()), new DLStaticResponseGroup(new StaticResponseGroupSQL()));
            return creation1;
        }

        public BLDemoParam CreateDemoParamController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLDemoParam(caller, new DLDemoParam(new DemoParamSQL()));
            return creation1;
        }


        public SchemeFullController CreateSchemeController(IAuditingArgumentsReadOnly caller)
        {
            var dal = new DLFullScheme(new SchemeSQL());
            var creation1 = new SchemeFullController(caller, dal);

            dal.SchemeFullCreationTechnique = @reader => new SchemeFull(@reader, ThinSchemeFactoryMethods.Singleton.ColumnNames6 )
            {
                FetchDecumSchemesTechnique = creation1.GetDecumSchemes
            };

            return creation1;
        }

        public BLMemberGroupEditor CreateMemberGroupController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLMemberGroupEditor(caller, new DlMemberGroup(new MemberGroupSql()));
            return creation1;
        }

        public BLFundClass CreateFundClassController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLFundClass(caller, new DLFundClass(new FundClassSQL()));
            return creation1;
        }


        //public BLFundClassDetail CreateFundClassDetailController(IAuditingArgumentsReadOnly caller)
        //{
        //    var creation1 = new BLFundClassDetail(caller, new DLFundClassDetail(new FundClassDetailSQL()));
        //    return creation1;
        //}


        //public BLFundClassMoneyType CreateFundClassMoneyTypeController(IAuditingArgumentsReadOnly caller)
        //{
        //    var creation1 = new BLFundClassMoneyType(caller, new DLFundClassMoneyType(new FundClassMoneyTypeSQL()));
        //    return creation1;
        //}


        public BLAssetClassGrowthRate CreateAssetClassGrowthRateController(IAuditingArgumentsReadOnly caller)
        {
            IDbProxy db1 = new DataAccessContext();

            var creation1 = new BLAssetClassGrowthRate(caller, new DLAssetClassGrowthRate(new AssetClassGrowthRateSQL(), db1 ));
            return creation1;
        }


        public BLStandingDataAudit CreateStandingDataAuditController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLStandingDataAudit(caller, MyDalFactory1.CreateDataAuditDal() );
            return creation1;
        }


        public BLContentWithCloning CreateContentListController(IAuditingArgumentsReadOnly caller)
        {
            var myRemarksVessel = CoreAbstractFactory.CreateRemarksVessel();
            IAuditor auditor1 = CoreAbstractFactory.CreateAuditor<ContentDataModel>(DomainCodes.DcorumComponentContent, caller.UserId, myRemarksVessel, 1, model => model.Id.ToString());

            var user1 = CoreAbstractFactory.FetchDcorumUser(caller.UserId);

            IDcorumUser user = BLDcorumUser.Singleton.GetUserById(caller.UserId) ?? new DcorumUser(caller.UserId);

            var creation1 = new BLContentWithCloning(user, MyDalFactory1.CreateContentDal(), auditor1 );

            return creation1;
        }


        public BLContent CreateContentFormController(IAuditingArgumentsReadOnly caller)
        {
            var myRemarksVessel = CoreAbstractFactory.CreateRemarksVessel();
            IAuditor auditor1 = CoreAbstractFactory.CreateAuditor<ContentDataModel>(DomainCodes.DcorumComponentContent, caller.UserId, myRemarksVessel, 1, model => model.Id.ToString());

            var user1 = CoreAbstractFactory.FetchDcorumUser(caller.UserId);

            IDcorumUser user = BLDcorumUser.Singleton.GetUserById(caller.UserId) ?? new DcorumUser(caller.UserId);

            var creation1 = new BLContent(user, MyDalFactory1.CreateContentDal(), auditor1 );

            return creation1;
        }


        public BLBillingGroup CreateBillingGroupController(IAuditingArgumentsReadOnly caller)
        {
            //AuditTypeMap.Singleton.TryAdd(typeof(BillingGroupViaReader), typeof(BillingGroup));

            return new BLBillingGroup( caller, DcorumBusinessDalFactoryMethods.Singleton.CreateBillingGroupDal() );
        }

        public BLOCPOptions CreateOCPOptionsController(IAuditingArgumentsReadOnly caller)
        {
            return new BLOCPOptions(caller, DcorumBusinessDalFactoryMethods.Singleton.CreateOCPOptionsDal());
        }

        //public BLOCPOptionsReadOnly CreateOCPOptionsReadOnlyController(IAuditingArgumentsReadOnly caller)
        //{
        //    return new BLOCPOptionsReadOnly(caller, DcorumBusinessDalFactoryMethods.Singleton.CreateOCPOptionsReadOnlyDal() );
        //}

        public BLAdviserCharging CreateAdviserChargingController(IAuditingArgumentsReadOnly caller)
        {
            IRemarksActor myRemarksVessel = CoreAbstractFactory.CreateRemarksVessel();
            IAuditor auditor1 = CoreAbstractFactory.CreateAuditor<LetterOfAuthority>(DomainCodes.DCorumLetterOfAuthority, caller.UserId, myRemarksVessel, 1, model => model.LetterOfAuthorityId.ToString());


            var user1 = CoreAbstractFactory.FetchDcorumUser(caller.UserId);

            return new BLAdviserCharging(user1, MyDalFactory1.CreateAdviserChargingDal(), MyDalFactory1.CreateLetterOfAuthorityDal( myRemarksVessel), auditor1, myRemarksVessel );
        }
    }
}
