﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dcorum.BusinessLayer.Entities;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Logic;

namespace Dcorum.BusinessLayer.Core
{
    public class PdiMessageContainer : IRemarksContainer
    {
        public PdiMessageContainer()
        {
        }

        private readonly List<PDIMessage> _container = new List<PDIMessage>();


        public void Clear()
        {
            _container.Clear();
        }

        public void AddCode(string code)
        {
            if (_container.Any(_ => String.Equals(_.MessageCode, code, StringComparison.OrdinalIgnoreCase))) return;
            _container.Add(BLPDIMessage.GetPDIMessageById(code));
        }

        public void AddCustomMessage(string message)
        {
            if (_container.Any(_ => _.MessageText.Equals(message))) return;

            _container.Add(PDIMessage.CreateIncomplete(message));
        }


        /// <summary>
        /// Typed
        /// </summary>
        internal PDIMessage[] Messages()
        {
            return _container.ToArray();
        }

        /// <summary>
        /// Untyped
        /// </summary>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return _container.GetEnumerator();
        }

        IEnumerator<IOutcomeItem> IEnumerable<IOutcomeItem>.GetEnumerator()
        {
            return _container.GetEnumerator();
        }
    }
}
