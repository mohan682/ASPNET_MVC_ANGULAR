﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dcorum.BusinessLayer.LifePath.Entities;

namespace Dcorum.BusinessLayer.LifePath.Viewing
{
    public static class LifePathViewHelper
    {
        public static object DefaultViewFacade(this GlidePathGraph model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.RefCodeHashCode,
                ID_________________________ = model.RefCode,
                LifePath_Type______________________ = model.Description,
                Valid = model.IsValid
            };
            return facade1;
        }


        public static object DefaultViewFacade(this TaintedLifePathFundMix model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.LifePathFundMixId,
                Term_To_End_Date = model.Term,
                Total_Term_Percentage = (model.TermPercentSum/100).ToString("P2"),
                Asset_Code = model.AssetType.RefCd,
                Asset_Type_______________________ = model.AssetType.Descript,
                Percentage = (model.Percentage/100).ToString("P2"),
            };
            return facade1;
        }
    }
}
