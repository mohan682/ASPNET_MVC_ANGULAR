﻿using Dcorum.BusinessLayer.LifePath.Validation;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Dcorum.BusinessLayer.LifePath.Entities
{
    public class GlidePathGraph : GlidePath
    {
        public GlidePathGraph() : this(null) { }

        public GlidePathGraph(IDataReader reader)
            :base(reader)
        {
        }

        private List<LifePathFundMix> _details = new List<LifePathFundMix>();
        public IEnumerable<LifePathFundMix> Details { get {return _details; }  }

        //[ReadOnly(true)]
        //[Display(Name = "Is Valid:")]
        //[UIHint("chkValid")]
        public bool IsValid { get; private set; }

        public void AddRange(LifePathFundMix[] toAdd)
        {
            _details.AddRange(toAdd);

            var badPairs = GlidePathAssociateExtensions.GetBadTermsSummary(toAdd);

            IsValid = !badPairs.Any() && _details.Count > 0;
        }
    }
}
