﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using Dcorum.BusinessLayer.LifePath.Contractual;
using System;

namespace Dcorum.BusinessLayer.LifePath.Entities
{
    public class LifePathFundMix : IGlidePathAssociate
    {
        protected LifePathFundMix(IDataReader reader)
        {
            if (reader == null) return;
            Build(this,reader);
        }

        [XmlIgnore, IgnoreDataMember]
        private static string[] _columnNames = { "LIFEPATH_FUND_MIX_ID", "DESCRIPT", "TERM", "ASSET_CODE", "PCT", "TYPE" };
        internal static IEnumerable<string> ColumnNames { get { return _columnNames; } }

        [Key]
        [ReadOnly(true)]
        [Display(Name = "LifePath Fund Mix ID:", Order = 5000)]
        [UIHint("txtId")]
        [UiDisplayingHint(UiDisplayMode.Invisible,UiDisplayMode.Displayable)]
        public int LifePathFundMixId { get; set; }

        [ReadOnly(true)]
        [Display(Name = "LifePath Type:", Order = 5100)]
        [UIHint("ddlLifePathType")]
        [RefCodeConstraint("LIFEPATH_TYPE")]
        public RefCode LifePathType { get; set; }

        //[ReadOnly(true)]
        //[Display(Name = "Description:")]
        //[UIHint("txtDesc")]
        public string Description { get; set; }

        [Required]
        [Display(Name = "Term To End Date:", Order = 5200)]
        [UIHint("txtTerm")]
        [Range(0, 99)]
        [UiDisplayingHint(UiDisplayMode.Editable, UiDisplayMode.Displayable)]
        public int Term { get; set; }

        [Required]
        [UIHint("ddlAssetDesc")]
        [Display(Name = "Asset Type:", Order = 5300)]
        [RefCodeConstraint("FND UNDRLY ASSET CLS")]
        public RefCode AssetType { get; set; }

        [Required]
        [Display(Name = "Percentage:", Order = 5400)]
        [UIHint("txtPercentage")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0.0, 100.0)]
        public decimal Percentage { get; set; }

        private static void Build(LifePathFundMix model, IDataReader reader)
        {
            model.LifePathFundMixId = DBHelper.GetIDataReaderInt(reader, _columnNames[0]);
            model.Description = DBHelper.GetIDataReaderString(reader, _columnNames[1]);
            model.Term = DBHelper.GetIDataReaderInt(reader, _columnNames[2]);
            model.AssetType = new RefCode(DBHelper.GetIDataReaderString(reader, _columnNames[3]));
            model.Percentage = DBHelper.GetIDataReaderDecimal(reader, _columnNames[4]);
            model.LifePathType = (reader.FetchTextualRefCode(_columnNames[5]));
        }
    }
}
