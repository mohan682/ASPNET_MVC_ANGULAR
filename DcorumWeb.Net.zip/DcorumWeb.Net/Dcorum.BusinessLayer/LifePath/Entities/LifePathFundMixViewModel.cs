﻿using Dcorum.BusinessLayer.LifePath.Contractual;
using Dcorum.Utilities.Contractual;
using DCorum.ViewModelling;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Dcorum.BusinessLayer.LifePath.Entities
{
    /// <summary>
    /// augmented with some view model concerns.
    /// </summary>
    public class TaintedLifePathFundMix : LifePathFundMix, IGlidePathAssociateWithIdentity
    {
        public TaintedLifePathFundMix() : this(null) { }

        public TaintedLifePathFundMix(IDataReader reader)
            : base(reader)
        {
        }

        [Display(Name = "Max Allocatable Percentage:", Order = 5250)]
        [Editable(false)]
        [UIHint("litMaxPercentage")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        public decimal MaxAllocatablePercent { get; set; }

        public decimal TermPercentSum { get; set; }

        string IGlidePathAssociateWithIdentity.TermDisplayName
        {
            get
            {
                return AnnotationHelp.GetDisplayNamePair(this, _ => _.Term).Item2;
            }
        }

        int IGlidePathAssociateWithIdentity.MyKey
        {
            get
            {
                return LifePathFundMixId; ;
            }
        }

        string IGlidePathAssociateWithIdentity.MyParentKey
        {
            get
            {
                return LifePathType?.RefCd;
            }
        }
    }
}
