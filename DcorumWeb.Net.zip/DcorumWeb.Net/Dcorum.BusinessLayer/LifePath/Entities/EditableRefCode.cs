﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using DCorum.ViewModelling.Annotations;

namespace Dcorum.BusinessLayer.LifePath.Entities
{
    public class GlidePath
    {
        protected GlidePath(IDataReader reader)
        {
            if (reader == null) return;
            Build(this, reader);
        }

        private static readonly string[] _columnNames = { "DOMAIN_NAME", "DESCRIPT", "DISABLE_CD", "REF_CD", "LINE_NO" };
        internal static IEnumerable<string> ColumnNames { get { return _columnNames; } }


        public string DomainName { get; set; }
        public bool Disabled { get; set; }
        public string LineNumber { get; set; }

        [Key]
        [ReadOnly(true)]
        public int RefCodeHashCode { get { return RefCode.GetHashCode(); } }

        [UIHint("txtRefCode")]
        [UIHint("txtRefCode", "search")]
        [Display(Name = "ID:")]
        [UiDisplayingHint(UiDisplayMode.Editable, UiDisplayMode.Displayable)]
        [UiSearchable(null, "like")]
        [RegularExpression("^(LP_)[A-Z0-9_]{3,27}", ErrorMessage = "Must start with 'LP_' and be alpha-numeric text. ")]
        [StringLength(30, ErrorMessage = "ID must must not be longer than 30 chararcters. ")]
        [Required]
        public string RefCode { get; set; }

        [UIHint("txtDesc")]
        [UIHint("txtDesc", "search")]
        [Display(Name = "LifePath Type:")]
        [UiSearchable(null, "like")]
        [Required]
        [StringLength(80)]
        public string Description { get; set; }

        private static void Build(GlidePath model, IDataReader reader)
        {
            model.DomainName = DBHelper.GetIDataReaderString(reader, _columnNames[0]);
            model.Description = DBHelper.GetIDataReaderString(reader, _columnNames[1]);

            model.Disabled = reader.FetchBooleanN(_columnNames[2]) ?? false;

            model.RefCode = DBHelper.GetIDataReaderString(reader, _columnNames[3]);
            model.LineNumber = DBHelper.GetIDataReaderString(reader, _columnNames[4]);
        }
    }
}
