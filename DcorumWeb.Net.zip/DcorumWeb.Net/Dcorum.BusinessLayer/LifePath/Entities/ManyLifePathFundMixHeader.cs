﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.LifePath.Entities
{
    public class ManyLifePathFundMixHeader
    {
        //[ReadOnly(true)]
        //[Display(Name = "LifePath Type:")]
        //[UIHint("ddlLifePathType")]
        //[RefCodeConstraint("LIFEPATH_TYPE")]
        //public RefCode LifePathType { get; set; }

        [ReadOnly(true)]
        [Display(Name = "LifePath Type:")]
        [UIHint("txtLifePathType")]
        public string LifePathTypeDesc { get; set; }
    }
}
