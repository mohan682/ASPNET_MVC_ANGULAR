﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dcorum.BusinessLayer.LifePath.Entities;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.LifePath.Sql
{
    /// <summary>
    /// [CLOSED_TYPE]
    /// </summary>
    internal class GlidePathSqlActor: SimpleSqlFullCrud<GlidePath, Tuple<string,string>, string>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal GlidePathSqlActor() : base(SqlSpec) {}

        public static ISqlSpecification<GlidePath> SqlSpec =
            new SqlSpecification<GlidePath>
            {
                TableName = "REF_CODES",
                ColumnNames = GlidePath.ColumnNames.ToArray(),

                MyIdentityIndexes = new[] {new[] {0,3}},
                UpdatableIndexes = new[] {1},

                ParentKeyIndex = 0,
                SqlSequenceName = null,
                GettersForSql = new Func<GlidePath, object>[]
                {
                    _ => _.DomainName.SqlQuotify(),
                    _ => _.Description.SqlQuotify(),
                    _ => _.Disabled.IntoSqlBool(),
                    _ => _.RefCode.SqlQuotify(),
                    _ => _.LineNumber.SqlQuotify()
                }
            };


        public override IEnumerable<object> GetKeyParts(Tuple<string, string> key)
        {
            string[] parts = { key.Item1, key.Item2 };
            string[] sqlParts = parts.Select(_ => _.SqlQuotify()).ToArray();
            return sqlParts;
        }
    }
}
