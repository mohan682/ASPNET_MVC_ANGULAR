﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using Dcorum.BusinessLayer.LifePath.Entities;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.LifePath.Sql
{
    /// <summary>
    /// [CLOSED_TYPE]
    /// </summary>
    internal class LifePathFundMixSqlActor : SimpleSqlFullCrud<LifePathFundMix, int, string>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal LifePathFundMixSqlActor() : base(SqlSpec) {}

        [XmlIgnore, IgnoreDataMember]
        public static ISqlSpecification<LifePathFundMix> SqlSpec =
            new SqlSpecification<LifePathFundMix>
            {
                TableName = "LIFEPATH_FUND_MIX",
                ColumnNames = LifePathFundMix.ColumnNames.ToArray(),
                ParentKeyIndex = 5,
                SqlSequenceName = "LIFEPATH_FUND_MIX_ID_SEQ",
                MyIdentityIndexes = new[] { new[] { 0 }, new[] { 2, 3, 5 } },
                UpdatableIndexes = null,
                OrderByIndexes = new[] { 5, 2, 3 },
                GettersForSql = new Func<LifePathFundMix, object>[]
                {
                    _ => _.LifePathFundMixId,
                    _ => _.Description.SqlQuotify(),
                    _ => _.Term,
                    _ => _.AssetType.IntoSqlValue(),
                    _ => _.Percentage,
                    _ => _.LifePathType.IntoSqlValue()
                }
            };
    }
}
