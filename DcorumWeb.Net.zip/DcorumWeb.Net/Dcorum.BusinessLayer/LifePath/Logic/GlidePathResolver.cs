﻿//using System;
//using System.Linq;
//using Dcorum.BusinessLayer.LifePath.DataAccess;
//using Dcorum.BusinessLayer.LifePath.Entities;
//using System.Diagnostics;

//namespace Dcorum.BusinessLayer.LifePath.Logic
//{
//    public class GlidePathResolver : RefCodeResolver<GlidePathGraph>
//    {
//        /// <summary>
//        /// [CONSTRUCTOR]
//        /// </summary>
//        internal GlidePathResolver(GlidePathCrudActor parentDataAccess, string domainName)
//            : base( @str => parentDataAccess.SelectManyViaParentKey(@str), domainName)
//        {
//            //_parentDataAccess = parentDataAccess;
//        }

//        //private readonly GlidePathCrudActor _parentDataAccess;
//    }


//    /// <summary>
//    /// 
//    /// </summary>
//    public class RefCodeResolver<TRefCode>
//        where TRefCode :GlidePath
//    {
//        internal readonly string DomainName ;

//        /// <summary>
//        /// hack: because UI only supports numeric keys at present;
//        /// </summary>
//        private readonly Lazy<TRefCode[]> _deferredGetMany;

//        /// <summary>
//        /// [CONSTRUCTOR]
//        /// </summary>
//        internal protected RefCodeResolver(Func<string,TRefCode[]> getManyViaParentKeyTechnique, string domainName)
//        {
//            DomainName = domainName;
//            Debug.Assert(string.IsNullOrWhiteSpace(DomainName) == false);

//            Func<string, TRefCode[]> GetManyViaParentKeyTechnique = getManyViaParentKeyTechnique;
//            if (GetManyViaParentKeyTechnique == null) throw new ArgumentNullException(nameof(getManyViaParentKeyTechnique));
          
//            _deferredGetMany = new Lazy<TRefCode[]>(() => GetManyViaParentKeyTechnique?.Invoke(DomainName));
//        }


//        public TRefCode GetItem(int? hashCode)
//        {
//            if (!hashCode.HasValue) return null;

//            var result = _deferredGetMany.Value.FirstOrDefault(_ => _.RefCodeHashCode == hashCode.Value);
//            return result;
//        }
//    }
//}
