﻿using System;
using System.ComponentModel;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.LifePath.DataAccess;
using Dcorum.BusinessLayer.LifePath.Entities;
using Dcorum.BusinessLayer.LifePath.Validation;
using Dcorum.BusinessLayer.LifePath.Viewing;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Auditing;
using DCorum.BusinessFoundation.Contractual;
using System.Diagnostics;

namespace Dcorum.BusinessLayer.LifePath.Logic
{
    [Category(DomainCodes.DCorumComponentLifePath)]
    public class BLLifePathFundMix : BLPersistorTemplate<TaintedLifePathFundMix, int, string>, IPersistor<TaintedLifePathFundMix>
    {
        private static AuditTypeMap _auditingAssociate1 = AuditTypeMap.Singleton;


        private readonly LifePathFundMixCrudActor _dataAccess ;
        private readonly Lazy<GlidePathGraph[]> _resolver ;

        private int? _parentNumericId;

        static BLLifePathFundMix()
        {
            bool success = _auditingAssociate1.TryAdd(typeof (TaintedLifePathFundMix), typeof (LifePathFundMix));
        }

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal BLLifePathFundMix(IAuditingArgumentsReadOnly tarnishSource, int? parentNumericId, LifePathFundMixCrudActor dataAccess, Lazy<GlidePathGraph[]> resolver)
            : base(tarnishSource, dataAccess)
        {
            _parentNumericId = parentNumericId;
            _resolver = resolver;
            _dataAccess = dataAccess;

            Debug.Assert(_resolver != null);
            Debug.Assert(_dataAccess != null);
            Debug.Assert(Caller != null);
        }

        protected override object AnonymousTableRowFacade(TaintedLifePathFundMix model)
        {
            var facade1 = LifePathViewHelper.DefaultViewFacade(model);
            return facade1;
        }

        /// <summary>
        /// [FACADE]
        /// </summary>
        public GlidePathGraph GetParent(int? hashCode)
        {
            if (!hashCode.HasValue) return null;
            return _resolver.Value.FirstOrDefault(_ => _.RefCodeHashCode == hashCode.Value) ;
        }

        /// <summary>
        /// Only exists to support bad UI key/parentKey contract requirement. Should never be hit (parentId is really a string).
        /// </summary>
        public TaintedLifePathFundMix[] GetMany(int parentId = 0, Func<object, bool> postQueryFilter = null, string augmentQueryWith = null)
        {
            throw new NotImplementedException();
        }


        protected override TaintedLifePathFundMix Create()
        {
            var creation1 = new TaintedLifePathFundMix();

            string actualParentId = GetParent(_parentNumericId).SafeFunc(_ => _.RefCode);

            creation1.LifePathType = new RefCode(actualParentId);

            return creation1;
        }


        protected override void Validate(TaintedLifePathFundMix model)
        {
            var results = GlidePathAssociateExtensions.Validate(model, @parentId => _dataAccess.SelectManyViaParentKey(@parentId));

            RemarksVessel.IncludeCustomRemarks( results.Select(_ => _.Item2).ToArray() );
        }


        public override TaintedLifePathFundMix GetUnique(int primaryId)
        {
            var result = base.GetUnique(primaryId);

            result.MaxAllocatablePercent = 100 - GlidePathAssociateExtensions.CalculateAllocatadPercentageExcludingModel(result, @parentId => _dataAccess.SelectManyViaParentKey(@parentId));

            return result;
        }

        public override TaintedLifePathFundMix[] GetMany(string parentId = default(string), string augmentQueryWith = null)
        {
            var results = base.GetMany(parentId, augmentQueryWith);

            var sumOfPercentagesGroupdByTerm = GlidePathAssociateExtensions.GetTermsSummary(results);

            foreach (var current1 in results)
            {
                var toUse = sumOfPercentagesGroupdByTerm.FirstOrDefault(_ => _.Item1 == current1.Term);
                if (toUse==null) continue;
                current1.TermPercentSum = toUse.Item2;
            }

            return results;
        }

    }
}
