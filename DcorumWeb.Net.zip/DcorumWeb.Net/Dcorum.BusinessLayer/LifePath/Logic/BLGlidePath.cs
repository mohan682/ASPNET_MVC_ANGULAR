﻿using System;
using System.ComponentModel;
using System.Linq;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.LifePath.DataAccess;
using Dcorum.BusinessLayer.LifePath.Entities;
using Dcorum.BusinessLayer.LifePath.Viewing;
using System.Diagnostics;

namespace Dcorum.BusinessLayer.LifePath.Logic
{
    [Category(DomainCodes.DCorumComponentLifePath)]
    public class BLGlidePath : BLPersistorTemplate<GlidePathGraph, int, string, Tuple<string,string>, string>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal BLGlidePath(IAuditingArgumentsReadOnly tarnishSource, GlidePathCrudActor dataAccess, LifePathFundMixCrudActor childDataAccess)
            : base(tarnishSource, new RemarksVessel(), dataAccess)
        {
            _dataAccess = dataAccess;
            _childDataAccess = childDataAccess;
            _deferredSiblingsAndSelf = new Lazy<GlidePathGraph[]>(() => _dataAccess.SelectManyViaParentKey(DomainName));
            Debug.Assert(_dataAccess != null);
            Debug.Assert(_childDataAccess != null);
            Debug.Assert(Caller != null);
        }

        private readonly GlidePathCrudActor _dataAccess ;
        private readonly LifePathFundMixCrudActor _childDataAccess ;

        private readonly Lazy<GlidePathGraph[]> _deferredSiblingsAndSelf;

        private LifePathFundMix[] GetChildren(string parentKey)
        {
            var results = _childDataAccess.SelectManyViaParentKey(parentKey);
            return results;
        }

        /// <summary>
        /// [STATIC|="LIFEPATH_TYPE"]
        /// </summary>
        public static string DomainName
        {
            get
            {
                return "LIFEPATH_TYPE";
            }
        }


        protected override object AnonymousTableRowFacade(GlidePathGraph model)
        {
            var facade1 = LifePathViewHelper.DefaultViewFacade(model);
            return facade1;
        }


        protected override Tuple<string,string> ConvertToDataKey(int key)
        {
            var result = _deferredSiblingsAndSelf.Value.FirstOrDefault(_ => _.RefCodeHashCode == key);
            if (result == null) return null;
            return Tuple.Create(DomainName,result.RefCode);
        }


        protected override string ConvertToParentDataKey(string key)
        {
            return key ;
        }


        public override GlidePathGraph[] GetMany(string parentId = default(string), string augmentQueryWith = null)
        {
            var results = base.GetMany(parentId, augmentQueryWith);

            foreach (var current1 in results)
            {
                var toAdd = GetChildren(current1.RefCode);
                current1.AddRange(toAdd);
            }

            return results;
        }


        protected override GlidePathGraph Create()
        {
            var creation1 = new GlidePathGraph()
            {
                //predefined and non editable on page...
                Disabled = false,
                DomainName = BLGlidePath.DomainName,
                LineNumber = null,
                //editable on page...
                RefCode = null,
                Description = null
            };

            return creation1;
        }
    }
}
