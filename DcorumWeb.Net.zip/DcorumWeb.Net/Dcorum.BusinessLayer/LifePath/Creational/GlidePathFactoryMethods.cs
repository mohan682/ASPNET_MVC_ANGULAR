﻿using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.LifePath.DataAccess;
using Dcorum.BusinessLayer.LifePath.Entities;
using Dcorum.BusinessLayer.LifePath.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.LifePath.Creational
{
    /// <summary>
    /// [SINGLETON]
    /// </summary>
    public class GlidePathFactoryMethods
    {
        public static readonly GlidePathFactoryMethods Singleton = new GlidePathFactoryMethods();

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        private GlidePathFactoryMethods() { }

        private readonly GlidePathCrudActor MySharedGlidePathCrudActor = new GlidePathCrudActor(new Sql.GlidePathSqlActor());
        private readonly LifePathFundMixCrudActor MySharedLifePathFundMixCrudActor = new LifePathFundMixCrudActor(new Sql.LifePathFundMixSqlActor());

        /// <summary>
        /// Used by GlidePathDetailsList.aspx & GlidePathDetailEdit.aspx
        /// </summary>
        public BLLifePathFundMix CreateLifePathFundMixController(IAuditingArgumentsReadOnly caller, int? parentNumericId)
        {
            //JIRA AWS-6435 mustn't be static as refcode keys for the domain name can be added via compass and 
            var resolver = new Lazy<GlidePathGraph[]>( () => MySharedGlidePathCrudActor.SelectManyViaParentKey(BLGlidePath.DomainName) );

            var creation1 = new BLLifePathFundMix(caller, parentNumericId, MySharedLifePathFundMixCrudActor, resolver);
            return creation1;
        }

        /// <summary>
        /// Used by LifePathList.aspx
        /// </summary>
        public BLGlidePath CreateGlidePathController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLGlidePath(caller, MySharedGlidePathCrudActor, MySharedLifePathFundMixCrudActor );
            return creation1;
        }
    }
}
