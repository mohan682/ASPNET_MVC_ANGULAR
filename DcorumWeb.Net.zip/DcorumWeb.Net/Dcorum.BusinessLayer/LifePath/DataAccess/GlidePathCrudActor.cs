﻿using System;
using Dcorum.BusinessLayer.LifePath.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using Dcorum.BusinessLayer.LifePath.Sql;

namespace Dcorum.BusinessLayer.LifePath.DataAccess
{
    public class GlidePathCrudActor : CrudActor<GlidePathGraph, Tuple<string,string>, string>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal GlidePathCrudActor(GlidePathSqlActor sqlMaker) : base(@reader => new GlidePathGraph(@reader), sqlMaker)
        {
            _sqlMaker = sqlMaker;
        }

        private readonly GlidePathSqlActor _sqlMaker;
    }
}
