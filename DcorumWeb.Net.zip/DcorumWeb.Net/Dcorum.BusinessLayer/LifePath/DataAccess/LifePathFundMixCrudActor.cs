﻿using Dcorum.BusinessLayer.LifePath.Entities;
using Dcorum.BusinessLayer.LifePath.Sql;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.LifePath.DataAccess
{
    public class LifePathFundMixCrudActor : CrudActor<TaintedLifePathFundMix, int, string>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal LifePathFundMixCrudActor(LifePathFundMixSqlActor sqlMaker): base( @reader => new TaintedLifePathFundMix(@reader), sqlMaker)
        {
            _sqlMaker = sqlMaker;
        }

        private readonly LifePathFundMixSqlActor _sqlMaker;
    }
}
