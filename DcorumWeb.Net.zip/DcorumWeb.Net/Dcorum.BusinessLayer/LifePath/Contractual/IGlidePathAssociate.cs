﻿using System;

namespace Dcorum.BusinessLayer.LifePath.Contractual
{
    /// <summary>
    /// int Term { get; }
    /// decimal Percentage { get; }
    /// </summary>
    public interface IGlidePathAssociate
    {
        int Term { get; }
        decimal Percentage { get; }
    }


    public interface IGlidePathAssociateWithIdentity :IGlidePathAssociate
    {
        int MyKey { get; }
        string MyParentKey { get; }

        string TermDisplayName { get; }
    }
}
