﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Dcorum.BusinessLayer.LifePath.Contractual;

namespace Dcorum.BusinessLayer.LifePath.Validation
{
    public static class GlidePathAssociateExtensions
    {
        public static IEnumerable<Tuple<PropertyInfo, string>> Validate(this IGlidePathAssociateWithIdentity model, Func<string,IEnumerable<IGlidePathAssociateWithIdentity>> howToGetAssociatedModels)
        {
            decimal maxPercent = 100.0m;
            decimal sumPercent = CalculateAllocatadPercentageExcludingModel(model, howToGetAssociatedModels) + model.Percentage;
        
            if (sumPercent > maxPercent)
            {              
                string message = String.Format("The sum of items with a {3} of {0} would total {2:P2}. It must not exceed {1:P2}", model.Term, maxPercent / 100, sumPercent / 100, model.TermDisplayName);
                yield return Tuple.Create( model.GetType().GetProperty(nameof(model.Term)), message);
            }
        }


        public static decimal CalculateAllocatadPercentageExcludingModel(this IGlidePathAssociateWithIdentity model, Func<string, IEnumerable<IGlidePathAssociateWithIdentity>> howToGetAssociatedModels)
        {
            decimal sumPercent;
            var many1 = howToGetAssociatedModels(model.MyParentKey).Where(_ => _.Term == model.Term).ToArray();

            decimal otherTotalPercent = many1.Where(_ => _.MyKey != model.MyKey).Sum(_ => _.Percentage);
            sumPercent = otherTotalPercent;

            return sumPercent;
        }


        /// <summary>
        /// Returns the sum of the supplied items' Percent property after having been grouped by the supplied items' Term property.
        /// </summary>
        public static Tuple<int, decimal>[] GetTermsSummary(this IEnumerable<IGlidePathAssociate> models)
        {
            if (models == null) return null;

            var groups1 = models.GroupBy(_ => _.Term);

            IEnumerable<Tuple<int, decimal>> pairs1 = groups1.Select(_ => Tuple.Create(_.Key, _.Sum(__ => __.Percentage)));

            var results = pairs1.ToArray();

            return results;
        }

        public static Tuple<int, decimal>[] GetBadTermsSummary(this IEnumerable<IGlidePathAssociate> models, decimal expectedSum = 100.0m)
        {
            var results = GetTermsSummary(models).Where(_ => _.Item2 != expectedSum).ToArray();
            return results;
        }
    }
}
