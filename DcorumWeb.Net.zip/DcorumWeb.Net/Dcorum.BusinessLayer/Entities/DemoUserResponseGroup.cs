﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using DCorum.BusinessFoundation.Bases;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Annotations;
using Dcorum.Utilities.Contractual;
using Dcorum.Utilities.Practices;
using Dcorum.BusinessLayer.Constants;

namespace Dcorum.BusinessLayer.Entities
{
    [DisplayName("Scenarios")]
    public class DemoUserResponseGroup : ModelWithBusinessContraints
    {
        public DemoUserResponseGroup()
           : this(null, null)
        {
        }

        internal DemoUserResponseGroup(IDataReader reader, IEnumerable<string> columnNames)
            : base(new BusinessContraintsContainer())
        {
            bool success = TryBuild(this, reader, columnNames.SafeLinq().ToArray());

            Debug.Assert(success == (reader!=null));
        }

        [Key]
        [UIHint("txt*", "debug")]
        [Display(Name="Demo User Response Group Id:")]
        [UiDisplayingHint(UiDisplayMode.Invisible,UiDisplayMode.Displayable)]
        public int MyId { get; set; }

        [Editable(false)]
        [UIHint("txt*")]
        [Display(Name = "User Account Demo Id:")]
        public int UserAccDemoId { get; set; }

        [Required]
        [UIHint("ddl*")]
        [Display(Name = "Static Response Group Id:")]
        [BusinessConstraint(1, typeof(StaticResponseGroup))]
        public int? StaticResponseGroupId { get; set; }

        [UIHint("chk*")]
        [Display(Name = "Is Primary Account:")]
        public bool IsPrimary { get; set; }

        [UIHint("chk*")]
        [Display(Name = "Is Decum Account:")]
        public bool IsDecum { get; set; }

        [Required]
        [UIHint("ddl*")]
        [RefCodeConstraint(DomainNames.MemberStatuses)]
        [Display(Name = "Member Account Status:")]
        public RefCode AccStatus { get; set; }

        [IgnoreDataMember]
        public int PrimaryTotal { get; private set; }

        [IgnoreDataMember]
        public int DecumTotal   { get; private set; }

        private static bool TryBuild(DemoUserResponseGroup model, IDataReader reader, string[] columnNames)
        {
            if (reader == null || model==null || columnNames ==null || columnNames.Length<=0 ) return false;

            model.MyId = reader.FetchAsValue<int>(columnNames[0]);
            model.UserAccDemoId = reader.FetchAsValue<int>(columnNames[1]);
            model.StaticResponseGroupId = reader.FetchAsValue<int>(columnNames[2]);
            model.IsPrimary = reader.FetchBooleanN(columnNames[3]) ?? false ;
            model.IsDecum = reader.FetchBooleanN(columnNames[4]) ?? false ;

            string refCd1 = reader.FetchAsString(columnNames[5]).SafeFunc( _ => _.PadLeft(2, '0'));
            model.AccStatus = (refCd1==null)? null : new RefCode(refCd1);

            model.PrimaryTotal = reader.FetchAsValue<int>("primaryTotal");
            model.DecumTotal = reader.FetchAsValue<int>("decumTotal");
            
            return true;
        }
    }
}
