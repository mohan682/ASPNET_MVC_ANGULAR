﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    public class SwitchRule : BaseEntity
    {
        [Key]
        public int SwitchRuleId { get; set; }

        [IgnoreDataMember]
        public string SwitchRuleDescription { get; set; }

        [IgnoreDataMember]
        public int SwitchRuleTRCode { get; set; }

        [IgnoreDataMember]
        public string DisplayText { get { return string.Format("[{0}] {1}", SwitchRuleTRCode, SwitchRuleDescription); } }
    }
}
