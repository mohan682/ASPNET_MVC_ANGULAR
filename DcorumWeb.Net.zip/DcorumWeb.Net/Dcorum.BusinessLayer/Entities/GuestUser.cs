﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities
{
    public class GuestUser : BaseEntity
    {
        [Key]
        public int GuestUserId { get; set; }
        public int GuestUserAccountId { get; set; }
        public string GuestUserName { get; set; }
        public string GuestUserPassword { get; set; }
        public string ModellerReference { get; set; }
        public bool IsCustomModellerReference { get; set; }

        public MemberGroupThin BenefitMemberGroup { get; set; }
        public MemberGroupThin InvestmentMemberGroup { get; set; }

        public string GetSecurePassword()
        {
            return CommonUser.GetSecurePassword(GuestUserPassword);
        }

        [IgnoreDataMember]
        internal bool PasswordUpdateModeOn 
        {
            get
            {
                return !String.IsNullOrWhiteSpace(GuestUserPassword);
            }
        }
    }
}
