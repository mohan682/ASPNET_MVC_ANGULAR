﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.BusinessLayer.Entities
{
    public class LetterOfAuthority
    {
        internal protected LetterOfAuthority(IDataRecord source)
            :this()
        {
            Build(source);
        }

        public LetterOfAuthority()
        {

        }

        [Key]
        public int LetterOfAuthorityId { get; set; }

        public int CaseMemberKey { get;set; }

        public int AgentKey { get; set; }

        [RefCodeConstraint(DomainNames.LetterAuthorites)]
        public string AuthorityType { get; set; }

        [NotMapped]
        public RefCode AuthorityTypeObj { get; set; }

        [DataType(DataType.Date)]
        public DateTime EffectiveDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime? ExpiryDate { get; set; }

        [NotMapped]
        [DataType(DataType.DateTime)]
        public DateTime LastModifiedDate { get; set; }

        [NotMapped]
        public string LastModifiedBy { get; set; }

        [NotMapped]
        public bool IsExpired { get { return (ExpiryDate.HasValue && ExpiryDate.Value.Date < DateTime.UtcNow.Date); } }

        [NotMapped]
        public bool IsRecordEligibleToExpire { get { return (EffectiveDate.Date!=DateTime.UtcNow.Date && !IsExpired && !ExpiryDate.HasValue); } }

        private void Build(IDataRecord reader)
        {
            LetterOfAuthorityId = reader.Fetch("Letter_Of_Authority_Id", reader.GetInt32);
            CaseMemberKey = reader.Fetch("CASE_MBR_KEY", reader.GetInt32);
            AgentKey = reader.Fetch("AGT_KEY", reader.GetInt32);
            AuthorityType = reader.Fetch("TYPE", reader.GetString);      
            EffectiveDate = reader.Fetch("EFF_DT", reader.GetDateTime);
            ExpiryDate = reader.FetchN("XPIR_DT", reader.GetDateTime);
            LastModifiedDate = reader.Fetch("LAST_MOD_DT", reader.GetDateTime);
            LastModifiedBy = reader.Fetch("LAST_MOD_USER", reader.GetString);
        }
    }
}
