﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Contracts;
using System.Xml.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    public class MoneyTypeGroup : CaseMoneyTypeGroup
    {
        /// <summary>
        /// Used for auditing...
        /// </summary>
    }

    public class CaseMoneyTypeGroup : BaseEntity, IKeyValuePair 
    {
        [Key]
        public int CaseMoneyTypeGroupKey { get; set; }

        public int MoneyTypeGroupKey { get; set; }

        public string MoneyTypeGroupName { get; set; }

        int IKeyValuePair.KeyItem { get { return MoneyTypeGroupKey; } }

        [XmlIgnore]
        [Pure]
        public string DisplayItem
        {
            get
            {
                string result = String.Format("[{0}] {1}", MoneyTypeGroupKey, MoneyTypeGroupName);
                return result;
            }
        }
    }
}
