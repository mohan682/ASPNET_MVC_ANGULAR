﻿using System;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BusinesObjects;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public class FundClassMoneyType:BaseEntity
    {
        //Public Properties to populate
        [Key]
        public int FundClassMoneyTypeId { get; set; }

        [UIHint("txtFundDescriptionId")]
        [Display(Name = "Fund Identifier:")]
        [Editable(false)]
        public string FundDescriptionId { get; set; }

        [UIHint("txtFundLongName")]
        [Display(Name = "Fund Name:")]
        [Editable(false)]
        public string FundLongName { get; set; }

        [IgnoreDataMember]
        public string FundShortName { get; set; }

        [UIHint("ddlMoneyTypeName")]
        [Display(Name = "Money Type:")]
        [Required]
        public int MoneyTypeNumber { get; set; }
      
        public string MoneyTypeName { get; set; }      
    }
}
