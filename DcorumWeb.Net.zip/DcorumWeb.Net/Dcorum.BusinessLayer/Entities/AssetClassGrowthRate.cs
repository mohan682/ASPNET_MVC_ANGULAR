﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using System.Data;
using Dcorum.Utilities;
using System.Runtime.Serialization;
using Dcorum.Utilities.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    [DisplayName("Asset Class Growth Rate")]
    public class AssetClassGrowthRate
    {
        protected internal AssetClassGrowthRate(IDataReader source)
        {
            Build(this, source);
        }

        [Key]
        [UIHint("txt*")]
        [Display(Name = "ID:", ShortName ="ID",  Order = 0)]
        [UiDisplayingHint(UiDisplayMode.Invisible,UiDisplayMode.Displayable)]
        public int AssetClassGrowthRateId { get; set; }

        [UIHint("ddl*")]
        [Display(Name = "Asset Class:", ShortName = "Asset Class", Order = 1)]
        [RefCodeConstraint(DomainNames.AssetClass)]
        [Required(ErrorMessage = "Please select a value for Asset Class")]
        public RefCode AssetClass { get; set; }

        [UIHint("ddl*")]
        [Display(Name = "Provider:", ShortName = "Provider", Order = 2)]
        [RefCodeConstraint(DomainNames.UEXT_Provider_Code)]
        public RefCode Provider { get; set; }

        [Display(Name = "Low:", ShortName = "Low", Order = 3)]
        [UIHint("txt*")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(-10.0, 25.0, ErrorMessage = "Low number field must be between -10 and 25.")]
        [RegularExpression(@"^-?\d{1,2}(\.\d{1,2})?$", ErrorMessage = "A valid number with maximum 2 decimal places is allowed.")]
        [Required(ErrorMessage = "Please enter a value for number field Low")]
        public decimal Low { get; set; }

        [Display(Name = "Medium:", ShortName = "Medium", Order = 4)]
        [UIHint("txt*")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(-10.0, 25.0, ErrorMessage = "Medium number field must be between -10 and 25.")]
        [RegularExpression(@"^-?\d{1,2}(\.\d{1,2})?$", ErrorMessage = "A valid number with maximum 2 decimal places is allowed.")]
        [Required(ErrorMessage = "Please enter a value for number field Medium")]
        public decimal Medium { get; set; }

        [Display(Name = "High:", ShortName = "High", Order = 5)]
        [UIHint("txt*")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(-10.0, 25.0, ErrorMessage = "High number field must be between -10 and 25.")]
        [RegularExpression(@"^-?\d{1,2}(\.\d{1,2})?$", ErrorMessage = "A valid number with maximum 2 decimal places is allowed.")]
        [Required(ErrorMessage = "Please enter a value for number field High")]
        public decimal High { get; set; }

        [Display(Name = "SMPI:", ShortName = "SMPI", Order = 6)]
        [UIHint("txt*")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(-10.0, 25.0, ErrorMessage = "SMPI number field must be between -10 and 25.")]
        [RegularExpression(@"^-?\d{1,2}(\.\d{1,2})?$", ErrorMessage = "A valid number with maximum 2 decimal places is allowed.")]
        [Required(ErrorMessage = "Please enter a value for number field SMPI")]
        public decimal SMPI { get; set; }


        public string OverrideType
        {
            get
            {
                string result = Provider?.RefCd == null ? string.Empty : "PROVIDER";
                return result;
            }
        }

        [IgnoreDataMember]
        public string AssetClassDesc
        {
            get
            {
                return AssetClass?.LongDesc;
            }
        }

        [IgnoreDataMember]
        public string ProviderDesc
        {
            get
            {
                return Provider?.Descript;
            }
        }


        private static void Build(AssetClassGrowthRate assetClassGrowth, IDataReader reader)
        {
            if (reader == null) return; 
            assetClassGrowth.AssetClassGrowthRateId = DBHelper.GetIDataReaderInt(reader, "ASSET_CLASS_GROWTH_RT_ID");
            assetClassGrowth.AssetClass = reader.FetchTextualRefCode("ASSET_CODE");
            assetClassGrowth.Provider = reader.FetchTextualRefCode("OVERRIDE_TYPE_CD");
            assetClassGrowth.High = DBHelper.GetIDataReaderDecimal(reader, "GROWTH_RATE_HIGH");
            assetClassGrowth.Medium = DBHelper.GetIDataReaderDecimal(reader, "GROWTH_RATE_MID");
            assetClassGrowth.Low = DBHelper.GetIDataReaderDecimal(reader, "GROWTH_RATE_LOW");
            assetClassGrowth.SMPI = DBHelper.GetIDataReaderDecimal(reader, "GROWTH_RATE_SMPI");
        }

    }
}
