﻿using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    /// <summary>
    /// [EXTENDS]
    /// </summary>
    public class DataAudit :StandingDataAudit, IAuditingArgumentsReadOnly
    {
        public int? CaseKey { get; set; }

        public int? MbGpKey { get; set; }

        [UIHint("lblAssociationDesc")]
        public string AuditIdentifierDesc { get; set; }

        [UIHint("lblModifiedBy")]
        public string AuditUserName { get; set; }

        public string SearchFilterStartDate { get; set; }
        public string SearchFilterEndDate { get; set; }
    }
}
