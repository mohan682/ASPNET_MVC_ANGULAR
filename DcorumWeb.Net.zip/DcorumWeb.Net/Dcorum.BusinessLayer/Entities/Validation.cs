﻿using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    public class Validation : BaseEntity
    {
        [Key]
        public int ValidationID { get; set; }
        public string ValidationName { get; set;}

        [UIHint("ddlValidationType")]
        //[RefCodeConstraint("VALIDATION TYPES")]
        public string ValidationType { get; set;}

        public string ErrorMessage { get; set;}
        public string ValidationValue { get; set;}

        [UIHint("ddlValueType")]
        //[RefCodeConstraint("VALIDATION VALUE TYPES")]
        public string ValueType { get; set;}

        public string ValueFrom { get; set;}
        public string ValueTo { get; set;}
    }
}
