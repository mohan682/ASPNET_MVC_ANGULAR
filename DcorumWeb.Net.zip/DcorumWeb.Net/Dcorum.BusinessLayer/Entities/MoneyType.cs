﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Contracts;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities
{
    public class MoneyType : BaseEntity
    {
        [Key]
        public int? CaseMoneyTypeGroupDetailKey { get; set; }

        public int? CaseMoneyTypeGroupKey { get; set; }

        [IgnoreDataMember]
        public int MoneyTypeGroupKey { get; set; }

        [IgnoreDataMember]
        public int MoneyTypeKey { get; set; }

        public int MoneyTypeNumber { get; set; }

        [IgnoreDataMember]
        public string MoneyTypeName { get; set; }

        [IgnoreDataMember]
        public string MoneyTypeDescription { get; set; }

        //public int? FundingRateKey { get; set; }

        public string TransactionRuleCode { get; set; }

        [IgnoreDataMember]
        public string TransactionRuleDescription { get; set; }

        [IgnoreDataMember]
        public string DisplayValueForMoneyType
        {
            get
            {
                return MoneyTypeExtensions.DisplayValueForMoneyType(this);
            }
        }

        [IgnoreDataMember]
        public string DisplayTextForMoneyType
        {
            get { return MoneyTypeExtensions.DisplayTextForMoneyType(this); }
        }
    }


    public static class MoneyTypeExtensions
    {
        [Pure]
        public static string DisplayValueForMoneyType(this MoneyType m)
        {
            return (m.MoneyTypeNumber <= 0 && string.IsNullOrEmpty(m.TransactionRuleCode))
                ? string.Empty
                : string.Format("{0} - {1}", m.MoneyTypeNumber, m.TransactionRuleCode);
        }

        [Pure]
        public static string DisplayTextForMoneyType(this MoneyType m)
        {
            return
                (string.IsNullOrEmpty(m.MoneyTypeDescription) && string.IsNullOrEmpty(m.TransactionRuleDescription))
                    ? string.Empty
                    : string.Format("{0} - {1}", m.MoneyTypeDescription, m.TransactionRuleDescription);

        }
    }
}
