﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.RefCoding;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Constants;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public class MaintenanceMessage : BaseEntity
    {
        public const string LevelScheme = "01"; //Constants.DomainCodes.MaintenanceMessageLevelScheme;

        [Key]
        public int Id { get; set; }

        [RefCodeConstraint(DomainNames.PDI_Maintenance_Message_Type)]
        public RefCode AccessLevelTypeId { get; set; }

        [IgnoreDataMember]
        public string AccessLevelName { get; set; }
        internal string SchemeName { get; set; }
        internal string SchemeExternalId { get; set; }        
        internal string MbgpName { get; set; }
        public string Messsage { get; set; }

        [RefCodeConstraint(DomainNames.PDI_Maintenance_Message_Permission)]
        public RefCode Permission { get; set; }

        public string EffectiveDateTime { get; set; }
        public string ExpiryDateTime { get; set; }

        public string RefCode
        {
            get;
            set;
        }

        [IgnoreDataMember]
        public bool IsSchemeMessageLevel
        {
            get
            {
                return AccessLevelTypeId.IsMatch(LevelScheme);
            }
        }

    }
}
