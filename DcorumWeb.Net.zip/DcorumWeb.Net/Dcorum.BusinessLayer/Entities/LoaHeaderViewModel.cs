﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Entities
{
    public class LoaHeaderViewModel
    {
        public LoaHeaderViewModel()
        {
            AdviserDetail = new LoaAddress();

            FirmDetail = new LoaAddress();

            NetworkDetail = new LoaAddress();
        }

        public LoaAddress AdviserDetail { get; set; }
        public LoaAddress FirmDetail { get; set; }
        public LoaAddress NetworkDetail { get; set; }
    }

    public class AdviserDetail
    {
        [UIHint("txt*")]
        [Display(Name = "Name")]
        [Editable(false)]
        public string Name { get; set; }

        [UIHint("txt*")]
        [Display(Name = "FCA Ref Number")]
        [Editable(false)]
        public string RefNumber { get; set; }
    }

    public class LoaAddress
    {
        [UIHint("txt*")]
        [Display(Name ="Name")]
        [Editable(false)]
        public string Name { get; set; }

        [UIHint("txt*")]
        [Display(Name = "FCA Ref Number")]
        [Editable(false)]
        public string RefNumber { get; set; }

        [UIHint("txt*")]
        [Display(Name = "Email")]
        [Editable(false)]
        public string Email { get; set; }

        [UIHint("txt*")]
        [Display(Name = "Address Line 1")]
        [Editable(false)]
        public string AddressLine1 { get; set; }

        [Display(Name = "Address Line 2")]
        [UIHint("txt*")]
        [Editable(false)]
        public string AddressLine2 { get; set; }

        [UIHint("txt*")]
        [Display(Name = "Address Line 3")]
        [Editable(false)]
        public string AddressLine3 { get; set; }

        [UIHint("txt*")]
        [Display(Name = "City")]
        [Editable(false)]
        public string City { get; set; }

        [UIHint("txt*")]
        [Display(Name = "County")]
        [Editable(false)]
        public string County { get; set; }

        [UIHint("txt*")]
        [Display(Name = "Post Code")]
        [DataType(DataType.PostalCode)]
        [Editable(false)]
        public string PostCode { get; set; }
    }

}
