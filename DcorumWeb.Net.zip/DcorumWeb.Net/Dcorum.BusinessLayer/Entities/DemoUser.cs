﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Enums;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using DCorum.BusinessFoundation.Annotations;
using DCorum.BusinessFoundation.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    [DisplayName("Demo User")]
    public class DemoUser : CommonUser
    {
        public DemoUser()
            :this(null)
        {
        }

        public DemoUser(IDataReader reader)
        {
            UserType = UserType.Demo;
            Build(this,reader);
        }

        [UIHint("txtLongDescription")]
        [Display(Name = "Description:", Order = 80)]
        [StringLength(500)]
        [DataType(DataType.MultilineText)]
        public string LongDescription { get; set; }

        [UIHint("txt*", "debug")]
        [Display(Name = "Demo User Id:", Order = -10)]
        [UiDisplayingHint(UiDisplayMode.Invisible,UiDisplayMode.Displayable)]
        public int? UserAccDemoId { get; set; }

        //[UIHint("ddlShortDescription")]
        //[Display(Name = "Static Response:", Order = 70)]
        //[RefreshProperties(RefreshProperties.Repaint)]
        //[StringLength(50)]
        //[Required]
        internal int? StaticResponseGroupId { get; set; }

        [IgnoreDataMember]
        [UIHint("txtDateOfBirth")]
        [Display(Name = "Date of Birth:", Order = 65)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [DataType(DataType.Date)]
        [Required]
        public DateTime DateOfBirth { get; set; }

        [UIHint("chkLockAccount")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Editable)]
        [Display(Name = "Would you like to lock this account?", Order = 110)]
        public bool IsLocked { get; set; }

        [IgnoreDataMember]
        internal int? AddressOtherId { get; private set; } //used as part of data graph deletion.

        [IgnoreDataMember]
        internal int ResponseGroupsTotal { get; private set; }


        private static void Build(DemoUser toBuild, IDataReader reader)
        {
            if (reader != null)
            {
                toBuild.IsLocked = Convert.ToBoolean(DBHelper.GetIDataReaderInt(reader, "LOCKED"));
                toBuild.LongDescription = DBHelper.GetIDataReaderString(reader, "DESCRIPT");
                toBuild.UserAccDemoId = DBHelper.GetIDataReaderNullableInt(reader, "USER_ACC_DEMO_ID");
                toBuild.StaticResponseGroupId = DBHelper.GetIDataReaderNullableInt(reader, "STATIC_RESPONSE_GROUP_ID");

                toBuild.Title = new RefCode(DBHelper.GetIDataReaderString(reader, "NAMEPREFIX"));
                toBuild.DateOfBirth = DBHelper.GetIDataReaderDateTime(reader, "BIRTHDT");

                toBuild.AddressOtherId = DBHelper.GetIDataReaderNullableInt(reader, "ADDROTHERID");

                toBuild.ResponseGroupsTotal = DBHelper.GetIDataReaderInt(reader, "groupTotal");

                CommonUser.Build(toBuild, reader);
            }
        }
    }
}
