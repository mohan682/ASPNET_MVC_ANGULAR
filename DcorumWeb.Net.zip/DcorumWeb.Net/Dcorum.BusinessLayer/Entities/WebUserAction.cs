﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics.Contracts;
using System.Runtime.Serialization;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.Entities
{
    public class WebUserAction
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public WebUserAction(IDataReader reader)
        {
            Build(this, reader);
        }

        [Key]
        public int WebUserActionId { get; private set; }

        public int ActionId { get; private set; }

        public string ActionName { get; private set; }

        public string ActionDescription { get; private set; }

        public string WebUserAccountNumber { get; private set; }

        public DateTime ActionDate { get; private set; }

        public int ScreenResourceId { get; private set; }

        public string ScreenResourceName { get; private set; }

        public string ScreenResourceDescription { get; private set; }

        public int WebUserAccountId { get; private set; }

        public int SchemeId { get; private set; }

        public string SchemeNumber { get; private set; }

        public string SchemeName { get; private set; }


        [Pure,IgnoreDataMember]
        public string SchemeDisplayName
        {
            get
            {
                if (SchemeId <= 0) return null;
                return string.Format("[{0}] {1}", SchemeNumber, SchemeName);
            }
        }

        private static void Build(WebUserAction toBuild, IDataReader reader)
        {
            toBuild.WebUserActionId = DBHelper.GetIDataReaderInt(reader, "USER_ACTION_ID");
            toBuild.ActionId = DBHelper.GetIDataReaderInt(reader, "ACTION_ID");
            toBuild.ActionName = DBHelper.GetIDataReaderString(reader, "ACTION_NAME");
            toBuild.ActionDescription = DBHelper.GetIDataReaderString(reader, "ACTION_DESCRIPT");
            toBuild.WebUserAccountNumber = DBHelper.GetIDataReaderString(reader, "ACCOUNT_NO");
            toBuild.ActionDate = DBHelper.GetIDataReaderDateTime(reader, "ACTION_DT");
            toBuild.ScreenResourceId = DBHelper.GetIDataReaderInt(reader, "SCREEN_RESOURCE_ID");
            toBuild.ScreenResourceName = DBHelper.GetIDataReaderString(reader, "SCREEN_RESOURCE_NAME");
            toBuild.ScreenResourceDescription = DBHelper.GetIDataReaderString(reader, "SCREEN_RESOURCE_DESCRIPT");
            toBuild.WebUserAccountId = DBHelper.GetIDataReaderInt(reader, "USER_ACC_ID");
            toBuild.SchemeId = DBHelper.GetIDataReaderInt(reader, "SCHEME_ID");
            toBuild.SchemeNumber = DBHelper.GetIDataReaderString(reader, "SCHEME_NUMBER");
            toBuild.SchemeName = DBHelper.GetIDataReaderString(reader, "SCHEME_NAME");
        }

        public object GetTableRowView()
        {
            return WebUserActionExtensions.TableRowView(this);
        }
    }


    internal static class WebUserActionExtensions
    {
        //not yet used!
        [Pure]
        public static object TableRowView(WebUserAction toView)
        {
            var anonViewModel1 = new
            {
                Action_DateTime = toView.ActionDate,
                Screen____ = toView.ScreenResourceDescription,
                Action______ = toView.ActionDescription,
                Account = toView.WebUserAccountNumber,
                Scheme______________________ = toView.SchemeDisplayName
            };

            return anonViewModel1;
        }
    }
}
