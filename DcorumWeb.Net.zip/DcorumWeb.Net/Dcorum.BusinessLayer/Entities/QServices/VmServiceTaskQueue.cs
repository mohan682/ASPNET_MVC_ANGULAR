﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Decorum.WebformsCore.Contractual;

namespace Dcorum.BusinessLayer.Entities.QServices
{
    /// <summary>
    ///     This is specialized case for the New Boarders Transfer Handler.
    ///     Needs to be generic.
    /// </summary>
    [DisplayName("AE New Boarders Service Task")]
    public class VmServiceTaskQueue : BaseEntity
    {

        private IEnumerable<ServiceTaskQueueParam> _qparams;

        [Key]
        public int Id { get; set; }

        private int _serviceTaskId = 139;
        public int ServiceTaskId
        {
            get { return _serviceTaskId; } 
            set { _serviceTaskId = value; }
        }

        public DateTime ScheduleDate { get; set; }

        public DateTime ProcessDate { get; set; }

        public bool IsLocked { get; set; }

        public int ThreadNo { get; set; }

        private bool? _isActive;
        public bool IsActive
        {
            get { return _isActive?? true; }
            set { _isActive = value; }
        }

        private string _status;
        public string Status
        {
            get { return _status ?? (_status = "PE"); }
            set { _status = value; }
        }


        public IEnumerable<ServiceTaskQueueParam> QParams
        {
            get { return _qparams ?? (_qparams = GetTransferHandlerParams()); }
        }

        // Gather parameter Info from the screen.
        [Required]
        [Display(Name = "Control ID:")]
        [UIHint("txtControlId")]
        [RegularExpression("\\d+")]
        public int ControlId { get; set; }

        [Required]
        [Display(Name = "History Control ID:")]
        [UIHint("txtHistoryControlId")]
        [RegularExpression("\\d+")]
        public int HistoryControlId { get; set; }

        [Required]
        [Display(Name = "Data Import File Path (relative to AeNewBoraders Folder):")]
        [UIHint("txtImportFolderName")]
        public string FilePath { get; set; }


        private IEnumerable<ServiceTaskQueueParam> GetTransferHandlerParams()
        {
            IList<ServiceTaskQueueParam> ps = new List<ServiceTaskQueueParam>
                {
                    GetParam("ControlId", 1, "int", ControlId.ToString()),
                    GetParam("HistoryControlId", 2, "int", HistoryControlId.ToString()),
                    GetParam("ClientFileName", 3, "STRING", FilePath),
                    GetParam("UserId",4,"int", UserId.ToString())
                };

            return ps;
        }

        // OK we can use reflection on the properites to do this.
        private ServiceTaskQueueParam GetParam(string name, int order, string type, string value)
        {
            return new ServiceTaskQueueParam
                {
                    Id = Id,
                    Name = name,
                    Order = order,
                    Type = type,
                    Value = value
                };
        }
    }
}