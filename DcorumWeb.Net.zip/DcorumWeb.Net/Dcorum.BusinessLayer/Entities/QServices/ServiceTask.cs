﻿using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.Entities.QServices
{
    public class ServiceTask
    {
        [Key]
        public int Id { get; set; }
    }
}