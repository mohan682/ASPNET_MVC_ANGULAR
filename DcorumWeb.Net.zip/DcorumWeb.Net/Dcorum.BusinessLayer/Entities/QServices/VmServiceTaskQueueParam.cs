﻿using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.Entities.QServices
{
    public class VmServiceTaskQueueParam :BaseEntity
    {
        [Required]
        [Display(Name = "Control ID:")]
        [UIHint("txtControlId")]
        public int ControlId { get; set; }

        [Required]
        [Display(Name = "History Control ID:")]
        [UIHint("txtHistoryControlId")]
        public int HistoryControlId { get; set; }

        [Required]
        [Display(Name = "Results Folder Path:")]
        [UIHint("txtFilePath")]
        public string FilePath { get; set; }
    }
}