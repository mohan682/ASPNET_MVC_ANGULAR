﻿using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.Entities.QServices
{
    public class ServiceTaskQueueParam
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        [Required]
        public string Value { get; set; }

        public int Order { get; set; }

        public string Type { get; set; }
    }
}