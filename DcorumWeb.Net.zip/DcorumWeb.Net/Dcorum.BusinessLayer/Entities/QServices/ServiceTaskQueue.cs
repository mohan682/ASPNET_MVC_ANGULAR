﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.Entities
{
    public class ServiceTaskQueue : BaseEntity
    {
        [Key]
        public int Id { get; set; }

        public int ServiceTaskId { get; set; }

        public DateTime ScheduleDate { get; set; }

        public DateTime ProcessDate { get; set; }

        public bool IsLocked { get; set; }

        public int ThreadNo { get; set; }

        public bool IsActive { get; set; }

        public string Status { get; set; }
    }
}