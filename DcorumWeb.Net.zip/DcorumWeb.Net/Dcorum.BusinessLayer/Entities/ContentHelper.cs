﻿using System;
using System.IO;

namespace Dcorum.BusinessLayer.Entities
{
    /// <summary>
    /// Helper class to deal with certain servie based aspects of the Content entity.
    /// </summary>
    public static class ContentHelper
    {

        public static void Perist(Content content, Stream toPersist)
        {
            
        }

        public static string WorkOutImageLocation(Content content, string location, string fileName, string type)
        {
             string relativePath = string.Format(@"\Content\{0}\", type);

            if (!string.IsNullOrEmpty(content.Provider))
            {
                relativePath += string.Concat(content.Provider, @"\");
            }
            else if (!string.IsNullOrEmpty(content.Product))
            {
                relativePath += string.Concat(content.Product, @"\");
            }
            else if (content.SchemeId.HasValue)
            {
                relativePath += string.Concat("scheme", content.SchemeId.Value, @"\");
            }
            else if (content.MemberGroupId.HasValue)
            {
                relativePath += string.Concat("mg", content.MemberGroupId.Value, @"\");
            }
            else if (content.IOClientId.HasValue)
            {
                relativePath += string.Concat("mg", content.IOClientId.Value, @"\");
            }

            string fileDirectory = string.Concat(location, relativePath);

            if (!Directory.Exists(fileDirectory))
                Directory.CreateDirectory(fileDirectory);

            string finalFileName = GetFileName(fileName);

            content.Value = string.Concat(relativePath.Replace(@"\", @"/"), finalFileName);
            return string.Concat(fileDirectory, finalFileName);
        }

        private static string GetFileName(string fileName)
        {
            return string.Concat(DateTime.Now.Ticks, "_", fileName);
        }
    }
}
