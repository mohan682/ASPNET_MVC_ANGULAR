﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    public class ContentSearchCriteria
    {
        [RefCodeConstraint(DomainNames.PDI_Content_Component)]
        [UIHint("ddlComponent")]
        public string Component { get; set; }

        [RefCodeConstraint(DomainNames.PDI_Content_Type)]
        [UIHint("ddlContentType")]
        public string ContentType { get; set; }

        public bool IsSchemeSelected{ get; set; }       

        public bool IsProviderSelected { get; set; }

        public bool IsProductSelected { get; set; }

        public int? SchemeId { get; set; }

        public int? MemberGroupId{ get; set; }

        [RefCodeConstraint(DomainNames.UEXT_Provider_Code)]
        [UIHint("ddlProviders")]
        public string Provider{ get; set; }

        [RefCodeConstraint(DomainNames.UEXT_Product_Code)]
        [UIHint("ddlProducts")]
        public string Product { get; set; }

        public bool ShowPending { get; set; }

        public bool ShowUnpublished { get; set; }

        public bool ShowExpired { get; set; }

        public string TargetSearch{ get; set; }

        public bool IsDefaultSelected { get; set; }
    }
}
