﻿using System.ComponentModel.DataAnnotations;
using System.Data;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.Entities
{
    public class TargetPlanAccount
    {
        public TargetPlanAccount(IDataReader reader)
        {
            Build(this, reader);
        }

        [Key]
        public int NameId { get; set; }

        public string AccountNumber { get; set; }

        public int SchemeId { get; set; }

        public string SchemeNumber { get; set; }

        public string SchemeName { get; set; }

        public string SchemeDisplayName
        {
            get
            {
                return string.Format("[{0}] {1}", SchemeNumber, SchemeName);
            }
        }

        public bool IsPrimary { get; set; }

         
        private static void Build(TargetPlanAccount toBuild, IDataReader reader)
        {
            toBuild.NameId = DBHelper.GetIDataReaderInt(reader, "NAMEID");
            toBuild.AccountNumber = DBHelper.GetIDataReaderString(reader, "USER_ACCOUNT_NUMBER");
            toBuild.SchemeId = DBHelper.GetIDataReaderInt(reader, "SCHEME_ID");
            toBuild.SchemeNumber = DBHelper.GetIDataReaderString(reader, "SCHEME_NUMBER");
            toBuild.SchemeName = DBHelper.GetIDataReaderString(reader, "SCHEME_NAME");
            toBuild.IsPrimary = DBHelper.GetIDataReaderNullableInt(reader, "PRIMARY") == 1 ? true : false;
        }

        //not yet used!
        public static object TableRowView(TargetPlanAccount toView)
        {
            var anonViewModel1 = new
            {
                Account_____ = toView.AccountNumber,
                Scheme___________________________ = toView.SchemeDisplayName,
                Primary = (toView.IsPrimary) ? "Yes" : "No",
                //Impersonation_BTN_Launch_TargetPlan_BTN_0 = toView.AccountNumber,             
            };

            return anonViewModel1;
        }
    }
}
