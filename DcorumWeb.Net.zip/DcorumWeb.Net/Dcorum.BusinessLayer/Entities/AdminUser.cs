﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Enums;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using DCorum.ViewModelling.Annotations;
using DCorum.ViewModelling.Contractual;
using DcorumWeb.Utilities;

namespace Dcorum.BusinessLayer.Entities
{

    public class AdminUser : CommonUser
    {
        public AdminUser()
            :this(null)
        {
        }

        public AdminUser(IDataReader reader)
        {
            if (reader !=null ) Build(this, reader);
            UserType = UserType.Admin;
        }

        [IgnoreDataMember]
        //comment out before release!
        //[UIHint("chkDeactivated", "search")]
        //[Display(Name = "Show Deactivated Users:")]
        //[SearchWhereFlag("NOTACTIVE")]
        public bool IsNotActive { get; set; }

        [IgnoreDataMember]
        public bool IsValid { get; set; }

        [UIHint("txtPasswordLastChanged")]
        [Display(Name = "Password last changed:", Order = 63)]
        [Editable(false)]
        public DateTime? PasswordLastChanged { get; set; }

        [UIHint("chkForcePasswordChange")]
        [Display(Name = "Force password to change at next login:", Order = 64)]
        public bool ForcePasswordChange { get; set; }

        [IgnoreDataMember]
        [UIHint("txtConfirmPassword")]
        [Display(Name = "Confirm Password:", Order = 101)]
        [Required]
        [StringLength(20, MinimumLength = 8)]
        [RegularExpression(pattern: @"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}$", ErrorMessage = "Password is not valid")]
        [PasswordPropertyText]
        [DataType(DataType.Password)]
        //[MustMatch("txtPassword")]
        public string ConfirmPassword { get; set; }

        [UIHint("txtDCorUserName")]
        [Display(Name = "Linked Dcorum Login:", Order = 61)]
        public string DCorUserName { get; set; }

        [UIHint("txtAwdUserId")]
        [Display(Name = "AWD User ID:", Order = 62)]
        [StringLength(8)]
        public string AwdUserId { get; set; }

        private static void Build(AdminUser toBuild, IDataReader reader)
        {
            toBuild.IsNotActive = reader.FetchBooleanN("NOTACTIVE") ?? false;
            toBuild.IsValid = reader.FetchAsValue<int>("role_count") == 1;
            toBuild.DCorUserName = reader.FetchAsString("USER_NAME");
            toBuild.ForcePasswordChange = DBHelper.GetIDataReaderInt(reader, "FORCEPASSWORDRESET") == 1;
            toBuild.Title = reader.FetchTextualRefCode("NAMEPREFIX");
            toBuild.AwdUserId = reader.FetchAsString("Account_Id");
            CommonUser.Build(toBuild, reader);
        }
    }


    public abstract class CommonUser : BaseEntity
    {
        /// <summary>
        /// [INJECTION]
        /// </summary>
        [IgnoreDataMember]
        public static Func<string, string> HowToEncrypt { get; set; }

        [Display(Name = "Name Id:", Order = 20)]
        [UIHint("txtNameId")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        [Editable(false)]
        [UiSearchable("NAMEID", null)]
        public int NameId { get; set; }

        [Key]
        [AmbientValue(0)]
        [Display(Name = "User Account Id:", Order = 10)]
        [UIHint("txtUserAccountId")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        [Editable(false)]
        public int AccountId { get; set; }

        [UIHint("txtUserName")]
        [Display(Name = "User name:", Order = 30)]
        [Required]
        [RegularExpression(pattern: RegExConstants.EmailRegEx, ErrorMessage = "User Name is not valid, enter a valid email(Ex: test@companyname.com)")]
        [DataType(DataType.EmailAddress)]
        [UiSearchable("EMAILDATA", "LIKE")]
        public string UserName { get; set; }

        [UIHint("ddlTitle")]
        [Display(Name = "Title:", Order = 35)]
        [RefCodeConstraint(DomainNames.PersonTitle)]
        [Required]
        public RefCode Title { get; set; }


        [Display(Name = "First name:", Order = 40)]
        [UIHint("txtFirstName")]
        [Required]
        [StringLength(50)]
        [RegularExpression(pattern: RegExConstants.MultiPartName)]
        [UiSearchable("PER.FIRSTNAME", "LIKE")]
        public string FirstName
        {
            get
            {
                if (String.IsNullOrEmpty(_firstName)) return String.Empty;
                return _firstName.Trim();
            }
            set
            {
                if (String.IsNullOrEmpty(value)) _firstName = "";
                _firstName = value.Trim();
            }
        }

        [IgnoreDataMember]
        private string _firstName;

        [Display(Name = "Middle name:", Order = 50)]
        [UIHint("txtMiddleName")]
        [RegularExpression(pattern: RegExConstants.MultiPartName)]
        [UiSearchable("PER.MIDNAME", "LIKE")]
        public string MidName { get; set; }

        [Display(Name = "Last name:", Order = 60)]
        [UIHint("txtLastName")]
        [Required]
        [StringLength(50)]
        [RegularExpression(pattern: RegExConstants.MultiPartName)]
        [UiSearchable("PER.LASTNAME", "LIKE")]
        public string LastName
        {
            get
            {
                if (String.IsNullOrEmpty(_lastName)) return String.Empty;
                return _lastName.Trim();
            }
            set
            {
                if (String.IsNullOrEmpty(value)) _lastName = "";
                _lastName = value.Trim();
            }
        }

        [IgnoreDataMember]
        private string _lastName;

        [IgnoreDataMember]
        [ScaffoldColumn(true)]
        public UserType UserType { get; protected set; }

        [IgnoreDataMember]
        [UIHint("chkPasswordUpdate")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Editable)]
        [Display(Name = "Would you like to update password?", Order = 90)]
        [RefreshProperties(RefreshProperties.Repaint)]
        public bool PasswordModeOn { get; set; }

        [UIHint("txtPassword")]
        [Display(Name = "Password:", Order = 100)]
        [Required]
        [StringLength(20, MinimumLength = 8)]
        [RegularExpression(pattern: @"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}$", ErrorMessage = "Password is not valid")]
        [PasswordPropertyText]
        [DataType(DataType.Password)]
        public string Password
        {
            get
            {
                if (!PasswordModeOn) return String.Empty;
                return _password;
            }
            set
            {
                if (!PasswordModeOn) throw new InvalidOperationException();
                _password = value;
            }
        }

        [IgnoreDataMember]
        private string _password;


        public string GetSecurePassword()
        {
            return GetSecurePassword(Password);
        }

        public static void Build(CommonUser toBuild, IDataReader reader)
        {
            toBuild.AccountId = DBHelper.GetIDataReaderInt(reader, "USER_ACC_ID");
            toBuild.NameId = DBHelper.GetIDataReaderInt(reader, "NAMEID");

            toBuild.FirstName = DBHelper.GetIDataReaderString(reader, "FIRSTNAME");
            toBuild.MidName = DBHelper.GetIDataReaderString(reader, "MIDNAME");
            toBuild.LastName = DBHelper.GetIDataReaderString(reader, "LASTNAME");
            toBuild.UserName = DBHelper.GetIDataReaderString(reader, "EMAILDATA");
            toBuild.UserType = (UserType)DBHelper.GetIDataReaderInt(reader, "USER_TYPE");
        }

        internal static string GetSecurePassword(string toEncrypt)
        {
            if (HowToEncrypt == null || String.IsNullOrWhiteSpace(toEncrypt)) throw new InvalidOperationException();
            string result = HowToEncrypt(toEncrypt);

            if (result.EqualsOIC(toEncrypt)) throw new InvalidOperationException("Failed to encrypt");

            return result;
        }
    }
}
