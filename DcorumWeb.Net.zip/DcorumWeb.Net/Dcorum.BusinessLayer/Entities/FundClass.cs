﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using DCorum.ViewModelling.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public class FundClass 
    {
        [Key]
        public int FundClassId { get; set; }

        [UIHint("txtFundDescriptionId")]
        [Display(Name = "Fund Identifier:")]
        [Editable(false)]
        public string FundDescriptionId { get; set; }

        [IgnoreDataMember]
        public string FundShortName { get; set; }

        [IgnoreDataMember]
        public string FundType { get; set; }

        [UIHint("txtFundLongName")]
        [Display(Name = "Fund Name:")]
        [Editable(false)]
        public string FundLongName { get; set; }

        [UIHint("txtBitMapLocation")]
        [Display(Name = "Performance Graph Location:")]
       // [Editable(false)]
        public string BitMapLocation { get; set; }

        [UIHint("txtAnnualManagementCharge")]
        [Display(Name = "Annual Management Charge:")]
        [Required]
        [Range(0D, 9.99D)]
        [RegularExpression(RegExConstants.CorrectFormat)]
        public decimal AnnualManagementCharge { get; set; }

        [UIHint("txtAdditionalCharge")]
        [Display(Name = "Additional Charge:")]
        [Range(-9.99D, 9.99D)]
        [RegularExpression(RegExConstants.CorrectFormat)]
        public decimal AdditionalCharge { get; set; }

        // [Editable(false)]
        [RefreshProperties(RefreshProperties.Repaint)]
        [UIHint("rdbLifepathFund")]
        [Display(Name = "Is LifePath Fund:")]
        //[RefreshProperties(RefreshProperties.Repaint)]
        public bool IsLifepathFund { get; set; }


        #region lifepath changes
        //[Required]
        [RefreshProperties(RefreshProperties.Repaint)]
        [UIHint("ddlLifePathPhase")]
        [Display(Name = "LifePath Phase:")]
        [RefCodeConstraint("LP_PHASE")]
        public RefCode LifePathPhase { get; set; }

        //[Required]
        //[RefreshProperties(RefreshProperties.Repaint)]
        [UIHint("ddlLifePath")]
        [Display(Name = "LifePath Type:")]
       // [RefCodeConstraint("LIFEPATH_TYPE")]
        public RefCode LifePathType { get; set; }      

        [Required] //when IsLifepathAndDated
        [UIHint("txtStartYear")]
        [Display(Name = "LifePath Target Start Year:")]
        //[RegularExpression(RegExConstants.YearWithDefault0OrNullFormat)]
        [Range(2000, 9999)]
        public int? LifepathTargetStartYear { get; set; }

        [Required] //when IsLifepathAndDated
        [UIHint("txtEndYear")]
        [Display(Name = "LifePath Target End Year:")]
        //[RegularExpression(RegExConstants.YearWithDefault0OrNullFormat)]
        [Range(2000, 9999)]
        public int? LifepathTargetEndYear { get; set; }

        [Required] //when IsLifepathAndDated
        [Display(Name = "Glidepath End Date: (dd/mm/yyyy)")]
        [UIHint("txtGlidepathEndDate")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [RegularExpression(RegExConstants.DateFormat)]
        [DefaultValue(typeof(DateTime), null)]
        [Range(typeof(DateTime), "01/01/1900", "31/12/3000")]
        public DateTime? GlidepathEndDate
        {
            get;
            set;
        }

        #endregion

       // [Obsolete("implement LifePath changes instead")]
       // [UIHint("txtLifepathTargetYear")]
       // [Display(Name = "Lifepath Target Year:")]
       //// [Range(2000, 9999)]
       // [RegularExpression(RegExConstants.YearWithDefault0OrNullFormat)]
       // public int? LifepathTargetYear { get; set; }

        [UIHint("txtGrowthRateLow")]
        [Display(Name = "Illustration Growth Rate – Low Basis:")]
        [Range(-3.00D, 2.00D)]
        [RegularExpression(RegExConstants.CorrectFormat, ErrorMessage = "Value must be numeric and should not start with special character.")]
        public decimal? GrowthRateLow { get; set; }

        [UIHint("txtGrowthRateMid")]
        [Display(Name = "Illustration Growth Rate – Mid Basis:")]
        [Range(-3.00D, 5.00D)]
        [RegularExpression(RegExConstants.CorrectFormat, ErrorMessage = "Value must be numeric and should not start with special character.")]
        public decimal? GrowthRateMid { get; set; }

        [UIHint("txtGrowthRateHigh")]
        [Display(Name = "Illustration Growth Rate – High Basis:")]
        [Range(-3.00D, 8.00D)]
        [RegularExpression(RegExConstants.CorrectFormat, ErrorMessage = "Value must be numeric and should not start with special character.")]
        public decimal? GrowthRateHigh { get; set; }

        [UIHint("txtGrowthRateSmpi")]
        [Display(Name = "Illustration Growth Rate – SMPI Basis:")]
        [Range(-3.00D, 8.00D)]
        [RegularExpression(RegExConstants.CorrectFormat, ErrorMessage = "Value must be numeric and should not start with special character.")]
        public decimal? GrowthRateSMPI { get; set; }


        [IgnoreDataMember]
        [Required]
        public bool? IsDatedLifepathFund { get; set; }


        public static object TableRowView(FundClass model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.FundClassId,
                Fund_Class_Identifier = model.FundDescriptionId.ToString(),
                Fund_Class_Name_______________________ = model.FundLongName,
                Annual_Management_Charge = model.AnnualManagementCharge,
                Is_Lifepath_Fund = model.IsLifepathFund,
                Lifepath_Type = model.LifePathType?.RefCd,
                Lifepath_Phase = model.LifePathPhase?.RefCd,
                Performance_Graph_Location____________________________________________________________________ = model.BitMapLocation
            };

            return facade1;
        }

    }
}
