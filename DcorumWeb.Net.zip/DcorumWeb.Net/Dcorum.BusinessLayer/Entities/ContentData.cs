﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.Entities
{

    [Serializable]
    public class ContentData
    {
        internal ContentData(int parentId) : base()
        {
            ContentId = parentId;
        }

        [Key]
        public int Id
        {
            get;
            set;
        }

        [Required]
        public int ContentId
        {
            get;
            set;
        }

        public Byte[] BinaryData
        {
            get; set;
        }


    }
}
