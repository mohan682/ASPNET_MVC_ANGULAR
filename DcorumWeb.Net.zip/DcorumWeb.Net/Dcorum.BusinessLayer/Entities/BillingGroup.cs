﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public class BillingGroup
    {
        [Key]
        public int BillingGroupId { get; set; }

        [UIHint("txtDescription")]
        [Editable(false)]
        [Display(Name = "Billing Group:")]
        public string Description { get; set; }

        [Required]
        [Display(Name = "Bill Due Day:")]
        [UIHint("ddlBillDueDay")]
        [RefCodeConstraint(DomainNames.DatesInMonth, OrderByRefCode = true)]
        public string BillDueDay { get; set; }

        [UIHint("chkApplyOPRA")]
        [Display(Name = "Apply OPRA reminder checks:")]
        public bool ApplyOPRAChecks { get; set; }

        [Required]
        [Display(Name = "Frequency:")]
        [UIHint("ddlFrequency")]
        [RefCodeConstraint("UEXT ILLUST FREQ CD")]
        //[RefCodeConstraint("UEXT ILLUST FREQ CD")]
        public string Frequency { get; set; }

        [UIHint("chkActiveLeaverBillingGroup")]
        [Display(Name = "Active Leaver Billing Group:")]
        [RefreshProperties(RefreshProperties.Repaint)]
        public bool ActiveLeaverBillingGroup { get; set; }

        [UIHint("chkOCPEnabled")]
        [Display(Name = "OCP Enabled?:")]
        [RefreshProperties(RefreshProperties.Repaint)]
        public bool OCPEnabled { get; set; }

        [Required]
        [Display(Name = "Contribution Method Checking :")]
        [UIHint("ddlContributionMethodChecking")]
        [RefCodeConstraint("OCP VALIDATION METHOD")]
        public string ContributionMethodChecking { get; set; }

        [UIHint("chkDDEnabled")]
        [Display(Name = "Direct Debit Enabled:")]
        public bool DDPaymentEnabled { get; set; }

        public bool ContributionChecking { get; set; }

        public string frequency_descript { get; set; }

        [UIHint("chkWorkplaceISAEnabled")]
        [Display(Name = "Workplace ISA Enabled:")]
        [RefreshProperties(RefreshProperties.Repaint)]
        public bool WorkplaceISAEnabled { get; set; }

        public string SchemeWorkplaceIsaRef { get; set; }


        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public BillingGroup()
        {
        }

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected BillingGroup(IDataReader reader)
        {
            Build(this, reader);
        }


        private static void Build(BillingGroup billingGroup, IDataReader reader)
        {
            billingGroup.BillingGroupId = DBHelper.GetIDataReaderInt(reader, "BGRP_KEY");
            billingGroup.OCPEnabled = reader.FetchAsString("ABP_ENABLED").IntoBoolean() ?? false;

            billingGroup.ApplyOPRAChecks = reader.FetchAsString("OPRA_APPLIES").IntoBoolean() ?? false;

            billingGroup.DDPaymentEnabled = reader.FetchAsString("ABP_DIRECT_DEBIT_ENABLED").IntoBoolean() ?? false;

            billingGroup.Description = reader.FetchAsString("DESCRIPT");
            billingGroup.ActiveLeaverBillingGroup = reader.FetchAsString("ACTIVE_LEAVER_BILLGRP").IntoBoolean() ?? false;
            billingGroup.BillDueDay = reader.FetchAsString("BILL_DUE_DAY");

            // this line added to fix issue when saving day 1st to 9th as would not match ref code witout leading zero.. CSG-3392
            if (billingGroup.BillDueDay.Length < 2)
            {
                billingGroup.BillDueDay = "0" + billingGroup.BillDueDay;
            }

            billingGroup.Frequency = reader.FetchAsString("FREQUENCY");
            billingGroup.ContributionMethodChecking = reader.FetchAsString("ABP_CHECK_CONTRIBUTIONS");

            billingGroup.WorkplaceISAEnabled = reader.FetchAsString("ABP_WORKPLACE_ISA_ENABLED").IntoBoolean() ?? false;

            billingGroup.SchemeWorkplaceIsaRef = reader.FetchAsString("WORKPLACE_ISA_REF") ;
        }

    }

}