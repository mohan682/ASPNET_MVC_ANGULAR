﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Linq;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.Entities
{
    public class TPAccountSetUp
    {
        internal TPAccountSetUp(IDataReader reader)
        {
            Build(this, reader);
        }

        [Key]
        public int NameId { get; private set; }
        public int UserAccId { get; private set; }

        public int CaseMemberKey { get; private set; }

        public int? UextCaseMemberKey { get; private set; }

        public int? EmailAddressId { get; private set; }

        public int? UextAddrId { get; private set; }

        public bool IsPrimary { get; private set; }

        public bool IsContactEmail { get; private set; }

        public string EmailType { get; private set; }
        public string EmailData { get; private set; }
        public int? AddrId { get; private set; }

        public bool IsEmailDataBlank
        {
            get
            {
                return String.IsNullOrWhiteSpace(EmailData);
            }
        }

        public string DefaultEmailData
        {
            get
            {
                return "A000" + CaseMemberKey + "@aegon.co.uk";
            }
        }

        private static void Build(TPAccountSetUp accountInfoToSetUp, IDataReader reader)
        {
            accountInfoToSetUp.UserAccId = DBHelper.GetIDataReaderInt(reader, "USER_ACC_ID");
            accountInfoToSetUp.NameId = DBHelper.GetIDataReaderInt(reader, "NAMEID");
            accountInfoToSetUp.CaseMemberKey = DBHelper.GetIDataReaderInt(reader, "CASE_MBR_KEY");
            accountInfoToSetUp.UextCaseMemberKey = DBHelper.GetIDataReaderNullableInt(reader, "UEXT_MBR_KEY");
            accountInfoToSetUp.EmailAddressId = DBHelper.GetIDataReaderNullableInt(reader, "ADDROTHERID");
            accountInfoToSetUp.UextAddrId = DBHelper.GetIDataReaderNullableInt(reader, "UEXT_ADDROTH_ID");

            accountInfoToSetUp.AddrId = DBHelper.GetIDataReaderNullableInt(reader, "AddrId");

            accountInfoToSetUp.IsPrimary = reader.FetchBooleanN("Primary") ?? false;
            accountInfoToSetUp.IsContactEmail = reader.FetchBooleanN("IsContactEmail") ?? false;
            accountInfoToSetUp.EmailType = reader.FetchAsString("EMAILTYPE");
            accountInfoToSetUp.EmailData = reader.FetchAsString("EMAILDATA");
        }

        /// <summary>
        /// Modifies Primary and possibly Email name and type too.
        /// </summary>
        internal void PreSave(bool isEmailRegisteredElsewhere)
        {
            bool isEmailBlank = IsEmailDataBlank;

            if (isEmailBlank || isEmailRegisteredElsewhere)
            {
                EmailType = "01";
                EmailData = DefaultEmailData;
            }

            if (!IsPrimary) IsPrimary = true;
        }

    }
}
