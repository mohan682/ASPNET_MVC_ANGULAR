﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Entities.BulkSwitching
{
	[Serializable]
	public class BulkSwitchLoad
	{
		[UIHint("litJobName")]
		[Display(Name = "Job Name:")]
		[Editable(false)]
		public string JobName { get { return "Load Bulk Switch"; } }

        //[UIHint("txtDataFile")]
        //[Display(Name = "Data File:")]
        //[DataType(DataType.Url)]
        //[Editable(true)]
        //[Required]
        //public string DataFile { get; set; }
	}

}
