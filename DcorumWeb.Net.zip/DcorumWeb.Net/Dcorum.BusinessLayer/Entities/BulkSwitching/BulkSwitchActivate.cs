﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using Dcorum.Utilities.Contractual;

namespace Dcorum.BusinessLayer.Entities.BulkSwitching
{
	[Serializable]
	public class BulkSwitchActivate
	{
		[UIHint("litJobName")]
		[Display(Name = "Job Name:")]
		[Editable(false)]
		public string JobName { get { return "Activate Bulk Switch"; } }

		[Key]
		[UIHint("txtRefNo")]
		[Display(Name = "Ref No:")]
		[Required]
		public string RefNo { get; set; }
	}
}
