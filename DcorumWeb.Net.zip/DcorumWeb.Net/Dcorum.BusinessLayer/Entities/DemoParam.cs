﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
//using System.Drawing;
using System.Runtime.Serialization;
using DCorum.BusinessFoundation.Annotations;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    [DisplayName("Overridden Parameters")]
    public class DemoParam
    {

        //[Display(Name = "Colour:")]
        //[UIHint("txtColor")]
        //public Color col1 { get; set; }

        [Key]
        [Display(Name = "Demo Param Id:")]
        [UIHint("litDemoParamId")]
        [UiDisplayingHint(UiDisplayMode.Invisible)]
        public int? DemoParamId { get; set; }

        //[ForeignKey]
        //[ParentId]
        [ScaffoldColumn(true)]
        public int DemoParamUserAccId { get; set; }

        [Required]
        [Display(Name = "Ref Code Description:")]
        [RefCodeConstraint(Constants.SpecialDomainNames.DemoParamKeys)]
        [UIHint("ddlParamCode")]
        [RefreshProperties(RefreshProperties.Repaint)]
        [UiDisplayingHint(UiDisplayMode.Editable, UiDisplayMode.Displayable)]
        public RefCode DemoParamCode { get; set; }

        [Required]
        [Display(Name = "Display Value:")]
        [UIHint("txtParamVal")]
        [StringLength(256)]
        [UiBypassXssDefence]
        public string DemoParamValue { get; set; }

        [IgnoreDataMember]
        [Display(Name = "Value To Find:")]
        [UIHint("litOriginalValue")]
        public string OriginalValue
        {
            get
            {
                if (DemoParamCode == null) return null;
                return DemoParamCode.LongDesc;
            }

        }
    }
}
