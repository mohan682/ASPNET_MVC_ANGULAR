﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using System.Collections.Generic;
using DCorum.BusinessFoundation.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public sealed class SchemeFull :Scheme
    {

        public DateTime? StagingDate { get; set; }
        public DateTime? PayrollStartDate { get; set; }
        public int? PayrollPeriodStart { get; set; }
        public bool IsContractuallyEnrolled { get; set; }

        [RefCodeConstraint("LIFEPATH_TYPE")]
        [UIHint("ddlLifePathTypeDefault")]
        public string LifePathTypeDefault { get; set; }

        [UIHint("chkDrawdownMemberOverride")]
        [Required]
        public bool DrawdownMemberOverrideModeOn { get; set; }

        [UIHint("chkIsaMbrOverrideEnabled")]
        [Required]
        public bool IsaMemberOverrideEnabled { get; set; }


        #region "target plan related settings"

        [UIHint("chkTargetPlanEnabled")]
        public int TargetPlanEnabled { get; set; }

        [UIHint("chkSTPDisabled")]
        public int? STPDisabled { get; set; }

        [UIHint("chkIsAssociatedDBScheme")]
        public int HasAssociatedDBScheme { get; set; }

        [UIHint("chkShortFall")]
        public int? ShortFall { get; set; }

        [UIHint("chkTaxLiability")]
        public int? TaxLiability { get; set; }

        [UIHint("ddlInvestmentsActive")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? InvestmentPermissionActive { get; set; }

        [UIHint("ddlContributionDeferred")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? ContribPermissionDeferred { get; set; }

        [UIHint("ddlPersonalActive")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? PersonalDetailsPermissionActive { get; set; }

        [UIHint("ddlContactActive")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? ContactDetailsPermissionActive { get; set; }

        [UIHint("ddlTRAActive")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? SetTRAPermissionActive { get; set; }

        [UIHint("ddlSecurityActive")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? SecurityDetailsPermissionActive { get; set; }

        [UIHint("ddlInvestmentDeferred")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? InvestmentPermissionDeferred { get; set; }

        [UIHint("ddlContributionActive")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? ContribPermissionActive { get; set; }

        [UIHint("ddlPersonalDeferred")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? PersonalDetailsPermissionDeferred { get; set; }

        [UIHint("ddlContactDeferred")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? ContactDetailsPermissionDeferred { get; set; }

        [UIHint("ddlTRADeferred")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? SetTraPermissionDeferred { get; set; }

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHideMessageCentre")]
		public int? HideMessageCentre { get; set; }

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHideMyPensionTab")]
		public int? HideMyPensionTab { get; set; }

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHidePensionEssentialsTab")]
		public int? HidePensionEssentialsTab { get; set; }

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHideMyIncomeTab")]
		public int? HideMyIncomeTab { get; set; }

        #endregion


        [Required]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [UIHint("ddlHideISATab")]
        public int? HideISATab { get; set; }


        [Required]
		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [UIHint("ddlPayrollAuto")]
		public int? PayrollAuto  { get; set; }

        [UIHint("txtEnrolmentStartDate")]
        public string EnrolmentStartDate { get; set; }

        [UIHint("txtAnnualIncomeIncreaseDate")]
        public string AnnualIncomeIncreaseDate { get; set; }

        #region new flags

        [UIHint("ddlWorkforce")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? WorkforceAccessLevel { get; set; }

        [UIHint("ddlOcp")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? OcpAccessLevel { get; set; }

        [UIHint("ddlReportManager")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? ReportManangerAccessLevel { get; set; }

        [UIHint("ddlMemberSearch")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? MemberSearchAccessLevel { get; set; }

        [UIHint("ddlMessageCenter")]
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        public int? MessageCenterAccessLevel { get; set; }

        [UIHint("ddlDecumeSchemes")]
        public int? AssociatedDecumeScheme { get; set; }

        #endregion

        [IgnoreDataMember]
        internal Func<SchemeFull, Scheme[]> FetchDecumSchemesTechnique
        {
            set
            {
                if ( value == null) throw new InvalidOperationException();
                _fetchDecumSchemesTechnique = value;
            }
        }

        [IgnoreDataMember]
        private Func<SchemeFull, Scheme[]> _fetchDecumSchemesTechnique;

        [IgnoreDataMember]
        public Scheme[] AssociatedDecumSchemes
        {
            get
            {
                return _fetchDecumSchemesTechnique.Invoke(this);
            }
        }

        [IgnoreDataMember]
        [RefCodeConstraint("UEXT CASE INV")]
        public string InvestmentStructureCode { get; private set; }


        [UIHint("txtWorkplaceISA")]
        [RegularExpression(@"[\d]{4}")]
        public string WorkplaceIsaRef { get; set; }


        #region ...Creational...

        public SchemeFull(IDataReader reader, string[] columnNames )
        {
            Scheme.BuildBasic(this, reader, columnNames );
            BuildRemainder(this,reader);   
         }


        private static void BuildRemainder(SchemeFull schemeRec, IDataReader reader)
        {
            schemeRec.TargetPlanEnabled = DBHelper.GetIDataReaderInt(reader, "TARGET_PLAN_ENABLED");
            schemeRec.STPDisabled = DBHelper.GetIDataReaderNullableInt(reader, "STP_DISABLED");
            schemeRec.HasAssociatedDBScheme = DBHelper.GetIDataReaderInt(reader, "HAS_ASSOCIATED_DB_SCHEME");

            //schemeRec.LifePathVintageModeOn = reader.FetchBooleanN("LIFEPATH_VINTAGE_ENABLED") ?? false;
            schemeRec.LifePathTypeDefault = reader.FetchAsString("LIFEPATH_TYPE_DEFAULT");
            schemeRec.DrawdownMemberOverrideModeOn = reader.FetchBooleanN("DRAWDOWN_MBR_OVERRIDE_ENABLED") ?? false;
            schemeRec.IsaMemberOverrideEnabled = reader.FetchBooleanN("ISA_MBR_OVERRIDE_ENABLED") ?? false;

            schemeRec.ShortFall = DBHelper.GetIDataReaderNullableInt(reader, "SHORTFALL");
            schemeRec.TaxLiability = DBHelper.GetIDataReaderNullableInt(reader, "TAX_LIABILITY");

            schemeRec.InvestmentPermissionActive = DBHelper.GetIDataReaderNullableInt(reader, "INVESTMENTS_PERMISSION_ID");
            schemeRec.ContribPermissionActive = DBHelper.GetIDataReaderNullableInt(reader, "CONTRIBUTION_PERMISSION_ID");
            schemeRec.PersonalDetailsPermissionActive = DBHelper.GetIDataReaderNullableInt(reader, "PERSONAL_DETAILS_PERMISSION_ID");
            schemeRec.ContactDetailsPermissionActive = DBHelper.GetIDataReaderNullableInt(reader, "CONTACT_DETAILS_PERMISSION_ID");
            schemeRec.SetTRAPermissionActive = DBHelper.GetIDataReaderNullableInt(reader, "SET_TRA_PERMISSION_ID");
            schemeRec.SecurityDetailsPermissionActive = DBHelper.GetIDataReaderNullableInt(reader, "SECURITY_DETAILS_PERMISSION_ID");

            schemeRec.InvestmentPermissionDeferred = DBHelper.GetIDataReaderNullableInt(reader, "INVESTMENTS_DEF_PERMISSION_ID");
            schemeRec.ContribPermissionDeferred = DBHelper.GetIDataReaderNullableInt(reader, "CONTRIBUTION_DEF_PERMISSION_ID");
            schemeRec.PersonalDetailsPermissionDeferred = DBHelper.GetIDataReaderNullableInt(reader, "PERSONAL_DTL_DEF_PERMISSION_ID");
            schemeRec.ContactDetailsPermissionDeferred = DBHelper.GetIDataReaderNullableInt(reader, "CONTACT_DTL_DEF_PERMISSION_ID");
            schemeRec.SetTraPermissionDeferred = DBHelper.GetIDataReaderNullableInt(reader, "SET_TRA_DEF_PERMISSION_ID");

            schemeRec.HideMessageCentre = reader.FetchAsNullable<int>("HIDE_MESSAGE_CENTRE");
            schemeRec.HideMyPensionTab = reader.FetchAsNullable<int>("HIDE_MY_PENSION_TAB");
            schemeRec.HidePensionEssentialsTab = reader.FetchAsNullable<int>("HIDE_PENSION_ESSENTIALS_TAB");
            schemeRec.HideMyIncomeTab = reader.FetchAsNullable<int>("HIDE_MY_INCOME_TAB");

            schemeRec.HideISATab = reader.FetchAsNullable<int>("HIDE_ISA_TAB");
            schemeRec.PayrollAuto = reader.FetchAsNullable<int>("PAYROLL_AUTO");

            schemeRec.EnrolmentStartDate = DBHelper.GetIDataReaderString(reader, "ENROLMENT_START_DT_FORMATTED"); 
            schemeRec.AnnualIncomeIncreaseDate = DBHelper.GetIDataReaderString(reader, "ANNUAL_INCOME_INC_DT_FORMATTED"); 

            schemeRec.WorkforceAccessLevel = reader.FetchAsNullable<int>("WF_MGR_PERMISION_ID");
            schemeRec.OcpAccessLevel = reader.FetchAsNullable<int>("CONTRIB_MGR_PERMISION_ID");
            schemeRec.ReportManangerAccessLevel = reader.FetchAsNullable<int>("REPORT_MGR_PERMISION_ID");
            schemeRec.MemberSearchAccessLevel = reader.FetchAsNullable<int>("MEMBER_MGR_PERMISION_ID");
            schemeRec.MessageCenterAccessLevel = reader.FetchAsNullable<int>("MESSAGE_CENTER_PERMISION_ID");

            schemeRec.AssociatedDecumeScheme = DBHelper.GetIDataReaderNullableInt(reader, "ASSOCIATED_DECUM_SCHEME");

            schemeRec.InvestmentStructureCode = DBHelper.GetIDataReaderString(reader, "INVEST_STRUCT_CD");
            schemeRec.WorkplaceIsaRef = reader.FetchAsString( "WORKPLACE_ISA_REF" );
        }

        #endregion

        public IEnumerable<IOutcomeItem> YieldWarnings(Scheme decumScheme)
        {
            if (decumScheme == null)
            {
                yield return new OutcomeItem("No decum-scheme has been specified!");
                yield break;
            }

            string accumProviderCode = this.ProviderCode;

            string decumProviderCode = decumScheme.ProviderCode;

            if (accumProviderCode != decumProviderCode)
            {
                string message1 = String.Format(
                    "<span class='warning'>Warning: This accum scheme belongs to provider {0}; however, {1} is the provider of the associated decum scheme.</span>"
                    , accumProviderCode, decumProviderCode);

                yield return new OutcomeItem(message1);

                yield return new OutcomeItem("Please make sure the accumulation scheme is associated with the correct Decumulation scheme.");

                yield return new OutcomeItem("Please check scheme setup documentation before saving");
            }
        }
    }
}