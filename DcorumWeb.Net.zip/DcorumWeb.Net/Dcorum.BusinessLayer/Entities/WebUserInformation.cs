﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.BusinessLayer.Enums;
using Dcorum.Utilities;
using Dcorum.Utilities.Practices;
using DcorumWeb.Utilities;

namespace Dcorum.BusinessLayer.Entities
{
    public class WebUserInformationTree
    {
        internal WebUserInformationTree(
            int nameId,
            int caseKey,
            Func<int, WebUserInformation> infoTechnique,
            Func<int,IEnumerable<TargetPlanAccount>> howToGetAccountsViaNameId,
            Func<int,int?,IEnumerable<TPAccountSetUp>> nameIdRelatedAccountSetupsTechnique,
            Func<string,IEnumerable<TPAccountSetUp>> emailRelatedAccountSetupsTechnique
            )
        {
            NameId = nameId;

            UserAccInfo = infoTechnique(nameId);
     
            _targetPlanEnabledAccounts = howToGetAccountsViaNameId(NameId).ToArray();

            int? caseKeyToUse = (UserAccInfo!=null && UserAccInfo.UserType == UserType.Admin) ? null : caseKey.NullifyDefault();

            NameIdAssociatedTargetPlanAccountSetUps = nameIdRelatedAccountSetupsTechnique(NameId, caseKeyToUse).SafeLinq().ToArray();

            string emailToCheck = TargetPlanAccountSetUp.SafeFunc( _ => _.EmailData) ;

            EmailAssociatedTargetPlanAccountSetUps = emailRelatedAccountSetupsTechnique(emailToCheck).SafeLinq().ToArray();      
       }

        public readonly int NameId ;

        public bool HasUserAccount {get { return UserAccInfo.SafeFuncN( _ => _.UserAccId).GetValueOrDefault() > 0; }}

        public int CaseMemberKey { get { return TargetPlanAccountSetUp.SafeFuncN( _ => _.CaseMemberKey).GetValueOrDefault(); }}

        public WebUserInformation UserAccInfo { get; private set; }

        private TargetPlanAccount[] _targetPlanEnabledAccounts { get; set; }

        private TPAccountSetUp[] NameIdAssociatedTargetPlanAccountSetUps { get; set; }
        private TPAccountSetUp[] EmailAssociatedTargetPlanAccountSetUps { get; set; }

        /// <summary>
        /// [DERIVED]
        /// </summary>
        public bool IsAdminUserModeOn()
        {
            if (UserAccInfo == null) return false;
            return UserAccInfo.UserType == UserType.Admin;
        }

        /// <summary>
        /// [DERIVED]
        /// </summary>
        public TargetPlanAccount[] TargetPlanEnabledAccounts
        {
            get
            {
                return (IsAdminUserModeOn() || HasUserAccount==false) ? Enumerable.Empty<TargetPlanAccount>().ToArray() : _targetPlanEnabledAccounts;
            }
        }

        /// <summary>
        /// [DERIVED] If UserAccId > 0 then there isn't a candidate 
        /// </summary>
        public TPAccountSetUp TargetPlanAccountSetUp
        {
            get
            {
                var result = NameIdAssociatedTargetPlanAccountSetUps.SafeLinq().FirstOrDefault();
                return result ; 
            }
        }


        public bool IsBad
        {
            get
            {
                return UserAccInfo == null && TargetPlanAccountSetUp == null;
            }
        }


        public int[] BlockingUserAccIds()
        {
            int userAccIdToIgnore = UserAccInfo.SafeFuncN(_ => _.UserAccId).GetValueOrDefault();
            return EmailAssociatedTargetPlanAccountSetUps.SafeLinq().Where(_ => _.UserAccId > 0 && _.UserAccId != userAccIdToIgnore).Select(_ => _.UserAccId).ToArray();
        }

        public bool IsEmailRegisteredElsewhere()
        {
            bool isRegisteredElsewhere = BlockingUserAccIds().Any(_ => _ != TargetPlanAccountSetUp.UserAccId);
            return isRegisteredElsewhere;
        }

        /// <summary>
        /// [CONDITIONAL|PURE]
        /// </summary>
        [Conditional("DEBUG")]
        [Pure]
        public void TestAssertions(int expectedNameId)
        {
            Debug.Assert(UserAccInfo == null || UserAccInfo.NameId == expectedNameId);
            Debug.Assert(NameIdAssociatedTargetPlanAccountSetUps.All(_ => _.NameId == expectedNameId));
            Debug.Assert(EmailAssociatedTargetPlanAccountSetUps.All(_ => _.EmailData == TargetPlanAccountSetUp.EmailData));
            
            if (UserAccInfo!=null && TargetPlanAccountSetUp != null) Debug.Assert(UserAccInfo.UserName == TargetPlanAccountSetUp.EmailData);
        }
    }


    public class WebUserInformation
    {
        public WebUserInformation(IDataReader reader)
        {
            if (reader == null) return;
            Build(this, reader);
        }

        [Key]
        public int NameId { get; private set; }

        public int UserAccId { get; private set; }

        public UserType? UserType { get; private set; }

        public string UserName { get; private set; }

        public DateTime RegisteredOn { get; private set; }

        public DateTime LastSuccessfullLogin { get; private set; }

        public DateTime? LastPasswordReset { get; private set; }

        public int FailedLoginAttempts { get; private set; }

        public DateTime? LastFailedAttempt { get; private set; }

        public bool IsTimedOut { get; private set; }

        public DateTime? TimedOutUntil { get; private set; }

        public bool Locked { get; private set; }

        private static void Build(WebUserInformation webUserInformation, IDataReader reader)
        {
            webUserInformation.UserAccId = DBHelper.GetIDataReaderInt(reader, "USER_ACC_ID");
            webUserInformation.NameId = DBHelper.GetIDataReaderInt(reader, "NAMEID");
            webUserInformation.UserName = DBHelper.GetIDataReaderString(reader, "EMAILDATA");
            webUserInformation.RegisteredOn = DBHelper.GetIDataReaderDateTime(reader, "REGISTERED_ON");
            webUserInformation.LastSuccessfullLogin = DBHelper.GetIDataReaderDateTime(reader, "LAST_SUCCESSFUL_LOGIN");
            webUserInformation.LastPasswordReset = DBHelper.GetIDataReaderNullableDateTime(reader, "LAST_PASSWORD_RESET");
            webUserInformation.FailedLoginAttempts = DBHelper.GetIDataReaderInt(reader, "FAILED_LOGIN_ATTEMPTS");
            webUserInformation.LastFailedAttempt = DBHelper.GetIDataReaderNullableDateTime(reader, "LAST_FAILED_ATTEMPT");
            webUserInformation.IsTimedOut = DBHelper.GetIDataReaderInt(reader, "TIMED_OUT") == 1 ? true : false;
            webUserInformation.TimedOutUntil = DBHelper.GetIDataReaderNullableDateTime(reader, "TIME_OUT_UNTIL");
            webUserInformation.Locked = DBHelper.GetIDataReaderInt(reader, "LOCKED") == 1 ? true : false;
            webUserInformation.UserType = reader.FetchAsEnum<UserType>("USER_TYPE");
        }
    }
}
