﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.Entities
{
    public class MemberGroupThin
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal MemberGroupThin(IDataReader reader, string[] columnNames = null)
            :this()
        {
            BuildThin(this, reader, columnNames);
        }

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        protected MemberGroupThin() { }

        [Key]
        [UIHint("txtMBGPKey")]
        public int? MbGpKey { get; set; }

        [UIHint("txtDesc")]
        public string Description { get; set; }

        [IgnoreDataMember]
        [RefCodeConstraint(DomainNames.Member_Group_Type)] //for BL only
        public RefCode Type { get; set; }

        /// <summary>
        /// [BUILD_PART]
        /// </summary>
        internal protected static void BuildThin(MemberGroupThin memberGroup, IDataReader reader, string[] columnNames = null)
        {
            columnNames = columnNames ?? DefaultColumnNames;

            memberGroup.MbGpKey = DBHelper.GetIDataReaderNullableInt(reader, columnNames[0]);
            memberGroup.Description = DBHelper.GetIDataReaderString(reader, columnNames[1]);
            if (columnNames.Length>2) memberGroup.Type = new RefCode(DBHelper.GetIDataReaderString(reader, columnNames[2]));
        }

        private static readonly string[] DefaultColumnNames = new[] { "MBGP_KEY", "DESCRIPT", "GRP_TYP_CD" };

        [IgnoreDataMember]
        public string DisplayText
        {
            get { return string.Format("[{0}] {1}", this.MbGpKey == null ? 0 : this.MbGpKey, this.Description); }
        }
    }

    public class MemberGroup : MemberGroupThin
    {
        public MemberGroup()
        {

        }

        public bool IsValid { get; set; }

        public int? CaseKey { get; set; }


        [IgnoreDataMember]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)] //for BL only
        public RefCode UextMBGrpExists { get; set; }

        public string LinkedToProductGroup { get; set; }

        //benefit member group
        [RefCodeConstraint(DomainNames.PDIContribBasis)]
        [UIHint("ddlContribBasis")]
        public RefCode ContribBasis { get; set; }

        [Required]
        [RefCodeConstraint(DomainNames.PDIContribBasisAVC)]
        //[DefaultValue(DomainCodes.AVCContribBasisNone)]
        [UIHint("ddlContribBasisAVC")]
        public RefCode ContribBasisAVC { get; set; }

        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [UIHint("ddlSalSac")]
        public RefCode SalarySac { get; set; }

        [UIHint("chkVariableEmployerContribution")]
        public RefCode VariableEmployerContribution { get; set; }

        // invement member group ...
        [UIHint("chkDefault")]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)] //for BL only
        public RefCode IsDefault { get; set; }

        [UIHint("chkDefaultBenefitMbrGroup")]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)] //for BL only
        public RefCode IsDefaultBenefitMbrGroup { get; set; }

        [UIHint("chkDisplay")]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)] //for BL only
        public RefCode IsDisplay { get; set; }

        [UIHint("chkIsCash")]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)] //for BL only
        public RefCode IsCash { get; set; }

        [RefCodeConstraint(DomainNames.PDIActiveDeferredMbrs)]
        [UIHint("ddlInvAvlableFor")]
        public RefCode InvAvlableTo { get; set; }

        [UIHint("ddlLnkDefSwtchGrp")]
        public int? LnkDefSwitchGroup { get; set; }

        [UIHint("txtPIandDLink")]
        public string LinkToDoc { get; set; }

        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [UIHint("ddlSTPDisabled")]
        public RefCode STPDisabled { get; set; }

        //Illustration fields
        [Required] //bugfix: 6832 but null for non benefit types(s).
        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [UIHint("ddlNewIllustration")]
        public RefCode UseNewIllustration { get; set; }

        [Required]
        [RefCodeConstraint(DomainNames.PDIContribFrequency)]
        //[DefaultValue(DomainCodes.ContribFrequencyMonthly)]
        [UIHint("ddlContribFrequency")]
        public RefCode ContribFrequency { get; set; }

        [Required]
        [RefCodeConstraint(DomainNames.RedirectFrequency)]
        [UIHint("ddlRedirectionFrequency")]
        public RefCode RedirectFrequency { get; set; }

        [UIHint("txtGrpEarnCap")]
        public decimal? GroupEarningsCap { get; set; }

        //[DefaultValue(DomainCodes.IncreaseTypeValueNAE)]
        [RefCodeConstraint(DomainNames.PDIIllustrationIncType)]
        [UIHint("ddlIncreaseType")]
        public RefCode IncreaseType { get; set; }

        [UIHint("txtOthrAmount")]
        public decimal? CapIncrOtherAmt { get; set; }
        [UIHint("txtIncreaseDt")]
        public string CapIncrDate { get; set; }
        [UIHint("txtEmplErningCap")]
        public decimal? EmployerEarningCap { get; set; }

        //[DefaultValue(DomainCodes.IncreaseTypeValueNAE)]
        [RefCodeConstraint(DomainNames.PDIIllustrationIncType)]
        [UIHint("ddlEmplIncType")]
        public RefCode EmployerIncreaseType { get; set; }

        [UIHint("txtEmplAmtOth")]
        public decimal? EmployerEarningCapOther { get; set; }
        [UIHint("txtEmplIncreaseDt")]
        public string EmplCapIncrDate { get; set; }

        //TargetPlan Permission settings Deferred members
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlInvDef")]
        public RefCode InvPermissionDeferred { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlChgContDef")]
        public RefCode ContribPermissionDeferred { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlPerDef")]
        public RefCode PersPermissionDeferred { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlConDef")]
        public RefCode ContPermissionDeferred { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlTRADef")]
        public RefCode TRAPermissionDeferred { get; set; }

        //TargetPlan Permission settings Active members
        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlInvAct")]
        public RefCode InvPermissionActive { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlChgContAct")]
        public RefCode ContribPermissionActive { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlPerAct")]
        public RefCode PersPermissionActive { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlConAct")]
        public RefCode ContPermissionActive { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlTRAAct")]
        public RefCode TRAPermissionActive { get; set; }

        [RefCodeConstraint(DomainNames.PDITargetPlanAccessLevels)]
        [UIHint("ddlSecAct")]
        public RefCode SecPermissionActive { get; set; }

		[Required]
		[UIHint("ddlInvestmentOnly")]
		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
	    public RefCode IsInvestmentOnly { get; set; }


		[Category("TargetPlan Viewing Permission Control")]

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHideMessageCentre")]
		public int? HideMessageCentre { get; set; }

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHideMyPensionTab")]
		public int? HideMyPensionTab { get; set; }

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHidePensionEssentialsTab")]
		public int? HidePensionEssentialsTab { get; set; }

		[RefCodeConstraint(DomainNames.CompassYesNoValues)]
		[UIHint("ddlHideMyIncomeTab")]
		public int? HideMyIncomeTab { get; set; }
        
        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [UIHint("ddlHideIsaTab")]      
        public int? HideIsaTab { get; set; }

        /// <summary>
        /// [BUILD_PART]
        /// </summary>
        internal protected static void BuildWhenSingle(MemberGroup memberGroup, IDataReader reader, bool singleModeOn = false)
        {       
            memberGroup.CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY");

            memberGroup.VariableEmployerContribution = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "VARIABLE_EMPLOYER_CONT").ToString());

            //Illustration Fields
            memberGroup.UseNewIllustration = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "USE_NEW_ILLUST").ToString());
            memberGroup.ContribFrequency = new RefCode(DBHelper.GetIDataReaderString(reader, "CONTRIB_FREQ_CD"));
            memberGroup.RedirectFrequency = new RefCode(DBHelper.GetIDataReaderInt(reader, "REDIRECT_FREQ_KEY").ToString());
            memberGroup.GroupEarningsCap = DBHelper.GetIDataReaderNullableDecimal(reader, "GROUP_EARNINGS_CAP");
            memberGroup.IncreaseType = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "CAP_INC_TYPE").ToString());
            memberGroup.CapIncrOtherAmt = DBHelper.GetIDataReaderNullableDecimal(reader, "CAP_INC_TYPE_OTHER_AMT");
            memberGroup.CapIncrDate = DBHelper.GetIDataReaderString(reader, "CAP_INC_DT");
            memberGroup.EmployerEarningCap = DBHelper.GetIDataReaderNullableDecimal(reader, "ER_AMOUNT_CAP");
            memberGroup.EmployerIncreaseType = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "ER_AMOUNT_CAP_INC_TYPE").ToString());
            memberGroup.EmployerEarningCapOther = DBHelper.GetIDataReaderNullableDecimal(reader, "ER_AMOUNT_CAP_INC_OTHER_AMT");
            memberGroup.EmplCapIncrDate = DBHelper.GetIDataReaderString(reader, "ER_AMOUNT_CAP_RESET_DT");

            //Permission Active Member Fields
            memberGroup.InvPermissionActive = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "INVESTMENTS_PERMISSION_ID").ToString());
            memberGroup.ContribPermissionActive = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "CONTRIBUTION_PERMISSION_ID").ToString());
            memberGroup.PersPermissionActive = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "PERSONAL_DETAILS_PERMISSION_ID").ToString());
            memberGroup.ContPermissionActive = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "CONTACT_DETAILS_PERMISSION_ID").ToString());
            memberGroup.TRAPermissionActive = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "SET_TRA_PERMISSION_ID").ToString());
            memberGroup.SecPermissionActive = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "SECURITY_DETAILS_PERMISSION_ID").ToString());

            //Permission Deferred Member Fields
            memberGroup.InvPermissionDeferred = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "INVESTMENTS_DEF_PERMISSION_ID").ToString());
            memberGroup.ContribPermissionDeferred = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "CONTRIBUTION_DEF_PERMISSION_ID").ToString());
            memberGroup.PersPermissionDeferred = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "PERSONAL_DTL_DEF_PERMISSION_ID").ToString());
            memberGroup.ContPermissionDeferred = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "CONTACT_DTL_DEF_PERMISSION_ID").ToString());
            memberGroup.TRAPermissionDeferred = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "SET_TRA_DEF_PERMISSION_ID").ToString());

            memberGroup.HideMessageCentre = reader.FetchAsNullable<int>("HIDE_MESSAGE_CENTRE");
            memberGroup.HideMyPensionTab = reader.FetchAsNullable<int>("HIDE_MY_PENSION_TAB");
            memberGroup.HidePensionEssentialsTab = reader.FetchAsNullable<int>("HIDE_PENSION_ESSENTIALS_TAB");
            memberGroup.HideMyIncomeTab = reader.FetchAsNullable<int>("HIDE_MY_INCOME_TAB");
            memberGroup.HideIsaTab = reader.FetchAsNullable<int>("HIDE_ISA_TAB");

            memberGroup.LnkDefSwitchGroup = DBHelper.GetIDataReaderNullableInt(reader, "Defr_Swc_MBGP_Key");
        }

        /// <summary>
        /// [BUILD_PART]
        /// </summary>
        internal protected static void BuildWhenNotThin(MemberGroup memberGroup, IDataReader reader)
        {
            memberGroup.ContribBasis = new RefCode(DBHelper.GetIDataReaderString(reader, "CONTRIB_BASIS_CD"));
            memberGroup.ContribBasisAVC = new RefCode(DBHelper.GetIDataReaderString(reader, "AVC_CONTRIB_BASIS_CD"));
            memberGroup.SalarySac = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "SAL_SAC").ToString());

            memberGroup.IsDefault = new RefCode(DBHelper.GetIDataReaderInt(reader, "DEFAULT_LIFESTYLE_GROUP").ToString());
            memberGroup.IsDefaultBenefitMbrGroup = new RefCode(DBHelper.GetIDataReaderInt(reader, "DEFAULT_BENEFIT_GROUP").ToString());
            memberGroup.InvAvlableTo = new RefCode(DBHelper.GetIDataReaderString(reader, "INV_AVAILABLE_TO"));
            memberGroup.IsDisplay = new RefCode(DBHelper.GetIDataReaderInt(reader, "DISPLAY").ToString());
            memberGroup.IsCash = new RefCode(DBHelper.GetIDataReaderInt(reader, "IS_CASH").ToString());
            memberGroup.LinkToDoc = DBHelper.GetIDataReaderString(reader, "LINK_TO_DOCUMENTATION");
            memberGroup.STPDisabled = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "STP_DISABLED").ToString());

            memberGroup.UextMBGrpExists = new RefCode(DBHelper.GetIDataReaderInt(reader, "UextExists").ToString());
            memberGroup.LinkedToProductGroup = DBHelper.GetIDataReaderString(reader, "PRODUCT_GROUP");

            memberGroup.IsInvestmentOnly = new RefCode(DBHelper.GetIDataReaderNullableInt(reader, "INVESTMENT_ONLY").ToString());
        }
    }


}
