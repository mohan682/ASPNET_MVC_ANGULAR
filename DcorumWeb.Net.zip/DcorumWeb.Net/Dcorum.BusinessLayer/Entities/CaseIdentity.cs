﻿using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.Entities
{
    public class CaseIdentity : BaseEntity
    {
        [Key]
        [UIHint("lblId")]
        public int? CaseIdentityId { get; set; }

        [UIHint("txtIdentityProvider")]
        public string IdentityProvider { get; set; }

        [UIHint("txtIDPShortName")]
        public string IDPShortName { get; set; }

        [UIHint("txtIDPURL")]
        public string IDPURL { get; set; }

        [UIHint("txtIDPCheckSum")]
        public string IdentityChecksum { get; set; }

        public string SchemeDisplayText { get; set; }
    }
}
