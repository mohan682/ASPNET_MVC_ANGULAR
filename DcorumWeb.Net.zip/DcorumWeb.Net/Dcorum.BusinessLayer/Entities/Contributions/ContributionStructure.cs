﻿using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities.Contributions
{
    public class ContributionStructureLookup : ContributionCommonLookup
    {
        //Used on 2nd page...
        [IgnoreDataMember]
        public ContributionStructureDetail[] Details
        {
            get;
            set;
        }

        public override bool HasChildren()
        {
            return Details != null && Details.Length > 0;
        }
    }
}
