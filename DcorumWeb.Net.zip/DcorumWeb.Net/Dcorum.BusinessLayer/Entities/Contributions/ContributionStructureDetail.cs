﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities.Contributions
{
    public class ContributionStructureDetail : BaseEntity
    {
        [Key]
        public int Id { get; set; }

        public int ParentId { get; set; }

        //[DD Aug14] Not part of the table row but a colun of the parent row. Only populated as part of an insert where a parent insert is also required.
        [IgnoreDataMember]
        [ScaffoldColumn(true)]
        public int? ContributionStructureLookupId
        {
            get;
            set;
        }

        [UIHint("txtAgeTo")]
        public int MemberAgeTo { get; set; }

        [UIHint("txtServiceYearTo")]
        public int MemberServiceYearTo { get; set; }

        [UIHint("txtMemberContributionTo")]
        public decimal MemberContributionTo { get; set; }

        [UIHint("txtMemberSalaryTo")]
        public Int64 MemberSalaryTo { get; set; }

        /// <summary>
        ///  The minimum rate that the employee has to contribute.
        /// </summary>
        [UIHint("txtMinMemberContribution")]
        public decimal MinEmployeeContribution { get; set; }

        /// <summary>
        /// The extra rate that the employer will add on top of the matching.
        /// e.g. if the ee contributes 2%, and the er matches 200%, the value of this is 3, then 
        /// the er coontribution would be 2*200% + 3 = 7%
        /// </summary>
        [UIHint("txtCoreContribution")]
        public decimal EmployerCoreContribution { get; set; }

        [UIHint("txtEmployerMatch")]
        public decimal EmployerMatchPercentage { get; set; }

        [UIHint("txtMaxEmployerMatch")]
        public decimal MaxEmployeeMatchedRate { get; set; }

        [UIHint("txtTotalMaxEmployerContributionPercentage")]
        public decimal TotalMaxEmployerContributionPercentage { get; set; }

        [UIHint("txtTotalMaxEmployerContributionAmount")]
        public decimal TotalMaxEmployerContributionAmout { get; set; }

        [UIHint("txtSalaryLimit")]
        public Int64 SalaryLimit { get; set; }

        [UIHint("txtEffDate")]
        public DateTime EffectiveDate { get; set; }

        [UIHint("calExpiryDate")]
        public DateTime? ExpiryDate { get; set; }

        [UIHint("txtDateTo")]
        public DateTime? DateTo { get; set; }
    }
}
