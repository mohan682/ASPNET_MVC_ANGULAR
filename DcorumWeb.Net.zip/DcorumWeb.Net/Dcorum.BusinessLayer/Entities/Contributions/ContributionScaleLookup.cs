﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.Entities.Contributions
{
    public class ContributionScaleLookup : ContributionCommonLookup
    {
        //Used on 2nd page...
        [IgnoreDataMember]
        public ContributionScaleDetail[] Details
        {
            get;
            set;
        }

        public override bool HasChildren()
        {
            return Details != null && Details.Length > 0;
        }
    }


    public abstract class ContributionCommonLookup : ContributionLookupCore
    {
        public abstract bool HasChildren();

        [IgnoreDataMember]
        public bool IsVariation
        {
            get { return VariationCode.IntoIntN() > 0; }
        }

        [IgnoreDataMember]
        public bool CanDetachFromGroup
        {
            get { return CanInvariant && LookupId > 0 && ContributionGroupId > 0 &&  IsShared ; }
        }


        [IgnoreDataMember]
        public bool CanRemoveGroup
        {
            get { return CanInvariant && LookupId > 0 && (!HasChildren() || IsShared); }
        }

        [IgnoreDataMember]
        public bool CanInvariant
        {
            get { return CaseKey > 0 && MbGpKey > 0; }
        }

        private string MapToVariation(string code)
        {
            if (String.IsNullOrWhiteSpace(code) || CommonCodes.Variation_Code_ALL.Equals(code, StringComparison.OrdinalIgnoreCase))
                return CommonCodes.Variation_Code_ALL;

            int value1 = code.IntoIntN() ?? -1;

            if (value1 == 0) return CommonCodes.Variation_Code_All_Other_Money;
            if (value1 > 0) return String.Format("[{0}] {1}", VariationCode, MoneyTypeGroupTitle);

            return "Unknown";
        }

        private string _variation;

        //used on UI tabular view
        [IgnoreDataMember]
        public string Variation
        {
            get { return _variation ?? (_variation = MapToVariation( VariationCode)); }
        }

        [IgnoreDataMember]
        public int ViewKey
        {
            get { return LookupId ?? -MbGpKey ?? default(int); }
        }

        [IgnoreDataMember]
        public bool HasAssociatedGroup
        {
            get
            {
                return ContributionGroupId > 0;
            }
        }

        //for dropdowns.
        [IgnoreDataMember]
        public string Textual
        {
            get { return String.Format("[{0}] {1} (group: {2})", VariationCode, MoneyTypeGroupTitle, ContributionGroupId); }
        }

        [IgnoreDataMember]
        public int NumericVariationCode
        {
            get { return VariationCode.IntoIntN().GetValueOrDefault();  }
        }

        [IgnoreDataMember]
        public CaseMoneyTypeGroup[] CaseMoneyTypeGroups { get; set; }


        [IgnoreDataMember]
        public bool IsLookupValid {get { return HasAssociatedGroup && DetailCount > 0; }
        }
    }


    public abstract class ContributionLookupCore : ThinMemberGroupAbstract 
    {
        //Assumption: Should never get audited when value is not greater than zero.
        [Key]
        public int? LookupId
        {
            get;
            set;
        }


        public int ContributionGroupId
        {
            get;
            set;
        }


        //DomainNames.PDIVariationCodes
        public string VariationCode
        {
            get;
            set;
        }


        [IgnoreDataMember]
        public bool IsShared
        {
            get;
            set;
        }


        [IgnoreDataMember]
        public int DetailCount
        {
            get;
            set;
        }

        [IgnoreDataMember]
        public string MoneyTypeGroupTitle { get; set; }
    }


    public sealed class ThinMemberGroup : ThinMemberGroupAbstract
    {    
    }

    public abstract class ThinMemberGroupAbstract : BaseEntity
    {
        [IgnoreDataMember]
        [UIHint("lblMemebrGroupName")]
        public string Description
        {
            get;
            set;
        }

        [IgnoreDataMember]
        [RefCodeConstraint(DomainNames.Member_Group_Type)] //for BL only
        public RefCode MemberGroupCategory { get; set; }
    }
}
