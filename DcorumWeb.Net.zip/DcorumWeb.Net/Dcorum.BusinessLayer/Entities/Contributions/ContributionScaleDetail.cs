﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Contractual;

namespace Dcorum.BusinessLayer.Entities.Contributions
{
    public class ContributionScaleDetail : BaseEntity
    {
        public static ContributionScaleDetail GetDefault(bool percentModeOn)
        {
            var creation1 = MetaDataHelper.CreateWithDefaultValues<ContributionScaleDetail>();
            creation1.ContributionTo = Convert.ToDouble(GetMemberContributionDefault(percentModeOn));
            return creation1;
        }

        public static object GetMemberContributionDefault(bool percentModeOn)
        {
            return percentModeOn ? PercentMax : MoneyMax;
        } 


        public static Tuple<object, object> GetMemberContributionRange(bool percentModeOn)
        {
            return percentModeOn ? Tuple.Create((object)0U, (object)PercentMax) : Tuple.Create((object)0D, (object)MoneyMax);
        }


        public const double PercentMax = 100D;
        public const double MoneyMax = 99999999D;

        [ScaffoldColumn(true)]
        [Key]
        public int ContributionScaleId
        {
            get;
            set;
        }

        [ScaffoldColumn(true)]
        public int ParentId
        {
            get;
            set;
        }

        //[DD Aug14] Not part of the table row but a colun of the parent row. Only populated as part of an insert where a parent insert is also required.
        [IgnoreDataMember]
        [ScaffoldColumn(true)]
        public int? ContributionScaleLookupId
        {
            get;
            set;
        }


        [Display(Name = "Member Contribution To:", Order=30)]
        [UIHint("txtMemberContributionTo")]
        [Range(0, MoneyMax)]
        [RegularExpression(RegExConstants.NumericDigits)]
        [DefaultValue(100)]
        public Double ContributionTo
        {
            get;
            set;
        }

        [Display(Name = "Date To:", Order = 40)]
        [UIHint("txtDateTo")]
        //[DisplayFormat(DataFormatString = "{0:d}")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [RegularExpression(RegExConstants.DateFormat)]
        [DefaultValue(typeof(DateTime),null)]
        [Range(typeof(DateTime), "31/12/2000", "31/12/3000")]
        public DateTime? DateTo
        {
            get;
            set;
        }

        [Display(Name = "Age To", Order = 10)]
        [UIHint("txtAgeTo")]
        [DefaultValue(99)]
        [Range(0, 99)]
        [RegularExpression(RegExConstants.NumericDigits)]
        public int AgeTo
        {
            get;
            set;
        }

        [Display(Name = "Fixed Points Only:", Order=60)]
        [UIHint("chkFixedPointsOnly")]
        [DefaultValue(false)]
        public bool FixedPointsOnly
        {
            get;
            set;
        }

        [Display(Name = "Increment Amount:", Order=70)]
        [UIHint("txtIncrementAmount")]
        [DefaultValue(1)]
        [Range(0.1D, 99999D)]
        [RegularExpression(RegExConstants.CorrectFormat)]
        public Double IncrementAmount
        {
            get;
            set;
        }

        [Display(Name = "Lower Amount:", Order=80)]
        [UIHint("txtLowerAmount")]
        [DefaultValue(0)]
        [Range(0, 99999D)]
        [RegularExpression(RegExConstants.CorrectFormat)]
        public Double LowerAmount
        {
            get;
            set;
        }

        [Display(Name = "Member Salary To:", Order=50)]
        [UIHint("txtMemberSalaryTo")]
        [DefaultValue(99999999)]
        [Range(0, 99999999D)]
        [RegularExpression(RegExConstants.NumericDigits)]
        public Double SalaryTo
        {
            get;
            set;
        }

        [Display(Name = "Service Year To:", Order=20)]
        [UIHint("txtServiceYearTo")]
        [DefaultValue(999)]
        [Range(0, 999)]
        [RegularExpression(RegExConstants.NumericDigits)]
        public int ServiceTo
        {
            get;
            set;
        }

        [Display(Name = "Upper Amount:", Order=90)]
        [UIHint("txtUpperAmount")]
        [DefaultValue(100)]
        [Range(0, 99999D)]
        [RegularExpression(RegExConstants.CorrectFormat)]
        public Double UpperAmount
        {
            get;
            set;
        }

    }
}
