﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Logic;
using Dcorum.Utilities;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Annotations;
using Dcorum.BusinessLayer.Logic.Helping;

namespace Dcorum.BusinessLayer.Entities
{
    [Flags]
    public enum ContentFlags
    {     
        [Description("Provider")]
        Provider = 1,
        [Description("Product")]
        Product = 2,
        [Description("Plan")]
        Plan = 4,
        [Description("Scheme")]
        Scheme = 8,
        [Description("Member Group")]
        MemberGroup = 16,
        [Description("IO Client")]
        IOClient = 32
    }

    public enum ContentSearchActionStatus
    {
        [Description("Pending")]
        Pending = 0,
        [Description("Approved")]
        Approved = 1,
    }

    public enum ContentSearchTimeStatus
    {
        [Description("Expired")]
        Expired = 1,
        [Description("Current")]
        Current = 2,
        [Description("Scheduled")]
        Scheduled = 3,
    }


    public class ContentDataModel
    {
        // order by f1.PROVIDER, f1.PRODUCT, f1.PLAN, f1.SCHEME, f1.MBR_GRP, f1.SCHEME, f1.COMPONENT, f1.TYPE, f1.TARGET, f1.APPROVED";

        [Key]
        public int Id { get; set; }

        [RefCodeConstraint(DomainNames.PDI_Content_Type)]
        [Display(Name = "Type:")]
        [UIHint("ddlContentType")]
        [Required]
        [UiSearchable("type", "=", CanBeNull = true, OrderOverride = 220, LabelNameOverride = "Content Type:")]
        public RefCode TypeRefCode { get; set; }


        [Display(Name = "Screen:")]
        [RefCodeConstraint(DomainNames.PDI_Content_Component)]
        [UIHint("ddlScreens")]
        [Required]
        [UiSearchable("component", "=", CanBeNull = true, OrderOverride = 210)]
        public RefCode ComponentRefCode { get; set; }

        [Display(Name = "Override Provider:")]
        [RefCodeConstraint(DomainNames.UEXT_Provider_Code)]
        [UIHint("ddlProviders")]
        [Required]
        [UiSearchable("provider", "=", CanBeNull = true, OrderOverride = 110, LogicGroup = 1, LabelNameOverride="Provider:")]
        public RefCode ProviderRefCode { get; set; }

        [Display(Name = "Override Product:")]
        [RefCodeConstraint(DomainNames.UEXT_Product_Code)]
        [UIHint("ddlProducts")]
        [Required]
        [UiSearchable("product", "=", CanBeNull = true, OrderOverride = 120, LogicGroup = 1, LabelNameOverride = "Product:")]
        public RefCode ProductRefCode { get; set; }

        [Display(Name = "Override Plan:")]
        [RefCodeConstraint("PLAN TYPE CODE")]
        [UIHint("ddlPlans")]
        [Required]
        [UiSearchable("plan", "=", CanBeNull = true, OrderOverride = 130, LogicGroup = 1, LabelNameOverride = "Plan:")]
        public RefCode PlanRefCode { get; set; }

        [Display(Name = "Override Scheme:", Prompt = "Enter partial case-key to show possible schemes")]
        [UIHint("txt*")]
        [UiSearchable("scheme", "=", CanBeNull = true, OrderOverride = 140, LogicGroup = 1, LabelNameOverride = "Scheme:")]
        [AutoExtender("GetTargetPlanEnabledSchemeList")]
        public int? SchemeId { get; set; }

        public string SchemeExternalId { get; set; }

        public string SchemeName { get; set; }

        [Display(Name = "Override Member Group:", Prompt = "Enter partial member group to show possible member groups")]
        [UIHint("txt*")]
        [UiSearchable("mbr_grp", "=", CanBeNull = true, OrderOverride = 150, LogicGroup = 1, LabelNameOverride = "Member Group:")]
        [AutoExtender("GetMemberGroupList")] //GetMemberGroupListForScheme
        public int? MemberGroupId { get; set; }

        [Display(Name = "Override IO Client:", Prompt = "Enter partial IO Client Name to show possible IO Clients")]
        [UIHint("txt*")]
        [UiSearchable("scheme", "=", CanBeNull = true, OrderOverride = 107, LogicGroup = 1, LabelNameOverride = "IO Client:")]
        [AutoExtender("GetIoClientNames")] 
        public int? IOClientId { get; set; }

        public string IOClientReference { get; set; }

        public string IOClientName { get; set; }

        private string _value;

        [Display(Name = "Text Value:")]
        [UIHint("txt*")]
        [UiSearchable("value", "like", CanBeNull = true, CaseSensitive = false, OrderOverride = 240, LabelNameOverride="Value (contains):")]
        public string Value
        {
            get { return _value; }
            set
            {
                _value = value;
                ContentData.SafeFunc( _ => _.BinaryData = null); //if textual value then discard any binary data.
            } 
        }


        [Display(Name = "Effective Date:")]
        public DateTime EffectiveDateTime { get; set; }

        [Display(Name = "Expiry Date:")]
        public DateTime? ExpiryDateTime { get; set; }

        public bool Approved { get; set; }

        [Display(Name = "Created By:")]
        public string CreatedUser { get; set; }

        [Display(Name = "Approved By:")]
        public string AuthUser { get; set; }

        public bool Published { get; set; }

        [UIHint("txt*")]
        [UiSearchable("target", "like", CanBeNull = true, CaseSensitive = false, OrderOverride = 230, LabelNameOverride="Target (contains):")]
        public string Target { get; set; }

        public int BaseId { get; set; }


        public bool HasShadowCopy { get; set; }

        [XmlIgnore]
        public ContentData ContentData { get; set; }


        protected static bool TryBuild(ContentDataModel content, IDataReader reader)
        {
            if (content == null || reader == null) return false;

            content.Id = DBHelper.GetIDataReaderInt(reader, "CONTENT_ID");
            content.ProviderRefCode = reader.FetchTextualRefCode("PROVIDER");
            content.ProductRefCode = reader.FetchNumericRefCode("PRODUCT");
            content.SchemeId = reader.FetchAsNullable<int>("SCHEME");
            content.SchemeExternalId = DBHelper.GetIDataReaderString(reader, "CONT_NO");
            content.SchemeName = DBHelper.GetIDataReaderString(reader, "PLAN_NM");
            content.MemberGroupId = reader.FetchAsNullable<int>("MBR_GRP");
            content.ComponentRefCode = reader.FetchTextualRefCode("COMPONENT");
            content.TypeRefCode = reader.FetchTextualRefCode("TYPE");
            content.PlanRefCode = reader.FetchTextualRefCode("Plan");

            content.Value = DBHelper.GetIDataReaderString(reader, "VALUE");

            content.EffectiveDateTime = DBHelper.GetIDataReaderDateTime(reader, "EFF_DT");
            content.ExpiryDateTime = reader.FetchAsNullable<DateTime>("EXPIR_DT");
            content.Approved = DBHelper.GetIDataReaderInt(reader, "APPROVED") == 1;
            content.CreatedUser = DBHelper.GetIDataReaderString(reader, "CREATED_USER_ID");
            content.AuthUser = DBHelper.GetIDataReaderString(reader, "AUTH_USER_ID");
            content.Published = DBHelper.GetIDataReaderInt(reader, "PUBLISHED") == 1;
            content.Target = DBHelper.GetIDataReaderString(reader, "TARGET");
            content.BaseId = DBHelper.GetIDataReaderInt(reader, "BASE_ID");
            content.HasShadowCopy = DBHelper.GetIDataReaderInt(reader, "Has_Shadow") > 0;

            //AWI-12446 : For supporting IO Client
            if(content.SchemeId<0)
            {
                content.IOClientId = content.SchemeId;

                content.SchemeId = null;
                content.SchemeExternalId = null;
            }

            return true;
        }
    }


    public class ContentBizModel : ContentDataModel
    {
        public bool IsExpired
        {
            get
            {
                bool result = (ExpiryDateTime.HasValue && ExpiryDateTime.Value <= DateTime.Now);
                return result;
            }
        }

        public bool IsCurrent
        {
            get
            {
                bool result = (EffectiveDateTime <= DateTime.Now && (!ExpiryDateTime.HasValue || ExpiryDateTime.Value > DateTime.Now));
                return result;
            }
        }

        public string TypeCode { get { return TypeRefCode?.RefCd; } }

        public string ComponentCode { get { return ComponentRefCode?.RefCd; } }

        public string Provider { get { return ProviderRefCode?.RefCd; } }

        public string Product { get { return ProductRefCode?.RefCd; } }

        public string Plan { get { return PlanRefCode?.RefCd ; } }
    }


    public interface IContentCloningArguments
    {
        int Id { get; }
        int BaseId { get; }
        bool Approved { get; }
        bool HasShadowCopy { get; }
    }


    public class Content : ContentBizModel, IContentCloningArguments
    {
        public Content()
            :this(null)
        {
            
        }

        public Content(IDataReader reader)
        {
            bool success = TryBuild(this, reader);
            Debug.Assert(success == (reader != null));
        }

        [UIHint("ddlOverrideLevel")]
        public ContentFlags? Override { get; set; }


        [IgnoreDataMember]
        [UIHint("ddlLookup")]
        [RefCodeConstraint(DomainNames.PDI_Lookup_types)]
        public RefCode LookupValue
        {
            get
            {
                return null;
            }
            set
            {
                return;
            }
        }


        #region ......list view......

        [IgnoreDataMember]
        public string Status
        {
            get
            {
                if (Approved)
                    return "Approved";

                return "Pending";
            }
        }


        private IEnumerable<string> OverrideLevelCore()
        {
            if (!string.IsNullOrEmpty(Provider))
                yield return string.Format("Provider [{0}]", Provider);

            if (!string.IsNullOrEmpty(Product))
                yield return string.Format("Product [{0}]", Product);

            if (!string.IsNullOrEmpty(Plan))
                yield return string.Format("Plan [{0}]", Plan);

            if (SchemeId.HasValue)
                //return string.Format("Scheme [{0}]", SchemeId.Value);
                yield return string.Format("[{0}] {1}", SchemeExternalId, SchemeName);

            if (MemberGroupId.HasValue)
                yield return string.Format("Member Group [{0}]", MemberGroupId.Value);

            if (IOClientId.HasValue)
                yield return BLHelper.ParseForIOClient(Math.Abs(IOClientId.Value));
               // yield return string.Format("IO Client [{0}]", IOClientId.Value);
        }


        public string OverrideLevel
        {
            get
            {
                string[] parts = OverrideLevelCore().ToArray();

                string result = parts.Any() ? String.Join(Environment.NewLine, parts) : "Default";

                return result;
            }
        }


        [IgnoreDataMember]
        public string TypeName
        {
            get
            {
                if (String.IsNullOrEmpty(TypeRefCode.DomainName)) return "Unrecognised value!";
                return TypeRefCode.Descript;
            }
        }

        [IgnoreDataMember]
        public string ComponentName
        {
            get
            {
                if (String.IsNullOrEmpty(ComponentRefCode.DomainName)) return "Unrecognised value!";
                return ComponentRefCode.Descript;
            }
        }

        [IgnoreDataMember]
        public string ValueDisplayText
        {
            get
            {
                const int maxLength = 33;

                string result;

                string typeName = (TypeRefCode.SafeFunc( _ => _.RefCd) ?? String.Empty).ToLower();

                if (typeName == "validation")
                {
                    int? parsed1 = Value.IntoIntN();
                    var subModel1 = (parsed1.HasValue) ? BLValidation.GetValidationById(parsed1.Value) : null;
                    Value = (subModel1!= null) ? subModel1.SafeFunc( _ => _.ValidationName) : String.Format("Unrecognised validation '{0}' !", Value);
                    result = Value;
                }
                else if (Value == null || Value.Length <= maxLength)
                {
                    result = Value;
                }
                else if (new []{"img","webpart"}.Contains(typeName) )
                {
                    Debug.Assert(Value != null && Value.Length > maxLength);
                    result = string.Concat("...", Value.Substring(Value.Length - maxLength +3));   
                }
                else
                {
                    Debug.Assert(Value != null && Value.Length > maxLength);
                    result = string.Concat(Value.Substring(0, maxLength-3), "...");
                }


                return result;
            }
        }

        [IgnoreDataMember]
        public bool Overridible
        {
            get
            {
                return !MemberGroupId.HasValue;
            }
        }

        [IgnoreDataMember]
        [Display(Name="ignored",Order = 200)]
        [UIHint("lab*", "search")]
        public string Separator1
        {
            get
            {
                return "Definition";
            }
        }

        [IgnoreDataMember]
        [UIHint("chk*", "search")]
        [UiSearchable("provider", "=", CanBeNull = false, OrderOverride = 105, LabelNameOverride = "Default Content", LogicGroup = 1, CustomFormat = "(({2} = 1 and provider is null and product is null and plan is null and scheme is null and mbr_grp is null) or ({2}=0 and (provider is not null or product is not null or plan is not null or scheme is not null or mbr_grp is not null)))")]
        public bool IsDefault
        {
            get
            {
                return true;
            }
        }

        [IgnoreDataMember]
        public bool IsPending
        {
            get
            {
                return !Approved;
            }
        }


        [UIHint("ddl*", "search")]
        [Display(Name="Content Status:")]
        [Required]
        public ContentSearchTimeStatus TimeStatus
        {
            get
            {
                if (IsExpired) return ContentSearchTimeStatus.Expired;
                if (IsCurrent) return ContentSearchTimeStatus.Current;
                return ContentSearchTimeStatus.Scheduled;
            }
        }


        [IgnoreDataMember]
        [Required]
        [UIHint("ddl*", "search")]
        [UiSearchable("Approved", "=", CanBeNull = false, OrderOverride = 310, LabelNameOverride = "Approval Status:", CustomFormat = "(({2} = 1 and {0} > 0) or ({2} = 0 and ({0} is null) or {0} = 0))")]
        public ContentSearchActionStatus ActionStatus
        {
            get
            {
                if (!Approved) return ContentSearchActionStatus.Pending;
                return ContentSearchActionStatus.Approved;
            }
        }

        [IgnoreDataMember]
        [Required]
        [UIHint("chk*", "search")]
        [UiSearchable("Published", "=", CanBeNull = false, OrderOverride = 315, LabelNameOverride = "Unpublished", CustomFormat = "(({2} = 0 and {0} > 0) or ({2} = 1 and ({0} is null) or {0} = 0))")]
        public bool Unpublished
        {
            get
            {
                return !Published;
            }
        }

        #endregion
    }
}
