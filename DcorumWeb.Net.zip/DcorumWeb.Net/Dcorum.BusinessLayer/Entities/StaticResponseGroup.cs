﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BusinesObjects;

namespace Dcorum.BusinessLayer.Entities
{
    [DisplayName("Static Response Groups")]
    public class StaticResponseGroup
    {
        [Key]
        public int? StaticResponseGroupId { get; set; }

        public string Description { get; set; }

        public RefCode Code { get; set; }

        public string ShortDescription { get; set; }
    }
}
