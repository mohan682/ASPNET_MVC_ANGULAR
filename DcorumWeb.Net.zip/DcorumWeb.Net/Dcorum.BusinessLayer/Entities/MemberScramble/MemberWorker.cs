﻿using System;

namespace Dcorum.BusinessLayer.Entities.MemberScramble
{
    public class MemberWorker
    {
        public int CaseMbrKey { get; set; }
        public int CaseKey { get; set; }
        public string NiNumber { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
    }
}