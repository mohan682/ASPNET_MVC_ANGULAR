﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Entities.MemberScramble
{
    public class ScrambleWorker
    {
        public string ScrambleMessage { get; set; }
    }
}
