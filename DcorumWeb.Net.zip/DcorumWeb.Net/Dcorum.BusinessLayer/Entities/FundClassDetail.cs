﻿using System;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BusinesObjects;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.Contractual;
using DCorum.ViewModelling.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public class FundClassDetail : BaseEntity
    {
        [Key]
        public int FundClassDetailId { get; set; }

        [UIHint("txtFundDescriptionId")]
        [Display(Name = "Fund Identifier:")]
        [Editable(false)]
        public string FundDescriptionId { get; set; }

        [IgnoreDataMember]
        public string FundShortName { get; set; }

        [IgnoreDataMember]
        public bool AllowInvestmentByMoneyType { get; set; }

        [UIHint("txtFundLongName")]
        [Display(Name = "Fund Name:")]
        [Editable(false)]
        public string FundLongName { get; set; }

        [UIHint("chkIsCoreFund")]
        [Display(Name = "Core Fund:")]
        public bool IsCoreFund { get; set; }

        [Display(Name = "Active Class:")]
        [RefCodeConstraint(Constants.DomainNames.UEXT_ActiveFundClass)]
        [UIHint("ddlActiveFundClass")]
        [Required]
        public RefCode ActiveFundClass { get; set; }

        [UIHint("txtAnnualManagementCharge")]
        [Display(Name = "Annual Management Charge:")]
        [Editable(false)]
        public decimal? AnnualManagementCharge { get; set; }

        [UIHint("txtAdditionalCharge")]
        [Display(Name = "Additional Charge:")]
        [Range(-9.99D, 9.99D)]
        [RegularExpression(RegExConstants.CorrectFormat)]
        public decimal AdditionalCharge { get; set; }

        [UIHint("txtGrowthRateLow")]
        [Display(Name = "Illustration Growth Rate Override – Low Basis:")]
        [Range(-3.00D, 2.00D)]
        [RegularExpression(RegExConstants.CorrectFormat,ErrorMessage = "Value must be numeric and should not start with special charecter.")]
        public decimal? GrowthRateLow { get; set; }

        [UIHint("txtGrowthRateMid")]
        [Display(Name = "Illustration Growth Rate Override – Mid Basis:")]
        [Range(-3.00D, 5.00D)]
        [RegularExpression(RegExConstants.CorrectFormat, ErrorMessage = "Value must be numeric and should not start with special charecter.")]
        public decimal? GrowthRateMid { get; set; }

        [UIHint("txtGrowthRateHigh")]
        [Display(Name = "Illustration Growth Rate Override – High Basis:")]
        [Range(-3.00D, 8.00D)]
        [RegularExpression(RegExConstants.CorrectFormat, ErrorMessage = "Value must be numeric and should not start with special charecter.")]
        public decimal? GrowthRateHigh { get; set; }

        [UIHint("txtGrowthRateSmpi")]
        [Display(Name = "Illustration Growth Rate Override – SMPI Basis:")]
        [Range(-3.00D, 8.00D)]
        [RegularExpression(RegExConstants.CorrectFormat, ErrorMessage = "Value must be numeric and should not start with special charecter.")]
        public decimal? GrowthRateSMPI { get; set; }

        [Display(Name = "Charge Met By:")]
        [RefCodeConstraint(Constants.DomainNames.UEXT_FundChargeMetBy)]
        [UIHint("ddlChargeMetBy")]
        [Required]
        public RefCode ChargeMetBy { get; set; }      

        [Display(Name = "Effective Date:")]       
        [UIHint("dtEffectiveDate")]
        [Required]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime EffectiveDate { get; set; }

        [Display(Name = "Expiry Date:")]
        [UIHint("dtExpiryDate")]       
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [RegularExpression(RegExConstants.DateFormat, ErrorMessage = "ExpiryDate value must be in the right format.")]
        public DateTime? ExpiryDate { get; set; }       
    }
}
