﻿using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Dcorum.BusinessLayer.Entities
{
    [Serializable]
    public class OCPOptions
    {
        [Key]
        public int BillingGroupId { get; set; }
               
        [Display (Name="Billing Group")]
        [UIHint("Descript")]
        [ReadOnly(true)]
        public string Description { get; set; }

        [Required]
        [Display (Name="Scheme Id:")]
        [UIHint("ddlSchemeId")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string SchemeId {get;set;}
        
        [Required]
        [Display(Name = "Payroll Id:")]
        [UIHint("ddlPayrollId")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string PayrollId { get; set; }

        [Required]
        [Display(Name = "Paying Office Id:")]
        [UIHint("ddlPayingOfficeId")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string PayingOfficeId { get; set; }


        [Required]
        [Display(Name = "NI Number:")]
        [UIHint("ddlNiNo")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string NINo { get; set; }

        [Required]
        [Display(Name = "Title:")]
        [UIHint("ddlTitle")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string Title { get; set; }

        [Required]
        [Display(Name = "Surname:")]
        [UIHint("ddlSurname")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string Surname { get; set; }

        [Required]
        [Display(Name = "Forenames:")]
        [UIHint("ddlForenames")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string Forenames { get; set; }

        [Required]
        [Display(Name = "DOB:")]
        [UIHint("ddlDOB")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string DOB { get; set; }

        [Required]
        [Display(Name = "Sex:")]
        [UIHint("ddlSex")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string Sex { get; set; }

        [Required]
        [Display(Name = "Earnings:")]
        [UIHint("ddlEarnings")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string Earnings { get; set; }

        [Required]
        [Display(Name = "AC Single Payment:")]
        [UIHint("ddlACSinglePayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string ACSinglePayment { get; set; }

        [Required]
        [Display(Name = "EM Single Payment:")]
        [UIHint("ddlEMSinglePayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string EMSinglePayment { get; set; }

        [Required]
        [Display(Name = "AC Core Payment:")]
        [UIHint("ddlACCorePayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string ACCorePayment { get; set; }

        [Required]
        [Display(Name = "EM Core Payment:")]
        [UIHint("ddlEMCorePayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string EMCorePayment { get; set; }

        [Required]
        [Display(Name = "AC Matching Payment:")]
        [UIHint("ddlACMatchingPayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string ACMatchingPayment { get; set; }

        [Required]
        [Display(Name = "EM Matching Payment:")]
        [UIHint("ddlEMMatchingPayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string EMMatchingPayment { get; set; }

        [Required]
        [Display(Name = "AVC Payment:")]
        [UIHint("ddlAVCPayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string AVCPayment { get; set; }

        [Required]
        [Display(Name = "EM Special Payment:")]
        [UIHint("ddlEMSpecialPayment")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string EMSpecialPayment { get; set; }

        [Required]
        [Display(Name = "AC Rebate:")]
        [UIHint("ddlACRebate")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string ACRebate { get; set; }

        [Required]
        [Display(Name = "EM Rebate:")]
        [UIHint("ddlEMRebate")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string EMRebate { get; set; }

        [Required]
        [Display(Name = "Workplace ISA:")]
        [UIHint("ddlWorkplaceISA")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string WorkplaceISA { get; set; }

        [Required]
        [Display(Name = "Suspended Date:")]
        [UIHint("ddlSuspendedDate")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string SuspendedDate { get; set; }

        [Required]
        [Display(Name = "Leaving Date:")]
        [UIHint("ddlLeavingDate")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string LeavingDate { get; set; }

        [Required]
        [Display(Name = "Joining Date:")]
        [UIHint("ddlJoiningDate")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string JoiningDate { get; set; }

        [Required]
        [Display(Name = "Reason Code:")]
        [UIHint("ddlReasonCode")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string ReasonCode { get; set; }

        [Required]
        [Display(Name = "Workplace ISA Reason Code:")]
        [UIHint("ddlWorkplaceIsaReasonCode")]
        [RefCodeConstraint("OCP USER FIELD OPTION")]
        public string WorkplaceIsaReasonCode { get; set; }

        public OCPOptions()
        { }


        public OCPOptions(IDataReader reader)
        {
            Build(this, reader);
        }


        private static void Build(OCPOptions ocpOptions, IDataReader reader)
        {
            ocpOptions.Description = DBHelper.GetIDataReaderString(reader, "DESCRIPT");

            ocpOptions.BillingGroupId = DBHelper.GetIDataReaderInt(reader, "BGRP_KEY");
            ocpOptions.SchemeId = reader.FetchAsString( "ABP_ED_SCHEME_ID" );
            ocpOptions.PayrollId = reader.FetchAsString("ABP_ED_PAYROLL_ID");
            ocpOptions.PayingOfficeId = reader.FetchAsString("ABP_ED_PAYING_OFFICE_ID");
            ocpOptions.NINo = reader.FetchAsString("ABP_ED_NI_NUMBER");
            ocpOptions.Title = reader.FetchAsString("ABP_ED_TITLE");
            ocpOptions.Surname = reader.FetchAsString("ABP_ED_SURNAME");
            ocpOptions.Forenames = reader.FetchAsString("ABP_ED_FORNAMES");
            ocpOptions.DOB = reader.FetchAsString("ABP_ED_DOB");
            ocpOptions.Sex = reader.FetchAsString("ABP_ED_SEX");
            ocpOptions.Earnings = reader.FetchAsString("ABP_ED_EARNINGS");
            ocpOptions.ACSinglePayment = reader.FetchAsString("ABP_ED_AC_SINGLE_PAYMENT");
            ocpOptions.EMSinglePayment = reader.FetchAsString("ABP_ED_EM_SINGLE_PAYMENT");
            ocpOptions.ACCorePayment = reader.FetchAsString("ABP_ED_AC_CORE_PAYMENT");
            ocpOptions.EMCorePayment = reader.FetchAsString("ABP_ED_EM_CORE_PAYMENT");
            ocpOptions.ACMatchingPayment = reader.FetchAsString("ABP_ED_AC_MATCHING_PAYMENT");
            ocpOptions.EMMatchingPayment = reader.FetchAsString("ABP_ED_EM_MATCHING_PAYMENT");
            ocpOptions.AVCPayment = reader.FetchAsString("ABP_ED_AVC_PAYMENT");
            ocpOptions.EMSpecialPayment = reader.FetchAsString("ABP_ED_EM_SPECIAL_PAYMENT");
            ocpOptions.ACRebate = reader.FetchAsString("ABP_ED_AC_REBATE");
            ocpOptions.EMRebate = reader.FetchAsString("ABP_ED_EM_REBATE");
            ocpOptions.SuspendedDate = reader.FetchAsString("ABP_ED_SUSPENDED_DATE");
            ocpOptions.LeavingDate = reader.FetchAsString("ABP_ED_LEAVING_DATE");
            ocpOptions.JoiningDate = reader.FetchAsString("ABP_ED_JOINING_DATE");
            ocpOptions.ReasonCode = reader.FetchAsString("ABP_ED_REASON_CODE");
            ocpOptions.WorkplaceISA = reader.FetchAsString("ABP_ED_WORKPLACE_ISA");
            ocpOptions.WorkplaceIsaReasonCode = reader.FetchAsString("ABP_ED_WORKPLACE_ISA_REASON_CD");
        }  
           
    }

}