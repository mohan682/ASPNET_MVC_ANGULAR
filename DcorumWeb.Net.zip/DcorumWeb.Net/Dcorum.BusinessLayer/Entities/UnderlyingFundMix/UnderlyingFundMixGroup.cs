﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities
{
    public class UnderlyingFundMixGroup
    {
        public int FundGroupNumber { get; set; }
        public string FundGroupName { get; set; }
        public string FundGroupManager { get; set; }
        public decimal TotalPercentage { get; set; }
        public int? NoOfTPSchemesLinked { get; set; }


        [IgnoreDataMember]
        public bool IsValid { get; set; }

        [IgnoreDataMember]
        public ICollection<PDIMessage> errorList { set; get; }
    }
}
