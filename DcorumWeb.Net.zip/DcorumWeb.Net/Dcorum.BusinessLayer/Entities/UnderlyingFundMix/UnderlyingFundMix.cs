﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.Entities
{
    public class UnderlyingFundMix
    {
        [Key]
        public int? UnderLyingFundMixId { get; set; }
        public string FundGroupNumber { get; set; }

        //[IgnoreDataMember]
        //public string FundGroupName { get; set; }

        public string InvestmentTypeId { get; set; }
        
        public string InvestmentTypeName { get; set; }
        public decimal? Percentage { get; set; }

        [IgnoreDataMember]
        public bool IsValid { get; set; }

        [IgnoreDataMember]
        public ICollection<PDIMessage> errorList { set; get; }
    }
}
