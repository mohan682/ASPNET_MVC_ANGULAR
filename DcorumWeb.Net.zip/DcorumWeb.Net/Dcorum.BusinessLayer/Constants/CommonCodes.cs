﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Constants
{
    public class CommonCodes
    {
        public const string Variation_Code_ALL="ALL";
        public const string Variation_Code_All_Other_Money = "All Other Money";

    }
}
