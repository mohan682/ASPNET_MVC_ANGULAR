﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.Enums
{
    public enum UserType
    {
        // Various statuses that the User session can be
        Member = 0,
        Guest = 1,
        Demo = 2,
        ImpersonatedMember = 3,
        System = 4,
        Admin = 5
    }
}
