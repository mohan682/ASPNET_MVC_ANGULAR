﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Logic
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    [Category(DomainCodes.DcorumComponentOCPOptions)]    
    public class BLOCPOptions : BLPersistorTemplate<OCPOptions, int, int>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected BLOCPOptions(IAuditingArgumentsReadOnly caller, DLOCPOptions dataAccess)
            : base(caller, dataAccess)
        {
        }


        public override TOutcome Save(OCPOptions model)
        {
            return base.Save(model);
        }         
        

        //Don't think this is required!!!!
        protected override object AnonymousTableRowFacade(OCPOptions model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.BillingGroupId,
                Billing_Group_Key = model.BillingGroupId,
                SCHEME_ID = model.SchemeId

                //  OPRA_Checks = (model.ApplyOPRAChecks == "Y") ? "Yes" : "No"
                //OCP_Enabled = model.

                //Nino_Identifier = model.nino.ToString(),
                //Member_Surname___________ = model.surname.ToString(),
                //Member_Name__________ = model.first_name.ToString(),
                //Member_Scheme__________ = model.scheme_ext_id.ToString()
            };

            return facade1;
        }  

    }

    //[Category(DomainCodes.DcorumComponentOCPOptions)]    
    //public class BLOCPOptionsReadOnly : BLPersistorTemplate<OCPOptionsReadOnly, int, int>
    //{
    //    /// <summary>
    //    /// [CONSTRUCTOR]
    //    /// </summary>
    //    internal protected BLOCPOptionsReadOnly(IAuditingArgumentsReadOnly caller, DLOCPOptionsReadOnly dataAccess)
    //        : base(caller, dataAccess)
    //    {
    //    }

    //    public override TOutcome Save(OCPOptionsReadOnly model)
    //    {
    //        return new List<OutcomeItem>();
    //    }

    //    protected override object AnonymousTableRowFacade(OCPOptionsReadOnly model)
    //    {
    //        return OCPOptionsReadOnly.AnonymousTableRowFacade(model);
    //    }

    //}
}
