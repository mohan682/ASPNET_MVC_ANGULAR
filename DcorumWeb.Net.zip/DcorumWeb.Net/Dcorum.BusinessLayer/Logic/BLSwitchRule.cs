﻿using System.Collections.Generic;
using System.ComponentModel;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(null)]
    public class BLSwitchRule //: BaseLogic
    {
        public static List<SwitchRule> GetSwitchRulesByCase(int caseKey)
        {
           return  DLSwitchRule.GetSwitchRulesByCase(caseKey);
        }
    }
}
