﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DcorumComponentUFundMix)]
    public class BLUnderlyingFundMix  : BaseLogic
    {
        public static List<UnderlyingFundMix> GetUnderlyingFundMixes(int fundGroupNumber)
        {
            return DLUnderlyingFundMix.GetUnderlyingFundMixes(fundGroupNumber);
        }


        public static List<PDIMessage> SaveFundMixInformation(List<UnderlyingFundMix> recordsToSave, int userId)
        {
            List<PDIMessage> executionOutcome = new List<PDIMessage>();
            DLUnderlyingFundMix fundMixDataLayer = new DLUnderlyingFundMix();

            UnderlyingFundMixGroup groupLevelRecord = new UnderlyingFundMixGroup();
            groupLevelRecord.TotalPercentage = recordsToSave.Sum(x => x.Percentage.HasValue ? x.Percentage.Value : 0);

            if (!BLFundDomainGroup.Validate(groupLevelRecord, true))
                executionOutcome.AddRange(groupLevelRecord.errorList);
            else
                try
                {
                    fundMixDataLayer.StartTransaction();
                    foreach (UnderlyingFundMix record in recordsToSave)
                    {
                        UnderlyingFundMix existingFundMix = null, newFundMix = null;
                        bool ddlOutcome = false;
                        bool raiseFailure = false;

                        if (record.UnderLyingFundMixId != null && (record.Percentage == 0 || record.Percentage == null))
                        {
                            existingFundMix = DLUnderlyingFundMix.GetUnderlyingFundMix(record.UnderLyingFundMixId.Value);
                            ddlOutcome = AppendError(fundMixDataLayer.DeleteUnderlyingInvestmentType(record.UnderLyingFundMixId.Value), Constants.ValidationErrorCodes.DBOperationInternalError, record, executionOutcome);
                            raiseFailure = !ddlOutcome;
                        }
                        else if (record.UnderLyingFundMixId != null && record.Percentage != null && record.Percentage > 0)
                        {
                            existingFundMix = DLUnderlyingFundMix.GetUnderlyingFundMix(record.UnderLyingFundMixId.Value);
                            if (existingFundMix.Percentage != record.Percentage)
                            {
                                ddlOutcome = AppendError(fundMixDataLayer.UpdateUnderLyingFundMix(record), Constants.ValidationErrorCodes.DBOperationInternalError, record, executionOutcome);
                                raiseFailure = !ddlOutcome;
                                newFundMix = record;
                            }
                        }
                        else if (record.UnderLyingFundMixId == null && record.Percentage != null && record.Percentage > 0)
                        {
                            if (Validate(record, true))
                            {
                                ddlOutcome = AppendError(fundMixDataLayer.InsertUnderLyingFundMix(record), Constants.ValidationErrorCodes.DBOperationInternalError, record, executionOutcome);
                                raiseFailure = !ddlOutcome;
                                newFundMix = record;
                            }
                            else
                                raiseFailure = true;
                        }

                        if (ddlOutcome && !CreateAuditRecord(userId, Constants.DomainCodes.DcorumComponentUFundMix, newFundMix, existingFundMix))
                        {
                            raiseFailure = true;
                            executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationAuditFailure));
                        }

                        if (record.errorList != null) executionOutcome.AddRange(record.errorList);
                        if (raiseFailure) throw new Exception("Unable To Process request");
                    }
                    fundMixDataLayer.CompleteTransaction(true);
                }
                catch (Exception ex)
                {
                    fundMixDataLayer.CompleteTransaction(false);
                }

            return executionOutcome;
        }

        private static bool AppendError(bool operationStatus, string errorCode, UnderlyingFundMix record, List<PDIMessage> errorList)
        {
            if (!operationStatus)
            {
                PDIMessage pdiMessage = BLPDIMessage.GetPDIMessageById(errorCode);
                pdiMessage.MessageText += record != null ? " - " + record.InvestmentTypeId : "";
                errorList.Add(pdiMessage);
            }
            return operationStatus;
        }

        private static bool Validate(UnderlyingFundMix rec, bool addErrorMessage)
        {
            rec.errorList = new List<PDIMessage>();
            if (rec.UnderLyingFundMixId == null && DLUnderlyingFundMix.GetUnderlyingFundMix(rec.FundGroupNumber, rec.InvestmentTypeId) != null)
            {
                PDIMessage pdiMessage = BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationRecordAlreadyExists);
                pdiMessage.MessageText += " - " + rec.InvestmentTypeId;
                rec.errorList.Add(pdiMessage);
            }

            return rec.errorList.Count == 0;
        }
    }




        /*************************************************************************************
         ******************       Fund Group Related Class & Methods        ******************
         *************************************************************************************/

    public class BLFundDomainGroup
    {
        private static PDIMessage fundMixTotPctError = null;

        public static List<UnderlyingFundMixGroup> GetAllFundGroupsWithMixes()
        {
            List<UnderlyingFundMixGroup> fundMixGroups = DLUnderlyingFundMix.GetAllFundGroupsWithMixes();
            foreach (UnderlyingFundMixGroup fundMixGroup in fundMixGroups)
                fundMixGroup.IsValid = Validate(fundMixGroup, false);

            return fundMixGroups;
        }

        public static UnderlyingFundMixGroup GetFundGroupsWithMixes(int fundGroupNumber)
        {
            return DLUnderlyingFundMix.GetFundGroupsWithMixes(fundGroupNumber);
        }

        internal static bool Validate(UnderlyingFundMixGroup rec, bool addErrorMessage)
        {
            rec.errorList = new List<PDIMessage>();
            if (rec.TotalPercentage != 100 && (rec.NoOfTPSchemesLinked > 0 || rec.NoOfTPSchemesLinked == null))
            {
                if (addErrorMessage && fundMixTotPctError == null)
                    fundMixTotPctError = BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.FundMixTotalPercentageError);

                rec.errorList.Add(addErrorMessage ? fundMixTotPctError : new PDIMessage());
            }

            return rec.errorList.Count == 0;
        }
    }
}
