﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.Logic
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    [Category(DomainCodes.DcorumComponentFundClass)]
    public class BLFundClassDetail : BLPersistorTemplate<FundClassDetail>
    {
        private static DLFundClassDetail _dataAccess = new DLFundClassDetail();

        public BLFundClassDetail()
            : base(_dataAccess)
        {
        }

        public override TOutcome Save(FundClassDetail model)
        {
            if (model.ExpiryDate.HasValue && model.ExpiryDate.Value < model.EffectiveDate)
            {
                var effectiveDateMessage = new[] { new PDIMessage { MessageText = "Expiry date should be greater than effective date." } };
                return effectiveDateMessage;
            }
            
            return base.Save(model);
        }


        public void PickUpNewSchemesAndFundsFromCompass( int caseKey)
        {
            _dataAccess.PickUpNewSchemesAndFundsFromCompass(caseKey);
        }

        public Tuple<string, string>[] GetSchemAndMemberGroups(int caseKey)
        {
            return _dataAccess.GetSchemAndMemberGroups(caseKey);
        }

        public FundClassDetail[] SelectMany(int caseKey, int? mbrGroupKey)
        {
            return _dataAccess.SelectMany(caseKey, mbrGroupKey);
        }

        protected override object AnonymousTableRowFacade(FundClassDetail model)
        {
            return GetAnonymousTableRowFacade(model);
        }

        public object GetAnonymousTableRowFacade(FundClassDetail model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.FundClassDetailId,
                Identifier = model.FundDescriptionId.ToString(),
                Name__________________________________ = model.FundLongName,
                Core_Fund = model.IsCoreFund ? "Yes" : "No",
                Annual_Management_Charge = model.AnnualManagementCharge.ToString(),
                Charge_Met_By = model.ChargeMetBy.ToString(),
                Active_fund_class_________ = model.ActiveFundClass.ToString(),
                _Active_fund_class_Id = model.ActiveFundClass.RefCd,
                _AllowInvestmentByMoneyType = model.AllowInvestmentByMoneyType.ToString(),
                Effective_Date = model.EffectiveDate.ToShortDateString(),
                Expiry_Date = model.ExpiryDate.HasValue ? model.ExpiryDate.Value.ToShortDateString() : string.Empty
            };

            return facade1;
        }
    }
}
