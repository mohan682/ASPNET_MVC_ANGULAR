﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DCorum.BusinessFoundation;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Entities.BulkSwitching;
using System.Configuration;
using Dcorum.BusinessLayer.Logic.Helping;

namespace Dcorum.BusinessLayer.Logic
{
    public class BLBulkSwitchingLoad : SimpleSavePersistor<BulkSwitchLoad, int>, IPersistor<BulkSwitchLoad>
	{
		/// <summary>
		/// CHANGE THIS!!!!
		/// </summary>
		private const string SqlTemplate = @"
                                            BEGIN
                                               Insert into SERVICE_TASK_QUEUE
                                                   (SERVICE_TASK_QUEUE_ID, SERVICE_TASK_ID, SCHEDULE_DATE, PROCESS_DATE, LOCKED, 
                                                    THREAD_NO, ACTIVE, STATUS_CD)
                                                Values
                                                   (SERVICE_TASK_QUEUE_ID_SEQ.nextval, 152, sysdate, NULL, '0', NULL, '1', 'PE');

                                                Insert into SERVICE_TASK_QUEUE_PARAM
                                                   (SERVICE_TASK_QUEUE_ID, PARAM_NAME, PARAM_VALUE, PARAM_ORDER, PARAM_TYPE)
                                                Values
                                                   (SERVICE_TASK_QUEUE_ID_SEQ.Currval, 'Target_Folder', '{0}', 1, 'STRING');

                                                Insert into SERVICE_TASK_QUEUE_PARAM
                                                   (SERVICE_TASK_QUEUE_ID, PARAM_NAME, PARAM_VALUE, PARAM_ORDER, PARAM_TYPE)
                                                Values
                                                   (SERVICE_TASK_QUEUE_ID_SEQ.Currval, 'Last_Run_Time', '{1}', 2, 'STRING');
                                            END;
                                            ";

		private List<PDIMessage> ExecutionOutcome { get; set; }

		public BLBulkSwitchingLoad()
		{
			ExecutionOutcome = new List<PDIMessage>();
		}

		protected override string GetInsertSql(BulkSwitchLoad arguments)
		{
            int minutes = int.Parse(ConfigurationManager.AppSettings["BulkSwitching.Load.Time"]);

            string datafile = ConfigurationManager.AppSettings["BulkSwitching.Load.TargetFolder"];

            TimeSpan ts = TimeSpan.FromMinutes(minutes);

            return String.Format(SqlTemplate, datafile, ts.ToString());
		}

		protected override void AddNoRowsAffectedError()
		{
			ExecutionOutcome.Add( BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationInternalError) );
		}

		protected override IEnumerable<IOutcomeItem> GetOutcomeItems()
		{
			return ExecutionOutcome;
		}
	}
}
