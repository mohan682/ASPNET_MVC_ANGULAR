﻿using System.Collections.Generic;
using System.ComponentModel;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic.Helping;

namespace Dcorum.BusinessLayer.Logic
{
    public class BLCaseMoneyTypeGroup 
    {
        public static CaseMoneyTypeGroup[] Select(int caseKey)
        {
            return DLMoneyTypeGroup.Select(caseKey);
        }
    }


    [Category(DomainCodes.DcorumComponentMoneyType)]
    public class BLMoneyTypeGroup //: BaseLogic
    {      
        private const string Category = Constants.DomainCodes.DcorumComponentMoneyType;

        public static MoneyTypeGroup GetCaseMoneyTypeGroupByKey(int caseMoneyTypeGroupKey)
        {
            return DLMoneyTypeGroup.GetCaseMoneyTypeGroupByKey(caseMoneyTypeGroupKey);
        }

        public static MoneyTypeGroup GetMoneyTypeGroupByKey(int caseId,int moneyGroupTypeKey)
        {
            return DLMoneyTypeGroup.GetMoneyTypeGroupByKey(caseId,moneyGroupTypeKey);
        }

        public static List<MoneyTypeGroup> GetMoneyTypeGroupByCase(int caseId)
        {
            return DLMoneyTypeGroup.GetMoneyTypeGroupByCase(caseId);
        }

        public static List<PDIMessage> Save(MoneyTypeGroup moneyTypeGroup)
        {
            return BLHelper.PersistChanges(moneyTypeGroup, DLMoneyTypeGroup.Save, DLMoneyTypeGroup.GetCaseMoneyTypeGroupByKey, _ => _.CaseMoneyTypeGroupKey, Category, false);

            //bool isUpdate=false;
            //MoneyTypeGroup existingMoneyTypeGroup=null;
            //if (moneyTypeGroup.CaseMoneyTypeGroupKey > 0)
            //{
            //    existingMoneyTypeGroup = GetMoneyTypeGroupByKey(moneyTypeGroup.CaseKey.Value, moneyTypeGroup.MoneyTypeGroupKey);
            //    isUpdate=true;                
            //}          

            // DLMoneyTypeGroup.Save(moneyTypeGroup);
            // CreateAuditRecord(moneyTypeGroup.UserId, Constants.DomainCodes.DcorumComponentMoneyType, moneyTypeGroup, (isUpdate) ? existingMoneyTypeGroup : null);

            //return true;
        }

        public static List<PDIMessage> Delete(MoneyTypeGroup model)
        {
            return BLHelper.PersistChanges(model, DLMoneyTypeGroup.Delete, DLMoneyTypeGroup.GetCaseMoneyTypeGroupByKey, _ => _.CaseMoneyTypeGroupKey, Category, true);

            //DLMoneyTypeGroup.Delete(caseMoneyTypeGroupKey.CaseMoneyTypeGroupKey);

            //CreateAuditRecord(caseMoneyTypeGroupKey.UserId, Constants.DomainCodes.DcorumComponentMoneyType, null, caseMoneyTypeGroupKey);

            //return true;
        }
       

        public static IEnumerable<MoneyTypeGroup> GetMoneyTypeGroupsForCaseByExcludingCurrMapps(int CaseKey)
        {
            return DLMoneyTypeGroup.GetMoneyTypeGroupsForCaseByExcludingCurrMapps(CaseKey);
        }

        public static bool IsExists(int caseKey,int moneyTypeGroupKey)
        {
            return DLMoneyTypeGroup.IsExists(caseKey, moneyTypeGroupKey);
        }
    }
}
