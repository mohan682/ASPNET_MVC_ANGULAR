﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.Extensions;
using Dcorum.RefCoding;
using System.Linq;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DCorumComponentMaintenanceMessage)]
    public class BLMaintenanceMessage : BaseLogic
    {
        private static string _dbDateFormatString = "DD/MM/YYYY HH24:MI:SS";

        public static List<MaintenanceMessage> GetMaintenanceMessages(bool includingExpired)
        {
            List<MaintenanceMessage> recordsToReturn = DLMaintenanceMessage.GetMaintenanceMessages(includingExpired, _dbDateFormatString);
            foreach (MaintenanceMessage rec in recordsToReturn)
                PopulatederivedFields(rec);

            return recordsToReturn;
        }

        public static MaintenanceMessage GetMaintenanceMessage(int id)
        {
            MaintenanceMessage recordToReturn = DLMaintenanceMessage.GetMaintenanceMessage(id, _dbDateFormatString);
            PopulatederivedFields(recordToReturn);
            return recordToReturn;
        }

        public static List<PDIMessage> Save(MaintenanceMessage message)
        {
            List<PDIMessage> executionOutcome = new List<PDIMessage>();

            MaintenanceMessage existingMessage = message.Id > 0 ? GetMaintenanceMessage(message.Id) : null;

            PopulatederivedFields(message);
            if (Validate(message, true))
            {
                DLMaintenanceMessage.Save(message, _dbDateFormatString);
                if (!CreateAuditRecord(message.UserId, Constants.DomainCodes.DCorumComponentMaintenanceMessage, message, existingMessage))
                    executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationAuditFailure));
            }
            else
                executionOutcome.AddRange(message.errorList);

            return executionOutcome;
        }

        public static List<PDIMessage> Delete(MaintenanceMessage message)
        {
            List<PDIMessage> executionOutcome = new List<PDIMessage>();
            MaintenanceMessage existingMessage = GetMaintenanceMessage(message.Id);

            if (DLMaintenanceMessage.Delete(message.Id) > 0)
            {
                existingMessage.UserId = message.UserId;
                if (!CreateAuditRecord(message.UserId, Constants.DomainCodes.DCorumComponentMaintenanceMessage, null, existingMessage))
                    executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationAuditFailure));
            }
            else
                executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationInternalError));

            return executionOutcome;
        }


        private static bool Validate(MaintenanceMessage rec, bool addErrorMessage)
        {
            rec.errorList = new List<PDIMessage>();

            bool success = Validate(rec).Any()==false ;

            if (addErrorMessage) rec.errorList.AddRange(Validate(rec));

            return success;
        }


        private static IEnumerable<PDIMessage> Validate(MaintenanceMessage rec)
        {
            if (rec.CaseKey == null & rec.MbGpKey == null)
                yield return BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.BothSchemeAndMbrGroupEmpty);

            if (rec.IsSchemeMessageLevel && rec.CaseKey == null)
                yield return BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.InvalidSchemeSelected);

            if (!rec.IsSchemeMessageLevel && rec.MbGpKey == null)
                yield return BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.InvalidMemberGroupSelected);

            if (!String.IsNullOrWhiteSpace(rec.EffectiveDateTime) & !String.IsNullOrWhiteSpace(rec.ExpiryDateTime))
            {
                DateTime effDtTm = DateTime.ParseExact(rec.EffectiveDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                DateTime expDtTm = DateTime.ParseExact(rec.ExpiryDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                if (!(expDtTm > effDtTm))
                    yield return BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.ExpiryDtGreaterThanEffectiveDt);
            }
        }


        private static void PopulatederivedFields(MaintenanceMessage message)
        {
            if (message == null) return;

            RefCodeHelp.DoBuildRefCodes(message, true);
            if (message.IsSchemeMessageLevel)
            {
                message.CaseKey = message.RefCode.IntoNullableValue<int>();
                message.AccessLevelName = string.Format("[{0}] {1}", message.SchemeExternalId, message.SchemeName);
            }
            else
            {
                message.MbGpKey = message.RefCode.IntoNullableValue<int>();
                message.AccessLevelName = string.Format("[{0}] {1}", message.MbGpKey, message.MbgpName);
            }
        }
    }
}
