﻿using System;
using System.ComponentModel;
using System.Linq;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic.Helping;
using Dcorum.RefCoding;
using DcorumWeb.Utilities;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(null)]
    public class BLStandingDataAudit 
    {

        internal BLStandingDataAudit(IAuditingArgumentsReadOnly caller, DLDataAudit dataAccess)
        {
            DLDataAudit = dataAccess;
            if (DLDataAudit == null) throw new ArgumentNullException(nameof(dataAccess));
        }

        private readonly DLDataAudit DLDataAudit;



        public DataAudit[] GetDataAuditRecords(DataAudit dataAuditSearchFilter)
        {
            PopulatederivedFields(dataAuditSearchFilter);
            DataAudit[] dataAuditRecords = DLDataAudit.GetDataAuditRecords(dataAuditSearchFilter);

            foreach (DataAudit auditRecord in dataAuditRecords)
            {
                PopulatederivedFields(auditRecord);
            }

            return dataAuditRecords;
        }


        public DataAudit GetDataAuditRecordById(int dataAuditId )
        {
            DataAudit dataAuditRecord = DLDataAudit.GetDataAuditRecordById(dataAuditId);

            PopulatederivedFields(dataAuditRecord);

            return dataAuditRecord;
        }


        private void PopulatederivedFields(DataAudit dataAudit)
        {
            if (dataAudit == null) return;

            var pair1 = dataAudit.GetAuditFriendlyIdentity();

            if (dataAudit.IdentifierType == null)
                dataAudit.IdentifierType = pair1.Item1;

            if (dataAudit.AuditIdentifier == null)
                dataAudit.AuditIdentifier = pair1.Item2;

            RefCodeHelp.DoBuildRefCodes(dataAudit, true);

        }

        /// <summary>
        /// Maniplate new and existing values to extract the identity of the changed entity.
        /// </summary>
        public string ExtractIdentity(DataAudit model)
        {
            string planBAuditedId = null;
            if (model.IdentifierType == null || String.IsNullOrWhiteSpace(model.IdentifierType.RefCd))
            {
                if (!String.IsNullOrWhiteSpace(model.AuditIdentifier)) planBAuditedId = model.AuditIdentifier;
            }

            string result = ExtractIdentityCore(model, planBAuditedId) ?? planBAuditedId;
            return result;
        }

        /// <summary>
        /// Maniplate new and existing values to extract the identity of the changed entity.
        /// </summary>
        private string ExtractIdentityCore(DataAudit model, string possibleAuditedId)
        {
            string[] rows1 = model.ExistingValue.Split(new[] {Environment.NewLine}, StringSplitOptions.None);
            string[] rows2 = model.NewValue.Split(new[] {Environment.NewLine}, StringSplitOptions.None);

            string identity1 = rows1.FirstOrDefault().NullIfWhiteSpace();
            string identity2 = rows2.FirstOrDefault().NullIfWhiteSpace();

            //if both not blank and still different then get out early...
            if (identity1==null && identity2==null) return null;
            if (identity1 != identity2 && identity1!=null && identity2!=null) return null;

            //main algorithm...
            bool identityDetected = (identity1 == identity2);

            if (!identityDetected)
            {
                string possibleIdentity = (identity1 ?? identity2 );
                int index1 = possibleIdentity.IndexOf(":");
                if (!(index1 > 0)) return null;
                string preValuePart = possibleIdentity.Substring(0,index1);
                identityDetected |= (preValuePart.Equals(preValuePart.ToUpperInvariant()));
            }

            if (!identityDetected)
            {
                return null;
            }

            string identity = identity1 ?? identity2;
            if (identity.IsNullOrWhitesSpace()) return null;

            if (possibleAuditedId!=null && !identity.Contains("[" + possibleAuditedId + "]")) return null;


            if (identity1 != null) //remove top row...
            {
                model.ExistingValue = String.Join(Environment.NewLine, rows1.Skip(1));
            }

            if (identity2 != null) //remove top row...
            {
                model.NewValue = String.Join(Environment.NewLine, rows2.Skip(1));
            }
       
            identity = identity.Replace("[", null).Replace("]", null);
            return identity;
        }
    }
}
