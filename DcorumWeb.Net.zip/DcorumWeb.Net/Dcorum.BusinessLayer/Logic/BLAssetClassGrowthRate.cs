﻿using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.RefCoding;
using Dcorum.Utilities;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Dcorum.BusinessLayer.Logic
{
    public class BLAssetClassGrowthRate
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal BLAssetClassGrowthRate(IAuditingArgumentsReadOnly caller, DLAssetClassGrowthRate dataAccess)
        {
            _userId = caller.UserId;
            _myDataAccess = dataAccess;
            if (_myDataAccess == null) throw new ArgumentNullException(nameof(_myDataAccess));
        }

        private int _userId;
        private readonly DLAssetClassGrowthRate _myDataAccess ;
        private RemarksVessel _remarks = new RemarksVessel();


        public AssetClassGrowthRate[] GetAllAssetClassGrowthRates()
        {
            var retVal = _myDataAccess.GetAllAssetClassGrowthRates();

            foreach (var rec in retVal.Where(rec => rec != null))
            {
                rec.DoBuildRefCodes();
            }

            return retVal;
        }

        public IEnumerable<IOutcomeItem> Save(AssetClassGrowthRate model)
        {
            int success = 0 ;

            try
            {
                if (model == null) _remarks.RemarkNoItemSpecified = true;
                if ((model?.AssetClassGrowthRateId < 0)) _remarks.RemarkInvalidIdentityDetected = true;

                if (_remarks.IsEmpty == false)
                {
                    return _remarks.YieldAndPurgeAll();
                }

                var originalValues = GetSingle(model.AssetClassGrowthRateId, null);

                bool insertModeOn = !(model.AssetClassGrowthRateId > 0);

                var potentialDuplicates = _myDataAccess.FetchDuplicates(model);

                if (insertModeOn)
                {
                    if (potentialDuplicates.Any()) _remarks.DuplicatesDetected = true ;

                    if (_remarks.IsEmpty)
                    {
                        success = _myDataAccess.InsertAssetClassGrowthRate(model);            
                    }
                    else
                    {
                        return _remarks.YieldAndPurgeAll();
                    }
                }
                else
                {
                    bool hasDuplicates = potentialDuplicates.Any(_ => _.AssetClassGrowthRateId != model.AssetClassGrowthRateId);

                    if (hasDuplicates) _remarks.DuplicatesDetected = true;

                    if (_remarks.IsEmpty)
                    {
                        success = _myDataAccess.UpdateAssetClassGrowthRate(model);
                    }
                    else
                    {
                        return _remarks.YieldAndPurgeAll();
                    }
                }

                CreateAuditRecord(success > 0, model, originalValues);
            }
            catch (Exception ex)
            {
                _remarks.IncludeCustomRemarks(new[] { ex.Message });
                EventLogger.WriteError(ex);
            }

            return _remarks.YieldAndPurgeAll();
        }


        public AssetClassGrowthRate GetSingle(int? myId, Action<AssetClassGrowthRate> projectionOntoModelTechnique = null)
        {
            if (myId < 0) throw new ArgumentException(string.Empty, nameof(myId));
            if (myId == null)  return null ;

            AssetClassGrowthRate result = (myId == 0)? new AssetClassGrowthRate(null) : _myDataAccess.GetAssetClassGrowthRateById(myId.Value) ;
            Debug.Assert(result != null);

            projectionOntoModelTechnique?.Invoke(result); //opportunity to manipulate/assign values before ref code hydration.
            result.DoBuildRefCodes();

            return result;
        }


        public IEnumerable<IOutcomeItem> Delete(AssetClassGrowthRate model)
        {
            int success = 0; 

            try
            {
                if (model == null) _remarks.RemarkNoItemSpecified = true;
                if ((model?.AssetClassGrowthRateId <= 0)) _remarks.RemarkInvalidIdentityDetected = true ;

                if (_remarks.IsEmpty == false)
                {
                    return _remarks.YieldAndPurgeAll();
                }

                if (_remarks.IsEmpty)
                {
                    success = _myDataAccess.DeleteAssetClassGrowthRate(model);
                }
                else
                {
                    return _remarks.YieldAndPurgeAll();
                }
            
                CreateAuditRecord(success > 0, null, model);
            }
            catch (Exception ex)
            {
                _remarks.IncludeCustomRemarks(new[] { ex.Message });
                EventLogger.WriteError(ex);
            }

            return _remarks.YieldAndPurgeAll();
        }


        private void CreateAuditRecord(bool success, AssetClassGrowthRate newValues, AssetClassGrowthRate oldValues)
        {
            var auditor = BusinessCoreFactoryMethods.CreateAuditor(DomainCodes.DcorumComponentAssetClassGrowthRate, _userId, _remarks);       
            auditor.AuditChanges(success, newValues, oldValues, null);
        }
    }
}
