﻿using DCorum.BusinessFoundation.Bases;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.Logic
{
    //public class BLStaticResponseGroup : BLRetrieverTemplate<StaticResponseGroup>
    //{
    //    private static DLStaticResponseGroup _dataAccess = new DLStaticResponseGroup();

    //    public BLStaticResponseGroup()
    //        : base(_dataAccess)
    //    {
            
    //    }
    //}


    //public class BLStaticResponseGroup : BaseLogic
    //{
    //    private static DLStaticResponseGroup _dataAccess = new DLStaticResponseGroup();

    //    public StaticResponseGroup[] Fill(int userAccId)
    //    {
    //        return _dataAccess.GetStaticResponseGroups();
    //    }
    //}
}
