﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic.Helping;
using Dcorum.RefCoding;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.Practices;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Contractual;
using DCorum.BusinessFoundation.Auditing.Constants;
using Dcorum.BusinessLayer.Core;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DcorumComponentMemberGroup)]
    public class BLMemberGroup
    {
        private static MemberGroupValidator _validator1 = new MemberGroupValidator();
        private static DlMemberGroup DlMemberGroup = new DlMemberGroup(new MemberGroupSql());

        public static List<MemberGroup> GetMemberGroupsForScheme(int case_key)
        {
            var recordsToReturn = DlMemberGroup.GetAllMemberGroups(case_key);
            foreach (var rec in recordsToReturn)
            {
                rec.IsValid = _validator1.ValidateMemberGroup(rec);
                PopulatederivedFields(rec);
            }

            return recordsToReturn.ToList();
        }


        public static MemberGroup GetMemeGroup(int memberGroupId)
        {
            MemberGroup memberGroup = DlMemberGroup.GetMemberGroup(memberGroupId);

            PopulatederivedFields(memberGroup);

            return memberGroup;
        }


        public static List<MemberGroupThin> GetBenefitMemberGroups(int caseKey)
        {
            var recordsToReturn = DlMemberGroup.GetMemberGroupsByType(caseKey, MemberGroupDomainCodes.BenefitMemberGroupType);
            foreach (var rec in recordsToReturn)
                PopulatederivedFields(rec);

            return recordsToReturn.ToList();
        }


        public static List<MemberGroupThin> GetInvestmentMemberGroups(int caseKey)
        {
            var recordsToReturn = DlMemberGroup.GetMemberGroupsByType(caseKey, MemberGroupDomainCodes.InvestmentMemberGroupType);
            foreach (var rec in recordsToReturn)
                PopulatederivedFields(rec);

            return recordsToReturn.ToList();
        }

        public static List<MemberGroupThin> GetGroupsByTypeAndInvAvailableTo(int caseKey, int? currMbrGrpKey)
        {
            var recordsToReturn = DlMemberGroup.GetMemberGroupsByTypeAndInvAvailableTo(caseKey, 
                string.Empty, MemberGroupDomainCodes.InvestmentAvailableToDefer);
            foreach (var rec in recordsToReturn)
                PopulatederivedFields(rec);

            return recordsToReturn.Where(o => (currMbrGrpKey.HasValue && currMbrGrpKey.Value != o.MbGpKey)).ToList();            
        }

        private static void PopulatederivedFields(MemberGroupThin memberGroup)
        {
            if (memberGroup == null) return;

            memberGroup.DoBuildRefCodes();
        }

    }


    internal class MemberGroupDerivedStateAdaptor
    {
        public MemberGroupDerivedStateAdaptor(MemberGroup toAdapt)
        {
            _adaptee = toAdapt;
        }

        private MemberGroup _adaptee;

        public bool IsBenefit()
        {
            return _adaptee.Type.IsMatch(MemberGroupDomainCodes.BenefitMemberGroupType);
        }


        public bool IsInvestment()
        {
            return _adaptee.Type.IsMatch(MemberGroupDomainCodes.InvestmentMemberGroupType);
        }

        public bool IsDeferred()
        {
            return _adaptee.InvAvlableTo.IsMatch(MemberGroupDomainCodes.InvestmentAvailableToDefer);
        }

        public bool DoesNotExist()
        {
            return _adaptee.UextMBGrpExists.IsNoFlag();
        }


        public bool IsAssociateOf(MemberGroup toAdapt)
        {
            bool result = ReferenceEquals(toAdapt, _adaptee);
            return result;
        }
    }

    /// <summary>
    /// [DERIVED]
    /// </summary>
    public class MemberGroupPlus : MemberGroup
    {
        internal MemberGroupPlus()
        {

            _adaptor1 = new MemberGroupDerivedStateAdaptor(this);
        }

        private readonly MemberGroupDerivedStateAdaptor _adaptor1;

        public bool IsBenefit
        {
            get
            {
                return _adaptor1.IsBenefit();
            }
        }


        public bool IsInvestment
        {
            get
            {
                return _adaptor1.IsInvestment();
            }
        }


        public bool DoesNotExist
        {
            get
            {
                return _adaptor1.DoesNotExist();
            }
        }


        [UIHint("lblMbrGrpTypeDesc")]
        public string SubHeading1
        {
            get
            {
                return String.Format("{0} Member Group Settings", (IsBenefit) ? "Benefit" : "Switch");
            }
        }
    }


    /// <summary>
    /// [STATELESS]
    /// </summary>
    internal class MemberGroupValidator
    {
        public bool ValidateMemberGroup(MemberGroup rec)
        {
            var adaption1 = new MemberGroupDerivedStateAdaptor(rec);

            int tally = FullValidate(rec, adaption1).Count();
            return tally>0 ;
        }


        public IEnumerable<IOutcomeItem> ValidateMemberGroupPreSave(MemberGroup rec, bool addErrorMessage = true)
        {
            var adaption1 = new MemberGroupDerivedStateAdaptor(rec);

            string[] validationCodes = CommonValidate(rec, adaption1).ToArray();

            var sink = new PdiMessageContainer();

            foreach(var current1 in validationCodes )
            {
                sink.AddCode(current1);
            }
            return sink.ToArray() ;
        }


        private IEnumerable<string> FullValidate(MemberGroup rec, MemberGroupDerivedStateAdaptor adaption1)
        {
            Debug.Assert(adaption1.IsAssociateOf(rec));

            return CommonValidate(rec, adaption1).Concat(OtherValidate(rec, adaption1));
        }


        private IEnumerable<string> OtherValidate(MemberGroup rec, MemberGroupDerivedStateAdaptor adaption1)
        {
            Debug.Assert(adaption1.IsAssociateOf(rec));

            if (rec.UextMBGrpExists != null && adaption1.DoesNotExist()) yield return ValidationErrorCodes.InvalidMemberGroupSelected;
        }


        private IEnumerable<string> CommonValidate(MemberGroup rec, MemberGroupDerivedStateAdaptor adaption1)
        {
            Debug.Assert(adaption1.IsAssociateOf(rec));

            if (adaption1.IsBenefit())
            {
                bool isInvalid = false;
                isInvalid |= rec.IsDefault.IsNotNoFlag(); //(rec.IsDefault != null && String.Compare(rec.IsDefault.RefCd, Constants.DomainCodes.NumberValueOfNoFlag, true) != 0);
                isInvalid |= rec.IsCash.IsNotNoFlag();    //(rec.IsCash    != null && String.Compare(rec.IsCash.RefCd,    Constants.DomainCodes.NumberValueOfNoFlag, true) != 0);
                isInvalid |= (rec.InvAvlableTo != null && !String.IsNullOrWhiteSpace(rec.InvAvlableTo.RefCd));
                isInvalid |= !String.IsNullOrWhiteSpace(rec.LinkToDoc);

                if (isInvalid) yield return ValidationErrorCodes.MbrGrpSwitchRuleFieldsNotAllowed;
            }

            if (adaption1.IsInvestment())
            {
                bool isInvalid = false;
                isInvalid |= (rec.ContribBasis != null && !String.IsNullOrWhiteSpace(rec.ContribBasis.RefCd));
                isInvalid |= (rec.ContribBasisAVC != null && String.Compare(rec.ContribBasisAVC.RefCd, MemberGroupDomainCodes.AVCContribBasisNone, true) != 0);
                isInvalid |= (rec.SalarySac != null && !String.IsNullOrWhiteSpace(rec.SalarySac.RefCd));

                if (isInvalid) yield return ValidationErrorCodes.MbrGrpBenefitFieldsNotAllowed;
            }

            if (String.Compare(rec.LinkedToProductGroup, MemberGroupDomainCodes.MoneyPurchaseSchemeProductGroup, true) != 0 || String.Compare(rec.Type.RefCd, MemberGroupDomainCodes.BenefitMemberGroupType, true) != 0)
                if (rec.ContribBasisAVC != null && String.Compare(rec.ContribBasisAVC.RefCd, MemberGroupDomainCodes.AVCContribBasisNone, true) != 0)
                    yield return ValidationErrorCodes.MbrGrpAVCContribBasisbNotAllowed;
        }  
    }

    public class BLMemberGroupEditor
    {
        internal BLMemberGroupEditor(IAuditingArgumentsReadOnly caller, DlMemberGroup dataAccess)
        {
            DlMemberGroup = dataAccess;
            _userId = caller.UserId;
            if (DlMemberGroup == null) throw new ArgumentNullException(nameof(dataAccess));
        }

        private readonly int _userId;
        private readonly DlMemberGroup DlMemberGroup;
        private readonly MemberGroupValidator _validator1 = new MemberGroupValidator();

        public void PreSaveModifications(MemberGroup memberGroup)
        {
            if (memberGroup == null) return;

            var adaption1 = new MemberGroupDerivedStateAdaptor(memberGroup);

            if (adaption1.IsInvestment())
            {
                memberGroup.ContribBasis = RefCodePool.Singleton.ObtainEmpty();
                memberGroup.ContribBasisAVC = new RefCode(MemberGroupDomainCodes.AVCContribBasisNone);
                memberGroup.SalarySac = RefCodePool.Singleton.ObtainEmpty();
                memberGroup.UseNewIllustration = RefCodePool.Singleton.ObtainEmpty();
                memberGroup.IsDefaultBenefitMbrGroup = RefCodePool.Singleton.ObtainNoFlag();
            }

            if (adaption1.IsBenefit())
            {
                memberGroup.IsDefault = RefCodePool.Singleton.ObtainNoFlag();
                memberGroup.IsDefaultBenefitMbrGroup = RefCodePool.Singleton.ObtainYesFlag();
                memberGroup.InvAvlableTo = RefCodePool.Singleton.ObtainEmpty();
                memberGroup.IsCash = RefCodePool.Singleton.ObtainNoFlag();
            }

            memberGroup.IsValid = _validator1.ValidateMemberGroup(memberGroup);
        }

        public IEnumerable<IOutcomeItem> SaveMemberGroup(MemberGroup memberGroup)
        {
            MemberGroup existingMbrGrp = GetMemeGroup(memberGroup.MbGpKey.Value);
            memberGroup.LinkedToProductGroup = existingMbrGrp.LinkedToProductGroup;

            memberGroup.Type = existingMbrGrp.Type;

            //if (!string.IsNullOrEmpty(memberGroup.LinkToDoc))
            //    memberGroup.LinkToDoc = memberGroup.LinkToDoc.Trim().Replace("'", "''");

            if (memberGroup.MbGpKey < 0)
            {
                return new[] { BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationTamperedData) };
            }
            else
            {
                var outcomes = _validator1.ValidateMemberGroupPreSave(memberGroup) ;
                if (outcomes.SafeLinq().Any()) return outcomes;
            }

            //happy path...

            bool ddlOutcome = false;
            Hydrate(memberGroup);

            var adaption1 = new MemberGroupDerivedStateAdaptor(memberGroup);

            if (!adaption1.IsInvestment() || adaption1.IsDeferred())
            {
                // Linked deferred switch group is not valid if the member group is either a non investment group or is 
                // itself a deferred group
                memberGroup.LnkDefSwitchGroup = null;
            }

            if (adaption1.DoesNotExist())
            {
                ddlOutcome = DlMemberGroup.InsertMemberGroup(memberGroup) > 0;
                existingMbrGrp = null;
            }
            else
                ddlOutcome = DlMemberGroup.UpdateMemberGroup(memberGroup) > 0;

            Func<object,Tuple<RefCode,string>> technique1 = @obj => Tuple.Create(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeMbrGrp), ((MemberGroup)@obj).MbGpKey.ToString());

            var results = new AuditService().Audit(ddlOutcome, DomainCodes.DcorumComponentMemberGroup, memberGroup, existingMbrGrp, _userId, technique1 );

            return results;
        }

        public MemberGroupPlus GetExtendedItem(int primaryKey)
        {
            var result = GetMemeGroup(primaryKey);

            if (result == null) return null;

            var extendedResult = new MemberGroupPlus();
            extendedResult.ProjectFromBaseInstance(result);

            return extendedResult;
        }


        public MemberGroup GetMemeGroup(int memberGroupId)
        {
            MemberGroup memberGroup = DlMemberGroup.GetMemberGroup(memberGroupId);

            Hydrate(memberGroup);

            return memberGroup;
        }

        public bool IsDeferredStatus(string status)
        {
            return MemberGroupDomainCodes.InvestmentAvailableToDefer.Equals(status);
        }

        private void Hydrate(MemberGroup memberGroup)
        {
            if (memberGroup == null) return;
            memberGroup.DoBuildRefCodes();
        }
    }
}
