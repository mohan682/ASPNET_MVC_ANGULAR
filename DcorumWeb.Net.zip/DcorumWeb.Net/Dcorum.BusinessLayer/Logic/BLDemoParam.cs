﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.RefCoding;

namespace Dcorum.BusinessLayer.Logic
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    [Category(DomainCodes.DcorumComponentDemoParam)]
    public class BLDemoParam : BLPersistorTemplate<DemoParam, int, int>, ICanBeHydrated<DemoParam>
    {
        private static IList<RefCode> _demoParamKeys = RefCodeCache.RetrieveByDomainName(SpecialDomainNames.DemoParamKeys);


        public BLDemoParam(IAuditingArgumentsReadOnly caller, DLDemoParam persistenceActor)
            : base(caller, persistenceActor)
        {
        }

        public override TOutcome Save(DemoParam demoParam)
        {
            demoParam.DemoParamValue = demoParam.DemoParamValue.Replace("'", "''");
            return base.Save(demoParam);
        }


        protected override object AnonymousTableRowFacade(DemoParam model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.DemoParamId,
                Ref_Code_Description__________________ = model.DemoParamCode.ToString(),
                Display_Value_______________________________________________________ = model.DemoParamValue,
                Programmatic = model.DemoParamCode.Disabled
            };
            return facade1;
        }

        #region ...optimizations...

        public override int GetPrimaryId(DemoParam model)
        {
            return model.DemoParamId.GetValueOrDefault();
        }

        public override void Hydrate(DemoParam demoParam)
        {
            if (demoParam != null)
                demoParam.DemoParamCode = demoParam.DemoParamCode.IntoHydratedRefCodeVia(_demoParamKeys);
        }

        #endregion .../optimizations...
    }

}
