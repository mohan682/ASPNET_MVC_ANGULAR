﻿
using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Configuration.Contractual;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.BusinessLayer.Logic
{
    public class BLAdviserCharging
    {
        internal protected BLAdviserCharging(IDcorumUser caller, DLAdviserChargingQueries queries, DLLetterOfAuthority loaDal, IAuditor loaAuditor, IRemarksActor remarksVessel)
        {
            Queries1 = queries;
            if (Queries1 == null) throw new ArgumentNullException(nameof(queries));

            MyAuditor1 = loaAuditor;
            if (MyAuditor1 == null) throw new ArgumentNullException(nameof(loaAuditor));

            LetterDal = loaDal;
            if (LetterDal == null) throw new ArgumentNullException(nameof(loaDal));

            RemarksVessel = remarksVessel;
            if (RemarksVessel == null) throw new ArgumentNullException(nameof(remarksVessel));

            AuthorityTypes = RefCodeCache.RetrieveByDomainName(DomainNames.LetterAuthorites, true, false);
            if (AuthorityTypes == null) throw new ArgumentException("Domain Name must result in refCode collection!", nameof(DomainNames.LetterAuthorites));

            Titles = RefCodeCache.RetrieveByDomainName(DomainNames.PersonTitle, true, false);
            if (Titles == null) throw new ArgumentException("Domain Name must result in refCode collection!", nameof(DomainNames.PersonTitle));

            UserName = caller.UserName ?? caller.Id.ToString();
            CanEdit = caller.IsInGroup(GroupId.LoaEdit) ;
        }

        private int _numberOfDistinctAdvisers = 0;

        private DLAdviserChargingQueries Queries1 { get; }

        private DLLetterOfAuthority LetterDal { get; }

        public IAuditor MyAuditor1 { get; }

        IRemarksActor RemarksVessel { get; }

        public IReadOnlyCollection<RefCode> Titles { get; }
        public IReadOnlyCollection<RefCode> AuthorityTypes { get; }

        public string UserName { get; }
        public bool CanEdit { get; }
        public bool MoreThan1Adviser { get { return _numberOfDistinctAdvisers > 1; } }

        /// <summary>
        /// [PROJECTION] Project anonymous object
        /// </summary>
        /// <param name="source">[DATA_MODEL]</param>
        /// <returns>[VIEW_MODEL]</returns>
        private object MakeAnonSummary(IReadOnlyDictionary<string, object> source)
        {
           // bool hasFees = source["Has_Fees"].ToString().IntoBoolean() ?? false ;

            if (source["ASSOC_AGT_PCT"].IntoValue<decimal>().GetValueOrDefault() > 0)
                _numberOfDistinctAdvisers++;

            string dataValue1 = source["Type"]?.ToString() ?? string.Empty ;
            string authorityDesc = (AuthorityTypes.FirstOrDefault(rc => dataValue1.Equals(rc.RefCd))?.Descript)
                                ?? dataValue1 
                                ;

            var anon1 = new
            {
                _Agt_Key = source["Agt_Key"].ToString(),
                _Case_Mbr_Key = source["Case_Mbr_Key"]?.ToString(),
                Adviser_Name____________ = string.Format("{0} {1} {2}", ToTitle(source["Adviser_Nameprefix"]), source["Adviser_Firstname"], source["Adviser_Lastname"]),
                FCA_Reference = source["Adviser_Number"]?.ToString(),
                Firm_Name__________ = source["Firm_Name"]?.ToString(),
                LOA_Type____ = authorityDesc,
                Effective_Date = source["EFF_DT"]?.ToString().IntoDateTimeN().SafeFunc(_ => _.ToString("d")),
                Expiry_Date___ = source["XPIR_DT"]?.ToString().IntoDateTimeN().SafeFunc(_ => _.ToString("d")),
                //_Has_Fees = hasFees.ToString(),
                //__canLink = hasFees.ToString(),
            };

            return anon1;
        }


        /// <summary>
        /// [PROJECTION]
        /// </summary>
        /// <param name="source">[DATA_MODEL]</param>
        /// <returns>[VIEW_MODEL]</returns>
        private LoaHeaderViewModel MakeHeaderDetail(IReadOnlyDictionary<string, object> source)
        {

            var Part1 = new LoaAddress()
            {
                Name = string.Format("{0} {1} {2}", ToTitle(source["Adviser_Nameprefix"]), source["Adviser_Firstname"], source["Adviser_Lastname"]),
                RefNumber = source["Adviser_Number"]?.ToString(),
                Email = source["ADVISER_EMAIL"]?.ToString(),
                AddressLine1 = source["ADVISER_ADDR_L1"]?.ToString(),
                AddressLine2 = source["ADVISER_ADDR_L2"]?.ToString(),
                AddressLine3 = source["ADVISER_ADDR_L3"]?.ToString(),
                City = source["ADVISER_ADDR_city"]?.ToString(),
                County = source["ADVISER_ADDR_county"]?.ToString(),
                PostCode = source["ADVISER_ADDR_postcd"]?.ToString(),
            };

            var Part2 = new LoaAddress()
            {
                Name = source["FIRM_NAME"]?.ToString(),
                RefNumber = source["FIRM_REF"]?.ToString(),
                Email = source["FIRM_EMAIL"]?.ToString(),
                AddressLine1 = source["FIRM_ADDR_L1"]?.ToString(),
                AddressLine2 = source["FIRM_ADDR_L2"]?.ToString(),
                AddressLine3 = source["FIRM_ADDR_L3"]?.ToString(),
                City = source["FIRM_ADDR_city"]?.ToString(),
                County = source["FIRM_ADDR_county"]?.ToString(),
                PostCode = source["FIRM_ADDR_postcd"]?.ToString(),
            };

            var Part3 = new LoaAddress()
            {
                Name = source["NTWK_NAME"]?.ToString(),
                RefNumber = source["NTWK_REF"]?.ToString(),
                Email = source["NTWK_EMAIL"]?.ToString(),
                AddressLine1 = source["NTWK_ADDR_L1"]?.ToString(),
                AddressLine2 = source["NTWK_ADDR_L2"]?.ToString(),
                AddressLine3 = source["NTWK_ADDR_L3"]?.ToString(),
                City = source["NTWK_ADDR_city"]?.ToString(),
                County = source["NTWK_ADDR_county"]?.ToString(),
                PostCode = source["NTWK_ADDR_postcd"]?.ToString(),
            };


            var creation1 = new LoaHeaderViewModel()
            {
                AdviserDetail = Part1,
                FirmDetail = Part2,
                NetworkDetail = Part3
            };

            return creation1;
        }


        /// <summary>
        /// [PROJECTION] Project anonymous object
        /// </summary>
        /// <param name="source">[DATA_MODEL]</param>
        /// <returns>[VIEW_MODEL]</returns>
        private object MakeAnonFee(IReadOnlyDictionary<string, object> source)
        {
            bool isCurrency = "C".Equals(source["Percent_Or_Currency"]?.ToString(), StringComparison.InvariantCultureIgnoreCase);
            bool isPercent = "P".Equals(source["Percent_Or_Currency"]?.ToString(), StringComparison.InvariantCultureIgnoreCase);

            var anon1 = new
            {
                //Agt_Key = source["Agt_Key"]?.ToString(),
                Type = source["Charge_Description"]?.ToString(),
                Amount= (isCurrency) ? source["Charge_Amount"]?.ToString().IntoDecimalN()?.ToString("#,0.00") : string.Empty,
                Percentage = (isPercent) ? source["Charge_Amount"]?.ToString().IntoDecimalN()?.ToString("#0.0#") : string.Empty,

                Last_Charge_Date = source["Last_Paid_Dt"]?.ToString().IntoDateTimeN()?.ToString("d"),
                Next_Charge_Date = source["Sched_Nxt_Dt"]?.ToString().IntoDateTimeN()?.ToString("d"),
                Charge_Expires = source["EXPIRY_DT"]?.ToString().IntoDateTimeN()?.ToString("d"),
            };

            return anon1;
        }


        /// <summary>
        /// [PROJECTION] Project anonymous object
        /// </summary>
        /// <param name="source">[DATA_MODEL]</param>
        /// <returns>[VIEW_MODEL]</returns>
        private object MakeAnonLoa(LetterOfAuthority source)
        {
            string authorityDesc = AuthorityTypes.FirstOrDefault(rc => (source.AuthorityType ?? string.Empty).Equals(rc.RefCd))?.Descript;

            var anon1 = new
            {
                _Id = source.LetterOfAuthorityId.ToString(),

                _Case_Mbr_Key = source.CaseMemberKey.ToString(),
                _Agt_Key = source.AgentKey.ToString(),

                Letter_Of_Authority_Type____ = authorityDesc,

                Effective_Date = source.EffectiveDate.ToString("d"),
                Expiry_Date = source.ExpiryDate.SafeFunc(_ => _.ToString("d")),
                __canEdit = CanEdit,
               // __canDelete = CanEdit && (!source.ExpiryDate.HasValue || source.ExpiryDate.Value > DateTime.UtcNow)
            };

            return anon1;
        }


        public string ToTitle(object titleRefCode)
        {
            string titleCode = (titleRefCode ?? string.Empty).ToString();
            string result = Titles.FirstOrDefault(rc => titleCode.Equals(rc.RefCd))?.Descript;
            return result;
        }


        public List<object> GetMemberAgentRows(int? caseMemberKey)
        {
            if (caseMemberKey.HasValue == false) return new List<object>();
            return Queries1.FetchMemberAgents(caseMemberKey.Value).Select(_ => MakeAnonSummary(_)).ToList();
        }

        public LoaHeaderViewModel GetLoaHeaderDetail(int? agentKey, int? caseMemberKey)
        {
            if (agentKey.HasValue == false || caseMemberKey.HasValue == false) return new LoaHeaderViewModel();
            return MakeHeaderDetail(Queries1.FetchLoaHeaderDetail(caseMemberKey.Value, agentKey.Value));
        }

        public List<LetterOfAuthority> GetMemberLoaRows(int? agentKey, int? caseMemberKey)
        {
            if (agentKey.HasValue == false || caseMemberKey.HasValue == false) return new List<LetterOfAuthority>();

            var result = Queries1.FetchLoaRows(caseMemberKey.Value, agentKey.Value).ToList();

            result.ForEach(r=>r.AuthorityTypeObj= RefCodeCache.RetrieveByRefCodeValue(DomainNames.LetterAuthorites,r.AuthorityType));

            return result;
        }

        public List<object> GetMemberFeeRows(int? caseMemberKey)
        {
            if (caseMemberKey.HasValue == false) return new List<object>();
            return Queries1.FetchMemberFees(caseMemberKey.Value).Select(_ => MakeAnonFee(_)).ToList();
        }

        public LetterOfAuthority Get(int letterOfAuthorityId)
        {
            var result = LetterDal.SelectViaPrimaryKey(letterOfAuthorityId);

            return result;
        }

        public IEnumerable<IOutcomeItem> Expiry(int letterOfAuthorityId)
        {
            if (CanEdit == false)
            {
                RemarksVessel.IncludeCustomRemarks(new[] { "This is not permitted in read-only mode!" });
                return RemarksVessel.YieldAndPurgeAll();
            }

            var toSave = LetterDal.SelectViaPrimaryKey(letterOfAuthorityId);

            if (toSave.EffectiveDate.Date==DateTime.UtcNow.Date)
            {
                RemarksVessel.IncludeCustomRemarks(new[] { "You canot expiry a record which is effective today" });
                return RemarksVessel.YieldAndPurgeAll();
            }

            toSave.ExpiryDate = DateTime.UtcNow;

            //Save Logic
            IEnumerable<IOutcomeItem> outcomes = new List<OutcomeItem>();

            var old1 = LetterDal.SelectViaPrimaryKey(toSave.LetterOfAuthorityId);

            outcomes = LetterDal.Save(toSave);

            if (outcomes?.Any() != true) MyAuditor1.AuditChanges(old1, toSave);

            return outcomes;
        }

        public IEnumerable<IOutcomeItem> Save(LetterOfAuthority toSave)
        {
            IEnumerable<IOutcomeItem> outcomes = new List<OutcomeItem>();

            if (CanEdit == false)
            {
                RemarksVessel.IncludeCustomRemarks(new[] { "This is not permitted in read-only mode!" });
                return RemarksVessel.YieldAndPurgeAll();
            }

            //Validation
            if (toSave.EffectiveDate > DateTime.UtcNow)
            {
                RemarksVessel.IncludeCustomRemarks(new[] { "Effective Date should not be future date" });
                return RemarksVessel.YieldAndPurgeAll();

            } 

            var rows = GetMemberLoaRows(toSave.AgentKey, toSave.CaseMemberKey).Where(r =>!r.IsExpired);

            if (rows.Any())
            {
                if (rows.First().EffectiveDate >= toSave.EffectiveDate) return new List<OutcomeItem>() { new OutcomeItem($"Unable to insert a new LOA record until {DateTime.Now.AddDays(1).ToShortDateString()} ") };

                if (rows.First().ExpiryDate.GetValueOrDefault().Date >= toSave.EffectiveDate.Date ||
                   rows.First().EffectiveDate.Date == DateTime.UtcNow.Date)
                {
                    RemarksVessel.IncludeCustomRemarks(new[] { "There is already 1 active record available in the system,please wait until tomorrow to add new record" });
                    return RemarksVessel.YieldAndPurgeAll();
                }
            }


            //Save Logic
            var old1 = LetterDal.SelectViaPrimaryKey(toSave.LetterOfAuthorityId);

            outcomes = LetterDal.Save(toSave);

            if (outcomes?.Any() != true) MyAuditor1.AuditChanges(old1, toSave);

            return outcomes;
        }

    }
}
