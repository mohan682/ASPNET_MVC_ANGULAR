﻿using System.Collections.Generic;
using System.ComponentModel;
using Dcorum.BusinessLayer.Bundles;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using DCorum.BusinessFoundation.Contractual;
using System;

namespace Dcorum.BusinessLayer.Logic
{

    [Category(DomainCodes.DCorumComponentAdminUser)]
    public class BLAdminUser : BLCommonUser<AdminUser>
    {
        internal BLAdminUser(IAuditingArgumentsReadOnly caller, DLAdminUser dataAccess)
            : base(caller, dataAccess)
        {
            _dataAccess = dataAccess;
            if (_dataAccess == null) throw new ArgumentNullException(nameof(dataAccess));
        }

        private readonly IRemarksContainer _remarks = new PdiMessageContainer();
        private readonly DLAdminUser _dataAccess;

        public override string GetTextualIdentityOf(AdminUser model)
        {
            return model.NameId.ToString();
        }

        public IEnumerable<IOutcomeItem> ForceReRegDuringNextLogin(AdminUser model)
        {     
            _remarks.Clear();
            if (_dataAccess.ForceReRegDuringNextLogin(model) > 0)
            {
                BundledContactHistory.BLContactHistory contactHistorySink = new BundledContactHistory.BLContactHistory(model.UserId, model.NameId,BundledContactHistory.ContactHistoryActionWebUserManagement);
                contactHistorySink.Save(0, string.Format("The Admin User has been forced for reregistration by {0}.", model.UserId), null, _remarks);
            }
            else
                _remarks.AddCode(ValidationErrorCodes.DBOperationInternalError);

            return _remarks;

        }

        protected override void Validate(AdminUser model)
        {
            base.Validate(model);

            if (!string.IsNullOrEmpty(model.AwdUserId) && _dataAccess.IsAwdUserAlreadyMapped(model))
                RemarksVessel.IncludeCustomRemarks(new string[] { "AWD User has been already mapped with different user!" });
        }

        protected override object AnonymousTableRowFacade(AdminUser model)
        {
            var result = new
            {
                _PrimaryKey = model.NameId,
                //Active_ = !model.IsNotActive,
                Name_Id__ = model.NameId,
                User_Name____________________ = model.UserName,
                First_Name_____________ = model.FirstName,
                Middle_Name____________ = model.MidName,
                Last_Name_______________ = model.LastName,
                Valid_ = model.IsValid
            };

            return result;
        }
    }


    public abstract class BLCommonUser<TUser> : BLPersistorTemplate<TUser>
        where TUser : CommonUser, new()
        {
        protected BLCommonUser(IAuditingArgumentsReadOnly caller, ICrudFull<TUser, int> crudFull)
            :base(caller, crudFull)
        {
        }


        public override void Hydrate(TUser toBuildUp)
        {
            base.Hydrate(toBuildUp); //used to populate title.
        }


        protected override bool BeforeAuditing(TUser model, int? rowsAffected)
        {
            if (model != null) //will be null during a delete.
            {
                if (model.PasswordModeOn) model.Password = "New password is stored for this user";
            }

            return base.BeforeAuditing(null,rowsAffected);
        }
    }
}
