﻿using System.Collections.Generic;
using System.ComponentModel;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic.Helping;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DcorumComponentMoneyType)]
    public class BLMoneyType //: BaseLogic
    {
        private const string Category = Constants.DomainCodes.DcorumComponentMoneyType;
        

        public static MoneyType[] GetDefaultMoneyTypes(int caseKey, int mtgKey)
        {
            return DLMoneyType.GetDefaultMoneyTypes(caseKey, mtgKey);
        }

        public static MoneyType[] GetMoneyTypes(int cmtgKey)
        {
            return DLMoneyType.GetMoneyTypes(cmtgKey);
        }

        public static MoneyType GetMoneyTypeByCMTGDKey(int cmtgdKey)
        {
            return DLMoneyType.GetMoneyTypeByCMTGDKey(cmtgdKey);
        }

        public static List<PDIMessage> Save(MoneyType moneyType)
        {
            return BLHelper.PersistChanges(moneyType, DLMoneyType.Save, DLMoneyType.GetMoneyTypeByCMTGDKey,
                _ => _.CaseMoneyTypeGroupDetailKey.GetValueOrDefault(), Category, false);

            //List<PDIMessage> executionOutcome = new List<PDIMessage>();
            //MoneyType existingMoneyType = null;

            //if (moneyType.CaseMoneyTypeGroupDetailKey.HasValue && moneyType.CaseMoneyTypeGroupDetailKey > 0)
            //    existingMoneyType = DLMoneyType.GetMoneyTypeByCMTGDKey(moneyType.CaseMoneyTypeGroupDetailKey.Value);

            //int result = DLMoneyType.Save(moneyType);

            //if (result > 0)
            //{
            //    if (existingMoneyType != null)
            //        CreateAuditRecord(moneyType.UserId, Constants.DomainCodes.DcorumComponentMoneyType, moneyType, existingMoneyType);
            //    else
            //        CreateAuditRecord(moneyType.UserId, Constants.DomainCodes.DcorumComponentMoneyType, moneyType, null);
            //}

            //return true;
        }

        public static List<PDIMessage> Delete(MoneyType modelStub)
        {
            return BLHelper.PersistChanges(modelStub, DLMoneyType.Delete, DLMoneyType.GetMoneyTypeByCMTGDKey,
                _ => _.CaseMoneyTypeGroupDetailKey.GetValueOrDefault(), Category, true);

            //if (!modelStub.CaseMoneyTypeGroupDetailKey.HasValue || modelStub.CaseMoneyTypeGroupDetailKey <= 0) return false;
        
            //MoneyType existingMoneyType = DLMoneyType.GetMoneyTypeByCMTGDKey(modelStub.CaseMoneyTypeGroupDetailKey.Value);

            //if (existingMoneyType == null) return false ;

            //Contract.Assert(existingMoneyType.CaseKey == modelStub.CaseKey);
            
            //var result = DLMoneyType.Delete(modelStub.CaseMoneyTypeGroupDetailKey.Value);

            //if (result > 0)
            //{
            //   CreateAuditRecord(modelStub.UserId, Constants.DomainCodes.DcorumComponentMoneyType, null, existingMoneyType);
            //}

            //return true;
        }

        public static bool IsExists(MoneyType moneyType)
        {
            return DLMoneyType.IsExists(moneyType);
        }
    }
}
