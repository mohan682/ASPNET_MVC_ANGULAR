﻿using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.RefCoding;
using System.ComponentModel;

namespace Dcorum.BusinessLayer.Logic
{
    /// <summary>
    /// BAD!!! but to minimise refactoring. Just becauses some other external classes are still fetching via a static method.
    /// </summary>
    public static class BLScheme
    {
        private static SchemeController _defaultFetcherInstance = new SchemeController(new DLScheme(new SchemeSQL()));

        public static Scheme GetScheme(string schemeExternalId)
        {
            return _defaultFetcherInstance.GetScheme(schemeExternalId);
        }

        public static Scheme GetScheme(int schemeId)
        {
            return _defaultFetcherInstance.GetScheme(schemeId);
        }

        public static Scheme[] GetAllSchemes()
        {
            return _defaultFetcherInstance.GetAllSchemes();
        }

        public static Scheme[] GetAllSTargetPlanEnabledchemes()
        {
            return _defaultFetcherInstance.GetAllSTargetPlanEnabledSchemes();
        }

        public static bool IsSchemeAllowedInvestmentByMoneyType(int caseKey)
        {
            return _defaultFetcherInstance.IsSchemeAllowedInvestmentByMoneyType(caseKey);
        }
    }


    [Category(DomainCodes.DCorumComponentScheme)]
    public class SchemeController
    {
        internal SchemeController(DLScheme dataAccess)
        {
            _dataAccess = dataAccess;
        }

        private DLScheme _dataAccess;

        public Scheme GetScheme(int schemeId)
        {
            if (!(schemeId > 0)) return null;
            Scheme schemeRec = _dataAccess.GetScheme(schemeId);
            PopulateDerivedFields(schemeRec);

            return schemeRec;
        }


        internal Scheme GetScheme(string schemeExternalId)
        {
            Scheme schemeRec = _dataAccess.GetScheme(schemeExternalId);
            PopulateDerivedFields(schemeRec);

            return schemeRec;
        }


        internal Scheme[] GetAllSTargetPlanEnabledSchemes()
        {
            return _dataAccess.GetAllSchemes(true);
        }

        internal Scheme[] GetAllSchemes()
        {
            return _dataAccess.GetAllSchemes(false);
        }


        private void PopulateDerivedFields(Scheme schemeRec)
        {
            schemeRec.DoBuildRefCodes();
        }


        internal bool IsSchemeAllowedInvestmentByMoneyType(int caseKey)
        {
            return _dataAccess.IsSchemeAllowedInvestmentByMoneyType(caseKey);
        }

    }
}
