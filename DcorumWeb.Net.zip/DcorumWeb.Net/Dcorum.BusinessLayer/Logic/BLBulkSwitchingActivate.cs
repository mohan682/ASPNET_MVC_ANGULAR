﻿using System;
using System.Collections.Generic;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Entities.BulkSwitching;
using DCorum.BusinessFoundation;
using Dcorum.BusinessLayer.Logic.Helping;

namespace Dcorum.BusinessLayer.Logic
{
	public class BLBulkSwitchingActivate : SimpleSavePersistor<BulkSwitchActivate,int>, IPersistor<BulkSwitchActivate>
	{
		/// <summary>
		/// CHANGE THIS!!!!
		/// </summary>
        private const string SqlTemplate = @" BEGIN
                                                   Insert into SERVICE_TASK_QUEUE
                                                   (SERVICE_TASK_QUEUE_ID, SERVICE_TASK_ID, SCHEDULE_DATE, PROCESS_DATE, LOCKED, 
                                                    THREAD_NO, ACTIVE, STATUS_CD)
                                                Values
                                                   (SERVICE_TASK_QUEUE_ID_SEQ.nextval, 153, sysdate, NULL, '0', NULL, '1', 'PE');

                                                Insert into SERVICE_TASK_QUEUE_PARAM
                                                   (SERVICE_TASK_QUEUE_ID, PARAM_NAME, PARAM_VALUE, PARAM_ORDER, PARAM_TYPE)
                                                Values
                                                   (SERVICE_TASK_QUEUE_ID_SEQ.Currval, '%%_Reference', '{0}', 1, 'STRING');
                                                END;";

		private List<PDIMessage> ExecutionOutcome { get; set; }

		public BLBulkSwitchingActivate()
		{
			ExecutionOutcome = new List<PDIMessage>();
		}

		protected override string GetInsertSql(BulkSwitchActivate arguments)
		{
			return String.Format(SqlTemplate, arguments.RefNo);
		}

		protected override void AddNoRowsAffectedError()
		{
            ExecutionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationInternalError));
		}

		protected override IEnumerable<IOutcomeItem> GetOutcomeItems()
		{
			return ExecutionOutcome;
		}
	}
}