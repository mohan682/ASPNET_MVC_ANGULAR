﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DcorumComponentSSOConfig)]
    public class BLCaseIdentity : BaseLogic
    {
        public static List<CaseIdentity> GetAllCaseIdentity()
        {
            List<CaseIdentity> schemeRoles = new List<CaseIdentity>();

            foreach (CaseIdentity rec in DLCaseIdentity.GetAllCaseIdentity())
            {
                PopulateDerivedFields(rec);
                schemeRoles.Add(rec);
            }

            return schemeRoles;
        }

        public static CaseIdentity GetCaseIdentityById(int caseIdentityId)
        {
            CaseIdentity caseIdentity = DLCaseIdentity.GetCaseIdentityById(caseIdentityId);
            PopulateDerivedFields(caseIdentity);

            return caseIdentity;
        }

        public static List<CaseIdentity> GetCaseIdentityByScheme(CaseIdentity caseIdentity)
        {
            List<CaseIdentity> caseIdentityRecs = new List<CaseIdentity>();

            foreach (CaseIdentity rec in DLCaseIdentity.GetCaseIdentityByScheme(caseIdentity))
            {
                PopulateDerivedFields(rec);
                caseIdentityRecs.Add(rec);
            }

            return caseIdentityRecs;
        }

        public static List<CaseIdentity> GetCaseIdentityByIDPAlias(CaseIdentity caseIdentity)
        {
            List<CaseIdentity> caseIdentityRecs = new List<CaseIdentity>();

            foreach (CaseIdentity rec in DLCaseIdentity.GetCaseIdentityByIDPAlias(caseIdentity))
            {
                PopulateDerivedFields(rec);
                caseIdentityRecs.Add(rec);
            }

            return caseIdentityRecs;
        }

        public static List<PDIMessage> SaveCaseIdentity(CaseIdentity caseIdentity)
        {
            List<PDIMessage> executionOutcome = new List<PDIMessage>();
            CaseIdentity existinSchemeRole = caseIdentity.CaseIdentityId == null ? null : DLCaseIdentity.GetCaseIdentityById(caseIdentity.CaseIdentityId.Value);

            if (Validate(caseIdentity, true))
            {
                bool ddlOutcome = false;
                caseIdentity.IdentityProvider = caseIdentity.IdentityProvider.Replace("'", "''").Trim();

                if (CaseIdentitySQL.Jira6845ModeOn)
                {
                    caseIdentity.IDPShortName = caseIdentity.IDPShortName.Replace("'", "''").Trim();
                    caseIdentity.IDPURL = caseIdentity.IDPURL.Replace("'", "''").Trim();
                    caseIdentity.IdentityChecksum = caseIdentity.IdentityChecksum.Replace("'", "''").Trim();
                }

                if (caseIdentity.CaseIdentityId == null)
                {
                    ddlOutcome = DLCaseIdentity.InsertCaseIdentity(caseIdentity);
                }
                else
                    ddlOutcome = DLCaseIdentity.UpdateCaseIdentity(caseIdentity);

                if (!ddlOutcome) executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationInternalError));
                else if (!CreateAuditRecord(caseIdentity.UserId, Constants.DomainCodes.DcorumComponentSSOConfig, caseIdentity, existinSchemeRole))
                    executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationAuditFailure));
            }
            else
                executionOutcome.AddRange(caseIdentity.errorList);

            return executionOutcome;
        }

        public static List<PDIMessage> DeleteCaseIdentity(CaseIdentity modelStub)
        {
            if (modelStub.CaseIdentityId.HasValue == false) return null ;

            var existing1 = GetCaseIdentityById(modelStub.CaseIdentityId.Value);

            if (existing1 == null) return null;

            List<PDIMessage> executionOutcome = new List<PDIMessage>();

            if (DLCaseIdentity.DeleteCaseIdentity(existing1))
            {
                if (!CreateAuditRecord(modelStub.UserId, DomainCodes.DcorumComponentSSOConfig, null, existing1))
                    executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationAuditFailure));
            }
            else
                executionOutcome.Add(BLPDIMessage.GetPDIMessageById(Constants.ValidationErrorCodes.DBOperationInternalError));

            return executionOutcome;
        }

        private static void PopulateDerivedFields(CaseIdentity caseIdentity)
        {
        }

        //JIRI 8066: (DD Apr15) Multiple entries per scheme is valid so ignore this validation!
        private static bool Validate(CaseIdentity rec, bool addErrorMessage)
        {
            rec.errorList = new List<PDIMessage>();

            CaseIdentity[] caseIdentity = DLCaseIdentity.GetCaseIdentityByScheme(rec).ToArray();

            if (rec.CaseIdentityId == null)
            {
                if (caseIdentity.Any( _ => _.IDPShortName == rec.IDPShortName))
                {
                    rec.errorList.Add(
                        BLPDIMessage.GetPDIMessageById(ValidationErrorCodes.DBOperationRecordAlreadyExists));
                }
            }
            else
            {
                if (caseIdentity.Any(x => x.CaseIdentityId != rec.CaseIdentityId && x.IDPShortName == rec.IDPShortName))
                {
                    rec.errorList.Add(
                        BLPDIMessage.GetPDIMessageById(ValidationErrorCodes.DBOperationRecordAlreadyExists));
                }
            }

            return rec.errorList.Count == 0;
        }

        public static bool Jira6845ModeOn
        {
            get
            {
                return CaseIdentitySQL.Jira6845ModeOn;
    }
        }
    }
}
