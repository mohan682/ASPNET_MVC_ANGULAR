﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using DCorum.BusinessFoundation.Auditing;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic.Helping;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling;
using DCorum.ViewModelling.Creational;
using DcorumWeb.Utilities;
using Dcorum.BusinessCore.Contractual;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.RefCoding;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DcorumComponentContent)]
    public class BLContent 
    {
        static BLContent()
        {
            AuditTypeMap.Singleton.TryAdd(typeof(Content), typeof(ContentDataModel));
        }

        protected internal BLContent(IDcorumUser user, DLContent contentDAL, IAuditor auditService)
        {
            DLContent = contentDAL;
            _user = user;

            AuditService1 = auditService;
            if (AuditService1 == null) throw new ArgumentNullException(nameof(auditService)) ; 

            if (DLContent == null) throw new ArgumentNullException(nameof(contentDAL));
        }

        //[Injected, Config]
        public static string ContentPrefixUrl { get; set; } //for displaying published images.

        private const string Category = DomainCodes.DcorumComponentContent;
        private DLContent DLContent { get; }

        private IAuditor AuditService1 { get; }

        protected IDcorumUser _user { get; } 


        public Content[] GetContents(string sqlSubClause, Func<Content,bool> postQueryPredicate )
        {
            postQueryPredicate = postQueryPredicate ?? (_ => true);

            var results = DLContent.GetContent(sqlSubClause).Where(_ => postQueryPredicate(_)).ToArray();

            return results;
        }

   
        public Content GetContentById(int id)
        {
            var result = DLContent.GetContentById(id);
            RefCodeHelp.DoBuildRefCodes(result, true);
            return result;
        }



        public bool Save(Content content)
        {
            bool isUpdate = content.Id > 0;

            Content contentBeforeUpdate = (isUpdate) ? GetContentById(content.Id) : null ;

            bool success = DLContent.SaveContent(content);

            AuditService1.AuditChanges(success, content, contentBeforeUpdate);

            return success;
        }     


        public bool DeletePendingContent(int id)
        {
            if (id <= 0) return false;

            var existing1 = DLContent.GetContentById(id);

            bool success = DLContent.DeletePendingContent(id);

            AuditService1.AuditChanges(success, null, existing1);
           
            return success;
        }


        public bool ApproveContent(int contentId)
        {
            if (contentId <= 0) return false;

            var existing1 = DLContent.GetContentById(contentId);

            bool success = DLContent.ApproveContent(contentId, _user.UserName);

            var current1 = DLContent.GetContentById(contentId);

            AuditService1.AuditChanges( success, current1, existing1 );

            return success;
        }


        public bool PublishingAgentRequired(Content toUse)
        {
            bool result = new[] { "img", "webpart" }.Contains(toUse.TypeCode.ToLower());
            return result;
        }


        public bool CanApprove(Content content)
        {            
            if (_user.Id == 0) return false;

            bool result = (content.Approved == false && content.CreatedUser != _user.UserName);     
            
            result &= !content.IsExpired && content.Id > 0;
            return result;
        }


        public bool HavePermissionToAuthorise(string userName)
        {
            if (!string.IsNullOrEmpty(userName) && userName.Equals(_user.UserName))
                return false;

            return true;
        }

        public bool CanCreate()
        {
            return _user.CanCreateContent;
        }


        public int? ParseMemberGroupId(string source)
        {
            if (String.IsNullOrWhiteSpace(source)) return null;

            int? result = StringParser.ParseIntInsideBrackets(source,-1);

            if (result == -1) result = source.IntoIntN();

            if (result <= 0) return null; //invalid

            return result; 
        }


        public int? ParseSchemeId(string source)
        {
            if (String.IsNullOrWhiteSpace(source)) return null;

            int? result = BLHelper.ParseKeyForScheme(source);

            if (result == -1) result = source.IntoIntN(); //plan B

            if (result <= 0) return null; //invalid

            return result;
        }

        public int? ParseIOClientId(string source)
        {
            if (String.IsNullOrWhiteSpace(source)) return null;

            int? result = BLHelper.ParseForIOClient(source);        

            return result;
        }


        public Content CreateBlank()
        {
            return new Content()
            {
                Approved = false,
                Published = false,
                CreatedUser = _user.UserName,
                //UserId = _user.Id,
                ComponentRefCode = new RefCode("Global"),
                TypeRefCode = new RefCode("text"),
                EffectiveDateTime = DateTime.Today,
                ExpiryDateTime = null
            };
        }


        public void Hydrate(Content model, Stream source)
        {
            //todo: assign primary key...

            model.ContentData = model.ContentData ?? new ContentData(model.Id);

            if (source == null) return;

            using (BinaryReader br = new BinaryReader(source))
            {
                model.ContentData.BinaryData = br.ReadBytes((Int32)source.Length);
            }
        }


        public IEnumerable<ContentFlags> YieldContentFlags(Content content)
        {
            if (!string.IsNullOrWhiteSpace(content.Provider))
                yield return ContentFlags.Provider;

            if (!string.IsNullOrWhiteSpace(content.Product))
                yield return ContentFlags.Product;

            if (!string.IsNullOrWhiteSpace(content.Plan))
                yield return ContentFlags.Plan;

            if (content.SchemeId.HasValue)
                yield return ContentFlags.Scheme;

            if (content.MemberGroupId.HasValue)
                yield return ContentFlags.MemberGroup;

            if (content.IOClientId.HasValue)
                yield return ContentFlags.IOClient;
        }


        public string GetSchemeDisplayText(int? caseKey)
        {
            if (caseKey == null) return default(string);

            var subModel1 = BLScheme.GetScheme(caseKey.Value);
            return subModel1.SafeFunc( _ => _.DisplayText);
        }


        public string GetMemberGroupDisplayText(int? mbrGrpKey)
        {
            if (mbrGrpKey == null) return default(string);

            var subModel1 = BLMemberGroup.GetMemeGroup(mbrGrpKey.Value);
            return subModel1.SafeFunc(_ => _.DisplayText);
        }

        public string GetIOClientDisplayText(int? ioContentId)
        {
            if (!ioContentId.HasValue) return default(string);

            var subModel1 = BLHelper.ParseForIOClient(Math.Abs(ioContentId.Value));

            return subModel1;
        }


        public IDictionary<string,string> DisplayableValidations()
        {
            var validations = BLValidation.GetAllValidationNames().OrderBy(x => x.ValidationName);
            var result = validations.ToDictionary(_ => _.ValidationID.ToString(), _ => _.ValidationName);
            return result;
        }


        public string GetEncodedImage(Content source, bool assumeRecognizedExtension = false)
        {
            if (source == null) return null;
            if (source.TypeRefCode.RefCd.EqualsOIC("img") == false) return null;
            if (String.IsNullOrWhiteSpace(source.Value)) return null;

            string result;   
 
            bool hasBinaryData =  (source.SafeFunc(_ => _.ContentData).SafeFunc(_ => _.BinaryData) != null) ;

            string fileExt1 = Path.GetExtension(source.Value).Replace(".", String.Empty).ToLower();

            if (hasBinaryData)
            {
                if ("jpg".EqualsOIC(fileExt1)) fileExt1 = "jpeg";

                string imageUrlPrefix = String.Format("data:image/{0};base64,", fileExt1);

                string base64 = Convert.ToBase64String(source.ContentData.BinaryData);

                result = imageUrlPrefix + base64;
            }
            else
            {
                result = GetPublishedUrl(source);
            }

            string[] recognizedImageExtensions = { "jpg", "jpeg", "png", "tif", "gif", "bmp", "ico" };         
            bool isKnownImageExtension = recognizedImageExtensions.Contains(fileExt1);
            return (isKnownImageExtension && !assumeRecognizedExtension) ? result : null;
        }


        public string GetRecognizedLinkableUrl(Content source, bool assumeRecognizedExtension = false)
        {
            if (source == null) return null;
            if (source.TypeRefCode.RefCd.EqualsOIC("img") == false) return null;
            if (String.IsNullOrWhiteSpace(source.Value)) return null;

            string fileExt1 = Path.GetExtension(source.Value).Replace(".", String.Empty).ToLower();
            string[] recognizedImageExtensions = { "pdf", "xls", "doc", "xlsx", "docx" };
            bool isKnownImageExtension = recognizedImageExtensions.Contains(fileExt1);

            string result = (isKnownImageExtension && !assumeRecognizedExtension) ? GetPublishedUrl(source) : null;
            return result;
        }


        private string GetPublishedUrl(Content source)
        {
            string result = (source.Published)
                ? source.Value.CombinePathSafely(ContentPrefixUrl, Path.AltDirectorySeparatorChar)
                : null
                ;
            return result;
        }

        public string GetUserName()
        {
            string result = _user.SafeFunc(_ => _.UserName);
            return result;
        }
    }

    [Category(DomainCodes.DcorumComponentContent)]
    public class BLContentWithCloning : BLContent
    {
        internal BLContentWithCloning(IDcorumUser user, DLContent contentDAL, IAuditor auditService)
            :base(user, contentDAL, auditService)
        {
        }

        public bool IsCloneAllowed(IEnumerable<IContentCloningArguments> listToCheck)
        {
            if (listToCheck == null) return false;
            var firstBad1 = listToCheck.FirstOrDefault(y => !y.Approved);
            var firstBad2 = listToCheck.FirstOrDefault(x => !CanClone(x));

            bool success = (firstBad1 ?? firstBad2) == null;
            return success;

            //return !(!listToCheck.Any(x => CanClone(x)) || listToCheck.Any(y => !y.Approved));
        }


        public bool CanClone(IContentCloningArguments toUse)
        {
            //bugfix 6586 DD 7AUG2014
            return (toUse.BaseId == 0 && toUse.Approved && !toUse.HasShadowCopy);
        }


        public bool CloneExistingContents(int[] existingContentIds, int? scheme, int? mbrGrp, out long clonedTotal)
        {
            int noOfRecordsCloned = 0;
            var loopResult = Parallel.ForEach(existingContentIds, r => CloneExistingContent(r, scheme, mbrGrp, ref noOfRecordsCloned));

            clonedTotal = loopResult.LowestBreakIteration ?? noOfRecordsCloned;

            return loopResult.IsCompleted;
        }


        private void CloneExistingContent(int existingContentId, int? scheme, int? mbrGrp, ref int noOfRecordsCloned)
        {
            Content existingContentRecord = GetContentById(existingContentId);

            //bugfix 6586 DD 7AUG2014
            if (!CanClone(existingContentRecord)) return;

            var clonedRecord = new Content
            {
                ComponentRefCode = existingContentRecord.ComponentRefCode,
                CreatedUser = _user.UserName,
                EffectiveDateTime = DateTime.Now,
                Target = existingContentRecord.Target,
                TypeRefCode = existingContentRecord.TypeRefCode,
                Value = existingContentRecord.Value,
                BaseId = existingContentRecord.BaseId,
                //bugfix 6586 DD 7AUG2014
                Published = !PublishingAgentRequired(existingContentRecord), //could be false for images that haven't been picked up by the publishing service.
                MemberGroupId = mbrGrp,
                SchemeId = scheme               
            };

            //for images and webparts when cloning we lose content_data so it is unpublished and has no known associated file.
            if (!clonedRecord.Published)
                clonedRecord.Value = null;

            Save(clonedRecord);
            System.Threading.Interlocked.Increment(ref noOfRecordsCloned);
        }

        /// <summary>
        /// not yet used!
        /// </summary>
        public bool CanOverride(Content model)
        {
            bool result = model.Approved && model.IsCurrent;
            return result;
        }


        public ModelQueryBuilder CreateContentQueryAssistant(string activeCriteriaControlPrefix)
        {
            var logicGroupSpecs = new Dictionary<int, SqlClauseSectionDefinition>
                {   {-1, SqlClauseSectionDefinition.Create("and", int.MinValue)}
                ,   {0, SqlClauseSectionDefinition.Create( "and", -1)}
                ,   {1, SqlClauseSectionDefinition.Create("or", 0)}
                };

            var customConversionTechniques = new Dictionary<string, Func<object, object>>()
                {   {"txtSchemeId"          , _ => ParseSchemeId(_.ToString())          }
                ,   {"txtMemberGroupId"     , _ => ParseMemberGroupId(_.ToString())     }
                ,   {"chkIsDefault"         , _ => ((bool)_) ? 1 : (int?)null           }
                ,   {"ddlApproved"          , _ => (int)(ContentSearchActionStatus)_    }
                ,   {"chkUnpublished"       , _ => ((bool)_) ? 1 : 0                    }
                ,   {"txtIOClientId"          , _ => ParseIOClientId(_.ToString()).SafeFuncN( num => -Math.Abs(num)) }
                };

            var creation1 = ViewModellingFactoryMethods.Singleton.CreateModelQueryBuilder(typeof(Content), activeCriteriaControlPrefix, logicGroupSpecs, customConversionTechniques);

            return creation1;
        }




        public Func<Content, bool> GetPostQueryPredicate(ContentSearchTimeStatus? source)
        {
            var timeStatusTechniques = new Dictionary<ContentSearchTimeStatus, Func<Content, bool>>()
                {   { ContentSearchTimeStatus.Expired, @model => @model.IsExpired }
                ,   { ContentSearchTimeStatus.Current, @model => @model.IsCurrent }
                ,   { ContentSearchTimeStatus.Scheduled, @model => !@model.IsExpired && !@model.IsCurrent }
                };

            if (source == null) return null;

            var result = timeStatusTechniques[source.Value];
            return result;
        }


        [Serializable] //for losforatter
        public struct ContentCloningArguments :IContentCloningArguments
        {
            public ContentCloningArguments(ContentBizModel source)
            {
                _id = source.Id;
                _baseId = source.BaseId;
                _approved = source.Approved;
                _hasShadowCopy = source.HasShadowCopy;
            }

            private int _id;
            private int _baseId;
            private bool _approved;
            private bool _hasShadowCopy;


            public int Id
            {
                get { return _id; }
            }

            public int BaseId
            {
                get { return _baseId; }
            }

            public bool Approved
            {
                get { return _approved; }
            }

            public bool HasShadowCopy
            {
                get { return _hasShadowCopy; }
            }
        }
    }
}
