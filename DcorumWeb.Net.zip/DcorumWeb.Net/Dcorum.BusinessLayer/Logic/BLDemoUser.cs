﻿using System;
using System.ComponentModel;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.Practices;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DcorumComponentDemoParam)]
    public class BLDemoUser : BLCommonUser<DemoUser>
    {
        public BLDemoUser(IAuditingArgumentsReadOnly caller, DLDemoUser dataAccess, BLDemoUserResponseGroup subController1)
            : base(caller, dataAccess)
        {
            MaxExpectedAffectedRows = Int32.MaxValue;
            _responseGroupController1 = subController1;
        }

        private BLDemoUserResponseGroup _responseGroupController1;

        public IUntypedPersistor ResponseGroupController
        {
            get { return _responseGroupController1; }
        }

        public override int GetPrimaryId(DemoUser model)
        {
            return model.SafeFuncN(_ => _.AccountId) ?? 0;
        }

        protected override object AnonymousTableRowFacade(DemoUser model)
        {
            var result = new
            {
                _UserAccId = model.AccountId,
                _PrimaryKey = model.UserAccDemoId,
                First_Name_____________ = model.FirstName,
                Middle_Name______________ = model.MidName,
                Last_Name_______________ = model.LastName,
                Description____________________ = model.LongDescription,
                Locked_ = model.IsLocked,
                Valid_ = (model.ResponseGroupsTotal > 0) && model.UserAccDemoId > 0
            };

            return result;
        }


        public object[] GetDemoUserResponseGroups(DemoUser model)
        {
            var results = ((IUntypedRetriever)_responseGroupController1).GetUntypedMany(model.UserAccDemoId, null, null, true);
            return results;
        }
    }
}
