﻿using System.Collections.Generic;
using System.ComponentModel;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess.QServices;
using Dcorum.BusinessLayer.Entities.QServices;

namespace Dcorum.BusinessLayer.Logic
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    [Category(null)]
    public class BLServiceTaskQueue : BLPersistorTemplate<VmServiceTaskQueue>
    {
        private static readonly DLServiceTaskQueue _dataAccess = new DLServiceTaskQueue();

        public BLServiceTaskQueue()
            : base(_dataAccess)
        {
        }


        public override TOutcome Save(VmServiceTaskQueue toSave)
        {
            return base.Save(toSave);
        }
    }
}