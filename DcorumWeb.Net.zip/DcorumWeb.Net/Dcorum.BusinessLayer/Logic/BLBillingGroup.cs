﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Creational;
using Dcorum.BusinessLayer.BusinesObjects;
using DcorumWeb.Utilities;
using System.Linq;
using Dcorum.RefCoding.Contractual;

namespace Dcorum.BusinessLayer.Logic
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    [Category(DomainCodes.DcorumComponentBillingGroup)]    
    public class BLBillingGroup : BLPersistorTemplate<BillingGroup, int, int>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected BLBillingGroup(IAuditingArgumentsReadOnly caller, DLBillingGroup dataAccess )
            : base(caller, dataAccess)
        {
            DataAccess1 = dataAccess;
            if (DataAccess1 == null) throw new ArgumentNullException(nameof(dataAccess)) ;

            OcpValidationMethodCodes = RefCodeCache.RetrieveByDomainName("OCP VALIDATION METHOD", true) ;
            FrequencyCodes = RefCodeCache.RetrieveByDomainName("UEXT ILLUST FREQ CD", true);
        }

        private DLBillingGroup DataAccess1 { get; }

        private IReadOnlyCollection<IHaveAKeyAndName> OcpValidationMethodCodes { get; }
        private IReadOnlyCollection<IHaveAKeyAndName> FrequencyCodes { get; }

        public override TOutcome Save(BillingGroup model)
        {                       
            BillingGroup toBeSavedModel = model;

            BillingGroup originalModel = DataAccess1.SelectViaPrimaryKey(model.BillingGroupId);

            if    (toBeSavedModel.BillDueDay == originalModel.BillDueDay 
                && toBeSavedModel.ApplyOPRAChecks == originalModel.ApplyOPRAChecks
                && toBeSavedModel.Frequency == originalModel.Frequency
                && toBeSavedModel.ActiveLeaverBillingGroup == originalModel.ActiveLeaverBillingGroup
                && toBeSavedModel.OCPEnabled == originalModel.OCPEnabled
                && toBeSavedModel.ContributionMethodChecking == originalModel.ContributionMethodChecking
                && toBeSavedModel.DDPaymentEnabled == originalModel.DDPaymentEnabled
                && toBeSavedModel.WorkplaceISAEnabled == originalModel.WorkplaceISAEnabled
                )
            {
                return new[] { new OutcomeItem("No changes to the billing group were detected. Save aborted!") };
            }

            return base.Save(model);
        }         
        
        protected override object AnonymousTableRowFacade(BillingGroup model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.BillingGroupId,
                Billing_Group = model.Description,
                //Contribution_Checking = model.ContributionChecking ? "Yes" : "No",
                //DD_Payment_Enabled = model.DDPaymentEnabled ? "Yes" : "No"

                OCP_Enabled = model.OCPEnabled ? "Yes" : "No",
                DD_Payment_Enabled = model.DDPaymentEnabled ? "Yes" : "No",
                Apply_OPRA_Checks = model.ApplyOPRAChecks ? "Yes" : "No",
                Contributions_Checking = OcpValidationMethodCodes?.FirstOrDefault(_ => _.KeyValue.EqualsOIC(model.ContributionMethodChecking))?.Name
                    ?? model.ContributionMethodChecking,
                Frequency = FrequencyCodes?.FirstOrDefault( _ => _.KeyValue.EqualsOIC( model.Frequency ))?.Name
                    ?? model.Frequency,
                Active_Leaver_Billing_Group = model.ActiveLeaverBillingGroup ? "Yes" : "No"

            };

            return facade1;
        }

        public static void InsertMissingUextBillGrp(int casekey)
        {
            // Works to insert any missing billing groups found in BILL_GRP table into the UEXT_BILL_GRP table
            DLBillingGroup dlbill = DcorumBusinessDalFactoryMethods.Singleton.CreateBillingGroupDal();
            dlbill.InsertNewUextBillGrpEntries(casekey);
         
        }
       
    }
}
