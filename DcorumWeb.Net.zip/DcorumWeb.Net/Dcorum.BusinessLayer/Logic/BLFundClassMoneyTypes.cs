﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.Logic
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    [Category(DomainCodes.DcorumComponentFundClass)]
    public class BLFundClassMoneyType : BLPersistorTemplate<FundClassMoneyType>
    {
        private static DLFundClassMoneyType _dataAccess = new DLFundClassMoneyType();

        public BLFundClassMoneyType()
            : base(_dataAccess)
        {
        }

        public override FundClassMoneyType GetUnique(int primaryId)
        {
            //if (primaryId == -1) 
            //    return _dataAccess.SelectDefaultMoneyType(2073, "474Y");
            
            return base.GetUnique(primaryId);
        }

        public KeyValuePair<int, string>[] SelectMoneyTypes(int caseKey)
        {
            return _dataAccess.SelectMoneyTypes(caseKey);
        }

        protected override object AnonymousTableRowFacade(FundClassMoneyType model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.FundClassMoneyTypeId.ToString(),
                Fund_Identifier=model.FundDescriptionId,
                Fund_Name______________________________________=model.FundLongName,
                _Money_Type_Number = model.MoneyTypeNumber,
                Money_Type______________________________________ = model.MoneyTypeName
            };

            return facade1;
        }
    }
}
