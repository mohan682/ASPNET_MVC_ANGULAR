﻿using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.RefCoding;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Dcorum.BusinessLayer.Logic
{
    [Category(DomainCodes.DCorumComponentScheme)]
    public class SchemeFullController
    {
        internal SchemeFullController(IAuditingArgumentsReadOnly caller, DLFullScheme dataAccess)
        {
            _dataAccess = dataAccess;
            _userId = caller.UserId;
            if (_dataAccess == null) throw new ArgumentNullException(nameof(dataAccess));
        }

        private DLFullScheme _dataAccess;
        private readonly int _userId;

        public SchemeFull GetScheme(int schemeId)
        {
            if (!(schemeId > 0)) return null;
            SchemeFull schemeRec = _dataAccess.GetScheme(schemeId);
            Hydrate(schemeRec);

            return schemeRec;
        }

        public IEnumerable<IOutcomeItem> UpdateScheme(SchemeFull scheme)
        {
            var remarks = new RemarksVessel();

            if (!(_userId > 0)) return new[] { "Invalid user id specified!" }.IntoOutcomeItems();

            if (scheme == null)
            {
                remarks.RemarkNoItemSpecified = true;
                return remarks.YieldAndPurgeAll();
            }

            if (!(scheme.CaseKey > 0))
            {
                remarks.RemarkInvalidIdentityDetected = true;
                return remarks.YieldAndPurgeAll();
            }

            Scheme existingSchemeRecord = GetScheme(scheme.CaseKey.Value);

            if (existingSchemeRecord.CaseKey != scheme.CaseKey) return new[] { "existing an current scheme case-keys do not match!" }.IntoOutcomeItems();

            if (scheme.LifePathTypeDefault == null && IsSchemeLifePath(scheme))
            {
                return new[] { "No LifePath Type Default has been specified!" }.IntoOutcomeItems();
            }

            string componentName = this.GetType().YieldAttributes<CategoryAttribute>().Single().Category;

            Hydrate(scheme);

            bool success = _dataAccess.UpdateScheme(scheme);

            if (!success)
            {
                remarks.DbOperationError = true;
            }
            else
            {
                bool success2 = BaseLogic.CreateAuditRecord(_userId, componentName, scheme, existingSchemeRecord);
                if (!success2) remarks.AuditFailure = true;
            }

            return remarks.YieldAndPurgeAll();
        }

        public bool IsSchemeLifePath(SchemeFull scheme)
        {
            var isLifePath = false;

            switch (scheme.InvestmentStructureCode)
            {
                case "4":
                case "5":
                case "6":
                case "7":
                    isLifePath = true;
                    break;
                default:
                    isLifePath = false;
                    break;
            }

            return isLifePath;
        }

        /// <summary>
        /// [CAN_RETURN_NULL] 
        /// </summary>
        internal Scheme[] GetDecumSchemes(SchemeFull accumScheme)
        {
            if (accumScheme == null) return null;

            bool drawDownEnabled = isSchemeDrawdownEnabled(accumScheme.CaseKey);

            int caseKey = accumScheme.CaseKey.GetValueOrDefault();

            bool canFetch = (caseKey > 0 && (drawDownEnabled || accumScheme.DrawdownMemberOverrideModeOn));

            var results = (canFetch) ? _dataAccess.GetDcumeSchemes(caseKey) : null;

            return results;
        }

        private bool isSchemeDrawdownEnabled(int? caseKey)
        {
            return _dataAccess.IsSchemeAllowedDrawdown(caseKey);
        }

        private void Hydrate(SchemeFull schemeRec)
        {
            schemeRec.DoBuildRefCodes();
        }
    }
}
