﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic.Helping;

namespace Dcorum.BusinessLayer.Logic
{
   [Category(DomainCodes.DcorumComponentGuestLogin)]
   public class BLGuestUser //:BaseLogic
    {
        private const string Category = Constants.DomainCodes.DcorumComponentGuestLogin;


        public static List<GuestUser> GetGuestUsers(int caseKey)
        {
            return DLGuestUser.GetGuestUsers(caseKey);
        }


        public static GuestUser GetGuestUser(int id)
        {
            return DLGuestUser.GetGuestUser(id);
        }


        public static List<PDIMessage> Save(GuestUser guestUser)
        {
            if (!(guestUser.GuestUserId > 0))
            {
                List<GuestUser> existingrecords = DLGuestUser.GetGuestUsers(guestUser.CaseKey);
                if (existingrecords.Any(r => r.GuestUserName.ToLower().Equals(guestUser.GuestUserName.ToLower())))
                {
                    return new[] {PDIMessage.CreateIncomplete("Record already exists.")}.ToList();
                }
            }

            Func<GuestUser, int> howToSave = gu =>
            {
                if (!gu.IsCustomModellerReference)
                    gu.ModellerReference = string.Format("{0}_{1}_{2}", gu.CaseKey, gu.BenefitMemberGroup.MbGpKey,
                        gu.InvestmentMemberGroup.MbGpKey);

                int result = DLGuestUser.Save(gu);

                gu.GuestUserPassword = !String.IsNullOrWhiteSpace(gu.GuestUserPassword)
                    ? "New password is stored for this user"
                    : "";

                return result;
            };

            return BLHelper.PersistChanges(guestUser, howToSave, DLGuestUser.GetGuestUser, _ => _.GuestUserId, Category);
        }


        public static List<PDIMessage> Delete(GuestUser guestUser)
        {
            return BLHelper.PersistChanges(guestUser, DLGuestUser.Delete, DLGuestUser.GetGuestUser, _ => _.GuestUserId, Category, true );
        }
    }
}
