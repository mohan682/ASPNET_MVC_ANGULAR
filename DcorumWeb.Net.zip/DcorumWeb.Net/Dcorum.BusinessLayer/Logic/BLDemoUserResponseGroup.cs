﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using DCorum.BusinessFoundation.Bases;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Contractual;

namespace Dcorum.BusinessLayer.Logic
{
    using ModelAlias = Entities.DemoUserResponseGroup;

    [Category(DomainCodes.DcorumComponentDemoParam)]
    public class  BLDemoUserResponseGroup : CopyOfControllerBase<ModelAlias, int, int, int, int>
    {
        internal BLDemoUserResponseGroup(IAuditingArgumentsReadOnly caller, DLDemoUserResponseGroup persistenceActor, DLStaticResponseGroup subDataAccess1)
            : base(caller, persistenceActor)
        {
            Invariants = new Dictionary<string, Predicate<ModelAlias>>()
            {   {"Model must exist", @model => @model != null }
            //,   {"Tax year must have an end date", @model => @model.ExpiryDate.HasValue}
            //,   {"End date must be greater than start date", @model => (@model.StartDate < @model.ExpiryDate) }
            //,   {"The minimum age must be less than the maximum age", @model => (model.MinimumAge <= model.MaximumAge) }
            //,   {"Id must be greater than zero", @model => @model.Id >= AmbientValue }
            };

            _dataAccess1 = persistenceActor ;
            _subDataAccess1 = subDataAccess1 ;
        }

        private DLStaticResponseGroup _subDataAccess1;
        private DLDemoUserResponseGroup _dataAccess1;

        #region for list controls
        private bool _fetched = false;
        private IKeyValuePair[] _staticResponses;
        #endregion


        public bool CanDelete(ModelAlias model)
        {
            return (!ReadOnlyModeOn);
        }


        public ModelAlias GetBlank(int demoUserId)
        {
            var result = _dataAccess1.SelectNewViaParentKey(demoUserId) ?? Create();
            Hydrate(result);
            return result;
        }


        public override void Hydrate(ModelAlias toHydrate)
        {
            base.Hydrate(toHydrate);

            if (_fetched == false)
            {
                _staticResponses = _subDataAccess1.SelectManyViaParentKey().SafeLinq().Where(_ => _.StaticResponseGroupId.HasValue).OrderBy( _ => _.StaticResponseGroupId).ToDictionary(_ => _.StaticResponseGroupId.Value, _ => _.Code + _.ShortDescription).IntoKeyedDisplayables();
                _fetched = true;
            }

            toHydrate.DeclareBusinessConstraint(1, typeof(StaticResponseGroup), () => _staticResponses, @choice => toHydrate.StaticResponseGroupId = @choice.IntoValue<int>(), true);
        }


        public override ModelAlias[] GetMany(int parentId = 0, string augmentQueryWith = null)
        {
            return base.GetMany(parentId, augmentQueryWith).OrderBy( _ => _.StaticResponseGroupId).ToArray() ;
        }

        protected override object AnonymousTableRowFacade(ModelAlias model)
        {
            object result = new
            {
                _id = model.MyId,
                _parentId = model.UserAccDemoId,
                Static_Response________________ = _staticResponses.FirstOrDefault(_ => _.KeyItem == model.StaticResponseGroupId).SafeFunc(_ => _.DisplayItem) ?? "undefined" + model.StaticResponseGroupId,
                Is_Primary = model.IsPrimary,
                Is_Decum = model.IsDecum,
                Member_Account_Status____________ = model.AccStatus.SafeFunc( _ => _.Descript),
                Valid = ((model.PrimaryTotal > 1) || (model.DecumTotal > 1)) == false,
                __canDelete = CanDelete(model).ToString()
            };
            return result;
        }


        protected override int ConvertToDataKey(int key)
        {
            return key;
        }

        protected override int ConvertToParentDataKey(int key)
        {
            return key;
        }
    }



    /// <summary>
    /// Copied from AE Project. Remove somehow in the future.
    /// </summary>
    public abstract class CopyOfControllerBase<TModel, TKey, TParentKey, TDataKey, TParentDataKey> : BLPersistorTemplate<TModel, TKey, TParentKey, TDataKey, TParentDataKey>
        where TModel : class, new()
    {
        protected CopyOfControllerBase(IAuditingArgumentsReadOnly caller, IOpenCrudFull<TModel, TDataKey,TParentDataKey> injectedCrud)
            : base(caller, new RemarksVessel(), injectedCrud)
        {
        }

        protected override void Validate(TModel model)
        {
            base.Validate(model);

            var failures = Invariants.SafeLinq().Where(_ => _.Value(model) == false).ToArray();

            if (failures.Any())
            {
                RemarksVessel.IncludeCustomRemarks(failures.Select(_ => _.Key).ToArray());
            }

            var cast1 = model as ModelWithBusinessContraints;

            if (cast1 != null && cast1.TryValidate() == false)
            {
                //needs to check business constraints in finer detail!
                RemarksVessel.IncludeCustomRemarks(new string[] { "Item is not in a valid state!" });
            }     
        }


        protected bool TryValidate(TModel model)
        {
            var failures = Invariants.SafeLinq().Where(_ => _.Value(model) == false).ToArray();
            if (failures.Any()) return false ;

            var cast1 = model as ModelWithBusinessContraints;

            if (cast1 != null)
            {
                bool result = cast1.TryValidate();
                return result;
            }

            return true;
        }


        protected Dictionary<string, Predicate<TModel>> Invariants { get; set; }
    }
}
