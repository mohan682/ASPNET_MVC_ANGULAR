﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.Logic
{
    //public static class BLPDIMessageHelp
    //{
    //    public static int DoValidate<T>(this T objectToValidate, IEnumerable<string> validationCodes, bool addErrorMessage = true)
    //        where T :BaseEntity 
    //    {
    //        int validationTally = 0;
    //        objectToValidate.errorList = new List<PDIMessage>();

    //        Action<string> howToAdd = (addErrorMessage)
    //            ? _ => objectToValidate.errorList.Add(BLPDIMessage.GetPDIMessageById(_))
    //            : (Action<string>)(_ => validationTally++);

    //        foreach (var current1 in validationCodes.ToArray()) howToAdd(current1);
            
    //        return (addErrorMessage) ? objectToValidate.errorList.Count : validationTally ;
    //    }
    //}


    [Category(DomainCodes.DCorumComponentPDIMessage)]
    public class BLPDIMessage : BaseLogic
    {
        private static readonly IList<RefCode> PdiMessageType = RefCodeCache.RetrieveByDomainName(DomainNames.PDIUserMessageLevels);


        public static PDIMessage[] GetAllPDIMessages()
        {
            PDIMessage[] recordsToReturn = DLPDIMessage.GetAllPDIMessages();

            foreach (PDIMessage rec in recordsToReturn)
            {
                if (rec == null) continue;
                rec.MessageType = rec.MessageType.IntoHydratedRefCodeVia(PdiMessageType);
            }

            return recordsToReturn;
        }

        /// <summary>
        /// [OVERLOAD]
        /// </summary>
        public static PDIMessage GetPDIMessageById(string messageId)
        {
            return GetSingle(messageId.IntoIntN());
        }


        public static PDIMessage GetSingle(int? messageId)
        {
            if (messageId.HasValue == false) return null;

            PDIMessage pdiMessage = DLPDIMessage.GetPDIMessagesById(messageId.Value) ;

            if (pdiMessage == null) return PDIMessage.CreateIncomplete(String.Format("Message [{0}] should be displayed here but is not defined!", messageId));

            pdiMessage.MessageType = pdiMessage.MessageType.IntoHydratedRefCodeVia(PdiMessageType);

            return pdiMessage;
        }


        public static List<PDIMessage> Save(PDIMessage messageToSave, bool isPreInsertCheckRequired)
        {
            List<PDIMessage> executionOutcome = new List<PDIMessage>();

            messageToSave.MessageText = messageToSave.MessageText.Trim().Replace("'", "''");
            messageToSave.MessageCode = messageToSave.MessageCode.Trim().Replace("'", "''");
            messageToSave.MessageType = messageToSave.MessageType.IntoHydratedRefCodeVia(PdiMessageType);

            if (Validate(messageToSave, true))
            {
                PDIMessage existingMessage = GetSingle(messageToSave.MessageId);
                if (isPreInsertCheckRequired && existingMessage != null)
                    executionOutcome.Add(GetPDIMessageById(ValidationErrorCodes.DBOperationRecordAlreadyExists));
                else
                {
                    bool ddlOutcome = ((!isPreInsertCheckRequired) ? DLPDIMessage.UpdatePDIMessage(messageToSave) : DLPDIMessage.InsertPDIMessage(messageToSave)) > 0;

                    if (!ddlOutcome) executionOutcome.Add(GetPDIMessageById(ValidationErrorCodes.DBOperationInternalError));

                    if (ddlOutcome && !CreateAuditRecord(messageToSave.UserId, DomainCodes.DCorumComponentPDIMessage, messageToSave, existingMessage))
                        executionOutcome.Add(GetPDIMessageById(ValidationErrorCodes.DBOperationAuditFailure));
                }
            }
            else
                executionOutcome.AddRange(messageToSave.errorList);

            return executionOutcome;
        }

        private static bool Validate(PDIMessage baseEntity, bool addErrorMessage)
        {
            return true;
        }
    }
}
