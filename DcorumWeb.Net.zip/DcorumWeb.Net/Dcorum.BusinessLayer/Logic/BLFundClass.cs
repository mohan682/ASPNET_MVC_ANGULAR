﻿using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.BusinessLayer.Entities;
using DCorum.BusinessFoundation.Contractual;
using DCorum.ViewModelling;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Practices;
using System.Diagnostics;

namespace Dcorum.BusinessLayer.Logic
{
    using BusinesObjects;
    using Utilities.Extensions;
    using TOutcome = IEnumerable<IOutcomeItem>;

    [Category(DomainCodes.DcorumComponentFundClass)]
    public class BLFundClass : BLPersistorTemplate<FundClass, int, int>, ICanBeHydrated<FundClass>
    {
        public BLFundClass(IAuditingArgumentsReadOnly caller, DLFundClass dataAccess)
            : base(caller, dataAccess)
        {
            _dataAccess = dataAccess;
            Debug.Assert(_dataAccess != null);
            Debug.Assert(CrudOut != null);
        }

        private readonly DLFundClass _dataAccess;

        private Dictionary<string, bool> _lifepathTypeWithDatedFlagPairs;
            
        public override TOutcome Save(FundClass model)
        {
            if (!model.IsLifepathFund)
            {
                model.LifepathTargetEndYear = null;
                model.LifepathTargetStartYear = null;
                model.LifePathType = null;
                model.LifePathPhase = null;
                model.GlidepathEndDate = null;
                //model.LifepathTargetYear = 0;
            }

            var validationComments = FundClassHelper.Validate(model).ToArray();

            if (validationComments.Any())
            {
                var result = validationComments.Select(_ => new OutcomeItem(_.Item2));
                return result;
            }

            return base.Save(model);
        }


        public override void Hydrate(FundClass toHydrate)
        {
            base.Hydrate(toHydrate);

            if (!toHydrate.IsLifepathFund)
            {
                toHydrate.LifePathType = null;
                toHydrate.LifePathPhase = null;
            }
            else if (toHydrate.FundType == "2")
                toHydrate.LifePathPhase = RefCodeCache.RetrieveByRefCodeValue(DomainNames.LifepathPhase, "GLIDE");

            if (toHydrate.LifePathPhase?.RefCd != "GLIDE")
            {
                toHydrate.LifepathTargetStartYear = null;
                toHydrate.LifepathTargetEndYear = null;
                toHydrate.GlidepathEndDate = null;
            }

            // if (toHydrate.IsLifepathFund && toHydrate.IsDatedLifepathFund == null) throw new InvalidOperationException("Unable to determine dated/undated value based on the model's lifepathType!");
        }


        public void PickUpNewFunds()
        {
            _dataAccess.PickUpNewFunds();
        }

        public FundClass[] SelectMany(string fundDescriptionId,string fundName)
        {
            return _dataAccess.SelectMany(fundDescriptionId, fundName);
        }

        protected override object AnonymousTableRowFacade(FundClass model)
        {
            return FundClass.TableRowView(model);
        }
    }


    internal static class FundClassHelper
    {
        public static IEnumerable<Tuple<PropertyInfo, string>> Validate(this FundClass model)
        {
            if (model == null) yield break;

            if (model.LifepathTargetStartYear > model.LifepathTargetEndYear)
            {           
                var subjectPair = AnnotationHelp.GetDisplayNamePair(model, _ => _.LifepathTargetStartYear);

                var objectPair = AnnotationHelp.GetDisplayNamePair(model, _ => _.LifepathTargetEndYear);

                string message1 = String.Format("{0} must not be greater than {1}!", subjectPair.Item2, objectPair.Item2);
                yield return new Tuple<PropertyInfo, string>(subjectPair.Item1, message1);
            }

            int tally1 = 0;
            if (model.LifepathTargetEndYear.HasValue) tally1++;
            if (model.LifepathTargetStartYear.HasValue) tally1++;

            if (model.IsLifepathFund && tally1 == 1)
            {
                var startPair = AnnotationHelp.GetDisplayNamePair(model, _ => _.LifepathTargetStartYear);
                var endPair = AnnotationHelp.GetDisplayNamePair(model, _ => _.LifepathTargetEndYear);

                var subjectPair = (model.LifepathTargetEndYear.HasValue) ? startPair : endPair;
                var objectPair = (model.LifepathTargetEndYear.HasValue) ? endPair : startPair;

                string message2 = String.Format("{0} must also have a value when {1} has a value!", subjectPair.Item2, objectPair.Item2);
                yield return new Tuple<PropertyInfo, string>(subjectPair.Item1, message2);
            }
        }
    }
}
