﻿using System.Data;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using System;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLStaticResponseGroup :ICrudOut<StaticResponseGroup, int>
    {
        internal DLStaticResponseGroup(StaticResponseGroupSQL sqlMaker)
        {
            DbProxy = new DataAccessContext();

            StaticResponseGroupSQL = sqlMaker;
            if (StaticResponseGroupSQL == null) throw new ArgumentNullException(nameof(sqlMaker));
        }

        private readonly StaticResponseGroupSQL StaticResponseGroupSQL;
        private IDbProxy DbProxy { get; }

        public StaticResponseGroup[] SelectManyViaParentKey(int parentKey = 0, string appendWhereClauseWith = null)
        {
            return DbProxy.GetMany(StaticResponseGroupSQL.GetStaticResponseGroups(), MapToStaticResponseGrop, () => new object[] { (parentKey == default(int)) ? (int?)null : parentKey, appendWhereClauseWith });
        }

        public StaticResponseGroup SelectViaPrimaryKey(int primaryKey)
        {
            return DbProxy.GetSingle(StaticResponseGroupSQL.GetStaticResponseGroup(primaryKey), MapToStaticResponseGrop, () => new object[] { primaryKey });
        }

        private static StaticResponseGroup MapToStaticResponseGrop(IDataReader reader)
        {
            var staticResponseGroup = new StaticResponseGroup();
            MapToStaticResponseGropCore(staticResponseGroup, reader);
            return staticResponseGroup;
        }

        private static void MapToStaticResponseGropCore(StaticResponseGroup staticResponseGroup, IDataReader reader)
        {
            staticResponseGroup.StaticResponseGroupId = DBHelper.GetIDataReaderNullableInt(reader, "STATIC_RESPONSE_GROUP_ID");
            staticResponseGroup.Code = new RefCode(DBHelper.GetIDataReaderString(reader, "CODE"));
            staticResponseGroup.ShortDescription = DBHelper.GetIDataReaderString(reader, "SHORT_DESCRIPT");
            staticResponseGroup.Description = DBHelper.GetIDataReaderString(reader, "DESCRIPT");
        }
    }
}
