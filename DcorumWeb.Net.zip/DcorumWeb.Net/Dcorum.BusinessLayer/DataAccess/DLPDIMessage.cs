﻿using System.Collections.Generic;
using System.Data;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    internal class DLPDIMessage
    {
        internal static PDIMessage[] GetAllPDIMessages()
        {
            string sql1 = PDIMessageSQL.GetPDIMessagesSql();
            var results = DataAccessHelp.GetMany(sql1, Build, "UEXT");
            return results;
        }

        internal static PDIMessage GetPDIMessagesById(int messageId)
        {
            string sql1 = PDIMessageSQL.GetPDIMessagesSql(messageId);
            var result = DataAccessHelp.GetSingle(sql1, Build, "UEXT");
            return result;
        }

        internal static int InsertPDIMessage(PDIMessage pdiMessage)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(PDIMessageSQL.InsertPDIMessagesSql(pdiMessage)))
                return db.ExecuteNonQuery(cmd);
        }

        internal static int UpdatePDIMessage(PDIMessage pdiMessage)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(PDIMessageSQL.UpdatePDIMessagesSql(pdiMessage)))
                return db.ExecuteNonQuery(cmd);
        }

        private static PDIMessage Build(IDataReader reader)
        {
            PDIMessage pdiMessage = new PDIMessage();

            pdiMessage.MessageId = DBHelper.GetIDataReaderInt(reader, "PDIMessage_Id");
            pdiMessage.MessageType = new RefCode(DBHelper.GetIDataReaderInt(reader, "Type").ToString());
            pdiMessage.MessageText = DBHelper.GetIDataReaderString(reader, "Message");
            pdiMessage.MessageCode = DBHelper.GetIDataReaderString(reader, "Code");

            return pdiMessage;
        }
    }
}
