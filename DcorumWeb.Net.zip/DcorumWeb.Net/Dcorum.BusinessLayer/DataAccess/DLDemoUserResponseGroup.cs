﻿using System.Data;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using Dcorum.Utilities.DataAccess;
using System;

namespace Dcorum.BusinessLayer.DataAccess
{
    internal class DLDemoUserResponseGroup : CrudActor<DemoUserResponseGroup, int, int>,
     ICrudFull<DemoUserResponseGroup, int>
    {
        internal DLDemoUserResponseGroup(DemoUserResponseGroupSqlMaker sqlMaker)
            : base(@CreateModel, sqlMaker)
        {
            _sqlMaker = sqlMaker;
            if (_sqlMaker == null) throw new ArgumentNullException(nameof(sqlMaker));
        }

        private readonly DemoUserResponseGroupSqlMaker _sqlMaker;


        public DemoUserResponseGroup SelectNewViaParentKey(int demoUserId)
        {
            string sql1 = _sqlMaker.GetSelectNewSql(demoUserId);

            var result = DataAccessHelp.GetSingle(sql1, @CreateModel);
            return result;
        }


        private static DemoUserResponseGroup CreateModel(IDataReader reader)
        {
            return new DemoUserResponseGroup(@reader, DemoUserResponseGroupSqlMaker.ColumnNames);
        }
    }
}
