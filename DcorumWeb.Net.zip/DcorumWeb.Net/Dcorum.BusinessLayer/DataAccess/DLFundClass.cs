﻿using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.DataAccess;
using System;
using System.Data;
using System.Diagnostics;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLFundClass : CrudFullTemplate<FundClass>
    {
        internal DLFundClass(FundClassSQL fundClassSqlIn)
            : base(fundClassSqlIn)
        {
            fundClassSql = fundClassSqlIn;
            Debug.Assert(CrudFullSql != null);
        }

        private readonly FundClassSQL fundClassSql;


        public void PickUpNewFunds()
        {
            int success = DataAccessHelp.SimpleExecuteNonQuery(fundClassSql.GetSqlStringForNewFunds());
        }


        private FundClass Make(IDataReader reader)
        {
            var creation1 = new FundClass();
            Build(creation1, reader);
            return creation1;
        }


        public FundClass[] SelectMany(string fundDescriptionId, string fundName)
        {
            string sql1 = fundClassSql.SelectManySql(fundDescriptionId, fundName).IntoWellFormedSql();

            var results = DataAccessHelp.GetMany<FundClass>(sql1, @Make);

            return results;
        }


        private Tuple<string, string> MakeDatedPair(IDataReader reader)
        {
            var creation1 = Tuple.Create(reader.FetchAsString("REF_CD"), reader.FetchAsString("LONG_DESC"));        
            return creation1;
        }


        public Tuple<string,string>[] SelectLifepathRefCodesWithDatedFlag()
        {
            string sql1 = fundClassSql.GetLifepathRefcodes() ;

            var results = DataAccessHelp.GetMany<Tuple<string, string>>(sql1, @MakeDatedPair);

            return results;
        }


        protected override void Build(FundClass fundClass, IDataReader reader, bool? isCollectionModeOn = false)
        {
            fundClass.FundClassId = DBHelper.GetIDataReaderInt(reader, "UEXT_FUND_DESC_ID");
            fundClass.FundDescriptionId = DBHelper.GetIDataReaderString(reader, "FD_DESC_ID");
            fundClass.FundShortName = DBHelper.GetIDataReaderString(reader, "SHRT_FD_NM");
            fundClass.FundLongName = DBHelper.GetIDataReaderString(reader, "LONG_FD_NM");
            fundClass.FundType = DBHelper.GetIDataReaderString(reader, "FD_TYP_CD");

            fundClass.BitMapLocation = DBHelper.GetIDataReaderString(reader, "BITMAP_LOCATION");

            //fundClass.LifepathTargetYear = DBHelper.GetIDataReaderNullableInt(reader, "LIFEPATH_TARGET_YR");

            fundClass.LifepathTargetStartYear = DBHelper.GetIDataReaderNullableInt(reader, "LIFEPATH_MIN_TARGET_YR");
            fundClass.LifepathTargetEndYear = DBHelper.GetIDataReaderNullableInt(reader, "LIFEPATH_MAX_TARGET_YR");
            fundClass.LifePathType = reader.FetchTextualRefCode("LIFEPATH_TYPE");
            fundClass.LifePathPhase = reader.FetchTextualRefCode("LIFEPATH_PHASE");

            fundClass.IsLifepathFund = DBHelper.GetIDataReaderInt(reader, "LIFEPATH_FUND") == 1;
            fundClass.AnnualManagementCharge = DBHelper.GetIDataReaderDecimal(reader, "ANNUAL_MANAGEMENT_CHARGE");
            fundClass.AdditionalCharge = DBHelper.GetIDataReaderDecimal(reader, "ADDITIONAL_CHARGE");
            fundClass.GrowthRateLow = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_LOW");
            fundClass.GrowthRateMid = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_MID");
            fundClass.GrowthRateHigh = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_HIGH");
            fundClass.GrowthRateSMPI = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_SMPI");
            fundClass.GlidepathEndDate = DBHelper.GetIDataReaderNullableDateTime(reader, "GLIDEPATH_END_DATE");

           // fundClass.IsDatedLifepathFund = fundClass.IsLifepathFund && DBHelper.GetIDataReaderString(reader, "LIFEPATH_PHASE") != "POST_GLIDE";
        }
    }
}