﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;
using DCorum.BusinessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLFundClassDetail : CrudFullTemplate<FundClassDetail>
    {
        private static readonly FundClassDetailSQL fundClassDetailSql = new FundClassDetailSQL();

        protected override DCorum.BusinessFoundation.Contractual.ISqlFullCrud<FundClassDetail, int> CrudFullSql
        {
            get { return fundClassDetailSql; }
        }

        public void PickUpNewSchemesAndFundsFromCompass(int caseKey)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(GetSqlStringForNewSchemesAndFunds(caseKey)))
            {
                db.ExecuteNonQuery(cmd);
            }
        }

        public FundClassDetail[] SelectMany(int caseKey,int? mbrGroupKey)
        {
            var fundClaseDetails = new List<FundClassDetail>();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(fundClassDetailSql.SelectManySql(caseKey, mbrGroupKey)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        var fundClaseDetail = new FundClassDetail();
                        Build(fundClaseDetail, reader);
                        fundClaseDetails.Add(fundClaseDetail);
                    }
                }
            }

            return fundClaseDetails.ToArray();
        }      

        /// <summary>
        /// Tuple with IsScheme,integer,name
        /// </summary>      
        /// <returns></returns>
        public Tuple<string, string>[] GetSchemAndMemberGroups(int caseKey)
        {
            // TODO: Call a check to pick up new funds and schemes.


            var schemeAndMbrGroups = new List<Tuple<string, string>>();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(fundClassDetailSql.SelectSchemeAndMemberGroupSql(caseKey)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        schemeAndMbrGroups.Add(new Tuple<string, string>(string.Format("{0},{1}",
                            DBHelper.GetIDataReaderInt(reader, "IS_SCHEME"),
                            DBHelper.GetIDataReaderInt(reader, "KEY")),
                            DBHelper.GetIDataReaderString(reader, "NAME")
                            ));
                    }
                }
            }

            return schemeAndMbrGroups.ToArray();
        }

        protected override void Build(FundClassDetail fundClassDetail, IDataReader reader, bool? isCollectionModeOn = false)
        {
            fundClassDetail.FundClassDetailId = DBHelper.GetIDataReaderInt(reader, "UEXT_CASE_FUND_RULES_ID");
            fundClassDetail.CaseKey = DBHelper.GetIDataReaderNullableInt(reader, "CASE_KEY");
            fundClassDetail.FundDescriptionId = DBHelper.GetIDataReaderString(reader, "FD_DESC_ID");
            fundClassDetail.FundShortName = DBHelper.GetIDataReaderString(reader, "SHRT_FD_NM");
            fundClassDetail.FundLongName = DBHelper.GetIDataReaderString(reader, "LONG_FD_NM");
            fundClassDetail.IsCoreFund = DBHelper.GetIDataReaderInt(reader, "IS_CORE") == 1;
            fundClassDetail.AllowInvestmentByMoneyType = DBHelper.GetIDataReaderInt(reader, "ALLOW_INV_BY_MNY_TYP") == 1;
            fundClassDetail.EffectiveDate = DBHelper.GetIDataReaderDateTime(reader, "EFF_DT");
            fundClassDetail.ExpiryDate = DBHelper.GetIDataReaderNullableDateTime(reader, "XPIR_DT");
            fundClassDetail.AnnualManagementCharge = DBHelper.GetIDataReaderNullableDecimal(reader, "ANNUAL_MANAGEMENT_CHARGE");
            fundClassDetail.AdditionalCharge = DBHelper.GetIDataReaderDecimal(reader, "ADDITIONAL_CHARGE");
            fundClassDetail.GrowthRateLow = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_LOW");
            fundClassDetail.GrowthRateMid = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_MID");
            fundClassDetail.GrowthRateHigh = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_HIGH");
            fundClassDetail.GrowthRateSMPI = DBHelper.GetIDataReaderNullableDecimal(reader, "GROWTH_RATE_SMPI");

            fundClassDetail.ChargeMetBy = new BusinesObjects.RefCode(
                DBHelper.GetIDataReaderString(reader, "CHARGE_CODE"),
                DBHelper.GetIDataReaderString(reader, "CHARGE_CODE_DESCRIPTION")
                );

            fundClassDetail.ActiveFundClass = new BusinesObjects.RefCode(
                DBHelper.GetIDataReaderString(reader, "ACTIVE_CLASS"),
                DBHelper.GetIDataReaderString(reader, "ACTIVE_CLASS_DESCRIPTION")
                );
        }

        private string GetSqlStringForNewSchemesAndFunds(int caseKey)
        {
            const string sqlTemplate = @"DECLARE 

    v_case_key INTEGER := {0};
    v_count INTEGER := 0;

BEGIN

    -- Update UEXT Case Data
    SELECT COUNT(*) INTO v_count FROM UEXT_CASE_DATA 
    WHERE CASE_KEY = v_case_key;
    
    DBMS_OUTPUT.PUT_LINE('count: ' || v_count);
    
    IF ( v_count = 0 ) THEN
                                            
        SELECT COUNT(*) INTO v_count FROM CASE_DATA 
        WHERE CASE_KEY = v_case_key;
                                                
        IF( v_count = 1 ) THEN
    
        INSERT INTO UEXT.UEXT_CASE_DATA UCD ( UCD.CASE_KEY )
        VALUES ( v_case_key );
        
        DBMS_OUTPUT.PUT_LINE('value inserted');
                                                
        END IF;
        
    END IF;
    
    
    -- Pick up any new member groups for the scheme.
    MERGE INTO UEXT_MBR_GRP UMG
        
    USING(
            SELECT CASE_KEY, MBGP_KEY
            FROM COMPASS.MBR_GRP
            WHERE CASE_KEY = v_case_key
         ) MG
         
    ON  ( MG.CASE_KEY = UMG.CASE_KEY AND MG.MBGP_KEY = UMG.MBGP_KEY)
    
    WHEN NOT MATCHED THEN
        INSERT ( 
                    UMG.CASE_KEY,
                    UMG.MBGP_KEY   
                )
        VALUES  (
                    MG.CASE_KEY,
                    MG.MBGP_KEY   
                );
    
    -- Update UEXT Fund rules.
    MERGE INTO UEXT.UEXT_CASE_FUND_RULES UB
    
    USING(
            SELECT CASE_KEY, FD_DESC_ID 
            FROM COMPASS.CASE_FUND_RULES
            WHERE CASE_KEY = v_case_key
         ) UC
         
    ON  ( UB.CASE_KEY = UC.CASE_KEY AND UB.FD_DESC_ID = UC.FD_DESC_ID)

    WHEN NOT MATCHED THEN
        INSERT (    UB.UEXT_CASE_FUND_RULES_ID, 
                    UB.CASE_KEY, 
                    UB.FD_DESC_ID,
                    UB.ACTIVE_CLASS,
                    UB.CHARGE_CODE 
               )
        VALUES (
                    UEXT.UEXT_CASE_FUND_RULES_ID_SEQ.NEXTVAL,
                    UC.CASE_KEY,
                    UC.FD_DESC_ID,
                    '0',
                    '0'
               );
               
END;";

            return string.Format(sqlTemplate, caseKey);
        }
    }
}
