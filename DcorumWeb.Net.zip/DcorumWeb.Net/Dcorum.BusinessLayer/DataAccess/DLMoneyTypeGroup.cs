﻿using System;
using System.Collections.Generic;
using System.Data;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLMoneyTypeGroup
    {
        #region ...Case Money Type Group [DD 5SEP14 for Contribution Scale/Structures]...

        public static CaseMoneyTypeGroup[] Select(int caseId)
        {
            string sql1 = MoneyTypeGroupSQL.SelectCaseMoneyTypeGroupsByCaseSql(caseId);
            return DataAccessHelp.GetMany(sql1, MapToCaseMoneyTypeGroup, "UEXT");
        }


        private static CaseMoneyTypeGroup MapToCaseMoneyTypeGroup(IDataReader reader)
        {
            var creation1 = new CaseMoneyTypeGroup();
            Build(creation1, reader);
            return creation1;
        }


        private static void Build(CaseMoneyTypeGroup toBuild, IDataReader reader)
        {
            toBuild.CaseMoneyTypeGroupKey = DBHelper.GetIDataReaderInt(reader, "CMTGP_KEY");
            toBuild.MoneyTypeGroupKey = DBHelper.GetIDataReaderInt(reader, "MTGP_KEY");
            toBuild.CaseKey = DBHelper.GetIDataReaderNullableInt(reader, "CASE_KEY");
            toBuild.MoneyTypeGroupName = DBHelper.GetIDataReaderString(reader, "NAME");
            // toBuild.MoneyTypeGroupDescription = DBHelper.GetIDataReaderString(reader, "DESCRIPT");
        }

        #endregion

        public static Entities.MoneyTypeGroup GetMoneyTypeGroupByKey(int caseId,int moneyTypeGroupKey)
        {
            var moneyTypeGroup = new Entities.MoneyTypeGroup();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(MoneyTypeGroupSQL.GetMoneyTypeGroupByKeySql(caseId,moneyTypeGroupKey)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                      moneyTypeGroup= MapToMoneyTypeGroup(reader);
                    }
                }
            }

            return moneyTypeGroup;
        }    

        public static List<Entities.MoneyTypeGroup> GetMoneyTypeGroupByCase(int caseId)
        {
            var moneyTypeGroups = new List<Entities.MoneyTypeGroup>();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(MoneyTypeGroupSQL.GetMoneyTypeGroupByCaseSql(caseId)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        moneyTypeGroups.Add(MapToMoneyTypeGroup(reader));
                    }
                }
            }

            return moneyTypeGroups;
        }

        public static int Save(MoneyTypeGroup moneyTypeGroup)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            string sql1 = null;

            if (moneyTypeGroup.CaseMoneyTypeGroupKey > -1)
            {
                sql1 = MoneyTypeGroupSQL.UpdateMoneyTypeGroupForCaseSql(moneyTypeGroup);
            }
            else
            {
                moneyTypeGroup.CaseMoneyTypeGroupKey = SequenceGetter.GetNextVal(db, "CMTGP_SEQ");
                sql1 = MoneyTypeGroupSQL.AddMoneyTypeGroupForCaseSql(moneyTypeGroup);
            }

            using (var cmd = db.GetSqlStringCommand(sql1))
            {
                return db.ExecuteNonQuery(cmd);
            }                 
        }

        public static int Delete(MoneyTypeGroup model)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            string sql = MoneyTypeGroupSQL.DeleteMoneyTypeGroupForCaseSql(model.CaseMoneyTypeGroupKey);

            using (var cmd = db.GetSqlStringCommand(sql))
            {
                return db.ExecuteNonQuery(cmd);
            }
        }


        private static MoneyTypeGroup MapToMoneyTypeGroup(IDataReader reader)
        {
            var moneyTypeGroup = new MoneyTypeGroup();
            Build(moneyTypeGroup, reader);
            return moneyTypeGroup;
        }


        private static void Build(MoneyTypeGroup toBuild, IDataReader reader)
        {
            Build((CaseMoneyTypeGroup)toBuild,reader);
        }

        public static MoneyTypeGroup GetCaseMoneyTypeGroupByKey(int caseMoneyTypeGroupKey)
        {
            var moneyTypeGroup = new Entities.MoneyTypeGroup();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(MoneyTypeGroupSQL.GetCaseMoneyTypeGroupByKeySql(caseMoneyTypeGroupKey)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        moneyTypeGroup = MapToMoneyTypeGroup(reader);
                    }
                }
            }

            return moneyTypeGroup;
        }

        public static IEnumerable<MoneyTypeGroup> GetMoneyTypeGroupsForCaseByExcludingCurrMapps(int CaseKey)
        {
            var moneyTypeGroups = new List<Entities.MoneyTypeGroup>();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(MoneyTypeGroupSQL.GetMoneyTypeGroupsForCaseByExcludingCurrMapps(CaseKey)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        moneyTypeGroups.Add(new MoneyTypeGroup
                        {
                            MoneyTypeGroupKey = DBHelper.GetIDataReaderInt(reader, "MTGP_KEY"),
                            MoneyTypeGroupName = DBHelper.GetIDataReaderString(reader, "NAME")
                        });
                    }
                }
            }

            return moneyTypeGroups;
        }

        public static bool IsExists(int caseKey, int moneyTypeGroupKey)
        {
            bool isExists = false;

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(MoneyTypeGroupSQL.IsExists(caseKey, moneyTypeGroupKey)))
                isExists = Convert.ToBoolean(db.ExecuteScalar(cmd));

            return isExists;
        }
    }
}
