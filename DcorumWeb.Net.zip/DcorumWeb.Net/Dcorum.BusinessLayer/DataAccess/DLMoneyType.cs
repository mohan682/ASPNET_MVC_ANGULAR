﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLMoneyType
    {
        public static MoneyType[] GetDefaultMoneyTypes(int caseKey, int mtgKey)
        {
            return DataAccessHelp.GetMany(MoneyTypeSQL.GetDefaultMoneyTypes(caseKey, mtgKey), MapToMoneyType, "UEXT");

            //var moneyTypes = new List<Entities.MoneyType>();

            //Database db = DatabaseFactory.CreateDatabase("UEXT");

            //using (var cmd = db.GetSqlStringCommand(MoneyTypeSQL.GetDefaultMoneyTypes(caseKey, mtgKey)))

            //using (IDataReader reader = db.ExecuteReader(cmd))
            //{
            //    if (!reader.IsClosed)
            //    {
            //        while (reader.Read())
            //        {
            //            moneyTypes.Add(MapToMoneyType(reader));
            //        }
            //    }
            //}

            //return moneyTypes;
        }

        public static MoneyType[] GetMoneyTypes(int cmtgKey)
        {
            return DataAccessHelp.GetMany(MoneyTypeSQL.GetMoneyTypes(cmtgKey), MapToMoneyType, "UEXT");

            //var moneyTypes = new List<Entities.MoneyType>();

            //Database db = DatabaseFactory.CreateDatabase("UEXT");

            //using (var cmd = db.GetSqlStringCommand(MoneyTypeSQL.GetMoneyTypes(cmtgKey)))

            //using (IDataReader reader = db.ExecuteReader(cmd))
            //{
            //    if (!reader.IsClosed)
            //    {
            //        while (reader.Read())
            //        {
            //            moneyTypes.Add(MapToMoneyType(reader));
            //        }
            //    }
            //}

            //return moneyTypes;
        }

        public static MoneyType GetMoneyTypeByCMTGDKey(int cmtgdKey)
        {
            //bug! [DD ]should this just use GetSingle instead???
            var results = DataAccessHelp.GetMany(MoneyTypeSQL.GetMoneyTypeByCMTGDKey(cmtgdKey), MapToMoneyType, "UEXT");
            return results.LastOrDefault();
            //var moneyType = new Entities.MoneyType();

            //Database db = DatabaseFactory.CreateDatabase("UEXT");

            //using (var cmd = db.GetSqlStringCommand(MoneyTypeSQL.GetMoneyTypeByCMTGDKey(cmtgdKey)))

            //using (IDataReader reader = db.ExecuteReader(cmd))
            //{
            //    if (!reader.IsClosed)
            //    {
            //        while (reader.Read())
            //        {
            //            moneyType = MapToMoneyType(reader);
            //        }
            //    }
            //}

            //return moneyType;
        }

        public static int Save(MoneyType moneyType)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            string sql1 = string.Empty;

            if (moneyType.CaseMoneyTypeGroupDetailKey > 0)
            {
                sql1 = MoneyTypeSQL.UpdateMoneyType(moneyType);
            }
            else
            {
                moneyType.CaseMoneyTypeGroupDetailKey = SequenceGetter.GetNextVal(db, "CMTGP_DETL_SEQ");
                sql1 = MoneyTypeSQL.AddMoneyType(moneyType);
            }
               

            using (var cmd = db.GetSqlStringCommand(sql1))
            {
                return db.ExecuteNonQuery(cmd);
            }
        }

        public static int Delete(MoneyType modelStub)
        {
            if (!(modelStub.CaseMoneyTypeGroupDetailKey>0)) return 0;

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(MoneyTypeSQL.DeleteMoneyType(modelStub.CaseMoneyTypeGroupDetailKey.Value)))
            {
                return db.ExecuteNonQuery(cmd);
            }
        }

        private static MoneyType MapToMoneyType(IDataReader reader)
        {
            var moneyType = new MoneyType();
            MapToMoneyTypeCore(moneyType, reader);
            return moneyType;
        }


        private static void MapToMoneyTypeCore(MoneyType moneyType, IDataReader reader)
        {
            moneyType.CaseMoneyTypeGroupDetailKey = DBHelper.GetIDataReaderNullableInt(reader, "CMTGP_DETL_KEY");
            moneyType.CaseMoneyTypeGroupKey = DBHelper.GetIDataReaderNullableInt(reader, "CMTGP_KEY");

            moneyType.CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY");
            moneyType.MoneyTypeGroupKey = DBHelper.GetIDataReaderInt(reader, "MTGP_KEY");

            moneyType.MoneyTypeKey = DBHelper.GetIDataReaderInt(reader, "MNY_TYP_KEY");
            moneyType.MoneyTypeNumber = DBHelper.GetIDataReaderInt(reader, "MNY_TYP_NUM");
            moneyType.MoneyTypeName = DBHelper.GetIDataReaderString(reader, "SHRT_NM");
            moneyType.MoneyTypeDescription = DBHelper.GetIDataReaderString(reader, "LONG_NM");
           // moneyType.FundingRateKey = DBHelper.GetIDataReaderNullableInt(reader, "FDRT_KEY");
            moneyType.TransactionRuleCode = DBHelper.GetIDataReaderString(reader, "TR_CD");
            moneyType.TransactionRuleDescription = DBHelper.GetIDataReaderString(reader, "TR_CD_DESC");
        }


        public static bool IsExists(MoneyType moneyType)
        {
            bool isExists = false;

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(MoneyTypeSQL.IsExists(moneyType)))
                            isExists = Convert.ToBoolean(db.ExecuteScalar(cmd));

            return isExists;
        }
    }
}
