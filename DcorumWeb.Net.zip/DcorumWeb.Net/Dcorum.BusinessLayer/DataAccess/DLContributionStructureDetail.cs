﻿using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics.Contracts;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities.Contributions;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.Contributions
{
    public class DLContributionStructureDetail
    {
        public const string DATABASE_NAME = "UEXT";

        public static ContributionStructureDetail Single(int detailId)
        {
            string sql1 = ContributionStructureDetailSql.SelectViaPKeySql(detailId);
            var result = DataAccessHelp.GetSingle(sql1, Map, DATABASE_NAME);
            return result;
        }


        public static ContributionStructureDetail[] Select(int contributonStructureGroupId)
        {
            string sql1 = ContributionStructureDetailSql.SelectViaFKeySql(contributonStructureGroupId);
            var result = DataAccessHelp.GetMany(sql1, Map, "UEXT");
            return result;
        }

        //public static bool HasDuplicate(ContributionStructureDetail detail)
        //{
        //    if (detail.ParentId == 0) return false;

        //    string sql1 = ContributionStructureSql.CheckForDuplicateSql(detail.ParentId, detail.MemberAgeTo, detail.MemberServiceYearTo, detail.MemberContributionTo, detail.MemberSalaryTo, detail.DateTo, detail.Id);
        //    int count = DataAccessHelp.GetSingle(sql1, _ => DBHelper.GetIDataReaderInt(_, "COUNTID"), "UEXT");
        //    return count > 0;
        //}

        public static bool HasDuplicate(ContributionStructureDetail detail)
        {
            if (detail.ParentId == 0)
                return false;

            Database db = DatabaseFactory.CreateDatabase(DATABASE_NAME);
            DbCommand dbCommand = db.GetSqlStringCommand(ContributionStructureDetailSql.CheckForDuplicateSql(detail.ParentId, detail.MemberAgeTo, detail.MemberServiceYearTo, detail.MemberContributionTo, detail.MemberSalaryTo, detail.DateTo, detail.Id));

            using (IDataReader resultsDataReader = db.ExecuteReader(dbCommand))
            {
                if (!resultsDataReader.IsClosed)
                {
                    if (resultsDataReader.Read())
                    {
                        return DBHelper.GetIDataReaderInt(resultsDataReader, "COUNTID") > 0;
                    }
                }
            }
            return false;
        }


        public static int Insert(ContributionStructureDetail detail)
        {
            Contract.Assert(detail.Id == 0);

            Database db = DatabaseFactory.CreateDatabase(DATABASE_NAME);

            //string sql1 = null;

            //if (detail.Lookup.Lookup > 0)
            //{
            //    sql1 = new ContributionStructureSql().InsertCslSql(db, detail.Lookup);
            //    detail.ParentId = detail.Lookup.ContributionGroupId;
            //    detail.ContributionStructureLookupId = detail.Lookup.LookupId;
            //}

            //string sql2 = ContributionStructureDetailSql.Insert(db, detail);

            //string fullSql = DataAccessHelp.Layout(sql1, sql2);
            //DbCommand dbCommand = db.GetSqlStringCommand(fullSql);
            //return result = db.ExecuteNonQuery(dbCommand);

            int result;
            int newLookupId = 0;

            detail.Id = SequenceGetter.GetNextVal(db, "Contribution_Structure_SEQ");

            if (!(detail.ParentId > 0))
            {
                newLookupId = SequenceGetter.GetNextVal(db, "CONTRIBUTION_STRUCT_LOOKUP_SEQ");
            }

            string sql1 = ContributionStructureSql.InsertContributionStructureDetailsSql(detail.Id,
                detail.ParentId, detail.MemberAgeTo, detail.MemberServiceYearTo, detail.MemberContributionTo,
                detail.DateTo, detail.MemberSalaryTo, detail.MinEmployeeContribution,
                detail.EmployerCoreContribution, detail.EmployerMatchPercentage, detail.MaxEmployeeMatchedRate,
                detail.TotalMaxEmployerContributionPercentage, detail.TotalMaxEmployerContributionAmout,
                detail.SalaryLimit, detail.EffectiveDate, detail.ExpiryDate.Value, detail.CaseKey.GetValueOrDefault(),
                detail.MbGpKey.GetValueOrDefault(), newLookupId);

            // Insert the look up and the cs
            DbCommand dbCommand = db.GetSqlStringCommand(sql1);
            result = db.ExecuteNonQuery(dbCommand);

            //for an insert where a new parent was also inserted at the same time...
            if (!(detail.ParentId > 0))
            {
                var fetchBack = Single(detail.Id);
                detail.ParentId = fetchBack.ParentId;
                detail.ContributionStructureLookupId = newLookupId;
                Contract.Assert(detail.ParentId > 0);
            }

            return result;
        }


        public static int Update(ContributionStructureDetail detail)
        {
            Contract.Assert(detail.ParentId > 0);
            Contract.Assert(detail.Id > 0);

            Database db = DatabaseFactory.CreateDatabase(DATABASE_NAME);

            string sql1 = ContributionStructureDetailSql.UpdateSql(detail.Id, detail.MemberAgeTo,
                detail.MemberServiceYearTo, detail.MemberContributionTo, detail.DateTo, detail.MemberSalaryTo,
                detail.MinEmployeeContribution, detail.EmployerCoreContribution, detail.EmployerMatchPercentage,
                detail.MaxEmployeeMatchedRate, detail.TotalMaxEmployerContributionPercentage,
                detail.TotalMaxEmployerContributionAmout, detail.SalaryLimit, detail.EffectiveDate,
                detail.ExpiryDate.Value);

            DbCommand dbCommand = db.GetSqlStringCommand(sql1);
            return db.ExecuteNonQuery(dbCommand);
        }


        public static int Delete(ContributionStructureDetail detail)
        {
            Database db = DatabaseFactory.CreateDatabase(DATABASE_NAME);
            DbCommand dbCommand = db.GetSqlStringCommand(ContributionStructureDetailSql.DeleteViaPKeySql(detail.Id));
            return db.ExecuteNonQuery(dbCommand);
        }


        internal static ContributionStructureDetail Map(IDataReader resultsDataReader)
        {
            var steppedContribDetail = new ContributionStructureDetail();
            steppedContribDetail.ParentId = DBHelper.GetIDataReaderInt(resultsDataReader, "ID");
            steppedContribDetail.Id = DBHelper.GetIDataReaderInt(resultsDataReader, "DetailId");
            steppedContribDetail.MemberAgeTo = DBHelper.GetIDataReaderInt(resultsDataReader, "AGE_TO");
            steppedContribDetail.MemberContributionTo = DBHelper.GetIDataReaderDecimal(resultsDataReader, "CONTRIBUTION_TO");
            steppedContribDetail.EmployerCoreContribution = DBHelper.GetIDataReaderDecimal(resultsDataReader, "CORE");
            steppedContribDetail.EffectiveDate = DBHelper.GetIDataReaderDateTime(resultsDataReader,
                                                                                  "EFF_DT");
            steppedContribDetail.EmployerMatchPercentage = DBHelper.GetIDataReaderDecimal(resultsDataReader, "MATCH");
            steppedContribDetail.MaxEmployeeMatchedRate = DBHelper.GetIDataReaderDecimal(
                resultsDataReader, "MAX_EE_CONT_MATCHED");
            steppedContribDetail.MinEmployeeContribution = DBHelper.GetIDataReaderDecimal(
                resultsDataReader, "MIN_EE_CONT");
            steppedContribDetail.MemberSalaryTo = Convert.ToInt64(resultsDataReader["SALARY_TO"]);
            steppedContribDetail.MemberServiceYearTo = DBHelper.GetIDataReaderInt(resultsDataReader, "SERVICE_TO");
            steppedContribDetail.TotalMaxEmployerContributionAmout = DBHelper.GetIDataReaderDecimal(resultsDataReader, "TOTAL_ER_MAX_CONTRIB_AMT");
            steppedContribDetail.TotalMaxEmployerContributionPercentage = DBHelper.GetIDataReaderDecimal(resultsDataReader, "TOTAL_ER_MAX_CONTRIB_PCT");
            steppedContribDetail.SalaryLimit = DBHelper.GetIDataReaderInt(resultsDataReader, "UPPER_LIMIT_SALARY");
            steppedContribDetail.ExpiryDate = DBHelper.GetIDataReaderDateTime(resultsDataReader, "XPIR_DT");
            int ordinalDateTo = resultsDataReader.GetOrdinal("DATE_TO");
            if (!resultsDataReader.IsDBNull(ordinalDateTo))
            {
                steppedContribDetail.DateTo = Convert.ToDateTime(resultsDataReader["DATE_TO"]);
            }

            return steppedContribDetail;
        }
    }
}
