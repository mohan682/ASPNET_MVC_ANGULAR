﻿
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLServiceQueueParam
    {
        public bool InsertServiceQueue(int caseKey)
        {
            var sql = ServiceTaskQueueSQL.GetServiceTaskIdQuery();
            var serviceTaskId = DBHelper.ExecuteScalar<int>(sql);
            
            var serviceTaskQueueId = DBHelper.ExecuteNonQuery(ServiceTaskQueueSQL.GetInsertQuery(serviceTaskId));
            DBHelper.ExecuteNonQuery(ServiceTaskQueueParamSQL.GetInsertQuery(caseKey));

            return serviceTaskQueueId > 0;
        }
    }
}
