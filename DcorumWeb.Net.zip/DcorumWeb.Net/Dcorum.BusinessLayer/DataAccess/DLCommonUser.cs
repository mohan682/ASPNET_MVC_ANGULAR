﻿using System.Data;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Enums;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.DataAccess
{
    public abstract class CommonUserHelp
    {
        public static void SafeGuardSingleQuotesForCommonUser(CommonUser commonUser)
        {
            if (commonUser.FirstName != null) commonUser.FirstName = commonUser.FirstName.Replace("'", "''");
            if (commonUser.MidName != null) commonUser.MidName = commonUser.MidName.Replace("'", "''");
            if (commonUser.LastName != null) commonUser.LastName = commonUser.LastName.Replace("'", "''");
            if (commonUser.UserName != null) commonUser.UserName = commonUser.UserName.Replace("'", "''");
        }
    }
}
