﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Contracts;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities.Contributions;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.Contributions
{
    public class DLContributionScaleLookup : DLContributionLookupBase<ContributionScaleLookup>
    {
        public DLContributionScaleLookup()
        {
            SqlStringBuilder = new ContributionScaleSql();
            BulkDetailDeletion = new ContributionScaleDetailSql();
        }

        //For AutoComplete use only!
        public static ThinMemberGroup[] GetMemberGroupsWithScales()
        {
            string sql1 = ContributionScaleSql.GetAllMemberGroupsWithScales();
            var results = DataAccessHelp.GetMany(sql1, MakeThinMemberGroup, DATABASE_NAME);

            bool mustBeTrue = Contract.ForAll(results, _ => _.MemberGroupCategory.RefCd == MemberGroupDomainCodes.BenefitMemberGroupType);
            Contract.Assert(mustBeTrue);

            return results;
        }
    }

    //public class DLContributionScaleLookup
    //{
    //    public static ContributionScaleLookup[] Select(int caseKey)
    //    {
    //        string sql1 = ContributionScaleSql.SelectSql(caseKey, true);
    //        var result = DataAccessHelp.GetMany(sql1, MapToMemberGroupContributionScaleShared, "UEXT");
    //        return result;
    //    }

    //    public static ContributionScaleLookup Single(int lookupId)
    //    {
    //        string sql1 = ContributionScaleSql.SelectSql(lookupId, false);
    //        var result = DataAccessHelp.GetSingle(sql1, MapToMemberGroupContributionScaleShared, "UEXT");
    //        return result;
    //    }

    //    public static List<ContributionScaleLookup> GetMemberGroupsWithScales()
    //    {
    //        var memberGroups = new List<ContributionScaleLookup>();
    //        Database db = DatabaseFactory.CreateDatabase("UEXT");

    //        using (var cmd = db.GetSqlStringCommand(ContributionScaleSql.GetAllMemberGroupsWithScales()))
    //        using (IDataReader reader = db.ExecuteReader(cmd))
    //        {
    //            if (!reader.IsClosed)
    //            {
    //                while (reader.Read())
    //                {
    //                    memberGroups.Add(MapToMemberGroupContributionScale(reader));
    //                }
    //            }
    //        }

    //        return memberGroups;
    //    }


    //    private static ContributionScaleLookup MapToMemberGroupContributionScale(IDataReader reader)
    //    {
    //        var result = new ContributionScaleLookup();

    //        int id = DBHelper.GetIDataReaderInt(reader, "MBGP_KEY");
    //        result.MbGpKey = id;
    //        result.Description = string.Concat(DBHelper.GetIDataReaderString(reader, "DESCRIPT"), " (", id, ")");
    //        result.ContributionGroupId = DBHelper.GetIDataReaderInt(reader, "CONTRIBUTION_SCALE_GROUP_ID");
    //        //var result = new ContributionScaleLookup(id, decript, Constants.DomainCodes.BenefitMemberGroupType, contributionScaleGroupId);
    //        return result;
    //    }

    //    private static ContributionScaleLookup MapToMemberGroupContributionScaleShared(IDataReader reader)
    //    {
    //        var result = new ContributionScaleLookup();

    //        int id = DBHelper.GetIDataReaderInt(reader, "MBGP_KEY");
    //        result.MbGpKey = id;
    //        result.Description = string.Concat(DBHelper.GetIDataReaderString(reader, "DESCRIPT"), " (", id, ")");
    //        result.ContributionGroupId = DBHelper.GetIDataReaderInt(reader, "CONTRIBUTION_SCALE_GROUP_ID");
    //        result.IsShared = DBHelper.GetIDataReaderInt(reader, "COUNTSCALE") > 0;

    //        result.VariationCode = DBHelper.GetIDataReaderString(reader, "VARIATION_CD");
    //        //result.Variation = DlContributionStructure.MapToVariation(result.VariationCode);
    //        //var result = new ContributionScaleLookup(id, decript, Constants.DomainCodes.BenefitMemberGroupType, contributionScaleGroupId, isShared,variation);
    //        result.LookupId = DBHelper.GetIDataReaderNullableInt(reader, "CSL_ID");
    //        result.CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY");
    //        result.MemberGroupCategory = new RefCode(DBHelper.GetIDataReaderString(reader, "GRP_TYP_CD"));
    //        return result;
    //    }


    //    public static String[] GetVariationCodes(int contributionScaleGroupId, int memberGroupId)
    //    {
    //        if (!(contributionScaleGroupId > 0)) return new string[0];
    //        var sql1 = ContributionScaleSql.GetVariationCodeSql(contributionScaleGroupId, memberGroupId);
    //        var result = DataAccessHelp.GetMany(sql1, _ => DBHelper.GetIDataReaderString(_, "VARIATION_CD"), "UEXT");
    //        return result;
    //    }

    //    public static int SaveVariation(string variation, int memberGroupId, int contributionScaleGroupId)
    //    {
    //        Database db = DatabaseFactory.CreateDatabase("UEXT");

    //        string sql1 = ContributionScaleSql.SaveVariationSql(variation, memberGroupId, contributionScaleGroupId);

    //        using (var cmd = db.GetSqlStringCommand(sql1))
    //        {
    //            return db.ExecuteNonQuery(cmd);
    //        }
    //    }


    //    /// <summary>
    //    /// Delete existing CSLs for target member group and insert a new CSL sharing the source member group's group id.
    //    /// </summary>
    //    public static int CopyContributionScale(int sourceMemberGroup, int targetMemberGroup)
    //    {
    //        Database db = DatabaseFactory.CreateDatabase("UEXT");
    //        var sql = ContributionScaleSql.CopySql(sourceMemberGroup, targetMemberGroup);

    //        using (var cmd = db.GetSqlStringCommand(sql))
    //        {
    //            return db.ExecuteNonQuery(cmd);
    //        }
    //    }

    //    /// <summary>
    //    /// Delete existing CSLs for target member group and insert a new CSL with a new group id then copy the detail rows over but with the new group id.
    //    /// </summary>
    //    public static int CloneContributionScale(int sourceMemberGroup, int targetMemberGroup)
    //    {
    //        Database db = DatabaseFactory.CreateDatabase("UEXT");
    //        var sql = ContributionScaleSql.CloneSql(sourceMemberGroup, targetMemberGroup);

    //        using (var cmd = db.GetSqlStringCommand(sql))
    //        {
    //            return db.ExecuteNonQuery(cmd);
    //        }
    //    }
    //}
}
