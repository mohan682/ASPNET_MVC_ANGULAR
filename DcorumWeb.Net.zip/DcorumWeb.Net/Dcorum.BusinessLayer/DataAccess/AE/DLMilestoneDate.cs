﻿using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;
using Dcorum.BusinessLayer.Entities.AE;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.AE
{
    public class DLMilestoneDate
    {
        private const string DatabaseName = "UEXT";

        public static IEnumerable<MilestoneDate> GetMilestoneDatesForClientFile(int clientFileId)
        {
            IList<MilestoneDate> milestoneDates = new List<MilestoneDate>();

            if (clientFileId <= 0)
                return milestoneDates;

            Database db = DatabaseFactory.CreateDatabase(DatabaseName);
            using (DbCommand dbCmd = db.GetSqlStringCommand(GetMilestoneDatesForClientFileSqlString(clientFileId)))
            using (IDataReader reader = db.ExecuteReader(dbCmd))
            {
                if (reader.IsClosed)
                    return null;

                while (reader.Read())
                    milestoneDates.Add(Map(reader));
            }

            return milestoneDates;
        }

        public static void DeleteForClientFile(int clientFileId)
        {
            if (clientFileId <= 0)
                return;

            Database db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (DbCommand dbCmd = db.GetSqlStringCommand(GetDeleteForClientFileSqlString(clientFileId)))
                db.ExecuteNonQuery(dbCmd);
        }

        #region Helper Methods

        private static string GetMilestoneDatesForClientFileSqlString(int clientFileId)
        {
            var sqlString = new StringBuilder();
            sqlString.AppendLine("SELECT");
            sqlString.AppendLine("AE_MILESTONE_DATES_ID, AUTO_ENROLL_DATE, JOIN_DATE, ");
            sqlString.AppendLine("OPT_IN_DATE, OPT_OUT_DATE, AE_COMMS_PRINTED_DATE, ");
            sqlString.AppendLine("AE_CONTROL_ID, CASE_MBR_KEY ");
            sqlString.AppendLine("FROM AE_MILESTONE_DATES");
            sqlString.AppendFormat("WHERE AE_CONTROL_ID ={0}", clientFileId);

            return sqlString.ToString();
        }

        private static string GetDeleteForClientFileSqlString(int clientFileId)
        {
            var sqlString = new StringBuilder();

            sqlString.AppendLine("DELETE FROM AE_MILESTONE_DATES");
            sqlString.AppendFormat("WHERE AE_CONTROL_ID = {0}", clientFileId);

            return sqlString.ToString();
        }

        private static MilestoneDate Map(IDataReader reader)
        {
            var milestoneDate = new MilestoneDate
                {
                    MilestoneDateId = DBHelper.GetIDataReaderInt(reader, "AE_MILESTONE_DATES_ID"),
                    AutoEnrollDate = DBHelper.GetIDataReaderNullableDateTime(reader, "AUTO_ENROLL_DATE"),
                    JoinDate = DBHelper.GetIDataReaderNullableDateTime(reader, "JOIN_DATE"),
                    OptInDate = DBHelper.GetIDataReaderNullableDateTime(reader, "OPT_IN_DATE"),
                    OptOutDate = DBHelper.GetIDataReaderNullableDateTime(reader, "OPT_OUT_DATE"),
                    CommsPrintedDate = DBHelper.GetIDataReaderNullableDateTime(reader, "AE_COMMS_PRINTED_DATE"),
                    ClientFileId = DBHelper.GetIDataReaderInt(reader, "AE_CONTROL_ID"),
                    CaseMbrKey = DBHelper.GetIDataReaderInt(reader, "CASE_MBR_KEY")
                };

            return milestoneDate;
        }

        #endregion
    }
}