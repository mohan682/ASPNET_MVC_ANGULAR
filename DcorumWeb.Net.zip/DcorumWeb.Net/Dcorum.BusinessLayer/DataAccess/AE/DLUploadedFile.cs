﻿using System;
using System.Data;
using System.Data.Common;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.DataAccess.AE
{
    public static class DLUploadedFile
    {
        private const string DatabaseName = "UEXT";

        /// <summary>
        /// Still have some work to do on the save.
        /// </summary>
        /// <param name="uploadedFile"></param>
        /// <returns></returns>
        internal static Entities.AE.UploadedFile Save(Entities.AE.UploadedFile uploadedFile)
        {
            if (uploadedFile.Id < 0)
                throw new ArgumentException();

            var db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (var dbCmd = db.GetSqlStringCommand(GetSaveSqlString(uploadedFile))) 
            {
               var rowsAffected =  db.ExecuteNonQuery(dbCmd);
            }

            return uploadedFile;
        }

        /// <summary>
        /// TODO: Refactor this.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        internal static Entities.AE.UploadedFile Get(int id)
        {
            IList<Entities.AE.UploadedFile> uploadedFiles = new List<Entities.AE.UploadedFile>();

            var db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (var dbCmd = db.GetSqlStringCommand(GetSqlString(id)))
            using (var reader = db.ExecuteReader(dbCmd))
            {
                if (reader.IsClosed)
                    return null;

                while (reader.Read())
                    uploadedFiles.Add(Map(reader));
            }

            return uploadedFiles[0];
        }

        internal static IList<Entities.AE.UploadedFile> GetFilesForBillingGroup(int bgrpKey)
        {
            IList<Entities.AE.UploadedFile> uploadedFiles = new List<Entities.AE.UploadedFile>();

            if (bgrpKey <= 0)
                return uploadedFiles;

            var db = DatabaseFactory.CreateDatabase(DatabaseName);


            using (var dbCmd = db.GetSqlStringCommand(GetUploadedFilesForBillingGroupSql(bgrpKey)))
            using (var reader = db.ExecuteReader(dbCmd))
            {
                if (reader.IsClosed)
                    return null;

                while (reader.Read())
                    uploadedFiles.Add(Map(reader));
            }

            return uploadedFiles;
        }

        private static string GetSqlString(int id, string userId = "")
        {
            var sqlString = new StringBuilder();

            sqlString.AppendLine("SELECT * FROM UEXT.AE_CONTROL");
            sqlString.AppendFormat("WHERE AE_CONTROL_ID = {0}", id);

            return sqlString.ToString();
        }

        private static string GetUploadedFilesForBillingGroupSql(int bgrpKey, string userId = "")
        {
            var sSQL = new StringBuilder();

            sSQL.AppendLine("SELECT * FROM UEXT.AE_CONTROL");
            sSQL.AppendFormat("WHERE BGRP_KEY = {0}", bgrpKey);
            sSQL.AppendLine("ORDER BY PRP_YEAR, PRP");

            return sSQL.ToString();
        }

        private static string GetSaveSqlString(Entities.AE.UploadedFile uploadedFile, string userId = "")
        {
            var sqlString = new StringBuilder();

            sqlString.AppendLine("UPDATE AE_CONTROL SET ");
            sqlString.AppendFormat("DATE_AUTHORISED = null {0}", Environment.NewLine);
            sqlString.AppendFormat("WHERE AE_CONTROL_ID = {0} ", uploadedFile.Id);

            return sqlString.ToString();
        }

        private static Entities.AE.UploadedFile Map(IDataReader reader)
        {
            var uploadedFile = new Entities.AE.UploadedFile
                       {
                           Id = DBHelper.GetIDataReaderInt(reader, "AE_CONTROL_ID"),
                           CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY"),
                           BgrpKey = DBHelper.GetIDataReaderInt(reader, "BGRP_KEY"),
                           Prp = DBHelper.GetIDataReaderString(reader, "PRP"),
                           FileSequence = DBHelper.GetIDataReaderInt(reader, "FILE_SEQ"),
                           PrpSequence = DBHelper.GetIDataReaderNullableInt(reader, "PRP_SEQ"),
                           DateProcessed = DBHelper.GetIDataReaderNullableDateTime(reader, "DATE_PROCESSED"),
                           DateValidated = DBHelper.GetIDataReaderNullableDateTime(reader, "DATE_VALIDATED"),
                           DateAuthorised = DBHelper.GetIDataReaderNullableDateTime(reader, "DATE_AUTHORISED"),
                           PrpYear = DBHelper.GetIDataReaderInt(reader, "PRP_YEAR"),
                           FileName = DBHelper.GetIDataReaderString(reader, "FILENAME"),
                           PrpStartDate = DBHelper.GetIDataReaderDateTime(reader, "PRP_START_DATE"),
                           PrpEndDate = DBHelper.GetIDataReaderDateTime(reader, "PRP_END_DATE"),
                           AuthorisedUserId = DBHelper.GetIDataReaderString(reader, "AUTHORISED_USER_ID")
                       };

            return uploadedFile;
        }
    }
}
