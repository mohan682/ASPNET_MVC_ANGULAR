﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities.AE;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.AE
{
    public class DLUploadedFileEntry
    {

        private const string DatabaseName = "UEXT";

        internal static IList<Entities.AE.UploadedFileEntry> SearchForAuthorizedFilesUsingCriteria(string searchCriteria)
        {
            if (string.IsNullOrEmpty(searchCriteria))
                throw new ArgumentException();

            IList<Entities.AE.UploadedFileEntry> uploadedFileEntries = new List<UploadedFileEntry>();

            var db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (var dbCmd = db.GetSqlStringCommand(GetSearchSqlString(searchCriteria)))
            using (var reader = db.ExecuteReader(dbCmd))
            {
                if (reader.IsClosed)
                    return null;

                while (reader.Read())
                    uploadedFileEntries.Add(Map(reader));
            }

            return uploadedFileEntries;
        }

        #region Helper Methods



        private static string GetSearchSqlString(string searchCriteria)
        {
            var sqlString = new StringBuilder();

            sqlString.AppendLine("SELECT D.AE_FILE_DETAIL_ID, D.AE_CONTROL_ID, D.FILE_ROW,");
            sqlString.AppendLine("D.SCHEME_EXT_ID, D.SCHEME_NAME, D.CURRENCY_CODE,");
            sqlString.AppendLine("D.TITLE, D.SURNAME, D.FIRST_NAME,");
            sqlString.AppendLine("D.MIDDLE_NAME, D.OTHER_NAME, D.DOB,");
            sqlString.AppendLine("D.NINO, D.GENDER, D.HOME_ADDRESS_1, ");
            sqlString.AppendLine("D.HOME_ADDRESS_2, D.HOME_ADDRESS_3, D.HOME_ADDRESS_4,");
            sqlString.AppendLine("D.HOME_ADDRESS_5, D.HOME_POSTCODE, D.HOME_COUNTRY, ");
            sqlString.AppendLine("D.HOME_EMAIL, D.WORK_ADDRESS_1, D.WORK_ADDRESS_2,");
            sqlString.AppendLine("D.WORK_ADDRESS_3, D.WORK_ADDRESS_4, D.WORK_ADDRESS_5,");
            sqlString.AppendLine("D.WORK_POSTCODE, D.WORK_COUNTRY, D.WORK_EMAIL, ");
            sqlString.AppendLine("D.EMPLOYMENT_START_DATE, D.GROSS_EARNINGS_PRP, D.EARNINGS_FREQUENCY_ID, ");
            sqlString.AppendLine("D.SALARY, D.SALARY_FREQUENCY_ID, D.MEMBER_CLASS_ID, ");
            sqlString.AppendLine("D.BILLING_GROUP_EXT_ID, D.OVERRIDE_MEMBER_GROUP_ID, D.OVERRIDE_CONT_CATEGORY_ID, ");
            sqlString.AppendLine("D.OVERRIDE_INVESTMENT_GROUP_ID, D.OVERRIDE_STATUS, D.WPP_END_DATE, ");
            sqlString.AppendLine("D.EJHPP_END_DATE, D.NOTICE_RECEIVED_DATE, D.OPTOUT_NOTICE_RECEIVED_DATE, ");
            sqlString.AppendLine("D.AE_INFO_GIVEN_DATE, D.TANDC_DELIVERED_DATE, D.INVALID_OPTOUT_NOTICE, ");
            sqlString.AppendLine("D.STATUS, D.PAYROLL_NO, D.IGNORE_REASON_CODE, ");
            sqlString.AppendLine("D.ERROR_REASON_CODE, D.AE_DATE, D.PRP, ");
            sqlString.AppendLine("D.PRP_SEQ, D.PRP_YEAR, D.EMPLOYER_ID");

            sqlString.AppendLine("FROM UEXT.AE_FILE_DETAIL D");
            sqlString.AppendLine("INNER JOIN AE_CONTROL C");
            sqlString.AppendLine("ON D.AE_CONTROL_ID = C.AE_CONTROL_ID");
            sqlString.AppendLine("INNER JOIN UEXT.AE_FILE_DETAIL_UPDATE U");
            sqlString.AppendLine("ON D.AE_FILE_DETAIL_ID = U.AE_FILE_DETAIL_ID AND U.DEFAULT_STATUS = 1");

            sqlString.AppendLine("WHERE 1 = 1");
            sqlString.AppendLine("AND C.DATE_AUTHORISED IS NOT NULL");
            sqlString.AppendLine(searchCriteria);

            return sqlString.ToString();
        }

        private static Entities.AE.UploadedFileEntry Map(IDataReader reader)
        {
            var uploadFileEntry = new Entities.AE.UploadedFileEntry
                {
                    Id = DBHelper.GetIDataReaderInt(reader,"AE_FILE_DETAIL_ID"),
                    SchemeExternalId = DBHelper.GetIDataReaderString(reader, "Scheme_Ext_ID"),
                    SchemeName = DBHelper.GetIDataReaderString(reader, "Scheme_Name"),
                    //PrpYear = DBHelper.GetIDataReaderString(reader, "PrpYear"),
                    //PayRollPeriod = DBHelper.GetIDataReaderString(reader, "Pay_Roll_Period"),
                    //PaySequenceNo = DBHelper.GetIDataReaderInt(reader, "Pay_Sequence_No"),
                    //Currency = DBHelper.GetIDataReaderString(reader, "Currency"),
                    Title = DBHelper.GetIDataReaderString(reader, "Title"),
                    Surname = DBHelper.GetIDataReaderString(reader, "Surname"),
                    FirstName = DBHelper.GetIDataReaderString(reader, "First_Name"),
                    //
                    Nino = DBHelper.GetIDataReaderString(reader, "NINO"),
                    //
                    //PayrollBillingGroupExternalId = DBHelper.GetIDataReaderString(reader, "Payroll_Billing_Group_External_ID"),
                    //
                    PayrollNumber = DBHelper.GetIDataReaderString(reader, "PAYROLL_NO")

                };

            return uploadFileEntry;
        }

        #endregion

    }
}
