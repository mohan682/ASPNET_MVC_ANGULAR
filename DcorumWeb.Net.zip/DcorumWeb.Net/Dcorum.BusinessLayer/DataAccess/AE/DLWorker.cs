﻿using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Text;
using Dcorum.BusinessLayer.Entities.AE;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.AE
{
    public static class DLWorker
    {
        private const string DatabaseName = "UEXT";

        internal static Worker Get(string niNumber, string userId = "")
        {
            IList<Worker> workers = new List<Worker>();

            var db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (var dbCmd = db.GetSqlStringCommand(GetSqlString(niNumber)))
            using (var reader = db.ExecuteReader(dbCmd))
            {
                if (reader.IsClosed)
                    return null;

                while (reader.Read())
                    workers.Add(Map(reader));
            }

            if(workers.Count == 1)
                return workers[0];

            if(workers.Count > 1)
                throw new InvalidDataException("Duplicate records found.");

            return null;
        }

        #region Helper Methods

        private static string GetSqlString(string niNumber, string userId = "")
        {
            var sqlString = new StringBuilder();

            sqlString.AppendLine("SELECT");
            sqlString.AppendLine("CM.CASE_MBR_KEY,CM.PYRL_NO,");
            sqlString.AppendLine("VP.NATLIDNO, VP.FIRSTNAME, VP.LASTNAME,VP.BIRTHDT");
            sqlString.AppendLine("FROM PERSON VP");
            sqlString.AppendLine("INNER JOIN CASE_MEMBERS CM");
            sqlString.AppendLine("ON VP.NAMEID = CM.NAMEID");
            sqlString.AppendFormat("WHERE VP.NATLIDNO = '{0}'", niNumber);

            return sqlString.ToString();
        }


        private static Worker Map(IDataReader reader)
        {
            var worker = new Worker
                {
                    NiNumber = DBHelper.GetIDataReaderString(reader, "NATLIDNO"),
                    Title = "Unknown",
                    FirstName = DBHelper.GetIDataReaderString(reader, "FIRSTNAME"),
                    LastName = DBHelper.GetIDataReaderString(reader, "LASTNAME"),
                    Birthday = DBHelper.GetIDataReaderDateTime(reader, "BIRTHDT")
                };

            return worker;
        }

        #endregion
    }
}