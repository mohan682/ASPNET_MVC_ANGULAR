﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;
using Dcorum.BusinessLayer.Entities.AE;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.AE
{
    public class DLDecision
    {
        private const string DatabaseName = "UEXT";

        internal static IList<Decision> GetDecisionsForWorker(string niNumber, int caseKey)
        {
            IList<Decision> decisions = new List<Decision>();

            Database db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (DbCommand dbCmd = db.GetSqlStringCommand(GetDecisionsForWorkerSqlString(niNumber)))
            using (IDataReader reader = db.ExecuteReader(dbCmd))
            {
                if (reader.IsClosed)
                    return null;

                while (reader.Read())
                    decisions.Add(Map(reader));
            }

            return decisions;
        }

        #region Helper Methods

        private static string GetDecisionsForWorkerSqlString(string niNumber)
        {
            var sql = new StringBuilder();
            sql.AppendLine("SELECT  C.AE_CONTROL_ID, D.AE_FILE_DETAIL_ID, U.AE_FILE_DETAIL_UPDATE_ID,");
            sql.AppendLine("D.NINO, C.CASE_KEY, BGRP_KEY, C.PRP, C.PRP_START_DATE, C.PRP_END_DATE, C.PRP_YEAR,");
            sql.AppendLine(
                "U.STATUS, U.REASON_CODE,  U.WORKER_TYPE, U.WPP_END_DATE, U.EJHPP_END_DATE, D.IGNORE_REASON_CODE,");
            sql.AppendLine("D.EMPLOYMENT_START_DATE, U.STATUS_DATE, C.DATE_AUTHORISED");

            sql.AppendLine("FROM AE_CONTROL C");
            sql.AppendLine("INNER JOIN UEXT.AE_FILE_DETAIL D ON C.AE_CONTROL_ID = D.AE_CONTROL_ID");
            sql.AppendLine(
                "INNER JOIN UEXT.AE_FILE_DETAIL_UPDATE U ON D.AE_FILE_DETAIL_ID = U.AE_FILE_DETAIL_ID AND U.DEFAULT_STATUS = 1");
            sql.AppendLine("WHERE C.DATE_AUTHORISED IS NOT NULL");
            sql.AppendFormat("AND D.NINO = '{0}'{1}", niNumber,Environment.NewLine);

            sql.AppendFormat("ORDER BY C.PRP_YEAR, C.PRP_START_DATE");

            return sql.ToString();
        }

        private static Decision Map(IDataReader reader)
        {
            var decision = new Decision
                {
                    UploadedFileEntryId = DBHelper.GetIDataReaderInt(reader, "AE_CONTROL_ID"),
                    UploadedFileId = DBHelper.GetIDataReaderInt(reader, "AE_FILE_DETAIL_ID"),
                    UpdateId = DBHelper.GetIDataReaderInt(reader, "AE_FILE_DETAIL_UPDATE_ID"),
                    Nino = DBHelper.GetIDataReaderString(reader, "NINO"),
                    CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY"),
                    BillingGroupKey = DBHelper.GetIDataReaderInt(reader, "BGRP_KEY"),
                    PayRollPeriod = new PRP
                        {
                            Name = DBHelper.GetIDataReaderString(reader, "PRP"),
                            Start = DBHelper.GetIDataReaderDateTime(reader, "PRP_START_DATE"),
                            End = DBHelper.GetIDataReaderDateTime(reader, "PRP_END_DATE"),
                            Year = DBHelper.GetIDataReaderInt(reader, "PRP_YEAR")
                        },
                    Status = DBHelper.GetIDataReaderString(reader, "STATUS"),
                    WorkerType = DBHelper.GetIDataReaderInt(reader, "WORKER_TYPE"),
                    WorkerPosponementEndDate = DBHelper.GetIDataReaderNullableDateTime(reader, "WPP_END_DATE"),
                    EjhPosponementEndDate = DBHelper.GetIDataReaderNullableDateTime(reader, "EJHPP_END_DATE"),
                    ReasonCode = DBHelper.GetIDataReaderString(reader, "REASON_CODE"),
                    EmployeeStartDate = DBHelper.GetIDataReaderString(reader, "EMPLOYMENT_START_DATE"),
                };

            return decision;
        }

        #endregion
    }
}