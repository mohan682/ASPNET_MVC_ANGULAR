﻿using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLFullScheme
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        /// <param name="sqlMaker"></param>
        internal DLFullScheme(SchemeSQL sqlMaker)
        {
            _sqlMaker = sqlMaker;
            ThinSchemeCreationTechnique = ThinSchemeFactoryMethods.Singleton.@MakeScheme;
        }

        private SchemeSQL _sqlMaker { get; }

        internal Func<IDataReader, SchemeFull> SchemeFullCreationTechnique;

        /// <summary>
        /// Used to fetch potential associated Drawdown schemes
        /// </summary>
        private Func<IDataReader, Scheme> ThinSchemeCreationTechnique { get; }



        internal SchemeFull GetScheme(int caseKey)
        {
            if (SchemeFullCreationTechnique == null) throw new InvalidOperationException(nameof(SchemeFullCreationTechnique));

            string sql1 = _sqlMaker.GetSchemeSettingSql(caseKey);
            return DataAccessHelp.GetSingle(sql1, @SchemeFullCreationTechnique);
        }

        internal bool UpdateScheme(SchemeFull scheme)
        {
            string sql1 = _sqlMaker.UpdateSchemeSql(scheme);
            int affectedCount = DataAccessHelp.SimpleExecuteNonQuery(sql1);
            return affectedCount > 0;
        }


        internal Scheme[] GetDcumeSchemes(int accumeSchemeId)
        {
            string sql1 = _sqlMaker.GetDecumSchemesSql(accumeSchemeId);
            return DataAccessHelp.GetMany(sql1, @ThinSchemeCreationTechnique);
        }


        internal bool IsSchemeAllowedDrawdown(int? caseKey)
        {
            bool isAllowed = false;

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(_sqlMaker.IsSchemeAllowedDrawdown(caseKey)))
            {
                object result = db.ExecuteScalar(cmd);

                if (result != null)
                    isAllowed = (result != null && int.Parse(result.ToString()) == 1) ? true : false;
            }

            return isAllowed;
        }
    }


    public class DLScheme
    {
        internal DLScheme(SchemeSQL sqlMaker)
        {
            _sqlMaker = sqlMaker;
            ThinSchemeCreationTechnique = ThinSchemeFactoryMethods.Singleton.@MakeScheme;
        }

        private /*readonly*/ SchemeSQL _sqlMaker;

        private Func<IDataReader, Scheme> ThinSchemeCreationTechnique { get; }


        internal Scheme[] GetAllSchemes(bool targetPlanEnabledOnly)
        {
            string sql1 = targetPlanEnabledOnly ? _sqlMaker.GetAllTargetPlanSchemesSql() : _sqlMaker.GetAllSchemesSql();
            return DataAccessHelp.GetMany(sql1, @ThinSchemeCreationTechnique);
        }


        internal Scheme GetScheme(int caseKey)
        {
            string sql1 = _sqlMaker.GetSchemeSettingSql(caseKey);
            return DataAccessHelp.GetSingle(sql1, @ThinSchemeCreationTechnique);
        }

        internal Scheme GetScheme(string schemeExternalId)
        {
            string sql1 = _sqlMaker.GetSchemeByExternalIdSql(schemeExternalId);
            return DataAccessHelp.GetSingle(sql1, @ThinSchemeCreationTechnique);
        }

        internal bool IsSchemeAllowedInvestmentByMoneyType(int caseKey)
        {
            bool isAllowed = false;

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(_sqlMaker.IsSchemeAllowedInvestmentByMoneyType(caseKey)))
            {
                object result = db.ExecuteScalar(cmd);

                if (result != null)
                    isAllowed = (result != null && int.Parse(result.ToString()) == 1) ? true : false;
            }

            return isAllowed;
        }


        public static bool IsSchemeEditable(int caseKey)
        {
            var sql = $"SELECT HIDE_MY_PENSION_TAB FROM uext_case_data WHERE Case_Key={caseKey}";
            return DBHelper.ExecuteScalar<int>(sql) == 0;
        }
    }
}