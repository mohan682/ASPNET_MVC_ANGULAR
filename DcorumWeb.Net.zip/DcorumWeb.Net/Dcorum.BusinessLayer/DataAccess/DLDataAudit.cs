﻿using System.Data;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities.Extensions;
using System;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLDataAudit
    {
        internal DLDataAudit(DataAuditSQL sqlMaker)
        {
            DataAuditSQL = sqlMaker;
            if (DataAuditSQL == null) throw new ArgumentNullException(nameof(sqlMaker));
        }

        private readonly DataAuditSQL DataAuditSQL;

        internal DataAudit[] GetDataAuditRecords(DataAudit searchFilter)
        {
            var sql = DataAuditSQL.SearchDataAuditSql(searchFilter) ;
            var results = DataAccessHelp.GetMany(sql, Make);
            return results ;
        }


        internal DataAudit GetDataAuditRecordById(int dataAuditId)
        {
            var sql = DataAuditSQL.SearchDataAuditByIdSql(dataAuditId);
            var result = DataAccessHelp.GetSingle(sql, Make);
            return result;
        }


        private DataAudit Make(IDataReader reader)
        {
            var creation1 = new DataAudit();
            Fill(creation1, reader);
            return creation1;
        }


        private void Fill(DataAudit toBuild, IDataReader reader)
        {  
            toBuild.DataAuditId = DBHelper.GetIDataReaderInt(reader, "Standing_Data_Audit_Id");
            toBuild.UserId = DBHelper.GetIDataReaderInt(reader, "User_Id");


            toBuild.AuditIdentifier = reader.GetValue( reader.GetOrdinal("Audit_Identifier")).ToString();

            toBuild.IdentifierType = new BusinesObjects.RefCode(DBHelper.GetIDataReaderString(reader, "Identifier_Type"));
            toBuild.ActionDateTime = DBHelper.GetIDataReaderString(reader, "Action_Date");
           
            string component1 = DBHelper.GetIDataReaderString(reader, "Component");
            toBuild.AuditComponent = new BusinesObjects.RefCode(component1);

            //bugfix: audit was for a time recording 'U', 'I', 'D' as ascii numeric values so this compensates for that.
            string operationCategory = DBHelper.GetIDataReaderString(reader, "Operation_Type");
            int? asciiValue = operationCategory.IntoIntN();
            if (asciiValue.HasValue) operationCategory = ((char)asciiValue.Value).ToString();
            toBuild.OperationType = new BusinesObjects.RefCode(operationCategory);

            toBuild.SourceSystem = new BusinesObjects.RefCode(DBHelper.GetIDataReaderString(reader, "Source"));
            toBuild.ExistingValue = DBHelper.GetIDataReaderString(reader, "Existing_Value");
            toBuild.NewValue = DBHelper.GetIDataReaderString(reader, "New_Value");
            toBuild.AuditIdentifierDesc = DBHelper.GetIDataReaderString(reader, "Identifier_Desc");
            toBuild.AuditUserName = DBHelper.GetIDataReaderString(reader, "User_Name");
        }
    }
}
