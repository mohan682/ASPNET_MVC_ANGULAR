﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.DataAccess
{
    internal class DLCaseIdentity
    {
        static DLCaseIdentity()
        {
            ChooseMode();
        }

        internal static List<CaseIdentity> GetAllCaseIdentity()
        {
            var caseIdentityRecs = new List<CaseIdentity>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(CaseIdentitySQL.GetAllCaseIdentitySql()))
            using (IDataReader reader = db.ExecuteReader(cmd))
                if (!reader.IsClosed)
                    while (reader.Read())
                        caseIdentityRecs.Add(PopulateCaseIdentity(reader));

            return caseIdentityRecs;
        }

        internal static CaseIdentity GetCaseIdentityById(int caseIdentityId)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");
            CaseIdentity caseIdentityRec = null;

            using (var cmd = db.GetSqlStringCommand(CaseIdentitySQL.GetCaseIdentityByIdSql(caseIdentityId)))
            using (IDataReader reader = db.ExecuteReader(cmd))
                if (!reader.IsClosed)
                    if (reader.Read())
                        caseIdentityRec = PopulateCaseIdentity(reader);

            return caseIdentityRec;
        }

        internal static List<CaseIdentity> GetCaseIdentityByScheme(CaseIdentity caseIdentity)
        {
            List<CaseIdentity> caseIdentityRecs = new List<CaseIdentity>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(CaseIdentitySQL.GetCaseIdentityBySchemeSql(caseIdentity)))
            using (IDataReader reader = db.ExecuteReader(cmd))
                if (!reader.IsClosed)
                    while (reader.Read())
                        caseIdentityRecs.Add(PopulateCaseIdentity(reader));

            return caseIdentityRecs;
        }

        internal static List<CaseIdentity> GetCaseIdentityByIDPAlias(CaseIdentity caseIdentity)
        {
            List<CaseIdentity> caseIdentityRecs = new List<CaseIdentity>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(CaseIdentitySQL.GetCaseIdentityByIDPAliasSql(caseIdentity)))
            using (IDataReader reader = db.ExecuteReader(cmd))
                if (!reader.IsClosed)
                    while (reader.Read())
                        caseIdentityRecs.Add(PopulateCaseIdentity(reader));

            return caseIdentityRecs;
        }

        public static bool InsertCaseIdentity(CaseIdentity caseIdentity)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(CaseIdentitySQL.InsertCaseIdentitySql(caseIdentity)))
                return db.ExecuteNonQuery(cmd) > 0;
        }

        public static bool UpdateCaseIdentity(CaseIdentity caseIdentity)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(CaseIdentitySQL.UpdateCaseIdentitySql(caseIdentity)))
                return db.ExecuteNonQuery(cmd) > 0;
        }

        public static bool DeleteCaseIdentity(CaseIdentity caseIdentity)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(CaseIdentitySQL.DeleteCaseIdentitySql(caseIdentity)))
                return db.ExecuteNonQuery(cmd) == 1;
        }

        private static CaseIdentity PopulateCaseIdentity(IDataReader reader)
        {
            CaseIdentity caseIdentityRec = new CaseIdentity();

            var Scheme = new Scheme(reader, true);
            caseIdentityRec.SchemeDisplayText = Scheme.DisplayText ;

            caseIdentityRec.CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY");

            caseIdentityRec.CaseIdentityId = DBHelper.GetIDataReaderInt(reader, "CASE_DATA_IDT_PROVIDER_ID");
            caseIdentityRec.IdentityProvider = DBHelper.GetIDataReaderString(reader, "IDENTITY_PROVIDER");
            if (CaseIdentitySQL.Jira6845ModeOn)
            {
                caseIdentityRec.IDPShortName = DBHelper.GetIDataReaderString(reader, "IDENTITY_PROVIDER_ALIAS");
                caseIdentityRec.IDPURL = DBHelper.GetIDataReaderString(reader, "IDENTITY_URL");
                caseIdentityRec.IdentityChecksum = DBHelper.GetIDataReaderString(reader, "IDENTITY_CHECKSUM");
            }

            //caseIdentityRec.SchemeLinked.CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY");
            //caseIdentityRec.SchemeLinked.ExternalId = DBHelper.GetIDataReaderString(reader, "CONT_NO");
            //caseIdentityRec.SchemeLinked.Name = DBHelper.GetIDataReaderString(reader, "PLAN_NM");

            return caseIdentityRec;
        }

        private static void ChooseMode()
        {
            CaseIdentitySQL.Jira6845ModeOn = true;
            try
            {
                GetAllCaseIdentity();
    }
            catch(DbException ex)
            {
                CaseIdentitySQL.Jira6845ModeOn = false;
            }
        }
    }
}
