﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLGuestUser
    {
        //public static List<GuestUser> GetAllGuestUsers()
        //{
        //    string sql = GuestUserSQL.GetAllGuestUsersSql();

        //    var guestUsers = new List<GuestUser>();
        //    Database db = DatabaseFactory.CreateDatabase("UEXT");

        //    using (DbCommand cmd = db.GetSqlStringCommand(sql))
        //    using (IDataReader reader = db.ExecuteReader(cmd))
        //    {
        //        if (!reader.IsClosed)
        //        {
        //            while (reader.Read())
        //            {
        //                guestUsers.Add(MapToGuestUser(reader));
        //            }
        //        }
        //    }

        //    return guestUsers;
        //}

        public static List<GuestUser> GetGuestUsers(int? caseKey)
        {
            var guestUsers = new List<GuestUser>();

            if (caseKey.HasValue == false) return guestUsers;

            string sql = GuestUserSQL.GetGuestUsers(caseKey.Value);

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (DbCommand cmd = db.GetSqlStringCommand(sql))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        guestUsers.Add(MapToGuestUser(reader));
                    }
                }
            }

            return guestUsers;
        }

        public static GuestUser GetGuestUser(int id)
        {
            string sql = GuestUserSQL.GetGuestUserSql(id);
            Database db = DatabaseFactory.CreateDatabase("UEXT");
            using (DbCommand cmd = db.GetSqlStringCommand(sql))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    if (reader.Read())
                    {
                        return MapToGuestUser(reader);
                    }
                }
            }

            return null;
        }

        public static int Save(GuestUser guestUser)
        {
            string sql = string.Empty;

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            if (guestUser.GuestUserId > 0)
            {  
                string[] sqlMany1 = GuestUserSQL.UpdateGuestUserSql(guestUser).ToArray();

                sql = sqlMany1.IntoWellFormedSql();
            }
            else
            {
                //List<GuestUser> existingrecords = GetGuestUsers(guestUser.CaseKey);
                //if (existingrecords.Any(r => r.GuestUserName.ToLower().Equals(guestUser.GuestUserName.ToLower())))
                //{
                //    return "Record already exist.";
                //}

                guestUser.GuestUserId = SequenceGetter.GetNextVal(db, "MODELLER_USER_GENERIC_ID_SEQ");

                sql = GuestUserSQL.InsertGuestUserSql(guestUser.GuestUserName,
                                                      guestUser.CaseKey.Value,
                                                      guestUser.ModellerReference,
                                                      guestUser.GetSecurePassword(),
                                                      guestUser.GuestUserId);
            }


            using (DbCommand cmd = db.GetSqlStringCommand(sql))
            {
                return db.ExecuteNonQuery(cmd);
            }

        }

        public static int Delete(GuestUser model)
        {
            string sql = GuestUserSQL.DeleteGuestUserSql(model.GuestUserId);
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (DbCommand cmd = db.GetSqlStringCommand(sql))
            {
                return db.ExecuteNonQuery(cmd);
            }
        }

        private static GuestUser MapToGuestUser(IDataReader reader)
        {
            var benefitGroup = new MemberGroupThin(reader, new[] { "BENEFIT_MEMBER_GROUP_ID" , "BENEFIT_MEMBER_GROUP_NAME" });
            benefitGroup.Type = new RefCode(MemberGroupDomainCodes.BenefitMemberGroupType);
            if (benefitGroup.MbGpKey == null) benefitGroup = null;

            var investmentGroup = new MemberGroupThin(reader, new[] { "INVESTMENT_MEMBER_GROUP_ID", "INVESTMENT_MEMBER_GROUP_NAME" });

            investmentGroup.Type = new RefCode(MemberGroupDomainCodes.InvestmentMemberGroupType);
            if (investmentGroup.MbGpKey == null) investmentGroup = null;

            return new GuestUser
                {
                    GuestUserId = DBHelper.GetIDataReaderInt(reader, "MODELLER_USER_GENERIC_ID"),
                    GuestUserName = DBHelper.GetIDataReaderString(reader, "EMAILDATA"),
                    ModellerReference = DBHelper.GetIDataReaderString(reader, "MODELLER_REFERENCE"),
                    IsCustomModellerReference = Convert.ToBoolean(DBHelper.GetIDataReaderInt(reader, "CUSTOM_REFERENCE")),

                    CaseKey = DBHelper.GetIDataReaderInt(reader, "SCHEME_ID"),
                    //SchemeLinked = new Scheme(reader, true, new[] { "SCHEME_ID", "SCHEME_NUMBER", "SCHEME_NAME" }),
                    BenefitMemberGroup = benefitGroup,
                    InvestmentMemberGroup = investmentGroup
                };
        }
    }
}