﻿using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.BusinessLayer.DataAccess
{
    using DCorum.BusinessFoundation.Contractual;
    using TKey = Int32;
    using TParentKey = Int32;


    public class DLLetterOfAuthority : CrudActor<LetterOfAuthority, int, int>
    {
        internal protected DLLetterOfAuthority( LetterOfAuthoritySqlMaker sqlMaker1, IRemarksActor remarksVessel)
            :base( @reader => new LetterOfAuthority(reader), sqlMaker1)
        {
            RemarksVessel = remarksVessel;
            if (RemarksVessel == null) throw new ArgumentNullException(nameof(remarksVessel));
        }

        IRemarksActor RemarksVessel { get; }

        private int GetPrimaryId(LetterOfAuthority model)
        {
            return model?.LetterOfAuthorityId ?? 0;
        }

        public IEnumerable<IOutcomeItem> Save(LetterOfAuthority model)
        {
            if (ReferenceEquals(model, null)) RemarksVessel.RemarkNoItemSpecified = true;

            //Validate(model);

            if (RemarksVessel.IsEmpty)
            {
                bool insertModeOn = GetPrimaryId(model) == 0;

                if (insertModeOn)
                {
                    if (SelectDuplicates(model).Length > 0)
                    {
                        RemarksVessel.DuplicatesDetected = true;
                    }
                    else
                    {                        
                        Insert(model);
                    }
                }
                else
                {
                    TKey primaryId = GetPrimaryId(model);
                    //note: excluding itself from the candidates any other items infer an impending duplication of data.
                    if (SelectDuplicates(model).Any(_ => !Equals(GetPrimaryId(_), primaryId)))
                    {
                        RemarksVessel.DuplicatesDetected = true;
                    }
                    else
                    {
                        Update(model);
                    }
                }
            }

            return RemarksVessel.YieldAndPurgeAll();
        }
    }
}
