﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLWebUserInformation
    {
        internal DLWebUserInformation() {}
    
        public WebUserInformation Get(int nameId)
        {
            string sql1 = WebUserInformationSQL.GetWebUserInformationSql(nameId);
            var creation1 = DataAccessHelp.GetMany(sql1, @reader => new WebUserInformation(@reader)).FirstOrDefault();
            return creation1;
        }

        public int UnlockWebUserAccount(WebUserInformation webUser)
        {
            var sql = WebUserInformationSQL.UnlockWebUserAccountSql(webUser);
            int affectedTally = DataAccessHelp.SimpleExecuteNonQuery(sql);
            return affectedTally;
        }


        public int LockWebUserAccount(WebUserInformation webUser)
        {
            var sql = WebUserInformationSQL.LockWebUserAccountSql(webUser);
            int affectedTally = DataAccessHelp.SimpleExecuteNonQuery(sql);
            return affectedTally;
        }


        public int DeregisterWebUserAccount(WebUserInformation webUser)
        {
            var sql = WebUserInformationSQL.DeregisterWebUserAccountSql(webUser.NameId);
            int affectedTally = DataAccessHelp.SimpleExecuteNonQuery(sql);
            return affectedTally;
        }
    }


    public class DLTargetPlanAccountSetUp
    {
        internal DLTargetPlanAccountSetUp() {}


        public TPAccountSetUp[] GetNameIdAssociatedAccountSetups(int nameId, int? caseKey)
        {
            string sql1 = WebUserInformationSQL.GetAccountInfoForRegistrationSql(nameId, caseKey);

            var result = DataAccessHelp.GetMany(sql1, @reader => new TPAccountSetUp(@reader));

            return result;
        }

        public TPAccountSetUp[] GetEmailAssociatedAccountSetups(string email)
        {
            if (String.IsNullOrWhiteSpace(email)) return null;

            string sql1 = WebUserInformationSQL.GetAccountInfoForRegistrationSql(null, null, email);

            var result = DataAccessHelp.GetMany(sql1, @reader => new TPAccountSetUp(@reader));

            return result;
        }


        //public TPAccountSetUp GetAccountInfoForRegistration(int caseMemberKey)
        //{
        //    string sql1 = WebUserInformationSQL.GetAccountInfoForRegistrationSql(caseMemberKey);

        //    var result = DataAccessHelp.GetSingle(sql1, @reader => new TPAccountSetUp(@reader));

        //    Debug.Assert(result==null || result.CaseMemberKey == caseMemberKey);

        //    return result;
        //}


        //public int[] GetConflictingNameIds(int nameId)
        //{
        //    string sql1 = WebUserInformationSQL.GetUserAccountsThatShareEmailSql(nameId);

        //    int[] results = DataAccessHelp.GetMany(sql1, @reader => reader.FetchAsValue<int>("nameId"));

        //    return results;
        //}


        public int EnrollUserAccount(TPAccountSetUp accountInfoToSetUp)
        {
            List<DbParam> dbParams = WebUserInformationSQL.BuildAccountEnrollmentParams(accountInfoToSetUp);
            Dictionary<string, object> returnParams = DBHelper.ExecuteSPReaderNoResultset("UEXT.PDI.Enroll_Member_To_TargetPlan", dbParams);

            int result = returnParams.Count > 0 ? Convert.ToInt16(returnParams["o_Success"]) : 0;
            return result;
        }
    }

}
