﻿using System.Diagnostics;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    internal class DLTargetPlanAccount
    {
        internal DLTargetPlanAccount(TargetPlanAccountSQL sqlMaker)
        {
            _sqlMaker = sqlMaker;
            Debug.Assert(_sqlMaker != null);
        }

        private readonly TargetPlanAccountSQL _sqlMaker;


        public TargetPlanAccount[] GetTargetPlanEnabledAccounts(int nameId)
        {
            string sql1 = _sqlMaker.GetTargetPlanEnabledAccounts(nameId);

            var results = DataAccessHelp.GetMany(sql1, @reader => new TargetPlanAccount(@reader));
            return results;
        }
    }
}
