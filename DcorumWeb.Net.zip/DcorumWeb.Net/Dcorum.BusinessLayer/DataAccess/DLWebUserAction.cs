﻿using System;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLWebUserAction
    {
        public static WebUserAction[] GetWebUserActions(int userAccId, DateTime actiondate)
        {
            string sql1 = WebUserActionSQL.GetWebUserActions(userAccId, actiondate);
            var results = DataAccessHelp.GetMany(sql1, @reader => new WebUserAction(@reader));
            return results;
        }

        public static bool IsUserBelongToGroup(int userID)
        {
            var sql = $"SELECT User_Id from USERS_GROUPS UG INNER JOIN GROUPS G ON G.GROUP_ID = UG.GROUP_ID WHERE G.Name='Modeller Synch' AND User_Id={userID}";
            return DBHelper.ExecuteScalar<int>(sql) > 0 ;
        }
    }
}
