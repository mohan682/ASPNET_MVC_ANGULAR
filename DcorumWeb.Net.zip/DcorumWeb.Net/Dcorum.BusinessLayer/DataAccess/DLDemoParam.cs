﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.Practices;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLDemoParam : CrudActor<DemoParam, int ,int>
    {
        internal DLDemoParam(DemoParamSQL demoParamSql)
            :base(@reader => new DemoParam().SafeAction( @dp => Build(dp,@reader)),demoParamSql)
        {
            DemoParamSql = demoParamSql;
            if (DemoParamSql == null) throw new ArgumentNullException(nameof(demoParamSql));
        }

        private readonly DemoParamSQL DemoParamSql ;

  
        protected static void Build(DemoParam demoParam, IDataReader reader)
        {
            demoParam.DemoParamId = DBHelper.GetIDataReaderNullableInt(reader, "USER_ACC_DEMO_PARAM_ID");
            demoParam.DemoParamUserAccId = DBHelper.GetIDataReaderInt(reader, "USER_ACC_ID");
            demoParam.DemoParamCode = new RefCode(DBHelper.GetIDataReaderString(reader, "KEY"));
            demoParam.DemoParamValue = DBHelper.GetIDataReaderString(reader, "VALUE");
        }


        //#region ......optimizations......
        //protected override void PreInsert(DemoParam model, Database db)
        //{
        //    model.DemoParamId = SequenceGetter.GetNextVal(db, "User_Acc_Demo_Param_Id_Seq");
        //}
        //#endregion
    }
}
