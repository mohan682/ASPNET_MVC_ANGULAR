﻿using System.Data;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using System;

namespace Dcorum.BusinessLayer.DataAccess
{

    public class DlMemberGroup
    {
        internal DlMemberGroup(MemberGroupSql sqlMaker)
        {
            MemberGroupSql = sqlMaker;
            if (MemberGroupSql == null) throw new ArgumentNullException(nameof(sqlMaker));
        }

        private MemberGroupSql MemberGroupSql { get; }

        public static MemberGroupThin[] GetMemberGroupsByType(int caseKey, string groupTypeCode)
        {
            string sql1 = MemberGroupSql.GetMemberGroupbyTypeSql(caseKey, groupTypeCode);
            var results = DataAccessHelp.GetMany(sql1, @reader => new MemberGroupThin(@reader));
            return results;
        }

        public MemberGroupThin[] GetMemberGroupsByTypeAndInvAvailableTo(int caseKey, string grpTypeCode = null, string inAvailableTo = null)
        {
            string sql1 = MemberGroupSql.GetMemberGroupsByTypeAndInvAvailableTo(caseKey, grpTypeCode, inAvailableTo);
            var results = DataAccessHelp.GetMany(sql1, @reader => new MemberGroupThin(@reader));
            return results;
        }

        public static MemberGroup[] GetAllMemberGroups(int caseKey)
        {
            string sql1 = MemberGroupSql.GetMemberGroupsSql(caseKey);
            var results = DataAccessHelp.GetMany(sql1, @MapToManyMemberGroup);
            return results;
        }

        public static MemberGroupThin[] GetAllMemberGroups()
        {
            string sql1 = MemberGroupSql.GetMemberGroupsSql();
            var results = DataAccessHelp.GetMany(sql1, @reader => new MemberGroupThin(@reader));
            return results;
        }

        public MemberGroup GetMemberGroup(int memberGroupId)
        {
            string sql1 = MemberGroupSql.GetMemberGroupByIdSql(memberGroupId);
            var results = DataAccessHelp.GetSingle(sql1, @MapToSingleMemberGroup);
            return results;
        }


        private MemberGroup MapToSingleMemberGroup(IDataReader reader)
        {
            var creation1 = new MemberGroup();
            MemberGroup.BuildThin(creation1,reader);
            MemberGroup.BuildWhenNotThin(creation1,reader);
            MemberGroup.BuildWhenSingle(creation1,reader);
            return creation1;
        }


        private static MemberGroup MapToManyMemberGroup(IDataReader reader)
        {
            var creation1 = new MemberGroup();
            MemberGroup.BuildThin(creation1, reader);
            MemberGroup.BuildWhenNotThin(creation1, reader);
            return creation1;
        }


        public int UpdateMemberGroup(MemberGroup memberGroup)
        {
            string sql1 = MemberGroupSql.UpdateMemberGroupSQL(memberGroup);
            return DataAccessHelp.SimpleExecuteNonQuery(sql1);
        }

        public int InsertMemberGroup(MemberGroup memberGroup)
        {
            string sql1 = MemberGroupSql.InsertMemberGroupSQL(memberGroup);
            return DataAccessHelp.SimpleExecuteNonQuery(sql1);
        }
    }
}
