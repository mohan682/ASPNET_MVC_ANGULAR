﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLUnderlyingFundMix
    {
        private DbTransaction _sharedTransaction;

        internal void StartTransaction()
        {
            DbConnection conn = DatabaseFactory.CreateDatabase("UEXT").CreateConnection();
            conn.Open();
            _sharedTransaction = conn.BeginTransaction();
        }

        internal void CompleteTransaction(bool executeCommit)
        {
            if (_sharedTransaction != null && _sharedTransaction.Connection != null)
            {
                if (executeCommit) _sharedTransaction.Commit();
                else _sharedTransaction.Rollback();
            }
            if (_sharedTransaction.Connection != null) _sharedTransaction.Connection.Close();
        }

        internal static List<UnderlyingFundMixGroup> GetAllFundGroupsWithMixes()
        {
            return GetFundGroupsWithMixes(UnderlyingFundMixSQL.GetAllFundGroupsWithMixesSQL());
        }

        internal static UnderlyingFundMixGroup GetFundGroupsWithMixes(int fundGroupNumber)
        {
            return GetFundGroupsWithMixes(UnderlyingFundMixSQL.GetFundGroupsWithMixesSQL(fundGroupNumber)).FirstOrDefault();
        }

        internal static List<UnderlyingFundMix> GetUnderlyingFundMixes(int fundGroupNumber)
        {
            var underlyingInvestmentTypes = new List<UnderlyingFundMix>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(UnderlyingFundMixSQL.GetUnderlyingFundMixesSQL(fundGroupNumber)))
            using (IDataReader reader = db.ExecuteReader(cmd))
                Fill(underlyingInvestmentTypes, reader);

            return underlyingInvestmentTypes;
        }

        internal static UnderlyingFundMix GetUnderlyingFundMix(int fundMixId)
        {
            var uderlyingFundMixes = new List<UnderlyingFundMix>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(UnderlyingFundMixSQL.GetUnderlyingFundMixSQL(fundMixId)))
            using (IDataReader reader = db.ExecuteReader(cmd))
                Fill(uderlyingFundMixes, reader);

            return uderlyingFundMixes.FirstOrDefault(); ;
        }

        internal static UnderlyingFundMix GetUnderlyingFundMix(string fundGroup, string investmentTypeId)
        {
            var uderlyingFundMixes = new List<UnderlyingFundMix>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(UnderlyingFundMixSQL.GetUnderlyingFundMixSQL(fundGroup, investmentTypeId)))

            using (IDataReader reader = db.ExecuteReader(cmd))
                Fill(uderlyingFundMixes, reader);

            return uderlyingFundMixes.FirstOrDefault();
        }

        internal bool InsertUnderLyingFundMix(UnderlyingFundMix underlyingFundMix)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            underlyingFundMix.UnderLyingFundMixId = SequenceGetter.GetNextVal(db, "UNDERLYING_FUND_MIX_ID_SEQ");
            using (var cmd = db.GetSqlStringCommand(UnderlyingFundMixSQL.InsertUnderlyingFundMix(underlyingFundMix)))
                if (_sharedTransaction != null)
                    db.ExecuteNonQuery(cmd, _sharedTransaction);
                else
                    db.ExecuteNonQuery(cmd);

            return true;
        }

        internal bool UpdateUnderLyingFundMix(UnderlyingFundMix underlyingFundMix)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(UnderlyingFundMixSQL.UpdateUnderlyingFundMix(underlyingFundMix)))
                if (_sharedTransaction != null)
                    db.ExecuteNonQuery(cmd, _sharedTransaction);
                else
                    db.ExecuteNonQuery(cmd);

            return true;
        }

        internal bool DeleteUnderlyingInvestmentType(int underlyingFundMixId)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(UnderlyingFundMixSQL.DeleteUnderlyingFundMix(underlyingFundMixId)))
                if (_sharedTransaction != null)
                    db.ExecuteNonQuery(cmd, _sharedTransaction);
                else
                    db.ExecuteNonQuery(cmd);

            return true;
        }

        private static List<UnderlyingFundMixGroup> GetFundGroupsWithMixes(string sql)
        {
            var uderlyingFundMixes = new List<UnderlyingFundMixGroup>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(sql))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        uderlyingFundMixes.Add(new UnderlyingFundMixGroup
                        {
                            FundGroupNumber = DBHelper.GetIDataReaderInt(reader, "MKEY_FD_NUM"),
                            FundGroupName = DBHelper.GetIDataReaderString(reader, "EXT_FD_NM"),
                            FundGroupManager = DBHelper.GetIDataReaderString(reader, "ManagerName"),
                            TotalPercentage = DBHelper.GetIDataReaderDecimal(reader, "TOT_PCT"),
                            NoOfTPSchemesLinked = DBHelper.GetIDataReaderInt(reader, "NO_OF_TP_SCHEMES")
                        });
                    }
                }
            }

            return uderlyingFundMixes;
        }

        private static void Fill(List<UnderlyingFundMix> fundMixes, IDataReader reader)
        {
            if (!reader.IsClosed)
                while (reader.Read())
                {
                    UnderlyingFundMix fundMix = new UnderlyingFundMix();

                    fundMix.UnderLyingFundMixId = DBHelper.GetIDataReaderNullableInt(reader, "FUND_MIX_ID");
                    fundMix.InvestmentTypeId = DBHelper.GetIDataReaderString(reader, "INVESTMENT_TYPE_ID");
                    fundMix.InvestmentTypeName = DBHelper.GetIDataReaderString(reader, "INVESTMENT_TYPE");
                    fundMix.FundGroupNumber = DBHelper.GetIDataReaderString(reader, "FUND_GROUP_NUMBER");
                    fundMix.Percentage = DBHelper.GetIDataReaderNullableDecimal(reader, "PERCENTAGE");

                    fundMixes.Add(fundMix);
                }
        }
    }
}
