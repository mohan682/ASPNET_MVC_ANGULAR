﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    internal class DLMaintenanceMessage
    {
        internal static List<MaintenanceMessage> GetMaintenanceMessages(bool includingExpired, string dbDateFormatString)
        {
            var sql = MaintenanceMessageSQL.GetAllMaintenaneeMessagesSql(includingExpired, dbDateFormatString);

            var maintenanceMessages = new List<MaintenanceMessage>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(sql))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        maintenanceMessages.Add(MapToMaintenanceMessage(reader));
                    }
                }
            }

            return maintenanceMessages;
        }

        internal static MaintenanceMessage GetMaintenanceMessage(int id, string dbDateFormatString)
        {
            var sql = MaintenanceMessageSQL.GetMaintenanceMessageSql(id, dbDateFormatString);
            Database db = DatabaseFactory.CreateDatabase("UEXT");
            using (var cmd = db.GetSqlStringCommand(sql))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    if (reader.Read())
                    {
                        return MapToMaintenanceMessage(reader);
                    }
                }
            }
            return null;
        }

        internal static int Save(MaintenanceMessage message, string dbDateFormatString)
        {
            var sql = "";

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            if (message.Id > 0)
            {
                sql = MaintenanceMessageSQL.UpdateMaintenaceMessageSql(message.AccessLevelTypeId.RefCd,
                    message.EffectiveDateTime, message.Messsage, message.Permission.RefCd, Convert.ToInt32(message.RefCode),
                    message.ExpiryDateTime, message.Id, dbDateFormatString);
            }
            else
            {
                message.Id = SequenceGetter.GetNextVal(db, "ACCESS_LIMITED_ID_SEQ");

                sql = MaintenanceMessageSQL.InsertMaintenanceMessageSql(message.AccessLevelTypeId.RefCd,
                    message.EffectiveDateTime, message.Messsage, message.Permission.RefCd, Convert.ToInt32(message.RefCode),
                    message.ExpiryDateTime, dbDateFormatString, message.Id);

            }

            using (var cmd = db.GetSqlStringCommand(sql))
            {
                return db.ExecuteNonQuery(cmd);
            }
        }

        internal static int Delete(int id)
        {
            var sql = MaintenanceMessageSQL.DeleteSql(id);
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(sql))
                return db.ExecuteNonQuery(cmd);
        }

        internal static MaintenanceMessage MapToMaintenanceMessage(IDataReader reader)
        {
            MaintenanceMessage recordToReturn = new MaintenanceMessage();

            recordToReturn.Id = DBHelper.GetIDataReaderInt(reader, "ACCESS_LIMITED_ID");
            recordToReturn.AccessLevelTypeId = new RefCode( DBHelper.GetIDataReaderString(reader, "ACCESS_LEVEL"));
            recordToReturn.SchemeName = DBHelper.GetIDataReaderString(reader, "SchemeName");
            recordToReturn.SchemeExternalId = DBHelper.GetIDataReaderString(reader, "CONT_NO");
            recordToReturn.MbGpKey = DBHelper.GetIDataReaderNullableInt(reader, "MBGP_KEY");
            recordToReturn.MbgpName = DBHelper.GetIDataReaderString(reader, "GroupName");
            recordToReturn.Permission = new RefCode(DBHelper.GetIDataReaderInt(reader, "PERMISSION_ID").ToString());
            ////List<RefCode> refCodeTypes = RefCodeCache.RetrieveByDomainName(Constants.DomainNames.PDI_Maintenance_Message_Type);
            recordToReturn.Messsage = DBHelper.GetIDataReaderString(reader, "MESSAGE");
            recordToReturn.EffectiveDateTime = DBHelper.GetIDataReaderString(reader, "EFF_DT");
            recordToReturn.ExpiryDateTime = DBHelper.GetIDataReaderString(reader, "XPIR_DT");

            recordToReturn.RefCode = DBHelper.GetIDataReaderInt(reader, "REF").ToString();

            return recordToReturn;
        }
    }
}
