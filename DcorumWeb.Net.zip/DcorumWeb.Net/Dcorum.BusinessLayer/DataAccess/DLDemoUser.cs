﻿using System.Data;
using System.Diagnostics.Contracts;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using System;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLDemoUser : ICrudFull<DemoUser>
    {
        internal DLDemoUser(DemoUserSQL demoUserSql)
        {
            DbProxy = new DataAccessContext();

            DemoUserSQL = demoUserSql;
            if (DemoUserSQL == null) throw new ArgumentNullException(nameof(demoUserSql));
        }

        private readonly DemoUserSQL DemoUserSQL;
        private IDbProxy DbProxy { get; }

        protected DemoUser Make(IDataReader reader)
        {
            var demoUser = new DemoUser(reader);
            return demoUser;
        }



        public DemoUser[] SelectManyViaParentKey(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            var sql = DemoUserSQL.GetDemoUsers() ;
            var results = DbProxy.GetMany(sql, Make, () => new object[] { (parentKey == default(int)) ? (int?)null : parentKey, appendWhereClauseWith });
            return results ;
        }


        public DemoUser SelectViaPrimaryKey(int primaryKey)
        {
            var sql = DemoUserSQL.GetDemoUserByUserAccId(primaryKey);
            var result =  DbProxy.GetSingle(sql, Make, () => new object[] { primaryKey });
            return result;
        }

        public DemoUser[] SelectDuplicates(DemoUser user)
        {
            return DbProxy.GetMany(DemoUserSQL.GetPossibleDuplicates(user), Make);
        }



        public virtual int Update(DemoUser user)
        {
            return UpdateUser(user, user.PasswordModeOn);
        }

        protected int UpdateUser(DemoUser demoUser, bool includePasswordUpdate = false)
        {
            Contract.Assert(demoUser.NameId > 0);
            string sql = DemoUserSQL.Update(demoUser, includePasswordUpdate).IntoWellFormedSql();
            return DbProxy.ExecuteNonQuery(sql);
        }


        public int Insert(DemoUser demoUser)
        {

            demoUser.NameId = DbProxy.GetNextSequenceValue("COMPASS.PRTY_SEQ");
            demoUser.AccountId = DbProxy.GetNextSequenceValue("USER_ACC_ID_SEQ");

            SafeGuardSingleQuotesForDemoUser(demoUser);
            var sql = DemoUserSQL.Insert(demoUser);

            int retval = DbProxy.ExecuteNonQuery(sql);
            if (retval > 0)
            {
                retval += InsertUserAccDemo(demoUser);

                //if (retval > 1)
                //{
                //    var inserter = new DLDemoParam();
                //    retval += inserter.Insert(new DemoParam()
                //    {
                //        DemoParamUserAccId = demoUser.AccountId,
                //        DemoParamCode = RefCodeCache.RetrieveByRefCodeDescription(Constants.DomainNames.DemoParamKeys,"Product Value"),
                //        DemoParamValue = "20"
                //    });
                //}

            }

            return retval;
        }


        public bool DetectAnyDependants(DemoUser model)
        {
            return false;
        }



        public int Delete(DemoUser demoUser)
        {
            var sql = DemoUserSQL.Delete(demoUser).IntoWellFormedSql();
            return DbProxy.ExecuteNonQuery(sql);
        }


        private void SafeGuardSingleQuotesForDemoUser(DemoUser demoUser)
        {
            //if (demoUser.LongDescription != null) demoUser.LongDescription = demoUser.LongDescription.Replace("'", "''");
            CommonUserHelp.SafeGuardSingleQuotesForCommonUser(demoUser);
        }

        private int InsertUserAccDemo(DemoUser demoUser)
        {
            demoUser.UserAccDemoId = DbProxy.GetNextSequenceValue("User_Acc_Demo_Id_Seq");
            var sql = DemoUserSQL.InsertUserAccDemo(demoUser);
            return DbProxy.ExecuteNonQuery(sql);
        }
    }
}
