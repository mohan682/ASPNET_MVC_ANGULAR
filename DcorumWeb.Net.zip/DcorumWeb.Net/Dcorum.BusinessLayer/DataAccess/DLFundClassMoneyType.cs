﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;
using DCorum.BusinessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLFundClassMoneyType : CrudFullTemplate<FundClassMoneyType>
    {
        private static readonly FundClassMoneyTypeSQL fundClassMoneyTypeSql = new FundClassMoneyTypeSQL();

        protected override DCorum.BusinessFoundation.Contractual.ISqlFullCrud<FundClassMoneyType, int> CrudFullSql
        {
            get { return fundClassMoneyTypeSql; }
        }      

        public KeyValuePair<int,string>[] SelectMoneyTypes(int caseKey)
        {
            var moneyTypes = new List<KeyValuePair<int, string>>();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(fundClassMoneyTypeSql.SelectMoneyTypesSql(caseKey)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        var moneyType = new KeyValuePair<int, string>(DBHelper.GetIDataReaderInt(reader, "MNY_TYP_NUM"),
                            DBHelper.GetIDataReaderString(reader, "LONG_NM"));
                      
                        moneyTypes.Add(moneyType);
                    }
                }
            }

            return moneyTypes.ToArray();
        }

        protected override void Build(FundClassMoneyType fundClassMoneyType, IDataReader reader, bool? isCollectionModeOn = false)
        {
            fundClassMoneyType.FundClassMoneyTypeId = DBHelper.GetIDataReaderInt(reader, "CFCR_KEY");
            fundClassMoneyType.CaseKey = DBHelper.GetIDataReaderNullableInt(reader, "CASE_KEY");
            fundClassMoneyType.FundDescriptionId = DBHelper.GetIDataReaderString(reader, "FD_DESC_ID");
            fundClassMoneyType.FundShortName = DBHelper.GetIDataReaderString(reader, "SHRT_FD_NM");
            fundClassMoneyType.FundLongName = DBHelper.GetIDataReaderString(reader, "LONG_FD_NM");
            fundClassMoneyType.MoneyTypeNumber = DBHelper.GetIDataReaderInt(reader, "MNY_TYP_NUM");
            fundClassMoneyType.MoneyTypeName = DBHelper.GetIDataReaderString(reader, "LONG_NM");
        }
    }
}
