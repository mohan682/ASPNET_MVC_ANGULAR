﻿using System;
using System.Collections.Generic;
using System.Data;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLContentData
    {
        internal DLContentData(ContentDataSqlMaker sqlMaker, IDbProxy dbProxy)
        {
            _dataContext = dbProxy ;
            _sqlMaker = sqlMaker ;

            if (_dataContext == null) throw new ArgumentNullException(nameof(dbProxy));
            if (_sqlMaker == null) throw new ArgumentNullException(nameof(sqlMaker));
        }

        private IDbProxy _dataContext { get; }
        private ContentDataSqlMaker _sqlMaker { get; }


        public ContentData Fetch(int parentId)
        {
            string sql = _sqlMaker.FetchSql(parentId);

            var creation1 = _dataContext.GetSingle(sql, @reader => Create(@reader));

            return creation1;
        }


        private ContentData Create(IDataReader reader)
        {
            var creation1 = new ContentData(default(int));

            creation1.Id = DBHelper.GetIDataReaderInt(reader, "CONTENT_DATA_ID");
            creation1.ContentId = DBHelper.GetIDataReaderInt(reader, "CONTENT_ID");
            creation1.BinaryData = reader.FetchByteArray("BINARY_DATA");

            return creation1;
        }


        /// <summary>
        ///     Content is supplied as ContentData may be set to null for an update from image to text, for example.
        /// </summary>
        public void PersistContentData(Content content, int parentId, bool isInsert)
        {
            ContentData contentData = content.ContentData;

            if (contentData == null) return;

            Dictionary<string, byte[]> blobs = new Dictionary<string, byte[]>
            {
                {"BinaryData", contentData.BinaryData}
            };

            if (isInsert || contentData.Id <= 0)
            {
                contentData.ContentId = parentId;

                contentData.Id = _dataContext.GetNextSequenceValue("CONTENT_DATA_SEQ");

                string sql1 = _sqlMaker.InsertSql(contentData);
                _dataContext.ExecuteNonQuery(sql1, blobs);
            }
            else //update
            {
                if (contentData.ContentId != parentId) throw new ArgumentException("parentId");

                if (contentData.BinaryData == null)
                {
                    string sql1 = _sqlMaker.DeleteSql(contentData);

                    _dataContext.ExecuteNonQuery(sql1);

                    content.ContentData = null;
                }
                else
                {
                    string sql1 = _sqlMaker.UpdateSql(contentData);
                    _dataContext.ExecuteNonQuery(sql1, blobs);
                }
            }
        }

        //private void BuildCommand(DbCommand cmd, ContentData contentData)
        //{
        //    /*
        //    OracleParameter blobParameter = new OracleParameter();
        //    blobParameter.OracleType = OracleType.Blob;
        //    blobParameter.ParameterName = "BlobParameter";
        //    blobParameter.Value = blob;
        //    */

        //    var dbParam1 = (OracleParameter) cmd.CreateParameter();

        //    Debug.Assert(dbParam1 is OracleParameter);

        //    dbParam1.OracleType = OracleType.Blob;
        //    //dbParam1.DbType = DbType.Binary;
        //    dbParam1.ParameterName = "BinaryData";
        //    //dbParam1.Size = contentData.BinaryData.Length;
        //    dbParam1.Value = contentData.BinaryData;

        //    cmd.Parameters.Add(dbParam1);
        //}

    }


    public class ContentDataSqlMaker
    {
        internal ContentDataSqlMaker()
        {

        }

        public string InsertSql(ContentData contenData)
        {
            const string sqlTemplate = @"INSERT INTO UEXT.CONTENT_DATA (CONTENT_DATA_ID, CONTENT_ID, BINARY_DATA) 
                                        VALUES ( {0}, {1}, :BinaryData )";

            return string.Format(sqlTemplate, contenData.Id, contenData.ContentId);
        }

        public string UpdateSql(ContentData toUse)
        {
            const string sqlTemplate =
                @"UPDATE UEXT.CONTENT_DATA SET CONTENT_ID={1}, BINARY_DATA=:BinaryData Where CONTENT_DATA_ID = {0}";

            return string.Format(sqlTemplate, toUse.Id, toUse.ContentId);
        }

        public string FetchSql(int contentId)
        {
            const string sqlTemplate = @"SELECT * FROM UEXT.CONTENT_DATA WHERE CONTENT_ID = {0}";
            return string.Format(sqlTemplate, contentId);
        }

        public string DeleteSql(ContentData toUse)
        {
            const string sqlTemplate = @"DELETE FROM UEXT.CONTENT_DATA WHERE CONTENT_DATA_ID = {0}";
            return string.Format(sqlTemplate, toUse.Id);
        }
    }
}