﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities.MemberScramble;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.MemberScramble
{
    public class DLUploadedMemberEntry
    {

        private const string DatabaseName = "UEXT";
        
        internal static IList<Entities.MemberScramble.MemberWorker> SearchForAuthorizedFilesUsingCriteria(string searchCriteria)
        {
            if (string.IsNullOrEmpty(searchCriteria))
                throw new ArgumentException();

            IList<Entities.MemberScramble.MemberWorker> MemberEntries = new List<MemberWorker>();

            var db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (var dbCmd = db.GetSqlStringCommand(GetSearchSqlString(searchCriteria)))
            using (var reader = db.ExecuteReader(dbCmd))
            {
                if (reader.IsClosed)
                    return null;

                while (reader.Read())
                    MemberEntries.Add(Map(reader));
            }

            return MemberEntries;
        }
        
        #region Helper Methods



        private static string GetSearchSqlString(string searchCriteria)
        {
            var sqlString = new StringBuilder();

            sqlString.AppendLine("SELECT DISTINCT ");
            sqlString.AppendLine("P.NATLIDNO, C.CASE_MBR_KEY, C.CASE_KEY, P.FIRSTNAME, P.LASTNAME ");
            sqlString.AppendLine("FROM CASE_MEMBERS C ");
            sqlString.AppendLine("INNER JOIN PERSON P ");
            sqlString.AppendLine("ON P.NAMEID = C.NAMEID ");
            sqlString.AppendLine("INNER JOIN MEMBER_STATUSES M ");
            sqlString.AppendLine("ON C.CASE_MBR_KEY = M.CASE_MBR_KEY ");
            sqlString.AppendLine("INNER JOIN UEXT.V_SCHEME VS ");
            sqlString.AppendLine("ON VS.CASE_KEY = C.CASE_KEY ");
            sqlString.AppendLine("INNER JOIN PRODUCTS PRD ");
            sqlString.AppendLine("ON PRD.PROD_TYP_CD = VS.PROD_TYP_CD ");
            sqlString.AppendLine("INNER JOIN PROD_GRP_DETL GD ");
            sqlString.AppendLine("ON PRD.PROD_TYP_CD = GD.PROD_TYP_CD ");
            sqlString.AppendLine("INNER JOIN PROD_GRP GP ");
            sqlString.AppendLine("ON GP.PRGP_KEY = GD.PRGP_KEY ");
            sqlString.AppendLine("INNER JOIN MBR_DATES MD ");
            sqlString.AppendLine("ON C.CASE_MBR_KEY = MD.CASE_MBR_KEY ");
            sqlString.AppendLine("LEFT OUTER JOIN UEXT.AE_MILESTONE_DATES AED ");
            sqlString.AppendLine("ON AED.CASE_MBR_KEY = C.CASE_MBR_KEY  AND AED.EFF_DT<=SYSDATE AND NVL(AED.XPIR_DT,SYSDATE+1)>SYSDATE ");
            sqlString.AppendLine("WHERE 1 = 1 ");
            sqlString.AppendLine("AND TRUNC(M.EFF_DT) <= TRUNC(SYSDATE) ");
            sqlString.AppendLine("AND (TRUNC(M.XPIR_DT) > TRUNC(SYSDATE) OR M.XPIR_DT IS NULL) ");
            sqlString.AppendLine("AND M.REC_STAT_CD = '0' ");
            sqlString.AppendLine("AND M.MBR_STAT_CD IN (15,92,95,93) ");
            sqlString.AppendLine("AND M.MBR_STAT_CD != 97 ");
            sqlString.AppendLine("AND MD.MBR_DT <= SYSDATE - 180 ");
            sqlString.AppendLine("AND MD.DT_TYP_NUM = 1 ");
            sqlString.AppendLine("AND MD.REC_STAT_CD = 1 ");
            sqlString.AppendLine("AND VS.PROD_TYP_CD = PRD.PROD_TYP_CD ");
            sqlString.AppendLine("AND GP.PRGP_KEY IN (1,10) ");
            sqlString.AppendLine("AND ((SELECT COUNT(CASE_MBR_KEY) ");
            sqlString.AppendLine("FROM PARTYXREF, CASE_MEMBERS ");
            sqlString.AppendLine("WHERE PARTYXREF.NAMEID = ");
            sqlString.AppendLine("( ");
            sqlString.AppendLine("SELECT PARTYXREF.NAMEID ");
            sqlString.AppendLine("FROM PARTYXREF, CASE_MEMBERS ");
            sqlString.AppendLine("WHERE CASE_MEMBERS.CASE_MBR_KEY = C.CASE_MBR_KEY ");
            sqlString.AppendLine("AND CASE_MEMBERS.MBR_GEN_KEY = PARTYXREF.REFKEY ");
            sqlString.AppendLine("AND PARTYXREF.REFTYPE = 'PART' ");
            sqlString.AppendLine(") ");
            sqlString.AppendLine("AND PARTYXREF.REFTYPE = 'PART' ");
            sqlString.AppendLine("AND PARTYXREF.REFKEY = CASE_MEMBERS.MBR_GEN_KEY) = 1) ");
            sqlString.AppendLine("AND AED.AUTO_ENROLL_DATE IS NULL ");

            sqlString.AppendLine(searchCriteria);
         
            return sqlString.ToString();
        }


        private static MemberWorker Map(IDataReader reader)
        {
            var worker = new MemberWorker
            {
                NiNumber = DBHelper.GetIDataReaderString(reader, "NATLIDNO"),
                CaseMbrKey = DBHelper.GetIDataReaderInt(reader, "CASE_MBR_KEY"),
                CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY"),
                FirstName = DBHelper.GetIDataReaderString(reader, "FIRSTNAME"),
                LastName = DBHelper.GetIDataReaderString(reader, "LASTNAME"),
            };

            return worker;
        }

        #endregion

    }
}
