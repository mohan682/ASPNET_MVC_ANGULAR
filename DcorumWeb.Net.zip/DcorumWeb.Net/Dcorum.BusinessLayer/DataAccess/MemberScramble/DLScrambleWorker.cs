﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Text;
using Dcorum.BusinessLayer.Entities.MemberScramble;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.MemberScramble
{
    public class DLScrambleWorker
    {
        private const string CASE_MBR_KEY = "P_CASE_MBR_KEY";
        private const string PROCEDURE = "PKG_CORE_FUNC.MULTI_MEMBER_SCRAMBLE";
        
        private const string MULTI = "P_MULTI";
        private const string RETURN = "P_RETURN";
        private const string DatabaseName = "UEXT";

        public DLScrambleWorker() {}

        private static DbCommand CreateCommand(string procedure, int caseMbrKey)
        {
            var db = DatabaseFactory.CreateDatabase(DatabaseName);  
            DbCommand cmd = db.GetStoredProcCommand(procedure);
            db.AddInParameter(cmd, CASE_MBR_KEY, System.Data.DbType.Decimal, caseMbrKey);
            db.AddInParameter(cmd, MULTI, System.Data.DbType.String, "1");
            db.AddOutParameter(cmd, RETURN, System.Data.DbType.StringFixedLength, 2000);
            return cmd;
        }


        internal static IList<Entities.MemberScramble.ScrambleWorker> ExecuteScrambleProc(int caseMbrKey)
        {
            if(caseMbrKey <= 0)
                throw new ArgumentNullException("caseMbrKey");

            IList<Entities.MemberScramble.ScrambleWorker> MemberEntries = new List<ScrambleWorker>();
            
            DbCommand cmd;

            var db = DatabaseFactory.CreateDatabase(DatabaseName);

            using (cmd = CreateCommand(PROCEDURE, caseMbrKey))
            {
                db.ExecuteNonQuery(cmd);
                var retval = db.GetParameterValue(cmd, RETURN).ToString();

                MemberEntries.Add(Map(retval));
            }

            return MemberEntries;
        }

        #region Helper Methods

        private static ScrambleWorker Map(string returnmessage)
        {
            var worker = new ScrambleWorker
            {
                ScrambleMessage = returnmessage
            };

            return worker;
        }

        #endregion
    }
}