﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.RefCoding;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLContent
    {
        internal protected DLContent(ContentSQL sqlMaker, DLContentData partnerDAL, IDbProxy dbProxy )
        {
            ContentSQL = sqlMaker;
            _dataContext = dbProxy ;
            _contentDataAccess = partnerDAL;

            if (_dataContext == null) throw new ArgumentNullException(nameof(dbProxy));
            if (ContentSQL == null) throw new ArgumentNullException(nameof(sqlMaker));
        }


        private IDbProxy _dataContext { get; }
        private DLContentData _contentDataAccess { get; }
        private ContentSQL ContentSQL { get; }


        internal List<Content> GetContent(string sqlSubClause)
        {
            var sql = ContentSQL.GetContentSql(sqlSubClause);

            var creation1 = _dataContext.GetMany(sql, @CreateContent);

            foreach (var content in creation1)
            {
                RefCodeHelp.DoBuildRefCodes(content, true);
            }

            return creation1.ToList();
        }


        public Content GetContentById(int id)
        {
            var sql = ContentSQL.GetContentByIdSql(id);

            var creation1 = _dataContext.GetSingle(sql, @CreateContent);

            if (creation1 != null) creation1.ContentData = _contentDataAccess.Fetch(creation1.Id);

            return creation1;
        }


        public bool SaveContent(Content content)
        {
            bool isInsert = content.Id == 0;
            var sql = "";
 
            if(!content.SchemeId.HasValue && content.IOClientId.HasValue)
            {
                content.SchemeId = -Math.Abs(content.IOClientId.Value);
            }

            if (isInsert)
            {
                content.Id = _dataContext.GetNextSequenceValue("CONTENT_SEQ");

                //TODO: pass the Entity through.

                // Get next value
                sql = ContentSQL.InsertContentSql(content.Id,content.Approved, content.AuthUser, content.ComponentCode,
                    content.CreatedUser,
                    content.EffectiveDateTime, content.ExpiryDateTime,
                    content.MemberGroupId.HasValue ? content.MemberGroupId.Value : 0, Convert.ToInt32(content.Product),
                    content.Provider, content.Published,
                    content.SchemeId.HasValue ? content.SchemeId.Value : 0, content.Target, content.TypeCode,
                    content.Value, content.BaseId, content.Plan);
            }
            else
            {
                sql = ContentSQL.UpdateContentSql(content.Approved, content.AuthUser, content.ComponentCode,
                    content.Id, content.CreatedUser,
                    content.EffectiveDateTime, content.ExpiryDateTime, content.MemberGroupId.HasValue? content.MemberGroupId.Value: 0, Convert.ToInt32(content.Product),
                    content.Provider, content.Published,
                    content.SchemeId.HasValue? content.SchemeId.Value : 0, content.Target, content.TypeCode, content.Value, content.Plan);
            }

            // Ideally should be done as a transaction.
            int affected = _dataContext.ExecuteNonQuery(sql);
            _contentDataAccess.PersistContentData(content, content.Id, isInsert);

            return affected > 0;
        }


        private Content CreateContent(IDataReader reader)
        {
            return new Content(reader);
        }


        public bool DeletePendingContent(int id)
        {
            var sql = ContentSQL.DeletePendingContent(id);

            int affected = _dataContext.ExecuteNonQuery(sql);

            return affected == 1;
        }

        
        public bool ApproveContent(int contentId, string userName)
        {
            var sql = ContentSQL.ApproveContent(contentId, userName);

            int affected = _dataContext.ExecuteNonQuery(sql);

            return affected == 1;
        }      
    }
}
