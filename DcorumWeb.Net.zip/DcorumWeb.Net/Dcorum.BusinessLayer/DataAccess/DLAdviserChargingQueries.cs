﻿using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities.Extensions;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.BusinessLayer.DataAccess
{


    public class DLAdviserChargingQueries
    {
        internal protected DLAdviserChargingQueries( AdviserChargingQuerySql sqlMaker, IDbFetcherProxy dbAccessor ) 
        {
            SqlMaker1 = sqlMaker;
            if (SqlMaker1 == null) throw new ArgumentNullException(nameof(sqlMaker));

            DbAccessor1 = dbAccessor;
            if (DbAccessor1 == null) throw new ArgumentNullException(nameof(dbAccessor));
        }

        private AdviserChargingQuerySql SqlMaker1 { get; }
        private IDbFetcherProxy DbAccessor1 { get; }


        private Dictionary<string,object> MakeNameValueRow(IDataReader reader)
        {
            var row1 = Enumerable.Range(0, reader.FieldCount)
                 .ToDictionary(reader.GetName, i => (reader.GetValue(i))==DBNull.Value ? null : reader.GetValue(i), StringComparer.InvariantCultureIgnoreCase);
                 ;

            return row1;
        }

        public Dictionary<string, object>[] FetchMemberAgents(int caseMemberKey)
        {
            string sql1 = SqlMaker1.MainSelectSql(caseMemberKey).IntoWellFormedSql();
            return DbAccessor1.GetMany(sql1, @reader => MakeNameValueRow( @reader ), () => new object[] { caseMemberKey });
        }

        public Dictionary<string, object> FetchLoaHeaderDetail(int caseMemberKey, int agentKey)
        {
            string sql1 = SqlMaker1.LoaHeaderSelectSql(caseMemberKey, agentKey).IntoWellFormedSql();
            return DbAccessor1.GetSingle(sql1, @reader => MakeNameValueRow(@reader), () => new object[] { caseMemberKey, agentKey });
        }

        public LetterOfAuthority[] FetchLoaRows(int caseMemberKey, int agentKey)
        {
            string sql1 = SqlMaker1.LoaRowsSelectSql(caseMemberKey, agentKey).IntoWellFormedSql();
            return DbAccessor1.GetMany(sql1, @reader => new LetterOfAuthority(@reader), () => new object[] { caseMemberKey, agentKey });
        }

        public Dictionary<string, object>[] FetchMemberFees(int caseMemberKey)
        {
            string sql1 = SqlMaker1.FeesSelectSql(caseMemberKey).IntoWellFormedSql();
            return DbAccessor1.GetMany(sql1, @reader => MakeNameValueRow(@reader), () => new object[] { caseMemberKey });
        }

        public Dictionary<string, object>[] FetchMemberFees(int caseMemberKey, string[] validAdviserFeeCodes,bool includeExpiredFees)
        {
            string sql1 = SqlMaker1.FeesSelectSql(caseMemberKey, validAdviserFeeCodes, includeExpiredFees).IntoWellFormedSql();
            return DbAccessor1.GetMany(sql1, @reader => MakeNameValueRow(@reader), () => new object[] { caseMemberKey });
        }

    }
}
