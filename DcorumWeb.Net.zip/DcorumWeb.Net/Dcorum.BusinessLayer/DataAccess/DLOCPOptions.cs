﻿using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using System;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLOCPOptions : CrudActor<OCPOptions, int, int>
    {
        internal protected DLOCPOptions(OCPOptionsSQL ocpOptionsSql)
            :base( @reader => new OCPOptions(@reader), ocpOptionsSql)
        {
            OcpOptionsSql = ocpOptionsSql;
            if (OcpOptionsSql == null) throw new ArgumentNullException(nameof(ocpOptionsSql));
        }

        private OCPOptionsSQL OcpOptionsSql { get; }
    }


    //public class DLOCPOptionsReadOnly : CrudActor<OCPOptionsReadOnly,int, int>
    //{
    //    internal protected DLOCPOptionsReadOnly(OCPOptionsReadOnlySQL ocpOptionsSql)
    //        :base(@reader => new OCPOptionsReadOnly(@reader), ocpOptionsSql)
    //    {
    //        OcpOptionsSql = ocpOptionsSql;
    //        if (OcpOptionsSql == null) throw new ArgumentNullException(nameof(ocpOptionsSql)) ;
    //    }

    //    private OCPOptionsReadOnlySQL OcpOptionsSql { get; }
    //}

}



