﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    internal class TargetPlanAccountSQL
    {      
        public string GetTargetPlanEnabledAccounts(int nameId)
        {
            string sql = @"
                            SELECT
	                            VA.NameId, 
                                    VA.Account_No       USER_ACCOUNT_NUMBER,
                                    CD.Case_Key         SCHEME_ID,
                                    CD.Cont_No          SCHEME_NUMBER,
                                    CD.Plan_Nm          SCHEME_NAME,
                                    VA.Primary_Account  PRIMARY         
                            FROM
	                            V_Account			VA
	                            INNER	JOIN Case_Data		CD	ON VA.Case_Key=CD.Case_Key  
                            WHERE
	                            VA.NameId=" + nameId;

            return sql;
        }
    }
}
