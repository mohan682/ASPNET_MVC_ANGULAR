﻿using System;
using System.Collections.Generic;
using System.Text;
using Dcorum.BusinessLayer.Entities;
using DCorum.BusinessFoundation.Contractual;
namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class FundClassDetailSQL : ISqlFullCrud<FundClassDetail, int>
    {
        public IEnumerable<string> DetectAnyDependants(FundClassDetail ofInterest)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> DeleteSql(FundClassDetail toDelete)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> InsertSql(FundClassDetail toInsert)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> UpdateSql(FundClassDetail toUpdate)
        {
            string sql = @"UPDATE UEXT_CASE_FUND_RULES
                                SET IS_CORE={1},CHARGE_CODE='{2}' ,ACTIVE_CLASS='{3}',EFF_DT=TO_DATE('{4}','dd/mm/yyyy'),
                                XPIR_DT={5},GROWTH_RATE_LOW={6},GROWTH_RATE_MID={7} ,GROWTH_RATE_HIGH={8},GROWTH_RATE_SMPI={9}
                                WHERE UEXT_CASE_FUND_RULES_ID={0}";

            yield return string.Format(sql, toUpdate.FundClassDetailId, Convert.ToInt32(toUpdate.IsCoreFund), toUpdate.ChargeMetBy.RefCd,
                toUpdate.ActiveFundClass.RefCd, toUpdate.EffectiveDate.ToShortDateString(),
                toUpdate.ExpiryDate.HasValue ? string.Format("TO_DATE('{0}','dd/mm/yyyy')", toUpdate.ExpiryDate.Value.ToShortDateString()) : "NULL",
                toUpdate.GrowthRateLow.HasValue ? toUpdate.GrowthRateLow.Value.ToString() : "NULL",
                toUpdate.GrowthRateMid.HasValue ? toUpdate.GrowthRateMid.Value.ToString() : "NULL",
                toUpdate.GrowthRateHigh.HasValue ? toUpdate.GrowthRateHigh.Value.ToString() : "NULL",
                toUpdate.GrowthRateSMPI.HasValue ? toUpdate.GrowthRateSMPI.Value.ToString() : "NULL");
        }

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            const string sql = @"SELECT UCFR.UEXT_CASE_FUND_RULES_ID, UCFR.CASE_KEY, UCFR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,UCFR.IS_CORE, 
                                   UCFR.CHARGE_CODE,RC1.DESCRIPT CHARGE_CODE_DESCRIPTION,UFD.ANNUAL_MANAGEMENT_CHARGE,UFD.ADDITIONAL_CHARGE,
                                    UCFR.GROWTH_RATE_LOW,UCFR.GROWTH_RATE_MID ,UCFR.GROWTH_RATE_HIGH,UCFR.GROWTH_RATE_SMPI,
                                    UCFR.ACTIVE_CLASS,RC.DESCRIPT ACTIVE_CLASS_DESCRIPTION,UCFR.EFF_DT,UCD.ALLOW_INV_BY_MNY_TYP,UCFR.XPIR_DT
                                    FROM UEXT_CASE_FUND_RULES UCFR
                                    INNER JOIN UEXT_CASE_DATA UCD ON UCD.CASE_KEY=UCFR.CASE_KEY
                                    INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=UCFR.FD_DESC_ID                                   
                                    INNER JOIN UEXT_FUND_DESC UFD ON UFD.FD_DESC_ID=UCFR.FD_DESC_ID                                  
                                    INNER JOIN REF_CODES RC ON RC.REF_CD=UCFR.ACTIVE_CLASS AND RC.DOMAIN_NAME='UEXT ACTIVE FUND CLASS'
                                    INNER JOIN REF_CODES RC1 ON RC1.REF_CD=UCFR.CHARGE_CODE AND RC1.DOMAIN_NAME='UEXT FUND CHARGE MET BY'
                                    WHERE  UCFR.UEXT_CASE_FUND_RULES_ID={0}";

            yield return string.Format(sql, primaryKey);
        }

        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            return null;
//            const string sql = @"SELECT UCFR.UEXT_CASE_FUND_RULES_ID, UCFR.CASE_KEY, UCFR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,UCFR.IS_CORE, 
//                                    UCFR.CHARGE_CODE,RC1.DESCRIPT CHARGE_CODE_DESCRIPTION,UFD.ANNUAL_MANAGEMENT_CHARGE,
//                                    UCFR.GROWTH_RATE_LOW,UCFR.GROWTH_RATE_MID ,UCFR.GROWTH_RATE_HIGH,UCFR.GROWTH_RATE_SMPI,
//                                    UCFR.ACTIVE_CLASS,RC.DESCRIPT ACTIVE_CLASS_DESCRIPTION,UCFR.EFF_DT,UCD.ALLOW_INV_BY_MNY_TYP,UCFR.XPIR_DT
//                                    FROM UEXT_CASE_FUND_RULES UCFR
//                                    INNER JOIN UEXT_CASE_DATA UCD ON UCD.CASE_KEY=UCFR.CASE_KEY
//                                    INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=UCFR.FD_DESC_ID
//                                    INNER JOIN UEXT_FUND_DESC UFD ON UFD.FD_DESC_ID=UCFR.FD_DESC_ID                                   
//                                    INNER JOIN REF_CODES RC ON RC.REF_CD=UCFR.ACTIVE_CLASS AND RC.DOMAIN_NAME='UEXT ACTIVE FUND CLASS'
//                                    INNER JOIN REF_CODES RC1 ON RC1.REF_CD=UCFR.CHARGE_CODE AND RC1.DOMAIN_NAME='UEXT FUND CHARGE MET BY'
//                                    WHERE UCFR.EFF_DT <= SYSDATE AND UCFR.CASE_KEY={0}";

//            yield return string.Format(sql, parentKey);
        }

        public string SelectDuplicatesSql(FundClassDetail similar)
        {
            const string sql = @" SELECT UCFR.UEXT_CASE_FUND_RULES_ID, UCFR.CASE_KEY, UCFR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,UCFR.IS_CORE, 
                                    UCFR.CHARGE_CODE,RC1.DESCRIPT CHARGE_CODE_DESCRIPTION,UFD.ANNUAL_MANAGEMENT_CHARGE,UFD.ADDITIONAL_CHARGE,
                                    UCFR.GROWTH_RATE_LOW,UCFR.GROWTH_RATE_MID ,UCFR.GROWTH_RATE_HIGH,UCFR.GROWTH_RATE_SMPI,
                                    UCFR.ACTIVE_CLASS,RC.DESCRIPT ACTIVE_CLASS_DESCRIPTION,UCFR.EFF_DT,UCD.ALLOW_INV_BY_MNY_TYP,UCFR.XPIR_DT
                                    FROM UEXT_CASE_FUND_RULES UCFR
                                    INNER JOIN UEXT_CASE_DATA UCD ON UCD.CASE_KEY=UCFR.CASE_KEY
                                    INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=UCFR.FD_DESC_ID
                                    INNER JOIN UEXT_FUND_DESC UFD ON UFD.FD_DESC_ID=UCFR.FD_DESC_ID                                      
                                    INNER JOIN REF_CODES RC ON RC.REF_CD=UCFR.ACTIVE_CLASS AND RC.DOMAIN_NAME='UEXT ACTIVE FUND CLASS'
                                    INNER JOIN REF_CODES RC1 ON RC1.REF_CD=UCFR.CHARGE_CODE AND RC1.DOMAIN_NAME='UEXT FUND CHARGE MET BY'
                                    WHERE UCFR.EFF_DT <= SYSDATE AND (UCFR.XPIR_DT >= SYSDATE OR UCFR.XPIR_DT IS NULL) AND UCFR.CASE_KEY ={0} AND UCFR.FD_DESC_ID='{1}'";

            return string.Format(sql, similar.CaseKey, similar.FundDescriptionId);
        }

        internal string SelectSchemeAndMemberGroupSql(int caseKey)
        {
            return string.Format(@"SELECT * FROM (
                                    SELECT 1 IS_SCHEME,UCD.CASE_KEY KEY,CD.PLAN_NM NAME FROM
                                    UEXT_CASE_DATA UCD
                                    INNER JOIN CASE_DATA CD ON CD.CASE_KEY=UCD.CASE_KEY
                                    WHERE UCD.CASE_KEY={0} 
                                    UNION
                                    SELECT 0 IS_SCHEME,UMG.MBGP_KEY KEY,MG.DESCRIPT NAME FROM
                                    UEXT_MBR_GRP UMG
                                    INNER JOIN MBR_GRP MG ON MG.MBGP_KEY=UMG.MBGP_KEY
                                    WHERE UMG.CASE_KEY={0}
                                    ) ORDER BY 1 DESC,3 ASC",caseKey);

        }

        internal string SelectManySql(int caseKey, int? mbrGroupKey)
        {
            var sql = new StringBuilder();

            sql.AppendFormat(@" SELECT UCFR.UEXT_CASE_FUND_RULES_ID, UCFR.CASE_KEY, UCFR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,UCFR.IS_CORE, 
                                        UCFR.CHARGE_CODE,RC1.DESCRIPT CHARGE_CODE_DESCRIPTION,UFD.ANNUAL_MANAGEMENT_CHARGE,UFD.ADDITIONAL_CHARGE,
                                        UCFR.GROWTH_RATE_LOW,UCFR.GROWTH_RATE_MID ,UCFR.GROWTH_RATE_HIGH,UCFR.GROWTH_RATE_SMPI,
                                        UCFR.ACTIVE_CLASS,RC.DESCRIPT ACTIVE_CLASS_DESCRIPTION,UCFR.EFF_DT,UCD.ALLOW_INV_BY_MNY_TYP,UCFR.XPIR_DT
                                    FROM UEXT_CASE_FUND_RULES UCFR
                                    INNER JOIN UEXT_CASE_DATA UCD ON UCD.CASE_KEY=UCFR.CASE_KEY
                                    INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=UCFR.FD_DESC_ID
                                    INNER JOIN UEXT_FUND_DESC UFD ON UFD.FD_DESC_ID=UCFR.FD_DESC_ID                                   
                                    INNER JOIN REF_CODES RC ON RC.REF_CD=UCFR.ACTIVE_CLASS AND RC.DOMAIN_NAME='UEXT ACTIVE FUND CLASS'
                                    INNER JOIN REF_CODES RC1 ON RC1.REF_CD=UCFR.CHARGE_CODE AND RC1.DOMAIN_NAME='UEXT FUND CHARGE MET BY'
                                    WHERE  UCFR.CASE_KEY={0} 
                                    AND UCFR.FD_DESC_ID NOT IN 
                                    (
                                        -- To construct the set of barred funds, select all the relevant funds from FD_FNCL_RULES
                                        -- where the FD_DESC_ID is explicitly stated. Add to this list a list of all funds that belong
                                        -- to any relevant fund group (FD_FNCL_RULES can exclude by FD_DESC_ID, or FDGP_KEY - fund or group)
                                       
                                            SELECT FD_GRP_DETL.FD_DESC_ID
                                            FROM FD_FNCL_RULES, FD_GRP_DETL
                                            WHERE CASE_KEY = {0}--V_CASE_KEY
                                            AND MBGP_KEY = {1}
                                            AND FD_FNCL_RULES.FDGP_KEY = FD_GRP_DETL.FDGP_KEY
                                       
                                        UNION
                                      
                                            SELECT FD_DESC_ID
                                            FROM FD_FNCL_RULES
                                            WHERE CASE_KEY = {0} --V_CASE_KEY
                                            AND MBGP_KEY = {1}
                                            AND FD_DESC_ID IS NOT NULL                                       
                                    ) ORDER BY XPIR_DT DESC,FD_DESC_ID", caseKey, (mbrGroupKey.HasValue) ? mbrGroupKey.Value.ToString() : "NULL");

            return sql.ToString();
        }

        public string GetSequenceIdForInsert()
        {
            return null;
        }
    }
}
