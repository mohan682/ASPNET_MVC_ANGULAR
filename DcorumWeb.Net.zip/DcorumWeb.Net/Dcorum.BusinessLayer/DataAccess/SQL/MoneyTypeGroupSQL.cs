﻿using System.Diagnostics.Contracts;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class MoneyTypeGroupSQL
    {

        public static string GetCaseMoneyTypeGroupByKeySql(int caseMoneyTypeGroupkey)
        {

            string sql = @"SELECT 
                                CMTG.CMTGP_KEY,
                                MTG.MTGP_KEY,
                                CMTG.CASE_KEY,
                                uext.pdi.mny_typ_grp_descript(CMTG.CASE_KEY,MTG.MTGP_KEY) NAME
                            FROM CASE_MNY_TYP_GROUPS CMTG
                            INNER JOIN MNY_TYP_GRP MTG ON MTG.MTGP_KEY=CMTG.MTGP_KEY
                            WHERE CMTG.CMTGP_KEY={0}    
                        
                                UNION

                                SELECT DISTINCT  
                                    0,
                                    0,
                                    {0},
                                    uext.pdi.mny_typ_grp_descript({0},NULL) NAME
                                FROM dual ";

            return string.Format(sql, caseMoneyTypeGroupkey);
        }


        public static string GetMoneyTypeGroupByKeySql(int caseKey, int moneyTypeGroupkey)
        {
            string sql = string.Format(@"SELECT 
                                            CMTG.CMTGP_KEY,
                                            MTG.MTGP_KEY,
                                            CMTG.CASE_KEY,
                                            uext.pdi.mny_typ_grp_descript(CMTG.CASE_KEY,MTG.MTGP_KEY) NAME
                                        FROM CASE_MNY_TYP_GROUPS CMTG
                                        INNER JOIN MNY_TYP_GRP MTG ON MTG.MTGP_KEY=CMTG.MTGP_KEY
                                        WHERE CMTG.CASE_KEY={0} 
                                        AND CMTG.MTGP_KEY={1}   
                         
                                        UNION

                                        SELECT DISTINCT  
                                            0,
                                            0,
                                            {0},
                                            uext.pdi.mny_typ_grp_descript({0},{1}) NAME
                                        FROM dual", caseKey, moneyTypeGroupkey);

            return sql;
        }

        public static string GetMoneyTypeGroupByCaseSql(int caseKey)
        {
            const string sql = @"SELECT 
                                    CMTG.CMTGP_KEY,
                                    MTG.MTGP_KEY,
                                    CMTG.CASE_KEY,
                                    uext.pdi.mny_typ_grp_descript(CMTG.CASE_KEY,MTG.MTGP_KEY) NAME
                                FROM CASE_MNY_TYP_GROUPS CMTG
                                INNER JOIN MNY_TYP_GRP MTG ON MTG.MTGP_KEY=CMTG.MTGP_KEY 
                                WHERE CMTG.CASE_KEY={0}
                            
                                UNION

                                SELECT DISTINCT  
                                    0,
                                    0,
                                    {0},
                                    uext.pdi.mny_typ_grp_descript({0},NULL) NAME
                                FROM dual";

            return string.Format(sql, caseKey);
        }

        public static string AddMoneyTypeGroupForCaseSql(MoneyTypeGroup moneyTypeGroup)
        {
            Contract.Requires(moneyTypeGroup != null);
            Contract.Requires(moneyTypeGroup.CaseMoneyTypeGroupKey > 0);
            string sql = string.Empty;

            if (moneyTypeGroup != null)
            {
                sql = string.Format(@"  INSERT INTO CASE_MNY_TYP_GROUPS 
                                        (
                                            CMTGP_KEY,
                                            CASE_KEY,
                                            MTGP_KEY,
                                            DESCRIPT
                                        ) 
                                        VALUES 
                                        (
                                            {3},
                                            {0},
                                            {1},
                                            '{2}'
                                        )",
                                        moneyTypeGroup.CaseKey,
                                        moneyTypeGroup.MoneyTypeGroupKey,
                                        moneyTypeGroup.MoneyTypeGroupName,
                                        moneyTypeGroup.CaseMoneyTypeGroupKey);
            }

            return sql;
        }

        public static string UpdateMoneyTypeGroupForCaseSql(MoneyTypeGroup moneyTypeGroup)
        {
            string sql = string.Empty;

            sql = string.Format(@"  UPDATE CASE_MNY_TYP_GROUPS SET 
                                        DESCRIPT=CASE WHEN uext.pdi.mny_typ_grp_descript(CASE_KEY,MTGP_KEY) != '{1}' Then '{1}' ELSE '' END
                                    WHERE CMTGP_KEY={0}",
                                    moneyTypeGroup.CaseMoneyTypeGroupKey,
                                    moneyTypeGroup.MoneyTypeGroupName.PreventForSqlInjection());

            return sql;
        }

        public static string DeleteMoneyTypeGroupForCaseSql(int caseMoneyTypeGroupKey)
        {
            string sql = @" BEGIN
                                DELETE FROM CASE_MNY_TYP_GRP_DETL WHERE CMTGP_KEY={0};                                
                                DELETE FROM CASE_MNY_TYP_GROUPS WHERE CMTGP_KEY={0};  
                            END;";

            return string.Format(sql, caseMoneyTypeGroupKey);
        }

        public static string GetMoneyTypeGroupsForCaseByExcludingCurrMapps(int CaseKey)
        {
            const string sql = @"SELECT DISTINCT 
                                    MTG.MTGP_KEY,
                                    MTG.DESCRIPT NAME 
                                FROM MNY_TYP_GRP MTG                                  
                                WHERE MTG.MTGP_KEY NOT IN (SELECT DISTINCT MTGP_KEY FROM CASE_MNY_TYP_GROUPS WHERE CASE_KEY={0}) 
                                ORDER BY MTG.DESCRIPT";

            return string.Format(sql, CaseKey);
        }

        public static string IsExists(int caseKey, int moneyTypeGroupKey)
        {
            const string sql = @"SELECT 
                                    CASE WHEN COUNT(1)>0 THEN 1 ELSE 0 END CASE 
                                FROM CASE_MNY_TYP_GROUPS CMTG                                   
                                WHERE CMTG.CASE_KEY={0} 
                                AND CMTG.MTGP_KEY={1}";

            return string.Format(sql, caseKey, moneyTypeGroupKey);
        }

        /// <summary>
        /// Used for contribution Scale/Structure variations
        /// </summary>
        public static string SelectCaseMoneyTypeGroupsByCaseSql(int caseKey)
        {
            const string sql = @"SELECT 
                                    CMTG.CMTGP_KEY,
                                    CMTG.MTGP_KEY,
                                    CMTG.CASE_KEY,
                                    uext.pdi.mny_typ_grp_descript(CMTG.CASE_KEY,CMTG.MTGP_KEY) NAME
                                FROM CASE_MNY_TYP_GROUPS CMTG
                                WHERE CMTG.CASE_KEY={0}
                                
                                UNION
                                
                                SELECT DISTINCT  
                                    0,
                                    0,
                                    {0},
                                    uext.pdi.mny_typ_grp_descript({0},NULL) NAME              
                                FROM dual";

            return string.Format(sql, caseKey);
        }
    }
}
