﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class GuestUserSQL
    {
        public static string GetAllGuestUsersSql()
        {
            return string.Format(@"SELECT 
                                    MUG.MODELLER_USER_GENERIC_ID ,
                                    MUG.user_acc_id,
                                    ao.emaildata,
                                    uc.CHKN_SLT_HSH ,
                                    MUG.MODELLER_REFERENCE,
                                    CASE when REGEXP_INSTR(modeller_reference,'[0-9]+_[0-9]+_[0-9]')>0 then 0
                                    else 1 end CUSTOM_REFERENCE,

                                    CASE when ao.xpirdt < sysdate then 0 else 1 end ACTIVE,

                                    UCD.CASE_KEY  SCHEME_ID,
                                    UCD.CONT_NO  SCHEME_NUMBER,
                                    UCD.PLAN_NM  SCHEME_NAME,
                                    BMG.MBGP_KEY  BENEFIT_MEMBER_GROUP_ID,
                                    BMG.DESCRIPT  BENEFIT_MEMBER_GROUP_NAME,
                                    SMG.MBGP_KEY  INVESTMENT_MEMBER_GROUP_ID,
                                    SMG.DESCRIPT  INVESTMENT_MEMBER_GROUP_NAME
                                    FROM MODELLER_USER_GENERIC MUG
                                        INNER JOIN User_Acc uc on uc.User_Acc_Id=mug.User_Acc_Id
                                         INNER JOIN PartyXRef pxr on pxr.nameid=uc.nameid and pxr.reftype='COMM'
                                         INNER JOIN AddrOther ao on ao.addrid=pxr.RefKey 
                                        INNER JOIN VCASE_DATA UCD ON UCD.CASE_KEY=MUG.CASE_KEY    
    
                                         -- BENEFIT MEMBER GROUP   
                                        LEFT JOIN 
                                                (SELECT UMG.MBGP_KEY,MG.DESCRIPT, UMG.CASE_KEY 
                                                 FROM MBR_GRP MG
                                                 INNER JOIN UEXT_MBR_GRP UMG ON UMG.MBGP_KEY = MG.MBGP_KEY   
                                                 WHERE MG.GRP_TYP_CD = '12') BMG ON TO_CHAR(BMG.MBGP_KEY) = REGEXP_SUBSTR(MUG.MODELLER_REFERENCE,'[^_]+',1,2)
                                                  -- INVESTMENT MEMBER GROUP   
                                        LEFT JOIN   
                                                (SELECT UMG.MBGP_KEY,MG.DESCRIPT, UMG.CASE_KEY
                                                FROM MBR_GRP MG 
                                                INNER JOIN UEXT_MBR_GRP UMG ON UMG.MBGP_KEY = MG.MBGP_KEY  
                                                WHERE MG.GRP_TYP_CD = '15') SMG ON TO_CHAR(SMG.MBGP_KEY) = REGEXP_SUBSTR(MUG.MODELLER_REFERENCE,'[^_]+',1,3)                  
                                              ");

        }

        public static string GetGuestUsers(int caseKey)
        {
            return string.Format(@"
                                    SELECT DISTINCT
                                    MUG.MODELLER_USER_GENERIC_ID ,
                                    MUG.user_acc_id,
                                    ao.emaildata ,
                                    uc.CHKN_SLT_HSH ,
                                    MUG.MODELLER_REFERENCE,
                                    CASE when REGEXP_INSTR(modeller_reference,'[0-9]+_[0-9]+_[0-9]')>0 then 0
                                    else 1 end CUSTOM_REFERENCE,

                                    CASE when ao.xpirdt < sysdate then 0 else 1 end ACTIVE,

                                    UCD.CASE_KEY  SCHEME_ID,
                                    UCD.CONT_NO  SCHEME_NUMBER,
                                    UCD.PLAN_NM  SCHEME_NAME,
                                    BMG.MBGP_KEY  BENEFIT_MEMBER_GROUP_ID,
                                    BMG.DESCRIPT  BENEFIT_MEMBER_GROUP_NAME,
                                    SMG.MBGP_KEY  INVESTMENT_MEMBER_GROUP_ID,
                                    SMG.DESCRIPT  INVESTMENT_MEMBER_GROUP_NAME
                                    FROM MODELLER_USER_GENERIC MUG
                                        INNER JOIN User_Acc uc on uc.User_Acc_Id=mug.User_Acc_Id
                                         INNER JOIN PartyXRef pxr on pxr.nameid=uc.nameid and pxr.reftype='COMM'
                                         INNER JOIN AddrOther ao on ao.addrid=pxr.RefKey 
                                        INNER JOIN VCASE_DATA UCD ON UCD.CASE_KEY=MUG.CASE_KEY    
    
                                         -- BENEFIT MEMBER GROUP   
                                        LEFT JOIN 
                                                (SELECT UMG.MBGP_KEY,MG.DESCRIPT, UMG.CASE_KEY 
                                                 FROM MBR_GRP MG
                                                 INNER JOIN UEXT_MBR_GRP UMG ON UMG.MBGP_KEY = MG.MBGP_KEY   
                                                 WHERE MG.GRP_TYP_CD = '12') BMG ON TO_CHAR(BMG.MBGP_KEY) = REGEXP_SUBSTR(MUG.MODELLER_REFERENCE,'[^_]+',1,2)
                                                  -- INVESTMENT MEMBER GROUP   
                                        LEFT JOIN   
                                                (SELECT UMG.MBGP_KEY,MG.DESCRIPT, UMG.CASE_KEY
                                                FROM MBR_GRP MG 
                                                INNER JOIN UEXT_MBR_GRP UMG ON UMG.MBGP_KEY = MG.MBGP_KEY  
                                                WHERE MG.GRP_TYP_CD = '15') SMG ON TO_CHAR(SMG.MBGP_KEY) = REGEXP_SUBSTR(MUG.MODELLER_REFERENCE,'[^_]+',1,3)
            
                                                WHERE      MUG. CASE_KEY={0}", caseKey);

        }

        public static string GetGuestUserSql(int id)
        {
            const string sqlTemplate = @"  SELECT DISTINCT
                                    MUG.MODELLER_USER_GENERIC_ID ,
                                    MUG.user_acc_id,
                                    ao.emaildata ,
                                    uc.CHKN_SLT_HSH ,
                                    MUG.MODELLER_REFERENCE,
                                    CASE when REGEXP_INSTR(modeller_reference,'[0-9]+_[0-9]+_[0-9]')>0 then 0
                                    else 1 end CUSTOM_REFERENCE,

                                    CASE when ao.xpirdt <= sysdate or ao.xpirdt is null then 1 else 0 end ACTIVE,

                                    UCD.CASE_KEY  SCHEME_ID,
                                    UCD.CONT_NO  SCHEME_NUMBER,
                                    UCD.PLAN_NM  SCHEME_NAME,
                                    BMG.MBGP_KEY  BENEFIT_MEMBER_GROUP_ID,
                                    BMG.DESCRIPT  BENEFIT_MEMBER_GROUP_NAME,
                                    SMG.MBGP_KEY  INVESTMENT_MEMBER_GROUP_ID,
                                    SMG.DESCRIPT  INVESTMENT_MEMBER_GROUP_NAME
                                    FROM MODELLER_USER_GENERIC MUG
                                        INNER JOIN User_Acc uc on uc.User_Acc_Id=mug.User_Acc_Id
                                         INNER JOIN PartyXRef pxr on pxr.nameid=uc.nameid and pxr.reftype='COMM'
                                         INNER JOIN AddrOther ao on ao.addrid=pxr.RefKey 
                                        INNER JOIN VCASE_DATA UCD ON UCD.CASE_KEY=MUG.CASE_KEY    
    
                                         -- BENEFIT MEMBER GROUP   
                                        LEFT JOIN 
                                                (SELECT UMG.MBGP_KEY,MG.DESCRIPT, UMG.CASE_KEY 
                                                 FROM MBR_GRP MG
                                                 INNER JOIN UEXT_MBR_GRP UMG ON UMG.MBGP_KEY = MG.MBGP_KEY   
                                                 WHERE MG.GRP_TYP_CD = '12') BMG ON TO_CHAR(BMG.MBGP_KEY) = REGEXP_SUBSTR(MUG.MODELLER_REFERENCE,'[^_]+',1,2)
                                                  -- INVESTMENT MEMBER GROUP   
                                        LEFT JOIN   
                                                (SELECT UMG.MBGP_KEY,MG.DESCRIPT, UMG.CASE_KEY
                                                FROM MBR_GRP MG 
                                                INNER JOIN UEXT_MBR_GRP UMG ON UMG.MBGP_KEY = MG.MBGP_KEY  
                                                WHERE MG.GRP_TYP_CD = '15') SMG ON TO_CHAR(SMG.MBGP_KEY) = REGEXP_SUBSTR(MUG.MODELLER_REFERENCE,'[^_]+',1,3)
            
                                                WHERE MUG.MODELLER_USER_GENERIC_ID={0}  ";
            return string.Format(sqlTemplate, id);
        }

        public static IEnumerable<string> UpdateGuestUserSql(GuestUser model)
        {
            const string template1 = @"
UPDATE ADDROTHER
    SET EMAILDATA=LOWER({1})
    WHERE ADDRID=(
    SELECT DISTINCT X.REFKEY FROM MODELLER_USER_GENERIC MU
    INNER JOIN User_Acc UA on UA.USER_ACC_ID=MU.user_acc_id
    INNER JOIN PARTYXREF X ON X.NAMEID=UA.NAMEID 
    WHERE MU.MODELLER_USER_GENERIC_ID={0}
    )
";

            const string template2 = @"
UPDATE UEXT.MODELLER_USER_GENERIC
    SET                                                   
        MODELLER_REFERENCE = {2}
    where MODELLER_USER_GENERIC_ID={0}
";

            const string template3 = @"
UPDATE USER_ACC
    SET CHKN_SLT_HSH= {3}
WHERE
    USER_ACC_ID=(
    SELECT MUG.USER_ACC_ID FROM MODELLER_USER_GENERIC MUG WHERE MUG.MODELLER_USER_GENERIC_ID={0}
    );
";

            yield return String.Format(template1, model.GuestUserId, model.GuestUserName.SqlQuotify());
            yield return String.Format(template2, model.GuestUserId, null, model.ModellerReference.SqlQuotify());

            if (model.PasswordUpdateModeOn)
            {
                yield return String.Format(template3, model.GuestUserId, null, null, model.GetSecurePassword().SqlQuotify());
            }
        }


        public static string InsertGuestUserSql(string guestUserName, int scheme, string modellerReference, string password, int modlerUserGenericIdPrimaryKey)
        {
            const string sqlTemplate = @"DECLARE
                                            TYPE MbrAccount_SetupRec IS RECORD 
                                            (
                                                        AccNo        NUMBER(8) := NULL, 
                                                        NameId        NUMBER(8) := NULL, 
                                                        EmailAdd    VARCHAR2(50) := '',
														ModellerReference VARCHAR2(255):=NULL,
                                                        Scheme        NUMBER(4) := NULL,                                                       
                                                        PassWord    VARCHAR2(50) := ''
                                            );
                                            TYPE TimeTabTyp IS TABLE OF MbrAccount_SetupRec  INDEX BY BINARY_INTEGER;
                                                tLoginSetup    TimeTabTyp;
        
                                                lTotCount    NUMBER(3);
                                                lCounter    NUMBER(3);
                                                lOprnDtTm    DATE;
                                                lTempStr    VARCHAR2(50);
                                                lAccID      User_Acc.User_Acc_Id%Type; 
                                                lAddrOthId  AddrOther.AddrOtherId%Type;
        
                                                lLastRefKey    PartyXRef.RefKey%TYPE;
                                        BEGIN
                                            lOprnDtTm := SYSDATE;
        
                                            lTotCount := 0;        
                                                --lTotCount := lTotCount + 1;    tLoginSetup(lTotCount).Scheme := 2150; tLoginSetup(lTotCount).EmailAdd := 'guestSS@ss.com';
                                                --lTotCount := lTotCount + 1;    tLoginSetup(lTotCount).Scheme := 2150; tLoginSetup(lTotCount).EmailAdd := 'SSguest@ss.com';
        
                                               lTotCount := lTotCount + 1;   
	                                          tLoginSetup(lTotCount).Scheme := {1}; 
	                                          tLoginSetup(lTotCount).ModellerReference := '{2}'; 	                                         
	                                          tLoginSetup(lTotCount).PassWord := '{3}'; 
	                                          tLoginSetup(lTotCount).EmailAdd := '{0}';
        
                                            FOR lCounter IN 1..lTotCount LOOP
        
                                                lTempStr := SUBSTR(TRANSLATE(UPPER(SUBSTR(tLoginSetup(lCounter).EmailAdd, 1, INSTR(tLoginSetup(lCounter).EmailAdd, '.', 1))), 'BAEIOU.@-_', 'B'),1,20);
                                                BEGIN
                                                    SELECT X.NameId, O.AddrOtherId, U.User_Acc_Id INTO tLoginSetup(lCounter).NameId, lAddrOthId, lAccID
                                                    FROM                AddrOther    O,                PartyXRef    X,             User_Acc    U
                                                    WHERE
                                                        O.AddrId        = X.RefKey
                                                    AND    X.RefType        = 'COMM'
                                                    AND    X.NameId        = U.NameId(+)
                                                    AND    LOWER(O.EmailData)    = LOWER(tLoginSetup(lCounter).EmailAdd);
                                                    DBMS_OUTPUT.PUT ('Existing emailAddress ::  ');

                                                    DELETE FROM MODELLER_USER_GENERIC WHERE User_Acc_Id = NVL(lAccID, -100);                                                  
                                                    DELETE FROM User_Acc_Session WHERE User_Acc_Id = NVL(lAccID, -100);
                                                    DELETE FROM User_Acc WHERE User_Acc_Id = NVL(lAccID, -100);
                                                    DELETE FROM PERSONCOMPASS  WHERE NAMEID = tLoginSetup(lCounter).NameId;        
                                                    DELETE FROM PERSON  WHERE NAMEID = tLoginSetup(lCounter).NameId;            
                                                    DELETE FROM PartyXRef WHERE NameId = tLoginSetup(lCounter).NameId;
                                                    DELETE FROM Uext_AddrOther WHERE AddrOtherId = lAddrOthId;
                                                    DELETE FROM AddrOther WHERE AddrOtherId = lAddrOthId;
                                                EXCEPTION
                                                    WHEN NO_DATA_FOUND THEN
                                                        tLoginSetup(lCounter).NameId := COMPASS.PRTY_SEQ.NextVal;  

                                                        INSERT INTO Party (NameId,                       Client_Id,                    PartyType, EffectDt,      SearchKey) 
                                                        VALUES            (tLoginSetup(lCounter).NameId, tLoginSetup(lCounter).NameId, 'P',       lOprnDtTm - 1, lTempStr);
                                                    DBMS_OUTPUT.PUT ('New emailAddress ::  ');
                                                END;    
                          
                                                lLastRefKey := Addr_Seq.NextVal;
                                                INSERT INTO AddrOther (AddrOtherId,           EmailType, EmailData,                      AddrId,      EffectDt,      Last_Mod_Dt, Last_Mod_User)
                                                VALUES                (AddrOther_Seq.NextVal, '01',      tLoginSetup(lCounter).EmailAdd, lLastRefKey, lOprnDtTm - 1, lOprnDtTm,   'PDI-Script' );

                                                INSERT INTO PartyXRef (NameId, RefKey, RefType) VALUES (tLoginSetup(lCounter).NameId, lLastRefKey, 'COMM');
                
                                                INSERT INTO Uext_AddrOther (AddrOtherId, Primary, Contact) VALUES    (ADDROTHER_SEQ.CurrVal, 1, 1);

                                                INSERT INTO User_Acc    (User_Acc_Id,               Nameid,                          User_Type,   CHKN_SLT_HSH) VALUES 
                                                                        (User_Acc_Id_Seq.NextVal,   tLoginSetup(lCounter).NameId,    1,           tLoginSetup(lCounter).PassWord); 

                                                INSERT INTO PERSON ( NAMEID,                        CLIENT_ID,                    FIRSTNAME, LASTNAME,PASSPORT_NO)  VALUES 
                                                                    ( TLOGINSETUP(LCOUNTER).NAMEID, TLOGINSETUP(LCOUNTER).NAMEID,'Guest',    'GuestUser','GUEST');                    												

                                                INSERT INTO PERSONCOMPASS ( NAMEID,                      LANG_PREF_CD,MAR_STAT_CD)  VALUES 
                                                                          ( TLOGINSETUP(LCOUNTER).NAMEID, '1',           '9');

												INSERT INTO MODELLER_USER_GENERIC (MODELLER_USER_GENERIC_Id, User_Acc_Id, Case_Key,Modeller_Reference) VALUES ({4}, User_Acc_Id_Seq.CurrVal, tLoginSetup(lCounter).Scheme,tLoginSetup(lCounter).ModellerReference);
                                
                                                IF SQL%ROWCOUNT = 0 THEN
                                                    DBMS_OUTPUT.Put_Line('EmailAddress ' || tLoginSetup(lCounter).EmailAdd || '(' || lTempStr || ') - Unable to create Account record');
                                                ELSE
                                                    DBMS_OUTPUT.PUT_LINE('EmailAddress ' || tLoginSetup(lCounter).EmailAdd || '(' || lTempStr || ') - Login created');
                                                END IF;
                        
                                            END LOOP;                    
                                        END;";

            return string.Format(sqlTemplate, guestUserName, scheme, modellerReference, password, modlerUserGenericIdPrimaryKey);
        }
   
        public static string DeleteGuestUserSql(int id)
        {
            const string sqlTemplate = @"
                                        BEGIN
                                            UPDATE ADDROTHER
                                            SET XPIRDT=sysdate-1
                                            WHERE ADDRID=(
                                            SELECT DISTINCT X.REFKEY FROM MODELLER_USER_GENERIC MU
                                            INNER JOIN User_Acc UA on UA.USER_ACC_ID=MU.user_acc_id
                                            INNER JOIN PARTYXREF X ON X.NAMEID=UA.NAMEID 
                                            WHERE MU.MODELLER_USER_GENERIC_ID={0});

                                           DELETE MODELLER_USER_GENERIC MU WHERE MU.MODELLER_USER_GENERIC_ID={0};
                                           END;
                                         ";

            return string.Format(sqlTemplate, id);
        }
    }
}
