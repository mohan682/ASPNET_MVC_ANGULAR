﻿using System.Collections.Generic;
using Dcorum.BusinessLayer.Entities;
using DCorum.BusinessFoundation.Contractual;
namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class FundClassMoneyTypeSQL : ISqlFullCrud<FundClassMoneyType, int>
    {
        public IEnumerable<string> DetectAnyDependants(FundClassMoneyType ofInterest)
        {
            yield break;
        }

        public IEnumerable<string> DeleteSql(FundClassMoneyType toDelete)
        {
            yield return string.Format("DELETE FROM CASE_FUND_CONTRIB_RULES WHERE CFCR_KEY={0}", toDelete.FundClassMoneyTypeId);
        }

        public IEnumerable<string> InsertSql(FundClassMoneyType toInsert)
        {
            yield return string.Format(@"INSERT INTO CASE_FUND_CONTRIB_RULES (CFCR_KEY,CASE_KEY,FD_DESC_ID,MNY_TYP_NUM) 
                                                                    VALUES ( {3},{0},'{1}',{2} )", 
                                        toInsert.CaseKey.Value, toInsert.FundDescriptionId, toInsert.MoneyTypeNumber, toInsert.FundClassMoneyTypeId);
        }

        public IEnumerable<string> UpdateSql(FundClassMoneyType toUpdate)
        {
            yield return string.Format(@"UPDATE CASE_FUND_CONTRIB_RULES
                                            SET MNY_TYP_NUM = {1} WHERE CFCR_KEY={0}",
                                       toUpdate.FundClassMoneyTypeId, toUpdate.MoneyTypeNumber);
        }

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            yield return string.Format(@"SELECT DISTINCT CFCR.CFCR_KEY , CFCR.CASE_KEY,CFCR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,
                                            CFCR.MNY_TYP_NUM,NVL(CU.LONG_NM,'Default Money')LONG_NM
                                            FROM CASE_FUND_CONTRIB_RULES CFCR
                                            INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=CFCR.FD_DESC_ID
                                            LEFT JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_NO = CFCR.MNY_TYP_NUM AND CU.CASE_KEY=CFCR.CASE_KEY
                                            WHERE CFCR.CFCR_KEY={0}", primaryKey);

        }

//        public string SelectDefaultMoneyType(int caseKey,string fundDescriptionId)
//        {
//            return string.Format(@"SELECT -1 CFCR_KEY , UCFR.CASE_KEY,UCFR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,
//                                                    -1 MNY_TYP_NUM,'Default Money' LONG_NM
//                                                    FROM FUND_DESC FD 
//                                                    INNER JOIN UEXT_CASE_FUND_RULES UCFR ON UCFR.FD_DESC_ID=FD.FD_DESC_ID  
//                                                    WHERE UCFR.CASE_KEY={0} AND UCFR.FD_DESC_ID='{1}'", caseKey, fundDescriptionId);
//        }

        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {
//            yield return string.Format(@"SELECT DISTINCT CFCR.CFCR_KEY , CFCR.CASE_KEY,CFCR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,
//                                            CFCR.MNY_TYP_NUM,NVL(CU.LONG_NM,'Default Money') LONG_NM 
//                                            FROM CASE_FUND_CONTRIB_RULES CFCR
//                                            INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=CFCR.FD_DESC_ID
//                                            INNER JOIN UEXT_CASE_FUND_RULES UCFR ON UCFR.FD_DESC_ID=FD.FD_DESC_ID  AND UCFR.CASE_KEY=CFCR.CASE_KEY
//                                            LEFT JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_NO = CFCR.MNY_TYP_NUM AND CU.CASE_KEY=UCFR.CASE_KEY
//                                            WHERE UCFR.UEXT_CASE_FUND_RULES_ID={0}", parentKey);

            yield return
                string.Format(@"SELECT DISTINCT CFCR.CFCR_KEY , CFCR.CASE_KEY,CFCR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,
                                            CFCR.MNY_TYP_NUM,NVL(CU.LONG_NM,'Default Money')LONG_NM
                                            FROM CASE_FUND_CONTRIB_RULES CFCR
                                            INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=CFCR.FD_DESC_ID
                                            INNER JOIN UEXT_CASE_FUND_RULES UCFR ON UCFR.FD_DESC_ID=FD.FD_DESC_ID  AND UCFR.CASE_KEY=CFCR.CASE_KEY
                                            INNER JOIN CONTRIB_TYPES CT ON CT.MNY_TYP_NUM = CFCR.MNY_TYP_NUM
                                            LEFT JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_KEY = CT.MNY_TYP_KEY AND CU.CASE_KEY=CFCR.CASE_KEY
                                            WHERE UCFR.UEXT_CASE_FUND_RULES_ID={0}", parentKey);
        }

        public string SelectMoneyTypesSql(int caseKey)
        {
//            return string.Format(@"SELECT 0 MNY_TYP_NO,'Default Money' LONG_NM  FROM dual
//                                    UNION
//                                    SELECT DISTINCT MNY_TYP_NO,LONG_NM  FROM CONTRIB_USAGE 
//                                    WHERE CASE_KEY= {0} ORDER BY LONG_NM", caseKey);

            return string.Format(@"SELECT 0 MNY_TYP_NUM,'Default Money' LONG_NM  FROM dual
                                    UNION
                                    SELECT DISTINCT CT.MNY_TYP_NUM , CU.LONG_NM  FROM CONTRIB_USAGE CU
                                    INNER JOIN CONTRIB_TYPES CT ON  CU.MNY_TYP_KEY = CT.MNY_TYP_KEY
                                    WHERE CU.CASE_KEY= {0} ORDER BY LONG_NM", caseKey);
        }

//        public IEnumerable<string> SelectManySql(int caseKey,string fundDescriptionId)
//        {
//            yield return string.Format(@"SELECT DISTINCT CFCR.CFCR_KEY , CFCR.CASE_KEY,CFCR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,
//                                                CFCR.MNY_TYP_NUM,CU.LONG_NM 
//                                                FROM CASE_FUND_CONTRIB_RULES CFCR
//                                                INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=CFCR.FD_DESC_ID
//                                                INNER JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_NO = CFCR.MNY_TYP_NUM AND CU.CASE_KEY=CFCR.CASE_KEY
//                                                WHERE CFCR.CASE_KEY={0} AND CFCR.FD_DESC_ID='{1}'", caseKey, fundDescriptionId);
//        }

        public string SelectDuplicatesSql(FundClassMoneyType similar)
        {
            return string.Format(@"SELECT DISTINCT CFCR.CFCR_KEY , CFCR.CASE_KEY,CFCR.FD_DESC_ID,FD.SHRT_FD_NM,FD.LONG_FD_NM,
                                                CFCR.MNY_TYP_NUM,CU.LONG_NM 
                                                FROM CASE_FUND_CONTRIB_RULES CFCR
                                                INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=CFCR.FD_DESC_ID
                                                INNER JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_NO = CFCR.MNY_TYP_NUM AND CU.CASE_KEY=CFCR.CASE_KEY
                                                WHERE CFCR.CASE_KEY={0} AND CFCR.FD_DESC_ID='{1}' AND  CFCR.MNY_TYP_NUM={2}",
                                                      similar.CaseKey, similar.FundDescriptionId, similar.MoneyTypeNumber);
        }

        public string GetSequenceIdForInsert()
        {
            return "UEXT.CFCR_SEQ";
        }
    }
}
