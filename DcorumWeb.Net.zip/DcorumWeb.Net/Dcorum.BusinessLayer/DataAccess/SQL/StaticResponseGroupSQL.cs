﻿namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class StaticResponseGroupSQL
    {
        internal StaticResponseGroupSQL() { }

        private const string sql = @"   SELECT
                                        RG.Static_Response_Group_Id,
                                        RG.Code,
                                        RG.Short_Descript,
                                        RG.Descript
                                    FROM
                                        Static_Response_Group     RG";

        public string GetStaticResponseGroups()
        {
            return sql;
        }


        public string GetStaticResponseGroup(int primayKey)
        {

            return sql + " where RG.Static_Response_Group_Id = " + primayKey ;
        }
    }
}
