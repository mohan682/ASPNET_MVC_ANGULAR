﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class MoneyTypeSQL
    {
        public static string GetDefaultMoneyTypes(int caseKey, int mtgKey)
        {
            const string sql = @"SELECT DISTINCT NULL CMTGP_KEY,NULL CMTGP_DETL_KEY, CU.CASE_KEY,MTGD.MTGP_KEY,
                                    CT.MNY_TYP_KEY,CT.MNY_TYP_NUM,CT.SHRT_NM,CT.LONG_NM, FR.FDRT_KEY, 
                                    TCR.TR_CD,TCR.TR_CD_DESC,CT.LONG_NM || ' - ' || TCR.TR_CD_DESC DESCRIPT  
                                    FROM MNY_TYP_GRP MTG
                                    inner join MNY_TYP_GRP_DETL MTGD on MTGD.MTGP_KEY=MTG.MTGP_KEY
                                    INNER JOIN CONTRIB_TYPES CT ON CT.MNY_TYP_KEY = MTGD.MNY_TYP_KEY
                                    INNER JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_KEY = CT.MNY_TYP_KEY 
                                    INNER JOIN BEN_TYPES BT ON CU.CASE_KEY = BT.CASE_KEY
                                    INNER JOIN FD_RATES FR ON FR.MNY_TYP_NO = CU.MNY_TYP_NO AND FR.BNTP_KEY = BT.BNTP_KEY
                                    LEFT JOIN TR_CODE_RULES TCR ON FR.TR_CD = TCR.TR_CD  
                                    WHERE CU.CASE_KEY={0} 
                                    AND MTG.MTGP_KEY={1}
                                    AND CT.EFF_DT <= SYSDATE 
                                    ORDER BY CT.MNY_TYP_KEY";

            return string.Format(sql, caseKey, mtgKey);
        }

        public static string GetMoneyTypes(int cmtgKey)
        {
            const string sql = @"SELECT DISTINCT CMTGD.CMTGP_DETL_KEY,CMTGD.CMTGP_KEY,CMTG.CASE_KEY,CMTG.MTGP_KEY,CT.MNY_TYP_KEY,CT.MNY_TYP_NUM,CT.SHRT_NM,CT.LONG_NM, 
                                            TCR.TR_CD,TCR.TR_CD_DESC,CT.LONG_NM || ' - ' || TCR.TR_CD_DESC DESCRIPT 
                                            FROM  CASE_MNY_TYP_GROUPS CMTG
                                            INNER JOIN CASE_MNY_TYP_GRP_DETL CMTGD ON CMTG.CMTGP_KEY=CMTGD.CMTGP_KEY
                                            INNER JOIN CONTRIB_TYPES CT ON CT.MNY_TYP_NUM = CMTGD.MNY_TYP_NUM
                                             INNER JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_KEY = CT.MNY_TYP_KEY AND CU.CASE_KEY=CMTG.CASE_KEY
                                             INNER JOIN BEN_TYPES BT ON CU.CASE_KEY = BT.CASE_KEY
                                             LEFT JOIN TR_CODE_RULES TCR ON TCR.TR_CD = CMTGD.TR_CD 
                                            WHERE 
                                            CMTGD.CMTGP_KEY={0}
                                            AND CT.EFF_DT <= SYSDATE 
                                            ORDER BY CT.MNY_TYP_KEY";

            return string.Format(sql, cmtgKey);
        }

        public static string GetMoneyTypeByCMTGDKey(int caseMoneyTypeGroupDetailKey)
        {
            const string sql = @"SELECT DISTINCT CMTGD.CMTGP_DETL_KEY,CMTGD.CMTGP_KEY,CMTG.CASE_KEY,CMTG.MTGP_KEY,CT.MNY_TYP_KEY,CT.MNY_TYP_NUM,CT.SHRT_NM,CT.LONG_NM, 
                                            TCR.TR_CD,TCR.TR_CD_DESC,CT.LONG_NM || ' - ' || TCR.TR_CD_DESC DESCRIPT 
                                            FROM  CASE_MNY_TYP_GROUPS CMTG
                                            INNER JOIN CASE_MNY_TYP_GRP_DETL CMTGD ON CMTG.CMTGP_KEY=CMTGD.CMTGP_KEY
                                            INNER JOIN CONTRIB_TYPES CT ON CT.MNY_TYP_NUM = CMTGD.MNY_TYP_NUM
                                             INNER JOIN CONTRIB_USAGE CU ON CU.MNY_TYP_KEY = CT.MNY_TYP_KEY AND CU.CASE_KEY=CMTG.CASE_KEY
                                             INNER JOIN BEN_TYPES BT ON CU.CASE_KEY = BT.CASE_KEY
                                             LEFT JOIN TR_CODE_RULES TCR ON TCR.TR_CD = CMTGD.TR_CD 
                                            WHERE 
                                            CMTGD.CMTGP_DETL_KEY={0}
                                            AND CT.EFF_DT <= SYSDATE 
                                            ORDER BY CT.MNY_TYP_KEY";

            return string.Format(sql, caseMoneyTypeGroupDetailKey);
        }

        public static string AddMoneyType(MoneyType moneyType)
        {
            Contract.Requires(moneyType != null);
            Contract.Requires(moneyType.CaseMoneyTypeGroupDetailKey > 0);
            const string sql = @"INSERT INTO CASE_MNY_TYP_GRP_DETL (
                                       CMTGP_DETL_KEY, CMTGP_KEY, MNY_TYP_NUM, TR_CD) 
                                        VALUES ({3},{0},{1},{2} )";

            return string.Format(sql, moneyType.CaseMoneyTypeGroupKey, moneyType.MoneyTypeNumber, moneyType.TransactionRuleCode,moneyType.CaseMoneyTypeGroupDetailKey);
        }

        public static string DeleteMoneyType(int caseMoneyTypeGroupDetailKey)
        {
            const string sql = @"DELETE FROM CASE_MNY_TYP_GRP_DETL WHERE CMTGP_DETL_KEY={0}";
            return string.Format(sql, caseMoneyTypeGroupDetailKey);
        }

        public static string IsExists(MoneyType moneyType)
        {
            const string sql = @"SELECT CASE WHEN COUNT(1) >0 THEN 1 ELSE 0 END CASE FROM CASE_MNY_TYP_GRP_DETL CMTGD
                                    INNER JOIN CASE_MNY_TYP_GROUPS CMTG ON CMTG.CMTGP_KEY=CMTGD.CMTGP_KEY
                                    WHERE CMTG.CMTGP_KEY={0} AND CMTGD.MNY_TYP_NUM={1} AND CMTGD.TR_CD={2}";

            return string.Format(sql, moneyType.CaseMoneyTypeGroupKey, moneyType.MoneyTypeNumber, moneyType.TransactionRuleCode);
        }

        public static string UpdateMoneyType(MoneyType moneyType)
        {
            const string sql = @"
                                UPDATE  CASE_MNY_TYP_GRP_DETL
                                SET MNY_TYP_NUM={0},TR_CD={1}
                                WHERE CMTGP_DETL_KEY={2} ";

            return string.Format(sql, moneyType.MoneyTypeNumber, moneyType.TransactionRuleCode,moneyType.CaseMoneyTypeGroupDetailKey);   
        }
    }
}
