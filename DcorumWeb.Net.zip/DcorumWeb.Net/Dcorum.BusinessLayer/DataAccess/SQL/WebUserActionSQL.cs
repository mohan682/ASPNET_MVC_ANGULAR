﻿using System;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class WebUserActionSQL
    {
        internal static string GetWebUserActions(int userAccId, DateTime actionDate)
        {
//            string sql = @" SELECT DISTINCT 
//                                UA.USER_ACTION_ID,
//                                UA.ACTION_ID, 
//                                A.CODE ACTION_NAME,
//                                UA.ACCOUNT_NO, 
//                                UA.ACTION_DT,
//                                UA.SCREENRESOURCE_ID SCREEN_RESOURCE_ID, 
//                                SR.CODE SCREEN_RESOURCE_NAME,
//                                UA.USER_ACC_ID,
//                                CM.CASE_KEY SCHEME_ID,
//                                CD.CONT_NO SCHEME_NUMBER,
//                                CD.PLAN_NM SCHEME_NAME
//                                FROM UEXT.USER_ACTION UA
//                                INNER JOIN ACTION A ON A.ACTION_ID=UA.ACTION_ID
//                                INNER JOIN SCREEN_RESOURCE SR ON SR.SCREEN_RESOURCE_ID=UA.SCREENRESOURCE_ID
//                                INNER JOIN USER_ACC UACC ON UACC.USER_ACC_ID=UA.USER_ACC_ID
//                                INNER JOIN CASE_MEMBERS CM ON CM.NAMEID=UACC.NAMEID
//                                INNER JOIN CASE_DATA CD ON CD.CASE_KEY=CM.CASE_KEY
//                                WHERE UACC.NAMEID=" + nameId;

            string sql1 = @"
SELECT DISTINCT 
    UA.USER_ACTION_ID,
    UA.ACTION_ID, 
    A.CODE ACTION_NAME,
    A.DESCRIPTION ACTION_DESCRIPT,
    UA.ACCOUNT_NO, 
    UA.ACTION_DT,
    UA.SCREENRESOURCE_ID SCREEN_RESOURCE_ID, 
    SR.CODE SCREEN_RESOURCE_NAME,
    SR.DESCRIPTION SCREEN_RESOURCE_DESCRIPT,
    UA.USER_ACC_ID,
    CD.CASE_KEY SCHEME_ID,
    CD.CONT_NO SCHEME_NUMBER,
    CD.PLAN_NM SCHEME_NAME
FROM 
    UEXT.USER_ACTION UA
INNER JOIN ACTION A 
    ON A.ACTION_ID=UA.ACTION_ID
INNER JOIN SCREEN_RESOURCE SR
    ON SR.SCREEN_RESOURCE_ID=UA.SCREENRESOURCE_ID
INNER JOIN USER_ACC UACC
    ON UACC.USER_ACC_ID=UA.USER_ACC_ID
LEFT JOIN CASE_MEMBERS CM 
    ON CM.NAMEID=UACC.NAMEID
LEFT JOIN CASE_DATA CD
    ON CD.CASE_KEY=CM.CASE_KEY
WHERE 
    UA.USER_ACC_ID= {0}
";

            string result = String.Format(sql1, userAccId) +
                            ((actionDate == null)
                                ? null
                                : string.Format(" AND UA.ACTION_DT >= {0} ",
                                    actionDate.ToSqlShortDateString()
                                    ));

            return result;
        }
    }
}
