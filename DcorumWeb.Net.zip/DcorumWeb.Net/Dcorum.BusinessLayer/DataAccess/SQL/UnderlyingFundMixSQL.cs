﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class UnderlyingFundMixSQL
    {
        private const string FundGroupQuerySqlTemplate = @"
                    SELECT FG.MKEY_FD_NUM, FG.EXT_FD_NM, FG.NO_OF_TP_SCHEMES, MG.ManagerName, SUM(NVL(PCT,0)) TOT_PCT
                    FROM
	                        (
                                    SELECT
                                            VSF.MKEY_FD_NUM, VSF.EXT_FD_NM, COUNT(DISTINCT UCD.CASE_KEY) NO_OF_TP_SCHEMES
               	                    FROM	
                                    		(
                                    			SELECT
                                                	VFD.Mkey_Fd_Num, VFD.Ext_Fd_Nm, VFD.Fd_Desc_Id, CFR.Case_Key, VFD.FD_TYP_CD
                                                FROM
                                                	V_FUND_DESC			VFD,
                                                	CASE_FUND_RULES		CFR
                                                WHERE
                                                	VFD.FD_DESC_ID = CFR.FD_DESC_ID(+)
          										AND VFD.FD_TYP_CD in ('0','2')
                                            )	VSF
	                                        LEFT JOIN UEXT_FUND_DESC UFD ON UFD.FD_DESC_ID = VSF.FD_DESC_ID
                                            LEFT JOIN 
                                               (
                                                    select ucd.case_key, count(ucd.case_key) NO_OF_GRPS
                                                    from uext_case_data ucd
                                                    left join uext_mbr_grp umg on umg.case_key = ucd.case_key
                                                    where UCD.TARGET_PLAN_ENABLED = 1
                                                    group by ucd.case_key

                                               ) UCD ON VSF.Case_Key = UCD.Case_Key and UCD.NO_OF_GRPS > 0
                                    WHERE 
                                        (VSF.FD_TYP_CD = 2 OR UFD.LIFEPATH_FUND != 1 OR UFD.LIFEPATH_PHASE != 'GLIDE')
                                    {0}
                                    GROUP BY VSF.MKEY_FD_NUM, VSF.EXT_FD_NM 
                            )	FG
                            LEFT OUTER JOIN Underlying_Fund_mix	FM ON FG.MKEY_FD_NUM = FM.MKEY_FD_NUM
                            LEFT OUTER JOIN
	                        (
                                    SELECT FD.MKEY_FD_NUM, IM.DESCRIPT ManagerName, COUNT(1) NoOfFunds
                                    FROM
                                            Fund_Desc	FD,
                                            FD_Invest_Mgrs	FM,
                                            Invest_Managers	IM,
                                            (
                                                SELECT iFD.MKEY_FD_NUM, MAX(NVL(iIM.Eff_Dt, TRUNC(SYSDATE + 1))) EffDt
                                                FROM
                                                    Fund_Desc	iFD,
                                                    FD_Invest_Mgrs	iIM
                                                WHERE
                                                    iFD.FD_DESC_ID	= iIM.FD_DESC_ID
                                                GROUP BY iFD.MKEY_FD_NUM
                                            )		DT
                                    WHERE
	                                    FD.FD_DESC_ID	= FM.FD_DESC_ID
                                    AND	FM.INMG_KEY	= IM.INMG_KEY
                                    AND	FD.MKEY_FD_NUM	= DT.MKEY_FD_NUM
                                    AND	FM.EFF_DT	= DT.EffDt
                                    GROUP BY FD.MKEY_FD_NUM, IM.DESCRIPT
                            )	MG   ON FG.MKEY_FD_NUM = MG.MKEY_FD_NUM
                    GROUP BY FG.MKEY_FD_NUM, FG.EXT_FD_NM, FG.NO_OF_TP_SCHEMES, MG.ManagerName
                    ORDER BY 5 DESC, 2";

        public static string GetAllFundGroupsWithMixesSQL()
        {
            return string.Format(FundGroupQuerySqlTemplate, "");
        }

        public static string GetFundGroupsWithMixesSQL(int fundGroup)
        {
            return string.Format(FundGroupQuerySqlTemplate, String.Format("AND     VSF.MKEY_FD_NUM = {0}", fundGroup));
        }

        internal static string GetUnderlyingFundMixesSQL(int fundGroupNumber)
        {
            const string sqlTemplate = @"
                                        SELECT
                                                UFM.Underlying_Fund_Mix_Id	FUND_MIX_ID, 
	                                            RC.Ref_Cd			        INVESTMENT_TYPE_ID, 
                                                RC.Long_Desc			    INVESTMENT_TYPE, 
                                                UFM.Mkey_Fd_Num			    FUND_GROUP_NUMBER, 
                                                UFM.Pct				        PERCENTAGE
                                        FROM 
	                                            REF_CODES RC
                                                LEFT JOIN UNDERLYING_FUND_MIX UFM ON RC.REF_CD = UFM.ASSET_CODE AND UFM.Mkey_Fd_Num = {0}
                                        WHERE
	                                            RC.Domain_Name = 'FND UNDRLY ASSET CLS' AND RC.Disable_Cd = '0'
                                        ORDER BY 3";

            return string.Format(sqlTemplate,fundGroupNumber);
        }

        internal static string GetUnderlyingFundMixSQL(int underlyingFundMixId)
        {
            const string sqlTemplate = @"                                             
                                        SELECT
                                                UFM.Underlying_Fund_Mix_Id	FUND_MIX_ID, 
	                                            UFM.Asset_Code			    INVESTMENT_TYPE_ID, 
                                                RC.Long_Desc			    INVESTMENT_TYPE, 
                                                UFM.Mkey_Fd_Num			    FUND_GROUP_NUMBER, 
                                                UFM.Pct				        PERCENTAGE
                                        FROM 
	                                            UNDERLYING_FUND_MIX UFM 
                                                LEFT JOIN REF_CODES RC ON UFM.ASSET_CODE = RC.REF_CD
                                        WHERE
	                                            RC.Domain_Name = 'FND UNDRLY ASSET CLS'
                                        AND     UFM.Underlying_Fund_Mix_Id = {0}";

            return string.Format(sqlTemplate, underlyingFundMixId);
        }

        internal static string GetUnderlyingFundMixSQL(string fundGroupNumber, string investmentTypeId)
        {
            const string sqlTemplate = @"                                             
                                        SELECT
                                                UFM.Underlying_Fund_Mix_Id	FUND_MIX_ID, 
	                                            UFM.Asset_Code			    INVESTMENT_TYPE_ID, 
                                                RC.Long_Desc			    INVESTMENT_TYPE, 
                                                UFM.Mkey_Fd_Num			    FUND_GROUP_NUMBER, 
                                                UFM.Pct				        PERCENTAGE
                                        FROM 
	                                            UNDERLYING_FUND_MIX UFM
                                                LEFT JOIN REF_CODES RC ON UFM.ASSET_CODE = RC.REF_CD
                                        WHERE
	                                            RC.Domain_Name = 'FND UNDRLY ASSET CLS'
                                        AND     UFM.Mkey_Fd_Num = {0} AND UFM.ASSET_CODE= '{1}' ";

            return string.Format(sqlTemplate, fundGroupNumber, investmentTypeId);
        }

        internal static string InsertUnderlyingFundMix(UnderlyingFundMix underlyingFundMix)
        {
            const string sqlTemplate = @"INSERT INTO UEXT.UNDERLYING_FUND_MIX 
                                            ( UNDERLYING_FUND_MIX_ID,MKEY_FD_NUM,ASSET_CODE,PCT)
                                            VALUES ( {0},{1},{2},{3} ) ";

            return string.Format(sqlTemplate, underlyingFundMix.UnderLyingFundMixId, underlyingFundMix.FundGroupNumber,
                underlyingFundMix.InvestmentTypeId, underlyingFundMix.Percentage);
        }

        internal static string UpdateUnderlyingFundMix(UnderlyingFundMix underlyingFundMix)
        {
            const string sqlTemplate = @"UPDATE UEXT.UNDERLYING_FUND_MIX
                                            SET PCT = {0}
                                            WHERE  UNDERLYING_FUND_MIX_ID = {1} ";

            return string.Format(sqlTemplate, underlyingFundMix.Percentage, underlyingFundMix.UnderLyingFundMixId);
        }

        internal static string DeleteUnderlyingFundMix(int underlyingFundMixId)
        {
            const string sqlTemplate = @"DELETE UEXT.UNDERLYING_FUND_MIX                                          
                                            WHERE  UNDERLYING_FUND_MIX_ID = {0} ";

            return string.Format(sqlTemplate, underlyingFundMixId);
        }
    }
}
