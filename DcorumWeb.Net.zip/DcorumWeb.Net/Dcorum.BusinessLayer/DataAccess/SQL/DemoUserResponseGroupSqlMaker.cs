﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    using ModelAlias = Entities.DemoUserResponseGroup;

    internal class DemoUserResponseGroupSqlMaker : SimpleSqlFullCrud<ModelAlias, int, int>
    {
        public DemoUserResponseGroupSqlMaker(ISqlSpecification<ModelAlias> sqlSpec = null)
            : base(sqlSpec ?? SqlSpec)
        {
        }

        public static IEnumerable<string> ColumnNames
        {
            get { return _columnNames; }
        }

        private static readonly ReadOnlyCollection<string> _columnNames = Array.AsReadOnly(new[]
        {   "Demo_User_Resp_Group_ID"
        ,   "User_Acc_Demo_ID"
        ,   "Static_Response_Group_Id"
        ,   "Is_Primary"
        ,   "Is_Deccum"
        ,   "Acc_Status"
        });

        private static readonly ISqlSpecification<ModelAlias> SqlSpec =
            new SqlSpecification<ModelAlias>
            {
                TableName = "demo_user_Resp_group",
                ColumnNames = _columnNames.ToArray(),

                MyIdentityIndexes = new[] {new[] {0}, new[] {1, 2}},
                UpdatableIndexes = new int[] {2, 3, 4, 5},

                ParentKeyIndex = 1,
                SqlSequenceName = "demo_user_resp_group_id_seq",

                AugmentSqlSelectFields = ", j1.primaryTotal, j1.decumTotal",

                AugmentSqlSelectJoins = @"
inner join 
(
select user_acc_demo_id user_acc_demo_id2, sum(is_primary) primaryTotal, sum(is_deccum) decumTotal
from demo_user_Resp_group 
group by user_acc_demo_id
) j1

on j1.user_acc_demo_id2 = from1.user_acc_demo_id
",

                //OrderByIndexes = new[] {2},

                GettersForSql = new Func<ModelAlias, object>[]
                {
                    _ => _.MyId,
                    _ => _.UserAccDemoId,
                    _ => _.StaticResponseGroupId,
                    _ => _.IsPrimary.IntoSqlBool(),
                    _ => _.IsDecum.IntoSqlBool(),
                    _ => _.AccStatus.IntoSqlValue()
                }
            };


        public override string SelectDuplicatesSql(ModelAlias similar)
        {
            var result = base.SelectDuplicatesSql(similar);
            return result;
        }

        /// <summary>
        /// Special sql for a new item to enable the boolean checkboxes to be correctly disabled depending on model associates.
        /// </summary>
        public string GetSelectNewSql(int demoUserId)
        {
            string template1 = @"SELECT 
    0 Demo_User_Resp_Group_ID, j1.user_acc_demo_id, 0 Static_Response_Group_Id, 
    0 Is_Primary, 0 Is_Deccum, null Acc_Status,
    j1.primaryTotal, j1.decumTotal FROM dual from1 
inner join 
(
select user_acc_demo_id user_acc_demo_id, sum(is_primary) primaryTotal, sum(is_deccum) decumTotal
from demo_user_Resp_group 
WHERE User_Acc_Demo_ID = {0}
group by user_acc_demo_id
) j1

on j1.user_acc_demo_id = {0}
";
            string result = String.Format(template1, demoUserId);
            return result;

        }
    }
}
