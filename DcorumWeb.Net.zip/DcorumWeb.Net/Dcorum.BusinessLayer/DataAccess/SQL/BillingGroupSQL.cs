﻿using Dcorum.BusinessLayer.Entities;
using System.Text;
using System;
using DCorum.BusinessFoundation.Contractual;
using System.Collections.Generic;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class BillingGroupSQL : ISqlFullCrud<BillingGroup, int>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected BillingGroupSQL()
        {
        }

        public IEnumerable<string> DeleteSql(BillingGroup toDelete)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> InsertSql(BillingGroup toInsert)
        {
            throw new NotImplementedException();
        }      

        public IEnumerable<string> UpdateSql(BillingGroup toUpdate)
        {
            string billDueDay = toUpdate.BillDueDay.IntoIntN().ToString() ?? "15";
            string applyOpraChecks = (toUpdate.ApplyOPRAChecks) ? "'1'" : "'0'";
            string activeLeaverBillGroup = (toUpdate.ActiveLeaverBillingGroup) ? "1" : "0";
            string ocpEnabled = (toUpdate.OCPEnabled) ? "'Y'" : "'N'";
            string ddEnabled = (toUpdate.DDPaymentEnabled) ? "'Y'" : "'N'";
            string workplaceISAEnabled = (toUpdate.WorkplaceISAEnabled) ? "'Y'" : "'N'";

            string sql = string.Format(@"update UEXT_BILL_GRP UBG
                            set UBG.BILL_DUE_DAY = {0},
                            UBG.OPRA_APPLIES = {1},
                            UBG.FREQUENCY = {2},
                            UBG.ACTIVE_LEAVER_BILLGRP = {3},
                            UBG.ABP_ENABLED = {4},
                            UBG.ABP_CHECK_CONTRIBUTIONS = {5},
                            UBG.ABP_DIRECT_DEBIT_ENABLED = {6},
                            UBG.ABP_WORKPLACE_ISA_ENABLED = {7}
                            where BGRP_KEY = {8} ", billDueDay, applyOpraChecks, toUpdate.Frequency.SqlQuotify(), activeLeaverBillGroup, ocpEnabled, toUpdate.ContributionMethodChecking.SqlQuotify(), ddEnabled, workplaceISAEnabled, toUpdate.BillingGroupId) ;

              yield return sql;
        }

        public IEnumerable<string> DetectAnyDependants(BillingGroup model)
        {
            yield break;
        }

        /// <summary>
        /// return "USER_ACC_ID_SEQ"
        /// </summary>
        /// <returns>"USER_ACC_ID_SEQ"</returns>
        public string GetSequenceIdForInsert()
        {
           // return "USER_ACC_ID_SEQ";

            throw new NotImplementedException();
        }

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            string sql = @"
SELECT
    UBG.BGRP_KEY,
    BG.DESCRIPT,
    UBG.ABP_DIRECT_DEBIT_ENABLED,
    UBG.ABP_ED_SCHEME_ID,
    UBG.ABP_ED_PAYROLL_ID,
    UBG.ABP_ED_PAYING_OFFICE_ID,
    UBG.ABP_ED_NI_NUMBER,
    UBG.ABP_ED_TITLE,
    UBG.ABP_ED_SURNAME,
    UBG.ABP_ED_FORNAMES,
    UBG.ABP_ED_DOB,
    UBG.ABP_ED_SEX,
    UBG.ABP_ED_EARNINGS,
    UBG.ABP_ED_AC_SINGLE_PAYMENT,
    UBG.ABP_ED_EM_SINGLE_PAYMENT,
    UBG.ABP_ED_AC_CORE_PAYMENT,
    UBG.ABP_ED_EM_CORE_PAYMENT ,
    UBG.ABP_ED_AC_MATCHING_PAYMENT,
    UBG.ABP_ED_EM_MATCHING_PAYMENT,
    UBG.ABP_ED_AVC_PAYMENT,
    UBG.ABP_ED_EM_SPECIAL_PAYMENT,
    UBG.ABP_ED_AC_REBATE,
    UBG.ABP_ED_EM_REBATE,
    UBG.ABP_ED_SUSPENDED_DATE,
    UBG.ABP_ED_LEAVING_DATE,
    UBG.ABP_ED_JOINING_DATE,
    UBG.ABP_ED_REASON_CODE,
    UBG.ABP_WORKPLACE_ISA_ENABLED,
    UBG.ABP_ED_WORKPLACE_ISA,
    UBG.ABP_ED_WORKPLACE_ISA_REASON_CD,
    UBG.ABP_ENABLED,
    UBG.ABP_CHECK_CONTRIBUTIONS,
    UBG.BILL_DUE_DAY,
    UBG.OPRA_APPLIES,
    UBG.FREQUENCY,
    UBG.ACTIVE_LEAVER_BILLGRP,
    J2.WORKPLACE_ISA_REF
from uext_bill_grp ubg
inner join bill_grp BG
    on UBG.BGRP_KEY = BG.BGRP_KEY
left join UEXT_CASE_DATA J2
    on J2.CASE_KEY = BG.CASE_KEY
WHERE 
    BG.BGRP_KEY = " + primaryKey ;
                            

            yield return string.Format(sql, primaryKey);
        }

        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {        
            var caseKey = parentKey;

            string sql = @"select 
                            UBG.BGRP_KEY,
                            BG.DESCRIPT,
                            UBG.ABP_ENABLED,
                            UBG.ABP_DIRECT_DEBIT_ENABLED,
                            UBG.BILL_DUE_DAY,
                            UBG.OPRA_APPLIES,
                            UBG.ABP_CHECK_CONTRIBUTIONS,
                            UBG.FREQUENCY,
                            UBG.ACTIVE_LEAVER_BILLGRP, 
                            UBG.ABP_WORKPLACE_ISA_ENABLED,
                            J2.WORKPLACE_ISA_REF
from uext_bill_grp ubg
inner join bill_grp BG
    on UBG.BGRP_KEY = BG.BGRP_KEY
left join UEXT_CASE_DATA J2
    on J2.CASE_KEY = BG.CASE_KEY

                            where bg.case_key = {0}
                            {1}
                            order by DESCRIPT desc
";

                       yield return String.Format(sql, parentKey, appendWhereClauseWith);
        }
        public string InsertMissingUextBillGrpSQL(int parentKey = default(int))
        {
            string sql = string.Format(@"INSERT INTO UEXT_BILL_GRP
                        (BGRP_KEY, 
                        BILL_DUE_DAY, OPRA_APPLIES, FREQUENCY, ACTIVE_LEAVER_BILLGRP, 
                        ABP_ENABLED, ABP_FREQUENCY, ABP_CONVERTER, ABP_ED_SCHEME_ID, ABP_ED_PAYROLL_ID, 
                        ABP_ED_PAYING_OFFICE_ID, ABP_ED_NI_NUMBER, ABP_ED_TITLE, ABP_ED_SURNAME, ABP_ED_FORNAMES, 
                        ABP_ED_DOB, ABP_ED_SEX, ABP_ED_EARNINGS, ABP_ED_AC_SINGLE_PAYMENT, ABP_ED_EM_SINGLE_PAYMENT, 
                        ABP_ED_AC_CORE_PAYMENT, ABP_ED_EM_CORE_PAYMENT, ABP_ED_AC_MATCHING_PAYMENT, ABP_ED_EM_MATCHING_PAYMENT, ABP_ED_AVC_PAYMENT, 
                        ABP_ED_EM_SPECIAL_PAYMENT, ABP_ED_AC_REBATE, ABP_ED_EM_REBATE, ABP_ED_SUSPENDED_DATE, ABP_ED_LEAVING_DATE, 
                        ABP_ED_JOINING_DATE, ABP_ED_REASON_CODE, ABP_CURRENCY_SCALE, ABP_CHECK_CONTRIBUTIONS, ABP_DIRECT_DEBIT_ENABLED, 
                        OPRA_REMINDER_DAY, ABP_WORKPLACE_ISA_ENABLED, ABP_ED_WORKPLACE_ISA, ABP_ED_WORKPLACE_ISA_REASON_CD)
    
                    (select bg.bgrp_key,
                    1, 1, '0', 0, 
                        'N', 'M', NULL, 'R', 'W',
                        'R', 'W', 'W', 'W', 'W', 
                        'W', 'W', 'W', 'W', 'W', 
                        'W', 'W', 'W', 'W', 'W', 
                        'W', 'W', 'W', 'R', 'W', 
                        'R', 'W', 2, 'P', 'N', 
                        NULL, 'N', 'N', 'N'
                        from bill_grp bg
                    left join uext_bill_grp ubg
                        on ubg.bgrp_key = bg.bgrp_key
                    where ubg.bgrp_key is null
                    and bg.case_key = {0})", parentKey);
            
            return sql;
        }


        public string SelectDuplicatesSql(BillingGroup similar)
        {
            return null;
        }
    }
}
