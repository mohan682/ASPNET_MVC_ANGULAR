﻿using Dcorum.BusinessLayer.Entities;
using System.Text;
using System;
namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class ValidationSql
    {
        public static string GetAllValidationsSql()
        {
            const string sql = @"select V.VALIDATION_ID, V.VALIDATION_NAME, V.TYPE,  
                                '[' || P.PDIMESSAGE_ID || '] ' || P.CODE AS ErrorMessage, 
                                V.VALUE, V.VALUE_TYPE, V.VALUE_FROM, V.VALUE_TO 
                                from validation v
                                inner join pdimessage p 
                                    on V.ERROR_MESSAGE_ID = P.PDIMESSAGE_ID     ";
            return sql;
        }

        public static string GetValidationSql(int ValidationID)
        {
            const string sql = @"select V.VALIDATION_ID, V.VALIDATION_NAME, V.TYPE,  
                                '[' || P.PDIMESSAGE_ID || '] ' || P.CODE AS ErrorMessage, 
                                V.VALUE, V.VALUE_TYPE, V.VALUE_FROM, V.VALUE_TO 
                                from validation v
                                inner join pdimessage p 
                                    on V.ERROR_MESSAGE_ID = P.PDIMESSAGE_ID     
                                where v.VALIDATION_ID = {0}";
            return string.Format(sql, ValidationID);

        }

        public static string GetValidationByNameSQL(string ValidationName)
        {
            const string sql = @"select V.VALIDATION_ID, V.VALIDATION_NAME, V.TYPE,  
                                '[' || P.PDIMESSAGE_ID || '] ' || P.CODE AS ErrorMessage, 
                                V.VALUE, V.VALUE_TYPE, V.VALUE_FROM, V.VALUE_TO 
                                from validation v
                                LEFT join pdimessage p 
                                    on V.ERROR_MESSAGE_ID = P.PDIMESSAGE_ID     
                                where UPPER(v.VALIDATION_NAME) = UPPER('{0}') ";
            return string.Format(sql, ValidationName);

        }

        public static string GetAllValidationTypes()
        {
            StringBuilder sSQL = new StringBuilder();

            sSQL.AppendLine("SELECT DESCRIPT ");
            sSQL.AppendLine("FROM REF_CODES ");
            sSQL.AppendLine("WHERE DOMAIN_NAME = 'VALIDATION TYPES'");

            return sSQL.ToString();
        }
        public static string GetAllValueTypes()
        {
            StringBuilder sSQL = new StringBuilder();

            sSQL.AppendLine("SELECT DESCRIPT ");
            sSQL.AppendLine("FROM REF_CODES ");
            sSQL.AppendLine("WHERE DOMAIN_NAME = 'VALIDATION VALUE TYPES'");

            return sSQL.ToString();
        }

        public static string GetAllErrorMessagesAndIds()
        {
            const string sql = @"select '[' || PDIMESSAGE_ID || '] ' || CODE AS ErrorMessage
                                from pdimessage  ";
            return sql;
        }

        public static string ErrormessageExists(string strErrorMessage)
        {
            StringBuilder sSQL = new StringBuilder();

            sSQL.AppendLine("SELECT COUNT(*) ");
            sSQL.AppendLine("FROM PDIMESSAGE ");
            sSQL.AppendLine(string.Format("WHERE TO_CHAR(PDIMESSAGE_ID) = '{0}' ", strErrorMessage));

            return sSQL.ToString();
                             
        }

        public static string InsertValidationSQL(Validation validation)
        {
            StringBuilder sSQL = new StringBuilder();

            string pKey = validation.ValidationID.ToString(); //"Validation_Id_Seq.NextVal";

            sSQL.AppendLine("INSERT INTO VALIDATION ");
            sSQL.AppendLine("( VALIDATION_ID, VALIDATION_NAME, TYPE, VALUE, VALUE_TYPE, VALUE_FROM, VALUE_TO, ERROR_MESSAGE_ID) VALUES ");
            sSQL.AppendFormat("( {0},",pKey );
            sSQL.AppendLine(string.Format(" '{0}', ", validation.ValidationName));
            sSQL.AppendLine(string.Format(" '{0}', ", validation.ValidationType));
            sSQL.AppendLine(string.Format(" '{0}', ", validation.ValidationValue));
            sSQL.AppendLine(string.Format(" '{0}', ", validation.ValueType));
            sSQL.AppendLine(string.Format(" '{0}', ", validation.ValueFrom));
            sSQL.AppendLine(string.Format(" '{0}', ", validation.ValueTo));
            sSQL.AppendLine(string.Format("  {0} ) ", validation.ErrorMessage));

            return sSQL.ToString();

        }

        public static string UpdateValidationSQL(Validation validation)
        {
            StringBuilder sSQL = new StringBuilder();

            sSQL.AppendLine("UPDATE VALIDATION ");
            sSQL.AppendLine(string.Format("SET VALIDATION_NAME = '{0}', ", validation.ValidationName));
            sSQL.AppendLine(string.Format("TYPE = '{0}', ", validation.ValidationType));
            // Deal with error message - Error message comes through as "[xxxx] Short Error Desc" where xxxx is the value we need for the Error_Message_Id
            sSQL.AppendLine(string.Format("ERROR_MESSAGE_ID = {0}, ", validation.ErrorMessage));
            sSQL.AppendLine(string.Format("VALUE = '{0}', ", validation.ValidationValue));
            sSQL.AppendLine(string.Format("VALUE_TYPE = '{0}', ", validation.ValueType));
            sSQL.AppendLine(string.Format("VALUE_FROM = '{0}', ", validation.ValueFrom));
            sSQL.AppendLine(string.Format("VALUE_TO = '{0}' ", validation.ValueTo));
            sSQL.AppendLine(string.Format("WHERE VALIDATION_ID = {0} ", validation.ValidationID.ToString()));

            return sSQL.ToString();

        }

        public static string GetAllValidationNamesSql()
        {
            return "select distinct V.VALIDATION_ID, V.VALIDATION_NAME from validation v order by V.VALIDATION_NAME";
        }
    }
}
