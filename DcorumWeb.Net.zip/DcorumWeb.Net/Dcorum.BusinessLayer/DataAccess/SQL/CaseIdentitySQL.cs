﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    class CaseIdentitySQL
    {
        public static bool Jira6845ModeOn { get; set; }

        private static string OptionalCommentLine
        {
            get { return (Jira6845ModeOn) ? null : "-- "; }
        }

        internal static string GetAllCaseIdentitySql()
        {
            const string sqlTemplate = @"
                                        SELECT 
                                            IP.Case_Data_Idt_Provider_Id, 
                                            IP.Case_Key,
                                            IP.Identity_Provider,
                                            {0}IP.Identity_Provider_Alias,
                                            {0}IP.Identity_URL,
                                            {0}IP.Identity_CheckSum,
                                            CD.Cont_No, 
                                            CD.Plan_Nm 
                                        FROM Case_Data_Identity_Provider IP
                                        INNER JOIN Case_Data CD  on IP.Case_Key = CD.Case_Key
                                        ORDER BY 2 ";

            return String.Format(sqlTemplate, OptionalCommentLine);
        }

        internal static string GetCaseIdentityByIdSql(int caseIdentityId)
        {
            const string sqlTemplate = @"
                                        SELECT 
                                            IP.Case_Data_Idt_Provider_Id, 
                                            IP.Case_Key,
                                            IP.Identity_Provider,
                                            {1}IP.Identity_Provider_Alias,
                                            {1}IP.Identity_URL,
                                            {1}IP.Identity_CheckSum,
                                            CD.Cont_No, 
                                            CD.Plan_Nm 
                                        FROM Case_Data_Identity_Provider IP
                                        INNER JOIN Case_Data CD  on IP.Case_Key = CD.Case_Key
                                        WHERE IP.Case_Data_Idt_Provider_Id = {0}
                                        ORDER BY 2 ";

            return string.Format(sqlTemplate, caseIdentityId, OptionalCommentLine);
        }

        internal static string GetCaseIdentityBySchemeSql(CaseIdentity caseIdentity)
        {
            const string sqlTemplate = @"
                                        SELECT 
                                            IP.Case_Data_Idt_Provider_Id, 
                                            IP.Case_Key,
                                            IP.Identity_Provider,
                                            {1}IP.Identity_Provider_Alias,
                                            {1}IP.Identity_URL,
                                            {1}IP.Identity_CheckSum,
                                            CD.Cont_No, 
                                            CD.Plan_Nm 
                                        FROM Case_Data_Identity_Provider IP
                                        INNER JOIN Case_Data CD  on IP.Case_Key = CD.Case_Key
                                        WHERE IP.Case_Key = {0}
                                        ORDER BY 2 ";

            return string.Format(sqlTemplate, caseIdentity.CaseKey, OptionalCommentLine);
        }

        internal static string GetCaseIdentityByIDPAliasSql(CaseIdentity caseIdentity)
        {
            const string sqlTemplate = @"
                                        SELECT 
                                            IP.Case_Data_Idt_Provider_Id, 
                                            IP.Case_Key,
                                            IP.Identity_Provider,
                                            IP.Identity_Provider_Alias,
                                            IP.Identity_URL,
                                            IP.Identity_CheckSum,
                                            CD.Cont_No, 
                                            CD.Plan_Nm 
                                        FROM Case_Data_Identity_Provider IP
                                        LEFT JOIN Case_Data CD  on IP.Case_Key = CD.Case_Key
                                        WHERE IP.Identity_Provider_Alias = '{0}'
                                        ORDER BY 2 ";

            return string.Format(sqlTemplate, caseIdentity.IDPShortName);
        }

        internal static string InsertCaseIdentitySql(CaseIdentity caseIdentity)
        {
            const string sqlTemplate = @"
            INSERT INTO UEXT.Case_Data_Identity_Provider (
            Case_Data_Idt_Provider_Id,              Case_Key,           Identity_Provider 
            {5},Identity_Provider_Alias,    Identity_URL,   Identity_CheckSum
            )  VALUES (
            Case_Data_Idt_Provider_Id_Seq.Nextval,  {0},                '{1}'             
            {5},'{2}',                      '{3}',          '{4}'
            ) ";

            return string.Format(sqlTemplate, caseIdentity.CaseKey, caseIdentity.IdentityProvider, caseIdentity.IDPShortName, caseIdentity.IDPURL, caseIdentity.IdentityChecksum, OptionalCommentLine);
        }

        internal static string UpdateCaseIdentitySql(CaseIdentity caseIdentity)
        {
            const string sqlTemplate = @" UPDATE Case_Data_Identity_Provider SET
                                                Case_Key                = {0},
                                                Identity_Provider = '{1}'
                                                {6},Identity_Provider_Alias = '{2}'
                                                {6},Identity_URL            = '{3}'
                                                {6},Identity_CheckSum       = '{4}'
                                          WHERE   Case_Data_Idt_Provider_Id = {5}";

            return string.Format(sqlTemplate, caseIdentity.CaseKey, caseIdentity.IdentityProvider, caseIdentity.IDPShortName, caseIdentity.IDPURL, caseIdentity.IdentityChecksum, caseIdentity.CaseIdentityId, OptionalCommentLine);
        }

        internal static string DeleteCaseIdentitySql(CaseIdentity caseIdentity)
        {
            const string sqlTemplate = @"DELETE FROM Case_Data_Identity_Provider WHERE Case_Data_Idt_Provider_Id = {0} ";

            return string.Format(sqlTemplate, caseIdentity.CaseIdentityId);
        }
    }
}
