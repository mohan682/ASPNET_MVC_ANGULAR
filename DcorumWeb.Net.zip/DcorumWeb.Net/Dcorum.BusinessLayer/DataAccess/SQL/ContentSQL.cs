﻿using System;
using System.Text;
using Dcorum.Utilities.DataAccess;
using DcorumWeb.Utilities;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class ContentSQL
    {
        internal protected ContentSQL()
        {
        }


        public string GetContentSql(string subClause)
        {
            string template1 = @"select f1.*, cd.CONT_NO, cd.PLAN_NM, (select count(base_id) from content where base_id = f1.content_id) as Has_Shadow 
                    from content f1
                    left join case_data cd on CD.CASE_KEY=f1.SCHEME
                    {0}
                    order by f1.PROVIDER, f1.PRODUCT, f1.PLAN, f1.SCHEME, f1.MBR_GRP, f1.SCHEME, f1.COMPONENT, f1.TYPE, f1.TARGET, f1.APPROVED";

            string result = String.Format(template1, (String.IsNullOrWhiteSpace(subClause)) ? null : "where 1=1 " + subClause);
            return result;
        }

        public string GetContentByIdSql(int id)
        {
            const string sqlTemplate = @"select f1.*, cd.CONT_NO, cd.PLAN_NM,
                                            (select count(base_id) from content where base_id = {0}) as Has_Shadow 
                                            from content f1 left join case_data cd on CD.CASE_KEY= f1.SCHEME where content_id = {0}";
            return string.Format(sqlTemplate, id);
        }

        public string UpdateContentSql(bool approved, string authUserId, string component, int id, string createdUserId, DateTime effDateTime, DateTime? expDateTime,
            int memberGroup, int product, string provider, bool published, int schemeId, string target, string type, string value, string plan)
        {
            const string sqlTemplate = @"
                                        UPDATE UEXT.CONTENT
                                        SET    APPROVED        = {0},
                                               AUTH_USER_ID    = {1},
                                               COMPONENT       = {2},
                                               CREATED_USER_ID = {4},
                                               EFF_DT          = {5},
                                               EXPIR_DT        = {6},
                                               MBR_GRP         = {7},
                                               PRODUCT         = {8},
                                               PROVIDER        = {9},
                                               PUBLISHED       = {10},
                                               SCHEME          = {11},
                                               TARGET          = {12},
                                               TYPE            = {13},
                                               VALUE           = {14},
                                               PLAN            = {15}

                                        Where CONTENT_ID      = {3}     ";

            return string.Format(sqlTemplate, approved.NullifyDefault().IntoSqlBool(), authUserId.SqlQuotify(), component.SqlQuotify(), id,
                createdUserId.SqlQuotify(), effDateTime.ToSqlShortDateString(), expDateTime.ToSqlShortDateString(),
                memberGroup.NullifyDefault().IntoSqlValue(), product.NullifyDefault().IntoSqlValue(), provider.SqlQuotify(),
                published.IntoSqlBool(), schemeId.NullifyDefault().IntoSqlValue(), target.SqlQuotify(), type.SqlQuotify(), value.SqlQuotify(), plan.SqlQuotify());
        }

        public string InsertContentSql(int contentId, bool approved, string authUserId, string component, string createdUserId, DateTime effDateTime, DateTime? expDateTime,
            int memberGroup, int product, string provider, bool published, int schemeId, string target, string type, string value, int baseId, string plan)
        {
            const string sqlTemplate = @"INSERT INTO UEXT.CONTENT (
                                           APPROVED, AUTH_USER_ID, COMPONENT, 
                                           CONTENT_ID, CREATED_USER_ID, EFF_DT, 
                                           EXPIR_DT, MBR_GRP, PRODUCT, 
                                           PROVIDER, PUBLISHED, SCHEME, 
                                           TARGET, TYPE, VALUE, BASE_ID, PLAN) 
                                        VALUES ( {0},
                                         {1},
                                         {2},
                                         {15},
                                         {3},
                                         {4},
                                         {5},
                                         {6},
                                         {7},
                                         {8},
                                         {9},
                                         {10},
                                         {11},
                                         {12},
                                         {13},
                                         {14},
                                         {16})";
            return string.Format(sqlTemplate, approved.NullifyDefault().IntoSqlBool(), authUserId.SqlQuotify(), component.SqlQuotify(),
                createdUserId.SqlQuotify(), effDateTime.ToSqlShortDateString(), expDateTime.ToSqlShortDateString(),
                memberGroup.NullifyDefault().IntoSqlValue(), product.NullifyDefault().IntoSqlValue(), provider.SqlQuotify(),
                published.IntoSqlBool(), schemeId.NullifyDefault().IntoSqlValue(), target.SqlQuotify(), type.SqlQuotify(), value.SqlQuotify(),
                baseId.NullifyDefault().IntoSqlValue(), contentId, plan.SqlQuotify());
        }


        public string DeletePendingContent(int id)
        {
            const string sqltemplate = "delete from content c where (C.APPROVED != 1 or C.APPROVED is null) and C.CONTENT_ID = {0}";
            return string.Format(sqltemplate, id);
        }

        public string ApproveContent(int contentId, string userName)
        {
            const string sqltemplate = @"DECLARE
                                            V_BASE_ID NUMBER;                                           
                                            V_EFFECTIVE_DATE DATE;
                                            V_SCHEME INTEGER;  
                                            V_MBR_GRP INTEGER; 
                                            V_PLAN NUMBER;   
                                            V_PRODUCT NUMBER;  
                                            V_PROVIDER VARCHAR2(20);  

                                            BEGIN

                                                SELECT  NVL(BASE_ID, 0),NVL(EFF_DT-1,NULL) ,SCHEME,MBR_GRP,PLAN, PRODUCT,PROVIDER
                                                INTO V_BASE_ID, V_EFFECTIVE_DATE ,V_SCHEME,V_MBR_GRP,V_PLAN, V_PRODUCT,V_PROVIDER
                                                FROM CONTENT WHERE CONTENT_ID = {0};

                                                UPDATE CONTENT C SET C.APPROVED = 1, C.BASE_ID = NULL, C.AUTH_USER_ID = {1} 
                                                WHERE C.CONTENT_ID = {0};                                             

                                                IF V_BASE_ID > 0 THEN

                                                    UPDATE CONTENT SET EXPIR_DT = V_EFFECTIVE_DATE 
                                                    WHERE CONTENT_ID =V_BASE_ID
                                                     AND NVL(SCHEME,0)=NVL(V_SCHEME,0) 
                                                     AND NVL(MBR_GRP,0)=NVL(V_MBR_GRP,0)
                                                     AND NVL(PLAN,0)=NVL(V_PLAN,0)
                                                     AND NVL(PRODUCT,0)=NVL(V_PRODUCT,0) AND NVL(PROVIDER,0)=NVL(V_PROVIDER,0);

                                                END IF;
                                                
                                        

                                            END;";
            return string.Format(sqltemplate, contentId, string.IsNullOrEmpty(userName)?null:string.Format("'{0}'",userName));
        }
    }
}
