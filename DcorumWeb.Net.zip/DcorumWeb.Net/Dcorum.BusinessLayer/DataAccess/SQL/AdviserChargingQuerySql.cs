﻿using Dcorum.Utilities.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class AdviserChargingQuerySql
    {
        internal protected AdviserChargingQuerySql()
        {

        }

        public IEnumerable<string> MainSelectSql(params int[] caseMemberKeys)
        {
            string sql1 = @"
SELECT 
    V.Case_Mbr_Key, VMAAB.Agt_Key, VMAAB.Adviser_Number,
    VMAAB.Adviser_Nameprefix, VMAAB.Adviser_Firstname, VMAAB.Adviser_Lastname,  
    VMAAB.Firm_Name, LOA.Type, LOA.EFF_DT, LOA.XPIR_DT,VMAAB.Assoc_Agt_Pct,
    ( SELECT 
          DECODE(COUNT(*),0,0,1) 
      FROM 
          UEXT.V_Mbr_Adviser_Charge VMAC 
      WHERE 
          V.Case_Mbr_Key = VMAC.Case_Mbr_Key 
          AND VMAC.Charge_Eff_Dt <= TRUNC(SYSDATE)
          AND VMAC.Charge_Amount IS NOT NULL
          AND NVL(Transact_Details_Eff_Dt,SYSDATE) >= TRUNC(SYSDATE-49)
          AND NVL(Charge_Xpir_Dt,SYSDATE) >= TRUNC(SYSDATE-49)
    ) AS Has_Fees
FROM
    VEmployees V
    INNER JOIN UEXT.V_Mbr_Adv_Agy_Bnk VMAAB ON V.Case_Mbr_Key = VMAAB.Case_Mbr_Key
    LEFT JOIN Letter_Of_Authority LOA ON V.Case_Mbr_Key = LOA.Case_Mbr_Key AND VMAAB.Agt_Key = LOA.Agt_Key
                                         AND LOA.EFF_DT <= SYSDATE AND NVL(LOA.XPIR_DT,SYSDATE)>=TRUNC(SYSDATE)
{0}
ORDER BY
    LOA.EFF_DT
";

            string values = string.Join(", ", (caseMemberKeys ?? Enumerable.Empty<int>()).Select(_ => _.ToString()));
            string clause1 = (string.IsNullOrWhiteSpace(values)) ? null : string.Format( "where V.Case_Mbr_Key in ({0})", values);

            yield return string.Format(sql1, clause1);
        }

        public IEnumerable<string> LoaHeaderSelectSql(int caseMemberKey, int agentKey)
        {
            string sql1 = @"
SELECT DISTINCT
    Agt_Key, 
    Adviser_Number, Adviser_Nameprefix, Adviser_Firstname, Adviser_Lastname,Adviser_Email, Adviser_Addr_L1, Adviser_Addr_L2, Adviser_Addr_L3, Adviser_Addr_City, Adviser_Addr_County, Adviser_Addr_PostCd,	
    Firm_Name, Firm_Ref,Firm_Email, Firm_Addr_L1, Firm_Addr_L2, Firm_Addr_L3, Firm_Addr_City, Firm_Addr_County, Firm_Addr_Postcd,
    Ntwk_Name, Ntwk_Ref,NtWk_Email, Ntwk_Addr_L1, Ntwk_Addr_L2, Ntwk_Addr_L3, Ntwk_Addr_City, Ntwk_Addr_County, Ntwk_Addr_Postcd
FROM
    UEXT.V_Mbr_Adv_Agy_Bnk
WHERE
    Case_Mbr_key = {0}
    AND Agt_Key = {1}
            ";
            yield return string.Format(sql1, caseMemberKey, agentKey);
        }


        public IEnumerable<string> LoaRowsSelectSql(int caseMemberKey, int agentKey)
        {
            string sql1 = @"
SELECT
    Loa.Letter_Of_Authority_id, Loa.Case_Mbr_Key, Loa.Agt_Key,
    LOA.Type,
    LOA.Eff_Dt, LOA.Xpir_Dt,LOA.LAST_MOD_DT,LOA.LAST_MOD_USER
FROM
    Letter_Of_Authority LOA
    --LEFT JOIN  Ref_Codes RC ON LOA.Type = RC.Ref_Cd AND RC.Domain_Name = 'LOA_TYPE'
WHERE
    Loa.Agt_Key = {1}
    and Loa.Case_Mbr_Key = {0}
ORDER BY
    LOA.Letter_Of_Authority_id
";
            yield return string.Format(sql1, caseMemberKey, agentKey);
        }


        public IEnumerable<string> FeesSelectSql(int caseMemberKey, string[] trCodes = null,bool includeExpiredFees=true)
        {
            string andTrCodes1 = (trCodes == null) ? null : string.Format("AND TR_CD IN( {0} )", (trCodes.Any() ? string.Join(", ", trCodes.Select(_ => _.SqlQuotify())) : "null"));

            string sql1 = $@"
SELECT
    Case_Mbr_Key, Tr_Cd, Charge_Description, Charge_Amount, Percent_Or_Currency, 
    Last_Paid_Dt, Sched_Nxt_Dt, Expiry_Dt     
FROM
(
    SELECT 
        Case_Mbr_Key, Tr_Cd, Charge_Description, Charge_Amount, Percent_Or_Currency, 
        MAX(Transact_Details_Eff_Dt) AS Last_Paid_Dt,
        Sched_Nxt_Dt,
        CASE
            WHEN Tr_Cd = '4081' THEN COALESCE(LEAST(Reg_Fxd_Term_End_Dt,Charge_Xpir_Dt),Reg_Fxd_Term_End_Dt,Charge_Xpir_Dt)
            ELSE Charge_Xpir_Dt
        END AS Expiry_Dt     
    FROM
        V_Mbr_Adviser_Charge
    WHERE
        Charge_Eff_Dt <= TRUNC(SYSDATE)
        AND Charge_Amount IS NOT NULL
        AND Case_Mbr_Key = {caseMemberKey}
        {andTrCodes1}
    GROUP BY
        Case_Mbr_Key, Tr_Cd, Charge_Description, Charge_Amount, Percent_Or_Currency, 
        Reg_Fxd_Term_End_Dt ,
        Sched_Nxt_Dt,
        CASE
            WHEN Tr_Cd = '4081' THEN COALESCE(LEAST(Reg_Fxd_Term_End_Dt,Charge_Xpir_Dt),Reg_Fxd_Term_End_Dt,Charge_Xpir_Dt)
            ELSE Charge_Xpir_Dt
        END
)
WHERE
    NVL(Last_Paid_Dt,SYSDATE) >= TRUNC(SYSDATE-49)
   AND NVL(Expiry_Dt,SYSDATE) >= {(includeExpiredFees ? " TRUNC(SYSDATE-49)" : "TRUNC(SYSDATE)")} 
ORDER BY 
    Charge_Description
";         

            yield return string.Format(sql1, caseMemberKey, andTrCodes1);
        }

    }
}
