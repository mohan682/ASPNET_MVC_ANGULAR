﻿using System;
using System.Diagnostics.Contracts;
using System.Text;
using Dcorum.BusinessLayer.Entities.Contributions;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Dcorum.BusinessLayer.Constants;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public interface IContributionLookupSqlBuilder<in T>
        where T: ContributionLookupCore 
    {
        string SelectViaPkeySql(int pkey);
        string SelectViaCaseKeySql(int fkey);
        string SelectViaMemberGroupKeySql(int fkey);
        //string CopySql(int sourceMemberGroupKey, int targetMemberGroupKey);
        //string CloneSql(int sourceMemberGroupKey, int targetMemberGroupKey);
        string UpdateVariationSql(T toUpdate);
        string UpdateGroupSql(Database db, T toUpdate);

        string InsertCslSql(Database db, T toInsert);

        string DeleteSql(T toUpdate);
    }


    public class ContributionStructureSql : IContributionLookupSqlBuilder<ContributionStructureLookup>
    {
        public static string InsertContributionStructureDetailsSql(int id, int parentId, int ageTo, int serviceTo,
            decimal contributionTo, DateTime? dateTo, Int64 salaryTo, decimal minEmployeeContribution,
            decimal coreContribution, decimal match, decimal maxMatch, decimal totalMaxEmployerContributionPercentage,
            decimal totalMaxEmploerContributionAmount, Int64 salaryLimit, DateTime effDate, DateTime expiryDate,
            int caseKey, int memberGroupKey, int newLookupId)
        {
            string dateToString = dateTo.HasValue
                ? string.Concat("to_date('", dateTo.Value.ToShortDateString(), "', 'dd/mm/yyyy')")
                : "null";

            string effectiveDateString = string.Concat("to_date('", effDate.ToShortDateString(), "', 'dd/mm/yyyy')");
            string expiryDateString = string.Concat("to_date('", expiryDate.ToShortDateString(), "', 'dd/mm/yyyy')");

            if (parentId == 0)
            {
                Contract.Assert(caseKey > 0);
                Contract.Assert(memberGroupKey > 0);
                Contract.Assert(newLookupId > 0);

                var sqlInsertWithoutCsId = new StringBuilder();

                sqlInsertWithoutCsId.Append("declare ");
                sqlInsertWithoutCsId.Append("v_csg_id number; ");
                //sqlInsertWithoutCsId.Append("v_csl_id number;  ");
                sqlInsertWithoutCsId.Append("begin  ");
                //sqlInsertWithoutCsId.Append("select CONTRIBUTION_STRUCT_LOOKUP_SEQ.nextval into v_csl_id from dual; ");
                sqlInsertWithoutCsId.Append(
                    "select UEXT.CONTRIB_STRUCTURE_GROUP_ID_SEQ.nextval into v_csg_id from dual; ");
                sqlInsertWithoutCsId.Append(
                    "INSERT INTO UEXT.CONTRIBUTION_STRUCTURE (AGE_TO, CONTRIBUTION_STRUC_GROUP_ID, CONTRIBUTION_TO,CORE, DATE_TO,EFF_DT, CONTRIBUTION_STRUCTURE_ID, ");
                sqlInsertWithoutCsId.Append(
                    "   MATCH, MAX_EE_CONT_MATCHED, MIN_EE_CONT, SALARY_INC_TYPE,SALARY_TO, SERVICE_TO, TOTAL_ER_MAX_CONTRIB_AMT,TOTAL_ER_MAX_CONTRIB_PCT,UPPER_LIMIT_SALARY, XPIR_DT) ");
                sqlInsertWithoutCsId.Append(
                    "VALUES ({0},v_csg_id,{1},{2},{3},{4},{17},{5},{6},{7},{8}, {9},{10},{11},{12},{13},{14}); ");
                sqlInsertWithoutCsId.Append(
                    "INSERT INTO UEXT.CONTRIBUTION_STRUCTURE_LOOKUP (CASE_KEY, CONTRIBUTION_STRUC_GROUP_ID, CONTRIBUTION_STRUC_LOOKUP_ID ,MBGP_KEY, VARIATION_CD)  ");
                sqlInsertWithoutCsId.Append("VALUES ( {15},v_csg_id,/*v_csl_id*/{18},{16},'{19}' ); ");
                sqlInsertWithoutCsId.Append("end; ");
                return string.Format(sqlInsertWithoutCsId.ToString(), ageTo, contributionTo, coreContribution,
                    dateToString,
                    effectiveDateString, match, maxMatch, minEmployeeContribution, "null", salaryTo, serviceTo,
                    totalMaxEmploerContributionAmount, totalMaxEmployerContributionPercentage, salaryLimit,
                    expiryDateString, caseKey, memberGroupKey, id, newLookupId,CommonCodes.Variation_Code_ALL);
            }

            var sqlInsertWithCsId = new StringBuilder();
            sqlInsertWithCsId.Append("begin ");
            sqlInsertWithCsId.Append(
                "INSERT INTO UEXT.CONTRIBUTION_STRUCTURE (AGE_TO,CONTRIBUTION_STRUC_GROUP_ID,CONTRIBUTION_TO,CORE,DATE_TO,EFF_DT,CONTRIBUTION_STRUCTURE_ID,MATCH,MAX_EE_CONT_MATCHED,MIN_EE_CONT,  ");
            sqlInsertWithCsId.Append(
                " SALARY_INC_TYPE,SALARY_TO,SERVICE_TO,TOTAL_ER_MAX_CONTRIB_AMT,TOTAL_ER_MAX_CONTRIB_PCT,UPPER_LIMIT_SALARY,XPIR_DT)  ");
            sqlInsertWithCsId.Append(
                "VALUES ({0},{15},{1},{2},{3},{4},{16},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}); ");
            sqlInsertWithCsId.Append("end; ");

            return string.Format(sqlInsertWithCsId.ToString(), ageTo, contributionTo, coreContribution, dateToString,
                effectiveDateString, match, maxMatch, minEmployeeContribution, "null", salaryTo, serviceTo,
                totalMaxEmploerContributionAmount, totalMaxEmployerContributionPercentage, salaryLimit,
                expiryDateString, parentId, id);

        }


        private const string SelectCore = @"
        select distinct CSL.CONTRIBUTION_STRUC_LOOKUP_ID as csl_id, mg.case_key, MG.MBGP_KEY, MG.DESCRIPT, MG.GRP_TYP_CD, CSL.CONTRIBUTION_STRUC_GROUP_ID as csl_group_id,
        uext.pdi.mny_typ_grp_descript(mg.CASE_KEY,Coalesce(To_number(Replace(Upper(CSL.VARIATION_CD),'ALL')),0)) NAME, 
        (select count(*) from contribution_structure_lookup where CONTRIBUTION_STRUC_GROUP_ID = CSL.CONTRIBUTION_STRUC_GROUP_ID) as COUNTSCALE, Upper(CSL.VARIATION_CD) as VARIATION_CD, MG.GRP_TYP_CD
        ,(select count(*) from contribution_structure where CONTRIBUTION_STRUC_GROUP_ID = CSL.CONTRIBUTION_STRUC_GROUP_ID) as DetailCount
        from mbr_grp mg
        inner join uext_mbr_grp umg on MG.MBGP_KEY = UMG.MBGP_KEY
        left join contribution_structure_lookup csl on UMG.MBGP_KEY = CSL.MBGP_KEY
        where MG.GRP_TYP_CD = '12' AND umg.DISPLAY = 1 and {0}
        order by DESCRIPT
        ";


        public string SelectViaPkeySql(int pkey)
        {
            return String.Format(SelectCore, "CSL.CONTRIBUTION_STRUC_LOOKUP_ID" + "=" + pkey);
        }

        public string SelectViaCaseKeySql(int fkey)
        {
            return String.Format(SelectCore, "MG.CASE_KEY" + "=" + fkey);
        }

        public string SelectViaMemberGroupKeySql(int fkey)
        {
            return String.Format(SelectCore, "MG.MBGP_KEY" + "=" + fkey);
        }


        public static string GetAllMemberGroupsWithStructures()
        {
            return @"select distinct MG.MBGP_KEY, MG.DESCRIPT, 0 as CSL_GROUP_ID, 0 as COUNTSCALE, '0' as VARIATION_CD, MG.GRP_TYP_CD
                                from mbr_grp mg
                                left join mbr_grp_detl mgd on MGD.MBGP_KEY = mg.MBGP_KEY
                                    and (trunc(MGD.EFF_DT) <= trunc(sysdate) and (trunc(MGD.XPIR_DT) >= trunc(sysdate) or MGD.XPIR_DT is null ))
                                inner join uext_mbr_grp umg on MG.MBGP_KEY = UMG.MBGP_KEY
                                inner join contribution_structure_lookup csl on UMG.MBGP_KEY = CSL.MBGP_KEY
                                where MG.GRP_TYP_CD = '12'
                                order by DESCRIPT";
        }

//        public string CopySql(int sourceMemberGroupKey, int targetMemberGroupKey)
//        {
//            const string sqlTemplate = @"declare 
//                                            v_case_key number;
//                                            begin
//                                            select UMG.CASE_KEY into v_case_key from uext_mbr_grp umg where UMG.MBGP_KEY = {1};
//                                            delete from CONTRIBUTION_STRUCTURE_LOOKUP CSL where CSL.MBGP_KEY = {1};
//     
//                                            INSERT INTO UEXT.CONTRIBUTION_STRUCTURE_LOOKUP (
//                                               CASE_KEY, CONTRIBUTION_STRUC_GROUP_ID, CONTRIBUTION_STRUC_LOOKUP_ID, 
//                                               MBGP_KEY, VARIATION_CD) 
//                                            SELECT 
//                                            v_case_key, CONTRIBUTION_STRUC_GROUP_ID, CONTRIBUTION_STRUCT_LOOKUP_SEQ.nextval, 
//                                               {1}, VARIATION_CD
//                                            FROM UEXT.CONTRIBUTION_STRUCTURE_LOOKUP csl where CSL.MBGP_KEY = {0} ;
//                                            end;";

//            return string.Format(sqlTemplate, sourceMemberGroupKey, targetMemberGroupKey);
//        }

//        public string CloneSql(int sourceMemberGroupKey, int targetMemberGroupKey)
//        {
//            const string sqlTemplate = @"declare
//                                v_csg_id number;
//                                v_case_key number;
//                                v_new_csg_id number;
//                                
//                                cursor csgids is 
//                                    select CSL.CONTRIBUTION_STRUC_GROUP_ID from Contribution_Structure_lookup csl where CSL.MBGP_KEY = {0};
//                                
//                                begin
//                                
//                                select UMG.CASE_KEY into v_case_key from uext_mbr_grp umg where UMG.MBGP_KEY = {1};
//                                delete from Contribution_structure_lookup CSL where CSL.MBGP_KEY = {1};
//                                
//                                delete from contribution_structure s1
//                                where exists ( 
//                                    select * from contribution_structure_lookup l1 
//                                    where l1.contribution_struc_group_id = s1.contribution_struc_group_id
//                                    and l1.mbgp_key = {1}
//                                    );
//
//                                for csgid in csgids
//                                loop
//
//
//                                    select UEXT.CONTRIB_STRUCTURE_GROUP_ID_SEQ.nextval into v_new_csg_id from dual;
//                                
//                                    INSERT INTO UEXT.CONTRIBUTION_STRUCTURE (
//                                         AGE_TO, CONTRIBUTION_STRUCTURE_ID, CONTRIBUTION_STRUC_GROUP_ID, 
//                                       CONTRIBUTION_TO, CORE, DATE_TO, 
//                                       EFF_DT, MATCH, MAX_EE_CONT_MATCHED, 
//                                       MIN_EE_CONT, SALARY_INC_TYPE, SALARY_TO, 
//                                       SERVICE_TO, TOTAL_ER_MAX_CONTRIB_AMT, TOTAL_ER_MAX_CONTRIB_PCT, 
//                                       UPPER_LIMIT_SALARY, XPIR_DT) 
//                                    SELECT 
//                                        AGE_TO, CONTRIBUTION_STRUCTURE_SEQ.nextval , v_new_csg_id, 
//                                           CONTRIBUTION_TO, CORE, DATE_TO, 
//                                           EFF_DT, MATCH, MAX_EE_CONT_MATCHED, 
//                                           MIN_EE_CONT, SALARY_INC_TYPE, SALARY_TO, 
//                                           SERVICE_TO, TOTAL_ER_MAX_CONTRIB_AMT, TOTAL_ER_MAX_CONTRIB_PCT, 
//                                           UPPER_LIMIT_SALARY, XPIR_DT
//                                        FROM UEXT.CONTRIBUTION_STRUCTURE cs where CS.CONTRIBUTION_STRUC_GROUP_ID = csgid.CONTRIBUTION_STRUC_GROUP_ID ;
//                                        
//                                    INSERT INTO UEXT.CONTRIBUTION_STRUCTURE_LOOKUP (
//                                       CASE_KEY, CONTRIBUTION_STRUC_GROUP_ID, CONTRIBUTION_STRUC_LOOKUP_ID, 
//                                       MBGP_KEY, VARIATION_CD)  
//                                    SELECT 
//                                        v_case_key, v_new_csg_id, CONTRIBUTION_STRUCT_LOOKUP_SEQ.nextval , 
//                                           {1}, VARIATION_CD
//                                        FROM UEXT.CONTRIBUTION_STRUCTURE_LOOKUP csl where CSL.MBGP_KEY = {0} and CSL.CONTRIBUTION_STRUC_GROUP_ID =  csgid.CONTRIBUTION_STRUC_GROUP_ID;
//                                     
//                                end loop;
//                                
//                                end;";
//            return string.Format(sqlTemplate, sourceMemberGroupKey, targetMemberGroupKey);
//        }


        public string UpdateVariationSql(ContributionStructureLookup toUpdate)
        {
            const string sqlTemplate = @"
                update contribution_structure_lookup csl 
                set CSL.VARIATION_CD = '{0}' 
                where CSL.CONTRIBUTION_STRUC_LOOKUP_ID = {1};
                ";
            return string.Format(sqlTemplate, toUpdate.VariationCode, toUpdate.LookupId);
        }


        public string UpdateGroupSql(Database db, ContributionStructureLookup toUpdate)
        {
            if (!(toUpdate.ContributionGroupId > 0)) toUpdate.ContributionGroupId = SequenceGetter.GetNextVal(db, "CONTRIB_STRUCTURE_GROUP_ID_SEQ");

            const string sqlTemplate = @"
                update contribution_structure_lookup csl 
                set CSL.CONTRIBUTION_STRUC_GROUP_ID = {0} 
                where CSL.CONTRIBUTION_STRUC_LOOKUP_ID = {1};
                ";
            return string.Format(sqlTemplate, toUpdate.ContributionGroupId, toUpdate.LookupId);
        }


        /// <summary>
        /// render insert sql for a new lookup row.
        /// </summary>
        public string InsertCslSql(Database db, ContributionStructureLookup toInsert)
        {
            string vc = toInsert.VariationCode;
            int mk = toInsert.MbGpKey.Value;
            int ck = toInsert.CaseKey.Value;

            if (!(toInsert.LookupId > 0)) toInsert.LookupId = SequenceGetter.GetNextVal(db, "CONTRIBUTION_STRUCT_LOOKUP_SEQ");
            if (!(toInsert.ContributionGroupId > 0)) toInsert.ContributionGroupId = SequenceGetter.GetNextVal(db, "CONTRIB_STRUCTURE_GROUP_ID_SEQ");

            Contract.Assert(toInsert.LookupId>0);
            Contract.Assert(toInsert.ContributionGroupId>0);

            int lookupId = toInsert.LookupId.Value;
            int groupId = toInsert.ContributionGroupId;

            const string sql1 = @"
                INSERT INTO UEXT.CONTRIBUTION_STRUCTURE_LOOKUP 
                (CASE_KEY, CONTRIBUTION_STRUC_GROUP_ID, CONTRIBUTION_STRUC_LOOKUP_ID ,MBGP_KEY, VARIATION_CD)
                VALUES ( {0},{1},{2},{3},'{4}' );
                ";

            string result = String.Format(sql1, ck, groupId, lookupId, mk, vc);
            return result;
        }


        public string DeleteSql(ContributionStructureLookup toUpdate)
        {
            const string sqlTemplate = @"
                delete contribution_structure_lookup csl 
                where CSL.CONTRIBUTION_STRUC_LOOKUP_ID = {0};
                ";
            return string.Format(sqlTemplate, toUpdate.LookupId);
        }
    }
}
