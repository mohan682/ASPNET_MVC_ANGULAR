﻿using System;
using System.Collections.Generic;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    /// <summary>
    /// [STATELESS]
    /// </summary>
    public class AdminUserSQL :ISqlFullCrud<AdminUser, int>
    {
        internal const string SoftDeleteEmailPrefix = "[deactivated]";

        private const string SqlSelectTemplate = @"
    SELECT DISTINCT
        UC.USER_ACC_ID,
        UC.CHKN_SLT_HSH ,
        UC.USER_TYPE,
        UC.FORCEPASSWORDRESET,

        PER.NAMEID,
        PER.FIRSTNAME,
        PER.MIDNAME,
        PER.LASTNAME,
        PER.NAMEPREFIX,
        PER.SEXCD,

        AO.EMAILDATA,
        AO.NOTACTIVE,
        AO.XPIRDT,

        US.User_Name,

        UAA.Account_Id,

        j5.role_count
        
    FROM 
        PERSON PER
    INNER JOIN PARTYXREF PXR 
        ON PXR.NAMEID=PER.NAMEID AND PXR.REFTYPE='COMM'
    INNER JOIN ( select emaildata, ADDRID, XPIRDT, CASE WHEN XPIRDT < SYSDATE THEN 1 ELSE 0 END NOTACTIVE from ADDROTHER) AO 
        ON AO.ADDRID=PXR.REFKEY 
    INNER JOIN USER_ACC UC 
        ON UC.NAMEID=PER.NAMEID
    LEFT JOIN  USERS    US  
        ON UC.User_Acc_Id = US.Admin_User_Acc_Id

    LEFT JOIN      
     (SELECT User_Acc_Id,Account_ID FROM USER_ACC_ACCOUNT UAA1
     INNER JOIN  REF_CODES RC ON RC.DOMAIN_NAME='UEXT_ACCOUNT_TYPES' AND RC.DISABLE_CD = '0' 
     AND UPPER(RC.DESCRIPT)='AWD' AND UAA1.Account_TYPE=RC.REF_CD)  UAA  
        ON UC.User_Acc_Id = UAA.User_Acc_Id 

    LEFT JOIN (
        SELECT f2.User_Acc_Id, count(f2.User_Acc_Id) role_count 
            from PDI_USER_ACC_ROLE f2 
        group by f2.User_Acc_Id) J5
            
        ON j5.user_Acc_Id = Uc.User_Acc_Id
    ";

        public IEnumerable<string> SelectManySql(int dummyParentId, string appendWhereClauseWith = null)
        {
            if (!String.IsNullOrWhiteSpace(appendWhereClauseWith) && appendWhereClauseWith.ToLower().Contains("nameid ="))
                appendWhereClauseWith = appendWhereClauseWith.ToLower().Replace("nameid =", "PER.nameid =");

            string result = SqlSelectTemplate + string.Format(@"
                WHERE UC.USER_TYPE=5
                {0} 
                order by AO.EMAILDATA
                ", appendWhereClauseWith );

            yield return result;
        }

        public IEnumerable<string> SelectOneSql(int nameId)
        {
            string result = SqlSelectTemplate + string.Format(@"
                WHERE UC.USER_TYPE=5 
                AND PER.NAMEID={0}
                ", nameId );
            yield return result;
        }


        public string SelectDuplicatesSql(AdminUser toUse)
        {
            string result = @"
                            SELECT DISTINCT
                                UC.User_Acc_Id,
                                UC.Chkn_Slt_Hsh ,
                                UC.User_Type,
                                UC.Forcepasswordreset,
                                PER.Nameid,
                                PER.Firstname,
                                PER.Midname,
                                PER.Lastname,
                                PER.Nameprefix,
                                PER.Sexcd,
                                other.Emaildata,
                                CASE WHEN Xpirdt < SYSDATE THEN 1 ELSE 0 END Notactive,
                                other.Xpirdt,
                                US.User_Name,
                                J5.Role_Count,
                                other.primary
                            FROM 
        		                        Person		PER

                            INNER JOIN    uext.V_party_addrother    other
                                ON other.Nameid=PER.Nameid

                            LEFT JOIN	User_Acc	UC		ON UC.Nameid=PER.Nameid
                            LEFT JOIN	Users		US		ON UC.User_Acc_Id = US.Admin_User_Acc_Id
                            LEFT JOIN	(
					                        SELECT f2.User_Acc_Id, COUNT(f2.User_Acc_Id) role_count	FROM Pdi_User_Acc_Role F2 GROUP BY F2.User_Acc_Id
                                        )			J5		ON J5.user_Acc_Id = UC.User_Acc_Id
                            WHERE
    	                        LOWER(other.Emaildata) = LOWER({0})
                            and primary = 1 and contact = 1 and (Xpirdt is null or not(Xpirdt < SYSDATE))
";

            return String.Format(result, toUse.UserName.SqlQuotify());
        }


        public IEnumerable<string> DetectAnyDependants(AdminUser model)
        {
            yield break;
        }


        public IEnumerable<string> UpdateSql(AdminUser adminUser)
        {
            string update1 = string.Format(@"
                UPDATE PERSON
                    SET FIRSTNAME={1}, MIDNAME={2}, LASTNAME={3}, NAMEPREFIX={4}
                WHERE 
                    NAMEID={0}",
                adminUser.NameId, adminUser.FirstName.SqlQuotify(), adminUser.MidName.SqlQuotify(), adminUser.LastName.SqlQuotify(), adminUser.Title.IntoSqlValue());

            yield return update1;


            string update2 = string.Format(@"
                UPDATE ADDROTHER
                    SET EMAILDATA=LOWER({1})
                WHERE
                    ADDRID=(
                        SELECT PXR.REFKEY FROM PERSON PER
                            INNER JOIN PARTYXREF PXR ON PXR.NAMEID=PER.NAMEID AND PXR.REFTYPE='COMM'                               
                            INNER JOIN USER_ACC UC ON UC.NAMEID=PER.NAMEID
                        WHERE UC.USER_TYPE=5 and PER.NAMEID={0}
                    )",
                adminUser.NameId, adminUser.UserName.SqlQuotify());

            yield return update2;


            if (adminUser.PasswordModeOn)
            {
                string update3 = string.Format(@"
                UPDATE UEXT.USER_ACC SET                                                   
                    CHKN_SLT_HSH = {0}
                WHERE USER_ACC_ID={1}",
                adminUser.GetSecurePassword().SqlQuotify(), adminUser.AccountId);

                yield return update3;
            }

            yield return string.Format(@" UPDATE UEXT.USER_ACC SET ForcePassWordReset = '{0}' WHERE USER_ACC_ID={1}", adminUser.ForcePasswordChange ? "1" : "", adminUser.AccountId);

            string update4 = string.Format(@"
                UPDATE USERS 
                    SET  Admin_User_Acc_Id = NULL WHERE Admin_User_Acc_Id = NVL({0}, -100);
                UPDATE USERS
                    SET  Admin_User_Acc_Id = {0} WHERE User_Name = {1}",
              adminUser.AccountId, adminUser.DCorUserName.SqlQuotify());

            yield return update4;

            string update5 = string.Format(@"DELETE USER_ACC_ACCOUNT WHERE USER_ACC_ID={0} AND ACCOUNT_TYPE=
                (SELECT REF_CD FROM REF_CODES WHERE DOMAIN_NAME='UEXT_ACCOUNT_TYPES' AND DISABLE_CD = '0' AND UPPER(DESCRIPT)='AWD')", adminUser.AccountId);

            yield return update5;

            if (!string.IsNullOrEmpty(adminUser.AwdUserId))
            {
                string update6 = string.Format(@" INSERT INTO USER_ACC_ACCOUNT (USER_ACC_ACCOUNT_ID, USER_ACC_ID, ACCOUNT_TYPE,ACCOUNT_ID) 
                                    VALUES (USER_ACC_ACCOUNT_ID_SEQ.NEXTVAL,{0},(SELECT REF_CD FROM REF_CODES WHERE DOMAIN_NAME='UEXT_ACCOUNT_TYPES' 
                                        AND DISABLE_CD = '0' AND UPPER(DESCRIPT)='AWD'),{1})", adminUser.AccountId, adminUser.AwdUserId.SqlQuotify());

                yield return update6;
            }
        }


        public IEnumerable<string> InsertSql(AdminUser adminUser)
        {
            const string sqlTemplate = @"
                DECLARE
		                lEmailAddr				VARCHAR2(50) := '{0}';
                        lPassWord				VARCHAR2(50) := '{1}';
                        lNamePrefix				VARCHAR2(50) := {2};                    
                        lFirstName				VARCHAR2(50) := {3};                    
                        lMidName				VARCHAR2(50) := {4};                    
                        lLastName				VARCHAR2(50) := {5};    
                        lForcePasswordReset		VARCHAR2(50) := '{6}';                                                        
                        lDCorUserNm				VARCHAR2(50) := '{7}'; 
                        lAwdUserID				VARCHAR2(500) := {10};           
                                                          
                        lOprnDtTm 				DATE			:= SYSDATE;
		                lTempStr    			VARCHAR2(50);
                        NAME_ID					NUMBER(8) 		:= NULL;
                        lAccId					User_Acc.User_Acc_Id%TYPE; 
                        lAddrothid				Addrother.Addrotherid%TYPE;        
                BEGIN  
                        lTempStr := SUBSTR(TRANSLATE(UPPER(SUBSTR(lEmailAddr, 1, INSTR(lEmailAddr, '.', 1))), 'BAEIOU.@-_', 'B'),1,20);
                        BEGIN
                            SELECT		PER.NAMEID,	O.ADDROTHERID,	U.USER_ACC_ID 
                                INTO	NAME_ID,	LADDROTHID,		lAccId
                            FROM        PERSON PER,		ADDROTHER    O,                PARTYXREF    X,		USER_ACC    U
                            WHERE
					                O.ADDRID        = X.REFKEY
                            AND		X.REFTYPE        = 'COMM'
                            AND		PER.NAMEID        = X.NAMEID
                            AND		PER.NAMEID        = U.NAMEID AND U.USER_TYPE=5
                            AND		LOWER(O.EMAILDATA)    = LOWER(lEmailAddr);

			                DELETE FROM User_Acc_Default_Scheme		WHERE User_Acc_Id = NVL(lAccId, -100);
			                DELETE FROM Pdi_User_Acc_Role			WHERE User_Acc_Id = NVL(lAccId, -100);
                            DELETE FROM User_Security_Questions		WHERE User_Acc_Id = NVL(lAccId, -100);
                            DELETE FROM User_Acc_Password_History	WHERE User_Acc_Id = NVL(lAccId, -100);
                            DELETE FROM User_Action					WHERE User_Acc_Id = NVL(lAccId, -100);
                            DELETE FROM User_Acc_Session			WHERE User_Acc_Id = NVL(lAccId, -100);
                            DELETE FROM USER_ACC_ACCOUNT			WHERE User_Acc_Id = NVL(lAccId, -100);
                            DELETE FROM User_Acc					WHERE User_Acc_Id = NVL(lAccId, -100);
                            DELETE FROM PartyXRef					WHERE NAMEID = NAME_ID;
                            DELETE FROM Uext_Addrother				WHERE ADDROTHERID = LADDROTHID;
                            DELETE FROM Addrother					WHERE ADDROTHERID = LADDROTHID;
                            DELETE FROM PersonCompass				WHERE NAMEID = NAME_ID;        
                            DELETE FROM Person  					WHERE NAMEID = NAME_ID;                                              
                        EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                                NAME_ID := {9};  
                
                                INSERT INTO PARTY	(NAMEID,		CLIENT_ID,		PARTYTYPE, EFFECTDT,      SEARCHKEY) VALUES
                                                    (NAME_ID,		NAME_ID,		'P',       lOprnDtTm - 1, lTempStr);
                        END;    
                                                                            
                        INSERT INTO PERSON ( NAMEID,		CLIENT_ID,	NamePrefix,		FIRSTNAME,		LASTNAME,       MIDNAME,        PASSPORT_NO)  VALUES 
                                            ( NAME_ID,		NAME_ID,	lNamePrefix,	lFirstName,		lLastName,		lMidName,		'ADMIN');

                        INSERT INTO PersonCompass ( NAMEID,		LANG_PREF_CD,	MAR_STAT_CD)  VALUES  ( NAME_ID,	'1',	'9');
                          
                        INSERT INTO Addrother (AddrotherId,           EmailType, EmailData,		AddrId,      		EffectDt,      Last_Mod_Dt, Last_Mod_User)
                        VALUES                (ADDROTHER_SEQ.NEXTVAL, '03',      lEmailAddr,	ADDR_SEQ.NEXTVAL,	LOPRNDTTM - 1, LOPRNDTTM,   'DCorumWeb' );
                
                        INSERT INTO Uext_Addrother (AddrotherId, Primary, Contact) VALUES    (ADDROTHER_SEQ.CURRVAL, 1, 1);

                        INSERT INTO PartyXRef (NameId, RefKey, RefType) VALUES (NAME_ID, ADDR_SEQ.CURRVAL, 'COMM');

		                lAccId := {8};
                        INSERT INTO User_Acc    (User_Acc_Id,   	NameId,     User_Type, Password_Last_Changed,  ForcePasswordReset,	Chkn_Slt_Hsh) VALUES 
                                                (lAccId,			NAME_ID,    5,         SYSDATE,                lForcePasswordReset, lPassWord);

		                UPDATE Users SET  Admin_User_Acc_Id = lAccId WHERE User_Name = lDCorUserNm;

                        IF length(lAwdUserID)>0 THEN
                           
                          INSERT INTO USER_ACC_ACCOUNT (USER_ACC_ACCOUNT_ID, USER_ACC_ID, ACCOUNT_TYPE,ACCOUNT_ID) 
                           VALUES (USER_ACC_ACCOUNT_ID_SEQ.NEXTVAL,lAccId,(SELECT REF_CD FROM REF_CODES WHERE DOMAIN_NAME='UEXT_ACCOUNT_TYPES' AND DISABLE_CD = '0' AND UPPER(DESCRIPT)='AWD'),lAwdUserID);
                              
                        END IF;
                END;
            ";

            string userAccoundKey = (adminUser.AccountId > 0) ? adminUser.AccountId.ToString() : "USER_ACC_ID_SEQ.NEXTVAL";
            string pKey = (adminUser.NameId > 0) ? adminUser.NameId.ToString() : "COMPASS.PRTY_SEQ.NEXTVAL";

            string result = string.Format(sqlTemplate,
                adminUser.UserName, adminUser.GetSecurePassword(), adminUser.Title.IntoSqlValue(),
                adminUser.FirstName.SqlQuotify(), adminUser.MidName.SqlQuotify(), adminUser.LastName.SqlQuotify(),
                adminUser.ForcePasswordChange ? "1" : "", adminUser.DCorUserName,
                userAccoundKey, pKey
                , adminUser.AwdUserId.SqlQuotify()
                );

            yield return result;
        }

        public IEnumerable<string> DeleteSql(AdminUser adminUser)
        {
            const string sqlTemplate = @"
DECLARE
	lEmailAddr				VARCHAR2(50) := {0};
    NAME_ID					NUMBER(8) 		:= {1};
    lAccId					User_Acc.User_Acc_Id%TYPE; 
    lAddrothid				Addrother.Addrotherid%TYPE;        
BEGIN        
    SELECT
        O.ADDROTHERID,	U.USER_ACC_ID 
    INTO
        LADDROTHID,		lAccId
    FROM
        PERSON PER,
        ADDROTHER    O,
        PARTYXREF    X,
        USER_ACC    U
    WHERE
			O.ADDRID        = X.REFKEY
    AND		X.REFTYPE        = 'COMM'
    AND		PER.NAMEID        = X.NAMEID
    AND		PER.NAMEID        = U.NAMEID AND U.USER_TYPE=5
    --AND		U.NameId		= NAME_ID
    AND		LOWER(O.EMAILDATA)    = LOWER(lEmailAddr);

                  
	DELETE FROM User_Acc_Default_Scheme		WHERE User_Acc_Id = NVL(lAccId, -100);
	DELETE FROM Pdi_User_Acc_Role			WHERE User_Acc_Id = NVL(lAccId, -100);
    DELETE FROM User_Acc_Session			WHERE User_Acc_Id = NVL(lAccId, -100);
    DELETE FROM USER_ACC_ACCOUNT			WHERE User_Acc_Id = NVL(lAccId, -100);

    UPDATE Users SET  Admin_User_Acc_Id = NULL WHERE Admin_User_Acc_Id = NVL(lAccId, -100);


    UPDATE ADDROTHER
        SET XPIRDT=sysdate-1
        ,LAST_MOD_DT=sysdate
        ,LAST_MOD_USER='DcorumWeb'
        ,EMAILDATA = '[deactivated]'|| lEmailAddr                                                
    WHERE ADDRID=(
        SELECT PXR.REFKEY FROM PERSON PER
        INNER JOIN PARTYXREF PXR 
            ON PXR.NAMEID=PER.NAMEID AND PXR.REFTYPE='COMM'                               
        INNER JOIN USER_ACC UC
            ON UC.NAMEID=PER.NAMEID
        WHERE UC.USER_TYPE=5 and PER.NAMEID=NAME_ID
        )
        and LOWER(EMAILDATA)=LOWER(lEmailAddr);

    /*
    DELETE FROM User_Security_Questions		WHERE User_Acc_Id = NVL(lAccId, -100);
    DELETE FROM User_Acc_Password_History	WHERE User_Acc_Id = NVL(lAccId, -100);
    DELETE FROM User_Action					WHERE User_Acc_Id = NVL(lAccId, -100);
                
    DELETE FROM User_Acc					WHERE User_Acc_Id = NVL(lAccId, -100);
    DELETE FROM PartyXRef					WHERE NAMEID = NAME_ID;
    DELETE FROM Uext_Addrother				WHERE ADDROTHERID = LADDROTHID;
    DELETE FROM Addrother					WHERE ADDROTHERID = LADDROTHID;
    DELETE FROM PersonCompass				WHERE NAMEID = NAME_ID;        
    DELETE FROM Person  					WHERE NAMEID = NAME_ID; 
    */                                             
END;";

            string result = string.Format(sqlTemplate, adminUser.UserName.SqlQuotify(), adminUser.NameId);

            yield return result;
        }


        public string ForceReRegDuringNextLogin(AdminUser adminUser)
        {
            const string sSQL = @"
                BEGIN
                    UPDATE User_Acc SET Locked = NULL, ForcePassWordReset = 1, Chkn_Slt_Hsh = {1}   WHERE User_Acc_Id = {0};
                    DELETE FROM User_Security_Questions WHERE User_Acc_Id = {0};
                END;
            ";

            string result = String.Format(sSQL, adminUser.AccountId, adminUser.GetSecurePassword().SqlQuotify());
            return result;
        }

        /// <summary>
        /// return "USER_ACC_ID_SEQ"
        /// </summary>
        /// <returns>"USER_ACC_ID_SEQ"</returns>
        public string GetSequenceIdForInsert()
        {
            return "USER_ACC_ID_SEQ";
        }

        internal string IsAwdUserAlreadyMapped(AdminUser adminUser)
        {
            return string.Format(@"SELECT * FROM USER_ACC_ACCOUNT UAC
                INNER JOIN REF_CODES RC ON RC.DOMAIN_NAME='UEXT_ACCOUNT_TYPES' AND UAC.ACCOUNT_TYPE=RC.REF_CD AND RC.DISABLE_CD = '0'
                INNER JOIN USER_ACC UC ON UC.USER_ACC_ID=UAC.USER_ACC_ID
                WHERE uc.user_acc_id<>{0} and upper(uac.ACCOUNT_ID)=UPPER({1})", adminUser.AccountId, adminUser.AwdUserId.SqlQuotify());
        }
    }
}
