﻿using System;
using System.Diagnostics.Contracts;
using Dcorum.BusinessLayer.Entities.Contributions;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public interface IContributionDetailSqlBuilder
    {
        string DeleteViaFKeySql(int groupId);
        string InsertViaGroupId(int sourceGroupId, int newGroupId);
    }


    public class ContributionStructureDetailSql : IContributionDetailSqlBuilder
    {
        private const string TableName = "contribution_structure";
        private const string PrimaryKey = "CONTRIBUTION_STRUC_GROUP_ID";

        private const string SelectTemplate1 = @"
        select 
        CS.CONTRIBUTION_STRUC_GROUP_ID as ID, 
        CS.CONTRIBUTION_STRUCTURE_ID as DetailId, 
        CS.AGE_TO, CS.DATE_TO, CS.CONTRIBUTION_TO, CS.CORE, CS.EFF_DT, CS.MATCH, CS.MAX_EE_CONT_MATCHED, 
        CS.MIN_EE_CONT, CS.SALARY_TO, CS.SERVICE_TO, CS.TOTAL_ER_MAX_CONTRIB_AMT, CS.TOTAL_ER_MAX_CONTRIB_PCT, 
        CS.UPPER_LIMIT_SALARY, nvl(CS.XPIR_DT, to_date('31/12/2199', 'dd/mm/yyyy')) as XPIR_DT 
        from contribution_structure cs
        ";


        public static string SelectViaFKeySql(int contributionScaleGroupId)
        {
            const string sqlTempalte = SelectTemplate1 + "where CS.CONTRIBUTION_STRUC_GROUP_ID = {0}";
            return string.Format(sqlTempalte, contributionScaleGroupId);
        }


        public static string SelectViaPKeySql(int contributionScaleId)
        {
            const string sqlTempalte = SelectTemplate1 + "where CS.CONTRIBUTION_STRUCTURE_ID = {0}";
            return string.Format(sqlTempalte, contributionScaleId);
        }


        public static string CheckForDuplicateSql(int parentId, int ageTo, int serviceYearTo, decimal contributionTo,
            Int64 salaryTo, DateTime? dateTo, int detailId)
        {
            string sql = @"select count(CS.CONTRIBUTION_STRUCTURE_ID) as COUNTID from contribution_structure cs 
                                where CS.CONTRIBUTION_STRUC_GROUP_ID = {0}
                                and CS.AGE_TO = {1}
                                and CS.DATE_TO  {2}
                                and CS.CONTRIBUTION_TO = {3}
                                and CS.SALARY_TO = {4}
                                and CS.SERVICE_TO = {5}";

            if (detailId > 0)
                sql = string.Concat(sql, " and not CS.CONTRIBUTION_STRUCTURE_ID = ", detailId);

            string dateToString = dateTo.HasValue
                ? string.Concat("= to_date('", dateTo.Value.ToShortDateString(), "', 'dd/mm/yyyy')")
                : "is null";

            return string.Format(sql, parentId, ageTo, dateToString, contributionTo, salaryTo, serviceYearTo);
        }

        public static string UpdateSql(int detailId, int ageTo, int serviceTo,
            decimal contributionTo, DateTime? dateTo, Int64 salaryTo, decimal minEmployeeContribution,
            decimal coreContribution, decimal match, decimal maxMatch, decimal totalMaxEmployerContributionPercentage,
            decimal totalMaxEmploerContributionAmount, Int64 salaryLimit, DateTime effDate, DateTime expiryDate)
        {
            const string sql = @"UPDATE UEXT.CONTRIBUTION_STRUCTURE
                                    SET    AGE_TO                    = {0},
                                           CONTRIBUTION_TO           = {1},
                                           CORE                      = {2},
                                           DATE_TO                   = {3},
                                           EFF_DT                    = {4},
                                           MATCH                     = {5},
                                           MAX_EE_CONT_MATCHED       = {6},
                                           MIN_EE_CONT               = {7},
                                           SALARY_INC_TYPE           = {8},
                                           SALARY_TO                 = {9},
                                           SERVICE_TO                = {10},
                                           TOTAL_ER_MAX_CONTRIB_AMT  = {11},
                                           TOTAL_ER_MAX_CONTRIB_PCT  = {12},
                                           UPPER_LIMIT_SALARY        = {13},
                                           XPIR_DT                   = {14}
                                    WHERE  CONTRIBUTION_STRUCTURE_ID = {15}";

            string dateToString = dateTo.HasValue
                ? string.Concat("to_date('", dateTo.Value.ToShortDateString(), "', 'dd/mm/yyyy')")
                : "null";

            string effectiveDateString = string.Concat("to_date('", effDate.ToShortDateString(), "', 'dd/mm/yyyy')");
            string expiryDateString = string.Concat("to_date('", expiryDate.ToShortDateString(), "', 'dd/mm/yyyy')");

            return string.Format(sql, ageTo, contributionTo, coreContribution, dateToString, effectiveDateString, match,
                maxMatch, minEmployeeContribution, "null", salaryTo, serviceTo, totalMaxEmploerContributionAmount,
                totalMaxEmployerContributionPercentage, salaryLimit, expiryDateString, detailId);
        }


        public static string Insert(Database db, ContributionStructureDetail toInsert)
        {
            Contract.Assert(toInsert.ParentId>0);

            if (!(toInsert.Id > 0)) toInsert.Id = SequenceGetter.GetNextVal(db, "Contribution_Structure_SEQ");
 
            const string sqlTemplate = @"
                INSERT INTO UEXT.CONTRIBUTION_STRUCTURE (AGE_TO,CONTRIBUTION_STRUC_GROUP_ID,CONTRIBUTION_TO,CORE,DATE_TO,EFF_DT,CONTRIBUTION_STRUCTURE_ID,MATCH,MAX_EE_CONT_MATCHED,MIN_EE_CONT,
                    SALARY_INC_TYPE,SALARY_TO,SERVICE_TO,TOTAL_ER_MAX_CONTRIB_AMT,TOTAL_ER_MAX_CONTRIB_PCT,UPPER_LIMIT_SALARY,XPIR_DT)
                VALUES ({0},{15},{1},{2},{3},{4},{16},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14})
                ";

            return string.Format(sqlTemplate,
                toInsert.MemberAgeTo, toInsert.MemberContributionTo, toInsert.EmployerCoreContribution, toInsert.DateTo.ToSqlShortDateString(), toInsert.EffectiveDate.ToSqlShortDateString(),
                toInsert.EmployerMatchPercentage, toInsert.MaxEmployeeMatchedRate, toInsert.MinEmployeeContribution, "null", toInsert.MemberContributionTo,
                toInsert.MemberServiceYearTo, toInsert.TotalMaxEmployerContributionAmout, toInsert.TotalMaxEmployerContributionPercentage, toInsert.SalaryLimit, toInsert.ExpiryDate.ToSqlShortDateString(),
                toInsert.ParentId, toInsert.Id);
        }


        public static string DeleteViaPKeySql(int detailId)
        {
            const string sql = @"delete from contribution_structure cs where CS.CONTRIBUTION_STRUCTURE_ID = {0}";
            return string.Format(sql, detailId);
        }


        public string DeleteViaFKeySql(int groupId)
        {
            const string sql = @"delete from contribution_structure cs where CS.CONTRIBUTION_STRUC_GROUP_ID = {0}";
            return string.Format(sql, groupId);
        }


        public string InsertViaGroupId(int sourceGroupId, int newGroupId)
        {
            const string sql1 = @"
            INSERT INTO UEXT.CONTRIBUTION_STRUCTURE (
                AGE_TO, CONTRIBUTION_STRUCTURE_ID, CONTRIBUTION_STRUC_GROUP_ID, 
                CONTRIBUTION_TO, CORE, DATE_TO, 
                EFF_DT, MATCH, MAX_EE_CONT_MATCHED, 
                MIN_EE_CONT, SALARY_INC_TYPE, SALARY_TO, 
                SERVICE_TO, TOTAL_ER_MAX_CONTRIB_AMT, TOTAL_ER_MAX_CONTRIB_PCT, 
                UPPER_LIMIT_SALARY, XPIR_DT) 
            SELECT 
                AGE_TO, CONTRIBUTION_STRUCTURE_SEQ.nextval, {1}, 
                CONTRIBUTION_TO, CORE, DATE_TO, 
                EFF_DT, MATCH, MAX_EE_CONT_MATCHED, 
                MIN_EE_CONT, SALARY_INC_TYPE, SALARY_TO, 
                SERVICE_TO, TOTAL_ER_MAX_CONTRIB_AMT, TOTAL_ER_MAX_CONTRIB_PCT, 
                UPPER_LIMIT_SALARY, XPIR_DT
            FROM UEXT.CONTRIBUTION_STRUCTURE cs 
            WHERE CS.CONTRIBUTION_STRUC_GROUP_ID = {0}
            ";
            return String.Format(sql1, sourceGroupId, newGroupId);
        }

    }
}
