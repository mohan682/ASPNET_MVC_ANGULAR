﻿using System;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class ServiceTaskQueueSQL
    {
        public static string GetInsertQuery(int serviceTaskId)
        {
            return $"INSERT INTO SERVICE_TASK_QUEUE(SERVICE_TASK_QUEUE_ID,SERVICE_TASK_ID,SCHEDULE_DATE,LOCKED,ACTIVE,STATUS_CD) Values(SERVICE_TASK_QUEUE_ID_Seq.NEXTVAL,{serviceTaskId},sysdate,'0','1','PE')";
        }

        public static string GetServiceTaskIdQuery()
        {
            return "SELECT Service_Task_Id FROM Event_Trigger_Selection ets INNER JOIN  Event_Trigger et ON ets.EVENT_TRIGGER_SELECTION_ID = et.EVENT_TRIGGER_SELECTION_ID Where SHORT_DESCRIPTION='Schemes for eValue Synch'";
        }
    }
}
