﻿using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class OCPOptionsSQL : ISqlFullCrud<OCPOptions, int>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected OCPOptionsSQL() { }

        public IEnumerable<string> DeleteSql(OCPOptions toDelete)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> InsertSql(OCPOptions toInsert)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> DetectAnyDependants(OCPOptions model)
        {
            yield break;
        }

        /// <summary>
        /// return "USER_ACC_ID_SEQ"
        /// </summary>
        /// <returns>"USER_ACC_ID_SEQ"</returns>
        public string GetSequenceIdForInsert()
        {
            // return "USER_ACC_ID_SEQ";

            throw new NotImplementedException();
        }

      
        public IEnumerable<string> UpdateSql(OCPOptions toUpdate)
        {

            string sql = string.Format("UPDATE UEXT_BILL_GRP " + 
                                        "SET ABP_ED_SCHEME_ID = {0}, " + 
                                        "ABP_ED_PAYROLL_ID = {1}, " + 
                                        "ABP_ED_PAYING_OFFICE_ID = {2}, " + 
                                        "ABP_ED_NI_NUMBER = {3}, " + 
                                        "ABP_ED_TITLE = {4}, " + 
                                        "ABP_ED_SURNAME = {5}, " + 
                                        "ABP_ED_FORNAMES = {6}, " + 
                                        "ABP_ED_DOB = {7}, " + 
                                        "ABP_ED_SEX = {8}, " + 
                                        "ABP_ED_EARNINGS = {9}, " + 
                                        "ABP_ED_AC_SINGLE_PAYMENT = {10}, " + 
                                        "ABP_ED_EM_SINGLE_PAYMENT = {11}, " + 
                                        "ABP_ED_AC_CORE_PAYMENT = {12}, " + 
                                        "ABP_ED_EM_CORE_PAYMENT = {13}, " + 
                                        "ABP_ED_AC_MATCHING_PAYMENT = {14}, " + 
                                        "ABP_ED_EM_MATCHING_PAYMENT = {15}, " + 
                                        "ABP_ED_AVC_PAYMENT = {16}, " + 
                                        "ABP_ED_EM_SPECIAL_PAYMENT = {17}, " + 
                                        "ABP_ED_AC_REBATE = {18}, " + 
                                        "ABP_ED_EM_REBATE = {19}, " + 
                                        "ABP_ED_SUSPENDED_DATE = {20}, " + 
                                        "ABP_ED_LEAVING_DATE = {21}, " + 
                                        "ABP_ED_JOINING_DATE = {22}, " + 
                                        "ABP_ED_REASON_CODE = {23}, " +
                                        "ABP_ED_WORKPLACE_ISA = {24}, " +                                        
                                        "ABP_ED_WORKPLACE_ISA_REASON_CD = {25} " +                                        
                                        "WHERE BGRP_KEY = {26}",
                                        toUpdate.SchemeId.SqlQuotify(),
                                        toUpdate.PayrollId.SqlQuotify(),
                                        toUpdate.PayingOfficeId.SqlQuotify(),
                                        toUpdate.NINo.SqlQuotify(),
                                        toUpdate.Title.SqlQuotify(),
                                        toUpdate.Surname.SqlQuotify(),
                                        toUpdate.Forenames.SqlQuotify(),
                                        toUpdate.DOB.SqlQuotify(),
                                        toUpdate.Sex.SqlQuotify(),
                                        toUpdate.Earnings.SqlQuotify(),
                                        toUpdate.ACSinglePayment.SqlQuotify(),
                                        toUpdate.EMSinglePayment.SqlQuotify(),
                                        toUpdate.ACCorePayment.SqlQuotify(),
                                        toUpdate.EMCorePayment.SqlQuotify(),
                                        toUpdate.ACMatchingPayment.SqlQuotify(),
                                        toUpdate.EMMatchingPayment.SqlQuotify(),
                                        toUpdate.AVCPayment.SqlQuotify(),
                                        toUpdate.EMSpecialPayment.SqlQuotify(),
                                        toUpdate.ACRebate.SqlQuotify(),
                                        toUpdate.EMRebate.SqlQuotify(),
                                        toUpdate.SuspendedDate.SqlQuotify(),
                                        toUpdate.LeavingDate.SqlQuotify(),
                                        toUpdate.JoiningDate.SqlQuotify(),
                                        toUpdate.ReasonCode.SqlQuotify(),
                                        toUpdate.WorkplaceISA.SqlQuotify(),
                                        toUpdate.WorkplaceIsaReasonCode.SqlQuotify(),
                                        toUpdate.BillingGroupId
                                        );
                                                  
            
            yield return sql;
        }


        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {        
            var bgrpKey = parentKey;

            string sql1 = @"select 
                            UBG.BGRP_KEY,
                            BG.DESCRIPT,
                            UBG.ABP_ED_SCHEME_ID,
                            UBG.ABP_ED_PAYROLL_ID,
                            UBG.ABP_ED_PAYING_OFFICE_ID,
                            UBG.ABP_ED_NI_NUMBER,
                            UBG.ABP_ED_TITLE,
                            UBG.ABP_ED_SURNAME,
                            UBG.ABP_ED_FORNAMES,
                            UBG.ABP_ED_DOB,
                            UBG.ABP_ED_SEX,
                            UBG.ABP_ED_EARNINGS,
                            UBG.ABP_ED_AC_SINGLE_PAYMENT,
                            UBG.ABP_ED_EM_SINGLE_PAYMENT,
                            UBG.ABP_ED_AC_CORE_PAYMENT,
                            UBG.ABP_ED_EM_CORE_PAYMENT ,
                            UBG.ABP_ED_AC_MATCHING_PAYMENT,
                            UBG.ABP_ED_EM_MATCHING_PAYMENT,
                            UBG.ABP_ED_AVC_PAYMENT,
                            UBG.ABP_ED_EM_SPECIAL_PAYMENT,
                            UBG.ABP_ED_AC_REBATE,
                            UBG.ABP_ED_EM_REBATE,
                            UBG.ABP_ED_SUSPENDED_DATE,
                            UBG.ABP_ED_LEAVING_DATE,
                            UBG.ABP_ED_JOINING_DATE,
                            UBG.ABP_ED_REASON_CODE,
                            UBG.ABP_ED_WORKPLACE_ISA,
                            UBG.ABP_ED_WORKPLACE_ISA_REASON_CD,
                            from uext_bill_grp ubg
                            inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY

                            where bg.BGRP_KEY = {" + bgrpKey;
   
            yield return sql1 ;
        }


        public string SelectDuplicatesSql(OCPOptions similar)
        {
            return null;
        }


        public IEnumerable<string> SelectOneSql(int bgrpKey)
        {

            string sql1 = string.Format(@"select 
                            UBG.BGRP_KEY,
                            BG.DESCRIPT,
(select case when UBG.ABP_ED_SCHEME_ID not in ('W','R','N') then 'R' else UBG.ABP_ED_SCHEME_ID end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_SCHEME_ID,
(select case when UBG.ABP_ED_PAYROLL_ID not in ('W','R','N') then 'W' else UBG.ABP_ED_PAYROLL_ID end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_PAYROLL_ID, 
(select case when UBG.ABP_ED_PAYING_OFFICE_ID not in ('W','R','N') then 'R' else UBG.ABP_ED_PAYING_OFFICE_ID end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_PAYING_OFFICE_ID,
(select case when UBG.ABP_ED_NI_NUMBER not in ('W','R','N') then 'W' else UBG.ABP_ED_NI_NUMBER end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_NI_NUMBER,
(select case when UBG.ABP_ED_TITLE not in ('W','R','N') then 'W' else UBG.ABP_ED_TITLE end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_TITLE,
(select case when UBG.ABP_ED_SURNAME not in ('W','R','N') then 'W' else UBG.ABP_ED_SURNAME end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_SURNAME,                            
(select case when UBG.ABP_ED_FORNAMES not in ('W','R','N') then 'W' else UBG.ABP_ED_FORNAMES end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_FORNAMES,                         
(select case when UBG.ABP_ED_DOB not in ('W','R','N') then 'W' else UBG.ABP_ED_DOB end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_DOB,                               
(select case when UBG.ABP_ED_SEX not in ('W','R','N') then 'W' else UBG.ABP_ED_SEX end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_SEX,  
(select case when UBG.ABP_ED_EARNINGS not in ('W','R','N') then 'W' else UBG.ABP_ED_EARNINGS end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_EARNINGS,                              
(select case when UBG.ABP_ED_AC_SINGLE_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_AC_SINGLE_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_AC_SINGLE_PAYMENT,  
(select case when UBG.ABP_ED_AC_SINGLE_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_AC_SINGLE_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_AC_SINGLE_PAYMENT,  
(select case when UBG.ABP_ED_EM_SINGLE_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_EM_SINGLE_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_EM_SINGLE_PAYMENT,    
(select case when UBG.ABP_ED_EM_SINGLE_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_EM_SINGLE_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_EM_SINGLE_PAYMENT,                        
(select case when UBG.ABP_ED_AC_CORE_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_AC_CORE_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_AC_CORE_PAYMENT,                              
(select case when UBG.ABP_ED_EM_CORE_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_EM_CORE_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_EM_CORE_PAYMENT,                            
(select case when UBG.ABP_ED_AC_MATCHING_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_AC_MATCHING_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_AC_MATCHING_PAYMENT,                             
(select case when UBG.ABP_ED_EM_MATCHING_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_EM_MATCHING_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_EM_MATCHING_PAYMENT,                              
(select case when UBG.ABP_ED_AVC_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_AVC_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_AVC_PAYMENT,                                                      
(select case when UBG.ABP_ED_EM_SPECIAL_PAYMENT not in ('W','R','N') then 'W' else UBG.ABP_ED_EM_SPECIAL_PAYMENT end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_EM_SPECIAL_PAYMENT,                              
(select case when UBG.ABP_ED_AC_REBATE not in ('W','R','N') then 'W' else UBG.ABP_ED_AC_REBATE end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_AC_REBATE,
(select case when UBG.ABP_ED_EM_REBATE not in ('W','R','N') then 'W' else UBG.ABP_ED_EM_REBATE end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_EM_REBATE,                             
(select case when UBG.ABP_ED_SUSPENDED_DATE not in ('W','R','N') then 'R' else UBG.ABP_ED_SUSPENDED_DATE end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_SUSPENDED_DATE,
(select case when UBG.ABP_ED_LEAVING_DATE not in ('W','R','N') then 'W' else UBG.ABP_ED_LEAVING_DATE end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_LEAVING_DATE, 
(select case when UBG.ABP_ED_JOINING_DATE not in ('W','R','N') then 'R' else UBG.ABP_ED_JOINING_DATE end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_JOINING_DATE,  
(select case when UBG.ABP_ED_REASON_CODE not in ('W','R','N') then 'W' else UBG.ABP_ED_REASON_CODE end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_REASON_CODE,
(select case when UBG.ABP_ED_WORKPLACE_ISA not in ('W','R','N') then 'N' else UBG.ABP_ED_WORKPLACE_ISA end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_WORKPLACE_ISA,
(select case when UBG.ABP_ED_WORKPLACE_ISA_REASON_CD not in ('W','R','N') then 'N' else UBG.ABP_ED_WORKPLACE_ISA_REASON_CD end
  from uext_bill_grp ubg
  inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
  where bg.BGRP_KEY = {0})as ABP_ED_WORKPLACE_ISA_REASON_CD
  from uext_bill_grp ubg
                            inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY
                            where bg.BGRP_KEY = {0}", bgrpKey);

            yield return sql1;
        }


        public string SelectMany(int bgrpKey)
        {
            string sql = @"select 
                            BG.DESCRIPT,
                            UBG.*
                            from uext_bill_grp ubg
                            inner join bill_grp bg on UBG.BGRP_KEY = BG.BGRP_KEY

                            where bg.BGRP_KEY = " + bgrpKey;

            return sql;
        }
    }

}
