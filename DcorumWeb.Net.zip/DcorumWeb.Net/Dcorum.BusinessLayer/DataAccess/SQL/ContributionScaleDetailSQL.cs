﻿using System;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class ContributionScaleDetailSql : IContributionDetailSqlBuilder
    {
        private const string SelectTemplate1 = @"
        SELECT 
        AGE_TO, CONTRIBUTION_SCALE_GROUP_ID, CONTRIBUTION_SCALE_ID, 
        CONTRIBUTION_TO, DATE_TO, FIXED_POINTS_ONLY, 
        INCREMENT_AMOUNT, LOWER_AMOUNT, SALARY_TO, 
        SERVICE_TO, UPPER_AMOUNT
        FROM CONTRIBUTION_SCALE CS
        "; 

        public static string SelectViaFKeySql(int contributionScaleGroupId)
        {
            const string sqlTempalte = SelectTemplate1 + "where CS.CONTRIBUTION_SCALE_GROUP_ID = {0}";
            return string.Format(sqlTempalte, contributionScaleGroupId);
        }

        public static string SelectViaPKeySql(int contributionScaleId)
        {
            const string sqlTempalte = SelectTemplate1 + "where CS.CONTRIBUTION_SCALE_ID = {0}";
            return string.Format(sqlTempalte, contributionScaleId);
        }


        public static string CheckForDuplicateSql(int parentId, int ageTo, int serviceYearTo, double contributionTo,
            double salaryTo, DateTime? dateTo, int detailId)
        {
            string sql = @"select count(CS.CONTRIBUTION_SCALE_ID) as COUNTID from contribution_SCALE cs 
                                where CS.CONTRIBUTION_SCALE_GROUP_ID = {0}
                                and CS.AGE_TO = {1}
                                and CS.DATE_TO  {2}
                                and CS.CONTRIBUTION_TO = {3}
                                and CS.SALARY_TO = {4}
                                and CS.SERVICE_TO = {5}";

            if (detailId > 0)
                sql = string.Concat(sql, " and not CS.CONTRIBUTION_SCALE_ID = ", detailId);

            string dateToString = dateTo.HasValue
                ? string.Concat("= to_date('", dateTo.Value.ToShortDateString(), "', 'dd/mm/yyyy')")
                : "is null";

            return string.Format(sql, parentId, ageTo, dateToString, contributionTo, salaryTo, serviceYearTo);
        }

        public static string DeleteViaPKeySql(int detailId)
        {
            const string sql = @"delete from contribution_scale cs where CS.CONTRIBUTION_SCALE_ID = {0}";
            return string.Format(sql, detailId);
        }


        public string DeleteViaFKeySql(int groupId)
        {
            const string sql = @"delete from contribution_scale cs where CS.CONTRIBUTION_SCALE_GROUP_ID = {0}";
            return string.Format(sql, groupId);
        }


        public string InsertViaGroupId(int sourceGroupId, int newGroupId)
        {
            const string sql1 = @"
            INSERT INTO UEXT.CONTRIBUTION_SCALE (
                AGE_TO, CONTRIBUTION_SCALE_GROUP_ID, CONTRIBUTION_SCALE_ID, 
                CONTRIBUTION_TO, DATE_TO, FIXED_POINTS_ONLY, 
                INCREMENT_AMOUNT, LOWER_AMOUNT, SALARY_TO, 
                SERVICE_TO, UPPER_AMOUNT)                
            SELECT 
                AGE_TO, {1}, Contribution_Scale_SEQ.nextval, 
                CONTRIBUTION_TO, DATE_TO, FIXED_POINTS_ONLY, 
                INCREMENT_AMOUNT, LOWER_AMOUNT, SALARY_TO, 
                SERVICE_TO, UPPER_AMOUNT
            FROM CONTRIBUTION_SCALE CS
            where CS.CONTRIBUTION_SCALE_GROUP_ID = {0};
            ";
            return String.Format(sql1, sourceGroupId, newGroupId);
        }


        public static string UpdateSql(int ageTo,
            int contributionScaleId,
            double contributionTo,
            DateTime? dateTo,
            int fixedPointsOnly,
            double incrementAmount,
            double lowerAmount,
            double salaryTo,
            int serviceTo,
            double upperAmount)
        {
            const string sqlTemplate = @"UPDATE UEXT.CONTRIBUTION_SCALE
                                        SET    AGE_TO                      = {0},
                                               CONTRIBUTION_TO             = {1},
                                               DATE_TO                     = {2},
                                               FIXED_POINTS_ONLY           = {3},
                                               INCREMENT_AMOUNT            = {4},
                                               LOWER_AMOUNT                = {5},
                                               SALARY_TO                   = {6},
                                               SERVICE_TO                  = {7},
                                               UPPER_AMOUNT                = {8}
                                        WHERE  CONTRIBUTION_SCALE_ID       = {9}";

            string dateToString = dateTo.HasValue
               ? string.Concat("to_date('", dateTo.Value.ToShortDateString(), "', 'dd/mm/yyyy')")
               : "null";

            return string.Format(sqlTemplate, ageTo,
                contributionTo, dateToString, fixedPointsOnly, incrementAmount, lowerAmount, salaryTo,
                serviceTo, upperAmount, contributionScaleId);
        }
    }
}
