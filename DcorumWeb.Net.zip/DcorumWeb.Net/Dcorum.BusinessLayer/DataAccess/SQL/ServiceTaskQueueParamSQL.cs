﻿
namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class ServiceTaskQueueParamSQL
    {
        public static string GetInsertQuery(int caseKey)
        {
            return $"INSERT INTO SERVICE_TASK_QUEUE_PARAM(SERVICE_TASK_QUEUE_ID,PARAM_NAME,PARAM_VALUE,PARAM_ORDER,PARAM_TYPE) Values(SERVICE_TASK_QUEUE_ID_Seq.currval,'Case_Key','{caseKey}','1','STRING')";
        }
    }
}
