﻿using System;
using System.Collections.Generic;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class FundClassSQL : ISqlFullCrud<FundClass,int>
    {
        private const string SelectTemplate = @"
        SELECT 
            UFD.*, FD.LONG_FD_NM,FD.SHRT_FD_NM,FD.FD_TYP_CD
        FROM 
            UEXT_FUND_DESC UFD 
        INNER JOIN 
            FUND_DESC FD ON
            FD.FD_DESC_ID=UFD.FD_DESC_ID
        ";

        public IEnumerable<string> DetectAnyDependants(FundClass ofInterest)
        {
            throw new NotImplementedException();
        }

        public System.Collections.Generic.IEnumerable<string> DeleteSql(FundClass toDelete)
        {
            throw new NotImplementedException();
        }

        public System.Collections.Generic.IEnumerable<string> InsertSql(FundClass toInsert)
        {
            throw new NotImplementedException();
        }

        public System.Collections.Generic.IEnumerable<string> UpdateSql(FundClass toUpdate)
        {
            string sql = @"
            UPDATE UEXT_FUND_DESC SET 
                BITMAP_LOCATION={1}, ANNUAL_MANAGEMENT_CHARGE={2},
                GROWTH_RATE_LOW={3}, GROWTH_RATE_MID={4},
                GROWTH_RATE_HIGH={5}, GROWTH_RATE_SMPI={6},
                LIFEPATH_FUND={7}, LIFEPATH_MIN_TARGET_YR={8}, 
                LIFEPATH_MAX_TARGET_YR={9}, ADDITIONAL_CHARGE={10},
                LIFEPATH_TYPE={11}, GLIDEPATH_END_DATE={12},
                LIFEPATH_PHASE={13}
            WHERE
                UEXT_FUND_DESC_ID={0}
            ";

            string result = string.Format(sql, toUpdate.FundClassId,
                toUpdate.BitMapLocation.SqlQuotify(),
                toUpdate.AnnualManagementCharge,
                toUpdate.GrowthRateLow.IntoSqlValue(),
                toUpdate.GrowthRateMid.IntoSqlValue(),
                toUpdate.GrowthRateHigh.IntoSqlValue(),
                toUpdate.GrowthRateSMPI.IntoSqlValue(),
                toUpdate.IsLifepathFund.IntoSqlBool(),
                toUpdate.LifepathTargetStartYear.IntoSqlValue(),
                toUpdate.LifepathTargetEndYear.IntoSqlValue(),
                toUpdate.AdditionalCharge,
                toUpdate.LifePathType.IntoSqlValue(),
                toUpdate.GlidepathEndDate.ToSqlShortDateString(),
                toUpdate.LifePathPhase.IntoSqlValue()
                );

            yield return result;
        }

        public System.Collections.Generic.IEnumerable<string> SelectOneSql(int primaryKey)
        {
            const string sql = SelectTemplate + "WHERE UFD.UEXT_FUND_DESC_ID={0}";

            yield return string.Format(sql, primaryKey);
        }

        public System.Collections.Generic.IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            yield break;
//            const string sql = @"SELECT UFD.UEXT_FUND_DESC_ID,UFD.FD_DESC_ID,FD.LONG_FD_NM,FD.SHRT_FD_NM,UFD.BITMAP_LOCATION,
//                                    UFD.LIFEPATH_TARGET_YR,UFD.LIFEPATH_FUND,UFD.ANNUAL_MANAGEMENT_CHARGE,UFD.GROWTH_RATE_LOW,
//                                    UFD.GROWTH_RATE_MID,UFD.GROWTH_RATE_HIGH,UFD.GROWTH_RATE_SMPI
//                                    FROM UEXT_FUND_DESC UFD 
//                                    INNER JOIN FUND_DESC FD ON FD.FD_DESC_ID=UFD.FD_DESC_ID
//                                    WHERE UPPER(UFD.FD_DESC_ID)=UPPER('{0}')";

//           yield return string.Format(sql, "434X");
        }

        public System.Collections.Generic.IEnumerable<string> SelectManySql(string fundDescriptionId,string fundName)
        {
            string sql = SelectTemplate + "WHERE 1=1";

            if (!string.IsNullOrEmpty(fundDescriptionId)) sql += string.Format("AND UFD.FD_DESC_ID like ('%{0}%') ", fundDescriptionId);
            if (!string.IsNullOrEmpty(fundName)) sql += string.Format("AND FD.LONG_FD_NM like ('%{0}%') ", fundName);

            sql.Replace("1=1 AND ", "");
            sql.Replace(" WHERE 1=1 ", "");

            yield return string.Format(sql);
        }

        public string SelectDuplicatesSql(FundClass similar)
        {
            const string sql = SelectTemplate + "WHERE UPPER(UFD.FD_DESC_ID)=UPPER('{0}')";

            return string.Format(sql, similar.FundDescriptionId);
        }


        public string GetSequenceIdForInsert()
        {
            return null;
        }


        public string GetLifepathRefcodes()
        {
                   string sql1 = @"
SELECT 
    f1.ref_cd, f1.long_desc
FROM 
    ref_codes f1
WHERE
    f1.DOMAIN_NAME = 'LIFEPATH_TYPE'
        ";

            return sql1;
    }


        public string GetSqlStringForNewFunds()
        {
            return @"BEGIN

       -- Pick up UEXT FUND_DESC
    MERGE INTO UEXT_FUND_DESC UFD
        
    USING(
            SELECT FD_DESC_ID
            FROM FUND_DESC
         ) FD
         
    ON  (FD.FD_DESC_ID = UFD.FD_DESC_ID)
    
    WHEN NOT MATCHED THEN
        INSERT ( 
                    UFD.FD_DESC_ID,
                    UFD.UEXT_FUND_DESC_ID  
                )
        VALUES  (
                    FD.FD_DESC_ID,
                    UEXT_FUND_DESC_ID_SEQ.NEXTVAL
                );
 END;";
        }
    }
}
