﻿using System.Text;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class MemberGroupSql
    {
        internal MemberGroupSql()
        {
        }

        private const string DbDateFormatString = "DD/MM/YYYY";

        public static string GetMemberGroupbyTypeSql(int caseKey, string groupTypeCode)
        {
            const string sql = @"SELECT DISTINCT MG.MBGP_KEY, MG.DESCRIPT, MG.GRP_TYP_CD
                                     FROM MBR_GRP MG
                                     INNER JOIN UEXT_MBR_GRP UMG ON UMG.MBGP_KEY = MG.MBGP_KEY   
                                     WHERE MG.GRP_TYP_CD = '{1}' AND MG.CASE_KEY = {0}
                                     ORDER BY MG.DESCRIPT";

            return string.Format(sql, caseKey, groupTypeCode);
        }

        public static string GetMemberGroupsSql(int caseKey)
        {
            const string sql = @"
                                SELECT 
                                        MG.MBGP_Key,
                                        MG.Descript,
                                        MG.Grp_Typ_Cd,
                                        UG.Contrib_Basis_Cd,
                                        UG.Avc_Contrib_Basis_Cd,
                                        UG.Sal_Sac,
                                        UG.Default_Lifestyle_Group,
                                        UG.DEFAULT_BENEFIT_GROUP,
                                        UG.VARIABLE_EMPLOYER_CONT,
                                        UG.Display,
                                        UG.Is_Cash,
                                        UG.Inv_Available_To,
                                        UG.Link_To_Documentation,
                                        UG.Stp_Disabled,
                                        DECODE(NVL(UG.MBGP_Key, 0), 0, 0, 1) UextExists,
                                        PD.Grp_Typ_Cd   Product_Group,
                                        UG.Investment_Only
                                FROM
	                                Mbr_Grp			        MG
	                                LEFT JOIN Uext_Mbr_Grp	UG on MG.MBGP_KEY = UG.MBGP_KEY
	                                INNER JOIN Case_Data	CD ON MG.Case_Key = CD.Case_Key
                                    INNER JOIN (
			                                            SELECT
                                                                GD.Prod_Typ_Cd,
                                                                PG.Grp_Typ_Cd
                                                        FROM
                                                                Prod_Grp_Detl   GD,
                                                                Prod_Grp        PG
                                                        WHERE
                                                                GD.Prgp_Key        = PG.Prgp_Key
                                                    )		PD ON PD.Prod_Typ_Cd = CD.Prod_Typ_Cd
                                WHERE MG.Case_Key = {0} 
                                ORDER BY
	                                    MG.Grp_Typ_Cd ASC, 
                                        UG.Display DESC, 
                                        MG.MBGP_Key ASC";

            return string.Format(sql, caseKey);
        }

        public static string GetMemberGroupsSql()
        {
            const string sql = @"                        
                        select distinct MG.MBGP_KEY, MG.DESCRIPT, MG.GRP_TYP_CD
                                from mbr_grp mg
                                left join mbr_grp_detl mgd on MGD.MBGP_KEY = mg.MBGP_KEY
                                    and (trunc(MGD.EFF_DT) <= trunc(sysdate) and (trunc(MGD.XPIR_DT) >= trunc(sysdate) or MGD.XPIR_DT is null ))
         
                                order by MG.DESCRIPT";
            return sql;
        }

        public string GetBenefitMemberGroupSql(int caseKey, int caseMbrKey)
        {
            const string sql = @"select distinct MG.MBGP_KEY, MG.DESCRIPT
                                from mbr_grp mg
                                left join mbr_grp_detl mgd on MGD.MBGP_KEY = mg.MBGP_KEY
                                    and (trunc(MGD.EFF_DT) <= trunc(sysdate) and (trunc(MGD.XPIR_DT) >= trunc(sysdate) or MGD.XPIR_DT is null ))
                                where MG.CASE_KEY = {0} and MG.GRP_TYP_CD = '12' 
                                and MGD.CASE_MBR_KEY = {1} 
                                order by DESCRIPT";
            return string.Format(sql, caseKey, caseMbrKey);
        }

        public string GetMemberGroupsSql(int caseKey, int caseMbrKey)
        {
            const string sql = @"select distinct MG.MBGP_KEY, MG.DESCRIPT, MG.GRP_TYP_CD, UMG.INV_AVAILABLE_TO, UMG.DEFAULT_LIFESTYLE_GROUP,UMG.DEFAULT_BENEFIT_GROUP, UMG.LINK_TO_DOCUMENTATION, UMG.SAL_SAC, UMG.DISPLAY, UMG.IS_CASH
                                from mbr_grp mg
                                left join mbr_grp_detl mgd on MGD.MBGP_KEY = mg.MBGP_KEY
                                    and (trunc(MGD.EFF_DT) <= trunc(sysdate) and (trunc(MGD.XPIR_DT) >= trunc(sysdate) or MGD.XPIR_DT is null ))
                                left join uext_mbr_grp umg on MG.MBGP_KEY = UMG.MBGP_KEY
                                where MG.CASE_KEY = {0} 
                                and MGD.CASE_MBR_KEY = {1} 
                                order by DESCRIPT";
            return string.Format(sql, caseKey, caseMbrKey);
        }

        /// <summary>
        /// Get Groups by case key and optionally filtered by Group Type Code and In Available To
        /// </summary>
        /// <param name="caseKey"></param>
        /// <param name="grpTypeCode">Optional</param>
        /// <param name="inAvailableTo">Optional</param>
        /// <returns></returns>
        public static string GetMemberGroupsByTypeAndInvAvailableTo(int caseKey, string grpTypeCode, string inAvailableTo)
        {
            const string Sql = @"SELECT
                                    UMG.MBGP_KEY,
                                    '(' || UMG.MBGP_KEY || ') ' || MG.DESCRIPT AS DESCRIPT,
                                    MG.GRP_TYP_CD
                                FROM
                                    UEXT_MBR_GRP UMG
                                INNER JOIN
                                    Mbr_Grp MG ON MG.MBGP_KEY = UMG.MBGP_KEY
                                WHERE
                                    UMG.CASE_KEY = {0}{1}
                                ORDER BY 
                                    DESCRIPT";

            var addWhereClause = new StringBuilder(string.Empty);
            if (!string.IsNullOrEmpty(grpTypeCode))
                addWhereClause.AppendFormat(" AND MG.GRP_TYP_CD = '{0}'", grpTypeCode);
            if (!string.IsNullOrEmpty(inAvailableTo))
                addWhereClause.AppendFormat(" AND UMG.INV_AVAILABLE_TO = '{0}'", inAvailableTo);

            return string.Format(Sql, caseKey, addWhereClause.ToString());
        }

        public string GetMemberGroupByIdSql(int memberGroupId)

        {
            const string sql = @"select distinct
                                    MG.CASE_KEY, MG.MBGP_KEY, MG.DESCRIPT, MG.GRP_TYP_CD, 
                                    UMG.DEFAULT_LIFESTYLE_GROUP,UMG.DEFAULT_BENEFIT_GROUP, UMG.DISPLAY, UMG.IS_CASH, UMG.INV_AVAILABLE_TO, UMG.LINK_TO_DOCUMENTATION, UMG.STP_DISABLED,
                                    UMG.CONTRIB_BASIS_CD, UMG.AVC_CONTRIB_BASIS_CD, UMG.SAL_SAC, 
                                    UMG.MODELLER_PERMISSION_ID, UMG.VARIABLE_EMPLOYER_CONT,

                                    UMG.INVESTMENTS_PERMISSION_ID,
                                    UMG.CONTRIBUTION_PERMISSION_ID,
                                    UMG.PERSONAL_DETAILS_PERMISSION_ID,
                                    UMG.CONTACT_DETAILS_PERMISSION_ID,
                                    UMG.SET_TRA_PERMISSION_ID,
                                    UMG.SECURITY_DETAILS_PERMISSION_ID,

                                    UMG.INVESTMENTS_DEF_PERMISSION_ID,
                                    UMG.CONTRIBUTION_DEF_PERMISSION_ID,
                                    UMG.PERSONAL_DTL_DEF_PERMISSION_ID,
                                    UMG.CONTACT_DTL_DEF_PERMISSION_ID,
                                    UMG.SET_TRA_DEF_PERMISSION_ID,

                                    UMG.USE_NEW_ILLUST,
                                    UMG.CONTRIB_FREQ_CD,
                                    UMG.REDIRECT_FREQ_KEY,
                                    UMG.GROUP_EARNINGS_CAP,
                                    UMG.CAP_INC_TYPE,
                                    UMG.CAP_INC_TYPE_OTHER_AMT,
                                    TO_CHAR(UMG.CAP_INC_DT, '{1}')  CAP_INC_DT, 
                                    UMG.ER_AMOUNT_CAP,
                                    UMG.ER_AMOUNT_CAP_INC_TYPE,
                                    UMG.ER_AMOUNT_CAP_INC_OTHER_AMT,
                                    TO_CHAR(UMG.ER_AMOUNT_CAP_RESET_DT, '{1}') ER_AMOUNT_CAP_RESET_DT,

                                    DECODE(NVL(UMG.MBGP_Key, 0), 0, 0, 1) UextExists,
                                    PD.Grp_Typ_Cd   Product_Group,
                                    UMG.Investment_Only,
									UMG.HIDE_MESSAGE_CENTRE,
									UMG.HIDE_MY_PENSION_TAB,
									UMG.HIDE_PENSION_ESSENTIALS_TAB,
									UMG.HIDE_MY_INCOME_TAB,
                                    UMG.HIDE_ISA_TAB,
                                    UMG.Defr_Swc_MBGP_Key
                                FROM
                                    mbr_grp mg
	                                INNER JOIN Case_Data	CD ON MG.Case_Key = CD.Case_Key
                                    left join mbr_grp_detl mgd on MGD.MBGP_KEY = mg.MBGP_KEY
                                      and (trunc(MGD.EFF_DT) <= trunc(sysdate) and (trunc(MGD.XPIR_DT) >= trunc(sysdate) or MGD.XPIR_DT is null ))
                                    left join uext_mbr_grp umg on MG.MBGP_KEY = UMG.MBGP_KEY
                                    INNER JOIN (
			                                            SELECT
                                                                GD.Prod_Typ_Cd,
                                                                PG.Grp_Typ_Cd
                                                        FROM
                                                                Prod_Grp_Detl   GD,
                                                                Prod_Grp        PG
                                                        WHERE
                                                                GD.Prgp_Key        = PG.Prgp_Key
                                                    )		PD ON PD.Prod_Typ_Cd = CD.Prod_Typ_Cd
                                where MG.MBGP_KEY = {0} 
                               ";
            return string.Format(sql, memberGroupId, DbDateFormatString);
        }

        public string UpdateMemberGroupSQL(MemberGroup memberGroup)
        {
            StringBuilder sSQL = new StringBuilder();

            sSQL.AppendLine("UPDATE UEXT_MBR_GRP SET ");

            //bugfix: 6289
            sSQL.AppendLine(string.Format("CONTRIB_BASIS_CD = '{0}', ", memberGroup.ContribBasis.RefCd));
            sSQL.AppendLine(string.Format("AVC_CONTRIB_BASIS_CD = '{0}', ", memberGroup.ContribBasisAVC.RefCd));
            sSQL.AppendLine(string.Format("SAL_SAC = '{0}', ", memberGroup.SalarySac.RefCd));
            sSQL.AppendLine(string.Format("VARIABLE_EMPLOYER_CONT = '{0}', ", memberGroup.VariableEmployerContribution.RefCd));

            sSQL.AppendLine(string.Format("DEFAULT_LIFESTYLE_GROUP = '{0}', ", memberGroup.IsDefault.RefCd));
            sSQL.AppendLine(string.Format("DEFAULT_BENEFIT_GROUP = '{0}', ", memberGroup.IsDefaultBenefitMbrGroup.RefCd));
            sSQL.AppendLine(string.Format("IS_CASH = '{0}', ", memberGroup.IsCash.RefCd));
            sSQL.AppendLine(string.Format("INV_AVAILABLE_TO = '{0}', ", memberGroup.InvAvlableTo.RefCd));
            sSQL.AppendLine(string.Format("LINK_TO_DOCUMENTATION = {0}, ", memberGroup.LinkToDoc.SqlQuotify()));
            
          
            sSQL.AppendLine(string.Format("DISPLAY = '{0}', ", memberGroup.IsDisplay.RefCd));
            sSQL.AppendLine(string.Format("STP_DISABLED = '{0}', ", memberGroup.STPDisabled.RefCd));
            sSQL.AppendLine(string.Format("USE_NEW_ILLUST = '{0}', ", memberGroup.UseNewIllustration.RefCd));
            sSQL.AppendLine(string.Format("CONTRIB_FREQ_CD = '{0}', ", memberGroup.ContribFrequency.RefCd));
            sSQL.AppendLine(string.Format("REDIRECT_FREQ_KEY = '{0}', ", memberGroup.RedirectFrequency.RefCd));
            sSQL.AppendLine(string.Format("GROUP_EARNINGS_CAP = '{0}', ", memberGroup.GroupEarningsCap));
            sSQL.AppendLine(string.Format("CAP_INC_TYPE = '{0}', ", memberGroup.IncreaseType.RefCd));
            sSQL.AppendLine(string.Format("CAP_INC_TYPE_OTHER_AMT = '{0}', ", memberGroup.CapIncrOtherAmt));
            sSQL.AppendLine(string.Format("CAP_INC_DT = TO_DATE('{0}', '{1}'), ", memberGroup.CapIncrDate, DbDateFormatString));
            sSQL.AppendLine(string.Format("ER_AMOUNT_CAP = '{0}', ", memberGroup.EmployerEarningCap));
            sSQL.AppendLine(string.Format("ER_AMOUNT_CAP_INC_TYPE = '{0}', ", memberGroup.EmployerIncreaseType.RefCd));
            sSQL.AppendLine(string.Format("ER_AMOUNT_CAP_INC_OTHER_AMT = '{0}', ", memberGroup.EmployerEarningCapOther));
            sSQL.AppendLine(string.Format("ER_AMOUNT_CAP_RESET_DT =  TO_DATE('{0}', '{1}'), ", memberGroup.EmplCapIncrDate, DbDateFormatString));

            sSQL.AppendLine(string.Format("INVESTMENTS_PERMISSION_ID = '{0}', ", memberGroup.InvPermissionActive.RefCd));
            sSQL.AppendLine(string.Format("CONTRIBUTION_PERMISSION_ID = '{0}', ", memberGroup.ContribPermissionActive.RefCd));
            sSQL.AppendLine(string.Format("PERSONAL_DETAILS_PERMISSION_ID = '{0}', ", memberGroup.PersPermissionActive.RefCd));
            sSQL.AppendLine(string.Format("CONTACT_DETAILS_PERMISSION_ID = '{0}', ", memberGroup.ContPermissionActive.RefCd));
            sSQL.AppendLine(string.Format("SET_TRA_PERMISSION_ID = '{0}', ", memberGroup.TRAPermissionActive.RefCd));
            sSQL.AppendLine(string.Format("SECURITY_DETAILS_PERMISSION_ID = '{0}', ", memberGroup.SecPermissionActive.RefCd));

            sSQL.AppendLine(string.Format("INVESTMENTS_DEF_PERMISSION_ID = '{0}', ", memberGroup.InvPermissionDeferred.RefCd));
            sSQL.AppendLine(string.Format("CONTRIBUTION_DEF_PERMISSION_ID = '{0}', ", memberGroup.ContribPermissionDeferred.RefCd));
            sSQL.AppendLine(string.Format("PERSONAL_DTL_DEF_PERMISSION_ID = '{0}', ", memberGroup.PersPermissionDeferred.RefCd));
            sSQL.AppendLine(string.Format("CONTACT_DTL_DEF_PERMISSION_ID = '{0}', ", memberGroup.ContPermissionDeferred.RefCd));
            sSQL.AppendLine(string.Format("SET_TRA_DEF_PERMISSION_ID = '{0}', ", memberGroup.TRAPermissionDeferred.RefCd));

			sSQL.AppendLine(string.Format("Investment_Only = '{0}', ", memberGroup.IsInvestmentOnly.RefCd));
			sSQL.AppendLine(string.Format("HIDE_MESSAGE_CENTRE = '{0}', ", memberGroup.HideMessageCentre));
			sSQL.AppendLine(string.Format("HIDE_MY_PENSION_TAB = '{0}', ", memberGroup.HideMyPensionTab));
			sSQL.AppendLine(string.Format("HIDE_PENSION_ESSENTIALS_TAB = '{0}', ", memberGroup.HidePensionEssentialsTab));
			sSQL.AppendLine(string.Format("HIDE_MY_INCOME_TAB = '{0}', ", memberGroup.HideMyIncomeTab));
            sSQL.AppendLine(string.Format("HIDE_ISA_TAB = '{0}', ", memberGroup.HideIsaTab));

            sSQL.AppendLine(string.Format("Defr_Swc_MBGP_Key = '{0}'", memberGroup.LnkDefSwitchGroup));

            sSQL.AppendLine(string.Format("WHERE MBGP_KEY = {0}", memberGroup.MbGpKey));

            return sSQL.ToString();
        }


        public string InsertMemberGroupSQL(MemberGroup memberGroup)
        {
            StringBuilder sSQL = new StringBuilder();

            sSQL.AppendLine("INSERT INTO UEXT_MBR_GRP ");
            sSQL.AppendLine("(MBGP_KEY, CASE_KEY, ");
            sSQL.AppendLine("CONTRIB_BASIS_CD, AVC_CONTRIB_BASIS_CD, SAL_SAC,VARIABLE_EMPLOYER_CONT, ");
            sSQL.AppendLine("DEFAULT_LIFESTYLE_GROUP, DISPLAY, IS_CASH, INV_AVAILABLE_TO, LINK_TO_DOCUMENTATION, STP_DISABLED, DEFAULT_BENEFIT_GROUP, ");
            sSQL.AppendLine("USE_NEW_ILLUST, CONTRIB_FREQ_CD, GROUP_EARNINGS_CAP, CAP_INC_TYPE, CAP_INC_TYPE_OTHER_AMT, CAP_INC_DT, ER_AMOUNT_CAP, ER_AMOUNT_CAP_INC_TYPE, ER_AMOUNT_CAP_INC_OTHER_AMT, ER_AMOUNT_CAP_RESET_DT, ");
            sSQL.AppendLine("INVESTMENTS_PERMISSION_ID, CONTRIBUTION_PERMISSION_ID, PERSONAL_DETAILS_PERMISSION_ID, CONTACT_DETAILS_PERMISSION_ID, SET_TRA_PERMISSION_ID, SECURITY_DETAILS_PERMISSION_ID, ");
            sSQL.AppendLine("INVESTMENTS_DEF_PERMISSION_ID, CONTRIBUTION_DEF_PERMISSION_ID, PERSONAL_DTL_DEF_PERMISSION_ID, CONTACT_DTL_DEF_PERMISSION_ID, SET_TRA_DEF_PERMISSION_ID,");
			sSQL.AppendLine("Investment_Only, HIDE_MESSAGE_CENTRE, HIDE_MY_PENSION_TAB, HIDE_PENSION_ESSENTIALS_TAB, HIDE_MY_INCOME_TAB,HIDE_ISA_TAB, Defr_Swc_MBGP_Key)");
            sSQL.AppendLine(string.Format("VALUES ({0}, {1}, ", memberGroup.MbGpKey, memberGroup.CaseKey));
            sSQL.AppendLine(string.Format("'{0}', '{1}', '{2}','{3}', ", memberGroup.ContribBasis.RefCd, memberGroup.ContribBasisAVC.RefCd, memberGroup.SalarySac.RefCd, memberGroup.VariableEmployerContribution.RefCd));
            sSQL.AppendLine(string.Format("'{0}', '{1}', '{2}', '{3}', {4}, '{5}','{6}', ", memberGroup.IsDefault.RefCd, memberGroup.IsDisplay.RefCd, memberGroup.IsCash.RefCd, memberGroup.InvAvlableTo.RefCd, memberGroup.LinkToDoc.SqlQuotify(), memberGroup.STPDisabled.RefCd,memberGroup.IsDefaultBenefitMbrGroup.RefCd));

            sSQL.AppendLine(string.Format("'{0}', '{1}', '{2}', '{3}', '{4}', ", memberGroup.UseNewIllustration.RefCd, memberGroup.ContribFrequency.RefCd, memberGroup.GroupEarningsCap, memberGroup.IncreaseType.RefCd, memberGroup.CapIncrOtherAmt));
            sSQL.AppendLine(string.Format("TO_DATE('{0}', '{1}'), ", memberGroup.CapIncrDate, DbDateFormatString));
            sSQL.AppendLine(string.Format("'{0}', '{1}', '{2}', ", memberGroup.EmployerEarningCap, memberGroup.EmployerIncreaseType.RefCd, memberGroup.EmployerEarningCapOther));
            sSQL.AppendLine(string.Format("TO_DATE('{0}', '{1}'), ", memberGroup.EmplCapIncrDate, DbDateFormatString));

            sSQL.AppendLine(string.Format("'{0}', '{1}', '{2}', '{3}', '{4}', '{5}', ", memberGroup.InvPermissionActive.RefCd, memberGroup.ContribPermissionActive.RefCd, memberGroup.PersPermissionActive.RefCd, memberGroup.ContPermissionActive.RefCd, memberGroup.TRAPermissionActive.RefCd, memberGroup.SecPermissionActive.RefCd));
			sSQL.AppendLine(string.Format("'{0}', '{1}', '{2}', '{3}', '{4}', ", memberGroup.InvPermissionDeferred.RefCd, memberGroup.ContribPermissionDeferred.RefCd, memberGroup.PersPermissionDeferred.RefCd, memberGroup.ContPermissionDeferred.RefCd, memberGroup.TRAPermissionDeferred.RefCd));
			sSQL.AppendLine(string.Format("'{0}', '{1}', '{2}', '{3}', '{4}', '{5}', ", memberGroup.IsInvestmentOnly.RefCd, memberGroup.HideMessageCentre, memberGroup.HideMyPensionTab, memberGroup.HidePensionEssentialsTab, memberGroup.HideMyIncomeTab, memberGroup.HideIsaTab));

            sSQL.AppendLine(string.Format("'{0}')", memberGroup.LnkDefSwitchGroup));

            return sSQL.ToString();
        }

        
        public string DoesUextTableEntryExistSQL(int MemberGroupId)
        {
            StringBuilder sSQL = new StringBuilder();

            sSQL.AppendLine("SELECT COUNT(*) AS UextMbrGroupCount ");
            sSQL.AppendLine("FROM UEXT_MBR_GRP ");
            sSQL.AppendLine(string.Format("WHERE MBGP_KEY = {0} ", MemberGroupId.ToString()));

            return sSQL.ToString();
        }
    }
}
