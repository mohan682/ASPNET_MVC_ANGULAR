﻿using System.Collections.Generic;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class DemoParamSQL :ISqlFullCrud<DemoParam,int>
    {
        public IEnumerable<string> SelectManySql(int userAccId, string appendWhereClauseWith = null)
        {
            const string sql = @"   SELECT
                                        DP.User_Acc_Demo_Param_Id,
                                        DP.User_Acc_Id,
                                        DP.Key,
                                        DP.Value ,
                                        RC.Long_Desc
                                    FROM
                                        User_Acc_Demo_Param     DP,
                                        Ref_Codes               RC
                                    WHERE
                                        DP.User_Acc_Id  = {0} 
                                    AND DP.Key          = RC.Ref_Cd
                                    AND RC.Domain_Name  = '{1}'
                                    --AND RC.Disable_Cd   = '0'
                                    ORDER BY RC.Long_Desc";

            yield return string.Format(sql, userAccId, Constants.SpecialDomainNames.DemoParamKeys);
        }

        public IEnumerable<string> SelectOneSql(int demoParamId)
        {
            const string sql = @"   SELECT
                                        DP.User_Acc_Demo_Param_Id,
                                        DP.User_Acc_Id,
                                        DP.Key,
                                        DP.Value ,
                                        RC.Long_Desc
                                    FROM
                                        User_Acc_Demo_Param     DP,
                                        Ref_Codes               RC
                                    WHERE
                                        DP.User_Acc_Demo_Param_Id   = {0} 
                                    AND DP.Key                      = RC.Ref_Cd
                                    AND RC.Domain_Name              = '{1}'
                                    --AND RC.Disable_Cd               = '0'
                                    ";

            yield return string.Format(sql, demoParamId, Constants.SpecialDomainNames.DemoParamKeys);
        }

        public string SelectDuplicatesSql(DemoParam demoParam)
        {
            const string sql = @"   SELECT
                                        DP.User_Acc_Demo_Param_Id,
                                        DP.User_Acc_Id,
                                        DP.Key,
                                        DP.Value
                                    FROM
                                        User_Acc_Demo_Param     DP
                                    WHERE
                                        DP.User_Acc_Id  = {0} 
                                    AND DP.Key          = '{1}'";

            return string.Format(sql, demoParam.DemoParamUserAccId, demoParam.DemoParamCode.RefCd);
        }

        public IEnumerable<string> InsertSql(DemoParam demoParam)
        {
            const string sql = @"INSERT INTO User_Acc_Demo_Param 
                                (User_Acc_Demo_Param_Id,    User_Acc_Id,    Key,    Value) VALUES 
                                ({0},                       {1},            '{2}',  '{3}')";

            yield return string.Format(sql, demoParam.DemoParamId, demoParam.DemoParamUserAccId, demoParam.DemoParamCode.RefCd, demoParam.DemoParamValue);
        }

        public IEnumerable<string> UpdateSql(DemoParam demoParam)
        {
            const string sql = @"UPDATE  User_Acc_Demo_Param SET
                                    Value   = '{0}'
                                WHERE User_Acc_Demo_Param_Id={1} ";

            yield return string.Format(sql, demoParam.DemoParamValue, demoParam.DemoParamId);   
        }


        public IEnumerable<string> DetectAnyDependants(DemoParam ofInterest)
        {
            yield break;
        }


        public IEnumerable<string> DeleteSql(DemoParam demoParam)
        {
            const string sql = @"DELETE FROM User_Acc_Demo_Param WHERE User_Acc_Demo_Param_Id = {0}";

            yield return string.Format(sql, demoParam.DemoParamId.Value);
        }


        public string GetSequenceIdForInsert()
        {
            return "User_Acc_Demo_Param_Id_Seq";
        }
    }
}
