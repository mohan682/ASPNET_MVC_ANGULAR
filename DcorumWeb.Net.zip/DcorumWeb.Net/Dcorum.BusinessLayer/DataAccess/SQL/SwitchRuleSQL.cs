﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class SwitchRuleSQL
    {
        public static string GetSwitchRulesByCase(int caseKey)
        {
            const string sql = @"SELECT CSWR_KEY,DESCRIPT,CASE_KEY,TR_CD
                                 FROM SWITCH_RULES
                                 WHERE CASE_KEY = {0} 
                                 AND SW_TYP_CD = '00' 
                                 AND TR_CD = '5095'
                                 AND AUTO_SW_CD = '0'
                                 AND EFF_DT <= sysdate 
                                AND (XPIR_DT >= sysdate OR XPIR_DT IS NULL)";

            return string.Format(sql, caseKey);
        }
    }
}
