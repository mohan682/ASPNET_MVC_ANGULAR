﻿using System;
using System.Data;
using System.Security.Permissions;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class MaintenanceMessageSQL
    {
        public static string GetAllMaintenaneeMessagesSql(bool includingExpired, string dbDateFormatString)
        {
            const string sqlTemplate = @" SELECT 
                                                ACCESS_LEVEL,
                                                ACCESS_LIMITED_ID,
                                                TO_CHAR(EFF_DT, '{0}') EFF_DT, 
                                                MESSAGE,
                                                PERMISSION_ID, REF, 
                                                TO_CHAR(XPIR_DT, '{0}') XPIR_DT, 
                                                CD.PLAN_NM as SchemeName,
                                                MG.DESCRIPT as GroupName,
                                                CD.CONT_NO, MG.MBGP_KEY
                                          FROM  UEXT.ACCESS_LIMITED al
                                                left join case_data cd on CD.CASE_KEY = AL.REF and AL.ACCESS_LEVEL = '01'
                                                left join mbr_grp mg on MG.MBGP_KEY = AL.REF and AL.ACCESS_LEVEL = '02'";

            if (!includingExpired)
                return String.Format(sqlTemplate + " where (AL.XPIR_DT >= sysdate or AL.XPIR_DT is null)", dbDateFormatString);
            else
                return String.Format(sqlTemplate, dbDateFormatString);

        }

        public static string GetMaintenanceMessageSql(int id, string dbDateFormatString)
        {
            const string sqlTemplate = @" SELECT 
                        ACCESS_LEVEL, ACCESS_LIMITED_ID, TO_CHAR(EFF_DT, '{1}') EFF_DT, 
                           MESSAGE, PERMISSION_ID, REF, 
                           TO_CHAR(XPIR_DT, '{1}') XPIR_DT, CD.PLAN_NM as SchemeName, MG.DESCRIPT as GroupName,CD.CONT_NO, MG.MBGP_KEY
                        FROM UEXT.ACCESS_LIMITED al
                        left join case_data cd
                        on CD.CASE_KEY = AL.REF and AL.ACCESS_LEVEL = '01'
                        left join mbr_grp mg
                        on MG.MBGP_KEY = AL.REF and AL.ACCESS_LEVEL = '02'
                        where AL.ACCESS_LIMITED_ID = {0}";
            return string.Format(sqlTemplate, id, dbDateFormatString);
        }

        internal static string InsertMaintenanceMessageSql(string accessLevel, string effectiveDate, string message, string permissionId, int refCode, string expiryDate, string dbDateFormatString, int pKey)
        {
            const string sqlTemplate = @"INSERT INTO UEXT.ACCESS_LIMITED (
                                           ACCESS_LEVEL, ACCESS_LIMITED_ID, EFF_DT, 
                                           MESSAGE, PERMISSION_ID, REF, 
                                           XPIR_DT) 
                                        VALUES ( '{0}',
                                         {7},
                                         to_date('{1}', '{6}'),
                                         '{2}',
                                         {3},
                                         {4},
                                         to_date('{5}', '{6}'))";
            return string.Format(sqlTemplate, accessLevel, effectiveDate, message, permissionId, refCode, expiryDate, dbDateFormatString, pKey);
        }

        internal static string UpdateMaintenaceMessageSql(string accessLevel, string effectiveDate, string message, string permissionId, int refCode, string expiryDate, int id, string dbDateFormatString)
        {
            const string sqlTemplate = @" UPDATE UEXT.ACCESS_LIMITED
                    SET    ACCESS_LEVEL      = '{0}',
                           EFF_DT            = to_date('{1}', '{7}'),
                           MESSAGE           = '{2}',
                           PERMISSION_ID     = {3},
                           REF               = {4},
                           XPIR_DT           = to_date('{5}', '{7}')
                    WHERE  ACCESS_LIMITED_ID = {6}";
            return string.Format(sqlTemplate, accessLevel, effectiveDate, message, permissionId, refCode,
                        expiryDate, id, dbDateFormatString);
        }

        public static string DeleteSql(int id)
        {
            const string sqlTemplate = @"delete ACCESS_LIMITED al where AL.ACCESS_LIMITED_ID = {0}";
            return string.Format(sqlTemplate, id);
        }
    }
}
