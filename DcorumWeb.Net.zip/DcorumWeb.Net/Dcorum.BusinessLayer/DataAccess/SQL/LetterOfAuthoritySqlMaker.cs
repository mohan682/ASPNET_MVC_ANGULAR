﻿using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class LetterOfAuthoritySqlMaker : ISqlOpenFullCrud<LetterOfAuthority, int, int>
    {
        internal protected LetterOfAuthoritySqlMaker()
        {

        }

        public IReadOnlyList<string> ColumnNames = new ReadOnlyCollection<string>(new[] { "Letter_Of_Authority_Id",
        "CASE_MBR_KEY",
        "AGT_KEY",
         "TYPE",
         "EFF_DT",
         "XPIR_DT",
         "LAST_MOD_DT",
        "LAST_MOD_USER" });

        public IEnumerable<string> DeleteSql(LetterOfAuthority toDelete)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> DetectAnyDependants(LetterOfAuthority ofInterest)
        {
            yield break;
        }

        public string GetSequenceIdForInsert()
        {
            return "Letter_Of_Authority_Id_Seq";
        }

        private IEnumerable<string> YieldNewValues(LetterOfAuthority toInsert)
        {
            yield return toInsert.LetterOfAuthorityId.ToString();
            yield return toInsert.CaseMemberKey.ToString();
            yield return toInsert.AgentKey.ToString();
            yield return toInsert.AuthorityType.SqlQuotify();
            yield return toInsert.EffectiveDate.ToSqlShortDateString();
            yield return toInsert.ExpiryDate.ToSqlShortDateString();
            yield return "SYSDATE";
            yield return "DcorumWeb".SqlQuotify();
        }


        public IEnumerable<string> InsertSql(LetterOfAuthority toInsert)
        {
            yield return $@"Update Letter_Of_Authority set Xpir_Dt={toInsert.EffectiveDate.AddDays(-1).ToSqlShortDateString()} where CASE_MBR_KEY={toInsert.CaseMemberKey} 
                            AND AGT_KEY={toInsert.AgentKey} AND EFF_DT<=SYSDATE AND NVL(XPIR_DT,SYSDATE)>=SYSDATE";

            string part1 = string.Join(", ", ColumnNames);

            string part2 = string.Join(", ", YieldNewValues(toInsert));

            yield return $@"Insert into Letter_Of_Authority ({part1}) Values ({part2})" ;
        }


        public string SelectDuplicatesSql(LetterOfAuthority similar)
        {
            return string.Empty;//$"SELECT * FROM LETTER_OF_AUTHORITY WHERE CASE_MBR_KEY={similar.CaseMemberKey} AND AGT_KEY={similar.AgentKey} AND TYPE={similar.AuthorityType.SqlQuotify()} AND EFF_DT<=SYSDATE AND NVL(XPIR_DT,SYSDATE+1)>SYSDATE";
        }

        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            string sql1 = @"
SELECT
    Loa.Letter_Of_Authority_id, Loa.Case_Mbr_Key, Loa.Agt_Key,
    LOA.Type AS LOA_TYPE,
    LOA.Eff_Dt AS LOA_EFF_DT, LOA.Xpir_Dt AS LOA_XPIR_DT
FROM
    Letter_Of_Authority LOA
    --LEFT JOIN  Ref_Codes RC ON LOA.Type = RC.Ref_Cd AND RC.Domain_Name = 'LOA_TYPE'
WHERE
    Loa.Agt_Key = {0}";

            yield return string.Format(sql1, parentKey);
        }

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            yield return $@"Select * from Letter_Of_Authority where Letter_Of_Authority_id = {primaryKey}";     
        }

        public IEnumerable<string> UpdateSql(LetterOfAuthority toUpdate)
        {
            yield return $"Update Letter_Of_Authority set Xpir_Dt={toUpdate.ExpiryDate.ToSqlShortDateString()} where Letter_Of_Authority_id={toUpdate.LetterOfAuthorityId}";
        }
    }
}
