﻿using System;
using System.Diagnostics.Contracts;
using System.Text;
using Dcorum.BusinessLayer.Entities.Contributions;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Dcorum.BusinessLayer.Constants;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class ContributionScaleSql :IContributionLookupSqlBuilder<ContributionScaleLookup>
    {
        private const string SelectCore = @"
                select distinct CSL.CONTRIBUTION_SCALE_LOOKUP_ID as csl_id, mg.case_key, mg.MBGP_KEY, MG.DESCRIPT, MG.GRP_TYP_CD, 
                    CSL.CONTRIBUTION_SCALE_GROUP_ID as csl_group_id, Upper(CSL.VARIATION_CD) as VARIATION_CD,
                    uext.pdi.mny_typ_grp_descript(mg.CASE_KEY,Coalesce(To_number(Replace(Upper(CSL.VARIATION_CD),'ALL')),0)) NAME
                    ,(select count(*) from contribution_scale_lookup where CONTRIBUTION_SCALE_GROUP_ID = CSL.CONTRIBUTION_SCALE_GROUP_ID) as COUNTSCALE 
                    ,(select count(*) from contribution_scale where CONTRIBUTION_SCALE_GROUP_ID = CSL.CONTRIBUTION_SCALE_GROUP_ID) as DetailCount
                from mbr_grp mg
                --left join mbr_grp_detl mgd on MGD.MBGP_KEY = mg.MBGP_KEY
                inner join uext_mbr_grp umg on MG.MBGP_KEY = UMG.MBGP_KEY
                left join contribution_scale_lookup csl on UMG.MBGP_KEY = CSL.MBGP_KEY
                where MG.GRP_TYP_CD = '12' and umg.DISPLAY = 1 and {0} 
                /*and (
                (trunc(MGD.EFF_DT) <= trunc(sysdate) or (MGD.EFF_DT is null and MGD.XPIR_DT is null))
                and (trunc(MGD.XPIR_DT) >= trunc(sysdate) or MGD.XPIR_DT is null )
                )*/
                order by DESCRIPT
                ";

        public string SelectViaPkeySql(int pkey)
        {
            return String.Format(SelectCore, "CSL.CONTRIBUTION_SCALE_LOOKUP_ID" + "=" + pkey);
        }

        public string SelectViaCaseKeySql(int fkey)
        {
            return String.Format(SelectCore, "MG.CASE_KEY" + "=" + fkey);
        }

        public string SelectViaMemberGroupKeySql(int fkey)
        {
            return String.Format(SelectCore, "MG.MBGP_KEY" + "=" + fkey);
        }

        public static string GetAllMemberGroupsWithScales()
        {
            return @"select distinct MG.MBGP_KEY, MG.DESCRIPT, 0 as CSL_GROUP_ID, MG.GRP_TYP_CD
                                from mbr_grp mg
                                left join mbr_grp_detl mgd on MGD.MBGP_KEY = mg.MBGP_KEY
                                    and (trunc(MGD.EFF_DT) <= trunc(sysdate) and (trunc(MGD.XPIR_DT) >= trunc(sysdate) or MGD.XPIR_DT is null ))
                                inner join uext_mbr_grp umg on MG.MBGP_KEY = UMG.MBGP_KEY
                                inner join contribution_scale_lookup csl on UMG.MBGP_KEY = CSL.MBGP_KEY
                                where MG.GRP_TYP_CD = '12'    
                                order by DESCRIPT";
        }


        public static string InsertContributionScaleSql(int ageTo,
            int contributionScaleId,
            double contributionTo,
            DateTime? dateTo,
            int fixedPointsOnly,
            double incrementAmount,
            double lowerAmount,
            double salaryTo,
            int serviceTo,
            double upperAmount,
            int parentId,
            int caseKey,
            int memberGroupKey,
            int newLookupId)
        {
            var sqlInsertWithoutCsgId = new StringBuilder();

            string dateToString = dateTo.HasValue
                ? string.Concat("to_date('", dateTo.Value.ToShortDateString(), "', 'dd/mm/yyyy')")
                : "null";

            if (parentId == 0)
            {
                Contract.Assert(caseKey > 0);
                Contract.Assert(memberGroupKey > 0);
                Contract.Assert(newLookupId > 0);

                sqlInsertWithoutCsgId.Append("declare ");
                sqlInsertWithoutCsgId.Append("v_csg_id number; ");
                //sqlInsertWithoutCsgId.Append("v_csl_id number;  ");
                sqlInsertWithoutCsgId.Append("begin  ");
                sqlInsertWithoutCsgId.Append("select Contrib_Scale_Group_Id_SEQ.nextval into v_csg_id from dual;");
                //sqlInsertWithoutCsgId.Append("select Contribution_Scale_Lookup_SEQ.nextval into v_csl_id from dual; ");
                sqlInsertWithoutCsgId.Append(
                    "INSERT INTO UEXT.CONTRIBUTION_SCALE (AGE_TO,CONTRIBUTION_SCALE_GROUP_ID,CONTRIBUTION_SCALE_ID,CONTRIBUTION_TO, DATE_TO, ");
                sqlInsertWithoutCsgId.Append(
                    "   FIXED_POINTS_ONLY,INCREMENT_AMOUNT,LOWER_AMOUNT, SALARY_TO, SERVICE_TO, UPPER_AMOUNT) ");
                sqlInsertWithoutCsgId.Append("VALUES ( {0},v_csg_id,{11},{1},{2},{3},{4},{5},{6},{7},{8}); ");
                sqlInsertWithoutCsgId.Append(
                    "INSERT INTO UEXT.CONTRIBUTION_SCALE_LOOKUP (CASE_KEY, CONTRIBUTION_SCALE_GROUP_ID, CONTRIBUTION_SCALE_LOOKUP_ID,MBGP_KEY, VARIATION_CD)   ");
                sqlInsertWithoutCsgId.Append("VALUES ( {9},v_csg_id,{12},{10},'{13}'); ");
                sqlInsertWithoutCsgId.Append("end; ");

                return string.Format(sqlInsertWithoutCsgId.ToString(),
                    ageTo, contributionTo, dateToString, fixedPointsOnly, incrementAmount,
                    lowerAmount, salaryTo, serviceTo, upperAmount, caseKey,
                    memberGroupKey, contributionScaleId, newLookupId,CommonCodes.Variation_Code_ALL);
            }

            Contract.Assert(newLookupId == 0);
            var sqlInsertWithCsgId = new StringBuilder();
            sqlInsertWithCsgId.Append("begin ");
            sqlInsertWithCsgId.Append(
                "INSERT INTO UEXT.CONTRIBUTION_SCALE (AGE_TO,CONTRIBUTION_SCALE_GROUP_ID,CONTRIBUTION_SCALE_ID,CONTRIBUTION_TO, DATE_TO,   ");
            sqlInsertWithCsgId.Append(
                " FIXED_POINTS_ONLY,INCREMENT_AMOUNT,LOWER_AMOUNT, SALARY_TO, SERVICE_TO, UPPER_AMOUNT)  ");
            sqlInsertWithCsgId.Append("VALUES ( {0},{9},{10},{1},{2},{3},{4},{5},{6},{7},{8});  ");
            sqlInsertWithCsgId.Append("end; ");

            return string.Format(sqlInsertWithCsgId.ToString(),
                ageTo, contributionTo, dateToString, fixedPointsOnly, incrementAmount,
                lowerAmount, salaryTo, serviceTo, upperAmount, parentId, contributionScaleId);
        }

//        public string CopySql(int sourceMemberGroupKey, int targetMemberGroupKey)
//        {
//            const string sqlTemplate = @"declare 
//                                v_csg_id number;
//                                v_case_key number;
//                                begin
//                                select CSL.CONTRIBUTION_SCALE_GROUP_ID into v_csg_id from contribution_scale_lookup csl where CSL.MBGP_KEY = {0} and rownum = 1;
//                                select UMG.CASE_KEY into v_case_key from uext_mbr_grp umg where UMG.MBGP_KEY = {1};
//                                delete from contribution_scale_lookup CSL where CSL.MBGP_KEY = {1};
//                                INSERT INTO UEXT.CONTRIBUTION_SCALE_LOOKUP (
//                                       CASE_KEY, CONTRIBUTION_SCALE_GROUP_ID, CONTRIBUTION_SCALE_LOOKUP_ID, 
//                                       MBGP_KEY) 
//                                    VALUES ( v_case_key,
//                                     v_csg_id,
//                                     Contribution_Scale_Lookup_SEQ.nextval,
//                                     {1});
//                                end;";
//            return string.Format(sqlTemplate, sourceMemberGroupKey, targetMemberGroupKey);
//        }

//        public string CloneSql(int sourceMemberGroupKey, int targetMemberGroupKey)
//        {
//            const string sqlTemplate = @"declare 
//                                v_csg_id number;
//                                v_case_key number;
//                                v_new_csg_id number;
//                                begin
//                                select CSL.CONTRIBUTION_SCALE_GROUP_ID into v_csg_id from contribution_scale_lookup csl where CSL.MBGP_KEY = {0} and rownum = 1;
//                                select Contrib_Scale_Group_Id_SEQ.nextval into v_new_csg_id from dual;
//                                
//                                INSERT INTO UEXT.CONTRIBUTION_SCALE (
//                                   AGE_TO, CONTRIBUTION_SCALE_GROUP_ID, CONTRIBUTION_SCALE_ID, 
//                                   CONTRIBUTION_TO, DATE_TO, FIXED_POINTS_ONLY, 
//                                   INCREMENT_AMOUNT, LOWER_AMOUNT, SALARY_TO, 
//                                   SERVICE_TO, UPPER_AMOUNT)                
//                                SELECT 
//                                AGE_TO, v_new_csg_id, Contribution_Scale_SEQ.nextval, 
//                                   CONTRIBUTION_TO, DATE_TO, FIXED_POINTS_ONLY, 
//                                   INCREMENT_AMOUNT, LOWER_AMOUNT, SALARY_TO, 
//                                   SERVICE_TO, UPPER_AMOUNT
//                                FROM CONTRIBUTION_SCALE CS
//                                where CS.CONTRIBUTION_SCALE_GROUP_ID = v_csg_id;
//                                
//                                select UMG.CASE_KEY into v_case_key from uext_mbr_grp umg where UMG.MBGP_KEY = {1};
//                                delete from contribution_scale_lookup CSL where CSL.MBGP_KEY = {1};
//                                INSERT INTO UEXT.CONTRIBUTION_SCALE_LOOKUP (
//                                       CASE_KEY, CONTRIBUTION_SCALE_GROUP_ID, CONTRIBUTION_SCALE_LOOKUP_ID, 
//                                       MBGP_KEY) 
//                                    VALUES ( v_case_key,
//                                     v_new_csg_id,
//                                     Contribution_Scale_Lookup_SEQ.nextval,
//                                     {1});
//                                end;";
//            return string.Format(sqlTemplate, sourceMemberGroupKey, targetMemberGroupKey);
//        }


        public string UpdateVariationSql(ContributionScaleLookup toUpdate)
        {
            const string sqlTemplate = @"
                update CONTRIBUTION_SCALE_LOOKUP csl 
                set CSL.VARIATION_CD = '{0}' 
                where CSL.CONTRIBUTION_SCALE_LOOKUP_ID = {1};
                ";
            return string.Format(sqlTemplate, toUpdate.VariationCode, toUpdate.LookupId);
        }


        public string UpdateGroupSql(Database db, ContributionScaleLookup toUpdate)
        {
            if (!(toUpdate.ContributionGroupId > 0)) toUpdate.ContributionGroupId = SequenceGetter.GetNextVal(db, "CONTRIB_STRUCTURE_GROUP_ID_SEQ");

            const string sqlTemplate = @"
                update contribution_scale_lookup csl 
                set CSL.CONTRIBUTION_SCALE_GROUP_ID = {0} 
                where CSL.CONTRIBUTION_SCALE_LOOKUP_ID = {1};
                ";
            return string.Format(sqlTemplate, toUpdate.ContributionGroupId, toUpdate.LookupId);
        }


        /// <summary>
        /// render insert sql for a new lookup row.
        /// </summary>
        public string InsertCslSql(Database db, ContributionScaleLookup toInsert)
        {
            string vc = toInsert.VariationCode;
            int mk = toInsert.MbGpKey.Value;
            int ck = toInsert.CaseKey.Value;

            if (!(toInsert.LookupId > 0)) toInsert.LookupId = SequenceGetter.GetNextVal(db, "CONTRIBUTION_SCALE_LOOKUP_SEQ");
            if (!(toInsert.ContributionGroupId > 0)) toInsert.ContributionGroupId = SequenceGetter.GetNextVal(db, "CONTRIB_SCALE_GROUP_ID_SEQ");

            Contract.Assert(toInsert.LookupId>0);
            Contract.Assert(toInsert.ContributionGroupId > 0);

            int lookupId = toInsert.LookupId.Value;
            int groupId = toInsert.ContributionGroupId;

            const string sql1 = @"
                INSERT INTO UEXT.CONTRIBUTION_SCALE_LOOKUP 
                (CASE_KEY, CONTRIBUTION_SCALE_GROUP_ID, CONTRIBUTION_SCALE_LOOKUP_ID ,MBGP_KEY, VARIATION_CD)
                VALUES ( {0},{1},{2},{3},'{4}' );
                ";

            string result = String.Format(sql1, ck, groupId, lookupId, mk, vc);
            return result;
        }


        public string DeleteSql(ContributionScaleLookup toUpdate)
        {
            const string sqlTemplate = @"
                delete CONTRIBUTION_SCALE_LOOKUP csl 
                where CSL.CONTRIBUTION_SCALE_LOOKUP_ID = {0};
                ";
            return string.Format(sqlTemplate, toUpdate.LookupId);
        }

    }
}
