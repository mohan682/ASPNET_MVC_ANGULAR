﻿using System;
using Dcorum.BusinessLayer.Entities;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    class PDIMessageSQL
    {
        public static string GetPDIMessagesSql()
        {
            const string sql = @"SELECT * 
                                FROM PDIMessage
                                ORDER BY Type, PDIMessage_Id";
            return sql;
        }

        public static string GetPDIMessagesSql(int messageId)
        {
            const string sql = @"SELECT * 
                                FROM PDIMessage
                                WHERE PDIMessage_Id = {0}
                                ORDER BY PDIMessage_Id";
            return String.Format(sql, messageId);
        }

        public static string InsertPDIMessagesSql(PDIMessage message)
        {
            const string sql = @"INSERT INTO PDIMessage
                                (   PDIMessage_Id,  Type,   Message,    Code) VALUES
                                (   {0},            {1},    '{2}',      '{3}')";

            return String.Format(sql, message.MessageId, message.MessageType.RefCd, message.MessageText, message.MessageCode);
        }

        public static string UpdatePDIMessagesSql(PDIMessage message)
        {
            const string sql = @"UPDATE PDIMessage SET
                                    Type = {1},
                                    Message = '{2}',
                                    Code = '{3}'
                                 WHERE PDIMessage_Id = {0}";

            return String.Format(sql, message.MessageId, message.MessageType.RefCd, message.MessageText, message.MessageCode);
        }
    }
}
