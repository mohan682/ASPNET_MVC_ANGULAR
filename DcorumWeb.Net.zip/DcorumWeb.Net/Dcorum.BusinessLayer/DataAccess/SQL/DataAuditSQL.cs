﻿using System;
using System.Text;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    internal class DataAuditSQL
    {
        internal DataAuditSQL() { }

        private static string _dbDateFormatString = "DD/MM/YYYY HH24:MI:SS";

        private const string SqlSelectTemplate = @"
        SELECT
            DA.Standing_Data_Audit_Id,
            DA.User_Id,
            DA.Audit_Identifier,
            DA.Identifier_Type,
            TO_CHAR(DA.Action_Date, '{0}')										                                            Action_Date,
            DA.Component,
            DA.Operation_Type,
            DA.Existing_Value,
            DA.New_Value,
            DA.Source,
            DECODE(DA.Identifier_Type, 
            'SC', '[' || CD.Cont_No || '] ' || CD.Plan_Nm, 
            'MG', '[' || MG.Mbgp_Key || '] ' || MG.Descript, '[]',
            null, '[' || DA.Audit_Identifier || '] ')    Identifier_Desc,
            coalesce(UR.User_Name,'[' || TO_CHAR(da.User_id) || ']') as USER_NAME
        ";


        private const string SqlFromJoinsTemplate = @"
        FROM
            Standing_Data_Audit	DA
	    LEFT JOIN	Case_Data		    CD 
            ON NVL(DA.Audit_Identifier, -1)	= CD.Case_Key	AND DA.Identifier_Type = 'SC'
        LEFT JOIN	Mbr_Grp			    
            MG ON NVL(DA.Audit_Identifier, -1)  = MG.Mbgp_Key	AND DA.Identifier_Type = 'MG'
        LEFT JOIN	UEXT.Users		    
            UR ON DA.User_Id                    = UR.User_Id                                
        ";

        public string SearchDataAuditSql(DataAudit searchFilter)
        {
            string sql = String.Format(SqlSelectTemplate, _dbDateFormatString)
                          + SqlFromJoinsTemplate
                          + String.Format("WHERE 1 = 1 ");

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat(sql, _dbDateFormatString);
            sb.AppendLine("");

            string operationCategory = searchFilter.OperationType.RefCd;

            if (searchFilter.UserId > -1)
                sb.AppendLine(" AND DA.User_Id = " + searchFilter.UserId + " ");

            if (searchFilter.MbGpKey > 0)
                sb.AppendFormat(" AND (MG.Mbgp_Key = {0} or (DA.Identifier_Type = 'MG' and DA.Audit_Identifier = {0}))  " + Environment.NewLine, searchFilter.MbGpKey.Value);

            if (searchFilter.CaseKey > 0)
                sb.AppendFormat(" AND (CD.CASE_KEY = {0} or MG.CASE_KEY = {0} or (DA.Identifier_Type = 'SC' and DA.Audit_Identifier = {0})) " + Environment.NewLine, searchFilter.CaseKey.Value);

            //if (searchFilter.AuditIdentifier != null)
            //    sb.AppendLine(" AND DA.Audit_Identifier = " + searchFilter.AuditIdentifier + " ");
            //if (!String.IsNullOrWhiteSpace(searchFilter.IdentifierType.RefCd))
            //    sb.AppendLine(" AND DA.Identifier_Type = '" + searchFilter.IdentifierType.RefCd + "' ");

            if (!String.IsNullOrWhiteSpace(searchFilter.AuditComponent.RefCd))
                sb.AppendLine(" AND DA.Component = '" + searchFilter.AuditComponent.RefCd + "' ");
            if (!String.IsNullOrWhiteSpace(operationCategory))
            {
                int asciiValue = operationCategory[0];
                sb.AppendFormat(" AND DA.Operation_Type in ('{0}','{1}') ", operationCategory, asciiValue );
            }
            if (!String.IsNullOrWhiteSpace(searchFilter.SearchFilterStartDate))
                sb.AppendLine(" AND DA.Action_Date >= TO_DATE('" + searchFilter.SearchFilterStartDate + "', '" + _dbDateFormatString + "') ");
            if (!String.IsNullOrWhiteSpace(searchFilter.SearchFilterEndDate))
                sb.AppendLine(" AND DA.Action_Date < TO_DATE('" + searchFilter.SearchFilterEndDate + "', '" + _dbDateFormatString + "') + 1 ");

            string result = sb.ToString();
            return result;
        }

        public string SearchDataAuditByIdSql(int dataAuditId)
        {
            string sql1 = String.Format(SqlSelectTemplate, _dbDateFormatString)
                          + SqlFromJoinsTemplate
                          + String.Format("WHERE DA.Standing_Data_Audit_Id = {0} ", dataAuditId);
            return sql1;
        }
    }
}
