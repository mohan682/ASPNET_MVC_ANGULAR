﻿using System;
using System.Collections.Generic;
using System.Data;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class WebUserInformationSQL
    {
        /// <summary>
        /// NOTE: Can return mulitple email address but these should alredy be ordered by priority.
        /// </summary>
        internal static string GetWebUserInformationSql(int nameId )
        {
            const string RegistrationDescription = "%The member has registered to use %"; //[DD7AUG] should now be compatible with TargetPlan and PlanManager message.

            const string sql = @"
	                            SELECT
                                    UA.USER_ACC_ID,
                                    UA.USER_TYPE,
                                    UA.NAMEID,
                                    O.EMAILDATA,
                                    (	SELECT MAX(DATE_TIME)
                                        FROM CONTACT_HISTORY 
                                        WHERE NAMEID={0} AND CALL_TYPE_CD=6 AND ACTION_TYPE_CD=3 AND LOWER(DESCRIPTION) LIKE LOWER('" + RegistrationDescription + @"')
                                    ) REGISTERED_ON,
                                    (	SELECT MAX(ACTION_DT) 
                                        FROM USER_ACTION 
                                        WHERE ACTION_ID=330 AND USER_ACC_ID=UA.USER_ACC_ID
                                    ) AS LAST_SUCCESSFUL_LOGIN,
                                    (	SELECT MAX(ACTION_DT) 
                                        FROM USER_ACTION 
                                         WHERE ACTION_ID=5 AND USER_ACC_ID=UA.USER_ACC_ID
                                    ) AS LAST_PASSWORD_RESET,
                                    PWD. FAILEDLOGINATTEMPTS FAILED_LOGIN_ATTEMPTS,
                                    PWD. LASTFAILEDATTEMPT LAST_FAILED_ATTEMPT,
                                    CASE
                                        WHEN (
                                                (UA.LOCKED=1 OR PWD. FAILEDLOGINATTEMPTS>=14) OR
                                                (PWD. FAILEDLOGINATTEMPTS >= 5 AND PWD.FAILEDLOGINATTEMPTS < 10 AND (PWD.LASTFAILEDATTEMPT+5/1440)>SYSDATE)
                                                 OR
                                                (PWD. FAILEDLOGINATTEMPTS >= 10 AND PWD.FAILEDLOGINATTEMPTS < 15 AND (PWD.LASTFAILEDATTEMPT+10/1440)>SYSDATE)
                                             )                         
                                        THEN 1
                                        ELSE 0
                                    END TIMED_OUT, 
                                    CASE
                                        WHEN (UA.LOCKED=1 OR PWD. FAILEDLOGINATTEMPTS>=14) THEN NULL
                                        WHEN (PWD. FAILEDLOGINATTEMPTS >= 5 AND PWD.FAILEDLOGINATTEMPTS < 10) THEN PWD.LASTFAILEDATTEMPT+5/1440
                                        WHEN (PWD. FAILEDLOGINATTEMPTS >= 10 AND PWD.FAILEDLOGINATTEMPTS < 15) THEN PWD.LASTFAILEDATTEMPT+10/1440
                                        ELSE NULL
                                    END TIME_OUT_UNTIL,
                                    CASE
                                        WHEN (UA.LOCKED=1) THEN 1
                                        ELSE 0
                                    END LOCKED
	                            FROM
                                    USER_ACC UA
                                    LEFT JOIN V_PARTY_ADDROTHER O on o.nameId = UA.nameId

                                    LEFT JOIN   (
                                                    SELECT AC.USER_ACC_ID, COUNT(*) AS FAILEDLOGINATTEMPTS, MAX(ACTION_DT) AS LASTFAILEDATTEMPT 
                                                    FROM USER_ACTION AC 
                                                    WHERE 
                        		                            (AC.ACTION_ID = 1 OR AC.ACTION_ID = 4) 
                                                    AND	(
                        			                        ACTION_DT between SYSDATE-(10/1440) AND SYSDATE 
                                       		                OR 0 =  (
                                        		                            SELECT COUNT(LAST_ACCESSED) 
							                                                FROM USER_ACC_SESSION WHERE USER_ACC_ID=AC.USER_ACC_ID
                                                                    )
                                                        ) 
                                                    GROUP BY AC.USER_ACC_ID 
                                                ) PWD ON PWD.USER_ACC_ID=UA.USER_ACC_ID 
	                            WHERE UA.NAMEID = {0}
                                AND NVL(O.XPIRDT,sysdate+1)>=trunc(sysdate)
                                ORDER BY nvl(O.PRIMARY, 0) DESC, O.EMAILTYPE
";

            return string.Format(sql, nameId);
        }

        internal static string UnlockWebUserAccountSql(WebUserInformation webUser)
        {
            const string sql = @"BEGIN
                                    UPDATE UEXT.USER_ACC SET LOCKED=0, LAST_UNLOCKED=sysdate WHERE NAMEID = {0}; 
                                    UPDATE UEXT.USER_ACC SET ForcePassWordReset = '1' WHERE NAMEID = {0} AND User_Type = 5  
                                    AND NOT EXISTS (
					                                    SELECT 1 
                                                        FROM
                    			                                    User_Security_Questions	SQ 
                                                        INNER JOIN	User_Acc				UA	ON SQ.User_Acc_Id = UA.User_Acc_Id
                                                        WHERE
                    	                                    UA.NameId = {0}
                                                    );
    
                                    UPDATE User_Acc_Session SET Last_Accessed = SYSDATE
                                    WHERE User_Acc_Session_Id = (
				                                                    SELECT MAX(US.User_Acc_Session_Id)
                                                                    FROM
                                	                                    User_Acc_Session 	US,
                                                                        User_Acc		    UA
                                                                    WHERE
                                	                                    UA.User_Acc_Id = US.User_Acc_Id
                                                                    AND	UA.NameId = {0}
			                                                    );
                                END;";

            return string.Format(sql, webUser.NameId);
        }

        internal static string LockWebUserAccountSql(WebUserInformation webUser)
        {
            const string sql = @"UPDATE UEXT.USER_ACC SET LOCKED = 1 WHERE NAMEID = {0}";

            return string.Format(sql, webUser.NameId);
        }

        internal static string DeregisterWebUserAccountSql(int nameId)
        {
            const string sql = @"
                        DECLARE
                            pCaseMemberKey          Case_Members.Case_Mbr_Key%Type ;
                            lNameId                 User_Acc.NameId%Type:= {0};
                            lUserAccId              User_Acc.User_Acc_Id%Type;
                            lAddrOtherId            AddrOther.AddrOtherId%Type;
                            lEmailType              AddrOther.EmailType%Type;
                            lPasswordLastChanged    User_Acc.Password_Last_Changed%Type;
                        BEGIN
                            SELECT
                                    UA.User_Acc_Id,UA.NameId, UA.Password_Last_Changed INTO lUserAccId,lNameId, lPasswordLastChanged 
                                FROM
                                    User_Acc    UA
                                WHERE
                                    UA.NameId=lNameId;

                                UPDATE Uext_Case_Members SET
                                        Primary_Account             = NULL,
                                        Modeller_Permission_Id      = NULL
                                WHERE
                                            Case_Mbr_Key in (
                                                                SELECT UCM.CASE_MBR_KEY FROM UEXT_CASE_MEMBERS UCM
                                                                INNER JOIN  CASE_MEMBERS CM ON CM.CASE_MBR_KEY=UCM.CASE_MBR_KEY WHERE CM.NAMEID=lNameId
                                                            );

                                SELECT    AO.AddrOtherId, AO.EmailType INTO lAddrOtherId, lEmailType
                                FROM  
                                        PartyXRef           PX
                                INNER JOIN  AddrOther       AO ON PX.RefKey         = AO.AddrId         AND NVL(AO.XpirDt, SYSDATE + 1)     > SYSDATE
                                INNER JOIN  Uext_AddrOther  UO ON AO.AddrOtherId    = UO.AddrOtherId    AND UO.Primary          = 1
                                WHERE
                                    PX.RefType          = 'COMM'
                                AND PX.NameId           = lNameId;
        
                                DELETE FROM Uext_AddrOther WHERE AddrOtherId = lAddrOtherId;
                                DELETE FROM AddrOther WHERE AddrOtherId = lAddrOtherId;

                                UPDATE AddrOther SET XpirDt = NULL WHERE AddrOtherId IN 
                                (
                                        SELECT  AO.AddrOtherId 
                                        FROM  
                                                PartyXRef        PX,
                                                AddrOther        AO
                                        WHERE
                                               PX.RefKey            = AO.AddrId
                                        AND    PX.RefType           = 'COMM'
                                        AND    PX.NameId            = lNameId
                                        AND    AO.EmailType         = lEmailType
                                        AND    AO.EffectDt          = (
                                                                        SELECT  MAX(EffectDt) FROM  
                                                                                PartyXRef        PX,
                                                                                AddrOther        AD
                                                                        WHERE
                                                                               PX.RefKey    = AD.AddrId
                                                                        AND    PX.RefType   = 'COMM'
                                                                        AND    PX.NameId    = lNameId
                                                                        AND    AD.EmailType = lEmailType
                                                                       )
                                        
                                );

                                DELETE FROM UEXT.Pending_Switch_Request_Detl    WHERE Pending_Switch_Request_Id IN (SELECT Pending_Switch_Request_Id FROM UEXT.Pending_Switch_Request WHERE Case_Mbr_Key = pCaseMemberKey);
                                DELETE FROM UEXT.Pending_Switch_Request        WHERE Case_Mbr_Key = pCaseMemberKey;
     
                                DELETE FROM UEXT.Profile_Milestone_Account    WHERE Case_Mbr_Key = pCaseMemberKey;
                                DELETE FROM UEXT.Profile_Milestone_Person    WHERE NameId = lNameId;
                                DELETE FROM UEXT.Pdi_User_Acc_Role        WHERE User_Acc_Id = lUserAccId;
                                DELETE FROM UEXT.User_Security_Questions    WHERE User_Acc_Id = lUserAccId;
                                DELETE FROM UEXT.User_Acc_Password_History    WHERE User_Acc_Id = lUserAccId;
                                DELETE FROM UEXT.User_Acc_Session        WHERE User_Acc_Id = lUserAccId;
                                -- For Plan Manager Admin Users
                                UPDATE UEXT.User_Acc_Session  SET ADMIN_USER_ACC_ID=NULL   WHERE ADMIN_USER_ACC_ID = lUserAccId;
                                DELETE FROM UEXT.USER_ACC_DEFAULT_SCHEME        WHERE User_Acc_Id = lUserAccId;
                                DELETE FROM UEXT.User_Action            WHERE User_Acc_Id = lUserAccId;
                                DELETE FROM UEXT.Modeller_User_Generic        WHERE User_Acc_Id = lUserAccId;                               
                                
                                -- mypath related information
                                DELETE MODEL_DECUM_PREF WHERE User_Acc_Id = lUserAccId;
                                DELETE MODEL_EXT_PENSION WHERE User_Acc_Id = lUserAccId;
                                DELETE MODEL_INCOME WHERE User_Acc_Id = lUserAccId;
                                DELETE MODEL_INTERNAL_PENSION WHERE User_Acc_Id = lUserAccId;
                                DELETE MODEL_INV_STRATEGY WHERE User_Acc_Id = lUserAccId;
                                DELETE MODEL_SESSION WHERE User_Acc_Id = lUserAccId;
                                DELETE MODEL_TARGET WHERE User_Acc_Id = lUserAccId;
                              
                                DELETE FROM UEXT.User_Acc            WHERE User_Acc_Id = lUserAccId;
        
                                COMMIT;
                        END;";

            return string.Format(sql, nameId);
        }


        internal static string GetAccountInfoForRegistrationSql(int? nameId = null, int? caseKey = null, string email = null, int? caseMemberKey = null)
        {
            const string sql1 = @"
    SELECT
        UA.User_Acc_Id,	UA.Chkn_Slt_Hsh,	f1.NameId,		CM.Case_Mbr_Key,	UM.Case_Mbr_Key	Uext_Mbr_Key,	
        UO.Primary,		AO.EmailType,	
        AO.AddrotherId,		UO.AddrotherId	Uext_AddrOth_Id, PX.RefKey	AddrId, AO.EMAILDATA,NVL(UO.contact,0) IsContactEmail
    FROM
        Person f1 
    LEFT JOIN	User_Acc			UA	ON	f1.NameId				= UA.NameId
    --INNER JOIN	Case_Data			CD	ON	CM.Case_Key				= CD.Case_Key
    INNER JOIN	PartyXref			PX	ON	f1.NameId				= PX.NameId			AND	PX.RefType					= 'COMM'
    LEFT JOIN	AddrOther			AO	ON	PX.RefKey				= AO.AddrId			AND NVL(AO.XpirDt, SYSDATE + 1)	>= TRUNC(SYSDATE)
    LEFT JOIN	Uext_Addrother		UO	ON	AO.AddrotherId			= UO.AddrotherId 
                                
    LEFT JOIN     Case_members        CM    on f1.nameId = cm.nameId
    LEFT JOIN	Uext_Case_Members	UM	ON	CM.Case_Mbr_Key			= UM.Case_Mbr_Key

    WHERE
        {0}
	ORDER BY
        CM.Case_Mbr_Key, nvl(UO.Primary,0) DESC,        AO.EmailType
    ";

            string subClause = null;

            if (caseMemberKey.HasValue) subClause = String.Format("CM.Case_Mbr_Key	= {0}", caseMemberKey.Value);
            else if (nameId.HasValue)
            {
                string beforeAnd = "f1.NAMEID " + nameId.IntoSqlValue().IntoSqlWithOperatorPrefix();
                string afterAnd = "cm.case_key " + caseKey.IntoSqlValue().IntoSqlWithOperatorPrefix();
                subClause = String.Format("{0} and {1}", beforeAnd, afterAnd);
            }
            else if (!String.IsNullOrWhiteSpace(email)) subClause = String.Format("upper(AO.EMAILDATA) = upper('{0}')",email);
            else throw new ArgumentException();

            string result = string.Format(sql1, subClause);
            return result;
        }


//        internal static string GetUserAccountsThatShareEmailSql(int nameId)
//        {
//            const string sql = @"
//select * from uext.user_acc where nameId in
//(
//select nameId from uext.v_party_addrother f1
//
//where nvl(xpirdt,sysdate+1) > sysdate
//
//and upper(emaildata) in (select upper(emaildata) from uext.v_party_addrother where nameid = {0}) 
//
//group by nameId
//)
//
//order by nameId";

//            return string.Format(sql, nameId);
//        }

        internal static List<DbParam> BuildAccountEnrollmentParams(TPAccountSetUp enrollmentInfo)
        {
            List<DbParam> dbParams = new List<DbParam>();

            dbParams.Add(new DbParam() { Name = "p_UserAccId", Type = DbType.Int32, Value = enrollmentInfo.UserAccId.IntoDbParamObject( _ => _ < 1), Direction = ParameterDirection.Input });
            dbParams.Add(new DbParam() { Name = "p_NameId", Type = DbType.Int32, Value = enrollmentInfo.NameId, Direction = ParameterDirection.Input });
            dbParams.Add(new DbParam() { Name = "p_CaseMemberKey", Type = DbType.Int32, Value = enrollmentInfo.CaseMemberKey, Direction = ParameterDirection.Input });

            dbParams.Add(new DbParam() { Name = "p_UextCaseMemberKey", Type = DbType.Int32, Value = enrollmentInfo.UextCaseMemberKey.IntoDbParamObjectN( _ => _ == 0), Direction = ParameterDirection.Input });

            dbParams.Add(new DbParam() { Name = "p_AddressId", Type = DbType.Int32, Value = enrollmentInfo.AddrId.IntoDbParamObjectN(_ => _ == 0), Direction = ParameterDirection.Input });
            
            dbParams.Add(new DbParam() { Name = "p_EmailAddressId", Type = DbType.Int32, Value = enrollmentInfo.EmailAddressId.IntoDbParamObjectN( _ => _ == 0), Direction = ParameterDirection.Input });

            dbParams.Add(new DbParam() { Name = "p_UextEmailAddressId", Type = DbType.Int32, Value = enrollmentInfo.UextAddrId.IntoDbParamObjectN(_ => _ == 0), Direction = ParameterDirection.Input });

            dbParams.Add(new DbParam() { Name = "p_EmailAddress", Type = DbType.String, Value = enrollmentInfo.EmailData, Direction = ParameterDirection.Input });
            dbParams.Add(new DbParam() { Name = "p_EmailType", Type = DbType.String, Value = enrollmentInfo.EmailType, Direction = ParameterDirection.Input });
            dbParams.Add(new DbParam() { Name = "p_IsPrimaryEmail", Type = DbType.Int32, Value = enrollmentInfo.IsPrimary.IntoSqlBool(), Direction = ParameterDirection.Input });
            dbParams.Add(new DbParam() { Name = "p_IsContactEmail", Type = DbType.Int32, Value = enrollmentInfo.IsContactEmail.IntoSqlBool(), Direction = ParameterDirection.Input });
            dbParams.Add(new DbParam() { Name = "p_Password", Type = DbType.String, Value = DBNull.Value, Direction = ParameterDirection.Input });

            dbParams.Add(new DbParam() { Name = "o_Success", Type = DbType.Int16, Value = DBNull.Value, Direction = ParameterDirection.Output, Size = 10 });


            return dbParams;
        }
    }
}
