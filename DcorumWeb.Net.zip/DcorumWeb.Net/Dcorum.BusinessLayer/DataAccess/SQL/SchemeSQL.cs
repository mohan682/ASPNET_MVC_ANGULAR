﻿using System;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities.Extensions;
using Dcorum.BusinessCore.DataAccess.Sql;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class SchemeSQL
    {
        internal SchemeSQL() { }

        public const string ThinSqlSelectTemplate = CommonSqlSelectStatements.SqlSelect6ColsCaseDataAndPlanTypeTemplate ;

        private const string SelectTemplate = @"
        select 
            CD.CASE_KEY, CD.CONT_NO, CD.PLAN_NM, CD.OVRD_CO_CD, CD.PROD_TYP_CD, J1.plan_typ_cd,    
            TO_CHAR(UCD.ENROLMENT_START_DATE, 'DD/MM/YYYY') ENROLMENT_START_DT_FORMATTED,
            TO_CHAR(UCD.ANNUAL_INCOME_INC_DT, 'DD/MM/YYYY') ANNUAL_INCOME_INC_DT_FORMATTED,
            UCD.*
        from
            uext_case_data ucd 
        LEFT JOIN Plan_Type_Hist j1 on 
            j1.case_key = UCD.CASE_KEY
            and trunc(j1.eff_dt)<=sysdate AND NVL(j1.XPIR_DT,sysdate) >= sysdate
        inner join case_data cd on 
            CD.CASE_KEY= UCD.CASE_KEY
        ";

        public string GetSchemeSettingSql(int caseKey)
        {
            const string sqlTemplate = SelectTemplate + "where CD.CASE_KEY= {0}";
            return string.Format(sqlTemplate, caseKey);
        }

        public string GetSchemeByExternalIdSql(string externalId)
        {
            const string sqlTemplate = SelectTemplate + "where CD.CONT_NO= '{0}'";
            return string.Format(sqlTemplate, externalId);
        }

        internal string GetDecumSchemesSql(int accumeSchemeId)
        {
            const string sqlFragment1 = @"
    INNER JOIN uext_case_data ucd on UCD.case_KEY=CD.CASE_KEY
    INNER JOIN REF_CODES RC ON CD.PROD_TYP_CD = RC.REF_CD AND DOMAIN_NAME = 'DRAWDOWN PRODUCTS'
    --INNER JOIN V_SCHEME ACUM ON CD.OVRD_CO_CD = ACUM.OVRD_CO_CD

    WHERE  CD.GENL_SUSP_CD <> 'P' --AND ACUM.CASE_KEY = {0}
";
            string sql = String.Format(ThinSqlSelectTemplate, sqlFragment1);
            return sql;
        }


        public string GetAllSchemesSql()
        {
            string sql = String.Format(ThinSqlSelectTemplate, String.Empty);
            return sql;
        }


        public string GetAllTargetPlanSchemesSql()
        {
            const string sqlFragment1 = @"
    INNER JOIN UEXT_CASE_DATA UC ON CD.CASE_KEY = UC.CASE_KEY
    WHERE UC.Target_Plan_Enabled = 1
";

            string sql = String.Format(ThinSqlSelectTemplate, sqlFragment1);
            return sql;
        }


        public string UpdateSchemeSql(SchemeFull schemeRec)
        {
            const string sqlTemplate = @"UPDATE UEXT.UEXT_CASE_DATA UCD SET    
                TARGET_PLAN_ENABLED             = {1},
                STP_DISABLED                    = {2},
                HAS_ASSOCIATED_DB_SCHEME        = {3},
                SHORTFALL                       = {4},
                TAX_LIABILITY                   = {5},
                INVESTMENTS_PERMISSION_ID       = {6},
                CONTRIBUTION_PERMISSION_ID      = {7},
                PERSONAL_DETAILS_PERMISSION_ID  = {8},
                CONTACT_DETAILS_PERMISSION_ID   = {9},
                SET_TRA_PERMISSION_ID           = {10},
                SECURITY_DETAILS_PERMISSION_ID  = {11},
                INVESTMENTS_DEF_PERMISSION_ID   = {12},
                CONTRIBUTION_DEF_PERMISSION_ID  = {13},
                PERSONAL_DTL_DEF_PERMISSION_ID  = {14},
                CONTACT_DTL_DEF_PERMISSION_ID   = {15},
                SET_TRA_DEF_PERMISSION_ID       = {16},
				HIDE_MESSAGE_CENTRE				= {17}, 
				HIDE_MY_PENSION_TAB				= {18}, 
				HIDE_PENSION_ESSENTIALS_TAB		= {19},
				HIDE_MY_INCOME_TAB				= {20},
				PAYROLL_AUTO                    = {21},
                DRAWDOWN_MBR_OVERRIDE_ENABLED   = {22},
                LIFEPATH_TYPE_DEFAULT           = {23},                                      
                WF_MGR_PERMISION_ID             = {24},
                CONTRIB_MGR_PERMISION_ID        = {25},
                REPORT_MGR_PERMISION_ID         = {26},
                MEMBER_MGR_PERMISION_ID         = {27},
                MESSAGE_CENTER_PERMISION_ID     = {28},
                ENROLMENT_START_DATE	        = {29},
                ANNUAL_INCOME_INC_DT	        = {30},
                ASSOCIATED_DECUM_SCHEME	        = {31},
                HIDE_ISA_TAB                    = {32},
                ISA_MBR_OVERRIDE_ENABLED        = {33},
                WORKPLACE_ISA_REF               = {34}
                where
                    UCD.CASE_KEY = {0}
";

            string result = string.Format(sqlTemplate, schemeRec.CaseKey,
                schemeRec.TargetPlanEnabled,
                schemeRec.STPDisabled.SqlQuotify(),
                schemeRec.HasAssociatedDBScheme,
                schemeRec.ShortFall.SqlQuotify(),
                schemeRec.TaxLiability.SqlQuotify(),
                schemeRec.InvestmentPermissionActive.IntoSqlValue(),
                schemeRec.ContribPermissionActive.IntoSqlValue(),
                schemeRec.PersonalDetailsPermissionActive.IntoSqlValue(),
                schemeRec.ContactDetailsPermissionActive.IntoSqlValue(),
                schemeRec.SetTRAPermissionActive.IntoSqlValue(),
                schemeRec.SecurityDetailsPermissionActive.IntoSqlValue(),
                schemeRec.InvestmentPermissionDeferred.IntoSqlValue(),
                schemeRec.ContribPermissionDeferred.IntoSqlValue(),
                schemeRec.PersonalDetailsPermissionDeferred.IntoSqlValue(),
                schemeRec.ContactDetailsPermissionDeferred.IntoSqlValue(),
                schemeRec.SetTraPermissionDeferred.IntoSqlValue(),
                schemeRec.HideMessageCentre.IntoSqlValue(),
                schemeRec.HideMyPensionTab.IntoSqlValue(),
                schemeRec.HidePensionEssentialsTab.IntoSqlValue(),
                schemeRec.HideMyIncomeTab.IntoSqlValue(),

                schemeRec.PayrollAuto.IntoSqlValue(),

                schemeRec.DrawdownMemberOverrideModeOn.IntoSqlBool(),
                schemeRec.LifePathTypeDefault.SqlQuotify(),

                schemeRec.WorkforceAccessLevel.IntoSqlValue(),
                schemeRec.OcpAccessLevel.IntoSqlValue(),
                schemeRec.ReportManangerAccessLevel.IntoSqlValue(),
                schemeRec.MemberSearchAccessLevel.IntoSqlValue(),
                schemeRec.MessageCenterAccessLevel.IntoSqlValue(),
                schemeRec.EnrolmentStartDate.IntoDateTimeN().ToSqlShortDateString(),
                schemeRec.AnnualIncomeIncreaseDate.IntoDateTimeN().ToSqlShortDateString(),
                schemeRec.AssociatedDecumeScheme.IntoSqlValue(),

                schemeRec.HideISATab.IntoSqlValue(),
                schemeRec.IsaMemberOverrideEnabled.IntoSqlBool(),
                schemeRec.WorkplaceIsaRef.SqlQuotify()

                );

            return result;
        }

        public string IsSchemeAllowedInvestmentByMoneyType(int caseKey)
        {
            string sql = @"SELECT ALLOW_INV_BY_MNY_TYP  FROM UEXT_CASE_DATA WHERE CASE_KEY="+caseKey;
            return sql;
        }
        public string IsSchemeAllowedDrawdown(int? caseKey)
        {
            string sql = @"SELECT VALUE FROM SCHEME_PERMISSION_FLAG WHERE CASE_KEY=" + caseKey + " AND FLAG_CODE = 'Enable_Drawdown' AND VALUE=1";
            return sql;
        }

    }
}
