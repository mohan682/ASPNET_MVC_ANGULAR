﻿using System;
using System.Collections.Generic;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Enums;
using Dcorum.Utilities.DataAccess;


namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class DemoUserSQL
    {
        internal DemoUserSQL() { }


        private const string SqlSelectTemplate = @"
            SELECT DISTINCT
                UA.User_Acc_Id,
                UA.Chkn_Slt_Hsh ,
                UA.User_Type,
                UA.Locked,
                PER.Nameid,
                PER.Firstname,
                PER.Midname,
                PER.Lastname,
                PER.Sexcd,
                PER.BIRTHDT,
                PER.NAMEPREFIX,
                AO.Emaildata,
                CASE WHEN AO.Xpirdt < SYSDATE THEN 0 ELSE 1 END ACTIVE,
                AD.Static_Response_Group_Id,
                AD.User_Acc_Demo_Id,
                AD.Descript,
                AO.ADDROTHERID,
                s1.groupTotal
            FROM PERSON PER
                INNER JOIN Partyxref PXR ON PXR.Nameid=PER.Nameid AND PXR.Reftype='COMM'
                INNER JOIN Addrother AO ON AO.Addrid=PXR.Refkey 
                INNER JOIN User_Acc UA ON UA.Nameid=PER.Nameid
                LEFT JOIN User_Acc_Demo AD on UA.User_Acc_Id = AD.User_Acc_Id
                LEFT JOIN ( 
                    SELECT user_acc_demo_id, count(*) groupTotal from demo_user_Resp_group f1 
                    --where f1.user_acc_demo_id = AD.user_acc_demo_id
                    group by f1.user_acc_demo_id
                    ) s1
                on s1.user_acc_demo_id = AD.User_Acc_Demo_Id
            ";


        public string GetDemoUsers()
        {
            return SqlSelectTemplate + String.Format("WHERE UA.User_Type = {0} ORDER BY AO.Emaildata ", (int)UserType.Demo);
        }

        public string GetDemoUserByUserAccId(int userAccId)
        {
            return SqlSelectTemplate + String.Format("WHERE UA.User_Acc_Id = {0} ORDER BY AO.Emaildata ", userAccId);
        }


        public string GetPossibleDuplicates(DemoUser toUse )
        {
            string result = SqlSelectTemplate + String.Format("WHERE AO.Emaildata = '{0}' and UA.User_Type = {1} ", toUse.UserName, (int)toUse.UserType );
            return result;
        }


        public IEnumerable<string> Update(DemoUser demoUser, bool includePasswordUpdate = false)
        {
            yield return $@"UPDATE PERSON
                                SET FIRSTNAME = {demoUser.FirstName.SqlQuotify()}, 
                                MIDNAME = {demoUser.MidName.SqlQuotify()}, 
                                LASTNAME = {demoUser.LastName.SqlQuotify()}, 
                                BIRTHDT = {demoUser.DateOfBirth.ToSqlShortDateString()}, 
                                NAMEPREFIX = {demoUser.Title.RefCd.SqlQuotify()}
                            WHERE NAMEID = {demoUser.NameId}";

            yield return $@"UPDATE ADDROTHER
                                SET EMAILDATA = LOWER({demoUser.UserName.SqlQuotify()})
                            WHERE ADDRID = (SELECT PXR.REFKEY FROM PERSON PER
                            INNER JOIN PARTYXREF PXR
                                ON PXR.NAMEID = PER.NAMEID AND PXR.REFTYPE = 'COMM'
                            INNER JOIN USER_ACC UC
                                ON UC.NAMEID = PER.NAMEID
                            WHERE PER.NAMEID ={demoUser.NameId})";

            yield return $@"UPDATE UEXT.USER_ACC
                                SET Locked = {(demoUser.IsLocked ? 1 : 0)}
                                     {(!demoUser.IsLocked ? string.Format(", LAST_UNLOCKED=sysdate") : string.Empty)}
                                     {(includePasswordUpdate ? string.Format(", CHKN_SLT_HSH = '{0}'", demoUser.GetSecurePassword()) : string.Empty)}
                            WHERE USER_ACC_ID={demoUser.AccountId}";
      
            if (demoUser.UserAccDemoId != null)
            {
                yield return UpdateUserAccDemo(demoUser);
            }
        }

        public string Insert(DemoUser baseUser)
        {
            const string sqlTemplate = @"   DECLARE
                                                LOPRNDTTM       DATE;
                                                LTEMPSTR        VARCHAR2(50);
                                                LACCID          USER_ACC.USER_ACC_ID%TYPE; 
                                                LADDROTHID      ADDROTHER.ADDROTHERID%TYPE;        
                                                LLASTREFKEY     PARTYXREF.REFKEY%TYPE;

                                                lNAMEID         NUMBER(8) := NULL;
                                                EMAILADD        VARCHAR2(50) := '{0}';
                                                PASSWORD        VARCHAR2(50) := '{1}'; 

                                                O_SUCCESS       NUMBER := NULL;
                                            BEGIN
                                                LOPRNDTTM := SYSDATE;
                                                LTEMPSTR := SUBSTR(TRANSLATE(UPPER(SUBSTR(EMAILADD, 1, INSTR(EMAILADD, '.', 1))), 'BAEIOU.@-_', 'B'),1,20);
                                                BEGIN
                                                    SELECT
                                                            PER.NAMEID, O.ADDROTHERID,  U.USER_ACC_ID  INTO lNAMEID,    LADDROTHID,     LACCID
                                                    FROM
                                                        PERSON PER,       ADDROTHER    O,                PARTYXREF    X, USER_ACC    U
                                                    WHERE
                                                        O.ADDRID            = X.REFKEY
                                                    AND X.REFTYPE           = 'COMM'
                                                    AND PER.NAMEID          = X.NAMEID
                                                    AND PER.NAMEID          = U.NAMEID(+)
                                                    AND U.USER_TYPE         = {7}
                                                    AND LOWER(O.EMAILDATA)  = LOWER(EMAILADD);

                                                    DELETE FROM PERSONCOMPASS  WHERE NAMEID = lNAMEID;        
                                                    DELETE FROM PERSON  WHERE NAMEID = lNAMEID;                                              
                                                    DELETE FROM USER_ACC_SESSION WHERE USER_ACC_ID = NVL(LACCID, -100);
                                                    DELETE FROM USER_ACC WHERE USER_ACC_ID = NVL(LACCID, -100);
                                                    DELETE FROM PARTYXREF WHERE NAMEID = lNAMEID;
                                                    DELETE FROM UEXT_ADDROTHER WHERE ADDROTHERID = LADDROTHID;
                                                    DELETE FROM ADDROTHER WHERE ADDROTHERID = LADDROTHID;
                                                EXCEPTION
                                                    WHEN NO_DATA_FOUND THEN
                                                        lNAMEID := {5};  

                                                        INSERT INTO PARTY (NAMEID,  CLIENT_ID,  PARTYTYPE, EFFECTDT,      SEARCHKEY) 
                                                        VALUES            (lNAMEID, lNAMEID,    'P',       LOPRNDTTM - 1, LTEMPSTR);
                                                END;    
                          
                                                LLASTREFKEY := ADDR_SEQ.NEXTVAL;
        
                                                INSERT INTO PERSON ( NAMEID,    CLIENT_ID,  FIRSTNAME,  MIDNAME,    LASTNAME,   PASSPORT_NO,    BIRTHDT,    NAMEPREFIX )  VALUES 
                                                                   ( lNAMEID,   lNAMEID,    '{2}',      '{3}',      '{4}',      'DEMO',         {8},        '{9}');

                                                INSERT INTO PERSONCOMPASS (NAMEID,  LANG_PREF_CD,   MAR_STAT_CD)  VALUES  (lNAMEID,     '1',    '9');

                                                INSERT INTO ADDROTHER (ADDROTHERID,           EMAILTYPE, EMAILDATA,     ADDRID,      EFFECTDT,      LAST_MOD_DT,    LAST_MOD_USER)
                                                VALUES                (ADDROTHER_SEQ.NEXTVAL, '01',      EMAILADD,      LLASTREFKEY, LOPRNDTTM - 1, LOPRNDTTM,      'PDI-SCRIPT' );

                                                INSERT INTO PARTYXREF (NAMEID, REFKEY, REFTYPE) VALUES (lNAMEID, LLASTREFKEY, 'COMM');
                
                                                INSERT INTO UEXT_ADDROTHER (ADDROTHERID, PRIMARY, CONTACT) VALUES    (ADDROTHER_SEQ.CURRVAL, 1, 1);

                                                INSERT INTO USER_ACC    (USER_ACC_ID,   NAMEID,    USER_TYPE,   CHKN_SLT_HSH) VALUES 
                                                                        ({6},           lNAMEID,   {7},         PASSWORD);

                                                UEXT.PDI.UPDATE_SECURITY_QUESTIONS ( EMAILADD, 
                                                            'Test question1', 'test1', 
                                                            'Test question2', 'test2', 
                                                            'Test question3', 'test3', 
                                                            'Test question4', 'test4', 
                                                            'Test question5', 'test5', 
                                                            O_SUCCESS );

                                            END;";

            return string.Format(sqlTemplate, baseUser.UserName,
                baseUser.GetSecurePassword(), baseUser.FirstName, baseUser.MidName,
                baseUser.LastName, baseUser.NameId, baseUser.AccountId, (int)baseUser.UserType, baseUser.DateOfBirth.ToSqlShortDateString(), baseUser.Title.RefCd);
        }

        public string InsertUserAccDemo(DemoUser demoUser)
        {
            const string sql = @"   INSERT INTO User_Acc_Demo (
                                            User_Acc_Demo_Id,   User_Acc_Id,    Static_Response_Group_Id,   Descript) VALUES (
                                            {0},                {1},            {2},                        {3}) ";

            return string.Format(sql, demoUser.UserAccDemoId.IntoSqlValue(), demoUser.AccountId, demoUser.StaticResponseGroupId.IntoSqlValue(), demoUser.LongDescription.SqlQuotify());
        }


        private string UpdateUserAccDemo(DemoUser demoUser)
        {
            if (demoUser.UserAccDemoId == null) return null ;
            const string sql = @"UPDATE User_Acc_Demo SET   Static_Response_Group_Id = {1}, Descript ={2} WHERE User_Acc_Demo_Id = {0} ";

            return string.Format(sql, demoUser.UserAccDemoId.IntoSqlValue(), demoUser.StaticResponseGroupId.IntoSqlValue(), demoUser.LongDescription.SqlQuotify());
        }


        public IEnumerable<string> Delete(DemoUser model)
        {
            int userAccId = model.AccountId;
           
            int nameId = model.NameId;

            if (model.UserAccDemoId.HasValue)
            {
                int demoUserId = model.UserAccDemoId.Value;
                yield return String.Format("DELETE FROM demo_user_Resp_group WHERE User_Acc_Demo_ID = {0}", demoUserId);
            }

            yield return String.Format("DELETE FROM User_Acc_Demo_Param WHERE User_Acc_Id = {0}", userAccId);
            yield return String.Format("DELETE FROM User_Acc_Demo WHERE User_Acc_Id = {0}", userAccId);
            yield return String.Format("DELETE FROM USER_ACC_SESSION WHERE USER_ACC_ID = {0}", userAccId);
            yield return String.Format("DELETE FROM User_Security_Questions WHERE User_Acc_Id = {0}", userAccId);
            yield return String.Format("DELETE FROM USER_ACC WHERE USER_ACC_ID = {0}", userAccId);

            yield return String.Format("DELETE FROM PARTYXREF WHERE NAMEID = {0}", nameId);

            if (model.AddressOtherId.HasValue)
            {
                int addressOtherId = model.AddressOtherId.Value;
                yield return String.Format("DELETE FROM UEXT_ADDROTHER WHERE ADDROTHERID = {0}", addressOtherId);
                yield return String.Format("DELETE FROM ADDROTHER WHERE ADDROTHERID = {0}", addressOtherId);
            }

            yield return String.Format("DELETE FROM PERSONCOMPASS  WHERE NAMEID = {0}", nameId);
            yield return String.Format("DELETE FROM PERSON  WHERE NAMEID = {0}", nameId);
        }
    }
}
