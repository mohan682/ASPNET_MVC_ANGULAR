﻿using System;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.DataAccess.SQL
{
    public class AssetClassGrowthRateSQL
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal AssetClassGrowthRateSQL()  { }
        public const string SequenceName = "ASSET_CLASS_GROWTH_RT_ID_SEQ" ;


        public string GetAssetClassGrowthRatesSQL()
        {
            const string sql = @"SELECT * 
                                FROM ASSET_CLASS_GROWTH_RT
                                ORDER BY 1,2";
            return sql;
        }


        public string GetAssetClassGrowthRateSQL(int assetClassGrowthRateId)
        {
            const string sql = @"SELECT * 
                                FROM ASSET_CLASS_GROWTH_RT
                                WHERE ASSET_CLASS_GROWTH_RT_ID = {0}";
            return String.Format(sql, assetClassGrowthRateId);
        }


        public string InsertAssetClassGrowthRateSql(AssetClassGrowthRate assetClassGrowthRate)
        {
            const string sql = @"INSERT INTO ASSET_CLASS_GROWTH_RT
                                (   ASSET_CLASS_GROWTH_RT_ID,  ASSET_CODE,   OVERRIDE_TYPE,    OVERRIDE_TYPE_CD, GROWTH_RATE_LOW, GROWTH_RATE_MID, GROWTH_RATE_HIGH, GROWTH_RATE_SMPI) VALUES
                                (   {0}, {1}, {2}, {3},'{4}','{5}','{6}', '{7}')";
          
            return String.Format(sql, assetClassGrowthRate.AssetClassGrowthRateId, assetClassGrowthRate.AssetClass.IntoSqlValue(), assetClassGrowthRate.OverrideType.SqlQuotify(), assetClassGrowthRate.Provider.IntoSqlValue(), assetClassGrowthRate.Low, assetClassGrowthRate.Medium, assetClassGrowthRate.High, assetClassGrowthRate.SMPI);
        }


        public string UpdateAssetClassGrowthRateSql(AssetClassGrowthRate assetClassGrowthRate)
        {
            const string sql = @"UPDATE ASSET_CLASS_GROWTH_RT SET
                                    ASSET_CODE = {1},
                                    OVERRIDE_TYPE = {2},
                                    OVERRIDE_TYPE_CD = {3},
                                    GROWTH_RATE_LOW = '{4}',
                                    GROWTH_RATE_MID = '{5}',
                                    GROWTH_RATE_HIGH = '{6}',
                                    GROWTH_RATE_SMPI = '{7}'
                                 WHERE ASSET_CLASS_GROWTH_RT_ID = {0}";
        
            return String.Format(sql, assetClassGrowthRate.AssetClassGrowthRateId, assetClassGrowthRate.AssetClass.IntoSqlValue(), assetClassGrowthRate.OverrideType.SqlQuotify(), assetClassGrowthRate.Provider.IntoSqlValue(), assetClassGrowthRate.Low, assetClassGrowthRate.Medium, assetClassGrowthRate.High, assetClassGrowthRate.SMPI);
        }


        public string DeleteAssetClassGrowthRateSql(AssetClassGrowthRate assetClassToDelete)
        {
            const string template1 = @"
DELETE FROM 
    ASSET_CLASS_GROWTH_RT 
WHERE 
    ASSET_CLASS_GROWTH_RT_ID = {0}
";

            return string.Format(template1,assetClassToDelete.AssetClassGrowthRateId);
        }


        internal string SelectAlternativeKeyMatches(AssetClassGrowthRate model)
        {
            const string template1 = @"
SELECT * 
FROM 
    ASSET_CLASS_GROWTH_RT
WHERE
    ASSET_CODE {0}
    AND OVERRIDE_TYPE {1}
    AND OVERRIDE_TYPE_CD {2}
ORDER BY
    1,2
";
            string sql1 = String.Format(template1, 
                model.AssetClass.IntoSqlValue().SqlPrefixWithOperator(), 
                model.OverrideType.SqlQuotify().SqlPrefixWithOperator(), 
                model.Provider.IntoSqlValue().SqlPrefixWithOperator()
                );
            return sql1;
        }
    }
}
