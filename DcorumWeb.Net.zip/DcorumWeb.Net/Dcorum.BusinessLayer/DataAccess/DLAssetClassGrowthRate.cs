﻿using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLAssetClassGrowthRate
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal DLAssetClassGrowthRate(AssetClassGrowthRateSQL sqlMaker, IDbProxy dbProxy)
        {
            _sqlMaker = sqlMaker;
            _context = dbProxy;

            if (_context == null) throw new ArgumentNullException(nameof(dbProxy));
            if (sqlMaker == null) throw new ArgumentNullException(nameof(sqlMaker));
        }

        private readonly AssetClassGrowthRateSQL _sqlMaker;
        private readonly IDbProxy _context;


        private AssetClassGrowthRate MakeModel(IDataReader source)
        {
            return new AssetClassGrowthRate(source);
        }


        internal AssetClassGrowthRate[] GetAllAssetClassGrowthRates()
        {
            string sql1 = _sqlMaker.GetAssetClassGrowthRatesSQL();
            var results = _context.GetMany( sql1, @MakeModel );
            return results;
        }


        internal AssetClassGrowthRate GetAssetClassGrowthRateById(int assetClassGrowthRateId)
        {
            string sql1 = _sqlMaker.GetAssetClassGrowthRateSQL(assetClassGrowthRateId);
            var result = _context.GetSingle( sql1, @MakeModel );
            return result;
        }


        internal int InsertAssetClassGrowthRate(AssetClassGrowthRate assetClassGrowth)
        {
            assetClassGrowth.AssetClassGrowthRateId = _context.GetNextSequenceValue(AssetClassGrowthRateSQL.SequenceName);

            string sql1 = _sqlMaker.InsertAssetClassGrowthRateSql(assetClassGrowth);

            int result = _context.ExecuteNonQuery( sql1 );
            return result;
        }


        internal int UpdateAssetClassGrowthRate(AssetClassGrowthRate assetClassGrowth)
        {     
            string sql1 = _sqlMaker.UpdateAssetClassGrowthRateSql(assetClassGrowth);

            int result = _context.ExecuteNonQuery( sql1 );
            return result;
        }


        public int DeleteAssetClassGrowthRate(AssetClassGrowthRate assetClassToDelete)
        {
            string sql1 = _sqlMaker.DeleteAssetClassGrowthRateSql(assetClassToDelete);
            int result = _context.ExecuteNonQuery( sql1 );
            return result;
        }


        public AssetClassGrowthRate[] FetchDuplicates(AssetClassGrowthRate model)
        {
            string sql1 = _sqlMaker.SelectAlternativeKeyMatches(model);
            var results = _context.GetMany( sql1, @MakeModel );
            return results;
        }
    }
}
