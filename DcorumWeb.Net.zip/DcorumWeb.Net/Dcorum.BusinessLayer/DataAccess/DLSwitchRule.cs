﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Entities;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Dcorum.BusinessLayer.DataAccess.SQL;
using System.Data;
using Dcorum.Utilities;
using Dcorum.BusinessLayer.BusinesObjects;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLSwitchRule
    {
        public static List<SwitchRule> GetSwitchRulesByCase(int caseKey)
        {
            var switchRules = new List<Entities.SwitchRule>();

            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(SwitchRuleSQL.GetSwitchRulesByCase(caseKey)))

            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                       switchRules.Add(MapToSwitchRule(reader));
                    }
                }
            }

            return switchRules;
        }

        private static SwitchRule MapToSwitchRule(IDataReader reader)
        {
            var switchRule = new SwitchRule();

            switchRule.SwitchRuleId = DBHelper.GetIDataReaderInt(reader, "CSWR_KEY");
            switchRule.SwitchRuleDescription = DBHelper.GetIDataReaderString(reader, "DESCRIPT");
            switchRule.CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY");
            string trcode=DBHelper.GetIDataReaderString(reader, "TR_CD");
            if (!string.IsNullOrEmpty(trcode))
                switchRule.SwitchRuleTRCode = int.Parse(trcode);

            return switchRule; 
        }
    }
}
