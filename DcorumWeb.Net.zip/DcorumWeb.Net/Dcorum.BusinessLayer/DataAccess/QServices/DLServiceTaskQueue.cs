﻿using System;
using System.Text;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Entities.QServices;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.QServices
{
    public class DLServiceTaskQueue : ICrudFull<VmServiceTaskQueue>
    {
        public bool DetectAnyDependants(VmServiceTaskQueue model)
        {
            throw new NotImplementedException();
        }

        public int Delete(VmServiceTaskQueue toDelete)
        {
            throw new NotImplementedException();
        }

        public int Insert(VmServiceTaskQueue toInsert)
        {
            toInsert.Id = SequenceGetter.GetNextVal(DatabaseFactory.CreateDatabase("UEXT"), "SERVICE_TASK_QUEUE_ID_SEQ");

            DataAccessHelp.ExecuteDeferredNonQuery(null, () => InsertSql(toInsert).IntoWellFormedSql());

            foreach (ServiceTaskQueueParam qparam in toInsert.QParams)
            {
                DLServiceTaskQueueParam.Insert(qparam);
            }

            return 1;
        }

        public int Update(VmServiceTaskQueue toUpdate)
        {
            throw new NotImplementedException();
        }

        public VmServiceTaskQueue SelectViaPrimaryKey(int primaryKey)
        {
            return null;
        }

        public VmServiceTaskQueue[] SelectManyViaParentKey(int parentKey = 0, string appendWhereClauseWith = null)
        {
            throw new NotImplementedException();
        }

        public VmServiceTaskQueue[] SelectDuplicates(VmServiceTaskQueue similar)
        {
            return new VmServiceTaskQueue[0];
        }

        public static string InsertSql(VmServiceTaskQueue stq)
        {
            var sql = new StringBuilder();
            sql.AppendLine("INSERT INTO UEXT.SERVICE_TASK_QUEUE (");
            sql.AppendLine("SERVICE_TASK_QUEUE_ID, SERVICE_TASK_ID, SCHEDULE_DATE, LOCKED, ACTIVE, STATUS_CD)");
            sql.AppendLine("VALUES ( ");
            sql.AppendFormat("{0},{1},SYSDATE,\'{2}\',\'{3}\',\'{4}\' )",
                             stq.Id,
                             stq.ServiceTaskId,
                             stq.IsLocked ? "1" : "0",
                             stq.IsActive ? "1" : "0",
                             stq.Status);

            return sql.ToString();
        }
    }
}