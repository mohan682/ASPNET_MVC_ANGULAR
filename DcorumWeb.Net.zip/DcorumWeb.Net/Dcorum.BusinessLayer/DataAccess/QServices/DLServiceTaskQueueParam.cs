﻿using System.Text;
using Dcorum.BusinessLayer.Entities.QServices;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.QServices
{
    public class DLServiceTaskQueueParam
    {
        private static string InsertSql(ServiceTaskQueueParam prm, object transactionManager = null)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            var sql = new StringBuilder();

            sql.AppendLine(
                "INSERT INTO SERVICE_TASK_QUEUE_PARAM (SERVICE_TASK_QUEUE_ID, PARAM_NAME, PARAM_VALUE, PARAM_ORDER, PARAM_TYPE)");
            sql.AppendLine("VALUES(");
            sql.AppendFormat("{0},\'{1}\',\'{2}\',{3},\'{4}\' )",
                             prm.Id,
                             prm.Name,
                             prm.Value,
                             prm.Order,
                             prm.Type);

            return sql.ToString();
        }

        public static ServiceTaskQueueParam Insert(ServiceTaskQueueParam toInsert)
        {
            int result = DataAccessHelp.ExecuteDeferredNonQuery(null, () => InsertSql(toInsert).IntoWellFormedSql());
            return toInsert;
        }
    }
}