﻿using System;
using System.Collections.Generic;
using System.Data;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DlValidation
    {
        internal static List<Validation> GetAllValidations()
        {
            var validations = new List<Validation>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(ValidationSql.GetAllValidationsSql()))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        validations.Add(MapToValidation(reader));
                    }
                }
            }

            return validations;
        }


        internal static List<Validation> GetAllValidationNames()
        {
            var validations = new List<Validation>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(ValidationSql.GetAllValidationNamesSql()))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        Validation validation = new Validation();
                        validation.ValidationID = DBHelper.GetIDataReaderInt(reader, "Validation_ID");
                        validation.ValidationName = DBHelper.GetIDataReaderString(reader, "VALIDATION_NAME");

                        validations.Add(validation);
                    }
                }
            }

            return validations;
        }

        internal static Validation GetValidation(int ValidationID)
        {
            Validation validation = new Validation();
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(ValidationSql.GetValidationSql(ValidationID)))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        validation = MapToValidation(reader);
                    }
                }
            }

            return validation;
        }

        internal static Validation GetValidationByname(string ValidationName)
        {
            Validation validation = null;
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(ValidationSql.GetValidationByNameSQL(ValidationName)))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        validation = MapToValidation(reader);
                    }
                }
            }

            return validation;
        }

        public static Validation MapToValidation(IDataReader reader)
        {
            Validation recordToReturn = new Validation();

            recordToReturn.ValidationID = DBHelper.GetIDataReaderInt(reader, "Validation_ID");
            recordToReturn.ValidationName = DBHelper.GetIDataReaderString(reader, "VALIDATION_NAME");
            recordToReturn.ValidationType = DBHelper.GetIDataReaderString(reader, "TYPE");
            recordToReturn.ErrorMessage = DBHelper.GetIDataReaderString(reader, "ERRORMESSAGE");
            recordToReturn.ValidationValue = DBHelper.GetIDataReaderString(reader, "VALUE");
            recordToReturn.ValueType = DBHelper.GetIDataReaderString(reader, "VALUE_TYPE");
            recordToReturn.ValueFrom = DBHelper.GetIDataReaderString(reader, "VALUE_FROM");
            recordToReturn.ValueTo = DBHelper.GetIDataReaderString(reader, "VALUE_TO");

            return recordToReturn; 
        }

        public static List<string> GetAllValidationTypes()
        {
            List<string> listValidationTypes = new List<string>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");
            using (var cmd = db.GetSqlStringCommand(ValidationSql.GetAllValidationTypes()))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        listValidationTypes.Add(DBHelper.GetIDataReaderString(reader, "DESCRIPT"));
                    }
                }
            }
            return listValidationTypes;

        }
        public static List<string> GetAllValueTypes()
        {
            List<string> listValueTypes = new List<string>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");
            using (var cmd = db.GetSqlStringCommand(ValidationSql.GetAllValueTypes()))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        listValueTypes.Add(DBHelper.GetIDataReaderString(reader, "DESCRIPT"));
                    }
                }
            }
            return listValueTypes;

        }
        public static List<string> GetAllErrorMessages()
        {
            List<string> listErrorMessages = new List<string>();
            Database db = DatabaseFactory.CreateDatabase("UEXT");
            using (var cmd = db.GetSqlStringCommand(ValidationSql.GetAllErrorMessagesAndIds()))
            using (IDataReader reader = db.ExecuteReader(cmd))
            {
                if (!reader.IsClosed)
                {
                    while (reader.Read())
                    {
                        listErrorMessages.Add(DBHelper.GetIDataReaderString(reader, "ErrorMessage"));
                    }
                }
            }
            return listErrorMessages;

        }

        internal static bool InsertValidation(Validation validation)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("UEXT");

                validation.ValidationID = SequenceGetter.GetNextVal(db, "Validation_Id_Seq");

                using (var cmd = db.GetSqlStringCommand(ValidationSql.InsertValidationSQL(validation)))
                    return (db.ExecuteNonQuery(cmd) == 1);
            }
            catch (Exception ex) { return false;  };
        }

        internal static bool UpdateValidation(Validation validation)
        {
            bool blUpdateSuccess = false;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("UEXT");

                DbCommand dbCommand = db.GetSqlStringCommand(ValidationSql.UpdateValidationSQL(validation));

                int iCount = 0;

                iCount = db.ExecuteNonQuery(dbCommand);

                if (iCount == 1)
                {
                    blUpdateSuccess = true;
                }
                else
                {
                    blUpdateSuccess = false;
                }
            }
            catch (Exception ex)
            {
                //TODO - deal with error message
                blUpdateSuccess = false;
            }

            return blUpdateSuccess;

        }
        internal static bool ErrorMessageExists(string strErrorMessage)
        {
            bool blMessageExists = false;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("UEXT");

                DbCommand dbCommand = db.GetSqlStringCommand(ValidationSql.ErrormessageExists(strErrorMessage));

                int iCount = 0;

                iCount = Convert.ToInt32(db.ExecuteScalar(dbCommand));

                if (iCount == 1)
                {
                    blMessageExists = true;
                }
                else
                {
                    blMessageExists= false;
                }
            }
            catch (Exception ex)
            {
                //TODO - deal with error message
                blMessageExists = false;
            }

            return blMessageExists;

 
        
        }
    }
}
