﻿using System;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLAdminUser : ICrudFull<AdminUser>
    {
        internal DLAdminUser(AdminUserSQL sqlMaker)
        {
            SQLActor = sqlMaker;
            if (SQLActor == null) throw new ArgumentNullException(nameof(sqlMaker));
        }

        private readonly AdminUserSQL SQLActor;

        public AdminUser[] SelectManyViaParentKey(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            Func<AdminUser, bool> predicate1 = @model =>
            {
                bool isBlankClause = String.IsNullOrWhiteSpace(appendWhereClauseWith);
                return (!@model.IsNotActive && isBlankClause) || !isBlankClause;
            };

            var sql = SQLActor.SelectManySql(parentKey, appendWhereClauseWith).IntoWellFormedSql();
            var results = DataAccessHelp.GetMany(sql, @reader => new AdminUser(@reader)).Where( @predicate1 ).Where( _ => _.UserName.StartsWith(AdminUserSQL.SoftDeleteEmailPrefix) == false).ToArray();
            return results ;
        }


        public AdminUser SelectViaPrimaryKey(int Id)
        {
            var sql = SQLActor.SelectOneSql(Id).IntoWellFormedSql();
            var result = DataAccessHelp.GetSingle(sql, @reader => new AdminUser(@reader));
            return result;
        }


        public virtual AdminUser[] SelectDuplicates(AdminUser user)
        {
            var sql = SQLActor.SelectDuplicatesSql(user);
            return DataAccessHelp.GetMany(sql, @reader => new AdminUser(@reader));
        }


        public virtual int Update(AdminUser adminUser)
        {
            Contract.Assert(adminUser.NameId > 0);
            var sql = SQLActor.UpdateSql(adminUser).IntoWellFormedSql();
            return DataAccessHelp.SimpleExecuteNonQuery(sql);
        }


        public int Insert(AdminUser adminUser)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            adminUser.NameId = SequenceGetter.GetNextVal(db, "COMPASS.PRTY_SEQ");
            adminUser.AccountId = SequenceGetter.GetNextVal(db, SQLActor.GetSequenceIdForInsert());

            var sql = SQLActor.InsertSql(adminUser).IntoWellFormedSql();
            return DataAccessHelp.SimpleExecuteNonQuery(sql);
        }


        public int ForceReRegDuringNextLogin(AdminUser adminUser)
        {
            var sql = SQLActor.ForceReRegDuringNextLogin(adminUser);
            return DataAccessHelp.SimpleExecuteNonQuery(sql);
        }


        public bool IsAwdUserAlreadyMapped(AdminUser adminUser)
        {
            var sql = SQLActor.IsAwdUserAlreadyMapped(adminUser);
            return DataAccessHelp.HasRows(sql);
        }

        public bool DetectAnyDependants(AdminUser model)
        {
            foreach (string sqlNow in SQLActor.DetectAnyDependants(model))
            {
                bool hasRows = DataAccessHelp.HasRows(sqlNow);
                if (hasRows) return true;
            }

            return false;
        }


        public int Delete(AdminUser adminUser)
        {
            var sql = SQLActor.DeleteSql(adminUser).IntoWellFormedSql();
            return DataAccessHelp.SimpleExecuteNonQuery(sql);
        }
    }
}
