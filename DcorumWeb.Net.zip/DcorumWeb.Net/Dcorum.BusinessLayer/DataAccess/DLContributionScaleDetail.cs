﻿using System;
using System.Data;
using System.Diagnostics.Contracts;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities.Contributions;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.Contributions
{
    public class DLContributionScale
    {
        public static ContributionScaleDetail[] Select(int contributonScaleGroupId)
        {
            string sql1 = ContributionScaleDetailSql.SelectViaFKeySql(contributonScaleGroupId);
            var result = DataAccessHelp.GetMany(sql1, MapToContributionScaleDetails, "UEXT");
            return result;
        }


        public static ContributionScaleDetail Single(int contributonScaleId)
        {
            string sql1 = ContributionScaleDetailSql.SelectViaPKeySql(contributonScaleId);
            var result = DataAccessHelp.GetSingle(sql1, MapToContributionScaleDetails, "UEXT");
            return result;
        }


        private static ContributionScaleDetail MapToContributionScaleDetails(IDataReader reader)
        {
            DateTime? dateTo = null;
            DBHelper.GetIDataReaderNullableValue(reader, "DATE_TO", out dateTo);
            var result = new ContributionScaleDetail();

            result.ContributionScaleId = DBHelper.GetIDataReaderInt(reader, "CONTRIBUTION_SCALE_ID");
            result.ContributionTo = DBHelper.GetIDataReaderDouble(reader, "CONTRIBUTION_TO");
            result.DateTo = dateTo;
            result.AgeTo = DBHelper.GetIDataReaderInt(reader, "AGE_TO");
            result.FixedPointsOnly = DBHelper.GetIDataReaderInt(reader, "FIXED_POINTS_ONLY") >= 1;
            result.IncrementAmount = DBHelper.GetIDataReaderDouble(reader, "INCREMENT_AMOUNT");
            result.LowerAmount = DBHelper.GetIDataReaderDouble(reader, "LOWER_AMOUNT");
            result.SalaryTo = DBHelper.GetIDataReaderDouble(reader, "SALARY_TO");
            result.ServiceTo = DBHelper.GetIDataReaderInt(reader, "SERVICE_TO");
            result.UpperAmount = DBHelper.GetIDataReaderDouble(reader, "UPPER_AMOUNT");
            result.ParentId = DBHelper.GetIDataReaderInt(reader, "CONTRIBUTION_SCALE_GROUP_ID");
            return result;
        }

        public static int Insert(ContributionScaleDetail detail)
        {
            Contract.Assert(detail.ContributionScaleId == 0);

            Database db = DatabaseFactory.CreateDatabase("UEXT");
            int result;
            int newLookupId = 0;

            detail.ContributionScaleId = SequenceGetter.GetNextVal(db, "Contribution_Scale_SEQ");

            if (!(detail.ParentId > 0))
            {
                newLookupId = SequenceGetter.GetNextVal(db, "Contribution_Scale_Lookup_SEQ");
            }

            //insert
            string sql1 = ContributionScaleSql.InsertContributionScaleSql(detail.AgeTo,
                detail.ContributionScaleId, detail.ContributionTo, detail.DateTo, Convert.ToInt32(detail.FixedPointsOnly),
                detail.IncrementAmount, detail.LowerAmount, detail.SalaryTo, detail.ServiceTo,
                detail.UpperAmount, detail.ParentId, detail.CaseKey.GetValueOrDefault(), detail.MbGpKey.GetValueOrDefault(), newLookupId);

            using (var cmd = db.GetSqlStringCommand(sql1))
            {
                result = db.ExecuteNonQuery(cmd);
            }

            //for an insert where a new parent was also inserted at the same time...
            if (!(detail.ParentId > 0))
            {
                var fetchBack = Single(detail.ContributionScaleId);
                detail.ParentId = fetchBack.ParentId;
                detail.ContributionScaleLookupId = newLookupId;
                Contract.Assert(detail.ParentId > 0);
            }

            return result;
        }


        public static int Update(ContributionScaleDetail detail)
        {
            Contract.Assert(detail.ContributionScaleId > 0);
            Contract.Assert(detail.ParentId > 0);

            Database db = DatabaseFactory.CreateDatabase("UEXT");
            int result;

            //update
            string sql1 = ContributionScaleDetailSql.UpdateSql(detail.AgeTo, detail.ContributionScaleId,
                detail.ContributionTo, detail.DateTo, Convert.ToInt32(detail.FixedPointsOnly), detail.IncrementAmount,
                detail.LowerAmount, detail.SalaryTo, detail.ServiceTo, detail.UpperAmount);

            using (var cmd = db.GetSqlStringCommand(sql1))
            {
                result = db.ExecuteNonQuery(cmd);
            }

            return result;
        }


        public static int Delete(ContributionScaleDetail detail)
        {
            var sqlDelete = ContributionScaleDetailSql.DeleteViaPKeySql(detail.ContributionScaleId);
            Database db = DatabaseFactory.CreateDatabase("UEXT");

            using (var cmd = db.GetSqlStringCommand(sqlDelete))
            {
                return db.ExecuteNonQuery(cmd);
            }
        }


        //public static bool IsContributionScaleGroupShared(int contributionScaleGroupId, int currentMemberGroupKey)
        //{
        //    var sql = ContributionScaleSql.CheckSharedStatusSql(contributionScaleGroupId, currentMemberGroupKey);
        //    int count = DataAccessHelp.GetSingle(sql, _ => DBHelper.GetIDataReaderInt(_, "COUNTSCALE"), "UEXT");
        //    return count > 0;
        //}

        //public static int GetContributionScaleGroupId(int memberGroupKey)
        //{
        //    var sql = ContributionScaleSql.GetScaleGroupId(memberGroupKey);
        //    int result = DataAccessHelp.GetSingle(sql, in1 => DBHelper.GetIDataReaderInt(in1, "CONTRIBUTION_SCALE_GROUP_ID"), "UEXT");
        //    return result;
        //}

        public static bool HasDuplicate(ContributionScaleDetail detail)
        {
            if (detail.ParentId == 0) return false;

            string sql1 = ContributionScaleDetailSql.CheckForDuplicateSql(detail.ParentId, detail.AgeTo, detail.ServiceTo, detail.ContributionTo, detail.SalaryTo, detail.DateTo, detail.ContributionScaleId);
            int count = DataAccessHelp.GetSingle(sql1, _ => DBHelper.GetIDataReaderInt(_, "COUNTID"), "UEXT");
            return count > 0;
        }
    }
}
