﻿using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using System;

namespace Dcorum.BusinessLayer.DataAccess
{
    public class DLBillingGroup : CrudActor<BillingGroup, int, int>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected DLBillingGroup( BillingGroupSQL sqlMaker )
            :base( @reader => new BillingGroup(@reader), sqlMaker)
        {
            BillingGroupSql = sqlMaker;
            if (BillingGroupSql == null) throw new ArgumentNullException(nameof(sqlMaker));
        }


        private BillingGroupSQL BillingGroupSql { get; }


        public void InsertNewUextBillGrpEntries(int casekey)
        {
            string sql1 = BillingGroupSql.InsertMissingUextBillGrpSQL(casekey) ;
            DbProxy.ExecuteNonQuery(sql1);
        }

    }

}


