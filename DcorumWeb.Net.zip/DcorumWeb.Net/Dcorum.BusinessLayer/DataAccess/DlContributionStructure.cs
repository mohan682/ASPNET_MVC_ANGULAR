﻿using System.Data;
using System.Data.Common;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.DataAccess.SQL;
using Dcorum.BusinessLayer.Entities.Contributions;
using Dcorum.BusinessLayer.Logic.Helping;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Dcorum.BusinessLayer.DataAccess.Contributions
{

    public class DLContributionStructureLookup : DLContributionLookupBase<ContributionStructureLookup>
    {
        public DLContributionStructureLookup()
        {
            SqlStringBuilder = new ContributionStructureSql();
            BulkDetailDeletion = new ContributionStructureDetailSql();
        }

        //For AutoComplete use only!
        public static ThinMemberGroup[] GetMemberGroupsWithStructures()
        {
            string sql1 = ContributionStructureSql.GetAllMemberGroupsWithStructures();
            var results = DataAccessHelp.GetMany(sql1, MakeThinMemberGroup, DATABASE_NAME);

            bool mustBeTrue = Contract.ForAll(results, _ => _.MemberGroupCategory.RefCd == MemberGroupDomainCodes.BenefitMemberGroupType);
            Contract.Assert(mustBeTrue);

            return results;
        }
    }


    public abstract class DLContributionLookupBase<TLookup>
        where TLookup : ContributionCommonLookup, new()
    {
        protected IContributionLookupSqlBuilder<TLookup> SqlStringBuilder { get; set; }
        protected IContributionDetailSqlBuilder BulkDetailDeletion { get; set; }

        public const string DATABASE_NAME = "UEXT";

        [ContractInvariantMethod]
        protected void Invariants()
        {
            Contract.Invariant(SqlStringBuilder != null);
            Contract.Invariant(BulkDetailDeletion != null);
        }

        public TLookup Single(int lookupId)
        {
            string sql1 = SqlStringBuilder.SelectViaPkeySql(lookupId);
            var result = DataAccessHelp.GetSingle(sql1, MakeContributionLookup, DATABASE_NAME);
            return result;
        }

        /// <summary>
        /// NotE: sharedModeOn && groupOfInterest = 0 implies Detach active shared group.
        /// </summary>
        public int CopyWip(TLookup toUse, int groupIdOfInterest, bool sharedModeOn = false)
        {
            Contract.Assert(toUse != null);
            //bool activeGroupModeOn = (toUse.ContributionGroupId == groupIdOfInterest) || groupIdOfInterest == 0 ;
            Contract.Assert(BulkDetailDeletion != null);

            Database db = DatabaseFactory.CreateDatabase(DATABASE_NAME);

            bool hasDeletableDetail = !toUse.IsShared && toUse.HasChildren();

            Contract.Assert(!hasDeletableDetail || toUse.ContributionGroupId > 0);

            string sql1 = (hasDeletableDetail) ? BulkDetailDeletion.DeleteViaFKeySql(toUse.ContributionGroupId) : null;

            toUse.ContributionGroupId = (sharedModeOn) ? groupIdOfInterest : 0;

            string sql2;
            if (!(toUse.LookupId > 0))
            {
                sql2 = SqlStringBuilder.InsertCslSql(db, toUse);
            }
            else
            {
                sql2 = SqlStringBuilder.UpdateGroupSql(db, toUse);
            }

            string sql3 = null;

            if (!sharedModeOn)
            {
                Contract.Assert(toUse.ContributionGroupId > 0);
                sql3 = BulkDetailDeletion.InsertViaGroupId(groupIdOfInterest, toUse.ContributionGroupId);
            }

            string fullSql = DataAccessHelp.Layout(sql1, sql2, sql3);

            using (var cmd = db.GetSqlStringCommand(fullSql))
            {
                return db.ExecuteNonQuery(cmd);
            }
        }


        public TLookup[] SelectViaCaseKey(int caseKey)
        {
            var sql1 = SqlStringBuilder.SelectViaCaseKeySql(caseKey);
            return DataAccessHelp.GetMany(sql1, MakeContributionLookup, DATABASE_NAME);
        }


        public TLookup[] SelectViaMemberGroupKey(int memberGroupKey)
        {
            var sql1 = SqlStringBuilder.SelectViaMemberGroupKeySql(memberGroupKey);
            return DataAccessHelp.GetMany(sql1, MakeContributionLookup, DATABASE_NAME);
        }


        public int SaveVariation(TLookup toUse, int newVariationCode)
        {
            Database db = DatabaseFactory.CreateDatabase(DATABASE_NAME);

            toUse.VariationCode = 0.ToString();
            string sql1 = (toUse.LookupId.HasValue)? SqlStringBuilder.UpdateVariationSql(toUse) : null ;

            toUse.LookupId = 0;
            toUse.ContributionGroupId = 0;
            toUse.VariationCode = newVariationCode.ToString(); //default AVC

            string sql2 = SqlStringBuilder.InsertCslSql(db, toUse);

            string fullSql = DataAccessHelp.Layout(sql1, sql2);

            using (DbCommand dbCommand = db.GetSqlStringCommand(fullSql))
            {
                return db.ExecuteNonQuery(dbCommand);
            }
        }


        public TLookup GetCoreVariant(TLookup toUse)
        {
            var candidates = SelectViaMemberGroupKey(toUse.MbGpKey.Value).ToArray();
            return candidates.SingleOrDefault(_ => !(_.NumericVariationCode>0));
        }


        //Deletes a single CSL row but no details rows. Should only be used where detail rows are shared or there are no detail rows!
        public int RemoveVariation(TLookup toUse)
        {
            Database db = DatabaseFactory.CreateDatabase(DATABASE_NAME);

            Contract.Assert(toUse.NumericVariationCode>0);
            string sql1 = null;
            string sql2 = SqlStringBuilder.DeleteSql(toUse);

            var siblings = SelectViaMemberGroupKey(toUse.MbGpKey.Value).Where( _ => _.NumericVariationCode != toUse.NumericVariationCode && _.NumericVariationCode > 0).ToArray();

            if (!siblings.Any())
            {
                var core = GetCoreVariant(toUse).CopyBaseEntityValuesFrom(toUse);

                if (core != null)
                {
                    Contract.Assert(toUse.MbGpKey == core.MbGpKey);
                    Contract.Assert(toUse.CaseKey == core.CaseKey);
                    Contract.Assert(toUse.LookupId != core.LookupId);
                    Contract.Assert(toUse.VariationCode != core.VariationCode);

                    Contract.Assert(core.VariationCode == "0");
                    core.VariationCode = CommonCodes.Variation_Code_ALL;
                    sql1 = SqlStringBuilder.UpdateVariationSql(core);
                }
            }
            string fullSql = DataAccessHelp.Layout(sql1, sql2);

            using(DbCommand dbCommand = db.GetSqlStringCommand(fullSql))
            {
                return db.ExecuteNonQuery(dbCommand);
            }
        }


        public int Delete(TLookup toDelete)
        {
            string sql1 = SqlStringBuilder.DeleteSql(toDelete).IntoWellFormedSql() ;
            int result = DataAccessHelp.SimpleExecuteNonQuery(sql1, DATABASE_NAME);
            return result;
        }


        /// <summary>
        /// [OVERLOAD|MEMBERGROUP compatible] 
        /// </summary>
        protected static TLookup MakeContributionLookup(IDataReader reader)
        {
            return MakeContributionLookup(reader, false);
        }

        protected static TLookup MakeContributionLookup(IDataReader reader, bool shortCircuitForAutoComplete)
        {
            var creation1 = new TLookup();
            Build(creation1, reader);
            return creation1;
        }


        protected static ThinMemberGroup MakeThinMemberGroup(IDataReader reader)
        {
            var creation1 = new ThinMemberGroup();
            Build(creation1, reader);
            return creation1;
        }


        private static void Build(ThinMemberGroupAbstract toBuild, IDataReader reader)
        {
            int id = DBHelper.GetIDataReaderInt(reader, "MBGP_KEY");
            toBuild.MbGpKey = id;
            toBuild.Description = DBHelper.GetIDataReaderString(reader, "DESCRIPT");
            toBuild.MemberGroupCategory = new RefCode(DBHelper.GetIDataReaderString(reader, "GRP_TYP_CD"));
        }


        private static void Build(ContributionLookupCore toBuild, IDataReader reader)
        {
            Build((ThinMemberGroupAbstract)toBuild, reader);

            toBuild.MoneyTypeGroupTitle = DBHelper.GetIDataReaderString(reader, "NAME");
            toBuild.ContributionGroupId = DBHelper.GetIDataReaderInt(reader, "CSL_GROUP_ID");
            toBuild.IsShared = DBHelper.GetIDataReaderInt(reader, "COUNTSCALE") > 1 ;
            toBuild.DetailCount = DBHelper.GetIDataReaderInt(reader, "DetailCount") ;
            toBuild.VariationCode = DBHelper.GetIDataReaderString(reader, "VARIATION_CD");
            toBuild.LookupId = DBHelper.GetIDataReaderNullableInt(reader, "CSL_ID");
            toBuild.CaseKey = DBHelper.GetIDataReaderInt(reader, "CASE_KEY");         
        }
    }
}
