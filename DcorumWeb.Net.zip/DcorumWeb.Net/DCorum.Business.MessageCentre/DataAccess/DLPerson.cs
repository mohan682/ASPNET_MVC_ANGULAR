﻿using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.MessageCentre.Entities;
using DCorum.Business.MessageCentre.Sql;
using System.Diagnostics;

namespace DCorum.Business.MessageCentre.DataAccess
{
    public class DLPerson : ICrudOut<Person, int>
    {
        internal DLPerson(PersonSQL sqlMaker)
        {
            _myInlineSqlMaker = sqlMaker;
            Debug.Assert(_myInlineSqlMaker != null);
        }

        private readonly PersonSQL _myInlineSqlMaker;

        public Person SelectViaPrimaryKey(int nameId)
        {
            string sql1 = _myInlineSqlMaker.Get(nameId);
            return DataAccessHelp.GetSingle(sql1, @reader => new Person(@reader));
        }

        public Person[] SelectManyViaParentKey(int parentKey = 0, string appendWhereClauseWith = null)
        {
            string sql1 = _myInlineSqlMaker.GetMany();
            return DataAccessHelp.GetMany(sql1, @reader => new Person(@reader));
        }

        //public static DcorumUser GetUserByExternalId(int externalId)
        //{
        //    DcorumUser aeUser = new DcorumUser();

        //    Database db = DatabaseFactory.CreateDatabase("UEXT");

        //    using (var cmd = db.GetSqlStringCommand
        //        (string.Format("SELECT USER_ID,USER_NAME,LASTNAME,FIRSTNAME FROM USERS WHERE EXTERNAL_NAMEID={0}", externalId)))
        //    using (OracleDataReaderWrapper reader = (OracleDataReaderWrapper)db.ExecuteReader(cmd))
        //    {
        //        if (!reader.InnerReader.HasRows) throw new ArgumentException();

        //        while (reader.Read())
        //        {
        //            aeUser.ExternalUserId = externalId;
        //            aeUser.Id = DBHelper.GetIDataReaderInt(reader, "USER_ID");
        //            aeUser.UserName = DBHelper.GetIDataReaderString(reader, "USER_NAME");
        //            aeUser.LastName = DBHelper.GetIDataReaderString(reader, "LASTNAME");
        //            aeUser.FirstName = DBHelper.GetIDataReaderString(reader, "FIRSTNAME");
        //        }
        //    }

        //    return aeUser;
        //}
    }
}
