﻿using Dcorum.Utilities.DataAccess;
using DCorum.Business.MessageCentre.Entities;
using DCorum.Business.MessageCentre.Sql;
using System.Diagnostics;

namespace DCorum.Business.MessageCentre.DataAccess
{
    public class DLEmail
    {
        internal DLEmail(EmailSQL sqlMaker)
        {
            _myInlineSqlMaker = sqlMaker;
            Debug.Assert(_myInlineSqlMaker != null);
        }

        private readonly EmailSQL _myInlineSqlMaker;

        public bool Add(Email email)
        {
            string sql = _myInlineSqlMaker.InsertEmailSQL(email);
            int iCount = DataAccessHelp.SimpleExecuteNonQuery(sql);
            return iCount > 0;
        }

        public bool Add(Email email, int email_to_user_acc_id)
        {
            string sql = _myInlineSqlMaker.InsertEmailSQL(email, email_to_user_acc_id);
            int iCount = DataAccessHelp.SimpleExecuteNonQuery(sql);
            return iCount > 0;
        }
    }
}
