﻿using DCorum.Business.MessageCentre.Entities;
using DCorum.Business.MessageCentre.Sql;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.Utilities.DataAccess;
using System.Diagnostics;

namespace DCorum.Business.MessageCentre.DataAccess
{
    public class DLUserMessage
    {
        internal DLUserMessage(UserMessageSQL sqlMaker)
        {
            _sqlActor = sqlMaker;
            Debug.Assert(_sqlActor != null);
        }

        private readonly UserMessageSQL _sqlActor;

        /// <summary>
        /// Method used to generate a collection of messages related to a particular user
        /// </summary>
        /// <returns>Returns a list of Messages</returns>
        public Message[] GetList(int nameId)
        {
            string sql1 = _sqlActor.GetMessagesSQL(nameId);
            var results = DataAccessHelp.GetMany(sql1, @reader => new Message(@reader));
            return results;
        }

        /// <summary>
        /// Method used to get message (including detail) specified by messageId
        /// </summary>
        /// <returns>Returns one user message</returns>
        public Message GetMessage(int messageId)
        {
            string sql1 = _sqlActor.GetMessageSQL(messageId);
            var result = DataAccessHelp.GetSingle(sql1, @reader => new Message(@reader));
            return result;
        }


        /// <summary>
        /// Method used to get a group of messages linked to a specified messageId
        /// </summary>
        /// <returns>Returns a list of user messages</returns>
        public Message[] GetMessageGroup(int messageId)
        {
            string sql1 = _sqlActor.GetMessageGroupSQL(messageId);
            var results = DataAccessHelp.GetMany(sql1, @reader => new Message(@reader));
            return results;
        }


        public bool Add(Message message, int userAccId)
        {
            // Will firstly get the next value for Message_Detail ID then create an entry for Message Detail then an entry then a Message Entry
            message.DetailId = SequenceGetter.GetNextVal(_sqlActor.GetMessageDetailSequenceName());
            string sql1 = _sqlActor.AddMessageDetailSQL(message);

            int affectedRowCount = DataAccessHelp.SimpleExecuteNonQuery(sql1);

            if (affectedRowCount == 0) return false;

            string sql2 = _sqlActor.AddMessageSQL(message, userAccId);

            affectedRowCount = DataAccessHelp.SimpleExecuteNonQuery(sql2);

            return (affectedRowCount > 0);
        }


        public bool UpdateReadDateForMessage(Message message)
        {
            string sql1 = _sqlActor.UpdateMessageReadDateSQL(message.DetailId);
            int affectedTotal = DataAccessHelp.SimpleExecuteNonQuery(sql1);
            return affectedTotal > 0;
        }
    }
}
