﻿using DCorum.Business.MessageCentre.Entities;

namespace DCorum.Business.MessageCentre
{
    public static class UserMessageExtensions
    {
        public static object GetMessageRowView(this Message model)
        {
            object result = new
            {
                _key = model.Id,
                Priority = model.Priority.Descript,
                Sender____________________ = model.Sender,
                Created_Date____ = model.CreateDate?.ToString("0:dd/MM/yyyy"),
                Read_Date_______ = model.ReadDate?.ToString("0:dd/MM/yyyy"),
                Subject__________________________________ = model.Subject
            };
            return result;
        }

        public static object GetEventRowView(this Message model)
        {
            object result = new
            {
                _key = model.Id,
                Priority = model.Priority.Descript,
                Date_______ = model.CreateDate?.ToString("0:d"),
                Subject__________________________________ = model.Subject
            };

            return result;
        }

        public static object GetNotificationRowView(this Message model)
        {
            object result = new
            {
                _key = model.Id,
                Priority = model.Priority.Descript,
                Date_______ = model.CreateDate?.ToString("0:d"),
                Subject__________________________________ = model.Subject

            };
            return result;
        }
    }
}
