﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Dcorum.RefCoding;
using Dcorum.Utilities;
using Dcorum.Utilities.Practices;

namespace DCorum.Business.MessageCentre.Entities
{
    [Serializable]
    public class Message :MessageDetail
    {
        public Message(IDataReader dataReader)
            :base(dataReader)
        {
            if (dataReader == null) return;
            Build(this, dataReader);
            this.DoBuildRefCodes();
        }


        //Public Properties to populate
        [Key]
        public int Id { get; set; }
        public int ParentId { get; set; } //FKEY
        //public int DetailId { get; set; } //FKEY

        public int UserAccID { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ReadDate { get; set; }

        //public int MessageGroupId { get; set; }

        /// <summary>
        /// Method takes an active datareader record and returns the object equivalent
        /// </summary>
        private static void Build(Message message, IDataReader dataReader)
        {
            message.Id = DBHelper.GetIDataReaderInt(dataReader, "Message_Id");
            message.ParentId = DBHelper.GetIDataReaderInt(dataReader, "Parent_Message_Id");
            //userMessage.DetailId = DBHelper.GetIDataReaderInt(dataReader, "Message_Detail_Id");
            message.UserAccID = DBHelper.GetIDataReaderInt(dataReader, "user_ID");
            message.CreateDate = DBHelper.GetIDataReaderNullableDateTime(dataReader, "Create_Date");
            message.ReadDate = DBHelper.GetIDataReaderNullableDateTime(dataReader, "Read_Date");
        }
    }
}
