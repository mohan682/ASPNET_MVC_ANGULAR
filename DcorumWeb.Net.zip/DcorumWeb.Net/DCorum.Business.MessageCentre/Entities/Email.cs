﻿namespace DCorum.Business.MessageCentre.Entities
{
    public class Email
    {
        public string  EmailFrom { get; internal set; }
        public string  EmailTo { get; internal set; }
        public string  Subject { get; internal set; }
        public string  Body { get; internal set; }       
    }
}
