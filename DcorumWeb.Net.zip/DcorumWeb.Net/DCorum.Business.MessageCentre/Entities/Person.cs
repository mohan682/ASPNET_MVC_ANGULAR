﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;

namespace DCorum.Business.MessageCentre.Entities
{
    public class Person
    {
        internal Person(IDataReader source)
        {
            if (source == null) return;
            Build(this, source);
        }

        [Key]
        public int NameId { get; private set; }
        public string LastName { get; private set; }
        public string MidName { get; private set; }
        public string FirstName { get; private set; }
        public DateTime DOB { get; private set; }
        public string NINo { get; private set; }

        [RefCodeConstraint(DomainNames.Gender)]
        private RefCode Sex { get; set; }

        [RefCodeConstraint(DomainNames.PersonTitle)]
        private RefCode Title { get; set; }

        public int UserAccId { get; private set; }
        public string UserAccName { get; private set; }

        public override string ToString()
        {
            return string.Format("{0} {1}", FirstName, LastName);
        }

        private static void Build(Person toBuild, IDataReader reader)
        {
            toBuild.NameId = DBHelper.GetIDataReaderInt(reader, "NAMEID");
            toBuild.UserAccId = DBHelper.GetIDataReaderInt(reader, "USER_ACC_ID");
            toBuild.UserAccName = DBHelper.GetIDataReaderString(reader, "USER_ACC_NAME");
            toBuild.LastName = DBHelper.GetIDataReaderString(reader, "LASTNAME");
            toBuild.MidName = DBHelper.GetIDataReaderString(reader, "MIDNAME");
            toBuild.FirstName = DBHelper.GetIDataReaderString(reader, "FIRSTNAME");
            toBuild.DOB = DBHelper.GetIDataReaderDateTime(reader, "BIRTHDT");
            toBuild.NINo = DBHelper.GetIDataReaderString(reader, "NATLIDNO");
            toBuild.Sex = new RefCode(DBHelper.GetIDataReaderString(reader, "SEXCD"));
            toBuild.Title = new RefCode(DBHelper.GetIDataReaderString(reader, "NAMEPREFIX"));
        }
    }

}
