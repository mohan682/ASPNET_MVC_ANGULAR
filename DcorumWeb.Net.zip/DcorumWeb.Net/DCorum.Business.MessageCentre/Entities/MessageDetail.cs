﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using DCorum.Business.MessageCentre.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.RefCoding;
using Dcorum.Utilities;

namespace DCorum.Business.MessageCentre.Entities
{
    [Serializable]
    public class MessageDetail
    {
        public MessageDetail(IDataReader dataReader)
        {
            if (dataReader == null) return;
            Build(this, dataReader);
            this.DoBuildRefCodes();
        }

        [Key]
        public int DetailId { get; set; }

        [RefCodeConstraint(MessageCentreDomainNames.UserMessagePriority)]
        public RefCode Priority { get; set; }

        [RefCodeConstraint(MessageCentreDomainNames.UserMessageType)]
        public RefCode Type { get; set; }

        [RefCodeConstraint(MessageCentreDomainNames.UserMessageCategory)]
        public RefCode Category { get; set; }
       
        public string Subject { get; set; }
        public string Sender { get; set; }
        public string Body { get; set; }


        /// <summary>
        /// Method takes an active datareader record and returns the object equivalent
        /// </summary>
        private static void Build(MessageDetail userMessage, IDataReader dataReader)
        {         
            userMessage.DetailId = DBHelper.GetIDataReaderInt(dataReader, "Message_Detail_Id");
        
            userMessage.Priority = dataReader.FetchNumericRefCode("Priority");
            userMessage.Type = dataReader.FetchTextualRefCode("Type");
            userMessage.Category = dataReader.FetchTextualRefCode("Category");

            userMessage.Subject = DBHelper.GetIDataReaderString(dataReader, "Subject");
            userMessage.Sender = DBHelper.GetIDataReaderString(dataReader, "Sender");

            //Dual use message fill...
            if (DBHelper.GetOrdinal(dataReader, "body", false) > 0)
            {
                userMessage.Body = DBHelper.GetIDataReaderString(dataReader, "body");
            }
        }
    }
}
