﻿using DCorum.Business.MessageCentre.DataAccess;
using DCorum.Business.MessageCentre.Logic;
using DCorum.Business.MessageCentre.Sql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Business.MessageCentre.Creational
{
    public class MessageCentreFactory
    {
        public static readonly MessageCentreFactory Singleton = new MessageCentreFactory();
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        private MessageCentreFactory() { }

        public BLUserMessage NewUserMessageController()
        {
            var creation1 = new BLUserMessage(new DLUserMessage( new UserMessageSQL()), new DLEmail(new EmailSQL()));
            return creation1;
        }

        //public BLEmail NewEmailController()
        //{
        //    var creation1 = new BLEmail( new DLEmail(new EmailSQL()));
        //    return creation1;
        //}

        public BLPerson NewPersonController()
        {
            var creation1 = new BLPerson(new DLPerson(new PersonSQL() ));
            return creation1;
        }

        public DLPerson NewPersonDataAccess()
        {
            var creation1 = new DLPerson(new PersonSQL());
            return creation1;
        }
    }
}
