﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Business.MessageCentre.Contractual
{
    public static class MessageCentreDomainNames
    {
        public const string UserMessageCategory = "MSG CATEGORY CD";
        public const string UserMessagePriority = "MSG PRIORITY CD";
        public const string UserMessageType = "MSG TYPE CD";
    }
}
