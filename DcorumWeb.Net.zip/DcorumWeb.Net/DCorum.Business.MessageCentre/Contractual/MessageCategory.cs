﻿namespace DCorum.Business.MessageCentre.Contractual
{
    //public enum msgPriority
    //{
    //    High = 1,
    //    Medium = 2,
    //    Low = 3
    //}

    public enum MessageCategory
    {
        Message = 1,
        Event = 2,
        Notification = 3
    }
}
