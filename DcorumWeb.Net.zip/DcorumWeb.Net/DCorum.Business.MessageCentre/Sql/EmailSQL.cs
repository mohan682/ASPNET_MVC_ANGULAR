﻿using System.Text;
using DCorum.Business.MessageCentre.Entities;

namespace DCorum.Business.MessageCentre.Sql
{
    internal class EmailSQL
    {
        internal EmailSQL() { }

        public string InsertEmailSQL(Email email)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendLine("insert into email ");
            sql.AppendLine("  (EMAIL_ID, ADDRESS_SENDER, ADDRESS_FROM, ADDRESS_REPLY_TO, ADDRESS_TO, ADDRESS_CC, ");
            sql.AppendLine("   ADDRESS_BCC, EMAIL_BODY, IS_HTML, REQUESTED, SENT, SUBJECT) ");
            sql.AppendLine("values ");
            sql.AppendFormat("  (email_id_seq.nextval, '{0}', '{0}', '{0}', ", email.EmailFrom);
            sql.AppendFormat("   '{0}', null, null, ", email.EmailTo);
            sql.AppendFormat("   '{0}', '0', sysdate, null, '{1}') ", email.Body, email.Subject);

            return sql.ToString();
        }

        public string InsertEmailSQL(Email email, int email_to_user_acc_id)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendLine("insert into email ");
            sql.AppendLine("  (EMAIL_ID, ADDRESS_SENDER, ADDRESS_FROM, ADDRESS_REPLY_TO, ADDRESS_TO, ADDRESS_CC, ");
            sql.AppendLine("   ADDRESS_BCC, EMAIL_BODY, IS_HTML, REQUESTED, SENT, SUBJECT) ");

            sql.AppendFormat("select email_id_seq.nextval, '{0}', '{0}', '{0}', emaildata, ", email.EmailFrom);
            sql.AppendFormat("null, null, '{0}', '0', sysdate, null, '{1}' ", email.Body, email.Subject);
            sql.AppendLine("from addrother ao ");
            sql.AppendLine("inner join uext_addrother uao on UAO.ADDROTHERID = AO.ADDROTHERID ");
            sql.AppendLine("inner join partyxref px on PX.REFTYPE = 'COMM' and PX.REFKEY = AO.ADDRID ");
            sql.AppendLine("inner join user_acc ua on UA.NAMEID = PX.NAMEID ");
            sql.AppendLine("where UAO.CONTACT = 1 and UAO.VERIFIED = 1 ");
            sql.AppendLine("AND     ao.EffectDt < SYSDATE AND NVL(ao.XpirDt, SYSDATE + 1) > SYSDATE ");
            sql.AppendFormat("and UA.USER_ACC_ID = {0}", email_to_user_acc_id);

            return sql.ToString();
        }
    }
}
