﻿using System;

namespace DCorum.Business.MessageCentre.Sql
{
    internal class PersonSQL
    {
        internal PersonSQL() { }

        private const string SqlSelectTemplate = @"
            select 
                p.NAMEID, LASTNAME, MIDNAME, FIRSTNAME, BIRTHDT, NATLIDNO, SEXCD, NAMEPREFIX
                , USER_ACC_ID
                , EMAILDATA as USER_ACC_NAME
            from 
                person p
            left join 
                user_acc ua 
                on ua.nameid = p.nameid
            left join
                v_party_addrother ao 
                on AO.NAMEID = P.NAMEID
                and AO.EFFECTDT <= trunc(sysdate)
                and (AO.XPIRDT is null or AO.XPIRDT >= trunc(sysdate))
                and AO.PRIMARY = 1
        ";

        public string Get(int primaryId)
        {
            return SqlSelectTemplate + String.Format("where p.nameid = {0} ", primaryId);
        }

        /// <summary>
        /// Not used other than for testing
        /// </summary>
        /// <returns></returns>
        public string GetMany()
        {
            return SqlSelectTemplate + "where rownum < 250";
        }
    }
}
