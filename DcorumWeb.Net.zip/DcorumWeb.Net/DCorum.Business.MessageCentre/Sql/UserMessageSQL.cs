﻿using System;
using System.Text;
using DCorum.Business.MessageCentre.Entities;
using Dcorum.Utilities.DataAccess;

namespace DCorum.Business.MessageCentre.Sql
{
    internal class UserMessageSQL
    {
        internal UserMessageSQL() { }

        private static string sqlSelect1 = @"
select
    m.Message_Detail_Id, m.Message_Id, m.Parent_Message_Id, m.Create_Date, m.Read_Date, Priority, user_id, Type, Category, Subject, Sender, body
from 
    message m 
inner join message_detail md 
    on M.MESSAGE_DETAIL_ID = MD.MESSAGE_DETAIL_ID
inner join user_acc ua
    on M.USER_ID = UA.USER_ACC_ID
";


        public string GetMessagesSQL(int nameId)
        {
            string sql1 = @"
where
    NameId = {0}
order by
    Create_Date desc
";
            string result = String.Format(sqlSelect1 + sql1, nameId);
            return result;
        }

        public string GetMessageGroupSQL(int messageId)
        {
            StringBuilder sSQL = new StringBuilder();

            // write some sql
            sSQL.AppendLine("select m2.message_group_id, m2.Message_Detail_Id, m2.Message_Id, m2.Parent_Message_Id, ");
            sSQL.AppendLine("m2.Create_Date,m2.Read_Date,Priority,m2.user_id, Type,Category,Subject,Sender,body ");
            sSQL.AppendLine("from message m ");
            sSQL.AppendLine("inner join message m2 on m2.message_group_id = m.message_group_id and M2.USER_ID = M.USER_ID ");
            sSQL.AppendLine("inner join message_detail md on M2.MESSAGE_DETAIL_ID = MD.MESSAGE_DETAIL_ID ");
            sSQL.AppendFormat("where m.Message_Id = {0} ", messageId);
            sSQL.AppendLine("order by m2.Message_Id desc ");

            return sSQL.ToString();
        }


        public string GetMessageSQL(int messageId)
        {
            string sql1 = @"
where
    m.Message_Id = {0}
";
            string result = String.Format(sqlSelect1 + sql1, messageId);
            return result;
        }

        public string AddMessageSQL(Message message, int userAccId)
        {
            StringBuilder sSQL = new StringBuilder();

            if (String.IsNullOrEmpty(message.ParentId.ToString()))
            {            
                sSQL.AppendLine("INSERT INTO MESSAGE ");
                sSQL.AppendLine("(MESSAGE_ID, PARENT_MESSAGE_ID, MESSAGE_DETAIL_ID, USER_ID, CREATE_DATE, MESSAGE_GROUP_ID) ");
                sSQL.AppendLine(string.Format("select MESSAGE_SEQ.NEXTVAL, 0, {0}, {1}, sysdate, m.msg_grp ",
                                              message.DetailId, userAccId));
                sSQL.AppendLine(string.Format("from (select nvl(max(MESSAGE_GROUP_ID),0) + 1 as msg_grp from message where user_id = {0}) m ",
                                              userAccId));
            }
            else
            {
                sSQL.AppendLine("INSERT INTO MESSAGE ");
                sSQL.AppendLine("(MESSAGE_ID, PARENT_MESSAGE_ID, MESSAGE_DETAIL_ID, USER_ID, CREATE_DATE, MESSAGE_GROUP_ID) ");
                sSQL.AppendLine(string.Format("select MESSAGE_SEQ.NEXTVAL, MESSAGE_ID, {0}, USER_ID, sysdate, MESSAGE_GROUP_ID ",
                                              message.DetailId));
                sSQL.AppendLine(string.Format("from message where user_id = {0} and MESSAGE_DETAIL_ID = {1} ",
                                              userAccId, message.ParentId));
            }
            return sSQL.ToString();
        }


        public string AddMessageDetailSQL(Message message)
        {
            const string template1 = @"INSERT 
INTO MESSAGE_DETAIL
    (MESSAGE_DETAIL_ID, PRIORITY, TYPE, CATEGORY, SUBJECT, BODY, SENDER)
VALUES 
    ({0}, {1}, {2}, {3}, {4}, {5}, {6})
";
            string result = String.Format(template1,
                message.DetailId,
                message.Priority.IntoSqlValue(),
                message.Type.IntoSqlValue(),
                message.Category.IntoSqlValue(),
                (message.Subject).SqlQuotify(),
                (message.Body).SqlQuotify(),
                message.Sender
                );

            return result;
        }

        public string GetMessageDetailSequenceName()
        {
            return "MESSAGE_DETAIL_SEQ";
        }

        public string UpdateMessageReadDateSQL(int messageDetailId)
        {
            const string sql1 = @"UPDATE MESSAGE
    SET
        READ_DATE = sysdate
    WHERE 
        MESSAGE_DETAIL_ID = {0} 
        AND READ_DATE IS NULL
";
            string result = String.Format(sql1, messageDetailId);
            return result;
        }
    }
}
