﻿using DCorum.Business.MessageCentre.DataAccess;
using DCorum.Business.MessageCentre.Entities;
using DCorum.BusinessFoundation.Bases;
using System.Diagnostics;

namespace DCorum.Business.MessageCentre.Logic
{
    public class BLPerson : BLRetrieverTemplate<Person>
    {
        internal BLPerson(DLPerson dataAccess) : base(dataAccess)
        {
            _myDataAccess = dataAccess;
            Debug.Assert(_myDataAccess != null);
        }

        private readonly DLPerson _myDataAccess;
    }
}
