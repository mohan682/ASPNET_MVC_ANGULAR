﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using DCorum.Business.MessageCentre.Contractual;
using DCorum.Business.MessageCentre.DataAccess;
using DCorum.Business.MessageCentre.Entities;
using Dcorum.BusinessLayer.Bundles;
using System.Diagnostics;

namespace DCorum.Business.MessageCentre.Logic
{
    [Category(null)]
    public class BLUserMessage
    {
        internal BLUserMessage(DLUserMessage dataAccess, DLEmail emailDataAccess)
        {
            _dataAccess = dataAccess;
            _myEmailDataAccess = emailDataAccess;

            Debug.Assert(_dataAccess != null);
            Debug.Assert(_myEmailDataAccess != null);
        }

        private readonly DLUserMessage _dataAccess;
        private readonly DLEmail _myEmailDataAccess;


        private static readonly IDictionary<MessageCategory, string> _keyTabHeadings = new Dictionary<MessageCategory, string>()
        {   {MessageCategory.Message, "Messages ({0})"}
        ,   {MessageCategory.Event, "Events ({0})"}
        ,   {MessageCategory.Notification, "Notifications ({0})"}
        };

        /// <summary>
        /// [IMMUTABLE]
        /// </summary>
        public IEnumerable<KeyValuePair<MessageCategory, string>> KeyedTabHeadings
        {
            get
            {
                return _keyTabHeadings.Select(_ => new KeyValuePair<MessageCategory, string>(_.Key, _.Value));
            }
        } 


        /// <summary>
        /// Method used to generate a collection of messages related to a particular user
        /// </summary>
        /// <returns>Returns a list of Messages</returns>
        public Message[] GetList(int nameId)
        {
            return _dataAccess.GetList(nameId);
        }

        /// <summary>
        /// Method used to get message (including detail) specified by messageId
        /// </summary>
        /// <returns>Returns one user message</returns>
        public Message GetMessage(int messageId)
        {
            return _dataAccess.GetMessage(messageId);
        }

        /// <summary>
        /// Method used to get a group of messages linked to a specified messageId
        /// </summary>
        /// <returns>Returns a list of user messages</returns>
        public Message[] GetMessageGroup(int messageId)
        {
            if (messageId <= 0) return new Message[] {};
            return _dataAccess.GetMessageGroup(messageId);
        }

        public bool Add(Message message, int userAccId)
        {
            return _dataAccess.Add(message, userAccId);
        }

        public bool UpdateReadDateForMessage(Message message)
        {
            return _dataAccess.UpdateReadDateForMessage(message);
        }


        public void SaveContactHistory(Person person, Message message, int userId, int caseMbrKey)
        {
            //Create email to member, informing they have a new message and incuding link to TargetPlan login
            var targetPlanLoginLink = ConfigurationManager.AppSettings["targetPlanLoginLink"];

            StringBuilder body = new StringBuilder();
            body.AppendLine("You have a new message in TargetPlan. Please click on the link below to login.");
            body.AppendLine();
            body.AppendLine(targetPlanLoginLink);

            var toAdd1 = new Email
            {
                EmailFrom = ConfigurationManager.AppSettings["Emailer.Sender.Default"],
                Subject = "You have a new message",
                Body = body.ToString()
            };

            bool emailSent = _myEmailDataAccess.Add( toAdd1, person.UserAccId);

            //Create Contact History entry saying message to user created
            string contactHistoryMsgTemplate = "New web message added: {0}\n\nSubject: {1}\n\n{2}\n\nNOTE: {3}\n";

            String note1 = emailSent ? "An email has been sent informing the user" : "We were NOT able to send an email to inform the user";

            string contactHistoryMsg = String.Format(contactHistoryMsgTemplate, "{0}", message.Subject, message.Body, note1);

            int? nameId = (caseMbrKey > 0) ? (int?)null : person.NameId;
            var subController1 = new BundledContactHistory.BLContactHistory(userId, nameId, BundledContactHistory.ContactHistoryActionMessageCentre);
            subController1.Save(caseMbrKey, contactHistoryMsg);
        }
    }
}
