﻿//using System.ComponentModel;
//using DCorum.Business.MessageCentre.DataAccess;
//using DCorum.Business.MessageCentre.Entities;
//using System.Diagnostics;

//namespace DCorum.Business.MessageCentre.Logic
//{
//    [Category(null)]
//    public class BLEmail
//    {
//        internal BLEmail(DLEmail dataAccess)
//        {
//            _myDataAccess = dataAccess;
//            Debug.Assert(_myDataAccess != null);
//        }

//        private readonly DLEmail _myDataAccess;

//        public bool Add(Email email)
//        {
//            return _myDataAccess.Add(email);
//        }

//        public bool Add(Email email, int email_to_user_acc_id)
//        {
//            return _myDataAccess.Add(email, email_to_user_acc_id);
//        }
//    }
//}
