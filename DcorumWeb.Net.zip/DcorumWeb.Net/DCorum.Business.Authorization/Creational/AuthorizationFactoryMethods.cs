﻿using Dcorum.BusinessLayer.Contractual;
using DCorum.Business.Authorization.Controllers;
using DCorum.Business.Authorization.DataAccess;
using DCorum.Business.Authorization.Internals;
using DCorum.Business.Authorization.ViewModels;
using System;
using System.Data;
using System.Linq;

namespace DCorum.Business.Authorization.Creational
{
    public class AuthorizationFactoryMethods
    {
        public static readonly AuthorizationFactoryMethods Singleton = new AuthorizationFactoryMethods();
        private AuthorizationFactoryMethods() {}


        private static readonly PermissionFlagValidator SharedPermissionFlagValidator = new PermissionFlagValidator();

        /// <summary>
        /// [FACTORY_METHOD]
        /// </summary>
        public SchemeFlagController CreateSchemePermissionFlagController(IAuditingArgumentsReadOnly caller, bool? readOnlyModeOn = null)
        {
            Func<IDataReader,SchemePermissionFlag> modelCreationTechnique = new Func<IDataReader, SchemePermissionFlag>( @reader => new SchemePermissionFlag(@reader, SchemePermissionFlagBundle.SqlSpec.ColumnNames.ToArray()));
            var dataAccessCreation = new SchemePermissionFlagBundle.CrudActor(new SchemePermissionFlagBundle.SqlMaker(), modelCreationTechnique);

            var creation1 = new SchemeFlagController(caller, dataAccessCreation, SharedPermissionFlagValidator );        
            if (readOnlyModeOn.HasValue) creation1.ReadOnlyModeOn = readOnlyModeOn.Value;
            return creation1;
        }

        /// <summary>
        /// [FACTORY_METHOD]
        /// </summary>
        public MemberGroupFlagController CreateMemberGroupPermissionFlagController(IAuditingArgumentsReadOnly caller)
        {
            Func<IDataReader, MemberGroupPermissionFlag> modelCreationTechnique = new Func<IDataReader, MemberGroupPermissionFlag>(@reader => new MemberGroupPermissionFlag(@reader, MemberGroupPermissionFlagBundle.SqlSpec.ColumnNames.ToArray()));
            var dataAccessCreation = new MemberGroupPermissionFlagBundle.CrudActor(new MemberGroupPermissionFlagBundle.SqlMaker(), modelCreationTechnique);

            var creation1 = new MemberGroupFlagController(caller, dataAccessCreation, SharedPermissionFlagValidator );
            return creation1;
        }
    }
}
