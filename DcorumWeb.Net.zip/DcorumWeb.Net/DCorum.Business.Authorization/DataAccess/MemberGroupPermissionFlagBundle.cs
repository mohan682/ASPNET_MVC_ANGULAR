﻿using Dcorum.Utilities.DataAccess;
using DCorum.Business.Authorization.Models;
using DCorum.Business.Authorization.ViewModels;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Data;
using System.Linq;

namespace DCorum.Business.Authorization.DataAccess
{
    public static class MemberGroupPermissionFlagBundle
    {
        internal class CrudActor : CrudActor<MemberGroupPermissionFlag, int, int>
        {
            protected internal CrudActor(SqlMaker injectedCrud, Func<IDataReader, MemberGroupPermissionFlag> creationTechnique)
                : base(creationTechnique, injectedCrud)
            {
            }

            public MemberGroupPermissionFlag SelectViaOtherIdentity(PermissionFlagBase identity)
            {
                string sql1 = string.Format(
                    CustomSqlCrudTemplates.SelectMissingOneTemplate
                    , SqlSpec.TableName
                    , identity.ParentId
                    , identity.FlagCode.IntoSqlValue()
                    , identity.Scope.IntoSqlValue()
                    );

                string finalSql1 = new[] { sql1 }.IntoWellFormedSql();

                return DataAccessHelp.GetSingle(finalSql1, @Make);
            }
        }

        internal class SqlMaker : SimpleSqlFullCrud<PermissionFlagBase, int, int>
        {
            protected internal SqlMaker()
                : base(SqlSpec, new SimpleSqlCrudTemplateBuilder(SqlSpec, CustomSqlCrudTemplates.Singleton))
            {
            }
        }


        private class CustomSqlCrudTemplates : SqlCrudTemplates
        {
            internal static readonly CustomSqlCrudTemplates Singleton = new CustomSqlCrudTemplates();

            private CustomSqlCrudTemplates()
            {
                SimpleSelectManyTemplate = @"
SELECT 
    nvl(from1.FLAG_CODE, j1.PERMISSION_FLAG) as FLAG_CODE, nvl(from1.Scope,j1.Scope) as Scope, nvl(from1.ANSWER_TYPE, j1.ANSWER_TYPE) as Answer_Type, from1.* 
FROM
    {0} from1
RIGHT JOIN PERMISSION_FLAG j1 
ON j1.PERMISSION_FLAG = from1.FLAG_CODE and j1.Scope = from1.Scope and {1}
";
            }

            internal const string SelectMissingOneTemplate = @"
SELECT 
    nvl(from1.FLAG_CODE, j1.PERMISSION_FLAG) as FLAG_CODE, nvl(from1.Scope,j1.Scope) as Scope, nvl(from1.ANSWER_TYPE, j1.ANSWER_TYPE) as Answer_Type, from1.* 
FROM
    {0} from1
RIGHT JOIN PERMISSION_FLAG j1 
ON j1.PERMISSION_FLAG = from1.FLAG_CODE and j1.Scope = from1.Scope and MBGP_KEY = {1}
WHERE 
    j1.PERMISSION_FLAG = {2}
    and j1.Scope = {3}
";

        }


        internal static readonly ISqlSpecification<PermissionFlagBase> SqlSpec =
            new SqlSpecification<PermissionFlagBase>
            {
                TableName = "MbGp_Permission_Flag",
                ColumnNames = new[] { "MBGP_PERMISSION_FLAG_ID", "MBGP_KEY", "FLAG_CODE", "ANSWER_TYPE", "SCOPE", "VALUE" }.ToArray(),

                MyIdentityIndexes = new[] { new[] { 0 }, new[] { 1, 2, 4 } },
                UpdatableIndexes = new int[] { 5 },

                ParentKeyIndex = 1,
                SqlSequenceName = "MbGp_Permission_Flag_id_seq",
    
                GettersForSql = new Func<PermissionFlagBase, object>[]
                {
                    _ => _.Id,
                    _ => _.ParentId,
                    _ => _.FlagCode.IntoSqlValue(),
                    _ => _.AnswerType.IntoSqlValue(),
                    _ => _.Scope.IntoSqlValue(),
                    _ => _.ChosenValue.IntoSqlValue()
                }
            };
    }
}
