﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.Utilities.Practices;
using DCorum.Business.Authorization.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;

namespace DCorum.Business.Authorization.ViewModels
{
    [DisplayName("Additional Settings")]
    public class SchemePermissionFlag : PermissionFlagBase
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        protected internal SchemePermissionFlag(IDataReader reader = null, string[] columnNames = null)
            :base(reader, columnNames)
        {
        }


        /// <summary>
        /// [CONSTRUCTOR] Just to satisty horrid controller generic argument constraint
        /// </summary>
        public SchemePermissionFlag()
        {
        }

        public int? CaseKey
        {
            get { return base.ParentId; }
            set { if (!(Id >= 1) && value.HasValue) base.ParentId = value.Value; }
        }


        [IgnoreDataMember]
        public string FlagDescription
        {
            get
            {
                return FlagCode.SafeFunc(_ => _.Descript);
            }
        }

        [IgnoreDataMember]
        public string FlagId
        {
            get
            {
                return FlagCode.SafeFunc(_ => _.RefCd);
            }
        }

        [IgnoreDataMember]
        public string scopeId
        {
            get
            {
                return Scope.SafeFunc(_ => _.RefCd);
            }
        }

        [IgnoreDataMember]
        public string ScopeDescription
        {
            get
            {
                return Scope.SafeFunc(_ => _.Descript);
            }
        }

        [IgnoreDataMember]
        public string AnswerGroupDescription
        {
            get
            {
                return AnswerType.SafeFunc(_ => _.Descript);
            }
        }

        [IgnoreDataMember]
        public string ChosenValueDescription
        {
            get
            {
                return ChosenValue.SafeFunc(_ => _.Descript);
            }
        }


        [IgnoreDataMember]
        public bool CanDelete { get { return Id > 0 && CanPersist; }}

        [IgnoreDataMember]
        public bool CanEdit { get { return CanPersist; }}

        [IgnoreDataMember]
        public bool CanPersist { get; internal set; }

        public IDictionary<string, string> OptionPairs()
        {
            IEnumerable<RefCode> options = RefCodeCache.RetrieveByDomainName(AnswerType.RefCd, true);
            var pairs = options.OrderBy(m => m.LineNo).ToDictionary(m => m.RefCd, m => m.Descript);
            return pairs;
        }
    }
}
