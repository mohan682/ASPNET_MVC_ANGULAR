﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;
using DCorum.Business.Authorization.Internals;
using DCorum.Business.Authorization.ViewModels;
using DCorum.BusinessFoundation.Auditing.Constants;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;

using static DCorum.Business.Authorization.DataAccess.MemberGroupPermissionFlagBundle;

namespace DCorum.Business.Authorization.Controllers
{
    [Category(DomainCodes.DcorumComponentMemberGroup)]
    public class MemberGroupFlagController : BLPersistorTemplate<MemberGroupPermissionFlag, int, int>, IRetriever<MemberGroupPermissionFlag>
    {
        internal MemberGroupFlagController(IAuditingArgumentsReadOnly caller, CrudActor injectedCrud, PermissionFlagValidator modelValidator)
            : base(caller, injectedCrud)
        {
            _dataAccess = injectedCrud;
            if (_dataAccess == null) throw new ArgumentNullException(nameof(injectedCrud));

            _modelValidator = modelValidator;
            if (_modelValidator == null) throw new ArgumentNullException(nameof(modelValidator));
        }

        private readonly CrudActor _dataAccess;
        private readonly PermissionFlagValidator _modelValidator;

        protected override Tuple<RefCode, string> GetAuditFriendlyId(MemberGroupPermissionFlag toUse)
        {
            return Tuple.Create(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeMbrGrp), toUse.MbGpKey.ToString());
        }


        public override void Hydrate(MemberGroupPermissionFlag toHydrate)
        {
            base.Hydrate(toHydrate); //hydrate ref_codes

            if (toHydrate?.AnswerType?.RefCd != null)
            {
                IEnumerable<RefCode> options = RefCodeCache.RetrieveByDomainName(toHydrate.AnswerType.RefCd, true);
                toHydrate.ChosenValue = RefCodeHelp.IntoHydratedRefCodeVia(toHydrate.ChosenValue, options);
            }

            toHydrate.CanPersist = (!ReadOnlyModeOn);

        }

        MemberGroupPermissionFlag IRetriever<MemberGroupPermissionFlag>.GetUniqueViaTextualId(string candidateKey)
        {
            return GetUniqueViaTextualId(candidateKey);
        }

        public MemberGroupPermissionFlag GetUniqueViaTextualId(string candidateKey, char optionalSeparator = '|')
        {
            MemberGroupPermissionFlag rowModel = null;

            int? primaryKey = candidateKey.IntoIntN();

            if (primaryKey.HasValue)
            {
                rowModel = _dataAccess.SelectViaPrimaryKey(primaryKey.Value) ?? Create();
            }
            else
            {
                string[] keyParts = candidateKey.Split(optionalSeparator);

                if (keyParts.Length != 3) throw new ArgumentException("", nameof(candidateKey));

                int? injectedMbGpKey = keyParts[0].IntoIntN();
                var identity = new MemberGroupPermissionFlag()
                {
                    MbGpKey = injectedMbGpKey,
                    FlagCode = new RefCode(keyParts[1]),
                    Scope = new RefCode(keyParts[2])
                };
                rowModel = _dataAccess.SelectViaOtherIdentity(identity) ?? Create();

                Debug.Assert(rowModel.MbGpKey == AmbientValue || rowModel.MbGpKey == injectedMbGpKey);

                if (rowModel.MbGpKey == AmbientValue)
                {
                    rowModel.MbGpKey = injectedMbGpKey;
                }
            }

            if (rowModel == null) throw new InvalidOperationException();

            Hydrate(rowModel);
            return rowModel;
        }

        public override MemberGroupPermissionFlag[] GetMany(int parentId = default(int), string augmentQueryWith = null)
        {
            var results = base.GetMany(parentId, augmentQueryWith);
            results = results.OrderBy(m => m.FlagCode.LineNo).ThenBy(m => m.Scope.LineNo).ToArray();

            return results;
        }


        //protected override TaintedMemberGroupPermissionFlag ConvertFromDataModel(PermissionFlagBase dataModel)
        //{
        //    return (TaintedMemberGroupPermissionFlag)dataModel;
        //}

        //protected override PermissionFlagBase ConvertIntoDataModel(TaintedMemberGroupPermissionFlag model)
        //{
        //    return model ;
        //}

        public IEnumerable<IOutcomeItem> ValidateMany(MemberGroupPermissionFlag[] toValidate)
        {
            IEnumerable<string> issues = _modelValidator.Validate(toValidate);
            var results = issues.Select(_ => new OutcomeItem(_));
            return results;
        }
    }
}
