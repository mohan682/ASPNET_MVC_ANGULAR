﻿using System.ComponentModel;

namespace DCorum.Business.Authorization.Controllers.Internals
{
    /// <summary>
    /// [ENUM]
    /// </summary>
    internal static class PermissionFlagHints
    {
        internal const string Enable_Drawdown = "Enable_Drawdown" ;
        internal const string Enable_Full_UFPLS = "Enable_Full_UFPLS";
        internal const string Enable_Partial_UFPLS = "Enable_Partial_UFPLS";
        internal const string Enable_Small_Pot = "Enable_Small_Pot";
        internal const string Enable_Small_Pot_PTFC = "Enable_Small_Pot_PTFC";

        internal const string Yes = "1";
        internal const string No = "0";
    }
}
