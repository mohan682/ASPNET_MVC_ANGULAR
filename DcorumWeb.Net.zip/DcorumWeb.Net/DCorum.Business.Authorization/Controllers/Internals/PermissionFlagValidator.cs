﻿using DCorum.Business.Authorization.Controllers.Internals;
using DCorum.Business.Authorization.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace DCorum.Business.Authorization.Internals
{
    /// <summary>
    /// [STATELESS]
    /// </summary>
    internal class PermissionFlagValidator
    {
        protected internal PermissionFlagValidator() { }


        public IEnumerable<string> Validate(IEnumerable<PermissionFlagBase> source)
        {
            string outcome1 = ValidateSpec(source);

            if (outcome1 != null) yield return outcome1;

            //Checked with DD and understand that bothe there rows will always be sent in parameter name "Source"
            PermissionFlagBase fullUFPLS = source.First(x => String.Equals(x.FlagCode.RefCd, PermissionFlagHints.Enable_Full_UFPLS, StringComparison.InvariantCultureIgnoreCase));
            PermissionFlagBase partialUFPLS = source.First(x => String.Equals(x.FlagCode.RefCd, PermissionFlagHints.Enable_Partial_UFPLS, StringComparison.InvariantCultureIgnoreCase));

            if (partialUFPLS.ChosenValue != null && partialUFPLS.ChosenValue.RefCd == PermissionFlagHints.Yes && (fullUFPLS.ChosenValue == null || fullUFPLS.ChosenValue.RefCd == PermissionFlagHints.No))
                yield return partialUFPLS.FlagCode.Descript  + " can not be set to "  + Dcorum.RefCoding.RefCodePool.Singleton.ObtainYesFlag().Descript  + " when " + fullUFPLS.FlagCode.Descript + " is set to " + Dcorum.RefCoding.RefCodePool.Singleton.ObtainNoFlag().Descript;
        }


        internal string ValidateSpec(IEnumerable<PermissionFlagBase> source)
        {
            if (source == null || source.Any() == false) return "There are no items to validate";

            if (source.Any(_ => _.FlagCode == null)) return "Some items have a missing key";
            if (source.Any(_ => string.IsNullOrEmpty(_.FlagCode?.RefCd))) return "Some items have a blank key";
            if (source.Any(_ => _.Scope == null)) return "Some items have a missing scope";
            if (source.Any(_ => string.IsNullOrEmpty(_.Scope?.RefCd))) return "Some items have a blank scope";

            return null;
        }
    }
}
