﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;
using DCorum.Business.Authorization.Internals;
using DCorum.Business.Authorization.ViewModels;
using DCorum.BusinessFoundation.Auditing.Constants;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using static DCorum.Business.Authorization.DataAccess.SchemePermissionFlagBundle;

namespace DCorum.Business.Authorization.Controllers
{
    [Category(DomainCodes.DCorumComponentScheme)]
    public class SchemeFlagController : BLPersistorTemplate<SchemePermissionFlag, int, int>, IRetriever<SchemePermissionFlag>
    {
        internal SchemeFlagController(IAuditingArgumentsReadOnly caller, CrudActor injectedCrud, PermissionFlagValidator modelValidator)
        : base(caller, injectedCrud)
        {
            _dataAccess = injectedCrud;
            if (_dataAccess == null) throw new ArgumentNullException(nameof(injectedCrud));

            _modelValidator = modelValidator;
            if (_modelValidator == null) throw new ArgumentNullException(nameof(modelValidator));
        }

        private readonly CrudActor _dataAccess;
        private readonly PermissionFlagValidator _modelValidator;

        protected override Tuple<RefCode, string> GetAuditFriendlyId(SchemePermissionFlag toUse)
        {
            return Tuple.Create(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeScheme), toUse.CaseKey.ToString());
        }


        public override void Hydrate(SchemePermissionFlag toHydrate)
        {
            base.Hydrate(toHydrate); //hydrate ref_codes

            if (toHydrate?.AnswerType?.RefCd != null)
            {
                IEnumerable<RefCode> options = RefCodeCache.RetrieveByDomainName(toHydrate.AnswerType.RefCd, true);
                toHydrate.ChosenValue = RefCodeHelp.IntoHydratedRefCodeVia(toHydrate.ChosenValue, options);
            }

            toHydrate.CanPersist = (!ReadOnlyModeOn);
        }


        SchemePermissionFlag IRetriever<SchemePermissionFlag>.GetUniqueViaTextualId(string candidateKey)
        {
            return GetUniqueViaTextualId(candidateKey);
        }

        /// <summary>
        /// [RESOLVER]
        /// </summary>
        /// <param name="candidateKey">can be either actual primary key or casekey+refcd alternative key</param>
        /// <param name="optionalSeparator">Specify if '|' delimiter isn't suitable.</param>
        /// <returns></returns>
        public SchemePermissionFlag GetUniqueViaTextualId(string candidateKey, char optionalSeparator = '|')
        {
            SchemePermissionFlag rowModel = null;

            int? primaryKey = candidateKey.IntoIntN();

            if (primaryKey.HasValue)
            {
                rowModel = _dataAccess.SelectViaPrimaryKey(primaryKey.Value);
            }
            else
            {
                string[] keyParts = candidateKey.Split(optionalSeparator);

                if (keyParts.Length != 3) throw new ArgumentException("", nameof(candidateKey));

                int? injectedCaseKey = keyParts[0].IntoIntN();

                var identity = new SchemePermissionFlag()
                {
                    CaseKey = injectedCaseKey,
                    FlagCode = new RefCode(keyParts[1]),
                    Scope = new RefCode(keyParts[2])
                };
                rowModel = _dataAccess.SelectViaOtherIdentity(identity) ?? Create();

                Debug.Assert(rowModel.CaseKey == AmbientValue || rowModel.CaseKey == injectedCaseKey);

                if (rowModel.CaseKey == AmbientValue)
                {
                    rowModel.CaseKey = injectedCaseKey;
                }
            }

            if (rowModel == null) throw new InvalidOperationException();

            Hydrate(rowModel);
            return rowModel;
        }


        public override SchemePermissionFlag[] GetMany(int parentId = default(int), string augmentQueryWith = null)
        {
            var results = base.GetMany(parentId, augmentQueryWith);
            results = results.OrderBy(m => m.FlagCode.LineNo).ThenBy(m => m.Scope.LineNo).ToArray();

            return results;
        }


        public IEnumerable<IOutcomeItem> ValidateMany(SchemePermissionFlag[] toValidate)
        {
            IEnumerable<string> issues = _modelValidator.Validate(toValidate);
            var results = issues.Select(_ => new OutcomeItem(_));
            return results;
        }
    }
}
