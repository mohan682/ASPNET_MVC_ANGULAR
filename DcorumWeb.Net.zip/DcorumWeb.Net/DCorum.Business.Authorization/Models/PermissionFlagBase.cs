﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;

namespace DCorum.Business.Authorization.Models
{
    public abstract class PermissionFlagBase
    {
        protected internal PermissionFlagBase(IDataReader reader = null, string[] columnNames = null)
        {
            if (reader == null) return;
            Build(this, reader, columnNames);
        }

        [Key]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        public int Id { get; protected set; }

        [IgnoreDataMember]
        internal protected int ParentId { get; protected set; }

        [RefCodeConstraint("PERMISSION_FLAGS")]
        [UiDisplayingHint(UiDisplayMode.Editable,UiDisplayMode.Displayable)]
        public RefCode FlagCode { get; internal set; }

        [UIHint("ddlChosenValue")]
        public RefCode ChosenValue { get; set; }

        [RefCodeConstraint("PERMISSION_ANSWER_TYPE")]
        public RefCode AnswerType { get; set; }
        [RefCodeConstraint("PERMISSION_SCOPE")]
        public RefCode Scope { get; set; }

        protected static void Build(PermissionFlagBase model, IDataReader reader, string[] columnNames)
        {
            model.Id = reader.FetchAsValue<int>(columnNames[0]);
            model.ParentId = reader.FetchAsValue<int>(columnNames[1]); //case key or member group key

            model.FlagCode = reader.FetchTextualRefCode(columnNames[2]);
            model.AnswerType = reader.FetchTextualRefCode(columnNames[3]);
            model.Scope = reader.FetchTextualRefCode(columnNames[4]);
            model.ChosenValue = reader.FetchTextualRefCode(columnNames[5]);
        }
    }
}
