﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.Business.ServiceTask.Entities
{
    public class EventTriggerAdditionalSql
    {
        public int Id { get; set; }

        public string Sql { get; set; }

        public string IdentifyingColumn { get; set; }

    }
}
