﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.Business.ServiceTask.Entities
{
   public class EventTrigger
    {
        public int Id { get; set; }

        public string Type { get; set; }

        public bool IsActive { get; set; }

        public Lazy<EventTriggerSql> Sql { get; set; }

       // public Lazy<EventTriggerDetail> Detail { get; set; }
    }
}
