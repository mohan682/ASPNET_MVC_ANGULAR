﻿using Dcorum.Business.ServiceTask.Creational;
using Dcorum.BusinessCore.Helping;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Annotations;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;

namespace Dcorum.Business.ServiceTask.Entities
{
    public class EventTriggerSuppression
    {
        public EventTriggerSuppression()
            :this(null, null)
        { }

        public EventTriggerSuppression(IDataReader reader, IEnumerable<string> columnNames)
        {
            string[] columnSet1 = columnNames.SafeLinq().ToArray();
            Build(this, reader, columnSet1);
        }

        [Key]
        public int Id { get; protected set; }

        [UIHint("ddl*", "search")]
        [UIHint("ddl*")]
        [Display(Name = "Status:", Prompt = "Please choose a category")]
        [Required]
        [RefCodeConstraint(ServiceTaskStandards.SuppressionDomainName)]
        [UiSearchable("TYPE_CD", "=", CanBeNull = false, LabelNameOverride = "Type Code:",  OrderOverride = 60)]
        public RefCode SuppressionCode { get; internal set; }

        //[UIHint("txt*", "search")]
        //[UIHint("txt*")]
        [Required]
        //[AutoExtender("GetTargetPlanEnabledSchemeList")]
        //[UiSearchable("CASE_KEY", "=", CanBeNull = false, LabelNameOverride = "Scheme:", OrderOverride = 40)]
        public int? CaseKey { get; internal set; }

        private static void Build(EventTriggerSuppression model, IDataReader reader, string[] columnNames)
        {
            if (reader == null) return;

            model.Id = reader.FetchAsValue<int>(columnNames[0]);

            model.SuppressionCode = reader.FetchTextualRefCode(columnNames[1]);

            model.CaseKey = reader.FetchAsValue<int>(columnNames[2]);
        }

        [IgnoreDataMember]
        public string RefCodeDesc { get { return SuppressionCode.Descript; } }

        [IgnoreDataMember]
        public bool CanEdit { get; internal set; }

        [IgnoreDataMember]
        public bool CanDelete { get; internal set; }

        [IgnoreDataMember]
        public bool CanInsert { get; internal set; }

        [Display(Name = "Scheme:", Prompt = "Please choose a scheme")]
        [UIHint("txt*")] //used in tabular view
        [UIHint("txt*", "search")]
        [Required]
        [AutoExtender("GetTargetPlanEnabledSchemeList")]
        [UiSearchable("CASE_KEY", "=", CanBeNull = false, LabelNameOverride = "Scheme:", OrderOverride = 40)]
        public string SchemeDesc
        {
            get
            {
                return CoreInjectedMechanics.IntoSchemeDisplayName(CaseKey);
            }
            set
            {
                CaseKey = CoreInjectedMechanics.ConvertSchemeDisplayNameToCaseKey(value);
            }
        }

    }
}
