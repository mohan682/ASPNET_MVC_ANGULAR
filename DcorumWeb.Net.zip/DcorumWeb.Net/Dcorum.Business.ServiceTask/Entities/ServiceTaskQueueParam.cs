﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.Business.ServiceTask.Entities
{
    public class ServiceTaskQueueParam
    {
        public string Name { get; set; }

        public string Value { get; set; }

        public Int16 Order { get; set; }
    }
}
