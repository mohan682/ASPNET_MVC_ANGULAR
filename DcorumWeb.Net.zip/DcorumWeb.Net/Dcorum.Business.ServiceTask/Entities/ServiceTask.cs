﻿using Dcorum.Utilities;
using Dcorum.Utilities.Practices;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Dcorum.Business.ServiceTask.Entities
{
    public class ServiceTask
    {
        public ServiceTask()
            :this(null, null)
        { }

        public ServiceTask(IDataReader reader, IEnumerable<string> columnNames)
        {
            string[] columnSet1 = columnNames.SafeLinq().ToArray();
            Build(this, reader, columnSet1);
        }


        private static void Build(ServiceTask model, IDataReader reader, string[] columnNames)
        {
            if (reader == null) return;

            model.Id = reader.FetchAsValue<int>(columnNames[0]);

            model.BindingName = reader.FetchAsString(columnNames[1]);

            model.Description = reader.FetchAsString(columnNames[2]);

            model.IsActive = reader.FetchBooleanN(columnNames[3]) ?? false;
        }


        public int Id { get; set; }

        public string BindingName { get; set; }

        public string Description { get; set; }

        public bool IsActive { get; set; }

        //public Lazy<EventTrigger> EventTrigger { get; set; }
    }
}
