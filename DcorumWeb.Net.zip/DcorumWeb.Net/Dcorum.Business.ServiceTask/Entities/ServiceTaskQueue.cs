﻿using Dcorum.Business.ServiceTask.Contractual;
using Dcorum.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Annotations;
using DCorum.BusinessFoundation.Bases;
using Dcorum.Utilities.Annotations;
using System.Runtime.Serialization;

namespace Dcorum.Business.ServiceTask.Entities
{
    using DCorum.ViewModelling.Contractual;
    using ServiceTaskAlias = Dcorum.Business.ServiceTask.Entities.ServiceTask;

    public class ServiceTaskQueueSearch :ServiceTaskQueue
    {
        [Display(Name = "Period:")]
        [UIHint("ddl*", "search")]
        [Required]
        [UiSearchable("SCHEDULE_DATE", "=", CanBeNull = false, OrderOverride = 40, PreventSqlQuotes = true, CustomFormat = "({0} between trunc({2}) and trunc({2})+1)")]
        public RelativeDay SearchPeriod { get; protected set; }
    }


    public class ServiceTaskQueue :ModelWithBusinessContraints
    {
        public ServiceTaskQueue()
            :this(null, null)
        { }

        public ServiceTaskQueue(IDataReader reader, IEnumerable<string> columnNames)
        : base(new BusinessContraintsContainer())
        {
            string[] columnSet1 = columnNames.SafeLinq().ToArray();
            Build(this, reader, columnSet1);

            _originalId = Id;        
        }


        private static void Build(ServiceTaskQueue model, IDataReader reader, string[] columnNames)
        {
            if (reader == null) return;

            model.Id = reader.FetchAsValue<int>(columnNames[0]);

            model.ScheduledDateTime = reader.FetchAsValue<DateTime>(columnNames[1]);

            model.ProcessedDate = reader.FetchAsNullable<DateTime>(columnNames[2]);

            model.IsLocked = reader.FetchBooleanN(columnNames[3]) ?? false ;

            model.ThreadNumber = reader.FetchAsValue<int>(columnNames[4]);

            model.IsActive = reader.FetchBooleanN(columnNames[5]) ?? false ;

            string _status = reader.FetchAsString(columnNames[6]);
            model.Status =  _status.IntoEnum<ServiceTaskStatus>();

            model.ServiceTaskId = reader.FetchAsValue<int>(columnNames[7]);

            model.ParamCount = reader.FetchAsValue<int>("paramCount");
        }


        internal void InitializeBeforeInsert()
        {
            Id = 0;
            ProcessedDate = null;
            IsLocked = false;
            ThreadNumber = 0;
            IsActive = true;
            Status = ServiceTaskStatus.PE ;
        }


        [Key]
        public int Id { get; internal protected set; }

        [Required]
        [BusinessConstraint(1, typeof(ServiceTaskAlias))]
        [UIHint("ddl*", "search")]
        [UiSearchable("SERVICE_TASK_ID", "=", CanBeNull = false, OrderOverride = 80, LabelNameOverride = "Service Task")]
        public int ServiceTaskId { get; internal set; }

        //[UIHint("txt*")]
        [DataType(DataType.DateTime)]
        [Required]
        public DateTime? ScheduledDateTime { get; internal protected set; }

        [Display(Prompt = "Please enter a date")]
        [UIHint("txt*")]
        [DataType(DataType.Date)]
        [Required]
        [IgnoreDataMember]
        public DateTime? ScheduledDate
        {
            get { return ScheduledDateTime?.Date; }
            set { ScheduledDateTime = value?.Add(ScheduledTime.Value); }
        }

        [Display(Prompt="Please enter a time")]
        [UIHint("txt*")]
        [DataType(DataType.Time)]
        [Required]
        [IgnoreDataMember]
        [RegularExpression(RegExConstants.Time24FormatWithOptionalLeadingZero)]
        public TimeSpan? ScheduledTime
        {
            get { return ScheduledDateTime?.TimeOfDayAsTimespan(); }
            set { ScheduledDateTime = ScheduledDate?.Add(value ?? default(TimeSpan) ); } 
        }


        [DataType(DataType.DateTime)]
        public DateTime? ProcessedDate { get; protected set; }

        public int? ThreadNumber { get; internal protected set; }

        //[UIHint("chk*")]
        //[UiSearchable("LOCKED", "=", CanBeNull = true, OrderOverride = 105, LabelNameOverride = "Locked")]
        public bool IsLocked { get; protected set; }

        //[UIHint("chk*")]
        //[UiSearchable("ACTIVE", "=", CanBeNull = true, OrderOverride = 155, LabelNameOverride = "Active")]
        public bool IsActive { get; protected set; }

        [Required]
        [Display(Name = "Status:")]
        [UIHint("ddl*", "search")]
        [UiSearchable("STATUS_CD", "=", CanBeNull = false, OrderOverride = 50)]
        public ServiceTaskStatus? Status { get; protected set; }

    
        [IgnoreDataMember]
        public bool CanEdit { get; internal set; }

        [IgnoreDataMember]
        public bool CanRerun { get; internal set; }

        [IgnoreDataMember]
        public bool CanClone { get; internal set; }

        public int ParamCount { get; protected set; }

        /// <summary>
        /// [READONLY]
        /// </summary>
        //[IgnoreDataMember]
        internal readonly int _originalId;

        public int OriginalId { get { return _originalId; } }

        /// <summary>
        /// For auditing clarity only!
        /// </summary>
        public string Action { get; set; }
    }
}
