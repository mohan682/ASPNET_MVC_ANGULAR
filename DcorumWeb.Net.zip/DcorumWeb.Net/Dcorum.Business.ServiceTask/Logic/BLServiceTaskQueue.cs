﻿using Dcorum.Business.ServiceTask.DataAccess;
using Dcorum.Business.ServiceTask.Entities;
using Dcorum.BusinessLayer.Core;
using Dcorum.Utilities.Extensions;
using System;
using System.Linq;
using System.Collections.Generic;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Business.ServiceTask.Contractual;
using DCorum.ViewModelling.Contractual;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.Practices;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Diagnostics;
using Dcorum.BusinessLayer.Constants;
using Dcorum.Configuration.Contractual;

using ParentModelAlias = Dcorum.Business.ServiceTask.Entities.ServiceTask;
using UserAlias = Dcorum.BusinessLayer.Entities.DcorumUser;

namespace Dcorum.Business.ServiceTask.Logic
{
    [Category(DomainCodes.DCorumServiceTaskQueue)]
    public class BLServiceTaskQueue : BLPersistorTemplate<ServiceTaskQueue,int,int>
    {
        internal BLServiceTaskQueue(UserAlias user, IAuditingArgumentsReadOnly caller, DLServiceTaskQueue persistenceActor, DLServiceTask serviceTaskDataAccess, DLServiceTaskQueueSummary summaryDataAccess)
            :base(caller,persistenceActor)
        {
            //bool hasPermission = user.IsInGroup(GroupId.TaskQueueEditing) || user.IsInGroup(GroupId.TaskQueueViewing);
            //if (hasPermission == false) throw new System.Security.SecurityException("Specified user does not belong to an applicable security group!");

            myDataAccess = persistenceActor;
            myParentDataAccess = serviceTaskDataAccess;
            mySummaryDataAccess = summaryDataAccess;

            Debug.Assert(caller.UserId == user.Id);

            ForceEditModeTest();
            ReadOnlyModeOn = user.IsInGroup(GroupId.TaskQueueEditing) == false ;
        }

        /// <summary>
        /// debug only
        /// </summary>
        [Conditional("DEBUG")]
        protected void ForceEditModeTest()
        {
            if (Caller != null && Caller.UserId == 12345) ReadOnlyModeOn = false;
        }

        private const string UpdateCommand = "UPDATE";
        private const string CloneCommand = "CLONE";
        private const string RerunCommand = "RERUN";

        private readonly DLServiceTaskQueue myDataAccess = null;
        private readonly DLServiceTask myParentDataAccess = null;
        private readonly DLServiceTaskQueueSummary mySummaryDataAccess = null;
   
        private ParentModelAlias[] _allServiceTasks;

        #region for list controls
        private bool _fetched = false;
        private IKeyValuePair[] _serviceTaskKeyedDescriptions;
        #endregion

        public IDictionary<int,string> GetServiceTaskKeyedDescriptions()
        {
            _allServiceTasks = myParentDataAccess.SelectManyViaParentKey(0);
            var results = _allServiceTasks.OrderBy( _ => _.Id).ToDictionary(@item => @item.Id, @item => String.Format("[{2}:{0}] {1}", @item.BindingName, @item.Description, @item.Id));
            return results;
        }

        private static IDictionary<string, Func<object, object>> _customSearchConversionTechniques = new Dictionary<string, Func<object, object>>()
                {   {"ddlStatus"        , _ => ServiceTaskStatusHelp.IntoDBString( (ServiceTaskStatus?)_.ToString().IntoIntN())  }
                ,   {"ddlSearchPeriod"  , _ => RelativeDayHelp.IntoDBString((RelativeDay?)_.ToString().IntoIntN()) }
                };


        private static IDictionary<string, Predicate<ServiceTaskQueue>> _guardedCommandTexts = new Dictionary<string, Predicate<ServiceTaskQueue>>
        { { "Edit", _ => _.CanEdit }
        , { "Clone", _ => _.CanClone }
        , { "Rerun", _ => _.CanRerun }
        };


        private static IDictionary<string, Predicate<ServiceTaskQueue>> _guardedCommandNames = new Dictionary<string, Predicate<ServiceTaskQueue>>
        { { UpdateCommand, _ => _.CanEdit }
        , { CloneCommand, _ => _.CanClone }
        , { RerunCommand, _ => _.CanRerun }
        };


        public IDictionary<string, Func<object, object>> CustomSearchConversionTechniques
        {
            get
            {
                return _customSearchConversionTechniques.IntoDictionary();
            }
        }

        public IDictionary<string, string> GetMIServiceTaskQueueTotals(string theDay)
        {
            RelativeDay? parsed1 = theDay.IntoEnum<RelativeDay>(true);

            var parts = new[] {
                mySummaryDataAccess.GetMIServiceTaskQueueTotals(parsed1.Value).IntoTextualDictionary()
                , mySummaryDataAccess.GetTotals2(parsed1.Value)
            };

            var result = parts.SelectMany(_ => _ ).IntoDictionary();
            return result;
        }

        [Pure]
        private bool CanEdit(ServiceTaskQueue model)
        {
            bool result = model.Status == ServiceTaskStatus.PE && model.IsLocked == false;
            return result;
        }

        [Pure]
        private bool CanClone(ServiceTaskQueue model)
        {
            bool result = model.Status.HasValue && new[] { ServiceTaskStatus.ER, ServiceTaskStatus.CM }.Contains(model.Status.Value) ;
            return result;
        }

        [Pure]
        private bool CanRerun(ServiceTaskQueue model)
        {
            bool result = model.Status == ServiceTaskStatus.PE && model.IsLocked;
            return result;
        }

        [Pure]
        public string GetBestCommandTextFor(ServiceTaskQueue model)
        {
            if (ReadOnlyModeOn) return null;

            string result = _guardedCommandTexts.SingleOrDefault( _ => _.Value(model)).Key;
            return result;
        }

        [Pure]
        private string GetBestCommandNameFor(ServiceTaskQueue model)
        {
            if (ReadOnlyModeOn) return null;

            string result = _guardedCommandNames.SingleOrDefault(_ => _.Value(model)).Key;
            return result;
        }


        public ServiceTaskQueue GetEditableModelViaTextualKey(string textualId)
        {
            int? key1 = textualId.IntoIntN();
            var result = GetUnique(key1.Value);

            string candidateCommandName = GetBestCommandTextFor(result);

            if (new[] { CloneCommand, RerunCommand}.Contains(candidateCommandName.ToUpperInvariant()) )
            {
                result.ScheduledDateTime = DateTime.Now;
            }

            return result;
        }


        #region ......overrides......

        public override ServiceTaskQueue[] GetMany(int parentId = default(int), string augmentQueryWith = null)
        {
            return base.GetMany(parentId, augmentQueryWith);
        }


        public override void Hydrate(ServiceTaskQueue toHydrate)
        {
            base.Hydrate(toHydrate);

            if (_fetched == false)
            {
                _serviceTaskKeyedDescriptions = GetServiceTaskKeyedDescriptions().IntoKeyedDisplayables();

                _fetched = true;
            }

            toHydrate.CanEdit = ReadOnlyModeOn ==false && CanEdit(toHydrate) ;
            toHydrate.CanClone = ReadOnlyModeOn == false && CanClone(toHydrate) ;
            toHydrate.CanRerun = ReadOnlyModeOn == false && CanRerun(toHydrate) ;

            toHydrate.DeclareBusinessConstraint(1, typeof(ParentModelAlias), () => _serviceTaskKeyedDescriptions, @choice => toHydrate.ServiceTaskId = @choice.IntoValue<int>().Value, false);
        }

        public override IEnumerable<IOutcomeItem> Save(ServiceTaskQueue model)
        {
            //return base.Save(model);
            if (ReadOnlyModeOn)
            {
                RemarksVessel.IncludeCustomRemarks(new[] { "This is not permitted in read-only mode!" });
                return RemarksVessel.YieldAndPurgeAll();
            }

            Validate(model);

            if (RemarksVessel.IsEmpty)
            {
                string candidateCommandName = GetBestCommandNameFor(model);

                model.Action = GetBestCommandTextFor(model);

                switch (candidateCommandName.ToUpper())
                {
                    case UpdateCommand:
                        Persist(model, myDataAccess.@Update, false);
                        break;
                    case CloneCommand:
                        model.InitializeBeforeInsert();
                        Persist(model, myDataAccess.@Insert, false);
                        break;
                    case RerunCommand:
                        model.InitializeBeforeInsert();
                        Persist(model, myDataAccess.@UpdateAndInsert, false);
                        break;
                    default:
                        return new[] { new OutcomeItem(String.Format("{0} is not a recognised action or command!", (candidateCommandName ?? "UNSPECIFIED").ToUpper())) };
                }
            }

            return RemarksVessel.YieldAndPurgeAll();
        }


        protected override void Validate(ServiceTaskQueue model)
        {       
            base.Validate(model);

            if (model == null)
            {
                RemarksVessel.RemarkNoItemSpecified = true;
                return;
            }

            if (model.ScheduledDateTime == null) RemarksVessel.IncludeCustomRemarks(new[] { "A scheduled date is required!" });
            if (model.Status == null) RemarksVessel.IncludeCustomRemarks(new[] { "'Status' requires a value!" });
        }

        #endregion
    }
}
