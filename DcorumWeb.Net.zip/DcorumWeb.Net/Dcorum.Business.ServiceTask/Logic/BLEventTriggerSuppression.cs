﻿using Dcorum.Business.ServiceTask.Creational;
using Dcorum.Business.ServiceTask.DataAccess;
using Dcorum.BusinessCore.Helping;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Configuration.Contractual;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;

using ModelAlias = Dcorum.Business.ServiceTask.Entities.EventTriggerSuppression;

namespace Dcorum.Business.ServiceTask.Logic
{
    [Category(DomainCodes.DCorumEventTriggerSuppression)]
    public class BLEventTriggerSuppression : BLPersistorTemplate<ModelAlias, int, int>
    {
        internal BLEventTriggerSuppression(DcorumUser user, IAuditingArgumentsReadOnly caller, DLEventTriggerSuppression persistenceActor)
            :base(caller,persistenceActor)
        {
            //bool hasPermission = user.IsInGroup(GroupId.TriggerSuppressionEditing) || user.IsInGroup(GroupId.TriggerSuppressionViewing);
            //if (hasPermission == false) throw new System.Security.SecurityException("Specified user does not belong to an applicable security group!");

            myDataAccess = persistenceActor;

            Debug.Assert(caller.UserId == user.Id);

            ForceEditModeTest();
            ReadOnlyModeOn = false; //user.IsInGroup(GroupId.TriggerSuppressionEditing) == false;
        }

        /// <summary>
        /// debug only
        /// </summary>
        [Conditional("DEBUG")]
        protected void ForceEditModeTest()
        {
            if (Caller != null && Caller.UserId == 12345) ReadOnlyModeOn = false;
        }

        private readonly DLEventTriggerSuppression myDataAccess;

        private static IDictionary<string, Func<object, object>> _customSearchConversionTechniques = new Dictionary<string, Func<object, object>>()
                {   {"ddlSuppressionCode"        , _ => _.ToString()  }
                //,   {"ddlValue"  , _ => StringParser.IntoBoolean(_.ToString())==true ? 1 : 0 }
                ,   {"txtSchemeDesc"  , _ => CoreInjectedMechanics.ConvertSchemeDisplayNameToCaseKey(_.ToString()) }
                } ;


        public IDictionary<string, Func<object, object>> CustomSearchConversionTechniques
        {
            get
            {
                return _customSearchConversionTechniques.IntoDictionary();
            }
        }


        //public ModelAlias GetEditableModelViaAlternativeKey(string caseKey, string refcodevalue)
        //{
        //    ModelAlias identity = new ModelAlias()
        //    {
        //        CaseKey = caseKey.IntoIntN().Value,
        //        SuppressionCode = new BusinessLayer.BusinesObjects.RefCode(refcodevalue)
        //    };

        //    RefCodeHelp.DoBuildRefCodes(identity);

        //    ModelAlias result =  myDataAccess.SelectViaOtherIdentity(identity);
        //    return result;
        //}

        #region ......overrides......

        public override ModelAlias[] GetMany(int parentId = default(int), string augmentQueryWith = null)
        {
            return base.GetMany(parentId, augmentQueryWith);
        }


        public override void Hydrate(ModelAlias toHydrate)
        {
            base.Hydrate(toHydrate);

            toHydrate.CanEdit = (ReadOnlyModeOn == false && (toHydrate.Id > AmbientValue));
            toHydrate.CanDelete = (ReadOnlyModeOn == false && (toHydrate.Id > AmbientValue));
            toHydrate.CanInsert = (ReadOnlyModeOn == false && !(toHydrate.Id > AmbientValue));
        }


        public override IEnumerable<IOutcomeItem> Save(ModelAlias model)
        {
            return base.Save(model);
        }


        protected override void Validate(ModelAlias model)
        {
            base.Validate(model);
            if (!(model.CaseKey > 0)) RemarksVessel.IncludeCustomRemarks(new[] {String.Format("A valid scheme is required!")});
            if (model.SuppressionCode == null || model.SuppressionCode.RefCd == null) RemarksVessel.IncludeCustomRemarks(new[] { String.Format("A type code value is required!") });
        }

        #endregion
    }
}
