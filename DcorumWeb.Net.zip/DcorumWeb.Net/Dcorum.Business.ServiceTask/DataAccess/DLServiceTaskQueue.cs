﻿using Dcorum.Business.ServiceTask.Entities;
using Dcorum.Business.ServiceTask.Sql;
using Dcorum.Utilities.DataAccess;
using DCorum.DataAccessFoundation.DataAccess;
using System;

namespace Dcorum.Business.ServiceTask.DataAccess
{
    internal  class DLServiceTaskQueue : CrudActor<ServiceTaskQueue, int, int>
    {
        private readonly ServiceTaskQueueSql mySqlMaker = null;

        internal DLServiceTaskQueue(ServiceTaskQueueSql sqlCrudActor) 
            : base(@reader => new ServiceTaskQueue(@reader,ServiceTaskQueueSql.ColumnNames), sqlCrudActor)
        {
            mySqlMaker = sqlCrudActor ;
        }

        public int UpdateAndInsert(ServiceTaskQueue model)
        {
            Func<string> sqlToExecuteDeferred = () => mySqlMaker.UpdateAndInsertSql(model).IntoWellFormedSql();

            return DataAccessHelp.ExecuteDeferredNonQuery(db => PreInsert(model), @sqlToExecuteDeferred);
        }
    }
   
}
