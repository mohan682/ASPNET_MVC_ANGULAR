﻿using Dcorum.Business.ServiceTask.Contractual;
using Dcorum.Business.ServiceTask.Sql;
using Dcorum.Utilities;
using Dcorum.Utilities.Extensions;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Dcorum.Business.ServiceTask.DataAccess
{
    internal class DLServiceTaskQueueSummary
    {
        internal DLServiceTaskQueueSummary(ServiceTaskQueueSummarySql sqlCrudActor) 
        {
            DbProxy = new DataAccessContext();

            mySqlMaker = sqlCrudActor;
        }

        private readonly ServiceTaskQueueSummarySql mySqlMaker = null;
        private IDbProxy DbProxy { get; }


        public Dictionary<string, int> GetMIServiceTaskQueueTotals(RelativeDay theDay)
        {
            string sql1 = mySqlMaker.SelectTotals1(theDay) ;
            var just1 = DbProxy.GetMany(sql1, 
                @reader => Tuple.Create(@reader.FetchAsString("Key"), @reader.FetchAsValue<int>("Value")),
                () => new object[] { theDay }
                ) ;

            var miTotalsResult = just1.ToDictionary( _ => _.Item1, _ => _.Item2 );
            return miTotalsResult;
        }

        /// <summary>
        /// note: using LINQ Single internally to contractually enforce one and only one row of data.
        /// </summary>
        public IDictionary<string, string> GetTotals2(RelativeDay theDay)
        {
            var collection1 = DbProxy.GetMany(mySqlMaker.SelectTotals2(theDay), @dr => Projection2(@dr), () => new object[] { theDay });

            var result = collection1.Single();

            return result;
        }


        private IDictionary<string, string> Projection2(IDataReader dr)
        {
            var result = ReadRow2(dr).IntoDictionary();
            return result;
        }


        private IEnumerable<Tuple<string, string>> ReadRow2(IDataReader dr)
        {
            yield return Tuple.Create("Pending & locked this Period", dr.FetchAsValue<int>("TodayLockedPE").ToString());
            yield return Tuple.Create("Probably failed (over 2hrs old)", dr.FetchAsValue<int>("TodayLockedPEOver2HrsOld").ToString());
            yield return Tuple.Create("Pending in the past", dr.FetchAsValue<int>("PEQuantity").ToString());
            yield return Tuple.Create("Oldest pending item", dr.FetchAsValue<DateTime>("PEOldestScheduleDate").ToString());
        }
    }
}
