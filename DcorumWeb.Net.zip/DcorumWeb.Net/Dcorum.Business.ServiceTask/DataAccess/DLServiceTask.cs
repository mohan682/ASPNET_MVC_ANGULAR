﻿using Dcorum.Business.ServiceTask.Sql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Contractual;
using DCorum.DataAccessFoundation.DataAccess;

namespace Dcorum.Business.ServiceTask.DataAccess
{
    //Note: Aliases are used simply to make template simpler to copy and paste.
    using ModelAlias = Dcorum.Business.ServiceTask.Entities.ServiceTask;
    using ModelKey = Int32;
    using ModelParentKey = Int32;
    using SqlMakerAlias = Dcorum.Business.ServiceTask.Sql.ServiceTaskSql;

    internal class DLServiceTask : CrudActor<ModelAlias, ModelKey, ModelParentKey>
    {
        public DLServiceTask(SqlMakerAlias sqlMaker)
            : base(@reader => new ModelAlias(@reader, SqlMakerAlias.ColumnNames.ToArray()), sqlMaker)
        {
            _sqlMaker = sqlMaker;
        }

        private SqlMakerAlias _sqlMaker;
    }

}
