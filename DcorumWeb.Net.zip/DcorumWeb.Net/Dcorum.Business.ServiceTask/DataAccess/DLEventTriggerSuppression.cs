﻿using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.DataAccess;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Linq;

using ModelAlias = Dcorum.Business.ServiceTask.Entities.EventTriggerSuppression;
using ModelKey = System.Int32;
using ModelParentKey = System.Int32;
using SqlMakerAlias = Dcorum.Business.ServiceTask.Sql.EventTriggerSuppressionSql;


namespace Dcorum.Business.ServiceTask.DataAccess
{
    internal class DLEventTriggerSuppression : CrudActor<ModelAlias, ModelKey, ModelParentKey>,
        ICrudFull<ModelAlias, int>
    {
        public DLEventTriggerSuppression(SqlMakerAlias sqlMaker)
            : base(@reader => new ModelAlias(@reader, sqlMaker.ColumnNames.ToArray()), sqlMaker)
        {
            _sqlMaker = sqlMaker;
        }

        private SqlMakerAlias _sqlMaker;

        ///// <summary>
        ///// Note: identiy is a husk model with just the alternative key fields populated.
        ///// </summary>
        //public ModelAlias SelectViaOtherIdentity(ModelAlias identity)
        //{
        //    string finalSql1 = _sqlMaker.SelectViaOtherIdentity(identity).IntoWellFormedSql();
        //    return DataAccessHelp.GetSingle(finalSql1, @Make);
        //}
    }
}
