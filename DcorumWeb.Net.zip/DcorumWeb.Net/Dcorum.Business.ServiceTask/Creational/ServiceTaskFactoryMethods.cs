﻿using Dcorum.Business.ServiceTask.DataAccess;
using Dcorum.Business.ServiceTask.Logic;
using Dcorum.Business.ServiceTask.Sql;
using Dcorum.BusinessLayer.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.Business.ServiceTask.Creational
{
    public class ServiceTaskFactoryMethods
    {
        public static readonly ServiceTaskFactoryMethods Singleton = new ServiceTaskFactoryMethods();
        private ServiceTaskFactoryMethods() { }

        public BLServiceTaskQueue CreateServiceTaskQueueController(IAuditingArgumentsReadOnly caller)
        {
            var user1 = BusinessLayer.Logic.BLDcorumUser.Singleton.GetUserById(caller.UserId);

            var creation1 = new BLServiceTaskQueue(
                user1,
                caller,
                new DLServiceTaskQueue(new ServiceTaskQueueSql()),
                new DLServiceTask(new ServiceTaskSql()),
                new DLServiceTaskQueueSummary(new ServiceTaskQueueSummarySql())
                );

            return creation1;
        }

        public BLEventTriggerSuppression CreateEventTriggerSuppressionController(IAuditingArgumentsReadOnly caller)
        {
            var user1 = BusinessLayer.Logic.BLDcorumUser.Singleton.GetUserById(caller.UserId);

            var creation1 = new BLEventTriggerSuppression(
                user1,
                caller,
                new DLEventTriggerSuppression(new EventTriggerSuppressionSql(EventTriggerSuppressionSql.SqlSpec))
                );

            return creation1;
        }
    }
}
