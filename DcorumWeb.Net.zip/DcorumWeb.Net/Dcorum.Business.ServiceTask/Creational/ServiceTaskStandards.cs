﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.Business.ServiceTask.Creational
{
    internal static class ServiceTaskStandards
    {
        internal const string SuppressionDomainName = "EVENT TRIGGER SUPPRESSION";
    }
}
