﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Dcorum.Business.ServiceTask.Contractual
{
    public enum RelativeDay
    {
        [Description("previous day")]
        PreviousDay = 0,
        [Description("current day")]
        CurrentDay = 1,
        [Description("next day")]
        NextDay = 2
    }

    public static class RelativeDayHelp
    {
        private static Dictionary<RelativeDay, string> source1 = new Dictionary<RelativeDay, string>()
        { {RelativeDay.CurrentDay, "sysdate" }
        , {RelativeDay.NextDay, "sysdate+1" }
        , {RelativeDay.PreviousDay, "sysdate-1" }
        };

        public static string IntoDBString(this RelativeDay? toConvert)
        {
            var result = (toConvert == null) ? null : source1[toConvert.Value];
            return result;
        }
    }
}
