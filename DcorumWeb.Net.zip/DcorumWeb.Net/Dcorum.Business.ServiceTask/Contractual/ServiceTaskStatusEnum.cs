﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Dcorum.Business.ServiceTask.Contractual
{
    public enum ServiceTaskStatus
    {
        [Description("Completed")]
        CM, //Completed
        [Description("Pending")]
        PE, //Pending
        [Description("Error")]
        ER, //Error Encountered
        //[Description("Disaster Recovery")]
        //DR  //Disaster Recovery
    }

    public static class ServiceTaskStatusHelp
    {
        private static Dictionary<ServiceTaskStatus, string> source1 = new Dictionary<ServiceTaskStatus, string>()
        { {ServiceTaskStatus.CM, "CM" }
        , {ServiceTaskStatus.PE, "PE" }
        , {ServiceTaskStatus.ER, "ER" }
        };

        public static string IntoDBString(this ServiceTaskStatus? toConvert)
        {
            var result = (toConvert == null)? null : source1[toConvert.Value];
            return result;
        }
    }

}
