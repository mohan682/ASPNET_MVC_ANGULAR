﻿using Dcorum.Business.ServiceTask.Creational;
using Dcorum.Business.ServiceTask.Entities;
using Dcorum.Utilities.DataAccess;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Dcorum.Business.ServiceTask.Sql
{
    public class EventTriggerSuppressionSql : SimpleSqlFullCrud<EventTriggerSuppression, int, int>
    {
        internal EventTriggerSuppressionSql(ISqlSpecification<EventTriggerSuppression> injectedSqlSpec)
                : base(injectedSqlSpec, new SimpleSqlCrudTemplateBuilder(injectedSqlSpec, CustomSqlCrudTemplates.Singleton))
            {
        }

        private readonly static ReadOnlyCollection<string> NamesOfColumns = new ReadOnlyCollection<String>( new[] { "EVENT_TRIGGER_SUPPRESSION_ID", "TYPE_CD", "CASE_KEY" }.ToList());

        internal static readonly ISqlSpecification<EventTriggerSuppression> SqlSpec =
            new SqlSpecification<EventTriggerSuppression>
            {
                TableName = "EVENT_TRIGGER_SUPPRESSION",
                ColumnNames = NamesOfColumns.ToArray(),

                MyIdentityIndexes = new[] { new[] { 0 }, new[] { 1, 2 } },
                UpdatableIndexes = new int[] { 1 },

                ParentKeyIndex = null, //2,
                SqlSequenceName = "EVENT_TRIGGER_SUPPRESSION_SEQ",

                GettersForSql = new Func<EventTriggerSuppression, object>[]
                {
                            _ => _.Id,
                            _ => _.SuppressionCode.IntoSqlValue(),
                             _ => _.CaseKey,
                },

                //OrderByIndexes = new[] { 0 }
            };


        public IEnumerable<string> ColumnNames { get { return NamesOfColumns; } }

//        public IEnumerable<string> SelectViaOtherIdentity(EventTriggerSuppression identity)
//        {
//             string selectMissingOneTemplate = @"
//SELECT 
//    j1.REF_CD as TYPE_CD, from1.* 
//FROM
//    {0} from1
//RIGHT JOIN  ref_codes j1 
//ON j1.ref_cd = from1.TYPE_CD and CASE_KEY = {1}
//WHERE 
//    domain_name = {3}
//    and REF_CD = {2}
//    and DISABLE_CD=0
//";

//            string sql1 = String.Format( selectMissingOneTemplate
//                , SqlSpec.TableName
//                , identity.CaseKey
//                , identity.SuppressionCode.IntoSqlValue(),
//                ServiceTaskStandards.SuppressionDomainName.SqlQuotify()
//                );


//            yield return sql1;

//        }
    }


    internal class CustomSqlCrudTemplates : SqlCrudTemplates
    {
        internal static readonly CustomSqlCrudTemplates Singleton = new CustomSqlCrudTemplates();

        private CustomSqlCrudTemplates()
        {
            string simpleSelectManyTemplate = @"
SELECT 
    j1.REF_CD as TYPE_CD, from1.* 
FROM
    {0} from1
LEFT JOIN  ref_codes j1 
ON j1.ref_cd = from1.TYPE_CD and {1}

WHERE domain_name = {2} and DISABLE_CD=0

{3}

ORDER BY from1.CASE_KEY, j1.LINE_NO asc
";
            SimpleSelectManyTemplate = String.Format(simpleSelectManyTemplate, "{0}", "{1}", ServiceTaskStandards.SuppressionDomainName.SqlQuotify(), "{4}");

        }
    }
}
