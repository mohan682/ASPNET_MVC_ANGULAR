﻿using Dcorum.Business.ServiceTask.Contractual;
using Dcorum.Utilities.DataAccess;
using System;

namespace Dcorum.Business.ServiceTask.Sql
{
    internal class ServiceTaskQueueSummarySql
    {
        public string SelectTotals1(RelativeDay arg1)
        {
            string template1 = @"select
                case when STATUS_CD is null then 'Period Total'
                when STATUS_CD = 'CM' then 'Completed this Period'
                when STATUS_CD = 'ER' then 'Errored this Period'
                when STATUS_CD = 'PE' then 'Pending this Period'
                end Key,
                count(1) Value
                from uext.service_task_queue
                where SCHEDULE_DATE between trunc({0}) and trunc({0}+1)
                group by rollup(STATUS_CD)
                order by status_cd desc    
";

            string textualArg1 = RelativeDayHelp.IntoDBString(arg1);

            string sql1 = String.Format(template1, textualArg1);
            return sql1 ;
        }

        public string SelectTotals2(RelativeDay arg1, DateTime? date = null)
        {
            string sql1 = @"
select
    sum(
    CASE WHEN (f1.locked= 1 and (trunc(f1.SCHEDULE_DATE) = trunc({2}))) THEN 1  ELSE 0 END 
    ) TodayLockedPE,
    sum(
    CASE WHEN (f1.locked= 1 and (trunc(f1.SCHEDULE_DATE) = trunc(sysdate)) and f1.SCHEDULE_DATE <= (sysdate)-(120/1440)) THEN 1  ELSE 0 END 
    ) TodayLockedPEOver2HrsOld,
    sum(1) PEQuantity,
    min(f1.SCHEDULE_DATE) PEOldestScheduleDate

from
  uext.service_task_queue f1
where
  SCHEDULE_DATE <= {0} and f1.STATUS_CD = {1}    
";
            string textualArg2 = RelativeDayHelp.IntoDBString(arg1);
            string textualDateArg0 = (date.HasValue) ? date.ToSqlShortDateString() : "sysdate";
            string result = String.Format(sql1, textualDateArg0, "PE".SqlQuotify(), textualArg2);

            return result;
        }
    }
}
