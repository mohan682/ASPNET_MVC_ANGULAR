﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.Business.ServiceTask.Sql
{
    using DCorum.BusinessFoundation.Contractual;
    //Note: Aliases are used simply to make template simpler to copy and paste.
    using ModelAlias = Dcorum.Business.ServiceTask.Entities.ServiceTask;
    using ModelKey = Int32;
    using ModelParentKey = Int32;

    internal class ServiceTaskSql : ISqlOpenFullCrud<ModelAlias, ModelKey, ModelParentKey>
    {
        //public static IEnumerable<string> ColumnNames
        //{
        //    get { throw new NotImplementedException(); }
        //}

        public static readonly IList<string> ColumnNames = Array.AsReadOnly(new[] {
                "SERVICE_TASK_ID",
                "BINDING_NAME",
                "DESCRIPTION",
                "ACTIVE",
        });

        public IEnumerable<string> DeleteSql(ModelAlias toDelete)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> InsertSql(ModelAlias toInsert)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> UpdateSql(ModelAlias toUpdate)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> SelectOneSql(ModelKey primaryKey)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> SelectManySql(ModelParentKey parentKey = 0, string appendWhereClauseWith = null)
        {
            string sql1 = @"
Select * from service_task
";
            yield return sql1;
        }

        public string SelectDuplicatesSql(ModelAlias similar)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Opportunity to yield any relevant select statements to detect child or associate table rows that would prevent table row deletion.
        /// </summary>
        public IEnumerable<string> DetectAnyDependants(ModelAlias ofInterest)
        {
            throw new NotImplementedException();
        }

        public string GetSequenceIdForInsert()
        {
            throw new NotImplementedException();
        }
    }

}
