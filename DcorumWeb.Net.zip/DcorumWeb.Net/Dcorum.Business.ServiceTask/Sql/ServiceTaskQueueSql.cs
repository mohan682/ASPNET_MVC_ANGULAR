﻿using Dcorum.Business.ServiceTask.Contractual;
using Dcorum.Business.ServiceTask.Entities;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;

namespace Dcorum.Business.ServiceTask.Sql
{
    internal class ServiceTaskQueueSql : ISqlOpenFullCrud<ServiceTaskQueue, int, int>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal ServiceTaskQueueSql()
        {
        }


        public static readonly IList<string> ColumnNames =
            Array.AsReadOnly(new[] {
                "SERVICE_TASK_QUEUE_ID",
                "SCHEDULE_DATE",
                "PROCESS_DATE",
                "LOCKED",
                "THREAD_NO",
                "ACTIVE",
                "STATUS_CD",
                "SERVICE_TASK_ID"
            });

        private const string TableName = "SERVICE_TASK_QUEUE";


        public IEnumerable<string> DetectAnyDependants(ServiceTaskQueue ofInterest)
        {
            yield break;
        }


        public IEnumerable<string> DeleteSql(ServiceTaskQueue toDelete)
        {
            throw new NotImplementedException();
        }


        public IEnumerable<string> UpdateAndInsertSql(ServiceTaskQueue model)
        {
            foreach (var current1 in InsertSql(model))
            {
                yield return current1;
            }

            const string sqlTemplate1 = @"
UPDATE {0} 
    SET STATUS_CD = 'ER'
    WHERE SERVICE_TASK_QUEUE_ID = {1}
";
            string sql1 = String.Format(sqlTemplate1, TableName, model.OriginalId);
            yield return sql1;

        }


        public IEnumerable<string> InsertSql(ServiceTaskQueue toInsert)
        {
            const string sqlTemplate1 = @"
INSERT INTO {0} (
    SERVICE_TASK_QUEUE_ID,
    SCHEDULE_DATE,
    PROCESS_DATE,
    LOCKED,
    THREAD_NO,
    ACTIVE,
    STATUS_CD,
    SERVICE_TASK_ID
    )  
    VALUES (
        {1},{2},{3},{4},{5},{6},{7},{8}
        )
";

            string sql1 = String.Format(sqlTemplate1, TableName,
                toInsert.Id,
                toInsert.ScheduledDateTime.ToSqlDateTimeString(),
                toInsert.ProcessedDate.ToSqlDateTimeString(),
                toInsert.IsLocked.IntoSqlBool(),
                toInsert.ThreadNumber,
                toInsert.IsActive.IntoSqlBool(),
                ServiceTaskStatusHelp.IntoDBString(toInsert.Status).SqlQuotify(),
                toInsert.ServiceTaskId
                );

            yield return sql1;



            const string sqlTemplate2 = @"
INSERT INTO service_task_queue_param (
    SERVICE_TASK_QUEUE_ID, PARAM_NAME, PARAM_VALUE, PARAM_ORDER, PARAM_TYPE)
SELECT {0}, f1.PARAM_NAME, f1.PARAM_VALUE, f1.PARAM_ORDER, f1.PARAM_TYPE
    FROM service_task_queue_param f1
WHERE
    f1.SERVICE_TASK_QUEUE_ID = {1}
";
            string sql2 = String.Format(sqlTemplate2, toInsert.Id, toInsert.OriginalId);
            yield return sql2;
        }


        public IEnumerable<string> UpdateSql(ServiceTaskQueue toUpdate)
        {
            const string sqlTemplate = @"
UPDATE {0} 
    SET SCHEDULE_DATE={2}
    WHERE SERVICE_TASK_QUEUE_ID = {1}
";
            string sql1 = String.Format(sqlTemplate, TableName, toUpdate.Id, toUpdate.ScheduledDateTime.ToSqlDateTimeString());
            yield return sql1;
        }


        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            const string select1 = @"
SELECT
    from1.*,  (select count(*) from SERVICE_TASK_QUEUE_PARAM where SERVICE_TASK_QUEUE_ID = from1.SERVICE_TASK_QUEUE_ID) paramCount
FROM {0} from1
WHERE 
    SERVICE_TASK_QUEUE_ID = {1}
";

            string sql1 = String.Format(select1, TableName, primaryKey);
            yield return sql1;
        }


        public IEnumerable<string> SelectManySql(int parentKey = 0, string appendWhereClauseWith = null)
        {
            const string SelectTemplate1 = @"
SELECT
    from1.*, (select count(*) from SERVICE_TASK_QUEUE_PARAM where SERVICE_TASK_QUEUE_ID = from1.SERVICE_TASK_QUEUE_ID) paramCount
FROM {0} from1

WHERE 1=1
    {1}
Order by from1.SCHEDULE_DATE desc
";
            string sql1 = String.Format(SelectTemplate1, TableName, appendWhereClauseWith);
            yield return sql1;
        }


        public string SelectDuplicatesSql(ServiceTaskQueue similar)
        {
            string sql1 = string.Empty;// String.Format(SelectTemplate1 + Clause3, similar.CaseKey, similar.ExternalRoleCode.IntoSqlValue());
            return sql1;
        }

        public string GetSequenceIdForInsert()
        {
            return "SERVICE_TASK_QUEUE_ID_SEQ";
        }

    } 
}
