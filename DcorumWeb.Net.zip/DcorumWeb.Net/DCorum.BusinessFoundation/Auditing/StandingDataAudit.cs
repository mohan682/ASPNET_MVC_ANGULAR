﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using DCorum.BusinessFoundation.Auditing.Constants;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.Entities
{
    public class StandingDataAudit
    {
        internal protected StandingDataAudit() {}

        [Key]
        [UIHint("lblId")]
        public int DataAuditId { get; set; }

        public int UserId { get; set; }

        public string AuditIdentifier { get; set; }

        [RefCodeConstraint(AuditingDomainNames.DataAuditIdentifierTypes)]
        public RefCode IdentifierType { get; set; }

        [UIHint("lblAuditDateTime")]
        public string ActionDateTime { get; set; }

        [UIHint("lblScreenName")]
        [UIHint("ddlComponent", "search")]
        [RefCodeConstraint(AuditingDomainNames.SWApplicationComponent)]
        public RefCode AuditComponent { get; set; }

        [UIHint("ddlOperationType", "search")]
        [UIHint("lblOperationType")]
        [RefCodeConstraint(AuditingDomainNames.PDIScreenOperations)]
        public RefCode OperationType { get; set; }

        [UIHint("lblOldValue")]
        public string ExistingValue   { get; set; }

        [UIHint("lblNewValue")]
        public string NewValue   { get; set; }

        [RefCodeConstraint(AuditingDomainNames.ESSCApplicationNames)]
        public RefCode SourceSystem { get; set; }

        //[UIHint("lblAssociationDesc")]
        //public string AuditIdentifierDesc { get; set; }

        //[UIHint("lblModifiedBy")]
        //public string AuditUserName { get; set; }

        //public string SearchFilterStartDate { get; set; }
        //public string SearchFilterEndDate { get; set; }
    }
}
