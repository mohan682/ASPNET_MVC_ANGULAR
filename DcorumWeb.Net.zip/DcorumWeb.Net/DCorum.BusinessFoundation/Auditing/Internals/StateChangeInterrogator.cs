﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Auditing;
using DCorum.BusinessFoundation.Auditing.Internals;
using DcorumWeb.Utilities;
using System.Collections;
using Dcorum.Utilities.Idioms;

namespace Dcorum.Utilities.Auditing
{
    internal class StateChangeInterrogator
    {
        private readonly AuditTypeMap _injectedAssociate1 ;

        private readonly Func<Type, PropertyInfo[]> _sourcePropertyInfos;
        private readonly Action<AuditableFinding> _sinkAuditableFinding;
        private readonly int? _maxDepth;

        private List<AuditableFinding> MyAuditableFindings { get; set; }


        public StateChangeInterrogator(AuditTypeMap associate1, int? maxDepth)
        {
            _injectedAssociate1 = associate1;
            MyAuditableFindings = new List<AuditableFinding>();

            _sourcePropertyInfos = _injectedAssociate1.@GetPropertyInfos;
            _sinkAuditableFinding = MyAuditableFindings.@Add ;

            _maxDepth = maxDepth;
        }


        internal InterrogationResult Interrogate<T>(T currentObject, T existingObject)
            where T: class
        {
            //check for obvious problems...
            if (currentObject == null && existingObject == null)
                throw new ArgumentNullException( nameof(currentObject), typeof(T)?.Name ) ;

            if (ReferenceEquals(currentObject, existingObject)) throw new ArgumentException("Must differ!");

            MyAuditableFindings.Clear(); //part of JIRA 8798

            Type auditeeType = (currentObject ?? existingObject).GetType();
            auditeeType = _injectedAssociate1.GetAuditableType(auditeeType) ?? auditeeType ;

            if (auditeeType == null) throw
                  new ArgumentNullException( nameof(auditeeType), typeof(T)?.Name ) ;
                             
            string objectTypeName = (auditeeType.GetFirstAttribute<DescriptionAttribute>().SafeFunc( _ => _.Description) ?? auditeeType.Name).ToUpperInvariant();


            //main activity...
            CompareCore(typeof(T), currentObject, existingObject, objectTypeName, 0);

            var result = new InterrogationResult
            {
                KindOfOperation = HelperMethods.GetTextualOperation(currentObject, existingObject),
                OriginalValues = FormatEachBeforeFinding(MyAuditableFindings),
                CurrentValues =  FormatEachAfterFinding(MyAuditableFindings)
            };

            return result;
        }

        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual List<string> FormatEachBeforeFinding(IEnumerable<AuditableFinding> source)         
        {
            var results = new List<string>();
            bool notEmpty = HelperMethods.FormatEachAuditFinding(source, _ => _.OriginalValue, _ => _.HadMissingOwnerBefore, results.@Add);

            if (notEmpty == false) results.Clear();

            return results;
        }

        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual List<string> FormatEachAfterFinding(IEnumerable<AuditableFinding> source)
        {
            var results = new List<string>();
            bool notEmpty = HelperMethods.FormatEachAuditFinding(source, _ => _.CurrentValue, _ => _.IsMissingOwnerNow, results.@Add);

            if (notEmpty == false) results.Clear();

            return results;
        }

        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual bool CanAuditCompositeImmediately(Type activeType)
        {
            bool isGenericCandidate = activeType.IsGenericType && new[] { typeof(KeyValuePair<,>), typeof(Tuple<,>) }.Contains( activeType.GetGenericTypeDefinition());

            bool success = isGenericCandidate && activeType.GenericTypeArguments.All( _ => CanAuditImmediately( _ )) ;

            return success;
        }

        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual bool CanAuditImmediately(Type ofItem)
        {
            return (ofItem.IsValueType || ofItem == typeof(string) || ofItem == typeof(object)) ;
        }

        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual PropertyInfo[] SourceManyPropertyInfo(Type ofItem)
        {
            return _sourcePropertyInfos(ofItem);
        }

        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual void SinkSingleFinding(AuditableFinding toConsume)
        {
            _sinkAuditableFinding(toConsume);
        }

        ///// <summary>
        ///// [POLYMORPHIC]
        ///// </summary>
        //protected virtual bool IsAuditable(AuditableFinding auditRec)
        //{
        //    return auditRec.CurrentValue != auditRec.OriginalValue && !(String.IsNullOrEmpty(auditRec.CurrentValue) && String.IsNullOrEmpty(auditRec.OriginalValue));
        //}


        /// <summary>
        /// [TEMPLATE_METHOD,RECURSIVE]
        /// </summary>
        private void CompareCore(Type activeType, object currentObject, object existingObject, string parentObjectName, int depth)
        {
            if (currentObject == null && existingObject == null) return ;
            if (_maxDepth.HasValue && depth > _maxDepth) return;

            //sanity check!
            if (currentObject != null && !activeType.IsInstanceOfType(currentObject)) throw new ArgumentException(String.Format("{0} is not assignable to {1}",currentObject.GetType(),activeType),"currentObject");
            if (existingObject != null && !activeType.IsInstanceOfType(existingObject)) throw new ArgumentException(String.Format("{0} is not assignable to {1}", existingObject.GetType(), activeType), "existingObject");



            bool collectionModeOn = (existingObject is IEnumerable) || (currentObject is IEnumerable);
            if (collectionModeOn)
            {
                IEnumerable<object> exMany = ((existingObject as IEnumerable) ?? Enumerable.Empty<object>()).Cast<object>();
                IEnumerable<object> cuMany = ((currentObject as IEnumerable) ?? Enumerable.Empty<object>()).Cast<object>();
           
                var pairs = cuMany.ZipWithDefault(exMany, (@a, @b) => Tuple.Create( @a, @b)).ToArray();
                int index = 0;
                foreach (var current1 in pairs)
                {
                    string propertyName = parentObjectName;
                    if (propertyName.EndsWith("[]"))
                        propertyName = propertyName.Substring(0, propertyName.Length - 1) + index + "]";
                    else
                        propertyName = propertyName + index;

                    Type enumerableItemType = (current1.Item1 ?? current1.Item2)?.GetType();

                    CompareCore(activeType.GetElementType() ?? enumerableItemType, current1.Item1, current1.Item2, propertyName, depth + 1);

                    index++;
                }
            }
            else if(CanAuditCompositeImmediately(activeType))
            {
                AuditableFinding auditRec = new AuditableFinding
                {
                    MemberName = parentObjectName,
                    CurrentValue = currentObject?.ToString(),
                    OriginalValue = existingObject?.ToString()
                };

                if (!auditRec.CurrentValue.IsEqualOrAlsoNullOrEmpty(auditRec.OriginalValue))
                {
                    SinkSingleFinding(auditRec);
                }
            }
            else
            {
                if (depth <= 0)
                {
                    AuditableFinding auditRec2 = new AuditableFinding
                    {
                        MemberName = parentObjectName,
                        CurrentValue = currentObject.GetTextualIdentity(),
                        OriginalValue = existingObject.GetTextualIdentity()
                    };

                    SinkSingleFinding(auditRec2);
                }

                var propertiesOfInterest = SourceManyPropertyInfo(activeType);

                foreach (var property in propertiesOfInterest)
                {
                    string propertyDisplayName = (depth <= 0)
                        ? property.Name
                        : parentObjectName + "." + property.Name;

                    Type propType = property.PropertyType;

                    object newChildObj = currentObject.SafeFunc( obj => property?.GetValue(obj, null)) ;  
                    object oldChildObj = existingObject.SafeFunc( obj => property?.GetValue(existingObject, null));

                    if (CanAuditImmediately(propType))
                    {
                        AuditableFinding auditRec = new AuditableFinding
                        {
                            MemberName = propertyDisplayName,
                            CurrentValue = newChildObj?.ToString(),
                            IsMissingOwnerNow = currentObject==null,
                            OriginalValue = oldChildObj?.ToString(),
                            HadMissingOwnerBefore = existingObject==null         
                        };

                        if (!auditRec.CurrentValue.IsEqualOrAlsoNullOrEmpty(auditRec.OriginalValue))
                        {
                            SinkSingleFinding(auditRec);
                        }
                    }
                    else
                    {
                        CompareCore(propType, newChildObj, oldChildObj, propertyDisplayName, depth + 1);
                    }
                }
            }
        }
    }
}
