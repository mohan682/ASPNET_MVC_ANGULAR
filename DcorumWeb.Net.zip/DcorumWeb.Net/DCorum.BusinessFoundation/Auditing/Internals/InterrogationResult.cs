﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace DCorum.BusinessFoundation.Auditing.Internals
{
    internal class InterrogationResult
    {
        public IList<string> OriginalValues { get; set; }
        public IList<string> CurrentValues { get; set; }
        public char KindOfOperation { get; set; }

        [Pure]
        public bool AuditRequired()
        {
            bool areBothNull = CurrentValues == null || OriginalValues == null;
            if (areBothNull) return false;

            bool isEmpty = !CurrentValues.Any() && !OriginalValues.Any();
            if (isEmpty) return false;
            /*
            string firstCurrent = CurrentValues[0];
            string firstOriginal = CurrentValues[0];

            bool sameIdentity = String.Equals(firstCurrent, firstOriginal);
            if (!sameIdentity) return true;

            bool bothOnlyOneRow = !CurrentValues.Take(1).Any() && !OriginalValues.Take(1).Any();
            if (bothOnlyOneRow && sameIdentity) return false; //an update with no changed values was detected!
            */
            return true;
        }
    }
}
