﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using DCorum.BusinessFoundation.Auditing.Constants.Internals;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;

namespace DCorum.BusinessFoundation.Auditing.Internals
{
    /// <summary>
    /// [STATELESS]
    /// </summary>
    internal static class HelperMethods
    {
        [Pure]
        public static bool FormatEachAuditFinding(IEnumerable<AuditableFinding> source,
            Func<AuditableFinding, string> howToQueryFinding, Func<AuditableFinding, bool> IsMissingOwnerTechnique,  Action<string> afterEachTechnique)
        {
            bool isVal = false;

            foreach (var v in source)
            {
                string queriedValue = howToQueryFinding(v);

                if (IsMissingOwnerTechnique(v) && queriedValue==null) continue;

                isVal |= (queriedValue != null);

                var toAdd = string.Format("[{0}] : [{1}]", v.MemberName, queriedValue) ;

                afterEachTechnique(toAdd);
            }

            return isVal;
        }

        [Pure]
        public static char GetTextualOperation<T2>(T2 currentObject, T2 existingObject)
            where T2 : class
        {
            char operationType;

            if (currentObject != null && existingObject != null)
                operationType = OperationTypeConstants.Update;
            else if (currentObject != null)
                operationType = OperationTypeConstants.Insert;
            else if (existingObject != null)
                operationType = OperationTypeConstants.Delete;
            else //both null
                operationType = OperationTypeConstants.Query;

            return operationType;
        }

        /// <summary>
        /// [SAFE]
        /// </summary>
        [Pure]
        public static PropertyInfo[] GetPropertyInfos(this AuditTypeMap mappings, Type ofInterest)
        {
            //const BindingFlags bindingFlags1 = BindingFlags.Instance | BindingFlags.GetProperty | BindingFlags.Public ;

            if (ofInterest == null) return null;

            Type auditableType = mappings?.GetAuditableType(ofInterest) ?? ofInterest;

            var candidates = auditableType.SelectManyMemberInfo(_ => _.GetProperties()).Where( _ =>
                       _.GetCustomAttributes(typeof(IgnoreDataMemberAttribute), false).Length == 0 &&
                       _.GetIndexParameters().GetLength(0) == 0
                       ) ;

            PropertyInfo[] ignorables = mappings?.GetIgnorableProperties(auditableType) ;

            var result = candidates.Except(ignorables).ToArray() ;

            return result;
        }
    }
}
