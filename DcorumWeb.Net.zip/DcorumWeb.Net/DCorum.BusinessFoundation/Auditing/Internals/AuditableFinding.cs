﻿using System;

namespace DCorum.BusinessFoundation.Auditing.Internals
{
    internal struct AuditableFinding
    {
        public string MemberName;

        public string CurrentValue;
        public bool IsMissingOwnerNow;

        public string OriginalValue;
        public bool HadMissingOwnerBefore ;
    }
}
