﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.Contractual;

namespace DCorum.BusinessFoundation.Auditing.Constants
{
    [RefCodeConstraint("DATA_AUDIT_IDENTIFIER_TYPES")]
    public static class AuditingDomainCodes
    {
        public const string DataAuditIdentifierTypeScheme = "SC";
        public const string DataAuditIdentifierTypeMbrGrp = "MG";
        public const string DataAuditIdentifierTypeMbr = "ME";
        public const string DataAuditIdentifierTypeTableSeqId = "TS";
    }
}
