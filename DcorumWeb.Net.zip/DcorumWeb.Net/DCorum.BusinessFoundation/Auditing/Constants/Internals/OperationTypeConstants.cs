﻿namespace DCorum.BusinessFoundation.Auditing.Constants.Internals
{
    internal class OperationTypeConstants
    {
        public const char Query = 'Q';
        public const char Insert = 'I';
        public const char Update = 'U';
        public const char Delete = 'D';
    }
}
