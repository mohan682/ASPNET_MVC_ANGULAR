﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.BusinessFoundation.Auditing.Constants
{
    public static class AuditingDomainNames
    {
        public const string DataAuditIdentifierTypes = "DATA_AUDIT_IDENTIFIER_TYPES";
        public const string PDIScreenOperations = "PDI_SCREEN_OPRN_TYPES";
        public const string ESSCApplicationNames = "ESSC_APP_NAMES";
        public const string SWApplicationComponent = "SW_APP_COMPONENTS";
    }
}
