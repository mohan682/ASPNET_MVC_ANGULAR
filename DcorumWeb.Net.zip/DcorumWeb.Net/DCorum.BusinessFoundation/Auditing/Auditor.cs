﻿using System;
using System.Diagnostics;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Entities;
using Dcorum.RefCoding;
using System.Collections;
using System.Collections.Generic;

namespace DCorum.BusinessFoundation.Auditing
{
    public class Auditor : IAuditor
    {
        public Auditor(IRemarksActor remarksVessel, StandingDataAuditCreator creator, string componentName,
            Func<StandingDataAudit, int> howToRecordAudit
            )
        {
            _creator1 = creator;
            _componentName = componentName;
            _howToRecordAudit = howToRecordAudit;
            _remarksVessel = remarksVessel;

            if (_howToRecordAudit == null) throw new ArgumentNullException(nameof(howToRecordAudit));
            if (_creator1 == null) throw new ArgumentNullException(nameof(creator));
        }

        private StandingDataAuditCreator _creator1;
        private Func<StandingDataAudit, int> _howToRecordAudit;
        private readonly string _componentName;
        private IRemarksActor _remarksVessel;

        /// <summary>
        /// Main Behaviour
        /// </summary>
        public void PersistThenAudit<T,TKey>(T injectedModel, Func<T,int> nonQueryAction, Func<TKey,T> getModel, Func<T,TKey> getKey, Func<T,int?, bool> beforeAuditAction, bool deletionModeOn, string extraComment, TKey ambientValue = default(TKey))
            where T : class
        {
            if (injectedModel == null) return ;


            TKey injectedKeyWas = getKey(injectedModel);

            T modelBefore = (Equals(ambientValue,injectedKeyWas)) ? null : getModel(injectedKeyWas) ;

            int rowsAffected = nonQueryAction(injectedModel);
            Debug.WriteLine($"INFO: {rowsAffected} rows affected whilst persisting changes.");

            TKey injectedKeyNow = getKey(injectedModel);

            //has the primary key changed and this wasn't an insert?
            if (rowsAffected > 0 && modelBefore != null && !(Equals(injectedKeyWas,injectedKeyNow)))
            {
                if (!deletionModeOn)
                {
                    T originalModelNow = getModel(injectedKeyWas);

                    //have we just done both an update followed by an insert?                  
                    //audit the update before the insert gets audited...
                    AuditChanges(true, originalModelNow, modelBefore, null);
 
                    if (getModel(injectedKeyNow) != null) //assume last part was an insert
                    {
                        modelBefore = null;
                    }
                    else //assume last part was a delete
                    {
                        deletionModeOn = true;
                        modelBefore = injectedModel;
                    }                 
                }
            }

            T lastestModel = (deletionModeOn) ? null : injectedModel;

            bool good = beforeAuditAction(lastestModel, rowsAffected);

            AuditChanges(good, lastestModel, modelBefore, extraComment);
        }
    
        /// <summary>
        /// Audit Changes plus remark when either database or auditing fails.
        /// </summary>
        public void AuditChanges<T>(bool success, T current1, T existing1, string extraComment)
            where T : class
        {
            if (!success)
                _remarksVessel.DbOperationError = true;
            else if (!AuditChanges(current1, existing1, extraComment))
            {
                _remarksVessel.AuditFailure = true;
            }
        }

        /// <summary>
        /// Innermost behaviour
        /// </summary>
        public bool AuditChanges<T>(T newValues, T oldValues, string extraCommment)
            where T : class
        {          
            RefCodeHelp.DoBuildRefCodes(newValues, true);

            StandingDataAudit creation1 = _creator1.Make(_componentName, newValues, oldValues, extraCommment);

            RefCodeHelp.DoBuildRefCodes(creation1, true);

            if (creation1 == null) return false;

            int affectedTotal = _howToRecordAudit(creation1);
            bool success = affectedTotal > 0;

            return success;
        }

        public IEnumerable<IOutcomeItem> YieldAndPurgeAllRemarks()
        {
            return _remarksVessel.YieldAndPurgeAll();
        }
    }
}
