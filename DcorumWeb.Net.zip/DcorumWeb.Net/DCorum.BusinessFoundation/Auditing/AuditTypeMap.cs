﻿using Dcorum.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;

namespace DCorum.BusinessFoundation.Auditing
{
    /// <summary>
    /// A repository if class types that should be audited using a different identity (usually a base class)
    /// </summary>
    public sealed class AuditTypeMap
    {
        #region ......singleton plumbing......
        private static AuditTypeMap _singleton = new AuditTypeMap();
        public static AuditTypeMap Singleton { get { return _singleton; }}

        private AuditTypeMap() { }
        #endregion

        private Dictionary<Type, Type> _dict1 = new Dictionary<Type, Type>();
        private Dictionary<Type, List<PropertyInfo>> TypeKeyedIgnorableProperyInfos = new Dictionary<Type, List<PropertyInfo>>();
     
        /// <summary>
        /// Suggest to the auditor that any object of type 'objectType' is instead treated as an alternative suitable type.
        /// </summary>
        public bool TryAdd(Type objectType, Type auditableType)
        {
            if (_dict1.ContainsKey(objectType)) return false;

            _dict1.Add(objectType, auditableType);

            return true;
        }

        public bool TryGet(Type objectType, out Type auditableType)
        {
            bool success = _dict1.TryGetValue(objectType, out auditableType);
            return success;
        }


        public Type GetAuditableType(Type objectType)
        {
            Type result;
            bool success = TryGet(objectType, out result);

            if (!success) return null;
            return result;
        }


        /// <summary>
        /// For auditable type 'T' declare properties that shouldn't be included when auditing objects of that type.
        /// </summary>
        public bool DeclareIgnorablesFor<T>(params Expression<Func<T,object>>[] ignorables)
        {
            var dict1 = TypeKeyedIgnorableProperyInfos ;

            Type objectType = typeof(T) ;

            if (dict1.ContainsKey(objectType)) return false;

            List<PropertyInfo> toAdd = ignorables.Select(_ => _.IntoPropertyInfo()).ToList() ;

            dict1.Add(objectType, toAdd);

            return true;
        }


        public PropertyInfo[] GetIgnorableProperties(Type objectType)
        {
            var dict1 = TypeKeyedIgnorableProperyInfos;

            List<PropertyInfo> out1;

            bool success1 = dict1.TryGetValue(objectType, out out1);
            
            return (out1 ?? Enumerable.Empty<PropertyInfo>()).ToArray() ;
        }

    }
}
