﻿using System;
using System.Diagnostics;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Utilities.Auditing;
using Dcorum.Utilities.Practices;
using DcorumWeb.Utilities;

namespace DCorum.BusinessFoundation.Auditing
{
    public class StandingDataAuditCreator
    {
        /// <summary>
        /// [CONFIG]
        /// </summary>
        public static string EsscApplicationName { private get; set; }

        /// <summary>
        /// [CONFIG]
        /// </summary>
        public static Func<object, Tuple<RefCode, string>> DefaultHowToGetCustomIdentity { private get; set; }


        private static readonly AuditTypeMap _ourAuditTypeMap = AuditTypeMap.Singleton;

        private readonly Func<object, Tuple<RefCode, string>> _howToGetCustomIdentity;
        private readonly int _userId;
        private readonly StateChangeInterrogator _myStateChangeInterrogator ;


        public StandingDataAuditCreator(int userId, int maxDepth, Func<object, Tuple<RefCode, string>> howToGetCustomIdentity = null )
        {
            _myStateChangeInterrogator = new StateChangeInterrogator(_ourAuditTypeMap, maxDepth);

            _howToGetCustomIdentity = howToGetCustomIdentity ?? DefaultHowToGetCustomIdentity;
            Debug.Assert(_howToGetCustomIdentity != null);
            _userId = userId;
        }


        protected virtual Tuple<RefCode, string> GetCustomIdentity(object source)
        {
            return source.SafeFunc(_howToGetCustomIdentity);
        }


        /// <summary>
        /// [TEMPLATE_METHOD] Creates an audit record.
        /// </summary>
        public StandingDataAudit Make<T>(string componentName, T newValues, T oldValues, string extraCommment = null)
            where T : class
        {   
            var interrogationResult = _myStateChangeInterrogator.Interrogate(newValues, oldValues);

            if (!interrogationResult.AuditRequired()) return null; //EARLY EXIT


            T baseRec = (newValues ?? oldValues);
            Tuple<RefCode, string> identity1 = GetCustomIdentity(baseRec) ; //?? GetStandardIdentity(baseRec);
            Debug.Assert(identity1 != null);


            var result = new StandingDataAudit
            {
                AuditIdentifier = identity1.Item2,
                IdentifierType = identity1.Item1,
                UserId = _userId,
                AuditComponent = new RefCode(componentName),
                OperationType = new RefCode(interrogationResult.KindOfOperation.ToString()),
                SourceSystem = new RefCode(EsscApplicationName),
                ExistingValue = String.Join(Environment.NewLine, interrogationResult.OriginalValues),
                NewValue = String.Join(Environment.NewLine, interrogationResult.CurrentValues) + extraCommment.IsNullOrEmptyReturnNull(),
            };

            return result;
        }
    }
}
