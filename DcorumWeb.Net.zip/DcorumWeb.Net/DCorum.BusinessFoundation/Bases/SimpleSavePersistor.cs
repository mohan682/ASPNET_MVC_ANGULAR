﻿using System;
using System.Collections.Generic;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.Practices;
using DcorumWeb.Utilities;

namespace DCorum.BusinessFoundation
{
	public abstract class SimpleSavePersistor<TModel,TKey> : IPersistor<TModel>
		where TModel : new()
        where TKey :IEquatable<TKey>
	{
		private readonly TKey _ambientValueOfModel;

		public SimpleSavePersistor(TKey ambientValueOfModel = default(TKey))
		{
			_ambientValueOfModel = ambientValueOfModel;
		}

		protected abstract string GetInsertSql(TModel arguments);
		protected abstract IEnumerable<IOutcomeItem> GetOutcomeItems();
		protected abstract void AddNoRowsAffectedError();
		
		public IEnumerable<IOutcomeItem> Save(TModel toSave)
		{
			string sqlToExecute = GetInsertSql(toSave);

			if (String.IsNullOrEmpty( sqlToExecute )) throw new InvalidOperationException();

			int rowsAffected = DataAccessHelp.ExecuteDeferredNonQuery(null, () => GetInsertSql(toSave));

			if (rowsAffected <= 0)
			{
				AddNoRowsAffectedError();
			}

			return GetOutcomeItems();
		}

		public IEnumerable<IOutcomeItem> Erase(TModel toSave)
		{
			throw new NotImplementedException();
		}

		//public void Hydrate(TModel toBuildUp)
		//{
		//	throw new NotImplementedException();
		//}


		public TModel GetUnique(TKey uniqueId)
		{
			if (!uniqueId.Equals(_ambientValueOfModel)) throw new InvalidOperationException();

			return new TModel();
		}

        string IPersistor<TModel>.TextualAmbientValue
        {
            get
            {
                string result = _ambientValueOfModel.SafeString();
                return result;
            }
        }

        string IPersistor<TModel>.GetTextualIdentityOf(TModel model)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Used to convert a view friendly key to a business friendly key.
        /// </summary>
        protected virtual bool TryDetextualize<TOut>(string textualValue, out TOut detextualizedValue)
        {
            bool success = TryParseHelp.Singleton.TryParse(textualValue, out detextualizedValue);
            return success;
        }


        TModel IRetriever<TModel>.GetUniqueViaTextualId(string uniqueId)
        {
            TKey realId;
            bool success = TryDetextualize(uniqueId, out realId);

            if (!success) return default(TModel); //key is neither and existing, valid or ambient value,

            return GetUnique(realId);
        }


        TModel[] IRetriever<TModel>.GetManyViaTextualId(string parentId, string augmentQueryWith)
        {
            throw new NotImplementedException();
        }
	}
}
