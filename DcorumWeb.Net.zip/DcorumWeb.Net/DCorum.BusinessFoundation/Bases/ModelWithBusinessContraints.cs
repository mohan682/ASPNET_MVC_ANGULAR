﻿using System;
using System.Diagnostics;
using Dcorum.Utilities.Contractual;
using DCorum.ViewModelling.Contractual;

namespace DCorum.BusinessFoundation.Bases
{
    /// <summary>
    /// [PROXY] Works alongside properties annotated with a BusinessConstraintAttibute.
    /// Allows simple model property types to be loosely associated with richer entities for the purposes of constraining/validating and list control binding.
    /// </summary>
    [Serializable]
    public abstract class ModelWithBusinessContraints : IHaveBindablePropertiesPlus
    {
        /// <summary>
        /// Created a BusinessContraintsContainer
        /// </summary>
        protected ModelWithBusinessContraints(BusinessContraintsContainer actor)
        {
            if (actor ==null) throw new ArgumentNullException("actor");
            _myBusinessConstraints = actor;
            Debug.Assert(MyBusinessConstraints!=null);
        }

        //Business driven property restrictions....
        [NonSerialized] //Note: for content list view state. Prevent losformatter including this, hence implement as a backing field.
        private BusinessContraintsContainer _myBusinessConstraints;
        protected BusinessContraintsContainer MyBusinessConstraints { get { return _myBusinessConstraints; } }


        public virtual IKeyValuePair[] Choices(int ruleId, Type ofProperty)
        {
            return MyBusinessConstraints.Choices(ruleId);
        }


        public virtual bool Choose(int ruleId, Type ofProperty, object chosenValue)
        {
            return MyBusinessConstraints.TryToChoose(ruleId, chosenValue, false);
        }


        public bool TryValidate()
        {
            return MyBusinessConstraints.TryValidate( this );
        }


        public virtual bool TryInferKey(int ruleId, Type ofProperty, object modelValue, out string key)
        {
            return MyBusinessConstraints.TryInferKey(ruleId, ofProperty, modelValue, out key);
        }


        public virtual void DeclareBusinessConstraint(int ruleId, Type ofProperty, Func<IKeyValuePair[]> howToGetRestrictedPairs, Action<object> encapsulatedSetterTechnique, bool allowUpdate = false, bool nullableModeOn = false)
        {
            MyBusinessConstraints.DeclareBusinessConstraint(ruleId, ofProperty, howToGetRestrictedPairs, encapsulatedSetterTechnique, allowUpdate, nullableModeOn);
        }
    }
}
