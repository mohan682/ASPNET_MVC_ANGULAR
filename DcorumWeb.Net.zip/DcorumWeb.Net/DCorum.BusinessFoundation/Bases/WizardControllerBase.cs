﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dcorum.RefCoding;
using Dcorum.Utilities;
using Dcorum.Utilities.Annotations;
using Dcorum.Utilities.Contractual;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Contractual;

namespace DCorum.BusinessFoundation.Bases
{
    public abstract class WizardControllerBase<TModel, TKey, TParentKey>
        : IPersistor<TModel>
        where TModel :class
    {
        protected WizardControllerBase(TKey defaultKeyValue)
        {
            AmbientValue = defaultKeyValue ;
        }

        protected abstract IHaveReadableContainers ModelAdaptor { get; }
        internal protected abstract IContainerCommandReceiver CommandReceiver { get; }

        public abstract void DiscardAllState();

        public TKey AmbientValue { get; }

        /// <summary>
        /// not currently used but included for interface compatibility.
        /// </summary>
        public bool ReadOnlyModeOn { get; set; }

        /// <summary>
        /// Object should already be in the session.
        /// </summary>
        [UIButtonHint("Ok", HasModelArgument= true)]
        public IEnumerable<IOutcomeItem> Save(TModel toSave)
        {
            if (toSave == null) return null;

            var validationComments = CommandReceiver.Validate(toSave).ToArray();

            if (validationComments.Any())
            {
                var result = validationComments.Select(_ => new OutcomeItem( _.Item2) );
                return result;
            }

            CommandReceiver.TrySave(toSave);

            return null;
        }

        [UIButtonHint("Cancel", HasModelArgument = true, ConfirmModeOn = true)]
        public IEnumerable<IOutcomeItem> Erase(TModel toErase)
        {
            bool success = CommandReceiver.TryRemove(toErase);
            if (!success) DiscardAllState();
            return null;
        }

        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected virtual void HydrateCore(TModel toHydrate)
        {
            if (ReferenceEquals(toHydrate, default(TModel))) return;
            CommandReceiver.TryInitialize(toHydrate);
            RefCodeHelp.DoBuildRefCodes(toHydrate);
        }


        public TKey GetPrimaryId(TModel ofInterest)
        {
            string textualId = MetaDataHelper.GetTextualIdentity(ofInterest);

            TKey parsed;
            bool success = TryParseHelp.Singleton.TryParse(textualId, out parsed);

            if (!success) return AmbientValue ;

            return parsed;
        }


        public TModel[] GetMany(TParentKey parentId, string augmentQueryWith = null)
        {
            return ModelAdaptor.Items<TModel>().ToArray();
        }


        public TModel GetUnique(TKey uniqueId)
        {
            TModel result = ModelAdaptor.Item<TModel>();
         
            result = result ?? ModelAdaptor.Items<TModel>().FirstOrDefault(_ => GetPrimaryId(_).Equals(uniqueId));

            result = result ?? CommandReceiver.CreatePossibleAddition<TModel>();
       
            HydrateCore(result);
            
            return result;
        }


        public string TextualAmbientValue
        {
            get
            {
                if (typeof(TKey).IsValueType) return AmbientValue.ToString();
                string result = AmbientValue.SafeString();
                return result;
            }
        }

        public string GetTextualIdentityOf(TModel model)
        {
            var result = MetaDataHelper.GetTextualIdentity(model);
            if (result == String.Empty) return null;
            return result;
        }


        /// <summary>
        /// Used to convert a view friendly key to a business friendly key.
        /// </summary>
        protected virtual bool TryDetextualize<TOut>(string textualValue, out TOut detextualizedValue)
        {
            bool success = TryParseHelp.Singleton.TryParse(textualValue, out detextualizedValue);
            return success;
        }


        TModel IRetriever<TModel>.GetUniqueViaTextualId(string uniqueId)
        {
            TKey realId;
            bool success = TryDetextualize(uniqueId, out realId);

            if (!success) return default(TModel); //key is neither and existing, valid or ambient value,

            return GetUnique(realId);
        }


        TModel[] IRetriever<TModel>.GetManyViaTextualId(string parentId, string augmentQueryWith)
        {
            TParentKey realId;
            bool success = TryDetextualize(parentId, out realId);

            if (!success) return null; //key is neither and existing, valid or ambient value,

            return GetMany(realId, augmentQueryWith);
        }
    }



    public class UntypedWizardControllerAdaptor<TModel, TKey, TParentKey>
        : IUntypedPersistor
        where TModel : class
    {
        public UntypedWizardControllerAdaptor(WizardControllerBase<TModel, TKey, TParentKey> adapteee)
        {
            Adaptee1 = adapteee;
            if (Adaptee1 == null) throw new ArgumentNullException(nameof(adapteee)) ;
        }

        private WizardControllerBase<TModel, TKey, TParentKey> Adaptee1 { get; }

        public object[] GetUntypedMany(object parentId, Func<object, bool> untypedFilter, string augmentQueryWith,
            bool applyAnonymousFacade)
        {
            TModel[] tooMany = Adaptee1.GetMany((TParentKey)parentId, augmentQueryWith);

            if (untypedFilter != null)
            {
                tooMany = tooMany.Where(_ => untypedFilter(_)).ToArray();
            }

            Func<TModel, object> howToFacade = _ => _; //default do nothing special;
            if (applyAnonymousFacade) howToFacade = Adaptee1.CommandReceiver.IntoAnonymousType;

            var results = tooMany.Select(howToFacade).ToArray();
            return results;
        }


        public object GetUntypedUnique(object uniqueId)
        {
            TKey identity1 = (TKey)uniqueId;
            return Adaptee1.GetUnique(identity1);
        }

        public IEnumerable<IOutcomeItem> Save(object toSave)
        {
            throw new NotImplementedException();
        }


        public IEnumerable<IOutcomeItem> Erase(object primaryKey)
        {
            TKey castPrimaryKey = (TKey)primaryKey;
            TModel toErase = Adaptee1.GetUnique(castPrimaryKey);
            bool success = Adaptee1.CommandReceiver.TryRemove(toErase);

            if (!success) yield return new OutcomeItem("Erase was unsuccessful.");
            yield break ;
        }


        public bool ReadOnlyModeOn { get { return Adaptee1.ReadOnlyModeOn;  } set { Adaptee1.ReadOnlyModeOn = value; } }
    }
}
