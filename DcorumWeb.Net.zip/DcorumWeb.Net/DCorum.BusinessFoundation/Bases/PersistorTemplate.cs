﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Reflection;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Contractual;

namespace DCorum.BusinessFoundation.Bases
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    public abstract class PersistorTemplate<TModel, TKey, TParentKey, TDataKey, TParentDataKey>
        : BLRetrieverTemplate<TModel,TKey, TParentKey, TDataKey, TParentDataKey>
        , IPersistor<TModel>
        , IUntypedPersistor
    {
        protected PersistorTemplate(IRemarksActor remarksVessel, IOpenCrudFull<TModel, TDataKey, TParentDataKey> crudFull)
            : base(crudFull)
        {
            RemarksVessel = remarksVessel;
            CrudIn = crudFull;
            CrudThru = crudFull;
        }


        protected virtual string Category
        {
            get { return this.GetType().GetFirstAttribute<CategoryAttribute>().Category; }
        }

        public virtual TKey AmbientValue { get { return default(TKey); } }
        
        /// <summary>
        /// Contains any Error/Warning messages that should be shown to the user.
        /// </summary>
        protected IRemarksActor RemarksVessel { get; private set; }
        protected ICrudIn<TModel> CrudIn { get; private set; }
        protected ICrudThru<TModel> CrudThru { get; private set; }


        public virtual string GetTextualIdentityOf(TModel model)
        {
            return MetaDataHelper.GetTextualIdentity(model);
        }


        public virtual TKey GetPrimaryId(TModel model)
        {
            string textualId = GetTextualIdentityOf(model);

            TKey realId;
            bool success = TryDetextualize(textualId, out realId);

            if (!success) return AmbientValue;

            return realId ;
        }


        public virtual bool IsAnActualId(TKey toCompare)
        {
            bool result = !Equals(toCompare, AmbientValue);
            return result;
        }


        protected abstract void Persist(TModel toPersist, Func<TModel, int> howToPersist, bool deleteModeOn);

        /// <summary>
        /// [POLYMORPHIC,PROTECTED]
        /// </summary>
        protected virtual void Insert(TModel model)
        {
            Persist(model, CrudIn.Insert, false);
        }

        /// <summary>
        /// [POLYMORPHIC,PROTECTED]
        /// </summary>
        protected virtual void Update(TModel model)
        {
            Persist(model, CrudIn.Update, false);
        }

        /// <summary>
        /// [POLYMORPHIC,PROTECTED]
        /// </summary>
        protected virtual void Delete(TModel model)
        {
            Persist(model, CrudIn.Delete, true);
        }

        protected virtual void Validate(TModel model)
        {
            RemarksVessel.YieldAndPurgeAll(); //start validation with an empty vessel!
        }


        private bool? _readOnlyModeOn = null;

        public bool ReadOnlyModeOn
        {
            get
            {
                return _readOnlyModeOn ?? false;
            }
            set
            {
                _readOnlyModeOn = _readOnlyModeOn ?? value;
            }
        }


        protected virtual bool InsertModeOn(TModel model)
        {
            TKey primaryId = GetPrimaryId(model);
            bool result = !IsAnActualId(primaryId);
            return result;
        }

        public virtual TOutcome Save(TModel model)
        {
            if (ReadOnlyModeOn)
            {
                RemarksVessel.IncludeCustomRemarks(new[] { "This is not permitted in read-only mode!" });
                return RemarksVessel.YieldAndPurgeAll();
            }

            if (ReferenceEquals(model,null)) RemarksVessel.RemarkNoItemSpecified = true ;

            Validate(model);

            if (RemarksVessel.IsEmpty)
            {
                bool insertModeOn = InsertModeOn(model);

                if (insertModeOn)
                {
                    if (CrudThru != null && CrudThru.SelectDuplicates(model).Length > 0)
                    {
                        RemarksVessel.DuplicatesDetected = true;
                    }
                    else
                    {
                        Insert(model);
                    }
                }
                else
                {
                    TKey primaryId = GetPrimaryId(model);
                    //note: excluding itself from the candidates any other items infer an impending duplication of data.
                    if (CrudThru != null &&
                        CrudThru.SelectDuplicates(model).Any(_ => !Equals(GetPrimaryId(_), primaryId)))
                    {
                        RemarksVessel.DuplicatesDetected = true;
                    }
                    else
                    {
                        Update(model);  
                    }
                }
            }

            return RemarksVessel.YieldAndPurgeAll();
        }


        public virtual TOutcome Erase(TModel toErase)
        {
            if (ReadOnlyModeOn)
            {
                RemarksVessel.IncludeCustomRemarks( new[] {"This is not permitted in read-only mode!"});
                return RemarksVessel.YieldAndPurgeAll();
            }

            if (ReferenceEquals(toErase, null)) RemarksVessel.RemarkNoItemSpecified = true;

            if (IsAnActualId(GetPrimaryId(toErase)))
            {
                if (CrudThru.DetectAnyDependants(toErase))
                {
                    RemarksVessel.DependanciesDetected = true;
                }
                else
                {
                    Delete(toErase);
                }
            }
            else
            {
                RemarksVessel.RemarkInvalidIdentityDetected = true;
            }

            return RemarksVessel.YieldAndPurgeAll();
        }


        TOutcome IKeyedEditor.Erase(object primaryId)
        {
            TKey castPrimaryId = (TKey) primaryId;

            if (IsAnActualId(castPrimaryId)==false)
            {
                RemarksVessel.RemarkInvalidIdentityDetected = true;
                return RemarksVessel.YieldAndPurgeAll();
            }

            var toDelete = GetUnique(castPrimaryId);
            return Erase(toDelete);
        }

        TOutcome IKeyedEditor.Save(object toSave)
        {
            Contract.Requires(toSave!=null);
            if (!(toSave is TModel)) throw new InvalidOperationException();
            var errors = Save((TModel)toSave);
            return errors;
        }


        string IPersistor<TModel>.TextualAmbientValue
        {
            get
            {
                string result = AmbientValue.SafeString();
                return result;
            }
        }
    }
}
