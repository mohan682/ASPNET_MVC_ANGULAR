﻿using System.Diagnostics;
using Dcorum.Utilities.Contractual;
using System.Collections;

namespace DCorum.BusinessFoundation.Bases
{
    /// <summary>
    /// [TEMPLATE]
    /// Obtains item either by retrieval or creation as well as being able to discard a previously retrieved item.
    /// </summary>
    public abstract class SessionCaretakerBase<TCreation> : SessionCaretakerBase
        where TCreation :class
    {
        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected abstract string BuildStorageKey();
        /// <summary>
        /// [POLYMORPHIC]
        /// </summary>
        protected abstract TCreation Create();


        /// <summary>
        /// [TEMPLATE METHOD]
        /// </summary>
        public TCreation Obtain()
        {
            string storageKey = BuildStorageKey();
            var result = Storage[storageKey] as TCreation;

            if (result != null) return result;
            Debug.Assert(result == null);

            var creation1 = Create();

            storageKey = BuildStorageKey();
            Storage.Add(storageKey, creation1);
            return creation1;
        }

        /// <summary>
        /// [TEMPLATE METHOD]
        /// </summary>
        public void Discard()
        {
            string storageKey2 = BuildStorageKey();
            Storage.Remove(storageKey2);
        }
    }



    public abstract class SessionCaretakerBase
    {
        /// <summary>
        /// Must maintin isolated storage for multiple simultainious users.
        /// </summary>
        private static IDictionary _storage;

        /// <summary>
        /// [INJECTION,SET-ONCE]
        /// </summary>
        public static IDictionary Storage
        {
            get { return _storage; }
            set { _storage = _storage ?? value; }
        }
    }
}
