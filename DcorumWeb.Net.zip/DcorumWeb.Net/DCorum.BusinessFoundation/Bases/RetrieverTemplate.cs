﻿using System;
using System.Collections.Generic;
using System.Linq;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.RefCoding;
using Dcorum.Utilities;

namespace DCorum.BusinessFoundation.Bases
{
    /// <summary>
    /// Common simplification where data key types match business model key types.
    /// </summary>
    public class BLRetrieverTemplate<TModel, TKey, TParentKey>
        : BLRetrieverTemplate<TModel, TKey, TParentKey, TKey, TParentKey>
    {
        public BLRetrieverTemplate( ICrudOut<TModel, TKey, TParentKey> crudOut )
            :base(crudOut)
        {
        }

        protected override TKey ConvertToDataKey(TKey key)
        {
            return key;
        }

        protected override TParentKey ConvertToParentDataKey(TParentKey key)
        {
            return key;
        }
    }

    /// <summary>
    /// Fetcher. Supports possibility the model and data row key types are different.
    /// </summary>
    public abstract class BLRetrieverTemplate<TModel,TKey, TParentKey, TDataKey, TParentDataKey>
        : IRetriever<TModel>, IUntypedRetriever
    {
        protected BLRetrieverTemplate(ICrudOut<TModel, TDataKey, TParentDataKey> crudOut)
        {
            CrudOut = crudOut;
        }

        protected ICrudOut<TModel, TDataKey, TParentDataKey> CrudOut { get; private set; }

       
        protected abstract TDataKey ConvertToDataKey(TKey key);
        protected abstract TParentDataKey ConvertToParentDataKey(TParentKey key);


        public virtual TModel[] GetMany(TParentKey parentId = default(TParentKey), string augmentQueryWith = null)
        {
            TParentDataKey parentDataKey = ConvertToParentDataKey(parentId);

            TModel[] results = CrudOut.SelectManyViaParentKey(parentDataKey, augmentQueryWith);

            foreach (TModel model in results)
            {
                Hydrate(model);
            }
            return results;
        }


        public virtual TModel GetUnique(TKey primaryId)
        {
            TDataKey dataKey = ConvertToDataKey(primaryId);
            TModel result = CrudOut.SelectViaPrimaryKey(dataKey);

            if (Equals(result, default(TModel)))
            {
                result = Create();
            }

            Hydrate(result);
            return result;
        }


        protected virtual TModel Create()
        {
            return default(TModel);
        }


        public virtual void Hydrate(TModel toHydrate)
        {
            if (ReferenceEquals(toHydrate, default(TModel))) return;
            RefCodeHelp.DoBuildRefCodes(toHydrate);
        }


        /// <summary>
        /// Provides and opportunity for derived classes to facade/adapt the model object graph prior to tabular presentation.
        /// </summary>
        protected virtual object AnonymousTableRowFacade(TModel toFacade)
        {
            return toFacade;
        }


        object IUntypedRetriever.GetUntypedUnique(object primaryId)
        {
            TKey identity1 = (TKey)primaryId;
            return GetUnique(identity1);
        }

        object[] IUntypedRetriever.GetUntypedMany(object parentId, Func<object, bool> postQueryFilter, string augmentQueryWith, bool applyAnonymousFacade)
        {
            Func<TModel, object> howToFacade = _ => _; //default do nothing special;
            if (applyAnonymousFacade) howToFacade = AnonymousTableRowFacade;
            TModel[] tooMany = GetMany((TParentKey)parentId, augmentQueryWith);

            if (postQueryFilter != null)
            {
                tooMany = tooMany.Where(_ => postQueryFilter(_)).ToArray();
            }

            var results = tooMany.Select(howToFacade).ToArray();
            return results;
        }


        /// <summary>
        /// Used to convert a view friendly key to a business friendly key.
        /// </summary>
        protected virtual bool TryDetextualize<TOut>(string textualValue, out TOut detextualizedValue)
        {
            bool success = TryParseHelp.Singleton.TryParse(textualValue, out detextualizedValue);
            return success;
        }


        TModel IRetriever<TModel>.GetUniqueViaTextualId(string uniqueId)
        {
            TKey realId;
            bool success = TryDetextualize(uniqueId, out realId);

            if (!success) return default(TModel); //key is neither and existing, valid or ambient value,

            return GetUnique(realId);
        }


        TModel[] IRetriever<TModel>.GetManyViaTextualId(string parentId, string augmentQueryWith)
        {
            TParentKey realId = default(TParentKey);

            if (parentId != null)
            {
                bool success = TryDetextualize(parentId, out realId);

                if (!success) return null; //key is neither and existing, valid or ambient value,
            }

            return GetMany(realId, augmentQueryWith);
        }
    }
}
