﻿using System;

namespace DCorum.BusinessFoundation.Annotations
{
    /// <summary>
    /// For information only: allows a developer to see associations that are otherwise hidden because of loosely coupled by refletive DI
    /// </summary>
    public class AgentsAttribute :Attribute
    {
        public AgentsAttribute(params Type[] agentTypes)
        {
            
        }
    }

}
