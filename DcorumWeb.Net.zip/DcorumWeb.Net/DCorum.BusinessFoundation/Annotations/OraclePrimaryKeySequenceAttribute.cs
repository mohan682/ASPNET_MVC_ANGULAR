﻿using System;

namespace DCorum.BusinessFoundation.Annotations
{   
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Struct, AllowMultiple = false, Inherited = true)]
    public class OraclePrimaryKeySequenceAttribute :Attribute
    {
        public string SequenceName { get; private set; }

        public OraclePrimaryKeySequenceAttribute(string sequenceName)
        {
            SequenceName = sequenceName;
        }
    }
}
