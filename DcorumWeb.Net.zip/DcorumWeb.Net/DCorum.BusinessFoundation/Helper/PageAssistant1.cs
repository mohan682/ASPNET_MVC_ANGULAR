﻿using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DcorumWeb.WebForms
{
    public static class PageAssistant
    {
        /// <summary>
        /// Core approach. Reuse if relevant.
        /// </summary>
        public static TGridModel RowEditingGetModelCore<TGridModel>(Func<int[],string[]> identityPartsSelector, IPersistor<TGridModel> tableController, int[] primaryColumns, int[] alternativeColumns, string parentTextualId, string badParentTextualId, Action failTechnique, int alternativeParentIndex = 0)
        {
            bool hasEmptyPrimaryId = primaryColumns == null || primaryColumns.Length <= 0;

            string[] ids = (hasEmptyPrimaryId) ? new string[] { } : identityPartsSelector(primaryColumns);

            if (hasEmptyPrimaryId == false)
            {
                hasEmptyPrimaryId = tableController.TextualAmbientValue.Equals(string.Join("|", ids), StringComparison.OrdinalIgnoreCase);
            }

            if (hasEmptyPrimaryId) // won't work because primary identity is the same as for an empty/blank model!
            {
                ids = identityPartsSelector(alternativeColumns);

                bool hasEmptyParentId = badParentTextualId.Equals(ids[alternativeParentIndex], StringComparison.OrdinalIgnoreCase);

                if (hasEmptyParentId)
                {
                    bool wontWork = badParentTextualId.Equals(parentTextualId, StringComparison.OrdinalIgnoreCase);

                    if (wontWork) failTechnique();
                    ids[alternativeParentIndex] = parentTextualId; //ensure first part of key is the row items's parent id!
                }
            }

            string candidateKey = string.Join("|", ids);

            if (string.IsNullOrWhiteSpace(candidateKey)) failTechnique();

            var result = tableController.GetUniqueViaTextualId(candidateKey);

            return result;
        }


        /// <summary>
        /// Core approach. Reuse if relevant.
        /// </summary>
        /// <param name="toSave"></param>
        /// <param name="existingRowModels"></param>
        /// <param name="matchRowPredicate"></param>
        /// <param name="displayableValidations"></param>
        /// <param name="validateManyTechnique"></param>
        /// <returns></returns>
        public static IOutcomeItem[] PreRowSaveCore<TGridModel>(TGridModel toSave,
            TGridModel[] existingRowModels, Predicate<TGridModel> matchRowPredicate, List<IOutcomeItem> displayableValidations, Func<TGridModel[], IOutcomeItem[]> validateManyTechnique
            )
        {
            TGridModel[] myCopy = existingRowModels.ToArray();
            int index1 = Array.FindIndex(myCopy, matchRowPredicate);

            string extraFail = null;

            if (index1 < 0)
            {
                extraFail = "Row doesn't seem to map to an updatable row!";
            }
            else
            {
                myCopy[index1] = toSave; //replace with proposed new state

                IOutcomeItem[] preSaveTableValidations = validateManyTechnique(myCopy);

                if (displayableValidations.Count < preSaveTableValidations.Length)
                {
                    extraFail = "Row update failed validation!";
                }

                displayableValidations.Clear();
                displayableValidations.AddRange(preSaveTableValidations);
            }

            if (string.IsNullOrEmpty(extraFail) == false)
            {
                var extraOutcome = new OutcomeItem(extraFail);
                displayableValidations.Add(extraOutcome);
                return new[] { extraOutcome };
            }

            return null;
        }
    }
}
