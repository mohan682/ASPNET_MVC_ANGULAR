﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Linq.Expressions;
//using System.Text;

//namespace DCorum.BusinessFoundation.Helper
//{
//    public static class SearchCriteriaFactory
//    {
//        public static Func<T, bool> CreateWherePropertyLikeFunc<T>(Expression<Func<T, string>> value, string likeExpression)
//        {
//            return (o) => value.Compile().Invoke(o).Contains(likeExpression);
//        }

//        public static Func<T, bool> CreateWherePropertyEquals<T, TVal>(Expression<Func<T, TVal>> value, TVal rhs)
//        {
//            return (o) => value.Compile().Invoke(o).Equals(rhs);
//        }
//    }
//}
