﻿using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace DCorum.BusinessFoundation.Bases
{
    /// <summary>
    /// Basic definition of an interface where the implementor is identified by an Id
    /// </summary>
    /// <typeparam name="TId"></typeparam>
    public interface IWithId<TId>
    {
        /// <summary>
        /// Get the id
        /// </summary>
        /// <remarks>
        /// NB. The underscore is deliberate as ultimately the view model, which implements this 
        /// interface will be bound the grid and the '_' 
        /// </remarks>
        TId _Id { get; }
    }
}
