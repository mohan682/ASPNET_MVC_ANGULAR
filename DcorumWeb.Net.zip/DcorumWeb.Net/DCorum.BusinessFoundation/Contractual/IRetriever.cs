﻿using System;

namespace DCorum.BusinessFoundation.Contractual
{
    public interface IRetriever<out TModel>
    {
        TModel[] GetManyViaTextualId(string parentId, string augmentQueryWith = null);
        TModel GetUniqueViaTextualId(string uniqueId);
    }
}
