﻿using System;
using System.Collections.Generic;

namespace DCorum.BusinessFoundation.Contractual
{
    public interface IAuditor
    {
        void AuditChanges<T>(bool success, T current1, T existing1, string extraComment = null)  where T : class;
        bool AuditChanges<T>(T newValues, T oldValues, string extraCommment = null) where T : class;

        IEnumerable<IOutcomeItem> YieldAndPurgeAllRemarks() ;
    }
}
