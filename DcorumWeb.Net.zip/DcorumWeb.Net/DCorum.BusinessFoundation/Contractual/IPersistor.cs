﻿using System.Reflection;

namespace DCorum.BusinessFoundation.Contractual
{
    public interface IPersistor<TModel> : IEditor<TModel>, IRetriever<TModel>
    {
        string GetTextualIdentityOf(TModel ofInterest);

        /// <summary>
        /// Allows us to determine if we should even attempt a call to TryToCascadeChange.
        /// </summary>
        string TextualAmbientValue { get; }
    }


    //public interface ITextualIdentity<TModel>
    //{
    //    string GetTextualIdentityOf(TModel ofInterest);

    //    /// <summary>
    //    /// Allows us to determine if we should even attempt a call to TryToCascadeChange.
    //    /// </summary>
    //    string TextualAmbientValue { get; }
    //}



    public interface ICanCascadeChange<TModel> 
    {
        /// <summary>
        /// Mechanism to allow the controller to maintain model integrity after a recent model change.
        /// </summary>
        bool TryToCascadeChange(TModel affectedModel, PropertyInfo changeOrigin);
    }


    public interface ICanBeHydrated<TModel>
    {
        /// <summary>
        /// (Re)Build object graph
        /// </summary>
        void Hydrate(TModel toBuildUp);
    }

}
