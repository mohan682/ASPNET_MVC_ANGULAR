﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;

namespace DCorum.BusinessFoundation.Contractual
{
    public interface IRemarksActor
    {
        [Pure]
        bool IsEmpty { get; }

        bool RemarkNoItemSpecified { set; }
        bool DuplicatesDetected { set; }
        bool DependanciesDetected { set; }
        bool RemarkInvalidIdentityDetected { set; }
        bool RemarkActionAffectedMoreThanExpected { set; }
        bool RemarkActionAffectedLessThanExpected { set; }
        bool RemarkActionAppearedToAffectNothing { set; }

        bool AuditFailure { set; }
        bool DbOperationError { set; }
        bool DbOperationTamperedData { set; }
      
        bool RemarkUnavailableCommand { set; }
        bool RemarkUnpermittedCommand { set; }

        void IncludeCustomRemarks(params string[] remarks);

        /// <summary>
        /// Test, comment and return flag to indicate if actualRowsAffected met expectations.
        /// </summary>
        bool RemarkUponRowsAffected(int? actualRowsAffected, int minExpectedRowsAffected = 1, int maxExpectedRowsAffected = 1);

        IEnumerable<IOutcomeItem> YieldAndPurgeAll();
    }
}
