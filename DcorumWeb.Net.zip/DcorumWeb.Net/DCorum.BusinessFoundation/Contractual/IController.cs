﻿using DCorum.BusinessFoundation.Bases;
using DCorum.BusinessFoundation.Contractual;
using System.Collections.Generic;

namespace DCorum.BusinessFoundation.Contractual
{
    /// <summary>
    /// Defintion of a controller 
    /// </summary>
    /// <typeparam name="TViewModel"></typeparam>
    /// <typeparam name="TId"></typeparam>
    public interface IController<TViewModel, TId>
        where TViewModel : class, IWithId<TId>
    {
        /// <summary>
        /// Get an uninitialised key value for the model data type. Used to differentiate between existing model data
        /// and new data
        /// </summary>
        /// <remarks>
        /// For a typical DB Table with a numeric primary key, this value would be -1 of type int
        /// </remarks>
        TId UninitialisedId { get; }

        /// <summary>
        /// Create a new instance of the view model, initialised with appropriate values
        /// </summary>
        /// <remarks>
        /// This is used typically for the use case where a user wishes to create a new instance of the model
        /// </remarks>
        /// <returns></returns>
        TViewModel CreateModel();

        /// <summary>
        /// Get view model for the specified id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        TViewModel Get(TId id);

        /// <summary>
        /// Get all models
        /// </summary>
        /// <returns></returns>
        IEnumerable<TViewModel> GetAll();

        /// <summary>
        /// Add a new model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        IEnumerable<IOutcomeItem> Add(TViewModel viewModel);

        /// <summary>
        /// Update model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        IEnumerable<IOutcomeItem> Update(TViewModel viewModel);

        /// <summary>
        /// Delete model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        IEnumerable<IOutcomeItem> Delete(TViewModel viewModel);
    }

}
