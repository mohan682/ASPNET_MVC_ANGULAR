﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace DCorum.BusinessFoundation.Contractual
{
    public interface IContainerCommandReceiver : IContainerCommandReceiver<Tuple<PropertyInfo, string>>
    {
    }

    public interface IContainerCommandReceiver<out TValidationResult>
    {
        TModel CreatePossibleAddition<TModel>() 
            where TModel: class;

        /// <summary>
        /// For a specified sub entity, assign dervived non editable properties using this outer model as the source.
        /// </summary>
        bool TryInitialize<TModel>(TModel toModify) 
            where TModel : class;

        /// <summary>
        /// Provides and opportunity for derived classes to facade/adapt the model object graph prior to tabular presentation.
        /// </summary>
        object IntoAnonymousType<TModel>(TModel toFacade)
            where TModel : class;

        IEnumerable<TValidationResult> Validate<TModel>(TModel toValidate)
            where TModel : class;


        bool TryToCascadeChange<TModel>(TModel toModify, PropertyInfo changeOrigin)
            where TModel : class;

        bool TrySave<TModel>(TModel toAdd)
            where TModel : class;

        bool TryRemove<TModel>(TModel toRemove)
            where TModel : class;
    }
}
