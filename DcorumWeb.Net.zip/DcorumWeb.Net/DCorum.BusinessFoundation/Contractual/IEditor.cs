﻿using System.Collections.Generic;

namespace DCorum.BusinessFoundation.Contractual
{

    public interface IEditor<in TModel>
    {
        IEnumerable<IOutcomeItem> Save(TModel toSave);
        IEnumerable<IOutcomeItem> Erase(TModel toSave);

        ///// <summary>
        ///// (Re)Build object graph
        ///// </summary>
        //void Hydrate(TModel toBuildUp);    
    }

}
