﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace DCorum.BusinessFoundation.Contractual
//{
//    public interface IWizardCommands
//    {
//        void DiscardAllState();
//        void RefreshModel();
//    }
//}
