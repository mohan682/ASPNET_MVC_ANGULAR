﻿using System;
using System.Collections;
using System.Collections.Generic;
using DCorum.BusinessFoundation.Contractual;

namespace DCorum.BusinessFoundation.Bases
{
    public interface IControllerFactory<in TCaller>
    {
        Type[] GetSupportedTypes();

        Type[] FindAssociatedTypes(Type ownerType);

        IUntypedPersistor CreateUntypedPersistor(Type ofModel, TCaller caller);

        //IPersistor<TModel> GetCreation<TModel>(TCaller caller);

        TCreation GetCreation<TCreation, TModel>(TCaller caller);
        // where TCreation : IRetriever<TModel>;
    }
}
