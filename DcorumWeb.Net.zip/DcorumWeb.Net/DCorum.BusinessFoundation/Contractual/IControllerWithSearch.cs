﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.BusinessFoundation.Contractual
{
    /// <summary>
    /// Defintion of a controller that supports searching based on a search criteria model
    /// </summary>
    /// <typeparam name="TViewSearchModel"></typeparam>
    /// <typeparam name="TViewModel"></typeparam>
    public interface IControllerWithSearch<TViewSearchModel, TViewModel>
    {
        /// <summary>
        /// Get view models based on search criteria
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        IEnumerable<TViewModel> Get(TViewSearchModel searchCriteria);
    }
}
