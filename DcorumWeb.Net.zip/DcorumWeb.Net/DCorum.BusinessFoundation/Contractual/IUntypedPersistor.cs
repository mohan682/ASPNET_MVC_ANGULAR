﻿using System;
using System.Collections.Generic;

namespace DCorum.BusinessFoundation.Contractual
{
    /// <summary>
    /// Useful when rendering tabular views based on anonymous types.
    /// </summary>
    public interface IUntypedPersistor : IKeyedEditor, IUntypedRetriever
    {
    }

    public interface IUntypedRetriever
    {
        object[] GetUntypedMany(object parentId, Func<object, bool> untypedFilter = null, string augmentQueryWith = null, bool applyAnonymousFacade = false);
        object GetUntypedUnique(object uniqueId);
    }


    public interface IUntypedTabularHeadings
    {
        IEnumerable<string> YieldSpecialColumnNames();
        IEnumerable<string> YieldSpecialColumnTooltips();
    }

    public interface IKeyedEditor
    {
        bool ReadOnlyModeOn { get; set; }
        [Obsolete]
        IEnumerable<IOutcomeItem> Save(object toSave);
        IEnumerable<IOutcomeItem> Erase(object primaryKey);
    }
}
