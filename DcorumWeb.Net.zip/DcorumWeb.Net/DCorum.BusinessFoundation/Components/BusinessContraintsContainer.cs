﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using Dcorum.Utilities.Annotations;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Contractual;

namespace DCorum.BusinessFoundation.Bases
{
    public sealed class BusinessContraintsContainer
    {
        private Dictionary<int, Type> _keyedForeignTypes = new Dictionary<int, Type>();
        private Dictionary<int, Func<IKeyValuePair[]>> _keyedOptions = new Dictionary<int, Func<IKeyValuePair[]>>();
        private Dictionary<int, Action<object>> _keyedSetterTechniques = new Dictionary<int, Action<object>>();
        private Dictionary<int, bool> _keyedNullableKeyMode = new Dictionary<int, bool>();

        public BusinessContraintsContainer()
        {
            
        }


        public void  DeclareBusinessConstraint(int ruleId, Type ofProperty, Func<IKeyValuePair[]> howToGetRestrictedPairs, Action<object> setterTechnique, bool allowUpdate, bool nullableKeyMode)
        {
            if (_keyedForeignTypes.ContainsKey(ruleId))
            {
                if (allowUpdate)
                {
                    _keyedForeignTypes[ruleId] = ofProperty;
                    _keyedOptions[ruleId] = @howToGetRestrictedPairs ;
                    _keyedSetterTechniques[ruleId] = setterTechnique ;
                    _keyedNullableKeyMode[ruleId] = nullableKeyMode;
                }
                else
                {
                    throw new ArgumentException("predefined key specified!", "ruleId");
                }
            }
            else
            {
                _keyedForeignTypes.Add(ruleId, ofProperty);
                _keyedOptions.Add(ruleId, @howToGetRestrictedPairs);
                _keyedSetterTechniques.Add(ruleId, setterTechnique);
                _keyedNullableKeyMode[ruleId] = nullableKeyMode;
            }
        }


        public IKeyValuePair[] Choices(int ruleId)
        {
            IKeyValuePair[] results;

            bool success = TryGetOptions(ruleId, out results);

            if (!success) throw new InvalidOperationException();

            return results;
        }


        private bool TryGetOptions(int ruleId, out IKeyValuePair[] output1)
        {
            Func<IKeyValuePair[]> function1;
            bool success = _keyedOptions.TryGetValue(ruleId, out function1);

            output1 = (success) ? function1() : null;
            return success;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ruleId"></param>
        /// <param name="chosenValue"></param>
        /// <param name="passiveModeOn">prevents the actual assignment to the property</param>
        /// <returns></returns>
        public bool TryToChoose(int ruleId, object chosenValue, bool passiveModeOn)
        {
            IKeyValuePair[] options;

            bool optionsModeOn = TryGetOptions(ruleId, out options);

            if (!optionsModeOn) throw new NotImplementedException("options failure!");

            bool allowAssignModeOn = false;

            if ((chosenValue == null || String.Empty.Equals(chosenValue)) && _keyedNullableKeyMode[ruleId])
            {
                allowAssignModeOn = true;
            }
            else
            {
                int numericChoice;
                bool success = chosenValue.TryConvert(out numericChoice);
                allowAssignModeOn = success && options.SafeLinq().Any(_ => _.KeyItem == numericChoice);
            }

            if (allowAssignModeOn)
            {
                Action<object> setterTechniqueOut;
                bool hasKnownTechnique = _keyedSetterTechniques.TryGetValue(ruleId, out setterTechniqueOut);

                if (!hasKnownTechnique) throw new NotImplementedException("setter technique failure!");

                if (!passiveModeOn) setterTechniqueOut(chosenValue);
            }

            return allowAssignModeOn;
        }


        public bool TryValidate(object toValidate)
        {
            bool success = toValidate != null; 

            var businessConstraints = toValidate.GetType().GetProperties().PairWithAttribute<BusinessConstraintAttribute>().ToArray();

            foreach (var current1 in businessConstraints)
            {
                PropertyInfo piNow = current1.Key;
                object currentValue = piNow.GetValue(toValidate, null);

                if (currentValue == null) continue;

                success &= TryToChoose(current1.Value.Single().RuleId, currentValue, true);
            }

            return success;
        }

        /// <summary>
        /// Basic behaviour. Verifies ruleId and property type. Assumes ambient value of model id is numeric zero.
        /// </summary>
        public bool TryInferKey(int ruleId, Type ofProperty, object modelValue, out string key)
        {
            key = String.Empty;

            if (_keyedForeignTypes.ContainsKey(ruleId) == false)
            {
                Debug.WriteLine("[WARNING] Rule {0} hasn't been declared!", ruleId);
                return false;
            }

            if (ReferenceEquals(_keyedForeignTypes[ruleId], ofProperty) == false)
            {
                Debug.WriteLine("[WARNING] Rule {0} relates to {1}, not a {2}", ruleId, _keyedForeignTypes[ruleId], ofProperty);
                return false;
            }

            if (modelValue != null)
            {
                key = modelValue.ToString();
            }

            return true;
        }
    }
}
