﻿using System;
using System.Diagnostics.Contracts;
using System.Linq;
using DCorum.BusinessFoundation.Contractual;
using DCorum.BusinessFoundation.Structural;

namespace DCorum.BusinessFoundation.Bases
{
    /// <summary>
    /// Factory of persistence agents for various anaemic types.
    /// </summary>
    public class ControllerFactory<TCaller, TInjectableCaller> :IControllerFactory<TCaller>
    {
        public ControllerFactory(TypeKeyedMethodContainer<TInjectableCaller> methodContainer
            , Func<TCaller, TInjectableCaller> conversionTechnique
            , Action<object, TInjectableCaller> howToAssociateCallerToController
            )
        {
            _keyedMethodContainer = methodContainer;
            _conversionTechnique = conversionTechnique;
            _howToAssociateCallerToController = howToAssociateCallerToController ?? ((_,__) => { });
        }

        private readonly TypeKeyedMethodContainer<TInjectableCaller> _keyedMethodContainer;
        private readonly Func<TCaller, TInjectableCaller> _conversionTechnique;
        private readonly Action<object, TInjectableCaller> _howToAssociateCallerToController;

        public Type[] GetSupportedTypes()
        {
            return _keyedMethodContainer.GetAllKeys();
        }

        public Type[] FindAssociatedTypes(Type ownerType)
        {
            throw new NotImplementedException();
            //return AnnotationBehaviourExtensions.FindAssociatedTypes(GetSupportedTypes(), ownerType);
        }


        public TCreation GetCreation<TCreation,TModel>(TCaller caller)
        {
            Type modelType = typeof (TModel);

            object creation1 = CreateController(modelType, caller);
            Contract.Assert(creation1 != null);

            var result = (TCreation)creation1;
            return result;
        }

        public IUntypedPersistor CreateUntypedPersistor(Type ofModel, TCaller caller)
        {
            object controller1 = CreateController(ofModel, caller);

            Contract.Assert(controller1 != null);
  
            var result = CreateFacade(controller1 as IUntypedRetriever, controller1 as IKeyedEditor);

            return result;
        }


        protected virtual IUntypedPersistor CreateFacade(IUntypedRetriever retriever, IKeyedEditor editor)
        {
            return new UntypedPersistorAdaptor(retriever, editor);
        }


        protected virtual object CreateController(Type key, TCaller caller)
        {
            Func<TInjectableCaller,object> toInvoke;
            bool success = _keyedMethodContainer.TryGetTechnique(key, out toInvoke);
            if (!success) return null;

            var castCaller1 = _conversionTechnique(caller);

            var result = toInvoke(castCaller1);

            _howToAssociateCallerToController(result, castCaller1);

            return result;
        }
    }
}
