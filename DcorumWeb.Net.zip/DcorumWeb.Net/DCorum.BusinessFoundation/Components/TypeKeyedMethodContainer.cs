﻿using System;
using System.Collections.Generic;
using Dcorum.Utilities.Containers;

namespace DCorum.BusinessFoundation.Bases
{
    public class TypeKeyedMethodContainer<TCaller> : Keyed1ArgFuncContainer<Type, TCaller, object>
    {
        public TypeKeyedMethodContainer(Predicate<Type> keyPredicate)
            : base(keyPredicate)
        {
        }

        public class Changer : IDisposable
        {
            public Changer(TypeKeyedMethodContainer<TCaller> toEdit)
            {
                _toEdit = toEdit;
            }

            private TypeKeyedMethodContainer<TCaller> _toEdit;

            public void PutMethods(IEnumerable<KeyValuePair<Type, Func<TCaller,object>>> toIterate)
            {
                _toEdit.AddMethods(toIterate);
            }

            public void Dispose()
            {
                _toEdit = null;
            }
        }
    }
}
