﻿using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;

namespace DCorum.BusinessFoundation.Structural
{
    /// <summary>
    /// Useful for spoofing a FormController on page when you want to bypass it's implementation yourself.
    /// </summary>
    public sealed class PeristorMock<ModelAlias> : IPersistor<ModelAlias>
    {
        public PeristorMock()
        {
        }


        public string TextualAmbientValue
        {
            get
            {
                return default(int).ToString();
            }
        }

        public string GetTextualIdentityOf(ModelAlias ofInterest)
        {
            return MetaDataHelper.GetTextualIdentity(ofInterest) ?? TextualAmbientValue ;
        }


        public ModelAlias[] GetManyViaTextualId(string parentId, string augmentQueryWith = null)
        {
            throw new NotImplementedException();
        }

        public ModelAlias GetUniqueViaTextualId(string uniqueId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOutcomeItem> Save(ModelAlias toSave)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOutcomeItem> Erase(ModelAlias toErase)
        {
            throw new NotImplementedException();
        }
    }
}
