﻿using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;

namespace DCorum.BusinessFoundation.Structural
{
    public sealed class UntypedRetrieverMock : IUntypedTabularHeadings, IUntypedRetriever
    {
        /// <summary>
        /// Opportunity to customise column display names
        /// </summary>
        IEnumerable<string> IUntypedTabularHeadings.YieldSpecialColumnNames()
        {
            yield break;
        }

        /// <summary>
        /// Opportunity to customise column display tooltips
        /// </summary>
        IEnumerable<string> IUntypedTabularHeadings.YieldSpecialColumnTooltips()
        {
            yield break;
        }

        object IUntypedRetriever.GetUntypedUnique(object primaryId)
        {
            throw new NotImplementedException();
        }

        object[] IUntypedRetriever.GetUntypedMany(object parentId, Func<object, bool> untypedFilter, string augmentQueryWith, bool applyAnonymousFacade)
        {
            throw new NotImplementedException();
        }
    }
}
