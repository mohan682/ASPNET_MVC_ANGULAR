﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using DCorum.BusinessFoundation.Contractual;

namespace DCorum.BusinessFoundation.Structural
{
    using TOutcome = IEnumerable<IOutcomeItem>;

    /// <summary>
    /// Adapts an IUntypedRetriever and an optional separate IKeyedEditor into an IUntypedPersistor.
    /// </summary>
    public sealed class UntypedPersistorAdaptor : IUntypedPersistor 
    {
        private readonly static OutcomeItem NotAvailableMessage = new OutcomeItem("Feature Not Available!") ;

        public UntypedPersistorAdaptor(IUntypedRetriever source, IKeyedEditor editor)
        {
            Contract.Ensures(source != null);
            Source = source;
            Editor = editor;

            if (!ReferenceEquals(source,editor)) Console.WriteLine(String.Format("Object references differ for {0} in {1}", source.GetType(), typeof(UntypedPersistorAdaptor)));
        }

        public IUntypedRetriever Source { get; private set; }

        internal IKeyedEditor Editor { get; private set; }

        private TOutcome NotAvailable
        {
            get { yield return NotAvailableMessage; }
        }

        //public bool CanEdit
        //{
        //    get { return Editor != null; }
        //}


        public TOutcome Erase(object primaryId)
        {
            if (Editor == null) return NotAvailable ;
            return Editor.Erase(primaryId);
        }


        public bool ReadOnlyModeOn
        {
            get
            {
                if (Editor == null) return true;

                return Editor.ReadOnlyModeOn;
            }
            set
            {
                if (Editor == null) return;
                Editor.ReadOnlyModeOn = value;
            }
        }

        public TOutcome Save(object toSave)
        {
            if (Editor == null) return NotAvailable ;
            return Editor.Save(toSave);
        }


        public object GetUntypedUnique(object uniqueId)
        {
            return Source.GetUntypedUnique(uniqueId);
        }


        public object[] GetUntypedMany(object parentId, Func<object, bool> untypedFilter = null, string augmentQueryWith = null, bool applyAnonymousFacade = false)
        {
            return Source.GetUntypedMany(parentId, untypedFilter, augmentQueryWith, applyAnonymousFacade);
        }
    }
}
