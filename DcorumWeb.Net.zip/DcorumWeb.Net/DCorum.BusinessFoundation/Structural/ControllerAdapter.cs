﻿using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace DCorum.BusinessFoundation.Bases
{
    /// <summary>
    /// Controller adaptor. Bridges between the existing interfaces, which are tightly coupled with the existing architecture
    /// and a much more simplified interface for interacting with a controller
    /// </summary>
    /// <typeparam name="TViewModel"></typeparam>
    /// <typeparam name="TId"></typeparam>
    public class ControllerAdapter<TViewModel, TId> : 
        IUntypedPersistor, IPersistor<TViewModel> 
        where TViewModel : class, IWithId<TId>
    {
        #region Fields

        private readonly IController<TViewModel, TId> _controllerImpl;

        #endregion

        #region Properties

        public IController<TViewModel, TId> ControllerImpl { get { return _controllerImpl; } }

        #endregion

        #region Ctor

        public ControllerAdapter(IController<TViewModel, TId> controllerImpl)
        {
            _controllerImpl = controllerImpl;
        }

        #endregion 

        #region IUntypedPersistor, IPersistor<ViewModelT> Members

        public bool ReadOnlyModeOn
        {
            get; set;
        }

        
        public string TextualAmbientValue
        {
            get
            {
                return _controllerImpl.UninitialisedId.ToString();
            }
        }

        public IEnumerable<IOutcomeItem> Save(object toSave)
        {
            return Save(toSave as TViewModel);
        }

        public IEnumerable<IOutcomeItem> Erase(object primaryKey)
        {
            var model = GetUniqueViaTextualId(primaryKey?.ToString());       
            return Erase(model);
        }

        public object[] GetUntypedMany(object parentId, Func<object, bool> untypedFilter = null, string augmentQueryWith = null, bool applyAnonymousFacade = false)
        {
            var results =  _controllerImpl.GetAll().ToArray();

            if (untypedFilter!=null)
            {
                results = results.Where(_ => untypedFilter(_)).ToArray();
            }

            return results;
        }

        public object GetUntypedUnique(object uniqueId)
        {
            return GetUniqueViaTextualId(uniqueId?.ToString());
        }


        public string GetTextualIdentityOf(TViewModel ofInterest)
        {
            return ofInterest._Id.ToString();
        }


        public IEnumerable<IOutcomeItem> Save(TViewModel toSave)
        {
            if (toSave == null) return new IOutcomeItem[] { new OutcomeItem("Invalid type passed to Save") };
            if (ReadOnlyModeOn) return new IOutcomeItem[] { new OutcomeItem("You are not allowed to perform this action!") };

            if (toSave._Id.Equals(_controllerImpl.UninitialisedId))
            {
                return _controllerImpl.Add(toSave);
            }
            else
            {
                return _controllerImpl.Update(toSave);
            }
        }


        public IEnumerable<IOutcomeItem> Erase(TViewModel toSave)
        {
            if (toSave == null) return new IOutcomeItem[] { new OutcomeItem("Invalid Id") };
            if (ReadOnlyModeOn) return new IOutcomeItem[] { new OutcomeItem("You are not allowed to perform this action!") };

            return _controllerImpl.Delete(toSave);
        }

        public TViewModel[] GetManyViaTextualId(string parentId, string augmentQueryWith = null)
        {
            Debug.Assert(string.IsNullOrEmpty(augmentQueryWith));
            return _controllerImpl.GetAll().ToArray();
        }

        public TViewModel GetUniqueViaTextualId(string uniqueId)
        {
            if (string.IsNullOrEmpty(uniqueId)) throw new ArgumentException(string.Empty, nameof(uniqueId));
            TId convertedId = (TId)Convert.ChangeType(uniqueId, typeof(TId));

            if (convertedId.Equals(_controllerImpl.UninitialisedId))
            {
                return _controllerImpl.CreateModel();
            }

            return _controllerImpl.Get(convertedId);
        }

        #endregion
    }
}
