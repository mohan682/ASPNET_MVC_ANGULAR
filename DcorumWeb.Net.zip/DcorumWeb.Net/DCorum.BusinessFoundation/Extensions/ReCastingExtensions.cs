﻿using DCorum.BusinessFoundation.Contractual;
using DCorum.BusinessFoundation.Structural;
using System;

namespace DCorum.BusinessFoundation.Extensions
{
    /// <summary>
    /// [TEMPORARY] Workaround for casting and untyped gridcontroller into a more useable type. 
    /// Useful until code behind base classes are refactored!
    /// </summary>
    public static class ReCastingExtensions
    {
        /// <summary>
        /// [WORKAROUND1] Cast to the IKeyedEditor constrained specified type either the supplied argument or one of it's children.
        /// DEV NOTE: Implementation must not directly call to polymorphic AutoForm....Core.GridController property otherwise infinite recursion may occur.
        /// </summary>
        public static TEditor RecastAsSpecificController<TEditor>(this IUntypedPersistor untypedController)
            where TEditor : IKeyedEditor
        {
            return CoreWithResultConstraint<TEditor,IKeyedEditor>(untypedController, true);
        }


        public static TResult RecastFirstWhereSelfOtherwiseChildPropertyIsOfType<TResult>(this IUntypedPersistor untypedController, bool mustMatch)
        {
            return Core<TResult>(untypedController, mustMatch);
        }


        /// <summary>
        /// [WORKAROUND2] Tries to get a more strongly typed version of the supplied object.
        /// </summary>
        public static IPersistor<TModel> RecastAsModelAwarePersistor<TModel>(this IUntypedPersistor untypedController)
        {
            return Core<IPersistor<TModel>>(untypedController, true);
        }

        /// <summary>
        /// [WORKAROUND2] Tries to get a more strongly typed version of the supplied object.
        /// </summary>
        public static IUntypedTabularHeadings RecastAsTableHeaderDetails(this IUntypedPersistor untypedController)
        {
            return Core<IUntypedTabularHeadings>(untypedController, false);
        }

        private static TResult CoreWithResultConstraint<TResult, TConstraint>(object gridController, bool mustMatch)
            where TResult : TConstraint
        {
            return Core<TResult>(gridController, true);
        }

        /// <summary>
        /// Return self or first child property that satifies the supplied desired type.
        /// </summary>
        /// <typeparam name="TDesiredResult"></typeparam>
        /// <param name="gridController"></param>
        /// <param name="mustMatch">If true and no result then throw Argument Exception</param>
        /// <returns>Self of first child member of the desired type</returns>
        private static TDesiredResult Core<TDesiredResult>(object gridController, bool mustMatch)
        {
            if (gridController is TDesiredResult) return (TDesiredResult)gridController; //source == result

            if (gridController is UntypedPersistorAdaptor)
            {
                var adaptor1 = (UntypedPersistorAdaptor)gridController;
                IKeyedEditor candidate2 = adaptor1.Editor;

                if (candidate2 is TDesiredResult) return (TDesiredResult)candidate2; //source == result

                IUntypedRetriever candidate3 = adaptor1.Source ;

                if (candidate3 is TDesiredResult) return (TDesiredResult)candidate3; //source == result
            }

            if (mustMatch) throw new ArgumentException($@"Unable to match to type: {typeof(TDesiredResult).Name}!", nameof(gridController));

            return default(TDesiredResult);
        }
    }
}
