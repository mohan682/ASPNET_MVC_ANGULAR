﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace Dcorum.Configuration
{
    public class EnterpriseLogger : ILogger
    {
        public EnterpriseLogger(string applicationName)
        {
            if (String.IsNullOrWhiteSpace(applicationName)) throw new ArgumentException("must not be null/empty or whitespace", "applicationName");
            _applicationName = applicationName;
        }

        private readonly string _applicationName ;

        private readonly Dictionary<TraceEventType, string> _keyedConfigKeys = new Dictionary<TraceEventType, string>
        {   {TraceEventType.Warning, "Trace.Log.Warning"}
        ,   {TraceEventType.Information, "Trace.Log.Information"}
        };


        private string GetConfigKey(TraceEventType eventType)
        {
            string out1;
            bool success = _keyedConfigKeys.TryGetValue(eventType, out out1);

            if (!success) return null;

            return out1;
        }


        private bool GetEventTypeFlag(TraceEventType eventType, bool defaultResult = true)
        {
            string key1 = GetConfigKey(eventType);

            if (String.IsNullOrEmpty(key1)) return defaultResult;

            bool result = ConfigHelp.Singleton.GetBoolean(key1) ?? false;

            return result;
        }


        public void WriteMessage(Exception ex, TraceEventType eventType, int priority = 10)
        {
            if (GetEventTypeFlag(eventType))
            {
                var entry = new LogEntry()
                {
                    Priority = priority,
                    Severity = eventType
                };

                entry.Title = ex.Source;
                entry.Message = String.Format("{1} event raised in:{2}.{0}{3}{0}{4}{0}", Environment.NewLine, eventType, ex.TargetSite, ex.Message, ex.StackTrace);

                Logger.Write(entry);
            }
        }


        public void WriteMessage(string message, TraceEventType eventType, int priority = 10)
        {
            if (GetEventTypeFlag(eventType))
            {
                var entry = new LogEntry()
                {
                    Priority = priority,
                    Severity = eventType
                };

                entry.Title = _applicationName;
                entry.Message = String.Format("{1}.{0}{2}{0}", Environment.NewLine, eventType, message);

                Logger.Write(entry);
            }
        }

        public static void Write(string message, string category, int eventID, TraceEventType severity)
        {
            Logger.Write(message, category, 1, eventID, severity);
        }
    }
}
