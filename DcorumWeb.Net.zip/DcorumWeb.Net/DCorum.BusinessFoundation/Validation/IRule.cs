﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.BusinessFoundation.Validation
{
    /// <summary>
    /// Definition of rule for the purpose of validating some operation
    /// </summary>
    public interface IRule
    {
        /// <summary>
        /// Run the validation rule. If validation fails, should throw <see cref="ValidationException"/>
        /// </summary>
        void RunValidation();
    }
}
