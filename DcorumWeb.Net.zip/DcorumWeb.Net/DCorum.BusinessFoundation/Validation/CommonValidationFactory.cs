﻿using System;

namespace DCorum.BusinessFoundation.Validation
{
    public class CommonValidationFactory
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public CommonValidationFactory()
        {
        }


        public IRule CreateValidateDatesRule(DateTime? dateFrom, DateTime? dateTo, string dateDesc)
        {
            return new Rule(
                () =>
                {
                    if (!dateFrom.HasValue && !dateTo.HasValue) return;

                    if (!dateFrom.HasValue && dateTo.HasValue)
                        throw new ValidationException($"{dateDesc} Date From field not set");

                    if (dateFrom.HasValue && dateTo.HasValue && dateFrom.Value > dateTo.Value)
                        throw new ValidationException($"{dateDesc} Date From can not be greater than {dateDesc} Date To");
                });
        }

        public IRule CreateValidateNonEmptyWhiteSpaceFieldRule(string fieldValue, string error)
        {
            return new Rule(
                () =>
                {
                    if (fieldValue != null && string.IsNullOrWhiteSpace(fieldValue))
                        throw new ValidationException(error);
                });
        }

    }

}
