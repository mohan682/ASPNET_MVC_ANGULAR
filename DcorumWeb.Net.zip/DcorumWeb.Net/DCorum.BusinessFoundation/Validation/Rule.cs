﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.BusinessFoundation.Validation
{

    /// <summary>
    /// Very simple <see cref="IRule"/> implementation
    /// </summary>
    public class Rule : IRule
    {
        private readonly Action _ruleImplFunc;

        public Rule(Action ruleImplFunc)
        {
            _ruleImplFunc = ruleImplFunc;
        }

        public void RunValidation()
        {
            _ruleImplFunc();    
        }
    }
}
