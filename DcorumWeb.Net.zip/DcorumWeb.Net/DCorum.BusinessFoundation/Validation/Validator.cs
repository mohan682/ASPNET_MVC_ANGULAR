﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.BusinessFoundation.Validation
{
    /// <summary>
    /// Validator responsible for acting on a set of validation rules
    /// </summary>
    public class Validator
    {
        public void Validate(IEnumerable<IRule> rules)
        {
            foreach (var rule in rules)
                rule.RunValidation();
        }
    }
}
