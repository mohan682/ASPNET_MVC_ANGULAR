﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.BusinessFoundation.Validation
{
    /// <summary>
    /// Validation Excpetion
    /// </summary>
    public class ValidationException : Exception
    {
        public ValidationException(string s) : base(s) { }
    }

}
