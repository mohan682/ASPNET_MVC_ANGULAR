﻿extern alias WCF;

using System;
using System.Linq;
using System.Collections.Generic;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using Dcorum.BusinessLayer.BRIA.DataAccess;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;

namespace Dcorum.BusinessLayer.BRIA.Logic
{
    using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;
    using WcfMessageParams = WCF::WcfBusiness.Illustrations.Illustration.Entities.MessageParams;

    public delegate IReadOnlyDictionary<string, object>[] FetchMemberFeesDelegate(int caseMemberKey, string[] validAdviserFeeCodes,bool includeExpiredFees);

    /// <summary>
    /// Build parts of the RiaAdhoc view graph from other pre-existing sources.
    /// </summary>
    public class BriaAdhocModelBuilder
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public BriaAdhocModelBuilder( BriaAdhocViewGraph toProjectOnto )
        {
            ViewGraph = toProjectOnto;
        }

        public static FetchMemberFeesDelegate FetchMemberFeesCommand { get; set; }

        /// <summary>
        /// [TO_MUTATE]
        /// </summary>
        private BriaAdhocViewGraph ViewGraph { get; }

        public void BuildDateAffectedParts( DecumIllustrationSession projectionSource )
        {
            var wcfModel = projectionSource.Repository;
            if (wcfModel == null) return;

            var model = ViewGraph;

            int key = 0;
            model.InvFundChoices =
                projectionSource.AllSchemeFunds.Select(_ => new BindableFundChoice
                {
                    SurrogateKey = ++key,
                    FundId = _.FundId,
                    FundDesc = _.Name,
                    IsFlyweight = true,
                    IsFreestyle = _.IsFreestyle
                }).ToArray();

            int disinvestmentsIndex = 0;

            model.Disinvestments = wcfModel.DisinvestmentStrategy.distribution.Select(
                _ => new CapturedDisinvestment
                {
                    SurrogateKey = ++disinvestmentsIndex,
                    BindableProperty = model.InvFundChoices.FirstOrDefault(__ => __.FundId == _.fund.id),
                    Percent = _.percentage.IntoDecimalN().GetValueOrDefault()
                }
                ).ToList();

            int investmentsIndex = 0;
            model.Investments = wcfModel.memberElections.Select(
                _ => new CapturedInvestment
                {
                    SurrogateKey = ++investmentsIndex,
                    BindableProperty = model.InvFundChoices.FirstOrDefault(__ => __.FundId == _.FundId),
                    Percent = _.Percent,
                    IsLifeStyle = _.IsLifestyle,
                }
                ).ToList();

            decimal uncrystallizedExistingBalancesSum = wcfModel.existingBalances.Where(_ => !_.IsCrystallised).Sum(_ => _.Value);
            model.TaxFreeCash.UncrystallizedExistingBalancesSum = uncrystallizedExistingBalancesSum;
            model.DummyTransferValue.HasUncrystallizedExistingBalances = uncrystallizedExistingBalancesSum > 0;

            var income = model.Income;
            if (model.Start.CaseMemberKey > 0)
            {
                var subSection = wcfModel.IncomeDetail;
                income.Frequency = new RefCode((int)subSection.incomeFrequency);
                income.IncreasePercent = Convert.ToInt32(subSection.escalationPct);
                income.Escalation = new RefCode(null,subSection.escalation);
                income.RegularAmount = subSection.grossRegularIncome;
                income.OneOffAmount = subSection.grossAdhocIncomeAmount;

                int? code = null;
                if (wcfModel.IncomeDetail != null && wcfModel.IncomeDetail.source != null)
                    code = wcfModel.IncomeDetail.source.code;
                else if (wcfModel.RetirementOptions != null &&  wcfModel.RetirementOptions.income != null && wcfModel.RetirementOptions.income.incomeSourceOptions != null)
                    code = wcfModel.RetirementOptions.income.incomeSourceOptions.FirstOrDefault(_ => _.selected).SafeFuncN(_ => _.code);

                if (code.HasValue)
                    income.IncomePriority = new RefCode(code.Value);

                income.CrystalizedExistingBalancesSum = wcfModel.existingBalances.Where(_ => _.IsCrystallised).Sum(_ => _.Value);
            }
            else
            {
                CapturedIncome.BuildNonMemberCapturedIncome(income);
            }

            RefCodeHelp.DoBuildRefCodes(income);
        }


        public void BuildStart( WcfMessageParams illustrationMessage )
        {
            var model = ViewGraph.Start;

            model.IsBriaScheme = illustrationMessage.IsBriaScheme;

            model.IsPendingBriaMember = illustrationMessage.IsPendingApplicationForm;

            model.TransferValueCount = illustrationMessage.TransferValueCount;

            model.CaseKey = illustrationMessage.CaseKey;
            model.CaseMemberKey = illustrationMessage.PolicyID;
            model.EffectiveDate = illustrationMessage.IllustrationDate;

            model.ActiveDrawdownStatusDate = illustrationMessage.ActiveDrawdownStatusDate;
        }


        public void BuildExistingAdviserCharges( AdvisorFeeCodes defaultTransferInFeeCode )
        {
            int caseMemberKey = ViewGraph.Start.CaseMemberKey ;

            string[] permittedAdvisorFeeCodes = RiaQueries.Default.FetchAdviserChargesTypeForIllustrationType(ViewGraph.Start.IllustrationOption);

            var fetchedRows = FetchMemberFeesCommand.Invoke(caseMemberKey, permittedAdvisorFeeCodes,false) ;

            ViewGraph.AdviserCharges = new List<CapturedAdviserCharge>() ;

            if (fetchedRows?.Any() == true)
            {
                ViewGraph.AdviserCharges = fetchedRows.Select( row => new CapturedAdviserCharge( row )).ToList() ;
            }

            if (ViewGraph.TvIns != null)
            {
                Dictionary<string, string> chargeCodes = RiaQueries.Default.FetchAdviserChargeDescriptionsFor(null);
                string transferInChargeCode = ((int)defaultTransferInFeeCode).ToString() ;
                foreach (var current in ViewGraph.TvIns)
                {
                    if (current.SurrogateKey > 0 == false) continue ;
                    int newKey = new[] { 0 }.Concat( ViewGraph.AdviserCharges.Select(_ => _.SurrogateKey)).Max() + 1 ;

                    ViewGraph.AdviserCharges.Add(new CapturedAdviserCharge() {
                        SurrogateKey = newKey,
                        SurrogateTranferInForeignKey = current.SurrogateKey,
                        ChargeTypeCode = transferInChargeCode,
                        ChargeTypeDescription = chargeCodes[transferInChargeCode],
                        TransferInAmount = current.TotalFundValue
                    });
                }
            }
        }
    }
}
