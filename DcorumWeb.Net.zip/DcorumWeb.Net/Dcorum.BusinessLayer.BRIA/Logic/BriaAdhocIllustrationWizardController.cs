﻿extern alias WCF;
using System;
using System.Diagnostics;
using System.Reflection;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Creational;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.Utilities.Annotations;
using Dcorum.Utilities.Contractual;
using DCorum.BusinessFoundation.Bases;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.BRIA.DataAccess;
using System.Collections.Generic;
using System.Linq;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;
using Dcorum.BusinessLayer.BRIA.Logic.Internal;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.BRIA.Logic
{

    using static ViewAssistance.RiaViewRowFlavours;
    using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;

    public class BriaAdhocIllustrationWizardController<TModel>
        : WizardControllerBase<TModel, int, int>
        , IBriaAdhocControllerIdentity
        , ICanCascadeChange<TModel>, ICanBeHydrated<TModel>
        where TModel : class
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected BriaAdhocIllustrationWizardController( RiaQueries riaQueries )
            : base(default(int))
        {
            MyRiaQueries = riaQueries;
            if (MyRiaQueries == null) throw new ArgumentNullException(nameof(riaQueries)) ;

            Build();
        }

        private RiaQueries MyRiaQueries { get; }

        public bool CanEdit
        {
            get
            {
                bool readOnlyWhen = IllustrationChoice == DecumIllustrationMode.AnnualReview
                       && (typeof(CapturedAdviserCharge).IsAssignableFrom(typeof(TModel)))
                       ;

                return !readOnlyWhen;
            }
        }

        /// <summary>
        /// [IMPLICIT]
        /// </summary>
        public int CaseKey { get; set; }

        /// <summary>
        /// [IMPLICIT]
        /// </summary>
        public int CaseMemberKey { get; set; }

        /// <summary>
        /// [IMPLICIT]
        /// </summary>
        public int? ExistingQueueId { get; set; }


        private Lazy<BriaAdhocIllustrationActorCaretaker> _deferredIllustrationActorCaretaker;

        private Lazy<BriaAdhocViewGraphCaretaker> _deferredViewGraphCaretaker;


        private DecumIllustrationSession ExternalIllustrationActor { get { return _deferredIllustrationActorCaretaker.Value.Obtain(); } }
        private BriaAdhocViewGraph ViewGraph { get { return _deferredViewGraphCaretaker.Value.Obtain(); } }


        private Lazy<IHaveReadableContainers> _deferredModelAdaptor;
        protected override IHaveReadableContainers ModelAdaptor { get { return _deferredModelAdaptor.Value; } }

        private Lazy<BriaAdhocCommandReceiver> _deferredCommandReceiver;
        protected override IContainerCommandReceiver CommandReceiver { get { return _deferredCommandReceiver.Value; } }


        /// <summary>
        /// Ensure the advisor charges have the correct transfer in amount assigned before delivery to the consuming class.
        /// </summary>
        private void TweakAdvisorCharges( BriaAdhocViewGraph toTweak)
        {
            if (toTweak?.AdviserCharges == null) return ;

            foreach( var current1 in toTweak.AdviserCharges)
            {
                if (current1?.SurrogateTranferInForeignKey > 0 == false) continue;

                var associate1 = toTweak.TvIns.FirstOrDefault( _ => _.SurrogateKey == current1.SurrogateTranferInForeignKey) ;

                current1.TransferInAmount = associate1?.TotalFundValue ;
            }
        }


        private void Build()
        {
            _deferredIllustrationActorCaretaker = new Lazy<BriaAdhocIllustrationActorCaretaker>(
                () => new BriaAdhocIllustrationActorCaretaker(ExistingQueueId.GetValueOrDefault(), CaseMemberKey, CaseKey)
                );

            _deferredViewGraphCaretaker = new Lazy<BriaAdhocViewGraphCaretaker>(
                () => new BriaAdhocViewGraphCaretaker(CaseKey, ExternalIllustrationActor)
                );

            _deferredModelAdaptor = new Lazy<IHaveReadableContainers>(
                () => BriaFactoryMethods.Singleton.CreateRiaReadOnlyModelAdaptor(ViewGraph, TweakAdvisorCharges)
                );

            _deferredCommandReceiver = new Lazy<BriaAdhocCommandReceiver>(
                () => new BriaAdhocCommandReceiver(ViewGraph, ExternalIllustrationActor)
                );
        }

        /// <summary>
        /// [IMPLICIT|POLYMORPHIC]
        /// </summary>
        public override void DiscardAllState()
        {
            _deferredIllustrationActorCaretaker.Value.Discard();
            _deferredViewGraphCaretaker.Value.Discard();
            Build(); //flush out lazy loaded objects.
        }

        /// <summary>
        /// [EXPLICIT] Mode to help determine wizard next/back steps
        /// </summary>
        public DecumIllustrationMode IllustrationChoice
        {
            get
            {
                return ModelAdaptor.Item<CapturedStart>().IllustrationOption;
            }
        }

        /// <summary>
        /// ViewModel key and display name collection. Can be further refined based on the context of the specified adviser change.
        /// </summary>
        /// <param name="model"></param>
        public IReadOnlyDictionary<string,string> GetAllowedAdviserFeeDescriptions( CapturedAdviserCharge model = null)
        {
            var illustrationMode = IllustrationChoice ;
   
            var results = MyRiaQueries.FetchAdviserChargeDescriptionsFor(null, illustrationMode) ;

            var feeHelper1 = new AdviserFeeAssistant();

            bool? transferItem = feeHelper1.MustTransferAmountHaveValue(model, IllustrationChoice);

            if (transferItem.HasValue)
            {
                var allowedCodes = AdvisorFeeCodesExtensions.PerTransferInFeeCodes(illustrationMode).ToArray() ;

                if (transferItem == true)
                {
                    return results.Where( _ => allowedCodes.DoesContain( _.Key ) == true ).IntoDictionary();
                }
                else
                {
                    return results.Where( _ => allowedCodes.DoesContain( _.Key ) == false).IntoDictionary();
                }
            }

            return results;
        }


        public IReadOnlyDictionary<int, decimal> GetTransferInDisplayNames( CapturedAdviserCharge model )
        {
            var feeHelper1 = new AdviserFeeAssistant();

            if (feeHelper1.MustTransferAmountHaveValue(model, IllustrationChoice) != false)
            {
                return ModelAdaptor.Items<CapturedTransferValueIn>().ToDictionary(_ => _.SurrogateKey, _ => _.TotalFundValue);
            }

            return new Dictionary<int, decimal>();
        }


        public bool GetAdviserChargesModeOn()
        {
            //return true; //remove after dev complete!!!!!!
            bool result = MyRiaQueries.IsSchemeAllowedAdviserCharges(CaseKey);
            return result ;
        }


        public T CreateEmptyViewModel<T>() //( bool applyAnonymousFacade )
            where T :new()
        {
            T result = new T();

            //if (applyAnonymousFacade) result = CommandReceiver.IntoAnonymousType(result);

            return result ;
        }


        public IUntypedTabularHeadings GetTableViewDecorationsFor<T>(T viewRow = default(T))
        {
            Type ofInterest = (viewRow?.GetType() ?? typeof(T));

            if (ofInterest == typeof(CapturedAdviserCharge)) return new TabularFeesHeadingsAndTooltips();
            return null;
        }


        /// <summary>
        /// [IMPLICIT|POLYMORPHIC]
        /// </summary>
        [UIButtonHint("Refresh")]
        public virtual void RefreshModel()
        {
            if (typeof(TModel) != typeof(ViewIllustrationResponse)) return;

            RefreshResponse( ModelAdaptor.Item<ViewIllustrationResponse>(), ExternalIllustrationActor) ;
        }

        private static void RefreshResponse(ViewIllustrationResponse response, DecumIllustrationSession wcfIllustrationSession)
        {
            response.LastPolled = DateTime.Now;

            if (wcfIllustrationSession.Message.ServiceTaskQueueId != response.QueueId)
            {

                wcfIllustrationSession.ReBuild(response.QueueId);

                if (!response.WizardModeOn)
                {
                    var visitor1 = new RiaInitializationFlavours(null, wcfIllustrationSession);
                    visitor1.Initialize(response);
                }
            }

            var queuedSession = wcfIllustrationSession.QueuedSession;

            response.WasSuccessful = queuedSession.GetWasIllustrationSuccessful();
            response.IllustrationPdfUrl = queuedSession.GetAdhocPathname();
            response.XmlResultsUrl = queuedSession.GetXmlResponsePathname() ?? queuedSession.GetXmlRequestPathname();
        }

        public bool TryToCascadeChange(TModel affectedModel, PropertyInfo changeOrigin)
        {
            return CommandReceiver.TryToCascadeChange(affectedModel, changeOrigin);
        }

        public void Hydrate(TModel toHydrate)
        {
            base.HydrateCore(toHydrate);
        }
    }
}
