﻿using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;
using Dcorum.BusinessLayer.BRIA.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Dcorum.BusinessLayer.BRIA.Logic.Internal
{
    public class AdviserFeeAssistant
    {
        public bool IsPercentageRequired(CapturedAdviserCharge model)
        {
            return model.IsChargeTypeAnyOf(AdvisorFeeCodes.Ongoing) ;
        }

        public bool IsAmountRequired(CapturedAdviserCharge model)
        {
            return model.IsChargeTypeAnyOf(AdvisorFeeCodes.PensionAdviceAllowance, AdvisorFeeCodes.Adhoc);
        }


        public bool? MustTransferAmountHaveValue(CapturedAdviserCharge model, DecumIllustrationMode illustrationMode)
        {
            if (illustrationMode.IsTransferInMode() == false) return false;

            if (string.IsNullOrWhiteSpace(model.ChargeTypeCode)) return null ;

            bool result = (model.IsChargeTypeAnyOf(AdvisorFeeCodesExtensions.PerTransferInFeeCodes(illustrationMode).ToArray())) ;

            return result;
        }


        public decimal MaximumPermittedFee(CapturedTransferValueIn transferIn)
        {
            return transferIn.TotalFundValue ;
        }


        public IEnumerable<decimal> CalculateFeeSplit(CapturedTransferValueIn transferIn, CapturedAdviserCharge optionalCharge)
        {
            if (optionalCharge == null) yield break;

            if (transferIn == null) throw new ArgumentNullException(nameof(transferIn));

            decimal fee = 0;

            if (optionalCharge.Amount.HasValue)
            {
                fee = optionalCharge.Amount.Value;
            }
            else if (optionalCharge.Percentage.HasValue)
            {
                fee = (transferIn.TotalFundValue) * (optionalCharge.Percentage.Value / 100);
            }
            else
            {
                yield break;
            }

            if (fee > 0)
            {
                decimal feeCrystallized = (transferIn.CrystallizedFundValue >= fee) ? fee : transferIn.CrystallizedFundValue;
                decimal feeUncrystallized = (transferIn.CrystallizedFundValue >= fee) ? 0 : fee - transferIn.CrystallizedFundValue;

                yield return feeCrystallized;
                yield return feeUncrystallized;
            }
            else
            {
                throw new InvalidProgramException("A negative fee was calculated!!!");
            }


        }

    }
}
