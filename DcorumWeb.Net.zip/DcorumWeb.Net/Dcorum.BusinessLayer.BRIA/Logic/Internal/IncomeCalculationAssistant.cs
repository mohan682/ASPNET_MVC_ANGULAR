﻿using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.ViewAssistance;
using Dcorum.Utilities.Practices;
using Dcorum.Utilities.Extensions;
using System.Collections.Generic;
using System;

namespace Dcorum.BusinessLayer.BRIA.Logic.Internal
{
    internal class IncomeCalculationAssistant
    {
        private BriaAdhocPureGraph _source;

        public IncomeCalculationAssistant(BriaAdhocPureGraph source)
        {
            _source = source;
        }


        /// <summary>
        /// [DERIVED]
        /// </summary>
        [Pure]
        public decimal TotalCrystallizedFundValue()
        {
            decimal result = _source.TvIns.Sum(_ => _.CrystallizedFundValue) + _source.Income.CrystalizedExistingBalancesSum;
            return result;
        }

        /// <summary>
        /// [DERIVED]
        /// </summary>
        [Pure]
        public decimal TotalUncrystallizedFundValue()
        {
            decimal result = _source.TvIns.Sum(_ => _.UncrystallizedFundValue) + _source.TaxFreeCash.UncrystallizedFundValue;
            return result;
        }
   
        /// <summary>
        /// [DERIVED]
        /// </summary>
        [Pure]
        public decimal CalculateTotalTaxFreeCash()
        {
            decimal result = _source.TvIns.SafeLinq().Sum(_ => _.DerivedTaxFreeAmount()) + _source.TaxFreeCash.DerivedTaxFreeAmount();
            return result;
        }

        /// <summary>
        /// [DERIVED]
        /// </summary>
        [Pure]
        public decimal CalculateTotalTaxFreePercent()
        {
            var totalFundValue = TotalUncrystallizedFundValue();

            Debug.Assert(totalFundValue > 0);

            var taxFreeAmount = CalculateTotalTaxFreeCash();

            decimal result = (taxFreeAmount / totalFundValue) * 100;
            return result;
        }

        /// <summary>
        /// [DERIVED]
        /// </summary>
        [Pure]
        public bool IncomeFromCrfEnabled()
        {
            bool result = (TotalCrystallizedFundValue() > 0) || (CalculateTotalTaxFreeCash() > 0);
            return result;
        }


        /// <summary>
        /// [DERIVED]
        /// </summary>
        [Pure]
        public bool IncomeFromUcrfEnabled()
        {
            bool result = (TotalUncrystallizedFundValue() > 0) && CalculateTotalTaxFreePercent() < Values.MaxTaxFreePercent;
            return result;
        }

        /// <summary>
        /// [DERIVED]
        /// </summary>
        [Pure]
        public decimal MaxAdhocAmount()
        {
            decimal result = TotalUncrystallizedFundValue() + TotalCrystallizedFundValue() - CalculateTotalTaxFreeCash();
            return result.RoundTowardsZero(2) ;
        }
    }

}
