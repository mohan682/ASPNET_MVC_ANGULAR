﻿using Dcorum.BusinessLayer.BRIA.Entities;
using DCorum.BusinessFoundation.Bases;
using Dcorum.BusinessLayer.BRIA.DataAccess;

namespace Dcorum.BusinessLayer.BRIA.Logic
{
    public class ServiceTaskQueueReadonlyController : BLRetrieverTemplate<ServiceTaskQueueLogEntry, int, int>
    {
        internal ServiceTaskQueueReadonlyController(DLServiceTaskQueueLogEntry crudActor)
            : base(crudActor)
        {

        }

        protected override object AnonymousTableRowFacade(ServiceTaskQueueLogEntry toFacade)
        {
            return ServiceTaskQueueLogEntryHelper.DefaultViewFacade(toFacade);
        }
    }
}
