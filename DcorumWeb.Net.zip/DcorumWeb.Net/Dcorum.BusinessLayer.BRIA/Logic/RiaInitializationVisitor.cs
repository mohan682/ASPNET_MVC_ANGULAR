﻿extern alias WCF;

using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.Logic.Internal;
using Dcorum.Utilities.Practices;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Dcorum.BusinessLayer.BRIA.Logic
{
    using Contractual.Internal;
    using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;

    public class RiaInitializationVisitor
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public RiaInitializationVisitor( RiaInitializationFlavours variationsSource )
        {
            VariationsSource1 = variationsSource ;

            flavours = new Dictionary<Type, Action<object>>
            {
                {typeof (DummyTransferValue), _ => VariationsSource1.Initialize((DummyTransferValue) _)},
                {typeof (CapturedTaxFreeCash), _ => VariationsSource1.Initialize((CapturedTaxFreeCash) _)},
                {typeof (DummyDisinvestment), _ => VariationsSource1.Initialize((DummyDisinvestment) _)},
                {typeof (CapturedSummary), _ => VariationsSource1.Initialize((CapturedSummary) _)},
                {typeof (ViewIllustrationResponse), _ => VariationsSource1.Initialize((ViewIllustrationResponse) _)},
                {typeof (CapturedIncome), _ => VariationsSource1.Initialize((CapturedIncome) _)},
                {typeof (CapturedInvestment), _ => VariationsSource1.Initialize((CapturedInvestment) _)},
                {typeof (CapturedDisinvestment), _ => VariationsSource1.Initialize((CapturedDisinvestment) _)},
                {typeof (CapturedTransferValueIn), _ => VariationsSource1.Initialize((CapturedTransferValueIn) _)},
                {typeof (DummyAdviserCharge), _ => VariationsSource1.Initialize((DummyAdviserCharge) _)},
                {typeof (CapturedAdviserCharge), _ => VariationsSource1.Initialize((CapturedAdviserCharge) _)},
            };
        }

        private RiaInitializationFlavours VariationsSource1 ;

        private Dictionary<Type, Action<object>> flavours;

        public bool TryVisit(object toVisit)
        {
            if (toVisit == null) return false;

            Type visiteeType = toVisit.GetType();

            Action<object> howToVisit;
            bool success = flavours.TryGetValue(visiteeType, out howToVisit);

            if (!success) return false;

            howToVisit?.Invoke(toVisit);

            return true;
        }
    }


    public class RiaInitializationFlavours
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected RiaInitializationFlavours(BriaAdhocViewGraph toVisit, DecumIllustrationSession illustrationActor)
        {
            _injectedIllustrationActor = illustrationActor;
            _injectedVisitee = toVisit;
        }

        private DecumIllustrationSession _injectedIllustrationActor;
        private readonly BriaAdhocViewGraph _injectedVisitee;

        public void Initialize(DummyTransferValue model)
        {
            if (model == null) return;

            model.HasExistingBalances = _injectedIllustrationActor.Repository.existingBalances.Any();
        }

        public void Initialize(CapturedTaxFreeCash cast1)
        {
            if (cast1 == null) return;
            //cast1.UncrystallizedTransferValuesSum = _injectedVisitee.TvIns.Sum(_ => _.UncrystallizedFundValue);
        }

        public void Initialize(DummyDisinvestment cast1A)
        {
            if (cast1A == null) return;
            cast1A.SameAsInvestmentsFlag = _injectedVisitee.Disinvestments.Count <= 0;
        }

        public void Initialize(CapturedSummary cast2)
        {
            if (cast2 == null) return;
            cast2.InvokeWcfFlag = _injectedVisitee.Start.IsBriaScheme;

            if (!_injectedVisitee.Start.IsBriaScheme) return ;

            cast2.CaseKey = _injectedVisitee.Start.CaseKey;
            cast2.CaseMemberKey = _injectedVisitee.Start.CaseMemberKey;

            cast2.IllustrationOption = _injectedVisitee.Start.IllustrationOption;
            cast2.EffectiveDate = _injectedVisitee.Start.EffectiveDate;

            cast2.Dob = _injectedVisitee.MemberDetail.Dob ?? _injectedIllustrationActor.PersonalDetails.DOB;
            cast2.GenderDescription = _injectedVisitee.MemberDetail.Gender.SafeFunc( _ => _.Descript) ?? _injectedIllustrationActor.PersonalDetails.Sex;

            cast2.MemberFullname = String.Format("{0} {1} {2}", 
                _injectedVisitee.MemberDetail.Title.SafeFunc( _ => _.Descript) ??  _injectedIllustrationActor.PersonalDetails.Title,
                _injectedVisitee.MemberDetail.FirstName ?? _injectedIllustrationActor.PersonalDetails.Forename, 
                _injectedVisitee.MemberDetail.Surname ??  _injectedIllustrationActor.PersonalDetails.Surname
                );

            cast2.WhatIfFlag = _injectedIllustrationActor.WhatIfModeOn();
            cast2.DeductionsFlag = _injectedIllustrationActor.DeductionsModeOn();
        }

        public void Initialize(ViewIllustrationResponse cast3)
        {
            if (cast3 == null || cast3.CaseKey != 0) return;
            cast3.CaseKey = _injectedIllustrationActor.CaseKey;
            cast3.CaseMemberKey = _injectedIllustrationActor.CaseMemberKey;
            cast3.WhatIfFlag = _injectedIllustrationActor.WhatIfModeOn();
        }

        public void Initialize(CapturedIncome cast4)
        {
            if (cast4 == null) return;

            var assistant1 = new IncomeCalculationAssistant(_injectedVisitee);

            cast4.IncomeFromCrfEnabled = assistant1.IncomeFromCrfEnabled();
            cast4.IncomeFromUcrfEnabled = assistant1.IncomeFromUcrfEnabled();
            cast4.MaxAdhocAmount = assistant1.MaxAdhocAmount();

            cast4.EditableInvestmentsModeOn = _injectedIllustrationActor.CaseMemberKey == default(int);
            cast4.HasExistingBalances = _injectedIllustrationActor.Repository.existingBalances.Any();
        }

        public void Initialize(CapturedInvestment cast5)
        {
            if (cast5 == null) return;

            if (cast5.SurrogateKey != _injectedVisitee.TemporaryInvestment?.SurrogateKey)
            {
                _injectedVisitee.TemporaryInvestment = null;
            }

            cast5.HowToGetFundChoices = () => _injectedVisitee.InvFundChoices;

            if (cast5.BindableProperty == null)
            {
                cast5.BindableProperty = new BindableFundChoice { SurrogateKey = -1 };
            }
        }

        public void Initialize(CapturedDisinvestment cast6)
        {
            if (cast6 == null) return;

            if (cast6.SurrogateKey != _injectedVisitee.TemporaryDisinvestment?.SurrogateKey)
            {
                _injectedVisitee.TemporaryDisinvestment = null;
            }

            string[] chosenChoices = _injectedVisitee.Investments.Select(_ => _.FundDescId).ToArray();

            cast6.HowToGetFundChoices = () => _injectedVisitee.InvFundChoices.Where(_ => chosenChoices.Contains(_.FundId)).ToArray();

            if (cast6.BindableProperty == null)
            {
                cast6.BindableProperty = new BindableFundChoice { SurrogateKey = -1 };
            }
        }


        public void Initialize(CapturedTransferValueIn cast7)
        {
            if (cast7 == null) return;

            if (cast7.SurrogateKey != _injectedVisitee.TemporaryTvIn?.SurrogateKey)
            {
                _injectedVisitee.TemporaryTvIn = null;
            }
        }


        public void Initialize(DummyAdviserCharge model)
        {
            if (model == null) return;

            if ( _injectedVisitee.AdviserCharges == null)
            {
                new BriaAdhocModelBuilder(_injectedVisitee).BuildExistingAdviserCharges( AdvisorFeeCodes.InitialOneOff );
            }

            Debug.Assert(_injectedVisitee.AdviserCharges != null) ;
        }

        public void Initialize(CapturedAdviserCharge cast8)
        {
            if (cast8 == null) return;

            if (cast8.SurrogateKey != _injectedVisitee.TemporaryAdviserCharge?.SurrogateKey)
            {
                _injectedVisitee.TemporaryAdviserCharge = null;
            }
        }

    }
}
