﻿extern alias PDI;
extern alias WCF;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.Logic.Internal;
using Dcorum.BusinessLayer.BRIA.ViewAssistance;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;

namespace Dcorum.BusinessLayer.BRIA.Logic
{
    using ExternalIllustrationActor = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;
    using WcfRepository = WCF::WcfBusiness.Illustrations.Illustration.Entities.DecumMessageRepositoryData ;
    using WcfMessageParams = WCF::WcfBusiness.Illustrations.Illustration.Entities.MessageParams ;

    /// <summary>
    /// [COMMAND] Assimilate view model state back into the external illustration actor just prior to submission.
    /// </summary>
    public class BriaAdhocPreSubmissionProjector
    {
        //to change once business info is made available!!!
        private const string CrystalisedKey = "crystalised";
        private const string UncrystalisedKey = "uncrystalised";
        private const string TaxFreeCashKey = "taxFreeCashAmount";

        private BriaAdhocPureGraph AdhocViewGraphSource ;

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public BriaAdhocPreSubmissionProjector( BriaAdhocPureGraph adhocViewGraphSource)
        {
            AdhocViewGraphSource = adhocViewGraphSource ;
        }

        public void ProjectOnto(ExternalIllustrationActor wcfModelIn )
        {
            if ( wcfModelIn == null) return;
            var source = AdhocViewGraphSource ;

            Debug.Assert(wcfModelIn.IsCapturedDataExpected());

            wcfModelIn.Repository.TransferIns = wcfModelIn.Repository.TransferIns
                ?? new List<PDI::Interfaces.Services.MemberDetailCommon.benefitCrystalisationEventType>();

            Debug.Assert(wcfModelIn.Repository.TransferIns != null);

            //personal details update
            if (source.Start.CaseMemberKey <= 0 && source.MemberDetail != null)
            {
                RefCodeHelp.DoBuildRefCodes(source.MemberDetail);

                wcfModelIn.PersonalDetails.DOB = source.MemberDetail.Dob.Value;
                wcfModelIn.PersonalDetails.Forename = ValueCompare(wcfModelIn.PersonalDetails.Forename, source.MemberDetail.FirstName);
                wcfModelIn.PersonalDetails.Sex = ValueCompare(wcfModelIn.PersonalDetails.Sex, source.MemberDetail.Gender.Descript);
                wcfModelIn.PersonalDetails.Surname = ValueCompare(wcfModelIn.PersonalDetails.Surname, source.MemberDetail.Surname);
                wcfModelIn.PersonalDetails.Title = ValueCompare(wcfModelIn.PersonalDetails.Title, (source.MemberDetail.Title != null) ?
                    source.MemberDetail.Title.Descript : null);
            }

            //Disinvestment
            if (source.Disinvestments != null)
            {
                foreach (var modelNow in wcfModelIn.Disinvestments)
                {
                    var toIgnore = source.Disinvestments.FirstOrDefault(_ =>
                        _.FundDescId == modelNow.fund.id
                        );

                    if (toIgnore != null) continue;

                    wcfModelIn.RemoveDisinvestment(modelNow.fund.id);
                }

                //update or add
                foreach (var viewNow in source.Disinvestments)
                {
                    var toUpdate = wcfModelIn.Disinvestments.FirstOrDefault(_ =>
                        _.fund.id == viewNow.FundDescId
                        );

                    if (toUpdate != null)
                    {
                        toUpdate.percentage = viewNow.Percent.ToString();
                    }
                    else
                    {
                        wcfModelIn.AddDisinvestment(new PDI::Interfaces.Services.Common.fundAllocationType()
                        {
                            fund = new PDI::Interfaces.Services.Common.fundType()
                            {
                                id = viewNow.FundDescId
                            },
                            percentage = viewNow.Percent.ToString()
                        });
                    }
                }
            }

            if (source.TaxFreeCash != null)
            {
                var assistant1 = new IncomeCalculationAssistant(source);

                var toAdd = new PDI::Interfaces.Services.MemberDetailCommon.benefitCrystalisationEventType()
                {
                    provider = null,
                    bceAmount = assistant1.CalculateTotalTaxFreeCash(),
                    bceType = TaxFreeCashKey
                };

                wcfModelIn.Repository.TransferIns.Add(toAdd);
            }

            //Investment
            if (source.Investments != null)
            {
                //remove
                foreach (var modelNow in wcfModelIn.Investments)
                {
                    var toIgnore = source.Investments.FirstOrDefault(_ =>
                        modelNow.FundId == _.FundDescId
                        && modelNow.IsLifestyle == _.IsLifeStyle);

                    if (toIgnore != null) continue;

                    wcfModelIn.RemoveInvestment(modelNow.FundId);
                }

                //update or add
                foreach (var viewNow in source.Investments)
                {
                    var toUpdate = wcfModelIn.Investments.FirstOrDefault(_ =>
                       _.FundId == viewNow.FundDescId
                       && _.IsLifestyle == viewNow.IsLifeStyle);

                    if (toUpdate != null)
                    {
                        toUpdate.Percent = viewNow.Percent;
                    }
                    else
                    {
                        wcfModelIn.AddInvestment(new WCF::WcfBusiness.Illustrations.Illustration.Entities.Election()
                        {
                            FundId = viewNow.FundDescId,
                            IsLifestyle = viewNow.IsLifeStyle,
                            Percent = viewNow.Percent
                        });
                    }
                }
            }

            //Income
            if (source.Income != null)
            {
                RefCodeHelp.DoBuildRefCodes(source.Income);
                var target1 = wcfModelIn.Repository.IncomeDetail;

                if (target1 != null && (target1.hasRegularIncome || target1.hasAdhocIncome))
                {
                    target1.incomeFrequency = (PDI::Interfaces.Enums.IncomeFrequencyType)source.Income.Frequency.RefCd.IntoIntN().GetValueOrDefault();
                    target1.escalationPct = source.Income.IncreasePercent.GetValueOrDefault();

                    target1.grossRegularIncome = source.Income.RegularAmount.GetValueOrDefault();
                    target1.grossAdhocIncomeAmount = source.Income.OneOffAmount.GetValueOrDefault();

                    target1.escalation = source.Income.Escalation.Descript;

                    //var destIncomeTypeObject = wcfModelIn.Repository.RetirementOptions.income;

                    target1.source = new PDI::Interfaces.Services.Common.incomeSourceOptionType()
                    {
                        code = source.Income.IncomePriority.RefCd.IntoIntN().GetValueOrDefault(),
                        description = source.Income.IncomePriority.Descript,
                        selected = true
                    };
                }
            }

            if (source.TvIns != null && source.TvIns.Any())
            {
                var manyToAdd = source.TvIns.SelectMany( 
                    tr => YieldTransferInPair(tr, source.AdviserCharges?.FirstOrDefault(ac => ac.SurrogateTranferInForeignKey == tr.SurrogateKey ))
                    ).ToArray() ;
                  
                wcfModelIn.Repository.TransferIns.AddRange(manyToAdd);
            }
        }


        public void ProjectAdviserChargesOnto(WcfMessageParams receiver)
        {
            if (AdhocViewGraphSource?.AdviserCharges?.Any() == true)
            {
                AddCharges(receiver, AdhocViewGraphSource.AdviserCharges);
            }
        }


        private void AddCharges(WcfMessageParams toMutate, IEnumerable<CapturedAdviserCharge> source)
        {    
            toMutate.AdviserCharges = source.Select(each1 => ConvertCharge(each1)).Where( _ => _ != null).ToArray() ; 
        }


        private WCF::WcfBusiness.Illustrations.Illustration.Entities.AdviserCharge ConvertCharge(CapturedAdviserCharge source)
        {
            if (source.SurrogateTranferInForeignKey > 0) return null; //Adviser Fee Initial One Off handled by transferIn collection!

            var creation1 = new WCF::WcfBusiness.Illustrations.Illustration.Entities.AdviserCharge()
            {
                AdviserKey = source.SurrogateKey,
                CaseMbrKey = 0,
                TransactionCode = source.ChargeTypeCode.IntoIntN().GetValueOrDefault(),
                ChargeDescription = source.ChargeTypeDescription,
                Charge = (source.Percentage ?? source.Amount).Value,
                IsPercentage = (source.Percentage.HasValue),
                LastChargeDate = null,
                NextChargeDate = null,
                ExpiryDate = null //source.ExpiryDate,

            };

            return creation1 ;
        }

        /// <summary>
        /// Emit a pair of objects: one crystalized, the other uncrystalised.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="optionalCharge"></param>
        /// <returns></returns>
        private IEnumerable<PDI::Interfaces.Services.MemberDetailCommon.benefitCrystalisationEventType> YieldTransferInPair(CapturedTransferValueIn source, CapturedAdviserCharge optionalCharge)
        {
            decimal[] feeSplit = new AdviserFeeAssistant().CalculateFeeSplit(source, optionalCharge).ToArray() ;
            if (feeSplit?.Any() != true) feeSplit = null ;

            var toAdd1 = new PDI::Interfaces.Services.MemberDetailCommon.benefitCrystalisationEventType()
            {
                provider = source.From,
                bceAmount = source.CrystallizedFundValue,
                bceType = CrystalisedKey,
                policyReference = source.SchemeType,
                AdviserCharge = feeSplit?[0] ?? 0,
                AdviserChargeInPercent = false
            };

            var toAdd2 = new PDI::Interfaces.Services.MemberDetailCommon.benefitCrystalisationEventType()
            {
                provider = source.From,
                bceAmount = source.UncrystallizedFundValue ,
                bceType = UncrystalisedKey,
                policyReference = source.SchemeType,
                AdviserCharge = feeSplit?[1] ?? 0,
                AdviserChargeInPercent = false
            };

            yield return toAdd1;
            yield return toAdd2;
        }



        private static T ValueCompare<T>(T t1, T t2)
            where T:class
        {
            return (t2 !=null && !t2.Equals(t1)) ? t2 : t1;
        }
    }
}
