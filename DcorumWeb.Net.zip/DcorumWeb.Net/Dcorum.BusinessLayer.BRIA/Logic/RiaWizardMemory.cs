﻿//extern alias WCF;
//using Dcorum.BusinessLayer.BRIA.Contractual;
//using Dcorum.BusinessLayer.BRIA.Creational;
//using Dcorum.BusinessLayer.BRIA.Entities;
//using DCorum.BusinessFoundation.Bases;
//using Dcorum.Utilities.Practices;

//using System;
//using System.Diagnostics;

//namespace Dcorum.BusinessLayer.BRIA.Logic
//{
//    using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;

//    public class RiaWizardMemory : IDisposable
//    {
//        internal protected RiaWizardMemory(Func<IBriaAdhocControllerIdentity> owner)
//        {
//            IllustrationSessionCaretaker = new SessionCaretakerSealed<DecumIllustrationSession>(() => SuggestTemporaryKeyForIllustrationSession(), () => MyFactory1.CreateIllustrationSession(Owner.CaseKey, Owner.CaseMemberKey));
//            ViewGraphCaretaker = new SessionCaretakerSealed<BriaAdhocViewGraph>(() => SuggestTemporaryKeyForViewGraph(), () => MyFactory1.CreateViewGraph(WcfIllustrationSession));

//            DeferredOwner = new Lazy<IBriaAdhocControllerIdentity>(owner);
//            if (DeferredOwner == null) throw new ArgumentNullException(nameof(owner));

//            DeferredWcfIllustrationSession = new Lazy<DecumIllustrationSession>(() => IllustrationSessionCaretaker.Obtain());
//            DeferredViewGraph = new Lazy<BriaAdhocViewGraph>(() => ViewGraphCaretaker.Obtain());
//        }

//        private BriaFactoryMethods MyFactory1 { get; } = BriaFactoryMethods.Singleton;

//        private Lazy<IBriaAdhocControllerIdentity> DeferredOwner { get; }
//        private IBriaAdhocControllerIdentity Owner { get { return DeferredOwner.Value; } }


//        private SessionCaretakerSealed<DecumIllustrationSession> IllustrationSessionCaretaker { get; }
//        private SessionCaretakerSealed<BriaAdhocViewGraph> ViewGraphCaretaker { get; }


//        private Lazy<DecumIllustrationSession> DeferredWcfIllustrationSession { get; }
//        public Lazy<BriaAdhocViewGraph> DeferredViewGraph { get; }


//        private bool IsOwnerReady()
//        {
//            bool ready = (Owner.CaseMemberKey >= 0 && Owner.CaseKey > 0);
//            return ready;
//        }

//        private string SuggestTemporaryKeyForIllustrationSession()
//        {
//            if (IsOwnerReady() == false) return null;
//            return typeof(DecumIllustrationSession).FullName + "||" + ((Owner.CaseMemberKey > 0) ? Owner.CaseMemberKey : Owner.CaseKey);
//        }


//        private string SuggestTemporaryKeyForViewGraph()
//        {
//            if (IsOwnerReady() == false) return null;

//            int part = Owner.CaseKey;

//            if (Owner.CaseMemberKey > 0) part = Owner.CaseMemberKey;

//            if (Owner.CaseKey != WcfIllustrationSession.CaseKey) part = default(int);

//            return typeof(BriaAdhocViewGraph).FullName + "||" + part;
//        }


//        public virtual void Dispose()
//        {
//            IllustrationSessionCaretaker.Dispose();
//            ViewGraphCaretaker.Dispose();
//        }


//        public DecumIllustrationSession WcfIllustrationSession { get { return DeferredWcfIllustrationSession.Value; } }
//        public BriaAdhocViewGraph ViewGraph { get { return DeferredViewGraph.Value; } }
//    }

//    /// <summary>
//    /// [TEMPLATE]
//    /// Obtains item either by retrieval or creation as well as being able to discard a previously retrieved item.
//    /// </summary>
//    public sealed class SessionCaretakerSealed<TCreation> : SessionCaretakerBase, IDisposable
//        where TCreation : class
//    {
//        public SessionCaretakerSealed(Func<string> deferredKey, Func<TCreation> creationTechnique)
//        {
//            DeferredKey = deferredKey;
//            if (DeferredKey == null) throw new ArgumentException(nameof(deferredKey));

//            CreationTechnique = new Lazy<TCreation>(creationTechnique);
//            if (CreationTechnique == null) throw new ArgumentException(nameof(creationTechnique));
//        }

//        Func<string> DeferredKey { get; }
//        Lazy<TCreation> CreationTechnique { get; }

//        string storageKey;

//        /// <summary>
//        /// [TEMPLATE METHOD]
//        /// </summary>
//        public TCreation Obtain()
//        {
//            storageKey = DeferredKey();
//            if (storageKey == null) throw new InvalidOperationException("Cannot retrieve a null key for " + typeof(TCreation).Name);
//            var result = Storage[storageKey] as TCreation;

//            if (result != null) return result;
//            Debug.Assert(result == null);

//            var creation1 = CreationTechnique.Value;

//            storageKey = DeferredKey();
//            if (storageKey == null) throw new InvalidOperationException("Cannot add a null key for " + typeof(TCreation).Name);
//            Storage.Add(storageKey, creation1);
//            return creation1;
//        }

//        /// <summary>
//        /// [TEMPLATE METHOD]
//        /// </summary>
//        public void Dispose()
//        {
//            storageKey.SafeAction(_ => Storage.Remove(_));
//            DeferredKey().SafeAction(_ => Storage.Remove(_));
//        }
//    }

//}
