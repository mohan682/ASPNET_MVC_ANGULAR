﻿extern alias WCF;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.ViewAssistance;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.BRIA.Logic
{
    using Validation;
    using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;

    /// <summary>
    /// [READONLY-STATE]
    /// </summary>
    public class BriaAdhocCommandReceiver : IContainerCommandReceiver
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public BriaAdhocCommandReceiver(BriaAdhocViewGraph toVisit, DecumIllustrationSession illustrationActor)
        {
            _injectedIllustrationActor = illustrationActor;
            _injectedVisitee = toVisit;
            MyRiaValidator = new RiaValidationsCommandFactory(toVisit) ;                
        }

        private DecumIllustrationSession _injectedIllustrationActor;
        private readonly BriaAdhocViewGraph _injectedVisitee;
        private RiaValidationsCommandFactory MyRiaValidator { get; }

        public TModel CreatePossibleAddition<TModel>()
            where TModel : class
        {
            Type ofModel = typeof (TModel);

            if (ofModel == typeof (CapturedTransferValueIn))
            {
                if (_injectedVisitee.TemporaryTvIn == null)
                {
                    _injectedVisitee.TemporaryTvIn = new CapturedTransferValueIn
                    {
                        SurrogateKey = new[] {0}.Concat(_injectedVisitee.TvIns.Select(_ => _.SurrogateKey)).Max() + 1
                    };
                }
                return _injectedVisitee.TemporaryTvIn as TModel;
            }

            if (ofModel == typeof (CapturedInvestment))
            {
                if (_injectedVisitee.TemporaryInvestment == null)
                {
                    _injectedVisitee.TemporaryInvestment = new CapturedInvestment
                    {
                        SurrogateKey = new[] {0}.Concat(_injectedVisitee.Investments.Select(_ => _.SurrogateKey)).Max() + 1
                    };
                }
                return _injectedVisitee.TemporaryInvestment as TModel;
            }

            if (ofModel == typeof (CapturedDisinvestment))
            {
                if (_injectedVisitee.TemporaryDisinvestment == null)
                {
                    _injectedVisitee.TemporaryDisinvestment = new CapturedDisinvestment
                    {
                        SurrogateKey = new[] {0}.Concat(_injectedVisitee.Disinvestments.Select(_ => _.SurrogateKey)).Max() + 1
                    };
                }
                return _injectedVisitee.TemporaryDisinvestment as TModel;
            }

            if (ofModel == typeof(CapturedAdviserCharge))
            {
                if (_injectedVisitee.TemporaryAdviserCharge == null)
                {
                    _injectedVisitee.TemporaryAdviserCharge = new CapturedAdviserCharge
                    {
                        SurrogateKey = new[] { 0 }.Concat(_injectedVisitee.AdviserCharges.Select(_ => _.SurrogateKey)).Max() + 1
                    };
                }
                return _injectedVisitee.TemporaryAdviserCharge as TModel;
            }

            return null;
        }


        public bool TrySave<TModel>(TModel toAdd)
            where TModel : class
        {
            if (toAdd == null) return false;

            var cast2 = toAdd as CapturedStart;
            if (cast2 != null)
            {
                _injectedIllustrationActor.BuildPart2(_injectedVisitee.Start.IllustrationOption.GetWcfIllustrationType());

                int rebuiltTally = _injectedVisitee.Rebuild(cast2.IllustrationOption);

                new BriaAdhocModelBuilder( _injectedVisitee ).BuildDateAffectedParts( _injectedIllustrationActor );

                _injectedVisitee.IllustrationResponse.WizardModeOn = true;

                return true;
            }


            var toAddCast1a = toAdd as CapturedMemberDetail;

            if (toAddCast1a != null)
            {
                RefCodeHelp.DoBuildRefCodes(toAddCast1a);
            }


            var toAddCast1 = toAdd as CapturedTransferValueIn;

            if (toAddCast1 != null)
            {
                if (_injectedVisitee.TemporaryTvIn != null)
                {
                    Debug.Assert(ReferenceEquals(toAdd, _injectedVisitee.TemporaryTvIn));

                    Debug.Assert(toAddCast1.SurrogateKey ==
                                 new[] { 0 }.Concat(_injectedVisitee.TvIns.Select(_ => _.SurrogateKey)).Max() + 1);
                    _injectedVisitee.TvIns.Add(toAddCast1);
                    _injectedVisitee.TemporaryTvIn = null;
                }
                return true;
            }

            var toAddCast2 = toAdd as CapturedInvestment;

            if (toAddCast2 != null)
            {
                if (_injectedVisitee.TemporaryInvestment != null)
                {
                    Debug.Assert(ReferenceEquals(toAdd, _injectedVisitee.TemporaryInvestment));

                    Debug.Assert(toAddCast2.SurrogateKey ==
                                 new[] { 0 }.Concat(_injectedVisitee.Investments.Select(_ => _.SurrogateKey)).Max() + 1);
                    _injectedVisitee.Investments.Add(toAddCast2);
                    _injectedVisitee.TemporaryInvestment = null;
                }
                return true;
            }

            var toAddCast3 = toAdd as CapturedDisinvestment;

            if (toAddCast3 != null)
            {
                if (_injectedVisitee.TemporaryDisinvestment != null)
                {
                    Debug.Assert(ReferenceEquals(toAdd, _injectedVisitee.TemporaryDisinvestment));

                    Debug.Assert(toAddCast3.SurrogateKey ==
                                 new[] { 0 }.Concat(_injectedVisitee.Disinvestments.Select(_ => _.SurrogateKey)).Max() + 1);
                    _injectedVisitee.Disinvestments.Add(toAddCast3);
                    _injectedVisitee.TemporaryDisinvestment = null;
                }
                return true;
            }


            var toAddCast4 = toAdd as CapturedAdviserCharge;

            if (toAddCast4 != null)
            {
                if (_injectedVisitee.TemporaryAdviserCharge != null)
                {
                    Debug.Assert(ReferenceEquals(toAdd, _injectedVisitee.TemporaryAdviserCharge));

                    Debug.Assert(toAddCast4.SurrogateKey ==
                                 new[] { 0 }.Concat(_injectedVisitee.AdviserCharges.Select(_ => _.SurrogateKey)).Max() + 1);
                    _injectedVisitee.AdviserCharges.Add(toAddCast4);
                    _injectedVisitee.TemporaryAdviserCharge = null;
                }
                return true;
            }

            
            var cast1 = toAdd as CapturedSummary;
            if (cast1 != null)
            {
                Debug.Assert(_injectedIllustrationActor.CanQueue());

                var preQueueProjector = new BriaAdhocPreSubmissionProjector(_injectedVisitee);
                preQueueProjector.ProjectAdviserChargesOnto(_injectedIllustrationActor.Message);

                if (_injectedIllustrationActor.IsCapturedDataExpected())
                {
                    preQueueProjector.ProjectOnto(_injectedIllustrationActor);
                }

                _injectedVisitee.IllustrationResponse.QueueId = _injectedIllustrationActor.PushMessageOntoServiceTaskQueue();

                return _injectedVisitee.IllustrationResponse.QueueId > 0;
            }


            var cast3 = toAdd as ViewIllustrationResponse;
            if (cast3 != null)
            {
                _injectedIllustrationActor.QueuedSession.AcceptIllustration();
                return true;
            }

            return false;
        }


        public bool TryRemove<TModel>(TModel toRemove)
            where TModel : class
        {
            if (toRemove == null) return false;

            var toAddCast1 = toRemove as CapturedTransferValueIn;

            if (toAddCast1 != null)
            {
                Debug.Assert(_injectedVisitee.TemporaryTvIn == null);
                _injectedVisitee.TvIns.Remove(toAddCast1);
                return true;
            }

            var toAddCast2 = toRemove as CapturedInvestment;

            if (toAddCast2 != null)
            {
                Debug.Assert(_injectedVisitee.TemporaryTvIn == null);
                _injectedVisitee.Investments.Remove(toAddCast2);
                return true;
            }

            var toAddCast3 = toRemove as CapturedDisinvestment;

            if (toAddCast3 != null)
            {
                Debug.Assert(_injectedVisitee.TemporaryTvIn == null);
                _injectedVisitee.Disinvestments.Remove(toAddCast3);

                _injectedVisitee.DummyDisinvestment.SameAsInvestmentsFlag = !_injectedVisitee.Disinvestments.Any();
                return true;
            }

            var toAddCast4 = toRemove as CapturedAdviserCharge;

            if (toAddCast4 != null)
            {
                Debug.Assert(_injectedVisitee.TemporaryAdviserCharge == null);

                //if (toAddCast4.SurrogateTranferInForeignKey > 0)
                //{
                //    var toMutate1 = _injectedVisitee.TvIns.FirstOrDefault(_ => _.SurrogateKey == toAddCast4.SurrogateTranferInForeignKey);

                //    if (toMutate1!=null)
                //    {
                //        toMutate1.ChargeAmount = null;
                //        toMutate1.ChargePercentage = null;
                //    }
                //} 
                bool success = _injectedVisitee.AdviserCharges.Remove(toAddCast4);
                return success;
            }
            

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        public IEnumerable<Tuple<PropertyInfo, string>> Validate<TModel>(TModel toValidate)
            where TModel : class
        {
            if (toValidate == null) return new Tuple<PropertyInfo, string>[] { };


            ValidationsCommand validationCommand0 = MyRiaValidator.CreateValidationsCommandFor( toValidate as CapturedStart );

            if (validationCommand0 != null)
            {
                return MyRiaValidator.Validate(validationCommand0).ToArray();
            }
            

            var cast5 = toValidate as DummyTransferValue;
            if (cast5 != null)
            {
                return _injectedVisitee.TvIns.Validate(_injectedVisitee);
            }

            var cast1 = toValidate as CapturedTransferValueIn;
            if (cast1 != null)
            {
                return cast1.Validate();
            }

            CapturedTaxFreeCash cast2 = toValidate as CapturedTaxFreeCash;
            if (cast2 != null)
            {
                return cast2.Validate();
            }

            var cast3 = toValidate as DummyInvestment;
            if (cast3 != null)
            {
                return _injectedVisitee.Investments.Validate();
            }

            var cast4 = toValidate as DummyDisinvestment;
            if (cast4 != null)
            {
                return _injectedVisitee.Disinvestments.Validate(_injectedVisitee);
            }

            var cast6 = toValidate as DummyAdviserCharge;
            if (cast6 != null)
            {
                IEnumerable<Tuple<PropertyInfo, string>> results = Enumerable.Empty<Tuple<PropertyInfo, string>>();

                ValidationsCommand validationCommand = MyRiaValidator.CreateValidationsCommandFor(cast6);

                if (validationCommand != null)
                {
                    results = MyRiaValidator.Validate(validationCommand).ToArray();
                }

                if (results.Any()) return results;

                foreach(var chargeNow in _injectedVisitee.AdviserCharges)
                {
                    validationCommand = MyRiaValidator.CreateValidationsCommandFor(chargeNow);

                    if (validationCommand != null)
                    {
                        results = MyRiaValidator.Validate(validationCommand).ToArray();

                        if (results.Any()) return results;
                    }
                }

                return results;
            }

            var cast7 = toValidate as CapturedAdviserCharge;
            if (cast7 != null)
            {
                ValidationsCommand validationCommand = MyRiaValidator.CreateValidationsCommandFor(cast7);

                if (validationCommand != null)
                {
                    return MyRiaValidator.Validate(validationCommand).ToArray() ;
                }
            }

            return new Tuple<PropertyInfo, string>[] { };
        }

        /// <summary>
        /// For a specified sub entity, assign dervived non editable properties using this outer model as the source.
        /// </summary>
        public bool TryInitialize<TModel>(TModel toModify)
            where TModel : class
        {
            if (toModify == null) return false;

            var vistor1 = new RiaInitializationVisitor( new RiaInitializationFlavours( _injectedVisitee, _injectedIllustrationActor) );
            bool success = vistor1.TryVisit(toModify);
            return success;
        }

        /// <summary>
        /// Provides and opportunity for derived classes to facade/adapt the model object graph prior to tabular presentation.
        /// </summary>
        public object IntoAnonymousType<TModel>(TModel toFacade)
            where TModel :class
        {
            var visitor1 = new RiaViewRowVisitor( new RiaViewRowFlavours() ) ;

            var result = visitor1.GetViewRowCommandFor(toFacade)?.Invoke() ?? toFacade ;

            return result ;
        }

        /// <summary>
        /// Respond to a non-trivial, non-button UI postback. E.G. to maintain model integrity. 
        /// </summary>
        public bool TryToCascadeChange<TModel>(TModel toModify, PropertyInfo changeOrigin)
             where TModel : class
        {
            if (changeOrigin == null || toModify == null) return false;

            var cast1 = toModify as CapturedStart;

            if (cast1 != null)
            {
                if (changeOrigin.DoesPropertyMatch(cast1, _ => _.EffectiveDate))
                {
                    Debug.Assert(ReferenceEquals(cast1, _injectedVisitee.Start));

                    _injectedIllustrationActor.BuildPart1(cast1.CaseMemberKey,cast1.CaseKey, cast1.EffectiveDate );
       
                    new BriaAdhocModelBuilder(_injectedVisitee ).BuildStart( _injectedIllustrationActor.Message );

                    return true;
                }
            }

            return false;
        }
    }
}
