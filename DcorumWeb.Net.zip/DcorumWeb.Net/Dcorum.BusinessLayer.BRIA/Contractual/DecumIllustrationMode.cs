﻿extern alias WCF;
using System;
using System.ComponentModel;
using System.Linq;

namespace Dcorum.BusinessLayer.BRIA.Contractual
{
    using MessageParams = WCF::WcfBusiness.Illustrations.Illustration.Entities.MessageParams;


    public enum DecumIllustrationMode
    {
        [Description("Annual Review")] AnnualReview,

        [Description("Existing member with changes")] ExistingMemberWithChanges,

        [Description("Existing member (no changes)")] ExistingMemberWithoutchanges,

        [Description("Existing member transfer-in with changes ")] ExistingMemberTransferInWithChanges,

        [Description("Existing member transfer-in (no changes)")] ExistingMemberTransferInWithoutChanges,

        [Description("Re-create new business illustration")] ReCreateNewBusinessIllustration
    }

    /// <summary>
    /// [STATELESS]
    /// </summary>
    public static class DecumIllustrationModeHelper
    {
        private static readonly DecumIllustrationMode[] TransferInModes =
            {
                DecumIllustrationMode.ExistingMemberTransferInWithChanges,
                DecumIllustrationMode.ExistingMemberTransferInWithoutChanges
            };

        private static readonly DecumIllustrationMode[] WithChangesModes =
            {
                DecumIllustrationMode.ExistingMemberTransferInWithChanges,
                DecumIllustrationMode.ExistingMemberTransferInWithChanges
            };


        public static bool IsTransferInMode(this DecumIllustrationMode? toCheck)
        {
            if (toCheck == null) return false;
            return TransferInModes.Contains(toCheck.Value);
        }


        public static bool IsWithChangesMode(this DecumIllustrationMode? toCheck)
        {
            if (toCheck == null) return false;
            return WithChangesModes.Contains(toCheck.Value);
        }


        public static bool IsTransferInMode(this DecumIllustrationMode toCheck)
        {
            return TransferInModes.Contains(toCheck);
        }


        public static bool IsWithChangesMode(this DecumIllustrationMode toCheck)
        {
            return WithChangesModes.Contains(toCheck);
        }


        public static MessageParams.BRIllustrationType GetWcfIllustrationType(this DecumIllustrationMode toConvert)
        {
            switch (toConvert)
            {
                case DecumIllustrationMode.AnnualReview:
                    return MessageParams.BRIllustrationType.AnnualReview;
                case DecumIllustrationMode.ExistingMemberTransferInWithChanges:
                    return MessageParams.BRIllustrationType.ExistingMemberTransferInWithChanges;
                case DecumIllustrationMode.ExistingMemberTransferInWithoutChanges:
                    return MessageParams.BRIllustrationType.ExistingMemberTransferInWithoutChanges;
                case DecumIllustrationMode.ExistingMemberWithChanges:
                    return MessageParams.BRIllustrationType.ExistingMemberWithChanges;
                case DecumIllustrationMode.ExistingMemberWithoutchanges:
                    return MessageParams.BRIllustrationType.ExistingMemberWithoutchanges;
                case DecumIllustrationMode.ReCreateNewBusinessIllustration:
                    return MessageParams.BRIllustrationType.ReCreateNewBusinessIllustration;

                default:
                    throw new InvalidOperationException();
            }
        }
    }

}
