﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.BRIA.Contractual
{
    public static class Values
    {
        public const decimal MaxTaxFreePercent = 25.0m;
        public const double MaxTaxFreePercentAsDouble = 25.0;

        public const decimal MaxTaxFreeCoeff = (MaxTaxFreePercent / 100m);
        public const double MaxTaxFreeCoeffAsDouble = (MaxTaxFreePercentAsDouble/100);
    }
}
