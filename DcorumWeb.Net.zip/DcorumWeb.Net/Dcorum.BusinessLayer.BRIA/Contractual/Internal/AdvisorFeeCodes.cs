﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Diagnostics;
using static Dcorum.BusinessLayer.BRIA.Contractual.Internal.AdvisorFeeCodes;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.BRIA.Contractual.Internal
{
    
    public enum AdvisorFeeCodes
    {
        Ongoing = 4083,
        RegularFixedTerm = 4081,
        InitialOneOff = 4080,
        Adhoc = 4084,
        PensionAdviceAllowance = 4082
    }

    public static class AdvisorFeeCodesExtensions
    {
        internal static Dictionary<DecumIllustrationMode, AdvisorFeeCodes[]> NewDefaultAdvisorFeeCodesMap => new Dictionary<DecumIllustrationMode, AdvisorFeeCodes[]>()
        {
            [DecumIllustrationMode.AnnualReview] = new[] { Ongoing },
            [DecumIllustrationMode.ReCreateNewBusinessIllustration] = new[] { Ongoing, InitialOneOff },
            [DecumIllustrationMode.ExistingMemberWithoutchanges] = new[] { Ongoing, Adhoc },
            [DecumIllustrationMode.ExistingMemberWithChanges] = new[] { Ongoing, Adhoc },
            [DecumIllustrationMode.ExistingMemberTransferInWithChanges] = new[] { Ongoing, InitialOneOff },
            [DecumIllustrationMode.ExistingMemberTransferInWithoutChanges] = new[] { Ongoing, InitialOneOff }
        };

        /// <summary>
        /// [DERIVES]
        /// </summary>
        public static Dictionary<DecumIllustrationMode, string[]> DeriveDefaultKeyedAdvisorFeeCodeSets => NewDefaultAdvisorFeeCodesMap.ToDictionary(_ => _.Key, _ => _.Value.Select(afc => ((int)afc).ToString()).ToArray() ) ;


        //https://confluence.aegon.co.uk/pages/viewpage.action?pageId=229083790 business rules.
        internal static IEnumerable<KeyValuePair<AdvisorFeeCodes, int>> YieldAdviserFeeCodeMaxPermittedCountPairsFor( DecumIllustrationMode illustrationMode )
        {
            var pool1 = new HashSet<AdvisorFeeCodes>( Enum.GetValues(typeof(AdvisorFeeCodes)).Cast<AdvisorFeeCodes>() );

            var AllowedAdviserFeeCodes = NewDefaultAdvisorFeeCodesMap[illustrationMode] ;

            Debug.Assert( pool1.IsSupersetOf( AllowedAdviserFeeCodes) );

            foreach (var current1 in AllowedAdviserFeeCodes )
            {
                yield return new KeyValuePair<AdvisorFeeCodes, int>(current1, 1); //maximum of 1 {0} allowed[for this kind of illustration]!
                pool1.Remove(current1);
            }

            foreach(var current1 in pool1)
            {
                yield return new KeyValuePair<AdvisorFeeCodes, int>(current1, 0); //non of this type of adviser fee allowed for this kind of illustration!
            }
        }


        internal static IEnumerable<AdvisorFeeCodes> PerTransferInFeeCodes(DecumIllustrationMode illustrationMode)
        {
            if (illustrationMode.IsTransferInMode()) yield return InitialOneOff ;
            yield break;
        }


        internal static bool DoesContain( this IEnumerable<AdvisorFeeCodes> codes, string codeToConsider)
        {
            int? myNumericCode = codeToConsider.IntoIntN();

            if (myNumericCode == null) return false;

            int[] numericCodes = codes.Select(_ => (int)_).ToArray();

            bool match1 = numericCodes.Contains(myNumericCode.Value);

            return match1;
        }
    }

}
