﻿namespace Dcorum.BusinessLayer.BRIA.Contractual.Internal
{
    internal interface IUncrystallizedProperties
    {
       decimal? TfcPercentage { get; }
       decimal? TfcAmount { get; }

       decimal UncrystallizedFundValue { get; }
    }
}
