﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dcorum.BusinessLayer.BRIA.Contractual
{
    public interface IBriaAdhocControllerIdentity
    {
        int CaseKey { get; }
        int CaseMemberKey { get; }
        int? ExistingQueueId { get; }
    }
}
