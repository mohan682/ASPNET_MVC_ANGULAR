﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.DataAccess;

namespace Dcorum.BusinessLayer.BRIA.DataAccess
{
    public class DLServiceTaskQueueLogEntry : ICrudOut<ServiceTaskQueueLogEntry>
    {
        public ServiceTaskQueueLogEntry SelectViaPrimaryKey(int primaryKey)
        {
            const string template1 = @"
    select * 
        from SERVICE_TASK_QUEUE_LOG
    where 
        SERVICE_TASK_QUEUE_LOG_ID    = {0}
    ";
            string sql1 = string.Format( template1, primaryKey );

            return DataAccessHelp.GetSingle(sql1, Make) ;
        }

        public ServiceTaskQueueLogEntry[] SelectManyViaParentKey(int parentKey = 0, string appendWhereClauseWith = null)
        {
            const string template1 = @"
    select * 
        from SERVICE_TASK_QUEUE_LOG
    where 
        SERVICE_TASK_QUEUE_ID = {0}
    order by
        SERVICE_TASK_QUEUE_LOG_ID desc
    ";
            string sql1 = string.Format(template1, parentKey);

            return DataAccessHelp.GetMany(sql1, Make);
        }

        private ServiceTaskQueueLogEntry Make(IDataReader reader)
        {
            var result = new ServiceTaskQueueLogEntry();
            ServiceTaskQueueLogEntry.Build(result, reader);
            return result;
        }

    }
}
