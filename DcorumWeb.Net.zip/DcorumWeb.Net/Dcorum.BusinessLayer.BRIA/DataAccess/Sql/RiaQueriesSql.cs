﻿using Dcorum.Utilities.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.BusinessLayer.BRIA.DataAccess.Sql
{
    public class RiaQueriesSql
    {
        internal protected RiaQueriesSql()
        {

        }

        public string SelectIsDecumSchemeSQL(int caseKey)
        {
            string sqlTemplate = @"
select 
    j1.DESCRIPT 
from 
    case_data f1
    inner join ref_codes j1 on j1.ref_cd = f1.PROD_TYP_CD and j1.DOMAIN_NAME = 'DRAWDOWN PRODUCTS'
where    
    f1.case_key = {0}
";
            string result = String.Format(sqlTemplate, caseKey);
            return result;
        }


        public string SelectAdvisorChargesModeOnSQL(int caseKey)
        {
            string sqlTemplate = @"
SELECT
    count(PKDF.CASE_KEY)
FROM 
    PKG_DEF PKDF
WHERE  
    PKDF.GRP_SORT_CD IN ('200', '203', '204', '205')
    AND PKDF.CASE_KEY = {0}
";
            string result = String.Format(sqlTemplate, caseKey);
            return result;
        }


        public string SelectAdviserChargesTypesSQL(IReadOnlyList<string> trCodes)
        {
            string sqlTemplate = @"
select distinct 
    TCR.Tr_Cd, COALESCE(BSTM.Description, TCR.Tr_Cd_Desc) Descript
from 
    tr_code_rules TCR
inner join
    Ben_Stat_Transact_Map BSTM 
    on TCR.Tr_Cd = Bstm.Tr_Cd
where
    TCR.Tr_Cd in ({0})
";
            string arg0 = string.Join(", ", trCodes.Select( _ => _.SqlQuotify())) ;

            if (string.IsNullOrWhiteSpace(arg0))
            {
                arg0 = "null";
            }

            
            string result = string.Format(sqlTemplate, arg0 );
            return result;
        }
    }
}

