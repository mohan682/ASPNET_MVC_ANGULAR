﻿using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;
using Dcorum.BusinessLayer.BRIA.DataAccess.Sql;
using Dcorum.Utilities;
using Dcorum.Utilities.Extensions;
using DCorum.DataAccessFoundation.DataAccess;

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;

namespace Dcorum.BusinessLayer.BRIA.DataAccess
{
    public class RiaQueries
    {
        public static readonly RiaQueries Default = new RiaQueries(new RiaQueriesSql(), new DataAccessContext(), null );

        internal protected RiaQueries( RiaQueriesSql sqlMaker, IDbFetcherProxy dbProxy, NameValueCollection configSource)
        {
            MySqlMaker = sqlMaker;
            if (MySqlMaker == null) throw new ArgumentNullException(nameof(sqlMaker)) ;

            MyFetcher = dbProxy;
            if (MyFetcher == null) throw new ArgumentNullException(nameof(dbProxy));

            ConfigSource = configSource; //optional
        }

        private RiaQueriesSql MySqlMaker { get; }
        private IDbFetcherProxy MyFetcher { get; }
        
        private NameValueCollection ConfigSource { get; }


        public bool IsBriaScheme(int caseKey)
        {
            string sql1 = MySqlMaker.SelectIsDecumSchemeSQL( caseKey );
            var fetched1 = MyFetcher.ExecuteScalar<string>(sql1) ;

            return string.IsNullOrWhiteSpace(fetched1)==false;
        }


        public bool IsSchemeAllowedAdviserCharges(int caseKey)
        {
            string sql1 = MySqlMaker.SelectAdvisorChargesModeOnSQL(caseKey);
            int? fetched1 = MyFetcher.ExecuteScalar<int>(sql1); 

            return fetched1 > 0 ;
        }


        public string[] FetchFullAdviserFeeCodes()
        {
            string codesTextualized = ConfigSource?["BRIllustrationType.AdviserCharge.DefaultCodes"] ?? "4080|4081|4082|4083|4084";
            string[] results = codesTextualized.Split('|');
            return results;
        }


        public string[] FetchAdviserChargesTypeForIllustrationType(DecumIllustrationMode key)
        {
            var serialized1 = ConfigSource?["BRIllustrationType.AdviserCharge.Mapping"];

            var keyedCodeSets = (string.IsNullOrWhiteSpace(serialized1))
                ? AdvisorFeeCodesExtensions.DeriveDefaultKeyedAdvisorFeeCodeSets
                : (Dictionary< DecumIllustrationMode,string[]>)null //JsonConvert.DeserializeObject<Dictionary<DecumIllustrationMode, int[]>>(serialized1)
                ;

            string[] results = null ;
            bool success1 = success1 = keyedCodeSets.TryGetValue(key, out results);

            if (success1 == false) throw new ArgumentException( "Key not defined!", nameof(key) );

            return results;
        }


        public Dictionary<string, string> FetchAdviserChargeDescriptionsFor(CultureInfo forLanguage,  DecumIllustrationMode selectedIllustrationType)
        {
            string[] trCodes = FetchAdviserChargesTypeForIllustrationType( selectedIllustrationType ) ;

            string sql1 = MySqlMaker.SelectAdviserChargesTypesSQL( trCodes );

            Dictionary<string, string> results = new Dictionary<string, string>() ;

            MyFetcher.FetchData(sql1, reader => results.Add( reader.Fetch("Tr_Cd",  reader.GetString ), reader.Fetch("Descript", reader.GetString ) ) );

            return results; 
        }


        public Dictionary<string, string> FetchAdviserChargeDescriptionsFor(CultureInfo forLanguage)
        {
            string[] trCodes = FetchFullAdviserFeeCodes();

            string sql1 = MySqlMaker.SelectAdviserChargesTypesSQL(trCodes);

            Dictionary<string, string> results = new Dictionary<string, string>();

            MyFetcher.FetchData(sql1, reader => results.Add(reader.Fetch("Tr_Cd", reader.GetString), reader.Fetch("Descript", reader.GetString)));

            return results;
        }

    }
}
