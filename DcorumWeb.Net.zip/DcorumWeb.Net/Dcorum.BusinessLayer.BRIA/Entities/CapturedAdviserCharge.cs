﻿using Dcorum.BusinessLayer.BRIA.Contractual.Internal;
using Dcorum.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    [DisplayName("Adviser Charge")]
    public class CapturedAdviserCharge
    {
        public CapturedAdviserCharge()
        {

        }

        public CapturedAdviserCharge(IReadOnlyDictionary<string, object> source)
            :this()
        {
            if (source == null) throw new ArgumentNullException( nameof( source) );
            Build(source);
        }

        [Key]
        public int SurrogateKey { get; set; }

        public int Agt_Key { get; set; }

        [Required]
        [Display(Name = "Charge type")]
        public string ChargeTypeCode { get; set; }

        [UIHint("ddl*")]
        [Required]
        [Display(Name = "Charge type")]
        public string ChargeTypeDescription { get; set; }

        [UIHint("ctl00")]
        [Display(Name = "Amount")]
        [Range(0.0, int.MaxValue)]
        public decimal? Amount { get; set; }

        [UIHint("ctl01")]
        [Display(Name = "Percentage")]
        [Range(0.0, 100.00)]
        public decimal? Percentage { get; set; }


        [UIHint("ddl*")]
        //[Editable(false)]
        [Display(Name = "Transfer In Amount")]
        public decimal? TransferInAmount { get; set; }
        

        [ScaffoldColumn(false)]
        [Display(Name = "Associated Transfer-In")]
        public int SurrogateTranferInForeignKey { get; set; }
        
        private void Build(IReadOnlyDictionary<string, object> source)
        {
            bool isCurrency = "C".Equals(source.Single(key=>key.Key == "format_cd" || key.Key == "PERCENT_OR_CURRENCY").Value?.ToString(), StringComparison.InvariantCultureIgnoreCase);
            bool isPercent = "P".Equals(source.Single(key => key.Key == "format_cd" || key.Key == "PERCENT_OR_CURRENCY").Value?.ToString(), StringComparison.InvariantCultureIgnoreCase);

            if(source.ContainsKey("Agt_Key"))  Agt_Key = (source["Agt_Key"]?.ToString()).IntoIntN().GetValueOrDefault() ;

            ChargeTypeCode = source["TR_CD"].ToString() ;

            ChargeTypeDescription = source.Single(key => key.Key == "descript" || key.Key == "CHARGE_DESCRIPTION").Value.ToString();

            Amount = (isCurrency) ? source.Single(key => key.Key == "Ben_Opt_Data" || key.Key == "CHARGE_AMOUNT").Value.ToString().IntoDecimalN() : null;

            if (source.ContainsKey("Bens.Long_Desc"))
            {
                string longDesc = source["Bens.Long_Desc"]?.ToString();
                Debug.Assert(isCurrency ? longDesc == "GDP" : string.IsNullOrWhiteSpace(longDesc));
            }

            Percentage = (isPercent) ? source.Single(key => key.Key == "Ben_Opt_Data" || key.Key == "CHARGE_AMOUNT").Value?.ToString().IntoDecimalN() : null;
   
        }


        internal bool IsChargeTypeAnyOf( params AdvisorFeeCodes[] codes)
        {
            return codes.DoesContain(ChargeTypeCode) ;
        }

    }
}
