﻿using DCorum.ViewModelling.Contractual;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class BindableFundChoice : IKeyValuePair
    {
        public bool IsFlyweight { get; set; } //false if not a fund
        public int SurrogateKey { get; set; }
        public string FundId { get; set; }
        public string FundDesc { get; set; }
        public bool IsFreestyle { get; set; }

        int IKeyValuePair.KeyItem
        {
            get { return SurrogateKey; }
        }

        string IKeyValuePair.DisplayItem
        {
            get { return FundDesc; }
        }
    }
}
