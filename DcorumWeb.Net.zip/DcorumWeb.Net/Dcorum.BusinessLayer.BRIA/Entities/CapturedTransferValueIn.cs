﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class CapturedTransferValueIn :IUncrystallizedProperties
    {
        [Key]
        public int SurrogateKey { get; set; }

        [Required]
        [Display(Name = "Transferring Scheme:")]
        [UIHint("txtFrom")]
        [StringLength(100)]
        public string From { get; set; }

        [Required]
        [Display(Name = "Scheme Type:")]
        [UIHint("txtSchemeType")]
        [StringLength(100)]
        public string SchemeType { get; set; }

        [Display(Name = "Crystallised Fund Value:")]
        [UIHint("txtCrFundValue")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal CrystallizedFundValue { get; set; }

        [Display(Name = "Uncrystallised Fund Value:")]
        [UIHint("txtUcrFundValue")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal UncrystallizedFundValue { get; set; }

        //[Display(Name = "Total Fund Value:")]
        //[UIHint("txtTotalFundValue")]
        //[DisplayFormat(DataFormatString = "{0:c2}")]
        [ReadOnly(true)]
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal TotalFundValue
        {
            get
            {
                return CrystallizedFundValue + UncrystallizedFundValue;
            }
        }

        [Display(Name = "TFC Percentage:", Prompt = "Enter either tax tree amount or percentage, but not both.")]
        [UIHint("txtPercentage")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, Values.MaxTaxFreePercentAsDouble)]
        [DataType(DataType.Currency)]
        public decimal? TfcPercentage { get; set; }


        [Display(Name = "TFC Amount:", Prompt = "Enter either tax tree amount or percentage, but not both.")]
        [UIHint("txtAmount")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal? TfcAmount { get; set; }

        //[ScaffoldColumn(false)]
        //public decimal? ChargeAmount { get; set; }

        //[ScaffoldColumn(false)]
        //public decimal? ChargePercentage { get; set; }
    }
}
