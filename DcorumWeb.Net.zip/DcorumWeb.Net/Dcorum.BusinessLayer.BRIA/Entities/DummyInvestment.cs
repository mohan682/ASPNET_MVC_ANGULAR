﻿using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.BRIA.Entities
{

    /// <summary>
    /// Dummy object to allow a FormController.Save() after a table step as part of a UI wizard
    /// </summary>
    [ScaffoldTable(false)]
    public class DummyInvestment
    {
    }
}