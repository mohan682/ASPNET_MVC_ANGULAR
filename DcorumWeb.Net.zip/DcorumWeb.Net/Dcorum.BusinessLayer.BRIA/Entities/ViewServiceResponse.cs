﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class ViewIllustrationResponse
    {
        [ReadOnly(true)]
        [Display(Name = "Scheme Id:")]
        [UIHint("litCaseKey")]
        public int CaseKey { get; set; }

        [Key]
        [ReadOnly(true)]
        [Display(Name = "Case Member Key:")]
        [UIHint("litCaseMemberKey")]
        public int CaseMemberKey { get; set; }

        //[ReadOnly(true)]
        [RefreshProperties(RefreshProperties.Repaint)]
        [Display(Name = "Queue Id:")]
        [UIHint("txtQueueId")]
        public int QueueId { get; set; }


        [ReadOnly(true)]
        [Display(Name = "Last checked:")]
        [UIHint("txtLastPolled")]
        [DisplayFormat(DataFormatString="{0:HH:mm:ss}")]
        [DataType(DataType.Time)]
        public DateTime? LastPolled { get; set; }

        public bool WhatIfFlag { get; set; }

        //[ReadOnly(true)]
        //[DataType(DataType.Url)]
        //[Display(Name = "Illustration link:")]
        //[UIHint("txtPdfUrl1")]
        public string IllustrationPdfUrl { get; set; }

        //[ReadOnly(true)]
        //[DataType(DataType.Url)]
        //[Display(Name = "What-If Illustration link:")]
        //[UIHint("txtPdfUrl2")]
        public string IllustrationPdfUrl2 { get; set; }

        public string XmlResultsUrl { get; set; }

        public bool? WasSuccessful { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Request Successful:")]
        [UIHint("txtSuccess")]
        public string TextualWasSuccessful
        {
            get
            {
                if (WasSuccessful.HasValue) return WasSuccessful.ToString();
                return (!(QueueId>0))? "N/A" : "Processing";
            }            
        }

        public bool WizardModeOn {get; set; }
    }
}
