﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class CapturedTaxFreeCash : IUncrystallizedProperties
    {
        public decimal UncrystallizedExistingBalancesSum { get; set; }
        //public decimal UncrystallizedTransferValuesSum { get; set; }

        [Display(Name = "Fund Value (uncrystallised):")]
        [UIHint("txtFundValueSum")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        [ReadOnly(true)]
        public decimal UncrystallizedFundValue
        {
            get
            {
                return UncrystallizedExistingBalancesSum; //+ UncrystallizedTransferValuesSum;
            }
        }


        [Display(Name = "TFC Percentage:")]
        [UIHint("txtPercentage")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, Values.MaxTaxFreePercentAsDouble)]
        [DataType(DataType.Currency)]
        public decimal? TfcPercentage { get; set; }

         
        [Display(Name = "TFC Amount:")]
        [UIHint("txtAmount")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal? TfcAmount { get; set; }
    }
}
