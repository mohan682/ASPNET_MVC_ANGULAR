﻿extern alias WCF;

using System.Collections.Generic;
using System.Diagnostics;
using Dcorum.BusinessLayer.BRIA.Contractual;
using System;
using System.Collections.ObjectModel;

namespace Dcorum.BusinessLayer.BRIA.Entities
{

    /// <summary>
    /// [COMPOSITE|ANAEMIC]
    /// </summary>
    public class BriaAdhocPureGraph
    {
        #region ViewModel sections...
        public CapturedStart Start { get; private set; }

        public CapturedMemberDetail MemberDetail { get; private set; }

        public List<CapturedTransferValueIn> TvIns { get; private set; }

        public CapturedTaxFreeCash TaxFreeCash { get; private set; }

        public CapturedIncome Income { get; private set; }

        public List<CapturedInvestment> Investments { get; internal set; }

        public List<CapturedDisinvestment> Disinvestments { get; internal set; }

        public List<CapturedAdviserCharge> AdviserCharges { get; internal set; }
 
        #endregion

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public BriaAdhocPureGraph()
        {
            Start = new CapturedStart();
            MemberDetail = new CapturedMemberDetail();

            int rebuiltTally = Rebuild();
            Debug.Assert(rebuiltTally == 2);
        }

        /// <summary>
        /// [JIRA 8174]
        /// Allows us to selectively throw away content when it's not relevant for a specified illustration mode.
        /// </summary>
        /// <param name="mode"></param>
        public int Rebuild(DecumIllustrationMode? mode = null)
        {
            int tally = 0;

            if (!mode.IsTransferInMode())
            {
                TvIns = new List<CapturedTransferValueIn>();
                tally++;
            }

            if (mode.IsWithChangesMode() == false)
            {
                TaxFreeCash = new CapturedTaxFreeCash();
                Income = new CapturedIncome();
                Investments = new List<CapturedInvestment>();
                Disinvestments = new List<CapturedDisinvestment>();
                tally++;
            }

            return tally;
        }
    }

    /// <summary>
    /// [COMPOSITE|ANAEMIC]
    /// </summary>
    public class BriaAdhocViewGraph : BriaAdhocPureGraph
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public BriaAdhocViewGraph()
            : base()
        {
            Summary = new CapturedSummary();
            IllustrationResponse = new ViewIllustrationResponse();

            DummyTransferValue = new DummyTransferValue();
            DummyInvestment = new DummyInvestment();
            DummyDisinvestment = new DummyDisinvestment();
            DummyAdviserCharge = new DummyAdviserCharge();

            //Dictionary<Type, Type[]> sequenceMap = new Dictionary<Type, Type[]>()
            //{
            //    [typeof(CapturedStart)] = new Type[] { } ,
            //    [typeof(CapturedMemberDetail)] = new Type[] { },
            //    [typeof(DummyTransferValue)] = new Type[] { },
            //    [typeof(CapturedTaxFreeCash)] = new Type[] { },
            //    [typeof(CapturedIncome)] = new Type[] { },
            //    [typeof(DummyInvestment)] = new Type[] { },
            //    [typeof(DummyDisinvestment)] = new Type[] { },
            //    [typeof(DummyAdviserCharge)] = new Type[] { },
            //    [typeof(CapturedSummary)] = new Type[] { },
            //};

            //BasicViewModelSequence = new ReadOnlyDictionary<Type, ReadOnlyCollection<Type>>(sequenceMap) ;

        }

        public CapturedSummary Summary { get; set; }
        public ViewIllustrationResponse IllustrationResponse { get; private set; }

        #region just to help with the mechanics

        //private IReadOnlyDictionary<Type, IReadOnlyList<Type>> BasicViewModelSequence { get; }

        public DummyTransferValue DummyTransferValue { get; private set; }
        public DummyInvestment DummyInvestment { get; private set; }
        public DummyDisinvestment DummyDisinvestment { get; private set; }
        public DummyAdviserCharge DummyAdviserCharge { get; private set; }

        public CapturedTransferValueIn TemporaryTvIn { get; internal set; }
        public CapturedInvestment TemporaryInvestment { get; internal set; }
        public CapturedDisinvestment TemporaryDisinvestment { get; internal set; }

        public CapturedAdviserCharge TemporaryAdviserCharge { get; internal set; }

        public BindableFundChoice[] InvFundChoices { get; internal set; }
        public BindableFundChoice[] DisFundChoices { get; internal set; }

        #endregion
    }
}
