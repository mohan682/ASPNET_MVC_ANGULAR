﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Dcorum.Utilities;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class ServiceTaskQueueLogEntry
    {
        [Key]
        public int QueueLogId { get; private set; }

        public int QueueId { get; private set; }

        public string Message { get; private set; }

        public DateTime CreatedAt { get; private set; }

        public int Sequence { get; private set; }

        public static void Build(ServiceTaskQueueLogEntry toBuild, IDataReader reader)
        {
            toBuild.QueueLogId = DBHelper.GetIDataReaderInt(reader, "SERVICE_TASK_QUEUE_LOG_ID");
            toBuild.QueueId = DBHelper.GetIDataReaderInt(reader, "SERVICE_TASK_QUEUE_ID");
            toBuild.Message = DBHelper.GetIDataReaderString(reader, "MESSAGE");
            toBuild.CreatedAt = DBHelper.GetIDataReaderDateTime(reader, "CREATED_DT");
            toBuild.Sequence = DBHelper.GetIDataReaderInt(reader, "SEQ");
        }
    }


    public static class ServiceTaskQueueLogEntryHelper
    {
        public static object DefaultViewFacade(this ServiceTaskQueueLogEntry model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.QueueLogId,
                Sequence = model.Sequence, 
                Message________________________________________________________________ = model.Message,
                Timestamp_ = model.CreatedAt.ToString("T")
            };
            return facade1;
        }
    }

}
