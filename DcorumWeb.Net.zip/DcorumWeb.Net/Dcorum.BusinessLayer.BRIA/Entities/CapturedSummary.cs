﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    /// <summary>
    /// OZUC109
    /// </summary>
    public class CapturedSummary
    {
        [ReadOnly(true)]
        [Display(Name = "Scheme Id:")]
        [UIHint("litCaseKey")]
        public int CaseKey { get; set; }

        [Key]
        [ReadOnly(true)]
        [Display(Name = "Case Member Key:")]
        [UIHint("litCaseMemberKey")]
        public int CaseMemberKey { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Illustration Type:")]
        [UIHint("litIllustrationOption")]
        public DecumIllustrationMode IllustrationOption { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Effective Date:")]
        [UIHint("txtEffectiveDate")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [DataType(DataType.Date)]
        public DateTime EffectiveDate { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Member Name:")]
        [UIHint("litMemberName")]
        public string MemberFullname { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Gender:")]
        [UIHint("litGender")]
        public string GenderDescription { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Date Of Birth:")]
        [UIHint("txtDob")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Dob { get; set; }

        [ReadOnly(true)]
        [Display(Name = "What If Mode:")]
        [UIHint("chkWhatIf", "debug")]
        public bool WhatIfFlag { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Deductions Flag On:")]
        [UIHint("chkBria", "debug")]
        public bool DeductionsFlag { get; set; }

        public bool UseCapturedData { get; set; }
        public bool InvokeWcfFlag { get; set; }

        
    }
}
