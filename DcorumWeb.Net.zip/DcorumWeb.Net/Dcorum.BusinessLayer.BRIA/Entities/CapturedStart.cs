﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BRIA.Contractual;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class CapturedStart
    {
        [ReadOnly(true)]
        [Display(Name = "Scheme Id:")]
        [UIHint("litCaseKey")]
        public int CaseKey { get; set; }

        [Key]
        [ReadOnly(true)]
        [Display(Name = "Case Member Key:")]
        [UIHint("litCaseMemberKey")]
        public int CaseMemberKey { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Is RIA scheme:")]
        [UIHint("chkRia", "debug")]
        public bool IsBriaScheme { get; set; }

        [ReadOnly(true)]
        [Display(Name = "Is Pending:")]
        [UIHint("chkPending", "debug")]
        public bool IsPendingBriaMember { get; set; }

        [Required]
        [Display(Name = "Illustration Type:")]
        [UIHint("ddlIllustrationOption")]
        [RefreshProperties(RefreshProperties.All)]
        public DecumIllustrationMode IllustrationOption { get; set; }

        [Required]
        [Display(Name = "Effective Date:")]
        [UIHint("txtEffectiveDate")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [DataType(DataType.Date)]
        [RefreshProperties(RefreshProperties.All)]
        public DateTime EffectiveDate { get; set; }

        // for the past 30 days...
        public int TransferValueCount { get; set; }

        public DateTime? ActiveDrawdownStatusDate { get; set; }

        public CapturedStart()
        {
            IsBriaScheme = false;
            EffectiveDate = DateTime.MinValue;
            IllustrationOption = DecumIllustrationMode.ReCreateNewBusinessIllustration;
        }
    }
}
