﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class CapturedIncome
    {
        private const string Group1 = "Regular Income";
        private const string Group2 = "One Off Income";
        private const string Group3 = "IncomePriority";

        public const string PriorityCrystalised = "62";
        public const string PriorityUncrystalised = "63";
        public const string PriorityProRated = "60";

        public static void BuildNonMemberCapturedIncome(CapturedIncome toBuild)
        {
            toBuild.Frequency = new RefCode(null, "Monthly");
            toBuild.Escalation = new RefCode(null, "RPI");
            toBuild.IncomePriority = new RefCode(PriorityProRated);
        }

        [Display(GroupName = Group1, Name = "Frequency:", Prompt = "Deferred Income")]
        [UIHint("ddlFrequency")]
        [RefCodeConstraint("INCOME_FREQUENCY_TYPE_LOOKUP", OrderByRefCode = true)]
        [RefreshProperties(RefreshProperties.All)]
        public RefCode Frequency { get; set; }

        [Required]
        [Display(GroupName = Group1, Name = "Regular Amount:", Prompt="Enter any regular payment here.")]
        [UIHint("txtRegularAmount")]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal? RegularAmount { get; set; }

        [Required]
        [Display(GroupName = Group1, Name = "Escalation:")]
        [UIHint("ddlEscalation")]
        [RefCodeConstraint("INCREASE_TYPE_LOOKUP", OrderByRefCode = true)]
        [RefreshProperties(RefreshProperties.All)]
        public RefCode Escalation { get; set; }

        [Required]
        [Display(GroupName = Group1, Name = "Increase Percent:", Prompt="Fixed escalation %.")]
        [UIHint("txtPercentIncrease")]
        //[DisplayFormat(DataFormatString = "{0:N}")]
        [Range(0, 10)]
        public int? IncreasePercent { get; set; }

        [Display(GroupName = Group2, Name = "Adhoc Income Amount:", Prompt = "Enter any one-off payment here.")]
        [UIHint("txtOneOffAmount")]
        [DisplayFormat(DataFormatString = "{0:N2}")]    
        [Range(0, double.MaxValue)]
        [DataType(DataType.Currency)]
        public decimal? OneOffAmount { get; set; }

        [Required]
        [Display(GroupName = Group3, Name = "Income Paid From:")]
        [UIHint("rblPriority")]
        [RefCodeConstraint("INCOME_SRC_TYPES", OrderByRefCode = true)]
        public RefCode IncomePriority { get; set; }

        public decimal CrystalizedExistingBalancesSum { get; set; }

        public bool IncomeFromCrfEnabled { get; set; }
        public bool IncomeFromUcrfEnabled { get; set; }

        /// <summary>
        /// used as the upper range allowed for an adhoc payment.
        /// </summary>
        public decimal MaxAdhocAmount { get; set; }

        public bool PercentIncreaseEnabled
        {
            get
            {
                if (Escalation == null) return false ;
                return Escalation.Descript.Equals("Fixed", StringComparison.OrdinalIgnoreCase);
            }
        }

        public bool RegularAmountEnabled
        {
            get
            {
                if (Frequency == null) return false ;
                return Frequency.RefCd.IntoIntN().GetValueOrDefault() > 0;
            }       
        }

        /// <summary>
        /// [VIEW_CONTROL_FLAG]Used to decide if we should skip the investments page.
        /// </summary>
        public bool EditableInvestmentsModeOn { get; set; }

        /// <summary>
        /// [VIEW_CONTROL_FLAG]Used to decide if we should return to tax free cash page.
        /// </summary>
        public bool HasExistingBalances { get; set; }
    }
}
