﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Dcorum.Utilities.Contractual;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Contractual;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class CapturedInvestment : IHaveABindableProperty<BindableFundChoice>
    {
        [Key]
        public int SurrogateKey { get; set; }

        /// <summary>
        /// Actual Key
        /// </summary>
        [ReadOnly(true)]
        [Display(Name = "Fund Id:")]
        [UIHint("txtFundId")]
        public string FundDescId { get { return BindableProperty.FundId; } }

        //[ReadOnly(true)]
        //[Display(Name = "Fund:")]
        //[UIHint("txtFund")]
        //[StringLength(100)]
        public string FundDesc { get { return BindableProperty.FundDesc; }}

        [Required]
        [Display(Name = "New % of Account:")]
        [UIHint("txtPercent")]
        [DisplayFormat(DataFormatString = "{0:#.##}")]
        [Range(0, 100)]
        public decimal Percent { get; set; }

        //public bool IsFreeStyle { get; set; }
        //public bool IsLifepath { get; set; }
        public bool IsLifeStyle { get; set; }

        [Required]
        [Display(Name = "Fund:")]
        [UIHint("ddlFund")]
        public BindableFundChoice BindableProperty { get; set; }

        internal Func<IEnumerable<BindableFundChoice>> HowToGetFundChoices { get; set; }

        public IEnumerable<BindableFundChoice> GetBindingChoices()
        {
            return HowToGetFundChoices().SafeLinq();
        }

        /// <summary>
        /// Used by UI Rendering
        /// </summary>
        IKeyValuePair[] IHaveBindableProperties.Choices(int ruleId, Type ofProperty)
        {
            if (ofProperty == typeof (BindableFundChoice)) return GetBindingChoices().ToArray();
            throw new NotImplementedException();
        }

        bool IHaveBindableProperties.Choose(int ruleId, Type ofProperty, object chosenValue)
        {
            if (ofProperty == typeof (BindableFundChoice))
            {
                int newValue = Convert.ToInt32(chosenValue);
                BindableProperty = GetBindingChoices().FirstOrDefault( _ => _.SurrogateKey == newValue );
                return true;
            }
            throw new NotImplementedException();
        }
    }
}
