﻿using System;
using System.ComponentModel.DataAnnotations;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    public class CapturedMemberDetail
	{
        [Required]
        [Display(Name = "Title:")]
        [UIHint("ddlTitle")]
        [RefCodeConstraint(DomainNames.PersonTitle, OrderByRefCode = true)]
		public RefCode Title { get; set; }

        [Required]
        [Display(Name = "Firstname:")]
        [UIHint("txtFirstName")]
		public string FirstName { get; set; }

        [Required]
        [Display(Name = "Surname:")]
        [UIHint("txtSurname")]
		public string Surname { get; set; }

        [Required]
        [Display(Name = "Date Of Birth:")]
        [UIHint("txtDob")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
		public DateTime? Dob { get; set; }

        [Required]
        [Display(Name = "Gender:")]
        [UIHint("ddlGender")]
        [RefCodeConstraint(DomainNames.Gender, OrderByRefCode = true)]
		public RefCode Gender { get; set; }
	}
}
