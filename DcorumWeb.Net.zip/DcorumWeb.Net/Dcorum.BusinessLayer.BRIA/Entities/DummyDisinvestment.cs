﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Dcorum.BusinessLayer.BRIA.Entities
{
    /// <summary>
    /// Dummy object to allow a FormController.Save() after a table step as part of a UI wizard
    /// </summary>
    public class DummyDisinvestment
    {
        [ReadOnly(true)]
        [Display(Name = "Same proportions:")] //, Description = "To use the same proportions as the invested funds, leave blank and proceed.")]
        [UIHint("chkSameProportions")]
        [IgnoreDataMember]
        public bool SameAsInvestmentsFlag { get; set; }

        [ReadOnly(true)]
        [Display(Name = "")]
        [UIHint("litNote1")]
        [IgnoreDataMember]
        public string Note1
        {
            get
            {
                return "To use the same proportions as the invested funds, leave blank and proceed.";
            }
        }
    }
}