﻿using Dcorum.BusinessLayer.BRIA.Entities;
using System;
using System.Collections.Generic;

namespace Dcorum.BusinessLayer.BRIA.ViewAssistance
{
    public class RiaViewRowVisitor
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public RiaViewRowVisitor(RiaViewRowFlavours variationsSource)
        {
            VariationsSource1 = variationsSource;

            flavours = new Dictionary<Type, Func<object, object>>
            {
                {typeof (CapturedTransferValueIn), _ => VariationsSource1.DefaultViewFacade((CapturedTransferValueIn) _)},
                {typeof (CapturedInvestment), _ => VariationsSource1.DefaultViewFacade((CapturedInvestment) _)},
                {typeof (CapturedDisinvestment), _ => VariationsSource1.DefaultViewFacade((CapturedDisinvestment) _)},
                //{typeof (CapturedAdviserCharge), _ => VariationsSource1.MakeAnonFee((CapturedAdviserCharge) _)},
            };
        }

        private RiaViewRowFlavours VariationsSource1;

        private Dictionary<Type, Func<object, object>> flavours;

        /// <summary>
        /// Obain a deferred command to be invoked later on.
        /// </summary>
        public Func<object> GetViewRowCommandFor(object toVisit)
        {
            if (toVisit == null) return null;

            Type key1 = toVisit.GetType();

            Func<object, object> outValue1;
            bool success = flavours.TryGetValue(key1, out outValue1);

            if (success && outValue1 != null)
            {
                return () => outValue1(toVisit); //encapsulate delegate before returning.
            }

            return null;
        }
    }
}
