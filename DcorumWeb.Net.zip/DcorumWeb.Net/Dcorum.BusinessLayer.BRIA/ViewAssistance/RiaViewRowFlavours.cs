﻿using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;

namespace Dcorum.BusinessLayer.BRIA.ViewAssistance
{
    public class RiaViewRowFlavours
    {
        internal protected RiaViewRowFlavours()
        {
        }

        public object DefaultViewFacade(CapturedDisinvestment model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.SurrogateKey,
                Fund_Desc_Id___________________ = model.FundDescId,
                Fund___________________ = model.Fund,
                Withdrawl_Percent_____ = (model.Percent / 100).ToString("P2")
            };
            return facade1;
        }

        public object DefaultViewFacade(CapturedInvestment model)
        {
            var facade1 = new
            {
                _PrimaryKey = model.SurrogateKey,
                Fund_Desc_Id___________________ = model.FundDescId,
                Fund_______________________ = model.FundDesc,
                //Freestyle = model.IsFreeStyle,
                //Lifestyle = model.IsLifeStyle,
                //Lifepath = model.IsLifepath,
                Percent_Of_Account = (model.Percent / 100).ToString("P2"),
            };
            return facade1;
        }

        public object DefaultViewFacade( CapturedTransferValueIn model)
        {

            var facade1 = new
            {
                _PrimaryKey = model.SurrogateKey,
                Transferring_Scheme___________________ = model.From,
                Scheme_Type_____________ = model.SchemeType,
                Crystallised_Fund_Value = model.CrystallizedFundValue.ToString("C2"),
                Uncrystallised_Fund_Value = model.UncrystallizedFundValue.ToString("C2"),
                Total_Fund_Value_________ = model.TotalFundValue.ToString("C2"),
                Tax_Free_Cash_________ = model.TfcAmount.SafeFunc(_ => _.ToString("C2")) ?? model.TfcPercentage.SafeFunc(_ => (_ / 100).ToString("P2"))
            };
            return facade1;
        }


        ///// <summary>
        ///// [PROJECTION] Project anonymous object
        ///// </summary>
        ///// <param name="source">[DATA_MODEL]</param>
        ///// <returns>[VIEW_MODEL]</returns>
        //public object MakeAnonFee(CapturedAdviserCharge source)
        //{
       
        //    var anon1 = new
        //    {
        //        _suggogateKey = source.SurrogateKey.ToString(),
        //        Agt_Key = source.Agt_Key.ToString(),
        //        Type = source.ChargeTypeDescription?.ToString(),
        //        Amount = source.Amount?.ToString("#,##.00"),
        //        Percentage = source.Percentage?.ToString("#"),
        //        //Tranfer_In_Amount = source.TransferInAmount?.ToString("#,##.00"),

        //        //Last_Charge_Date = source["LAST_PAID_DT"]?.ToString().IntoDateTimeN()?.ToString("d"),
        //        //Next_Charge_Date = source["NXT_DT"]?.ToString().IntoDateTimeN()?.ToString("d"),
        //        //Charge_Expires = source.ExpiryDate?.ToString("d"),
        //    };

        //    return anon1;
        //}


        internal class TabularFeesHeadingsAndTooltips : IUntypedTabularHeadings
        {
            public IEnumerable<string> YieldSpecialColumnNames()
            {
                yield return null;
                yield return null;
                yield return null;
                yield return "Amount (£)";
                yield return "Percentage (%)";
                yield return null;
            }

            public IEnumerable<string> YieldSpecialColumnTooltips()
            {
                yield return null;
                yield return null;
                yield return null;
                yield return "GBP Currency";
                yield return null;
                yield return null;
            }
        }
    }

}
