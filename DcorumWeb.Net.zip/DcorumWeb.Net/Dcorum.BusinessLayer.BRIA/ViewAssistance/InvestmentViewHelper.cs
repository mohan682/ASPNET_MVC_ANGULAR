﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Dcorum.BusinessLayer.BRIA.Entities;

namespace Dcorum.BusinessLayer.BRIA.ViewAssistance
{
    internal static class InvestmentViewHelper
    {
        public static IEnumerable<Tuple<PropertyInfo, string>> Validate(this IEnumerable<CapturedInvestment> models)
        {
            var investments = models.ToArray();

            decimal percentSum = investments.Sum(_ => _.Percent);

            if (percentSum != 100)
            {
                yield return new Tuple<PropertyInfo, string>(null, "The total percentage must match 100%");
            }

            string[] fundIds = investments.Select(_ => _.FundDescId).ToArray();
            string[] distinctfundIds = fundIds.Distinct().ToArray();

            bool duplicatesDetected = fundIds.Length != distinctfundIds.Length;

            if (duplicatesDetected)
            {
                yield return new Tuple<PropertyInfo, string>(null, "Each fund may only occur once!");
            }
        }
    }
}
