﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;

namespace Dcorum.BusinessLayer.BRIA.ViewAssistance
{
    internal static class TransferValueInViewHelper
    {
        public static IEnumerable<Tuple<PropertyInfo, string>> Validate(this CapturedTransferValueIn model)
        {
            if (model == null) yield break;

            if (model.TotalFundValue <= 0)
            {
                var pi1 = ExpressionExtensions.IntoPropertyInfo<CapturedTransferValueIn>(_ => _.TotalFundValue);
                yield return new Tuple<PropertyInfo, string>(pi1, "The sum of the crystalised and uncrystalised fund value must be greater than 0");
            }

            foreach (var current1 in TaxFreeCashViewHelper.Validate(model))
            {
                yield return current1;
            }
        }

        public static IEnumerable<Tuple<PropertyInfo, string>> Validate(this IEnumerable<CapturedTransferValueIn> models, BriaAdhocViewGraph rootModel)
        {
            var transferValues = models.ToArray();

            if (rootModel.TaxFreeCash.UncrystallizedExistingBalancesSum > 0) yield break;

            bool noValuesDetected = transferValues.Sum(_ => _.CrystallizedFundValue) <= 0
                                    && transferValues.Sum(_ => _.UncrystallizedFundValue) <= 0;
   
            if (noValuesDetected)
            {
                var pi1 = ExpressionExtensions.IntoPropertyInfo<BriaAdhocViewGraph>(_ => _.TvIns);
                yield return new Tuple<PropertyInfo, string>(pi1, "At least one non-zero transfer value is required!");
            }
        }

    }
}
