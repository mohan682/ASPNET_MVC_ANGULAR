﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Reflection;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;

namespace Dcorum.BusinessLayer.BRIA.ViewAssistance
{
    internal static class TaxFreeCashViewHelper
    {
        public static decimal DerivedTaxFreeAmount(this IUncrystallizedProperties model)
        {
            if (model.TfcAmount > 0) return model.TfcAmount.Value;

            decimal result = (model.UncrystallizedFundValue * model.TfcPercentage.GetValueOrDefault()) / 100;
            return result;
        }


        //public static decimal DerivedTaxFreePercentage(this IUncrystallizedProperties model)
        //{
        //    Debug.Assert(model.UncrystallizedFundValue > 0);
        //    if (model.TfcPercentage > 0) return model.TfcPercentage.Value;

        //    decimal result = (model.TfcAmount.GetValueOrDefault() / model.UncrystallizedFundValue) * 100;
        //    return result;
        //}


        //public static decimal CalculatedTaxFreeCash(this IUncrystallizedProperties source)
        //{
        //    Decimal result = (source.TfcAmount.GetValueOrDefault() == 0)
        //        ? (source.UncrystallizedFundValue*source.TfcPercentage.GetValueOrDefault())/100
        //        : source.TfcAmount.GetValueOrDefault();
        //    return result;
        //}


        public static IEnumerable<Tuple<PropertyInfo, string>> Validate(this IUncrystallizedProperties model)
        {
            if (model == null) yield break;

            if (model.TfcAmount > model.UncrystallizedFundValue * Values.MaxTaxFreeCoeff)
            {
                var pi1 = ExpressionExtensions.IntoPropertyInfo<CapturedTaxFreeCash>(_ => _.TfcAmount);
                string subject1 = pi1.GetFirstAttribute<DisplayAttribute>().Name.Replace(":", null);

                var pi2 = ExpressionExtensions.IntoPropertyInfo<CapturedTaxFreeCash>(_ => _.UncrystallizedFundValue);
                string object1 = pi2.GetFirstAttribute<DisplayAttribute>().Name.Replace(":", null);

                yield return
                    new Tuple<PropertyInfo, string>(pi1,
                        String.Format("{1} must not be greater than {0:P0} of {2}!", Values.MaxTaxFreeCoeff, subject1,
                            object1));
            }

            if (model.TfcPercentage.HasValue && model.TfcAmount.HasValue && 
                model.TfcPercentage != 0 && model.TfcAmount != 0)
            {
                var pi1 = ExpressionExtensions.IntoPropertyInfo<CapturedTaxFreeCash>(_ => _.TfcAmount);
                string subject1 = pi1.GetFirstAttribute<DisplayAttribute>().Name.Replace(":", null);

                var pi2 = ExpressionExtensions.IntoPropertyInfo<CapturedTaxFreeCash>(_ => _.TfcPercentage);
                string subject2 = pi2.GetFirstAttribute<DisplayAttribute>().Name.Replace(":", null);

                yield return
                    new Tuple<PropertyInfo, string>(pi1,
                        String.Format("{0} and {1} cannot both be non-zero!", subject1, subject2));

            }
        }
    }
}
