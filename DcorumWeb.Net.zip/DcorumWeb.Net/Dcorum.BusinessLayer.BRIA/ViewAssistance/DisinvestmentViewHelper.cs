﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Dcorum.BusinessLayer.BRIA.Entities;

namespace Dcorum.BusinessLayer.BRIA.ViewAssistance
{
    internal static class DisinvestmentViewHelper
    {
        public static IEnumerable<Tuple<PropertyInfo, string>> Validate(this IEnumerable<CapturedDisinvestment> models, BriaAdhocViewGraph rootModel)
        {
            var disinvestments = models.ToArray();

            if (disinvestments.Length <=0) yield break ;

            decimal percentSum = disinvestments.Sum(_ => _.Percent);

            if (percentSum != 100)
            {
                yield return new Tuple<PropertyInfo, string>(null, "The total percentage must match 100%");
            }


            string[] disFundIds = disinvestments.Select(_ => _.FundDescId).ToArray();
            string[] distinctfundIds = disFundIds.Distinct().ToArray();

            bool duplicatesDetected = disFundIds.Length != distinctfundIds.Length;

            if (duplicatesDetected)
            {
                yield return new Tuple<PropertyInfo, string>(null, "Each fund may only occur once!");
            }


            string[] invFundIds = rootModel.Investments.Select(_ => _.FundDescId).ToArray();

            var x = new HashSet<string>(disFundIds);
            bool isSubset = x.IsSubsetOf(invFundIds);

            if (!isSubset)
            {
                yield return new Tuple<PropertyInfo, string>(null, "Each disinvestment must correspond to an investment!") ;
            }
        }
    }
}
