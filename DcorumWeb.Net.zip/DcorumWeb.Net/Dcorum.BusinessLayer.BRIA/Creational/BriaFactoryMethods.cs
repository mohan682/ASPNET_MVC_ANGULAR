﻿extern alias WCF;

using Dcorum.BusinessLayer.BRIA.DataAccess;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.Logic;
using Dcorum.Utilities.Contractual;
using System;
using System.Collections.Generic;
using Dcorum.Utilities.Structural;
using DCorum.BusinessFoundation.Bases;

using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;
using Dcorum.Utilities.Practices;

namespace Dcorum.BusinessLayer.BRIA.Creational
{
    public class BriaFactoryMethods
    {
        public static readonly BriaFactoryMethods Singleton = new BriaFactoryMethods();
        private BriaFactoryMethods() { }

        public ServiceTaskQueueReadonlyController CreateServiceTaskQueueLogEntryController()
        {
            return new ServiceTaskQueueReadonlyController(new DLServiceTaskQueueLogEntry());
        }


        public BriaAdhocIllustrationWizardController<TModelStep> CreateDecumIllustrationController<TModelStep>()
            where TModelStep : class
        {
            return new BriaAdhocIllustrationWizardController<TModelStep>(RiaQueries.Default);
        }

        /*
        public BriaAdhocIllustrationWizardController<TModelStep> CreateDecumIllustrationController<TModelStep>()
            where TModelStep :class
        {
            BriaAdhocIllustrationWizardController<TModelStep> creation1 = null;

            RiaWizardMemory memory1 = new RiaWizardMemory( () => creation1 );

            creation1 = new BriaAdhocIllustrationWizardController<TModelStep>( RiaQueries.Default, memory1 ) ;

            return creation1 ;
        }
        */

        internal IHaveReadableContainers CreateRiaReadOnlyModelAdaptor(BriaAdhocViewGraph toAdapt, Action<BriaAdhocViewGraph> AdvisorChargeTweaker )
        {
            var itemMaplets = new Dictionary<Type, Func<object>>()
            {
                {typeof (CapturedStart), () => toAdapt.Start},
                {typeof (CapturedMemberDetail), () => toAdapt.MemberDetail},
                {typeof (CapturedTaxFreeCash), () => toAdapt.TaxFreeCash},
                {typeof (CapturedIncome), () => toAdapt.Income},
                {typeof (CapturedSummary), () => toAdapt.Summary},
                {typeof (ViewIllustrationResponse), () => toAdapt.IllustrationResponse},
                {typeof (DummyTransferValue), () => toAdapt.DummyTransferValue},
                {typeof (DummyInvestment), () => toAdapt.DummyInvestment},
                {typeof (DummyDisinvestment), () => toAdapt.DummyDisinvestment},
                {typeof (DummyAdviserCharge), () => toAdapt.DummyAdviserCharge }
            };

            var listMaplets = new Dictionary<Type, Func<IEnumerable<object>>>()
            {
                {typeof (CapturedTransferValueIn), () => toAdapt.TvIns},
                {typeof (CapturedInvestment), () => toAdapt.Investments},
                {typeof (CapturedDisinvestment), () => toAdapt.Disinvestments },
                {typeof (CapturedAdviserCharge), () => toAdapt.SafeAction( _ => AdvisorChargeTweaker?.Invoke( _ ) ).AdviserCharges }
            };

            var creation1 = new ReadableContainersAdaptor(itemMaplets, listMaplets);

            return creation1;
        }

        public UntypedWizardControllerAdaptor<TModel, TKey, TParentKey> Adapt<TModel, TKey, TParentKey>(WizardControllerBase<TModel, TKey, TParentKey> toAdapt)
            where TModel : class
            where TKey : IEquatable<TKey>
        {
            var creation1 = new UntypedWizardControllerAdaptor<TModel, TKey, TParentKey>(toAdapt) ;
            return creation1 ;
        }


        /*
        internal DecumIllustrationSession CreateIllustrationSession(int caseKey, int caseMemberKey)
        {
            if (caseKey <= 0) throw new ArgumentException("must be greater than 0", nameof(caseKey)) ;
            if (caseMemberKey < 0) throw new ArgumentException("must be equal or greater than 0", nameof(caseMemberKey));

            var creation1 = new DecumIllustrationSession();
            creation1.BuildPart1(caseMemberKey, caseKey, DateTime.Now);
            return creation1;
        }


        /// <summary>
        /// [CREATIONAL]
        /// </summary>
        internal DecumIllustrationSession CreateIllustrationSession(int existingQueueId, out int caseKey, out int caseMemberKey)
        {
            var creation1 = new DecumIllustrationSession(existingQueueId);
            caseMemberKey = creation1.CaseMemberKey;
            caseKey = creation1.CaseKey;
            return creation1;
        }

        /// <summary>
        /// [CREATIONAL]
        /// </summary>
        internal BriaAdhocViewGraph CreateViewGraph( DecumIllustrationSession associate1)
        {
            var creation1 = new BriaAdhocViewGraph();

            var builder = new BriaAdhocModelBuilder(creation1);
            builder.BuildStart(associate1.Message);
            return creation1;
        }
        */
    }
}
