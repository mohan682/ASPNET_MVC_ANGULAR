﻿extern alias WCF;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.Logic;
using DCorum.BusinessFoundation.Bases;

namespace Dcorum.BusinessLayer.BRIA.Creational
{
    using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;

    /// <summary>
    /// Obtains [BriaAdhocViewGraph] either by retrieval or creation as well as being able to discard a previously retrieved [BriaAdhocViewGraph].
    /// </summary>
    public class BriaAdhocViewGraphCaretaker : SessionCaretakerBase<BriaAdhocViewGraph>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal BriaAdhocViewGraphCaretaker(int caseKey, DecumIllustrationSession illustrationAssociate)
        {
            Associate1 = illustrationAssociate;
            OverrideNumericPart = caseKey != illustrationAssociate.CaseKey;
        }

        private DecumIllustrationSession Associate1 { get; set; }

        /// <summary>
        /// When navigating directly onto the reponse page this prevents the original object graph being severered on subsequent postbacks.
        /// </summary>
        private bool OverrideNumericPart { get; set; }

        public int CaseKey { get { return Associate1.CaseKey; }}
        public int CaseMemberKey { get { return Associate1.CaseMemberKey; }}

        /// <summary>
        /// [CREATIONAL]
        /// </summary>
        protected override BriaAdhocViewGraph Create()
        {
            var creation1 = new BriaAdhocViewGraph();

            var builder = new BriaAdhocModelBuilder(creation1);
            builder.BuildStart( Associate1.Message );     
            return creation1;
        }

        private int StorageNumericPart()
        {
            if (OverrideNumericPart) return default(int);
            return (CaseMemberKey > 0) ? CaseMemberKey : CaseKey;
        }

        protected override string BuildStorageKey()
        {
            return typeof (BriaAdhocViewGraph).FullName + "||" + StorageNumericPart();
        }
    }
}
