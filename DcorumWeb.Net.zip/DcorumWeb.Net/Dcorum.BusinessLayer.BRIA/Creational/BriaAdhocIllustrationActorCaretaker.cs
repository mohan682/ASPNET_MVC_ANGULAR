﻿extern alias WCF;
using System;
using System.Diagnostics;
using DCorum.BusinessFoundation.Bases;

namespace Dcorum.BusinessLayer.BRIA.Logic
{
    using wcfFactory = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DcorumWebIllustrationFactory;
    using DecumIllustrationSession = WCF::WcfBusiness.Illustrations.Illustration.Interaction.DecumIllustrationSession;

    /// <summary>
    /// Obtains [DecumIllustrationSession] either by retrieval or creation as well as being able to discard a previously retrieved [DecumIllustrationSession].
    /// </summary>
    public class BriaAdhocIllustrationActorCaretaker : SessionCaretakerBase<DecumIllustrationSession>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal BriaAdhocIllustrationActorCaretaker(int existingQueueId, int caseMemberKey, int caseKey)
        {
            CaseKey = caseKey;
            CaseMemberKey = caseMemberKey;
            ExistingQueueId = existingQueueId;
        }

        public int CaseKey { get; private set; }
        public int CaseMemberKey { get; private set; }
        public int ExistingQueueId { get; private set; }

        /// <summary>
        /// [CREATIONAL]
        /// </summary>
        protected override DecumIllustrationSession Create()
        {
            var creation1 = wcfFactory.Singleton.Create(ExistingQueueId) ;

            if (ExistingQueueId > 0)
            {
                CaseMemberKey = creation1.CaseMemberKey;
                CaseKey = creation1.CaseKey;
            }
            else
            {
                creation1.BuildPart1(CaseMemberKey, CaseKey, DateTime.Now);
                return creation1;
            }

            return creation1;
        }

        ///// <summary>
        ///// [CREATIONAL]
        ///// </summary>
        //protected override DecumIllustrationSession Create()
        //{
        //    var creation1 = DecumIllustrationSession.Create(ExistingQueueId);

        //    if (ExistingQueueId > 0)
        //    {
        //        CaseMemberKey = creation1.CaseMemberKey;
        //        CaseKey = creation1.CaseKey;
        //    }
        //    else
        //    {
        //        creation1.BuildPart1(CaseMemberKey, CaseKey, DateTime.Now);
        //    }

        //    return creation1;
        //}

        private int StorageNumericPart()
        {
            return (CaseMemberKey > 0) ? CaseMemberKey : CaseKey;
        }

        protected override string BuildStorageKey()
        {
            return typeof(DecumIllustrationSession).FullName + "||" + StorageNumericPart();
        }
    }
}
