﻿using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.Logic.Internal;
using DCorum.ViewModelling;
using System;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Dcorum.BusinessLayer.BRIA.Validation
{
    public class RiaAdviserChargeValidationMethods
    {
        internal protected RiaAdviserChargeValidationMethods(CapturedAdviserCharge model, BriaAdhocViewGraph riaViewGraph, AdviserFeeAssistant feeHelper)
        {
            MyModel = model;
            if (MyModel == null) throw new ArgumentNullException( nameof(model) );

            RiaViewGraph = riaViewGraph;
            if (RiaViewGraph == null) throw new ArgumentNullException( nameof(riaViewGraph) );

            MyFeeHelper = feeHelper ;
            if (MyFeeHelper == null) throw new ArgumentNullException( nameof(MyFeeHelper) ) ;
        }


        private CapturedAdviserCharge MyModel { get; }

        private BriaAdhocViewGraph RiaViewGraph { get; }

        private AdviserFeeAssistant MyFeeHelper { get; }

        private DecumIllustrationMode MyIllustrationMode { get { return RiaViewGraph.Start.IllustrationOption; } }

        private DateTime IllustrationDate { get { return RiaViewGraph.Start.EffectiveDate; } }



        private Tuple<PropertyInfo, string> GetDisplayNamePair(Expression<Func<CapturedAdviserCharge, object>> getPropertyLambda)
        {
            return AnnotationHelp.GetDisplayNamePair(MyModel, getPropertyLambda);
        }

        public Tuple<PropertyInfo, string> ValidateChargeTypeCode()
        {
            var model = MyModel;

            if (string.IsNullOrWhiteSpace(model.ChargeTypeCode))
            {
                var viewPair1 = GetDisplayNamePair(_ => _.ChargeTypeCode);

                string message = string.Format("{0} cannot be NULL.", viewPair1.Item2);
                return Tuple.Create(viewPair1.Item1, message);
            }

            return null;
        }


        public Tuple<PropertyInfo, string> ValidateAmount()
        {
            var model = MyModel;

            var viewPair1 = GetDisplayNamePair( _ => _.Amount);

            if (model.Amount == null )
            {
                if (MyFeeHelper.IsAmountRequired(model))
                {
                    string message = string.Format("{0} must have a value.", viewPair1.Item2);
                    return Tuple.Create(viewPair1.Item1, message);
                }        
            }
            else
            {
                if (MyFeeHelper.IsPercentageRequired(model))
                {
                    string message = string.Format("{0} cannot have a value.", viewPair1.Item2);
                    return Tuple.Create(viewPair1.Item1, message);
                }
            }

            return null;
        }


        public Tuple<PropertyInfo, string> ValidatePercentage()
        {
            var model = MyModel;

            var viewPair1 = GetDisplayNamePair(_ => _.Percentage);

            if (model.Percentage == null)
            {
                if (MyFeeHelper.IsPercentageRequired(model))
                {
                    string message = string.Format("{0} must have a value.", viewPair1.Item2);
                    return Tuple.Create(viewPair1.Item1, message);
                }
            }
            else
            {
                if (MyFeeHelper.IsAmountRequired(model))
                {
                    string message = string.Format("{0} cannot have a value.", viewPair1.Item2);
                    return Tuple.Create(viewPair1.Item1, message);
                }
            }

            return null;
        }


        public Tuple<PropertyInfo, string> ValidateOnlyOneValue()
        {
            var model = MyModel;

            if (model.Amount.HasValue && model.Percentage.HasValue)
            {
                var viewPair1 = GetDisplayNamePair(_ => _.Amount);
                var viewPair2 = GetDisplayNamePair(_ => _.Percentage);

                string message = string.Format("Only {0} or {1} is permitted! Please remove the value in one of those fields.", viewPair1.Item2, viewPair2.Item2);
                return Tuple.Create(viewPair1.Item1, message);
            }

            return null;
        }


        public Tuple<PropertyInfo, string> ValidateNotBothBlank()
        {
            var model = MyModel;

            if (model.Amount.HasValue == false && model.Percentage.HasValue == false)
            {
                var viewPair1 = GetDisplayNamePair(_ => _.Amount);
                var viewPair2 = GetDisplayNamePair(_ => _.Percentage);

                string message = string.Format("Both {0} and {1} cannot be blank! Please specify a value in one of those fields.", viewPair1.Item2, viewPair2.Item2);
                return Tuple.Create(viewPair1.Item1, message);
            }

            return null;
        }



        public Tuple<PropertyInfo, string> ValidateSurrogateTranferInForeignKey()
        {
            var model = MyModel;

            var viewPair1 = GetDisplayNamePair(_ => _.SurrogateTranferInForeignKey);

            if (model.SurrogateTranferInForeignKey > 0)
            {
                bool transferInModeOn = MyIllustrationMode.IsTransferInMode() ;

                if (transferInModeOn)
                {
                    var transferIn = RiaViewGraph.TvIns.FirstOrDefault(_ => _.SurrogateKey == model.SurrogateTranferInForeignKey);

                    if (transferIn == null)
                    {
                        string message1 = string.Format("{0}: {1} couldn't be found.", viewPair1.Item2, model.SurrogateTranferInForeignKey);
                        return Tuple.Create(viewPair1.Item1, message1);
                    }


                    decimal totalFee = MyFeeHelper.CalculateFeeSplit(transferIn, model).DefaultIfEmpty(0).Sum();

                    if (model.Amount.HasValue && totalFee > MyFeeHelper.MaximumPermittedFee(transferIn))
                    {
                        string message2 = string.Format("Not enough money in {0}: {1} to cover the charge amount.", viewPair1.Item2, model.SurrogateTranferInForeignKey);
                        return Tuple.Create(viewPair1.Item1, message2);
                    }
                    else if (model.Percentage.HasValue && totalFee > MyFeeHelper.MaximumPermittedFee(transferIn))
                    {
                        string message2 = string.Format("Not enough money in {0}: {1} to cover the charge percentage.", viewPair1.Item2, model.SurrogateTranferInForeignKey);
                        return Tuple.Create(viewPair1.Item1, message2);
                    }
                }
                else
                {
                    string message1 = string.Format("{0}: {1} is not allowed for this kind of illustration.", viewPair1.Item2, model.SurrogateTranferInForeignKey);
                    return Tuple.Create(viewPair1.Item1, message1);

                }

            }

            return null;
        }

     
        public Tuple<PropertyInfo, string> ValidateTransferInAmount()
        {
            var model = MyModel;
            var viewPair1 = GetDisplayNamePair(_ => _.TransferInAmount);

            bool? mustHaveValue = MyFeeHelper.MustTransferAmountHaveValue( model, MyIllustrationMode);

            if (mustHaveValue.HasValue && model.TransferInAmount.HasValue != mustHaveValue.Value)
            {
                string modelAuxiliaryVerb = (mustHaveValue == true) ? "must have" : "cannot have";

                string message = string.Format("{0} {1} a value for this kind of illustration.", viewPair1.Item2, modelAuxiliaryVerb);
                return Tuple.Create(viewPair1.Item1, message);
            }

            return null;
        }


    }
}

