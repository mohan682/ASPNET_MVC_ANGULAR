﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.Utilities.Extensions;
using DCorum.ViewModelling;

namespace Dcorum.BusinessLayer.BRIA.ViewAssistance
{
    public static class CapturedStartValidation
    {
        public static Tuple<PropertyInfo, string> ValidateEffectiveDate(this CapturedStart model)
        {
            if (model == null) return null ;

            if (model.IllustrationOption == DecumIllustrationMode.ReCreateNewBusinessIllustration &&  model.ActiveDrawdownStatusDate < model.EffectiveDate)
            {
                var viewPair1 = AnnotationHelp.GetDisplayNamePair(model, _ => _.EffectiveDate);

                string message = String.Format("You must enter an {0} prior to {1} which was when the account status was updated to Active Drawdown.", viewPair1.Item2, model.ActiveDrawdownStatusDate.Value.Date.ToString("D"));
                return Tuple.Create(viewPair1.Item1, message);
            }

            return null ;
        }
    }
}
