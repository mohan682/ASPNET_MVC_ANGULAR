﻿using Dcorum.BusinessLayer.BRIA.Contractual;
using Dcorum.BusinessLayer.BRIA.Contractual.Internal;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Dcorum.BusinessLayer.BRIA.Validation
{
    public class RiaAdviserChargeCollectionValidationMethods
    {

        internal protected RiaAdviserChargeCollectionValidationMethods(IReadOnlyCollection<CapturedAdviserCharge> model, BriaAdhocViewGraph riaViewGraph, IReadOnlyDictionary<string, string> adviserFeeDescriptions)
        {
            MyModel = model;
            if (MyModel == null) throw new ArgumentNullException(nameof(model));

            RiaViewGraph = riaViewGraph;
            if (RiaViewGraph == null) throw new ArgumentNullException(nameof(riaViewGraph));

            AdviserFeeDescriptions = adviserFeeDescriptions;
            if (AdviserFeeDescriptions == null) throw new ArgumentNullException(nameof(adviserFeeDescriptions));
        }


        private IReadOnlyCollection<CapturedAdviserCharge> MyModel { get; }

        private BriaAdhocViewGraph RiaViewGraph { get; }

        private DecumIllustrationMode MyIllustrationModeNow { get { return RiaViewGraph.Start.IllustrationOption; } }

        private IReadOnlyDictionary<string, string> AdviserFeeDescriptions { get; }


        private Tuple<PropertyInfo, string> GetDisplayNamePair(Expression<Func<CapturedAdviserCharge, object>> getPropertyLambda)
        {
            PropertyInfo pi1 = getPropertyLambda.IntoPropertyInfo();
            string displayName = pi1.YieldAttributes<DisplayAttribute>().First().Name.Replace(":", null);

            return Tuple.Create(pi1, displayName);
        }


        public Tuple<PropertyInfo, string> ValidateNotBothBlank()
        {
            var allRows = MyModel;

            bool anyBad = allRows.Any(model => model.Amount.HasValue == false && model.Percentage.HasValue == false);

            if (anyBad)
            {
                var viewPair1 = GetDisplayNamePair(_ => _.Amount);
                var viewPair2 = GetDisplayNamePair(_ => _.Percentage);

                string message = string.Format("Both {0} and {1} cannot be blank! Please specify a value in one of those fields.", viewPair1.Item2, viewPair2.Item2);
                return Tuple.Create(viewPair1.Item1, message);
            }

            return null;
        }

        public Tuple<PropertyInfo, string> ValidateChargeTypeCode()
        {
            var allRows = MyModel;

            var feeTypeMaximums = AdvisorFeeCodesExtensions.YieldAdviserFeeCodeMaxPermittedCountPairsFor(MyIllustrationModeNow).IntoDictionary();

            if (feeTypeMaximums.Any(_ => _.Value < 0)) throw new InvalidOperationException("negative permitted totals detected!");


            bool isBad = false;

            var perTransferInCodes = AdvisorFeeCodesExtensions.PerTransferInFeeCodes(MyIllustrationModeNow).ToArray() ;

            //check feeCode quantities per transfer
            foreach (var codeNow in perTransferInCodes)
            {   
                if (allRows.Where(_ => _.IsChargeTypeAnyOf(codeNow)).GroupBy(_ => _.SurrogateTranferInForeignKey).Any(_ => _.Count() > feeTypeMaximums[codeNow]))
                {
                    isBad = true;
                }
            }

            //check feeCode quantities in entire collection except the per transfer codes.
            foreach (var feeTypeMaximum in feeTypeMaximums)
            {
                if (perTransferInCodes.Contains(feeTypeMaximum.Key)) continue; //already checked this kind.

                int matchingRowCount = (allRows.Count(_ => _.IsChargeTypeAnyOf(feeTypeMaximum.Key)));

                if (matchingRowCount > feeTypeMaximum.Value)
                {
                    isBad = true;
                    break;
                }

                //non allowed for transfer-in rows!
                if (allRows.Where(_ => _.SurrogateTranferInForeignKey > 0).Any(_ => _.IsChargeTypeAnyOf(feeTypeMaximum.Key)))
                {
                    isBad = true;
                    break;
                }
            }
            
  
            List<string> messageParts = new List<string>();

            if (isBad)
            {
                string preText1 = "Can have a maximum of";

                foreach (var feeTypeMaximum in feeTypeMaximums.Where(_ => _.Value > 0))
                {
                    messageParts.Add(preText1);
                    string adviserFeeName = AdviserFeeDescriptions[((int)feeTypeMaximum.Key).ToString()] ;

                    if (perTransferInCodes.Contains(feeTypeMaximum.Key))
                    {
                        messageParts.Add(string.Format(" {0} {1} per transfer in", feeTypeMaximum.Value, adviserFeeName));
                    }
                    else
                    {
                        messageParts.Add(string.Format(" {0} {1}", feeTypeMaximum.Value, adviserFeeName));
                    }

                    preText1 = " &";
                }

                messageParts.Add(". No other adviser charges are allowed.");

                var viewPair1 = GetDisplayNamePair(_ => _.ChargeTypeCode);
                string message = string.Concat(messageParts);
                return Tuple.Create(viewPair1.Item1, message);
            }
    
            return null;
        }
    }
}
