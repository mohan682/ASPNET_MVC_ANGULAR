﻿using Dcorum.BusinessLayer.BRIA.DataAccess;
using Dcorum.BusinessLayer.BRIA.Entities;
using Dcorum.BusinessLayer.BRIA.Logic.Internal;
using Dcorum.BusinessLayer.BRIA.ViewAssistance;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Dcorum.BusinessLayer.BRIA.Validation
{
    public delegate Tuple<PropertyInfo, string> ValidationsCommand() ;

    /// <summary>
    /// Cluster of Factory Methods plus a Validator Method
    /// </summary>
    public class RiaValidationsCommandFactory
    {
        /// <summary>
        /// [CONSTRUCTED]
        /// </summary>
        /// <param name="riaViewGraph"></param>
        internal protected RiaValidationsCommandFactory(BriaAdhocViewGraph riaViewGraph)
        {
            RiaViewGraph = riaViewGraph;
            if (RiaViewGraph == null) throw new ArgumentNullException(nameof(riaViewGraph));
        }


        private BriaAdhocViewGraph RiaViewGraph { get; }


        public IEnumerable<Tuple<PropertyInfo, string>> Validate( ValidationsCommand toInvoke )
        {
            if (toInvoke == null) yield break;

            foreach(ValidationsCommand current1 in toInvoke.GetInvocationList())
            {
                if (current1 == null) continue;

                var validationResult = current1.Invoke();

                if (validationResult == null) continue;

                yield return validationResult ;
            }
        }


        public ValidationsCommand CreateValidationsCommandFor(CapturedStart model)
        {
            if (model == null) return null;

            ValidationsCommand result = null ;
            result += () => CapturedStartValidation.ValidateEffectiveDate(model) ;

            return result;
        }


        public ValidationsCommand CreateValidationsCommandFor(CapturedAdviserCharge model)
        {
            if (model == null) return null ; 

            var validator1 = new RiaAdviserChargeValidationMethods(model, RiaViewGraph, new AdviserFeeAssistant());

            ValidationsCommand result = null;
            result += validator1.ValidateChargeTypeCode;

            result += validator1.ValidateNotBothBlank;

            result += validator1.ValidateAmount  ;
            result += validator1.ValidatePercentage;

            //result += validator1.ValidateOnlyOneValue;

            result += validator1.ValidateTransferInAmount;

            result += validator1.ValidateSurrogateTranferInForeignKey;

            //result += validator1.ValidateExpiryDate1;
            //result += validator1.ValidateExpiryDate2;

            return result;
        }


        public ValidationsCommand CreateValidationsCommandFor(DummyAdviserCharge model)
        {
            if (model == null) return null;

            var Validator1 = new RiaAdviserChargeCollectionValidationMethods(RiaViewGraph.AdviserCharges, RiaViewGraph, RiaQueries.Default.FetchAdviserChargeDescriptionsFor(null));

            ValidationsCommand result = null;
            result += Validator1.ValidateNotBothBlank ;
            result += Validator1.ValidateChargeTypeCode ;

            return result;
        }

    }
}
