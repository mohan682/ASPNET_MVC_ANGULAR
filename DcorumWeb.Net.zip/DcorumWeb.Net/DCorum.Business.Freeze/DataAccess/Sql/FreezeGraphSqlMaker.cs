﻿using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;

using ModelAlias = DCorum.Feature.Freeze.ViewModels.FreezeEventViewGraph;

namespace DCorum.Feature.Freeze.DataAccess.Sql
{
    public class FreezeGraphSqlMaker : ISqlOpenFullCrud<ModelAlias, int, int>
    {
        internal FreezeGraphSqlMaker(
            FreezeEvent2SqlMaker sqlMaker1,
            FreezeEventScopeSqlMaker sqlMaker2,
            FreezeEventMemberSqlMaker sqlMaker3,
            FreezeEventComponentOptionSqlMaker sqlMaker4
            )
        {
            SqlMakerStep1 = sqlMaker1;
            SqlMakerStep2a = sqlMaker2;
            SqlMakerStep2b = sqlMaker3;
            SqlMakerStep3 = sqlMaker4;
        }

        private FreezeEvent2SqlMaker SqlMakerStep1 { get; }
        private FreezeEventScopeSqlMaker SqlMakerStep2a { get; }
        private FreezeEventMemberSqlMaker SqlMakerStep2b { get; }
        private   FreezeEventComponentOptionSqlMaker SqlMakerStep3 { get; }


        public IEnumerable<string> DeleteSql(ModelAlias modelRoot)
        {
            var results = new List<string>();

            int ownerId = modelRoot.StrongId.Value;

            SqlMakerStep3.TestPriorToDeleteOfChildren(modelRoot.Step3, modelRoot);
            results.AddRange(SqlMakerStep3.DeleteManySql(ownerId));

            SqlMakerStep2a.TestPriorToDeleteOfChildren(modelRoot.Step2ScopeRows, modelRoot);
            results.AddRange(SqlMakerStep2a.DeleteManySql(ownerId));

            SqlMakerStep2b.TestPriorToDeleteOfChildren(modelRoot.Step2MemberRows, modelRoot);
            results.AddRange(SqlMakerStep2b.DeleteManySql(ownerId));

            results.AddRange(SqlMakerStep1.DeleteSql(modelRoot.Step1));
            return results;
        }

        public IEnumerable<string> InsertSql(ModelAlias modelRoot)
        {
            var results = new List<string>();

            results.AddRange(SqlMakerStep1.InsertSql(modelRoot.Step1));

            results.AddRange(SqlMakerStep2a.SqlInsertsForChildren(modelRoot.Step2ScopeRows, modelRoot));
            results.AddRange(SqlMakerStep2b.SqlInsertsForChildren(modelRoot.Step2MemberRows, modelRoot));

            results.AddRange(SqlMakerStep3.SqlInsertsForChildren(modelRoot.Step3, modelRoot));
            return results;
        }


        public IEnumerable<string> UpdateSql(ModelAlias modelRoot)
        {
            var results = new List<string>();

            results.AddRange(SqlMakerStep1.UpdateSql(modelRoot.Step1));

            if (modelRoot.IsScopeModeOn==false)
            {
                results.AddRange(SqlMakerStep2a.DeleteManySql(modelRoot.StrongId.Value));
            }
            else if (modelRoot.Step2ScopeRows.Any(_ => _.IsFromDb == false || _.MarkedForDeletion))
            {
                results.AddRange(SqlMakerStep2a.SqlChangesForChildren(modelRoot.Step2ScopeRows, modelRoot));
            }

            if (modelRoot.IsMemberModeOn==false)
            {
                results.AddRange(SqlMakerStep2b.DeleteManySql(modelRoot.StrongId.Value));
            }
            else // member mode is true
            {
                int[] dontDeleteThese = modelRoot.Step2MemberRows.Where(_ => _.IsFromDb).Select(_ => _.Id).ToArray();

                if (dontDeleteThese.Any())
                {
                    results.AddRange(new[] { SqlMakerStep2b.DeleteExceptWhereIdIsIn(dontDeleteThese, modelRoot.StrongId.Value) });
                    
                }
                else
                {
                    results.AddRange(SqlMakerStep2b.DeleteManySql(modelRoot.StrongId.Value));
                }

                if (modelRoot.Step2MemberRows.Any(_ => _.IsFromDb == false))
                {
                    results.AddRange(SqlMakerStep2b.SqlInsertsForChildren(modelRoot.Step2MemberRows, modelRoot));
                }
            }

            results.AddRange(SqlMakerStep3.SqlChangesForChildren(modelRoot.Step3, modelRoot));

            return results;
        }

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            return SelectOneSqlInner(primaryKey).SelectMany( _ => _ ) ;
        }

        /// <summary>
        /// Note this method is not public because the results of this method need to be flattened.
        /// </summary>
        private IEnumerable<IEnumerable<string>> SelectOneSqlInner(int primaryKey)
        {
            yield return SqlMakerStep1.SelectOneSql(primaryKey);
            yield return SqlMakerStep2a.SelectManySql(primaryKey);
            yield return SqlMakerStep2b.SelectManySql(primaryKey);
            yield return SqlMakerStep3.SelectManySql(primaryKey);
        }

        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            throw new NotImplementedException();
        }

        public string SelectDuplicatesSql(ModelAlias similar)
        {
            string result = SqlMakerStep1.SelectDuplicatesSql(similar.Step1);
            return result ;
        }

        public IEnumerable<string> DetectAnyDependants(ModelAlias ofInterest)
        {
            yield break;
        }

        public string GetSequenceIdForInsert()
        {
            throw new InvalidOperationException("This is a sqlMaker class for a weak-entity (containing strong entities). There is no physical db table for objects of this type!");
        }

        public IEnumerable<string> GetSequenceIdsForInsert()
        {
            yield return SqlMakerStep1.GetSequenceIdForInsert();
            yield return SqlMakerStep2a.GetSequenceIdForInsert();
            yield return SqlMakerStep2b.GetSequenceIdForInsert();
            yield return SqlMakerStep3.GetSequenceIdForInsert();
        }
    }
}
