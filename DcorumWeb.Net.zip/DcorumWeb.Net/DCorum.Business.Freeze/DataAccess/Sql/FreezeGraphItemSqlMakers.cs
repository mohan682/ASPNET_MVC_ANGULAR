﻿using Dcorum.Utilities.DataAccess;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using DCorum.Feature.Freeze.ViewModels;


namespace DCorum.Feature.Freeze.DataAccess
{
    public class FreezeEvent2SqlMaker : SimpleSqlFullCrud<FreezeEventVm, int, int>
    {
        internal FreezeEvent2SqlMaker(ISqlSpecification<FreezeEventVm> injectedSqlSpec)
            : base(injectedSqlSpec, new SimpleSqlCrudTemplateBuilder(injectedSqlSpec))
        {
            _injectedSqlSpec = injectedSqlSpec;
        }

        private readonly ISqlSpecification<FreezeEventVm> _injectedSqlSpec;
    }

    public class FreezeEventMemberSqlMaker : SimpleSqlFullCrud<FreezeEventMemberVm, int, int>
    {
        internal FreezeEventMemberSqlMaker(ISqlSpecification<FreezeEventMemberVm> injectedSqlSpec)
            : base(injectedSqlSpec, new SimpleSqlCrudTemplateBuilder(injectedSqlSpec))
        {
            _injectedSqlSpec = injectedSqlSpec;
        }

        private readonly ISqlSpecification<FreezeEventMemberVm> _injectedSqlSpec;

        public string DeleteExceptWhereIdIsIn(int[] idsToKeep, int freezeId)
        {
            string template1 = @"
                delete 
                from Freeze_Event_Member 
                where freeze_event_id = {1} and not ({0})" 
                ;
            string result = string.Format(template1, idsToKeep.IntoSqlInClause("Freeze_Event_Member_id", 1000), freezeId);
            return result;
        }
    }

    public class FreezeEventScopeSqlMaker : SimpleSqlFullCrud<FreezeEventScopeVm, int, int>
    {
        internal FreezeEventScopeSqlMaker(ISqlSpecification<FreezeEventScopeVm> injectedSqlSpec)
            : base(injectedSqlSpec, new SimpleSqlCrudTemplateBuilder(injectedSqlSpec))
        {
            _injectedSqlSpec = injectedSqlSpec;
        }

        private readonly ISqlSpecification<FreezeEventScopeVm> _injectedSqlSpec;
    }

    public class FreezeEventComponentOptionSqlMaker : SimpleSqlFullCrud<FreezeComponentOptionVm, int, int>
    {
        internal FreezeEventComponentOptionSqlMaker(ISqlSpecification<FreezeComponentOptionVm> injectedSqlSpec)
            : base(injectedSqlSpec, new SimpleSqlCrudTemplateBuilder(injectedSqlSpec, ComponentOptionCustomSqlCrudTemplates.Singleton))
        {
            _injectedSqlSpec = injectedSqlSpec;
        }

        private readonly ISqlSpecification<FreezeComponentOptionVm> _injectedSqlSpec;
    }

    internal class ComponentOptionCustomSqlCrudTemplates : SqlCrudTemplates
    {
        internal static readonly ComponentOptionCustomSqlCrudTemplates Singleton = new ComponentOptionCustomSqlCrudTemplates();

        private ComponentOptionCustomSqlCrudTemplates()
        {
            SimpleSelectManyTemplate = @"
SELECT 
    j1.REF_CD as COMPONENT_REF_CD, from1.* 
FROM
    {0} from1
RIGHT JOIN  ref_codes j1 
ON j1.ref_cd = from1.COMPONENT_REF_CD_VALUE and {1}

WHERE domain_name = 'FREEZE_COMPONENTS' and DISABLE_CD=0

ORDER BY j1.LINE_NO asc
";
        }

        internal const string SelectMissingOneTemplate = @"
SELECT 
    j1.REF_CD as COMPONENT_REF_CD, from1.* 
FROM
    {0} from1
RIGHT JOIN  ref_codes j1 
ON j1.ref_cd = from1.COMPONENT_REF_CD_VALUE and FREEZE_COMPONENT_OPTIONS_ID = {1}
WHERE 
    domain_name = 'FREEZE_COMPONENTS'
    and REF_CD = {2}
";

    }
}
