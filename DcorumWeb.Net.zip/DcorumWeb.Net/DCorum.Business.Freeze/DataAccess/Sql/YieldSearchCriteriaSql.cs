﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.Utilities.DataAccess;
using DCorum.Feature.Freeze.Contractual;
using DCorum.Feature.Freeze.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace DCorum.Feature.Freeze.DataAccess.Sql
{
    public class SearchCriteriaSqlMaker
    {
        internal SearchCriteriaSqlMaker()
        {
        }

        public IEnumerable<string> YieldSqlWhereCriteria(FreezeEventSearchCriteriaDm sc )
        {       
            // reference
            if (!string.IsNullOrEmpty(sc.Reference))
                yield return $"AND fe.REFERENCE LIKE {sc.Reference.SqlLikeQuotify()}";
            // description
            if (!string.IsNullOrEmpty(sc.Description))
                yield return $"AND fe.DESCRIPTION LIKE {sc.Description.SqlLikeQuotify()}";
            // start date from
            if (sc.StartDateFrom.HasValue)
                yield return $"AND TRUNC(fe.START_DATETIME) >= {sc.StartDateFrom.ToSqlShortDateString()}";
            // start date to
            if (sc.StartDateTo.HasValue)
                yield return $"AND TRUNC(fe.START_DATETIME) <= {sc.StartDateTo.ToSqlShortDateString()}";
            // end date from
            if (sc.ExpiryDateFrom.HasValue)
                yield return $"AND TRUNC(fe.END_DATETIME) >= {sc.ExpiryDateFrom.ToSqlShortDateString()}";
            // start date to
            if (sc.ExpiryDateTo.HasValue)
                yield return $"AND TRUNC(fe.END_DATETIME) <= {sc.ExpiryDateTo.ToSqlShortDateString()}";
            // include expired

            if (sc.FreezeStatus.HasValue)
            {
                yield return FreezeStatusSql(sc.FreezeStatus.Value);
            }


            if (sc.ThinScheme == null || sc.ThinScheme.CaseKey == null)
            {
                if (!string.IsNullOrWhiteSpace(sc.FreezeTypeCode))
                {
                    yield return $"AND fe.FREEZE_TYPE = {sc.FreezeTypeCode.SqlQuotify()}";
                }

                yield break;
            }

            Debug.Assert(sc.ThinScheme?.CaseKey != null);

            bool noFreezeType = string.IsNullOrWhiteSpace(sc.FreezeTypeCode); 

            if (noFreezeType)
            {
                yield return $"AND (";
                yield return ScopeCaseKeySql(sc.ThinScheme);
                yield return "OR " + MemberCaseKeySql(sc.ThinScheme.CaseKey.Value);
                yield return $"OR  (fe.FREEZE_TYPE = {FreezeTypeCodes.System.SqlQuotify()})";
                yield return ")";
            }
            else
            {
                if (FreezeTypeCodes.Scope.IsFreezeTypeEqualTo(sc.FreezeTypeCode)) yield return "AND " + ScopeCaseKeySql(sc.ThinScheme);
                if (FreezeTypeCodes.Member.IsFreezeTypeEqualTo(sc.FreezeTypeCode)) yield return "AND " + MemberCaseKeySql(sc.ThinScheme.CaseKey.Value);
            }
        }


        private string ScopeCaseKeySql(ISchemeThinReadOnly scheme)
        {
            var scopeSql = $@"( fe.FREEZE_TYPE = {FreezeTypeCodes.Scope.SqlQuotify()} 
                                      AND EXISTS(SELECT fes.* FROM FREEZE_EVENT_SCOPE fes 
                                                 WHERE fes.FREEZE_EVENT_ID = fe.FREEZE_EVENT_ID
                                                 AND (fes.CASE_KEY = {scheme.CaseKey} or fes.OVRD_CO_CD = '{scheme.ProviderCode}' or fes.PROD_TYP_CD = {scheme.ProductCode} or fes.PLAN_TYP_CD = '{scheme.PlanCode}' )))";
            return scopeSql;
        }


        private string MemberCaseKeySql(int caseKey)
        {
            var memberSql = $@"( fe.FREEZE_TYPE = {FreezeTypeCodes.Member.SqlQuotify()} 
                                        AND EXISTS(SELECT fem.* FROM FREEZE_EVENT_MEMBER fem
                                                    INNER JOIN COMPASS.CASE_MEMBERS cm ON cm.CASE_MBR_KEY = fem.CASE_MBR_KEY
                                                                                        AND cm.CASE_KEY = {caseKey}
                                                    WHERE fem.FREEZE_EVENT_ID = fe.FREEZE_EVENT_ID))";
            return memberSql;
        }


        private string FreezeStatusSql(FreezeStatus status)
        {
            switch (status)
            {
                case FreezeStatus.NotExpired:
                    return $"AND NOT(fe.END_DATETIME < SYSDATE)";
                case FreezeStatus.ActiveFreeze:
                    return $"AND (NOT(fe.END_DATETIME < SYSDATE) AND NOT(fe.START_DATETIME > SYSDATE))";
                case FreezeStatus.ScheduledFreeze:
                    return $"AND fe.START_DATETIME > SYSDATE";
                case FreezeStatus.ExpiredFreeze:
                    return $"AND fe.END_DATETIME < SYSDATE";
                case FreezeStatus.AllFreezes:
                    return null;
                default:
                    throw new ArgumentException("unsupported value", nameof(status));
            }
        }
    }
}
