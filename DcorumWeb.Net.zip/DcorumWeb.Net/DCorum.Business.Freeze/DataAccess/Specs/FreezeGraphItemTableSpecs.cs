﻿using Dcorum.Utilities.DataAccess;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.Feature.Freeze.ViewModels;
using System;
using System.Linq;

namespace DCorum.Feature.Freeze.DataAccess.Specs
{
    internal class FreezeGraphItemTableSpecs
    {
        internal static readonly ISqlSpecification<FreezeEventVm> FreezeEventSqlSpec =
            new SqlSpecification<FreezeEventVm>
            {
                TableName = "FREEZE_EVENT",
                ColumnNames = new[] { "FREEZE_EVENT_ID", "REFERENCE", "DESCRIPTION", "START_DATETIME", "END_DATETIME", "FREEZE_TYPE" }.ToArray(),

                MyIdentityIndexes = new[] { new[] { 0 } },
                UpdatableIndexes = new int[] { 1, 2, 3, 4, 5 },

                ParentKeyIndex = null,
                SqlSequenceName = "FREEZE_EVENT_SEQ",

                GettersForSql = new Func<FreezeEventVm, object>[]
                {
                    _ => _.Id,
                    _ => _.Reference.SqlQuotify(),
                    _ => _.Description.SqlQuotify(),
                    _ => _.Start.ToSqlDateTimeString(),
                    _ => _.End.ToSqlDateTimeString(),
                    _ => _.FreezeType.SqlQuotify() //.IntoSqlValue()
                }
            };


        internal static readonly ISqlSpecification<FreezeEventScopeVm> FreezeEventScopeSqlSpec =
            new SqlSpecification<FreezeEventScopeVm>
            {
                TableName = "FREEZE_EVENT_SCOPE",
                ColumnNames = new[] { "FREEZE_EVENT_SCOPE_ID", "FREEZE_EVENT_ID", "OVRD_CO_CD", "PROD_TYP_CD", "PLAN_TYP_CD", "CASE_KEY", "MBGP_KEY", "MBR_STAT_CD", "EMPR_KEY", "BGRP_KEY" }.ToArray(),

                MyIdentityIndexes = new[] { new[] { 0 }, new[] { 1, 2 } },
                UpdatableIndexes = new int[] {},

                ParentKeyIndex = 1,
                SqlSequenceName = "FREEZE_EVENT_SCOPE_SEQ",

                GettersForSql = new Func<FreezeEventScopeVm, object>[]
                {
                    _ => _.Id,
                    _ => _.FreezeEventId,
                    _ => _.OvrdCoCd.SqlQuotify(),
                    _ => _.ProdTypeCd.SqlQuotify(),
                    _ => _.PlanTypeCd.SqlQuotify(),
                    _ => _.CaseKey.IntoSqlValue(),
                    _ => _.MbgpKey.IntoSqlValue(),
                    _ => _.MbrStatCd.SqlQuotify(),
                    _ => _.EmprKey.SqlQuotify(),
                    _ => _.BgrpKey.SqlQuotify(),
                }
            };


        internal static readonly ISqlSpecification<FreezeEventMemberVm> FreezeEventMemberSqlSpec =
            new SqlSpecification<FreezeEventMemberVm>
            {
                TableName = "FREEZE_EVENT_MEMBER",
                ColumnNames = new[] { "FREEZE_EVENT_MEMBER_ID", "FREEZE_EVENT_ID", "CASE_MBR_KEY" }.ToArray(),

                MyIdentityIndexes = new[] { new[] { 0 }, new[] { 1, 2 } },
                UpdatableIndexes = new int[] { },

                ParentKeyIndex = 1,
                SqlSequenceName = "FREEZE_EVENT_MEMBER_SEQ",

                GettersForSql = new Func<FreezeEventMemberVm, object>[]
                {
                    _ => _.Id,
                    _ => _.FreezeEventId,
                    _ => _.CaseMbrKey,
                },
            };

        internal static readonly ISqlSpecification<FreezeComponentOptionVm> FreezeComponentOptionSqlSpec =
            new SqlSpecification<FreezeComponentOptionVm>
            {
                TableName = "FREEZE_COMPONENT_OPTIONS",
                ColumnNames = new[] { "FREEZE_COMPONENT_OPTIONS_ID", "FREEZE_EVENT_ID", "COMPONENT_REF_CD_VALUE", "SELECTED_REF_CD_VALUE", "MESSAGE" }.ToArray(),

                MyIdentityIndexes = new[] { new[] { 0 }, new[] { 1, 2 } },
                UpdatableIndexes = new int[] { 3, 4 },

                ParentKeyIndex = 1,
                SqlSequenceName = "FREEZE_COMPONENT_OPTIONS_SEQ",

                GettersForSql = new Func<FreezeComponentOptionVm, object>[]
                {
                    _ => _.Id,
                    _ => _.FreezeEventId,
                    _ => _.ComponentType.IntoSqlValue(),
                    _ => _.SelectedValue.IntoSqlValue(),
                    _ => _.Message.SqlQuotify()
                }
            };
    }
}
