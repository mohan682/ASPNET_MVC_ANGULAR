﻿using DCorum.DataAccessFoundation.DataAccess;
using DCorum.DataAccessFoundation.Extensions;
using DCorum.Feature.Freeze.DataAccess.Sql;
using DCorum.Feature.Freeze.ViewModels;
using System;
using System.Diagnostics;
using System.Linq;

using ModelAlias = DCorum.Feature.Freeze.ViewModels.FreezeEventViewGraph;

namespace DCorum.Feature.Freeze.DataAccess
{

    internal class FreezeGraphDal : CrudActor<ModelAlias, int, int>
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected FreezeGraphDal(FreezeGraphSqlMaker graphSqlMaker, IDbProxy dbProxy)
            : base(@reader => { throw new NotImplementedException(); }, graphSqlMaker)
        {
            _sqlMaker = graphSqlMaker;
            DbProxy = dbProxy;

            if (_sqlMaker==null) throw new ArgumentNullException(nameof(graphSqlMaker));
            if (DbProxy == null) throw new ArgumentNullException(nameof(dbProxy));
        }

        private readonly FreezeGraphSqlMaker _sqlMaker;
        private IDbProxy DbProxy { get; }


        /// <summary>
        /// 
        /// </summary>
        public override ModelAlias SelectViaPrimaryKey(int primaryId)
        {
            Func<object[]> deferredCannedDataId = () => new object[] { primaryId }; 

            string[] sqlSelectParts = _sqlMaker.SelectOneSql(primaryId).ToArray();

            if (sqlSelectParts?.Length != 4) throw new ArgumentException("Must inject 4 textual sql select statements!", nameof(sqlSelectParts));

            var step1                = DbProxy.GetSingle(sqlSelectParts[0], @reader => new FreezeEventVm(@reader), @deferredCannedDataId) ?? new FreezeEventVm(null);
            var step1CurrentDbValues = DbProxy.GetSingle(sqlSelectParts[0], @reader => new FreezeEventVm(@reader)) ?? new FreezeEventVm(null);

            var step2ScopeRows       = DbProxy.GetMany(sqlSelectParts[1], @reader => new FreezeEventScopeVm     (@reader), @deferredCannedDataId);
            var step2MemberRows      = DbProxy.GetMany(sqlSelectParts[2], @reader => new FreezeEventMemberVm    (@reader), @deferredCannedDataId);
            var step3                = DbProxy.GetMany(sqlSelectParts[3], @reader => new FreezeComponentOptionVm(@reader), @deferredCannedDataId);

            var creation1 = new ModelAlias(step1, step1CurrentDbValues, step2ScopeRows, step2MemberRows, step3);

            return creation1;
        }

        protected override void PreInsert( ModelAlias model )
        {
            Debug.Assert((model.StrongId > 0)==false);

            string[] seqNames = _sqlMaker.GetSequenceIdsForInsert().ToArray();
            if (seqNames?.Length != 4) throw new InvalidOperationException("Must have 4 sql sequencename to proceed!");

            model.Step1.Id = DbProxy.GetNextSequenceValue(seqNames[0]);

            model.Step2ScopeRows .AssignNewIds(model, true, () => DbProxy.GetNextSequenceValue(seqNames[1]));
            model.Step2MemberRows.AssignNewIds(model, true, () => DbProxy.GetNextSequenceValue(seqNames[2]));
            model.Step3          .AssignNewIds(model, true, () => DbProxy.GetNextSequenceValue(seqNames[3]));
        }


        protected override void PreUpdate( ModelAlias model )
        {
            Debug.Assert(model.StrongId > 0);

            string[] seqNames = _sqlMaker.GetSequenceIdsForInsert().ToArray();
            if (seqNames?.Length != 4) throw new InvalidOperationException("Must have 4 sql sequencename to proceed!");

            model.Step2ScopeRows .AssignNewIds(model, false, () => DbProxy.GetNextSequenceValue(seqNames[1]));
            model.Step2MemberRows.AssignNewIds(model, false, () => DbProxy.GetNextSequenceValue(seqNames[2]));
            model.Step3          .AssignNewIds(model, false, () => DbProxy.GetNextSequenceValue(seqNames[3]));
        }

    }
}
