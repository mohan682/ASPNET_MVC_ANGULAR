﻿using DCorum.DataAccessFoundation.DataAccess;
using DCorum.Feature.Freeze.DataAccess.Sql;
using DCorum.Feature.Freeze.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DCorum.Feature.Freeze.DataAccess
{
    public interface IFreezeEventDal
    {
        IEnumerable<FreezeEvent> GetAll();

        FreezeEvent Get(int id);

        IEnumerable<FreezeEvent> GetMany( FreezeEventSearchCriteriaDm searchCriteria );
    }

    public class FreezeEventDal : IFreezeEventDal
    {
        internal protected FreezeEventDal(SearchCriteriaSqlMaker criteriaSqlMaker, IDbProxy dbProxy)
        {
            CriterSqlMaker = criteriaSqlMaker;
            DbProxy = dbProxy;
            if (DbProxy == null) throw new ArgumentNullException(nameof(dbProxy));
        }

        private SearchCriteriaSqlMaker CriterSqlMaker { get; }
        private IDbProxy DbProxy { get; }

        private const string sqlSelect1 = @"SELECT fe.* FROM UEXT.FREEZE_EVENT fe";

        public IEnumerable<FreezeEvent> GetAll()
        {
            return DbProxy.GetMany(sqlSelect1, Create);
        }

        public FreezeEvent Get(int id)
        {
            var sql = sqlSelect1 + $@" WHERE FREEZE_EVENT_ID = {id}";

            return DbProxy.GetSingle(sql, Create, () => new object[] { id });
        }

        public IEnumerable<FreezeEvent> GetMany( FreezeEventSearchCriteriaDm searchCriteria )
        {
            string sql1 = sqlSelect1 + " WHERE 1 = 1";

            IEnumerable<string> yieldedSqlSelectCriteria = new[] { sql1 }.Concat( CriterSqlMaker.YieldSqlWhereCriteria( searchCriteria) ) ;

            string selectSql1 = string.Join(Environment.NewLine, yieldedSqlSelectCriteria);

            return DbProxy.GetMany(selectSql1, Create, () => new object[] { searchCriteria });
        }

        private FreezeEvent Create(System.Data.IDataReader reader)
        {
            return new FreezeEvent(reader);
        }
    }
}
