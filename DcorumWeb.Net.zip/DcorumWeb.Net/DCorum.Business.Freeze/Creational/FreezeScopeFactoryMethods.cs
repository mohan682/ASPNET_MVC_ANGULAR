﻿using Dcorum.BusinessCore.DataAccess;
using Dcorum.Utilities.Extensions;
using DCorum.Feature.Freeze.Validation;
using DCorum.Feature.Freeze.ViewModels;
using DcorumWeb.Utilities;
using System;
using System.Linq.Expressions;


namespace DCorum.Feature.Freeze.Creational
{

    public class FreezeScopeFactoryMethods
    {
        internal static readonly FreezeScopeFactoryMethods Singleton = new FreezeScopeFactoryMethods(SimpleDisplayablesDal.Singleton);

        private FreezeScopeFactoryMethods(SimpleDisplayablesDal repo1)
        {
            Repo1 = repo1;
        }


        private SimpleDisplayablesDal Repo1 { get; }

        /// <summary>
        /// Interrogate view to extract scope criteria using a supplied specialised technique. Items don't have to exist, they just need to be valid for the data type.
        /// </summary>
        public FreezeEventScopeVm ManualPullExtraScopeCriteriaFromView(Func<Expression<Func<FreezeEventScopeVm, object>>, string> pullTextFromViewTechnique, int? failureValue = null)
        {
            var criteria = new FreezeEventScopeVm();

            string schemeDescript = pullTextFromViewTechnique(_ => _.CaseKey);

            int? caseKey = TextualSchemeIdValidator.ParseToVerifiedCaseKeyN(schemeDescript, false);

            criteria.CaseKey = caseKey ?? (string.IsNullOrEmpty(schemeDescript) ? null : failureValue);


            string memberGroupDescript = pullTextFromViewTechnique(_ => _.MbgpKey);

            int? memberGroupKey = memberGroupDescript.IntoIntN() ?? memberGroupDescript.QuerySubstringBetween("[", "]", false, true).IntoIntN();

            criteria.MbgpKey = memberGroupKey ?? (string.IsNullOrEmpty(memberGroupDescript) ? null : failureValue);


            string billingGroupDescript = pullTextFromViewTechnique(_ => _.BgrpKey);

            int? billingGroupKey = billingGroupDescript.IntoIntN() ?? billingGroupDescript.QuerySubstringBetween("[", "]", false, true).IntoIntN(); ;

            criteria.BgrpKey = billingGroupKey ?? (string.IsNullOrEmpty(billingGroupDescript) ? null : failureValue);


            string employerDescript = pullTextFromViewTechnique(_ => _.EmprKey);

            int? employerKey = employerDescript.IntoIntN() ?? employerDescript.QuerySubstringBetween("[", "]", false, true).IntoIntN(); ;

            criteria.EmprKey = employerKey ?? (string.IsNullOrEmpty(employerDescript) ? null : failureValue);


            return criteria;
        }


        /// <summary>
        /// Create a validated version of the specified scope criteria;
        /// </summary>
        public FreezeEventScopeVm CreateValidatedScopeCriteria(FreezeEventScopeVm toValidate)
        {
            var criteria = new FreezeEventScopeVm();

            criteria.OvrdCoCd = toValidate.OvrdCoCd;
            criteria.ProdTypeCd = toValidate.ProdTypeCd;
            criteria.PlanTypeCd = toValidate.PlanTypeCd;
            criteria.MbrStatCd = toValidate.MbrStatCd;

            int? caseKey = TextualSchemeIdValidator.ParseToVerifiedCaseKeyN(toValidate.CaseKey?.ToString(), true);

            criteria.CaseKey = caseKey;


            int? memberGroupKey = toValidate.MbgpKey;

            var x1 = Repo1.FetchMemberGroupDisplayablesSubset(memberGroupKey ?? 0);

            criteria.MbgpKey = (x1.ContainsKey(memberGroupKey ?? 0)) ? memberGroupKey ?? 0 : (int?)null;



            int? billingGroupKey = toValidate.BgrpKey;

            var x2 = Repo1.FetchBillingGroupDisplayablesSubset(billingGroupKey ?? 0);

            criteria.BgrpKey = (x2.ContainsKey(billingGroupKey ?? 0)) ? billingGroupKey ?? 0 : (int?)null;



            int? employerKey = toValidate.EmprKey;

            var x3 = Repo1.FetchEmployerDisplayablesSubset(employerKey ?? 0);

            criteria.EmprKey = (x3.ContainsKey(employerKey ?? 0)) ? employerKey ?? 0 : (int?)null;


            return criteria;
        }

    }
}
