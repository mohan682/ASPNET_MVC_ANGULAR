﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessCore.DataAccess;
using Dcorum.BusinessCore.Modelling;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.Feature.Freeze.Contractual;
using DCorum.Feature.Freeze.Extensions;
using DCorum.Feature.Freeze.Models;
using DCorum.Feature.Freeze.ViewModels;
using DcorumWeb.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace DCorum.Feature.Freeze.Creational
{
    /// <summary>
    /// Projection extension methods.
    /// </summary>
    public static class ProjectionExtensions
    {
        /// <summary>
        /// Converts the freeze-event data-model into a view-row friendly equivalent.
        /// </summary>
        public static FreezeEventSummaryVm IntoViewModel(this FreezeEvent model, IDictionary<string, string> freezeTypes)
        {
            if (model == null) return null;

            var vm = new FreezeEventSummaryVm(model.Id);
            vm.End_Date = model.End;
            vm.Freeze_Description = model.Description;
            vm.Freeze_Ref = model.Reference;

            string freezeName = null;
            bool success = freezeTypes.TryGetValue(model.FreezeType, out freezeName);
            vm.Freeze_Type = (success)? freezeName : model.FreezeType + " Unrecognised!";

            vm.Start_Date = model.Start;

            return vm;
        }


        /// <summary>
        /// Converts the search-criteria view-model into a data-domain friendly equivalent.
        /// </summary>
        public static FreezeEventSearchCriteriaDm IntoSearchCriteriaDm(this FreezeEventSearchCriteriaVm searchCriteria, Func<string, ISchemeThinReadOnly> validateTextualSchemeTechnique)
        {
            var creation1 = new FreezeEventSearchCriteriaDm()
            {
                FreezeTypeCode = searchCriteria.FreezeType,
                Reference = searchCriteria.Reference,
                Description = searchCriteria.Description,
                FreezeStatus = searchCriteria.FreezeStatus.ToString().IntoEnum<FreezeStatus>(),
                ThinScheme = (searchCriteria.Scheme != null) ? validateTextualSchemeTechnique(searchCriteria.Scheme) : null,
                StartDateFrom = searchCriteria.StartDateFrom,
                StartDateTo = searchCriteria.StartDateTo,
                ExpiryDateFrom = searchCriteria.ExpiryDateFrom,
                ExpiryDateTo = searchCriteria.ExpiryDateTo
            };

            return creation1;
        }


        /// <summary>
        /// Converts the freeze-member data-row into a view-row friendly equivalent.
        /// </summary>
        public static object ReshapeToAnonymous(this Tuple<string,VEmployee> model)
        {
            var result = new
            {   Valid = model.Item2 != null
            ,   Case_Member_Key = model.Item1
            ,   NI_Number = model.Item2?.NatlIdNo
            ,   Surname = model.Item2?.LastName
            ,   Status = model.Item2?.MemberTypeCode
            ,   Scheme_Number = model.Item2?.ContNo
            ,   Scheme_Name = model.Item2?.PlanName 
            } ;

            return result;
        }

        /// <summary>
        /// Converts the freeze-scope data-row into a view-row friendly equivalent.
        /// </summary>
        public static object ReshapeToAnonymous(this FreezeEventScopeVm model, SimpleDisplayablesDal repo1, DLThinCompassScheme repo2)
        {
            string contractNumber = null;

            PropertyInfo levelPI = model.GetLevelPI(); 
   
            string levelTitle = levelPI.GetFirstAttribute<DisplayAttribute>()?.Name.QueryBeforeLastN(":");
            string levelValue = levelPI?.GetValue(model, null)?.ToString().NullIfWhiteSpace();
            string levelDisplayValue = null;
            string levelDomainName = levelPI?.GetFirstAttribute<RefCodeConstraintAttribute>()?.DomainName;
            if (string.IsNullOrEmpty(levelDomainName) == false)
            {
                levelDisplayValue = RefCodeCache.RetrieveByRefCodeValue(levelDomainName, levelValue)?.Descript;
            }
            else if (model.CaseKey.HasValue)
            {
                int caseKey = model.CaseKey.Value;

                var thinScheme = repo2.FetchLightScheme(caseKey) ;

                levelDisplayValue = thinScheme.Name ;
                contractNumber = thinScheme.ExternalId;

                //var x = repo1.FetchSchemeDisplayablesSubset(caseKey);
                //x.TryGetValue(caseKey, out levelDisplayValue );
            }

            //assumes mutual exclusivity!
            PropertyInfo refinementPI = model.GetRefinementPI();

            string refinementTitle = refinementPI.GetFirstAttribute<DisplayAttribute>()?.Name.QueryBeforeLastN(":");
            string refinementValue = refinementPI?.GetValue(model, null)?.ToString().NullIfWhiteSpace(); //.Replace(" ", "&nbsp;"); 
            string refinementDisplayValue = null;
            string refinementDomainName = refinementPI?.GetFirstAttribute<RefCodeConstraintAttribute>()?.DomainName;
            if (string.IsNullOrEmpty(refinementDomainName) == false)
            {
                refinementDisplayValue = RefCodeCache.RetrieveByRefCodeValue(refinementDomainName, refinementValue)?.Descript;
            }
            else
            {
                if (model.BgrpKey.HasValue)
                {
                    var x = repo1.FetchBillingGroupDisplayablesSubset(model.BgrpKey.Value);
                    x.TryGetValue(model.BgrpKey.Value, out refinementDisplayValue);
                }
                if (model.EmprKey.HasValue)
                {
                    var x = repo1.FetchEmployerDisplayablesSubset(model.EmprKey.Value);
                    x.TryGetValue(model.EmprKey.Value, out refinementDisplayValue);
                }
                if (model.MbgpKey.HasValue)
                {
                    var x = repo1.FetchMemberGroupDisplayablesSubset(model.MbgpKey.Value);
                    x.TryGetValue(model.MbgpKey.Value, out refinementDisplayValue);
                }
            }


            string valueSuffix = null;
            string memberStatusCode = null;

            if (model.MbrStatCd != null )
            {      
                var statCodePi = model.PI(_ => _.MbrStatCd);

                if (statCodePi != refinementPI)
                {
                    string statCodeDomainName = statCodePi.GetFirstAttribute<RefCodeConstraintAttribute>()?.DomainName;

                    var refCode = RefCodeCache.RetrieveByRefCodeValue(statCodeDomainName, model.MbrStatCd);

                    valueSuffix = $@" [{refCode?.Descript ?? model.MbrStatCd}] ";

                    memberStatusCode = " + " + model.MbrStatCd;
                }
            }

       
            var result = new
            {   Remove = model.MarkedForDeletion
            //,   _Id = model.Id
            ,   _TempId = model.TempId
            ,   Level_____ = levelTitle
            ,   Context__________ = contractNumber ?? levelValue
            ,   Refinement_____ = refinementTitle
            ,   Code_______ = (refinementValue) + memberStatusCode
            ,   Value________________________________________________________ = (refinementDisplayValue ?? levelDisplayValue ?? "???") + valueSuffix + ((model.IsFromDb)? null : "*")
            };

            return result;
        }

    }
}
