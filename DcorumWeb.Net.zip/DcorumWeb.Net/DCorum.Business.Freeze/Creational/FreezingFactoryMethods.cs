﻿using DCorum.Feature.Freeze.ViewModels;
using DCorum.Feature.Freeze.Controller;
using DCorum.Feature.Freeze.Validation;
using System.Collections.Generic;
using DCorum.Feature.Freeze.DataAccess;
using DCorum.BusinessFoundation.Validation;
using Dcorum.BusinessLayer.Contractual;
using DCorum.Feature.Freeze.DataAccess.Sql;
using DCorum.Feature.Freeze.DataAccess.Specs;
using Dcorum.BusinessCore.Creational;
using System;
using Dcorum.BusinessLayer.BusinesObjects;
using DCorum.Feature.Freeze.Contractual;
using System.Linq;
using Dcorum.BusinessCore.Contractual;
using Dcorum.Utilities.Extensions;


namespace DCorum.Feature.Freeze.Creational
{
    public sealed class FreezingFactoryMethods
    {
        public static readonly FreezingFactoryMethods Singleton = new FreezingFactoryMethods( CoreAbstractFactoryMethods.Singleton );
        private FreezingFactoryMethods(ICoreAbstractFactory coreAbstractFactory)
        {
            CoreAbstractFactory = coreAbstractFactory;
        }

        private ICoreAbstractFactory CoreAbstractFactory { get; }

        /// <summary>
        /// Used on the list page
        /// </summary>
        /// <returns></returns>
        public IFreezeEventConfigController CreateFreezeEventConfigController(IAuditingArgumentsReadOnly caller)
        {
            var user1 = CoreAbstractFactory.FetchDcorumUser(caller.UserId);
            var myDbProxy = CoreAbstractFactory.CreateDbProxy();

                     
            Func<string, ISchemeThinReadOnly> convertTextualSchemeTechnique = @textual => TextualSchemeIdValidator.ParseToScheme(@textual);


            var availableFreezeTypes = RefCodeCache.RetrieveByDomainName(FreezeDomainNames.FreezeType, true, false);
            IDictionary<string, string> freezeKeyedPairs = availableFreezeTypes.OrderBy(o => o.RefCd).ToDictionary(_ => _.RefCd, _ => _.Descript);


            return new FreezeEventConfigController(
                user1,
                new FreezeEventDal( new SearchCriteriaSqlMaker(), myDbProxy ),
                @searchCriteriaVm => searchCriteriaVm.IntoSearchCriteriaDm(@convertTextualSchemeTechnique),
                @args => CreateValidateSearchCriteriaRules(@args, @convertTextualSchemeTechnique),
                @keyedFreezeTypesDescriptions => @GetDefaultSearchCriteria(@keyedFreezeTypesDescriptions),
                freezeKeyedPairs
                );
        }



        private IEnumerable<IRule> CreateValidateSearchCriteriaRules(FreezeEventSearchCriteriaVm viewModel, Func<string, ISchemeThinReadOnly> validateTextualSchemeTechnique)
        {
            FreezeEventValidationFactory factory1 = new FreezeEventValidationFactory( new CommonValidationFactory() );

            yield return factory1.CreateValidateDescriptionRule(viewModel);
            yield return factory1.CreateValidateReferenceRule(viewModel);
            yield return factory1.CreateValidateSchemeRule(viewModel, @validateTextualSchemeTechnique);
            yield return factory1.CreateValidateStartDatesRule(viewModel);
            yield return factory1.CreateValidateExpiryDatesRule(viewModel);
            yield return factory1.CreateValidateDateRangesRule(viewModel);
        }



        private FreezeEventSearchCriteriaVm GetDefaultSearchCriteria(IDictionary<string, string> availableFreezeTypes)
        {
            var vm = new FreezeEventSearchCriteriaVm()
            {
                AvailableFreezeTypes = availableFreezeTypes.OrderBy(o => o.Key).ToDictionary(_ => _.Key, _ => _.Value),
                AvailableFreezeStatuses = typeof(FreezeStatus).IntoDescriptionDictionary(EnumExtensions.@GetDescription)
            };

            return vm;
        }



        public FreezeGraphController CreateFreezeEventFormController(IAuditingArgumentsReadOnly2 caller, bool readonlyModeOn)
        {
            var user1 = CoreAbstractFactory.FetchDcorumUser(caller.UserId);
            var myDbProxy = CoreAbstractFactory.CreateDbProxy() ;

            var sqlMaker = new FreezeGraphSqlMaker
                ( new FreezeEvent2SqlMaker(FreezeGraphItemTableSpecs.FreezeEventSqlSpec)
                , new FreezeEventScopeSqlMaker(FreezeGraphItemTableSpecs.FreezeEventScopeSqlSpec)
                , new FreezeEventMemberSqlMaker(FreezeGraphItemTableSpecs.FreezeEventMemberSqlSpec)
                , new FreezeEventComponentOptionSqlMaker(FreezeGraphItemTableSpecs.FreezeComponentOptionSqlSpec)
                )
                ;

            var EmployeeController = BusinessCoreFactoryMethods.CreateEmployeeController();

            var creation1 = new FreezeGraphController(user1, caller, new FreezeGraphDal(sqlMaker, myDbProxy), EmployeeController);

            return creation1;
        }

    }
}
