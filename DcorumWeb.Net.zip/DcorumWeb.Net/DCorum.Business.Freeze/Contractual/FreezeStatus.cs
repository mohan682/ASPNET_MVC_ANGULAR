﻿using System.ComponentModel;

namespace DCorum.Feature.Freeze.Contractual
{
    public enum FreezeStatus
    {
        [Description("Not Expired")]
        NotExpired = 0,
        [Description("Active")]
        ActiveFreeze = 1,
        [Description("Scheduled")]
        ScheduledFreeze = 2,
        [Description("Expired")]
        ExpiredFreeze = 3,
        [Description("All")]
        AllFreezes = 4
    }
}
