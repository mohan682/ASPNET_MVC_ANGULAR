﻿using System;


namespace DCorum.Feature.Freeze.Contractual
{
    //each item must be unique!
    internal static class FreezeTypeCodes
    {
        /// <summary>
        /// 00
        /// </summary>
        public const string System = "02";

        /// <summary>
        /// 01
        /// </summary>
        public const string Scope = "00";

        /// <summary>
        /// 02
        /// </summary>
        public const string Member = "01";
    }


    internal static class FreezeTypeCodeExtensions
    {
        /// <summary>
        /// false if either arguemnt is null|blank|whitespace, otherwise result is the outcome of a string comparison.
        /// </summary>
        public static bool IsFreezeTypeEqualTo(this string toEquate, string refCode)
        {
            if (string.IsNullOrWhiteSpace(toEquate)) return false;          
            if (string.IsNullOrWhiteSpace(refCode)) return false;

            bool success = string.Equals(toEquate, refCode.PadLeft(2, '0'), StringComparison.OrdinalIgnoreCase);
            return success;
        }
    }

}
