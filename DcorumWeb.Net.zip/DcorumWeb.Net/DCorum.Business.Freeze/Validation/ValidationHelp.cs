﻿using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Feature.Freeze.Validation
{
    public static class ValidationHelp
    {
        /// <summary>
        /// Helper method to detemine bad texualised keys either because they're not numeric 
        /// or because they don't correspond to a real item as determined via the injected verification technique.
        /// </summary>
        public static string[] DetermineBadKeysViaVerification(string[] allKeysOfInterest, Func<int[], IEnumerable<int>> numericKeyVerificationTechnique)
        {
            Tuple<string, int?>[] pairs = allKeysOfInterest.SafeLinq().Select(_ => Tuple.Create(_, _.IntoIntN())).ToArray();

            if (pairs.All(_ => _.Item2 == null)) return allKeysOfInterest; //all bad because none are numeric!!!!

            int[] numericKeys = pairs.Where(_ => _.Item2 > 0).Select(_ => _.Item2.Value).ToArray();

            int[] goodNumericKeys = numericKeyVerificationTechnique(numericKeys).ToArray();

            string[] nonNumeric = pairs.Where(_ => _.Item2 == null).Select(_ => _.Item1).ToArray();

            string[] badKeys = (numericKeys.Except(goodNumericKeys)).Select(_ => _.ToString()).Concat(nonNumeric).ToArray();

            return badKeys;
        }
    }
}
