﻿using Dcorum.BusinessCore.Contractual;
using DCorum.BusinessFoundation.Validation;
using DCorum.Feature.Freeze.ViewModels;
using System;

namespace DCorum.Feature.Freeze.Validation
{
    public class FreezeEventValidationFactory
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal FreezeEventValidationFactory(CommonValidationFactory subValidationFactory)
        {
            SubValidationFactory = subValidationFactory;
        }

        private CommonValidationFactory SubValidationFactory { get; }

        public IRule CreateValidateDescriptionRule(FreezeEventSearchCriteriaVm vm)
        {
            return SubValidationFactory.CreateValidateNonEmptyWhiteSpaceFieldRule(vm.Description, "Freeze description field not set");
        }

        public IRule CreateValidateReferenceRule(FreezeEventSearchCriteriaVm vm)
        {
            return SubValidationFactory.CreateValidateNonEmptyWhiteSpaceFieldRule(vm.Reference, "Freeze reference field not set");
        }

        public IRule CreateValidateSchemeRule(FreezeEventSearchCriteriaVm vm, Func<string, ISchemeThinReadOnly> validateTextualSchemeTechnique)
        {
            return new Rule(
                () =>
                {
                    if (vm.Scheme != null)
                    {
                        if(string.IsNullOrWhiteSpace(vm.Scheme))
                            throw new ValidationException("Scheme field not set");

                        ISchemeThinReadOnly thinScheme = validateTextualSchemeTechnique?.Invoke(vm.Scheme);
                        if (!(thinScheme.CaseKey>0))
                            throw new ValidationException("Invalid Scheme");
                    }
                });
        }

        public IRule CreateValidateStartDatesRule(FreezeEventSearchCriteriaVm vm)
        {
            return SubValidationFactory.CreateValidateDatesRule(vm.StartDateFrom, vm.StartDateTo, "Start");
        }

        public IRule CreateValidateExpiryDatesRule(FreezeEventSearchCriteriaVm vm)
        {
            return SubValidationFactory.CreateValidateDatesRule(vm.ExpiryDateFrom, vm.ExpiryDateTo, "Expiry");
        }

        public IRule CreateValidateDateRangesRule(FreezeEventSearchCriteriaVm vm)
        {
            return new Rule(
                () =>
                {
                    if (vm.StartDateFrom.HasValue && vm.ExpiryDateFrom.HasValue)
                    {
                        if (vm.StartDateFrom.Value > vm.ExpiryDateFrom.Value)
                            throw new ValidationException($"Start Date From ({vm.StartDateFrom.Value.ToString("dd/MM/yyyy")}) can not be greater than Expiry Date From ({vm.ExpiryDateFrom.Value.ToString("dd/MM/yyyy")})");
                    }

                    if (vm.StartDateTo.HasValue && vm.ExpiryDateTo.HasValue)
                    {
                        if (vm.StartDateTo.Value > vm.ExpiryDateTo.Value)
                            throw new ValidationException($"Start Date To ({vm.StartDateTo.Value.ToString("dd/MM/yyyy")}) can not be greater than Expiry Date To ({vm.ExpiryDateTo.Value.ToString("dd/MM/yyyy")})");
                    }
                });
        }
    }
}
