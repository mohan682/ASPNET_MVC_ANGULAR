﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessCore.Creational;
using Dcorum.Utilities.Extensions;
using DcorumWeb.Utilities;

namespace DCorum.Feature.Freeze.Validation
{
    public static class TextualSchemeIdValidator
    {
        private static ISchemeThinFetcher CompassSchemeSource1 = ThinSchemeFactoryMethods.Singleton.CreateCompassSchemeReader();

        public static int? ParseToVerifiedCaseKeyN(string contextKey, bool validateNumericModeOn = true)
        {
            if (contextKey == null) return null;

            int? caseKey = contextKey.IntoIntN();
            string innerText = null;

            if (caseKey == null)
            {
                innerText = contextKey.QuerySubstringBetween("[", "]", false, true);

                caseKey = contextKey.IntoIntN();
            }


            if (caseKey.HasValue)
            {
                if (validateNumericModeOn) caseKey = CompassSchemeSource1.FetchLightScheme(caseKey.Value)?.CaseKey;
            }
            else
            {
                caseKey = CompassSchemeSource1.FetchLightScheme(innerText)?.CaseKey;
            }

            return caseKey;
        }


        public static ISchemeThinReadOnly ParseToScheme(string contextKey)
        {
            int? caseKey = ParseToVerifiedCaseKeyN(contextKey, true) ;
            ISchemeThinReadOnly result = (caseKey == null) ? null : CompassSchemeSource1.FetchLightScheme(caseKey.Value);
            return result ;
        }

    }
}
