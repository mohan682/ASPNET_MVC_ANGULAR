﻿using System;
using System.Collections;
using System.Diagnostics;

namespace DCorum.Feature.Freeze.Controller
{
    public class EncounterMemory
    {
        public EncounterMemory(IDictionary storage)
        {
            TempStore = storage ;
        }

        private IDictionary TempStore { get; }


        public TModel Obtain<TKey, TModel>( TKey id, Func<TKey,TModel> getFromElsewhere, bool isNewEncounter )
        {
            Debug.Assert(getFromElsewhere != null);

            if (isNewEncounter)
            {
                string defaultKey = GetKey<TKey, TModel>(default(TKey));

                if (TempStore.Contains(defaultKey))
                {
                    TempStore.Remove(defaultKey);
                    Console.WriteLine($"Removing memory of {defaultKey}");
                }
            }

            // ------------------

            string key = GetKey<TKey, TModel>(id);

            if (isNewEncounter && TempStore.Contains(key))
            {
                TempStore.Remove(key);
                Console.WriteLine($"Removing memory of {key}");
            }

            if (TempStore.Contains(key)==false)
            {
                TempStore.Add(key, getFromElsewhere(id));
                Console.WriteLine($"Remembering {key}");
            }

            TModel result = (TModel)TempStore[key];

            return result ;
        }


        private string GetKey<TKey, TModel>(TKey id)
        {
            string part2 = id.ToString();
            if (string.IsNullOrWhiteSpace(part2)) throw new ArgumentException("", nameof(id));
            return typeof(TModel).Name + part2 ;
        }


        public void Putback<TKey, TModel>(TKey id, TModel toRemember)
        {     
            //-----

            if (toRemember==null)
            {
                string defaultKey = GetKey<TKey, TModel>(default(TKey));

                if (TempStore.Contains(defaultKey))
                {
                    TempStore.Remove(defaultKey);
                    Console.WriteLine($"Removing memory of {defaultKey}");
                }
            }


            string key = GetKey<TKey, TModel>(id);

            if (TempStore.Contains(key))
            {
                if (toRemember != null)
                {
                    TempStore[key] = toRemember;
                }
                else
                {
                    TempStore.Remove(key) ;
                    Console.WriteLine($"Removing memory of {key}");
                }
            }
            else if(ReferenceEquals(toRemember,default(TModel))==false)
            {
                TempStore.Add(key, toRemember);
            }
        }
    }
}
