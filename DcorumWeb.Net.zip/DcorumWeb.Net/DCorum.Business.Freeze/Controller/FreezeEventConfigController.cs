﻿using Dcorum.Configuration.Contractual;
using DCorum.BusinessFoundation.Validation;
using DCorum.Feature.Freeze.Creational;
using DCorum.Feature.Freeze.DataAccess;
using DCorum.Feature.Freeze.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using DCorum.Feature.Freeze.Models;


using UserAlias = Dcorum.BusinessCore.Contractual.IDcorumUser;


namespace DCorum.Feature.Freeze.Controller
{

    using SearchValidationTechniqueAlias = Func<FreezeEventSearchCriteriaVm, IEnumerable<IRule>>;

    public interface IFreezeEventConfigController
    {
        FreezeEventSearchCriteriaVm GetDefaultSearchCriteria();

        bool Validate(FreezeEventSearchCriteriaVm searchCriteria, ref string error);

        FreezeEventSummaryVm GetOne(int freezeEventId);

        IEnumerable<FreezeEventSummaryVm> GetMany(FreezeEventSearchCriteriaVm searchCriteria);

        bool CanAddNew { get; }
    }


    public class FreezeEventConfigController : IFreezeEventConfigController
    {
        #region Fields

        private readonly IFreezeEventDal _freezeEventDal;

        /// <summary>
        /// Converts the search-criteria view-model to a data-domain friendly equivalent.
        /// </summary>
        private Func<FreezeEventSearchCriteriaVm, FreezeEventSearchCriteriaDm> SearchCriteriaProjectionTechnique { get; }

        private readonly SearchValidationTechniqueAlias _searchValidationTechnique;

        Func<IDictionary<string, string>,FreezeEventSearchCriteriaVm> CreateSearchCriteriaTechnique { get; }

        private IDictionary<string, string> _availableFreezeTypes;

        #endregion

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        /// <param name="freezeEventDal"></param>
        /// <param name="caseDataDal"></param>
        /// <param name="searchValidationTechnique"></param>
        internal protected FreezeEventConfigController(
            UserAlias user,
            IFreezeEventDal freezeEventDal,
            Func<FreezeEventSearchCriteriaVm, FreezeEventSearchCriteriaDm> searchCriteriaProjectionTechnique,
            SearchValidationTechniqueAlias searchValidationTechnique,
            Func<IDictionary<string, string>,FreezeEventSearchCriteriaVm> createSearchCriteriaTechnique,
            IDictionary<string, string> freezeKeyedPairs)
        {
            _freezeEventDal = freezeEventDal;

            SearchCriteriaProjectionTechnique = searchCriteriaProjectionTechnique ;

            CreateSearchCriteriaTechnique = createSearchCriteriaTechnique ;

            _searchValidationTechnique = searchValidationTechnique;

            CanAddNew = user.IsInGroup( GroupId.FreezeConfigurationEdit ) ;

            _availableFreezeTypes = freezeKeyedPairs;

            if (_searchValidationTechnique == null) throw new ArgumentNullException(nameof(searchValidationTechnique));
        }

        #region IFreezeEventConfigController

        public bool CanAddNew { get; }

        public bool Validate(FreezeEventSearchCriteriaVm searchCriteria, ref string error)
        {
            try
            {
                var searchRules = _searchValidationTechnique(searchCriteria).ToArray();
                new Validator().Validate(searchRules);
                return true;
            }
            catch(Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public FreezeEventSummaryVm GetOne(int freezeEventId)
        {
            var dataModel = _freezeEventDal.Get(freezeEventId);

            var viewModel = dataModel.IntoViewModel(_availableFreezeTypes);

            return viewModel;
        }


        public IEnumerable<FreezeEventSummaryVm> GetMany(FreezeEventSearchCriteriaVm searchCriteria)
        {
            if (searchCriteria.FreezeType!=null)
            {
                bool success = _availableFreezeTypes.ContainsKey(searchCriteria.FreezeType) ;

                if (!success) throw new ArgumentException($"freeze-type '{searchCriteria.FreezeType}' in search criteria is invalid!", nameof(searchCriteria));
            }                     
         

            var models = _freezeEventDal.GetMany( SearchCriteriaProjectionTechnique( searchCriteria ) );
    

            if (!models.Any()) return new FreezeEventSummaryVm[] { };

            return models.Select(m=>m.IntoViewModel(_availableFreezeTypes)).OrderByDescending( _ => _.Freeze_Ref, StringComparer.InvariantCultureIgnoreCase);
        }


        public FreezeEventSearchCriteriaVm GetDefaultSearchCriteria()
        {
            return CreateSearchCriteriaTechnique( _availableFreezeTypes ) ;
        }

        #endregion
    }
}
