﻿using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.Contractual;
using System;
using System.Diagnostics;


namespace DCorum.Feature.Freeze.Controller
{
    public class SubAuditingDal<TModel>
        where TModel : class, IAmATypicalDataParent
    {
        internal SubAuditingDal(ICrudIn<TModel> injectedCrud, IRemarksActor remarksVessel, int idOfNonExistantModel, int userId, string auditCategory, Func<int,TModel> fetchModelTechnique )
        {
            AmbientValue = idOfNonExistantModel ;
            UserId = userId ;
            InjectedCrud = injectedCrud ;
            AuditCategory = auditCategory ;
            RemarksVessel = remarksVessel ;
            FetchModelTechnique = fetchModelTechnique ;
        }


        private int AmbientValue { get; }
        private int UserId { get; }
        private string AuditCategory { get; }

        ICrudIn<TModel> InjectedCrud {get;}
        IRemarksActor RemarksVessel { get; }

        Func<int, TModel> FetchModelTechnique { get; }


        public void Insert(TModel model)
        {
            int strongId = model?.StrongId ?? AmbientValue;

            Debug.Assert(!(model.StrongId > AmbientValue));

            TModel modelBefore = Fetch(strongId);

            Debug.Assert(modelBefore == null);

            int rowsAffected = InjectedCrud.Insert(model);

            Debug.Assert(model.StrongId > AmbientValue);

            TModel modelAfter = Fetch(model.StrongId);

            Audit(rowsAffected, modelBefore, modelAfter);
        }


        public void Update(TModel model)
        {
            int strongId = model?.StrongId ?? AmbientValue;

            Debug.Assert(model.StrongId > AmbientValue);

            TModel modelBefore = Fetch(strongId);

            int rowsAffected = InjectedCrud.Update(model);

            Debug.Assert(model.StrongId == strongId);

            TModel modelAfter = Fetch(model.StrongId);

            Audit(rowsAffected, modelBefore, modelAfter);
        }


        public void Delete(TModel model)
        {
            int strongId = model?.StrongId ?? AmbientValue;

            Debug.Assert(model.StrongId > AmbientValue);

            int rowsAffected = InjectedCrud.Delete(model);

            TModel modelAfter = Fetch(strongId);

            Debug.Assert(modelAfter == null || modelAfter.StrongId == AmbientValue);

            Audit(rowsAffected, model, modelAfter);
        }


        private Tuple<RefCode, string> GetAuditFriendlyId(TModel toUse)
        {
            return Tuple.Create<RefCode, string>(null, toUse.StrongId.ToString());
        }


        private void Audit(int rowsAffected, TModel modelBefore, TModel modelAfter, int depthOfAudit = 3)
        {
            var auditId = GetAuditFriendlyId(modelBefore ?? modelAfter);

            var auditor = BusinessCoreFactoryMethods.CreateAuditor( AuditCategory, UserId, RemarksVessel, depthOfAudit, _ => auditId);

            bool good = RemarksVessel.RemarkUponRowsAffected(rowsAffected, 0, int.MaxValue);

            auditor.AuditChanges(good, modelAfter, modelBefore, null);
        }


        private TModel Fetch(int? strongId)
        {
            if (!(strongId > 0)) return null;

            TModel fetched1 = FetchModelTechnique(strongId.Value);

            return fetched1;
        }
    }
}
