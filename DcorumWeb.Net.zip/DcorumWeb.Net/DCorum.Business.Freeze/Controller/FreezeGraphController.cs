﻿using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessCore.Modelling;
using Dcorum.BusinessLayer.Bundles;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.Configuration.Contractual;
using Dcorum.RefCoding;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.BusinessFoundation.Bases;
using DCorum.BusinessFoundation.Contractual;
using DCorum.Feature.Freeze.Creational;
using DCorum.Feature.Freeze.DataAccess;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using Dcorum.Utilities.Textual;
using Dcorum.BusinessCore.Contractual;
using System.Linq.Expressions;
using Dcorum.BusinessCore.DataAccess;
using DCorum.Feature.Freeze.ViewModels;
using DCorum.Feature.Freeze.Validation;

using ModelAlias = DCorum.Feature.Freeze.ViewModels.FreezeEventViewGraph;


namespace DCorum.Feature.Freeze.Controller
{
    [Category(DomainCodes.DCorumFreezeEvent)]
    public class FreezeGraphController : BLPersistorTemplate<ModelAlias, int, int>, IPersistor<ModelAlias>
    {
        internal FreezeGraphController(IDcorumUser user, IAuditingArgumentsReadOnly2 caller, FreezeGraphDal injectedCrud, BundledEmployee.BLEmployee employeeController)
            : base(caller, injectedCrud)
        {
            _injectedCrud = injectedCrud;
            _employeeController = employeeController;

            IsNewEncounter = caller.IsNewEncounter;
            TempStore = SessionCaretakerBase.Storage;

            ReadOnlyModeOn = user.IsInGroup(GroupId.FreezeConfigurationEdit) == false;
        }

        private IDictionary TempStore { get; }
        private bool IsNewEncounter { get; }

        private readonly FreezeGraphDal _injectedCrud;
        private readonly BundledEmployee.BLEmployee _employeeController;


        protected override Tuple<RefCode, string> GetAuditFriendlyId(ModelAlias toUse)
        {
            return Tuple.Create<RefCode, string>(null, toUse.StrongId.ToString());
        }


        public override void Hydrate(ModelAlias toHydrate)
        {
            if (toHydrate == null) return;

            RefCodeHelp.DoBuildRefCodes(toHydrate);
            RefCodeHelp.DoBuildRefCodes(toHydrate.Step1);

            foreach (var current1 in toHydrate.Step2ScopeRows.SafeLinq())
            {
                RefCodeHelp.DoBuildRefCodes(current1);
            }

            foreach (var current1 in toHydrate.Step2MemberRows.SafeLinq())
            {
                RefCodeHelp.DoBuildRefCodes(current1);
            }

            foreach (var current1 in toHydrate.Step3.SafeLinq())
            {
                RefCodeHelp.DoBuildRefCodes(current1);

                if (current1.SelectedValue?.RefCd != null)
                {
                    string selectedDomainName = current1.ComponentType.LongDesc;

                    if (string.IsNullOrEmpty(selectedDomainName))
                    {
                        current1.SelectedValue = null;
                        continue;
                    }
                    IEnumerable<RefCode> options = RefCodeCache.RetrieveByDomainName(selectedDomainName, true);
                    current1.SelectedValue = RefCodeHelp.IntoHydratedRefCodeVia(current1.SelectedValue, options);
                }
            }

            //toHydrate.CanPersist = (!ReadOnlyModeOn);
        }


        protected override void Insert(ModelAlias model)
        {
            int strongId = model?.StrongId ?? AmbientValue;

            Debug.Assert(!(model.StrongId > AmbientValue));

            ModelAlias modelBefore = Fetch(strongId);

            Debug.Assert(modelBefore == null);

            int rowsAffected = _injectedCrud.Insert(model);

            Debug.Assert(model.StrongId > AmbientValue);

            ModelAlias modelAfter = Fetch(model.StrongId);

            Audit(rowsAffected, modelBefore, modelAfter);
        }


        protected override void Update(ModelAlias model)
        {
            int strongId = model?.StrongId ?? AmbientValue;

            Debug.Assert(model.StrongId > AmbientValue);

            ModelAlias modelBefore = Fetch(strongId);

            int rowsAffected = _injectedCrud.Update(model);

            ModelAlias modelAfter = Fetch(model.StrongId);

            Audit(rowsAffected, modelBefore, modelAfter);
        }


        protected override void Delete(ModelAlias model)
        {
            int strongId = model?.StrongId ?? AmbientValue;

            Debug.Assert(model.StrongId > AmbientValue);

            //model.Flags = _deferredChildrenController.Value.GetMany(strongId).Where(_ => _.Id > 0).SafeLinq().ToArray();

            int rowsAffected = _injectedCrud.Delete(model);

            ModelAlias modelAfter = Fetch(strongId);

            Debug.Assert(modelAfter?.StrongId == null);

            Audit(rowsAffected, model, modelAfter);
        }


        protected override void Validate(ModelAlias model)
        {
            if (model == null)
            {
                RemarksVessel.RemarkNoItemSpecified = true;
                return;
            }

            if (model.Step1.Start > model.Step1.End)
            {
                RemarksVessel.IncludeCustomRemarks("Start date must be before the end date!");
            }

            if ((model.Step1.Start <= DateTime.Now) && model.IsActive == false)
            {
                RemarksVessel.IncludeCustomRemarks("Start date must be in the future!");
            }

            if (model.Step1.End < DateTime.Now.AddMinutes(1))
            {
                RemarksVessel.IncludeCustomRemarks("End date must be in the future!");
            }

            if (model.IsMemberModeOn)
            {
                if (model.Step2MemberRows?.Any() != true)
                {
                    RemarksVessel.IncludeCustomRemarks("At least one member is required!");
                }
                else if (model.Step2MemberRows.Any(_ => _.IsBadCaseMemberKey == true && _.IsFromDb == false))
                {
                    RemarksVessel.IncludeCustomRemarks("Uploaded file contains some invalid members.");
                }
            }

            if (model.IsScopeModeOn)
            {
                if (model.Step2ScopeRows?.Any() != true)
                {
                    RemarksVessel.IncludeCustomRemarks("At least one scope item is required!");
                }
                //else if (model.Step2ScopeRows.Any(_ => _.IsFromDb == false && _.IsFromDb == false))
                //{
                //    RemarksVessel.IncludeCustomRemarks("Please remove invalid scope items.");
                //}
            }
        }


        public override IEnumerable<IOutcomeItem> Save(ModelAlias model)
        {
            var results = base.Save(model);

            if (results.Any() == false)
            {
                model = Fetch(model.StrongId);
                Putback(model, true); //don't let the 'add new' copy of the model linger in memory!
            }

            return results;
        }


        public override ModelAlias GetUnique(int primaryId)
        {
            string key = typeof(ModelAlias).Name + primaryId;

            ModelAlias result;

            if (IsNewEncounter)
            {
                result = base.GetUnique(primaryId);
                Putback(result);
            }

            result = (ModelAlias)TempStore[key];

            return result;
        }


        protected void Putback(ModelAlias toRemember, bool removeDefault = false)
        {
            if (toRemember == null) throw new ArgumentNullException(nameof(toRemember));

            string keyTemplate = string.Format(@"{0}{1}", toRemember.GetType().Name, "{0}");

            //-----

            if (removeDefault)
            {
                string defaultkey = string.Format(keyTemplate, (toRemember.StrongId ?? 0));

                if (TempStore.Contains(defaultkey))
                {
                    TempStore[defaultkey] = toRemember;
                }
            }

            //-----

            string key = string.Format(keyTemplate, (toRemember.StrongId ?? 0));

            if (TempStore.Contains(key))
            {
                TempStore[key] = toRemember;
            }
            else
            {
                TempStore.Add(key, toRemember);
            }
        }



        public bool CanDelete(ModelAlias formModel1)
        {
            if (ReadOnlyModeOn) return false;

            bool result = !formModel1.IsActive && !formModel1.IsExpired;
            return result;
        }

        public bool CanSave(ModelAlias formModel1)
        {
            if (ReadOnlyModeOn) return false;

            bool result = !formModel1.IsExpired;
            return result;
        }

        private void Audit(int rowsAffected, ModelAlias modelBefore, ModelAlias modelAfter)
        {
            var auditId = GetAuditFriendlyId(modelBefore ?? modelAfter);

            var auditor = BusinessCoreFactoryMethods.CreateAuditor(Category, Caller.UserId, RemarksVessel, 3, _ => auditId);

            bool good = RemarksVessel.RemarkUponRowsAffected(rowsAffected, 0, int.MaxValue);

            auditor.AuditChanges(good, modelAfter, modelBefore, null);
        }


        private ModelAlias Fetch(int? strongId)
        {
            if (!(strongId > 0)) return null;

            ModelAlias fetched1 = base.GetUnique(strongId.Value);

            return fetched1;
        }

        public object[] AnonymousMembers(ModelAlias model)
        {
            if (model.IsMemberModeOn == false) return null;

            int[] maybeGoodKeys = model.Step2MemberRows.Select(_ => _.CaseMbrKey.IntoIntN() ?? 0).Where(_ => _ > 0).ToArray();
            VEmployee[] existingEmployees = _employeeController.GetMany(maybeGoodKeys);

            string[] badKeys = model.Step2MemberRows.Select(_ => _.CaseMbrKey).Except(existingEmployees.Select(_ => _.CaseMemberKey.ToString())).ToArray();

            Tuple<string, VEmployee>[] badPairs = badKeys.Select(@key => Tuple.Create(@key, (VEmployee)null)).ToArray();

            Tuple<string, VEmployee>[] goodPairs = existingEmployees.Select(@emp => Tuple.Create(@emp.CaseMemberKey.ToString(), @emp)).ToArray();

            var results = badPairs.Concat(goodPairs).OrderBy(_ => _.Item2 != null).ThenBy(_ => _.Item1).Select(@row => @row.ReshapeToAnonymous()).ToArray();

            return results;
        }


        public object[] AnonymousScopes(ModelAlias model)
        {
            if (model.IsScopeModeOn == false) return null;

            var repo2 = ThinSchemeFactoryMethods.Singleton.CreateCompassSchemeReader();

            var results = model.Step2ScopeRows.Select(@row => @row.ReshapeToAnonymous(SimpleDisplayablesDal.Singleton, repo2));

            return results.ToArray();
        }


        public IEnumerable<IOutcomeItem> ChangeMemberRows(ModelAlias model, string rawString, string freezeTypeRefCd)
        {
            RemarksVessel.YieldAndPurgeAll();

            if (model == null)
            {
                RemarksVessel.RemarkNoItemSpecified = true;
            }
            else
            {
                model.SetFeezeType(freezeTypeRefCd);
                if (model.IsMemberModeOn == false)
                {
                    RemarksVessel.RemarkUnavailableCommand = true;
                    return RemarksVessel.YieldAndPurgeAll();
                };

                string errorMessage = null;

                string[] untestedCaseMemberKeys = RawCsvHelp.ExtractValuesFromLargeString(rawString, @v => v.IntoIntN().HasValue, Environment.NewLine, _ => ",", out errorMessage)?.Select( _ => _.Trim()).ToArray() ;


                if (string.IsNullOrEmpty(errorMessage))
                {
                    Func<int[], IEnumerable<int>> goodKeysSelectionTechnique = @numericKeys => _employeeController.GetMany(@numericKeys).Select(_ => _.CaseMemberKey) ;

                    model.Step2MemberRows = KeepIgnoreCreateMemberRows(model.Step2MemberRows, untestedCaseMemberKeys, goodKeysSelectionTechnique);
                    Putback(model);
                }
                else
                {
                    RemarksVessel.IncludeCustomRemarks(errorMessage);
                }

            }

            return RemarksVessel.YieldAndPurgeAll();
        }


        private static FreezeEventMemberVm[] KeepIgnoreCreateMemberRows(FreezeEventMemberVm[] source, string[] suppliedCaseMemberKeys, Func<int[], IEnumerable<int>> goodKeysSelectionTechnique)
        {
            var dbRows = source.Where(_ => _.IsFromDb).ToList();

            //Important: must set IsInFile each time we enter this method!
            dbRows.ForEach(_ => _.IsInFile = suppliedCaseMemberKeys?.Contains(_.CaseMbrKey) ?? false);

            var extraCaseMemberKeys = suppliedCaseMemberKeys.SafeLinq().Except(dbRows.Select(_ => _.CaseMbrKey)).ToArray();

            var newRows = extraCaseMemberKeys.Select(_ => new FreezeEventMemberVm() { CaseMbrKey = _, IsInFile = true }).ToList();

            var results = dbRows.Where(_ => _.IsInFile == true).Concat(newRows).ToArray();

            string[] badCaseMemberKeys = ValidationHelp.DetermineBadKeysViaVerification(suppliedCaseMemberKeys, @goodKeysSelectionTechnique );

            results.ForEach(@row => @row.IsBadCaseMemberKey = badCaseMemberKeys.Contains(@row.CaseMbrKey));

            return results;
        }


        public IEnumerable<IOutcomeItem> AddScopeRow(ModelAlias model, string freezeTypeRefCd)
        {
            RemarksVessel.YieldAndPurgeAll();

            if (model == null)
            {
                RemarksVessel.RemarkNoItemSpecified = true;
            }
            else
            {
                model.SetFeezeType(freezeTypeRefCd);
                if (model.IsScopeModeOn == false)
                {
                    RemarksVessel.RemarkUnavailableCommand = true;
                    return RemarksVessel.YieldAndPurgeAll();
                };

                var scopeCriteria = model.Step2SearchCriteria;

                if (scopeCriteria.Equals(null))
                {
                    RemarksVessel.RemarkInvalidIdentityDetected = true;
                }
                else if (model.Step2ScopeRows.Any(_ => _.Equals(scopeCriteria)))
                {
                    RemarksVessel.DuplicatesDetected = true;
                }
                else if (scopeCriteria.Equals(FreezeScopeFactoryMethods.Singleton.CreateValidatedScopeCriteria(scopeCriteria)) == false)
                {
                    RemarksVessel.RemarkInvalidIdentityDetected = true;
                }
                else //success
                {
                    var toAdd = new FreezeEventScopeVm(model.Step2SearchCriteria);
                    toAdd.TempId = --model.Step2SearchCriteria.TempId;
                    model.Step2ScopeRows = model.Step2ScopeRows.Concat(new[] { toAdd }).ToArray();
                }

                Putback(model);
            }


            return RemarksVessel.YieldAndPurgeAll();
        }

        public FreezeEventScopeVm ExtractUnverifiedFreezeScopeSearchCriteriaFromView(Func<Expression<Func<FreezeEventScopeVm, object>>, string> pullTextFromViewTechnique, int? failureValue = null)
        {
            FreezeEventScopeVm result = FreezeScopeFactoryMethods.Singleton.ManualPullExtraScopeCriteriaFromView(pullTextFromViewTechnique, failureValue);
            return result;
        }

    }
}
