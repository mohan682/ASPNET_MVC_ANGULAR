﻿using Dcorum.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace DCorum.Feature.Freeze.Models
{
    /*  FREEZE_EVENT_MEMBER_ID INT No   
        FREEZE_EVENT_ID INT No   
        CASE_MBR_KEY NUMBER(15,0) No 
     */


    public class FreezeEventMemberDm
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        protected FreezeEventMemberDm()
        {
        }

        [Key]
        public int Id { get; protected set; }

        public int FreezeEventId { get; protected set; }

        public string CaseMbrKey { get; set; }


        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected class Builder
        {
            protected Builder(FreezeEventMemberDm affected)
            {
                if (affected == null || affected.Id > 0) throw new ArgumentException("affected item must exist and be unused!", nameof(affected));
                model = affected;
            }

            private FreezeEventMemberDm model;

            public void Build(IDataRecord reader, string[] columnNames)
            {
                if (reader == null) return;
                if (model.Id > 0) throw new InvalidOperationException();

                /*  FREEZE_EVENT_MEMBER_ID INT No   
                    FREEZE_EVENT_ID INT No   
                    CASE_MBR_KEY NUMBER(15,0) No 
                */

                model.Id = reader.FetchAsValue<int>("FREEZE_EVENT_MEMBER_ID");
                model.FreezeEventId = reader.FetchAsValue<int>("FREEZE_EVENT_MEMBER_ID");
                model.CaseMbrKey = reader.FetchAsValue<int>("CASE_MBR_KEY").ToString();
            }

        }

    }

}
