﻿using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using DCorum.Feature.Freeze.Contractual;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;

namespace DCorum.Feature.Freeze.Models
{

    public class FreezeEventDm
    {
        [Key]
        [UIHint("txt*")]
        [Display(Name = "Freeze Event Id:", Order = 100)]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Invisible)]
        public int Id { get; protected internal set; }

        [UIHint("txt*")]
        [Required]
        [Display(Name = "Freeze Reference:", Order = 200)]
        //[DataType(DataType.Url)]
        public string Reference { get; set; }

        [UIHint("txt*")]
        [Required]
        [Display(Name = "Description:", Order = 300)]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        [IgnoreDataMember]
        public DateTime? Start { get; protected set; }

        [IgnoreDataMember]
        public DateTime? End { get; protected set; }

        [Required]
        [UIHint("ddl*")]
        [RefCodeConstraint(FreezeDomainNames.FreezeType, OrderByRefCode = true)]
        [Display(Name = "Freeze Type:", Order = 1000000)]
        [RefreshProperties(RefreshProperties.None)]
        public string FreezeType { get; set; }


        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected class Builder
        {
            protected Builder(FreezeEventDm affected)
            {
                if (affected == null || affected.Id > 0) throw new ArgumentException("affected item must exist and be unused!", nameof(affected));
                model = affected;
            }

            private FreezeEventDm model;

            public void Build(IDataRecord reader, string[] columnNames)
            {
                if (reader == null) return;
                if (model.Id > 0) throw new InvalidOperationException();

                /*  FREEZE_EVENT_ID INT No   
                    REFERENCE VARCHAR(50) No   
                    DESCRIPTION VARCHAR(500) No   
                    START_DATETIME DATETIME No   
                    END_DATETIME DATETIME Yes   
                    FREEZE_TYPE VARCHAR2(2) 
                    */

                model.Id = reader.FetchAsValue<int>("FREEZE_EVENT_ID");
                model.Reference = reader.FetchAsString("REFERENCE");
                model.Description = reader.FetchAsString("DESCRIPTION");
                model.Start = reader.FetchAsValue<DateTime>("START_DATETIME");
                model.End = reader.FetchAsValue<DateTime>("END_DATETIME");
                model.FreezeType = reader.FetchAsString("FREEZE_TYPE"); //reader.FetchTextualRefCode("FREEZE_TYPE");         
            }

        }

    }




}
