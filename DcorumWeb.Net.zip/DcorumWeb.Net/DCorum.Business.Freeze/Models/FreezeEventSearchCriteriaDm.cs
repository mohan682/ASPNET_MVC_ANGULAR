﻿using Dcorum.BusinessCore.Contractual;
using DCorum.Feature.Freeze.Contractual;
using System;

namespace DCorum.Feature.Freeze.Models
{
    public class FreezeEventSearchCriteriaDm
    {
        public string Description { get; set; }

        public string Reference { get; set; }


        public string FreezeTypeCode { get; set; }


        public DateTime? StartDateFrom { get; set; }

        public DateTime? StartDateTo { get; set; }

        public DateTime? ExpiryDateFrom { get; set; }

        public DateTime? ExpiryDateTo { get; set; }



        public ISchemeThinReadOnly ThinScheme { get; set; }

        public FreezeStatus? FreezeStatus { get; set; }
    }
}
