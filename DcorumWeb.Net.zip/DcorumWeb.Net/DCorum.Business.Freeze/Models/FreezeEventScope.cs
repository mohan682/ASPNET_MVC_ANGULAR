﻿using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using DCorum.ViewModelling.Annotations;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace DCorum.Feature.Freeze.Models
{
    /*FREEZE_EVENT_SCOPE_ID INT No   
FREEZE_EVENT_ID INT No   
OVRD_CO_CD VARCHAR2(1) Yes   
PROD_TYP_CD NUMBER(3) Yes   
PLAN_TYP_CD NUMBER(3) Yes   
CASE_KEY NUMBER(15) Yes   
MBGP_KEY NUMBER(8,0) Yes   
MBR_STAT_CD VARCHAR2(2) Yes   
EMPR_KEY NUMBER(8,0) Yes   
BGRP_KEY NUMBER(8,0) 
*/

    public class FreezeEventScopeDm
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        protected FreezeEventScopeDm()
        {
        }

        [Key]
        public int Id { get; protected set; }

        public int FreezeEventId { get; protected set; }

        [UIHint("ddl*")]
        [Display(GroupName = "Freeze Level", Name = "Provider:")]
        [RefCodeConstraint(DomainNames.UEXT_Provider_Code)]
        public string OvrdCoCd { get; set; }

        [UIHint("ddl*")]
        [Display(GroupName = "Freeze Level", Name = "Product:")]
        [RefCodeConstraint(DomainNames.UEXT_Product_Code)]
        public int? ProdTypeCd { get; set; }

        [UIHint("ddl*")]
        [Display(GroupName = "Freeze Level", Name = "Plan Type:")]
        [RefCodeConstraint(DomainNames.UEXT_PlanType)]
        public string PlanTypeCd { get; set; }

        [UIHint("txt*")]
        [Display(GroupName = "Freeze Level", Name = "Scheme:")]
        //[AutoExtender("GetSchemeList")] 
        [AutoExtenderWithContext("GetFreezableSchemes")]
        public int? CaseKey { get; set; }

        [UIHint("txt*")]
        [Display(GroupName = "Refinement", Name = "Member Group:")]

        //[AutoExtender("GetMemberGroupList")]
        [AutoExtenderWithContext("GetMemberGroupsUsingSchemeContext")]
        public int? MbgpKey { get; set; }

        [UIHint("txt*")]
        [Display(GroupName = "Refinement", Name = "Employer:")]
        [AutoExtenderWithContext("GetEmployersUsingSchemeContext")]
        public int? EmprKey { get; set; }

        [UIHint("txt*")]
        [Display(GroupName = "Refinement", Name = "Billing Group:")]
        [AutoExtenderWithContext("GetBillingGroupsUsingSchemeContext")]
        public int? BgrpKey { get; set; }

        [UIHint("ddl*")]
        [Display(GroupName = "Refinement", Name = "Member Status:")]
        [RefCodeConstraint(DomainNames.MemberStatuses)]
        public string MbrStatCd { get; set; }

        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected class Builder
        {
            protected Builder(FreezeEventScopeDm affected)
            {
                if (affected == null || affected.Id > 0) throw new ArgumentException("affected item must exist and be unused!", nameof(affected));
                model = affected;
            }

            private FreezeEventScopeDm model;
        
            /// <summary>
            /// [PROTECTED]
            /// </summary>
            public void Build(IDataRecord reader, string[] columnNames)
            {
                if (reader == null) return;
                
                /*  FREEZE_EVENT_SCOPE_ID INT No   
                    FREEZE_EVENT_ID INT No   
                    OVRD_CO_CD VARCHAR2(1) Yes   
                    PROD_TYP_CD NUMBER(3) Yes   
                    PLAN_TYP_CD NUMBER(3) Yes   
                    CASE_KEY NUMBER(15) Yes   
                    MBGP_KEY NUMBER(8,0) Yes   
                    MBR_STAT_CD VARCHAR2(2) Yes   
                    EMPR_KEY NUMBER(8,0) Yes   
                    BGRP_KEY NUMBER(8,0) 
                    */

                model.Id = reader.FetchAsValue<int>("FREEZE_EVENT_SCOPE_ID");
                model.FreezeEventId = reader.FetchAsValue<int>("FREEZE_EVENT_ID");

                model.BgrpKey = reader.FetchAsNullable<int>("BGRP_KEY");
                model.CaseKey = reader.FetchAsNullable<int>("CASE_KEY");
                model.EmprKey = reader.FetchAsNullable<int>("EMPR_KEY");
                model.MbgpKey = reader.FetchAsNullable<int>("MBGP_KEY");
                model.OvrdCoCd = reader.FetchAsString("OVRD_CO_CD");
                model.PlanTypeCd = reader.FetchAsString("PLAN_TYP_CD");
                model.ProdTypeCd = reader.FetchAsNullable<int>("PROD_TYP_CD");
                model.MbrStatCd = reader.FetchAsString("MBR_STAT_CD");
            }
        }

    }

}
