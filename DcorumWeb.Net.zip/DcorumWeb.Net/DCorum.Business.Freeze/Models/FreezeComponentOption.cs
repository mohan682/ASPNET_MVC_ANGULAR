﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace DCorum.Feature.Freeze.Models
{
    public class FreezeComponentOptionDataRow
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        protected FreezeComponentOptionDataRow()
        {
        }

        [Key]
        //[UIHint("")]
        public int Id { get; protected set; }

        public int FreezeEventId { get; protected set; }

        [UIHint("hidden1")]
        [RefCodeConstraint("FREEZE_COMPONENTS")]
        public RefCode ComponentType { get; set; }

        /// <summary>
        /// Variable domainname
        /// </summary>
        [UIHint("ddlPermission")]
        public RefCode SelectedValue { get; set; }

        [UIHint("txtMessage")]
        public string Message { get; set; }


        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected class Builder
        {
            protected Builder(FreezeComponentOptionDataRow affected)
            {
                if (affected == null || affected.Id > 0) throw new ArgumentException("affected item must exist and be unused!", nameof(affected));
                model = affected;
            }

            private FreezeComponentOptionDataRow model;

            public void Build(IDataRecord reader, string[] columnNames)
            {
                if (reader == null) return;
                if (model.Id > 0) throw new InvalidOperationException();

                /*  COMPONENT_TYPE	VARCHAR2(30 BYTE)	No
                    DESCRIPTION	VARCHAR2(2 BYTE)	No
                    FREEZE_COMPONENT_OPTIONS_ID	NUMBER	No
                    FREEZE_EVENT_ID	NUMBER	No
                    MESSAGE	VARCHAR2(2000 BYTE)	Yes
                    SELECTED_VALUE	VARCHAR2(2 BYTE)	No
                    */

                model.Id = reader.FetchAsValue<int>("FREEZE_COMPONENT_OPTIONS_ID");
                model.FreezeEventId = reader.FetchAsValue<int>("FREEZE_EVENT_ID");

                model.ComponentType = reader.FetchTextualRefCode("COMPONENT_REF_CD");

                model.SelectedValue = reader.FetchTextualRefCode("SELECTED_REF_CD_VALUE");

                model.Message = reader.FetchAsString("MESSAGE");
            }
        }
    }

}
