﻿using Dcorum.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace DCorum.Feature.Freeze.Models
{
    /// <summary>
    /// Used for list page
    /// </summary>
    public class FreezeEvent
    {
        /*FREEZE_EVENT_ID INT No   
REFERENCE VARCHAR(50) No   
DESCRIPTION VARCHAR(500) No   
START_DATETIME DATETIME No   
END_DATETIME DATETIME No   
FREEZE_TYPE VARCHAR2(2) 
*/
        public FreezeEvent(IDataReader reader)
        {
            Build(this, reader);
        }

        [Key]
        public int Id { get; private set; }

        public string Reference { get; set; }

        public string Description { get; set; }

        public DateTime Start { get; set; }

        public DateTime End { get; set; }

        public string FreezeType { get; set; }

        private static void Build(FreezeEvent model, IDataReader reader)
        {
            if (reader == null) return;

            /*  FREEZE_EVENT_ID INT No   
                REFERENCE VARCHAR(50) No   
                DESCRIPTION VARCHAR(500) No   
                START_DATETIME DATETIME No   
                END_DATETIME DATETIME Yes   
                FREEZE_TYPE VARCHAR2(2) 
                */

            model.Id = reader.FetchAsValue<int>("FREEZE_EVENT_ID");
            model.Reference = reader.FetchAsString("REFERENCE");
            model.Description = reader.FetchAsString("DESCRIPTION");
            model.Start = reader.FetchAsValue<DateTime>("START_DATETIME");
            model.End = reader.FetchAsValue<DateTime>("END_DATETIME");
            model.FreezeType = reader.FetchAsString("FREEZE_TYPE");
        }
    }
}
