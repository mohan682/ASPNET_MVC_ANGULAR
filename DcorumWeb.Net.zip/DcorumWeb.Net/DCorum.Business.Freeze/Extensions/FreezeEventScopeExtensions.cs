﻿using Dcorum.Utilities.Extensions;
using DCorum.Feature.Freeze.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace DCorum.Feature.Freeze.Extensions
{
    public static class FreezeEventScopeExtensions
    {
        /// <summary>
        /// Assumes an order of priority of underlying candidates.
        /// </summary>
        public static PropertyInfo GetLevelPI(this FreezeEventScopeDm model)
        {
            PropertyInfo[] levelStuff = new[] { model.PI(_ => _.OvrdCoCd), model.PI(_ => _.ProdTypeCd), model.PI(_ => _.PlanTypeCd), model.PI(_ => _.CaseKey) };
            PropertyInfo levelPI = levelStuff.LastOrDefault(_ => _.GetValue(model, null) != null);

            return levelPI;
        }

        /// <summary>
        /// Assumes mutual exclusivity or underlying candidates.
        /// </summary>
        public static PropertyInfo GetRefinementPI(this FreezeEventScopeDm model)
        {
            //assumes mutual exclusivity!
            PropertyInfo[] refinementStuff = new[] { model.PI(_ => _.MbgpKey), model.PI(_ => _.EmprKey), model.PI(_ => _.BgrpKey),  model.PI(_ => _.MbrStatCd) };

            PropertyInfo refinementPI = refinementStuff.FirstOrDefault(_ => _.GetValue(model, null) != null);

            return refinementPI;
        }

        public static bool IsEmpty(this FreezeEventScopeDm model)
        {
            bool result = YieldEqualityFlags(model, default(FreezeEventScopeDm)).All(_ => _ == true);
            return result;
        }

        /// <summary>
        /// note: Ignores Id and FreezeEventId
        /// </summary>
        public static IEnumerable<bool> YieldEqualityFlags(this FreezeEventScopeDm model, FreezeEventScopeDm model2, StringComparison stringComparison = StringComparison.InvariantCultureIgnoreCase)
        {
            if (model == null) yield break;
            bool flag = string.Equals(model.OvrdCoCd, model2?.OvrdCoCd, stringComparison);
            yield return flag;
            yield return model.ProdTypeCd == model2?.ProdTypeCd;
            yield return string.Equals(model.PlanTypeCd, model2?.PlanTypeCd, stringComparison);
            yield return model.CaseKey == model2?.CaseKey;
            yield return model.MbgpKey == model2?.MbgpKey;
            yield return model.BgrpKey == model2?.BgrpKey;
            yield return model.EmprKey == model2?.EmprKey;
            yield return string.Equals(model.MbrStatCd, model2?.MbrStatCd, stringComparison);
        }
    }
}
