﻿using Dcorum.Utilities.Practices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Feature.Freeze.Bases
{
    public abstract class FreezeControllerAdaptorBase<Model>
    {
        public string TextualAmbientValue
        {
            get
            {
                return default(int).ToString() ;
            }
        }

        public string GetTextualIdentityOf(Model ofInterest)
        {
            return MetaDataHelper.GetTextualIdentity(ofInterest);
        }
    }
}
