﻿using DCorum.DataAccessFoundation.Contractual;
using DCorum.Feature.Freeze.Extensions;
using DCorum.Feature.Freeze.Models;
using DcorumWeb.Utilities;
using System;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;

namespace DCorum.Feature.Freeze.ViewModels
{
    public class FreezeEventScopeVm : FreezeEventScopeDm, IHaveATypicalDataParent, IEquatable<FreezeEventScopeVm>
    {
        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected new class Builder : FreezeEventScopeDm.Builder { internal protected Builder(FreezeEventScopeVm affected) : base(affected) { } }


        internal FreezeEventScopeVm() : this(null, null) { }


        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal FreezeEventScopeVm(IDataReader reader, string[] columnNames = null)
        {
            new Builder(this).Build(reader, columnNames);

            IsFromDb = reader != null;
            TempId = Id;

            TidyUp();
        }

        /// <summary>
        /// [COPY_CONSTRUCTOR]
        /// </summary>
        internal FreezeEventScopeVm(FreezeEventScopeDm toCopy)
        {
            var model = this;

            model.Id = toCopy.Id;
            model.FreezeEventId = toCopy.FreezeEventId;

            model.BgrpKey = toCopy.BgrpKey;
            model.CaseKey = toCopy.CaseKey;
            model.EmprKey = toCopy.EmprKey;
            model.MbgpKey = toCopy.MbgpKey;
            model.OvrdCoCd = toCopy.OvrdCoCd;
            model.PlanTypeCd = toCopy.PlanTypeCd;
            model.ProdTypeCd = toCopy.ProdTypeCd;
            model.MbrStatCd = toCopy.MbrStatCd;
        }

        [IgnoreDataMember]
        public int TempId { get; internal protected set; } //same as Id if from DB otherwise set to a negative value to keep uniqueness.

        [IgnoreDataMember]
        public bool IsFromDb { get; }

        [IgnoreDataMember]
        public bool MarkedForDeletion { get; set; }


        int IHaveADataParent<int, int>.Id
        {
            get
            {
                return this.Id;
            }

            set
            {
                this.Id = value;
            }
        }

        int IHaveADataParent<int, int>.ParentId
        {
            get
            {
                return this.FreezeEventId;
            }

            set
            {
                this.FreezeEventId = value;
            }
        }


        bool IHaveADataParent.DeleteNow()
        {
            return Id > 0 && FreezeEventId > 0 && (MarkedForDeletion && IsFromDb);
        }

        bool IHaveADataParent.UpdateNow()
        {
            //note: only saving the alternative key so updated row would look the same anyway!
            return false; //Id > 0 && (MarkedForDeletion==false && IsFromDb);
        }

        bool IHaveADataParent.InsertNow()
        {
            return FreezeEventId <= 0 && (MarkedForDeletion == false && IsFromDb == false);
        }

        /// <summary>
        /// Replace unwanted string.Empty with will
        /// </summary>
        public void TidyUp()
        {
            OvrdCoCd = OvrdCoCd.NullIfWhiteSpace();
            PlanTypeCd = PlanTypeCd.NullIfWhiteSpace();
            MbrStatCd = MbrStatCd.NullIfWhiteSpace();
        }

        /// <summary>
        /// [EXPLICIT_IMPLEMENTATION]
        /// </summary>
        bool IEquatable<FreezeEventScopeVm>.Equals(FreezeEventScopeVm other)
        {
            var flags = this.YieldEqualityFlags(other).ToArray();
            bool result = flags.All(_ => _ == true);
            return result;
        }


        public override bool Equals(object obj)
        {
            return ((IEquatable<FreezeEventScopeVm>)this).Equals(obj as FreezeEventScopeVm);
        }

    }
}
