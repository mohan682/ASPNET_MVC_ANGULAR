﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.Utilities.Extensions;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.Feature.Freeze.Models;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics.Contracts;

namespace DCorum.Feature.Freeze.ViewModels
{
    public class FreezeComponentOptionVm : FreezeComponentOptionDataRow, FreezeComponentOptionVm.IAlternativeKey1, IHaveATypicalDataParent
    {

        internal interface IAlternativeKey1
        {
            int FreezeEventId { get; }

            RefCode ComponentType { get; }
        }


        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected new class Builder : FreezeComponentOptionDataRow.Builder { internal protected Builder(FreezeComponentOptionVm affected) : base(affected) { } }


        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal FreezeComponentOptionVm(IDataReader reader, string[] columnNames = null)
        {
            new Builder(this).Build(reader, columnNames);

            Ticked = Id > 0;
        }


        /// <summary>
        /// [CONSTRUCTOR] for alternative key only
        /// </summary>
        private FreezeComponentOptionVm(int parentId, string componentTypeRefCd)
        {
            FreezeEventId = parentId;
            ComponentType = new RefCode(componentTypeRefCd);
        }

        /// <summary>
        /// [PROJECTION METHOD|PARSE]
        /// </summary>
        [Pure]
        internal static IAlternativeKey1 ParseId(string compositeCandidate)
        {
            string[] parts1 = compositeCandidate.Split('|');

            if (parts1.Length != 2) return null;

            var built1 = new FreezeComponentOptionVm(parts1[0].IntoIntN().Value, parts1[1]);
            return built1;
        }

        [UIHint("chk1")]
        public bool Ticked { get; set; }


        int IHaveADataParent<int, int>.Id
        {
            get
            {
                return this.Id;
            }

            set
            {
                this.Id = value;
            }
        }

        int IHaveADataParent<int, int>.ParentId
        {
            get
            {
                return this.FreezeEventId;
            }

            set
            {
                this.FreezeEventId = value;
            }
        }

        bool IHaveADataParent.DeleteNow()
        {
            return Id > 0 && FreezeEventId > 0 && Ticked == false;
        }

        bool IHaveADataParent.UpdateNow()
        {
            return Id > 0 && FreezeEventId > 0 && Ticked;
        }

        bool IHaveADataParent.InsertNow()
        {
            return FreezeEventId <= 0 && Ticked;
        }
    }
}
