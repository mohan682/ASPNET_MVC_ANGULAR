﻿using DCorum.BusinessFoundation.Bases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DCorum.Feature.Freeze.ViewModels
{
    [Description("Step 1: Set up the Freeze:")]
    public class FreezeEventSummaryVm : IWithId<int>
    {
        public FreezeEventSummaryVm(int id)
        {
            _Id = id;
        }

        [UIHint("txt*")]
        [Required]
        public string Freeze_Ref { get; set; }

        [UIHint("ddl*")]
        public string Freeze_Type { get; set; }

        [UIHint("txt*")]
        [DataType(DataType.MultilineText)]
        [Required]
        public string Freeze_Description { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime Start_Date { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime End_Date { get; set; }

        [Key]
        public int _Id
        {
            get; private set;
        }
    }
}
