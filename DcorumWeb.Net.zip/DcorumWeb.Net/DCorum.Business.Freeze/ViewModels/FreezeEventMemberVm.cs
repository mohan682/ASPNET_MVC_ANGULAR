﻿using DCorum.DataAccessFoundation.Contractual;
using System.Data;
using System.Runtime.Serialization;
using DCorum.Feature.Freeze.Models;

namespace DCorum.Feature.Freeze.ViewModels
{
    public class FreezeEventMemberVm : FreezeEventMemberDm, IHaveATypicalDataParent
    {
        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected new class Builder : FreezeEventMemberDm.Builder { internal protected Builder(FreezeEventMemberVm affected) : base(affected) { } }


        internal FreezeEventMemberVm() : this(null, null) { }

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal FreezeEventMemberVm(IDataReader reader, string[] columnNames = null)
        {
            new Builder(this).Build(reader, columnNames);

            IsFromDb = reader != null;
        }


        [IgnoreDataMember]
        public bool IsFromDb { get; }

        [IgnoreDataMember]
        public bool? IsInFile { get; set; }

        [IgnoreDataMember]
        public bool? IsBadCaseMemberKey { get; set; }


        int IHaveADataParent<int, int>.Id
        {
            get
            {
                return this.Id;
            }

            set
            {
                this.Id = value;
            }
        }

        int IHaveADataParent<int, int>.ParentId
        {
            get
            {
                return this.FreezeEventId;
            }

            set
            {
                this.FreezeEventId = value;
            }
        }

        bool IHaveADataParent.DeleteNow()
        {
            return Id > 0 && FreezeEventId > 0 && (IsInFile == false && IsFromDb);
        }

        bool IHaveADataParent.UpdateNow()
        {
            //note: only saving the alternative key so updated row would look the same anyway!
            return false;//Id > 0 && FreezeEventId > 0 && (IsInFile==true && IsFromDb);
        }

        bool IHaveADataParent.InsertNow()
        {
            return FreezeEventId <= 0 && (IsInFile == true && IsFromDb == false);
        }
    }
}
