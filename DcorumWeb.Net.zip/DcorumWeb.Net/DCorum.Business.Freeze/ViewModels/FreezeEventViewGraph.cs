﻿using Dcorum.BusinessLayer.BusinesObjects;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.Feature.Freeze.Contractual;
using DCorum.Feature.Freeze.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace DCorum.Feature.Freeze.ViewModels
{
    public class FreezeEventViewGraph : IAmATypicalDataParent
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public FreezeEventViewGraph()
        {
        }

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public FreezeEventViewGraph(FreezeEventVm step1, FreezeEventVm step1IntialValues, FreezeEventScopeVm[] scopes, FreezeEventMemberVm[] members, FreezeComponentOptionVm[] options)
        {
       
            Step1 = step1 ?? new FreezeEventVm(null);

            Step1CurrentDbValues = step1IntialValues ?? new FreezeEventVm(null);

            Step2ScopeRows = scopes ?? Enumerable.Empty<FreezeEventScopeVm>().ToArray();
            Step2MemberRows = members ?? Enumerable.Empty<FreezeEventMemberVm>().ToArray();
            Step3 = options ?? Enumerable.Empty<FreezeComponentOptionVm>().ToArray();

            if (Step2SearchCriteria == null) Step2SearchCriteria = new FreezeEventScopeVm();
        }

        public FreezeEventVm Step1 { get; private set; }
        internal FreezeEventVm Step1CurrentDbValues { get; private set; }


        public FreezeEventScopeVm Step2SearchCriteria { get; private set; }

        public FreezeEventScopeVm[] Step2ScopeRows { get; internal set; }

        public FreezeEventMemberVm[] Step2MemberRows { get; internal set; }

        public FreezeComponentOptionVm[] Step3 { get; private set; }

        [Key]
        public int? StrongId
        {
            get
            {
                return !(Step1?.Id > 0) ? (int?)null : Step1.Id;
            }
        }


        public bool IsSystemModeOn
        {
            get
            {
                return IsFreezeTypeEqualTo(FreezeTypeCodes.System );
            }
        }

        public bool IsScopeModeOn
        {
            get
            {
                return IsFreezeTypeEqualTo(FreezeTypeCodes.Scope );
            }
        }

        public bool IsMemberModeOn
        {
            get
            {
                return IsFreezeTypeEqualTo(FreezeTypeCodes.Member );
            }
        }

        public bool IsExpired
        {
            get
            {
                return (StrongId > 0) && (Step1CurrentDbValues.End <  DateTime.Now);
            }
        }


        public bool IsActive
        {
            get
            {
                return (StrongId > 0) && (Step1CurrentDbValues.End >= DateTime.Now && Step1CurrentDbValues.Start <= DateTime.Now);
            }
        }


        public bool IsFuture
        {
            get
            {
                return /*(Step1.Start == null || Step1.End == null) ||*/ (!IsExpired && !IsActive);
            }
        }


        public IEnumerable<string> YieldSectionTitles()
        {
            yield return "<strong>Step 1:</strong> Set up the Freeze:";

            yield return "<strong>Step 2:</strong> Scope Freeze";
            yield return "<strong>Step 2:</strong> Member Freeze";
            yield return "<strong>Step 2:</strong> System Freeze";

            yield return "<strong>Step 3:</strong> Set the System Permissions & Messages:";
        }


        public void SetFeezeType(string freezeTypeRefCd)
        {
            if (string.IsNullOrEmpty(freezeTypeRefCd) == false)
            {
               Step1.FreezeType = RefCodeCache.RetrieveByRefCodeValue(FreezeDomainNames.FreezeType, freezeTypeRefCd)?.RefCd;
            }
        }

        private bool IsFreezeTypeEqualTo(string toEquate)
        {
            return FreezeTypeCodeExtensions.IsFreezeTypeEqualTo(toEquate, Step1.FreezeType);//?.RefCd);
        }
    }
}
