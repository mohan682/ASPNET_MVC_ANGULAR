﻿using Dcorum.Utilities.Extensions;
using DCorum.Feature.Freeze.Models;
using DCorum.ViewModelling.Contractual;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace DCorum.Feature.Freeze.ViewModels
{
    /// <summary>
    /// Used for child page
    /// </summary>
    public class FreezeEventVm : FreezeEventDm
    {
        /// <summary>
        /// [NESTED_CLASS]
        /// </summary>
        protected new class Builder : FreezeEventDm.Builder { internal protected Builder(FreezeEventVm affected) : base(affected) { } }


        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal FreezeEventVm(IDataReader reader, string[] columnNames = null)
        {
            //if (columnNames == null) throw new ArgumentNullException("columnNames"); //must hold values when reader is specified.
            new Builder(this).Build(reader, columnNames);
        }


        [UIHint("txt*")]
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Start Date:", Prompt = @"dd/mm/yyyy")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? StartDate
        {
            get { return Start?.Date; }
            set { Start = value?.Add(StartTime ?? default(TimeSpan)); }
        }

        [UIHint("txt*")]
        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "Start Time:", Prompt = @"00:00:00")]
        [RegularExpression(RegExConstants.Time24FormatWithOptionalLeadingZero)]
        public TimeSpan? StartTime
        {
            get { return Start?.TimeOfDayAsTimespan(); }
            set { Start = StartDate?.Add(value.Value); }
        }

        [UIHint("txt*")]
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "End Date:", Prompt = @"dd/mm/yyyy")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? EndDate
        {
            get { return End?.Date; }
            set { End = value?.Add(EndTime ?? default(TimeSpan)); }
        }

        [UIHint("txt*")]
        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "End Time:", Prompt = @"00:00:00")]
        [RegularExpression(RegExConstants.Time24FormatWithOptionalLeadingZero)]
        public TimeSpan? EndTime
        {
            get { return End?.TimeOfDayAsTimespan(); }
            set { End = EndDate?.Add(value.Value); }
        }
    }
}
