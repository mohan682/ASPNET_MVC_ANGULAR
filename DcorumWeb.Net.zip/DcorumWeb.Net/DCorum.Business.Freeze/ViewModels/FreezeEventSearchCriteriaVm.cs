﻿using Dcorum.BusinessLayer.Contractual;
using DCorum.Feature.Freeze.Contractual;
using DCorum.ViewModelling.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DCorum.Feature.Freeze.ViewModels
{
    /// <summary>
    /// [ANAEMIC]
    /// </summary>
    public class FreezeEventSearchCriteriaVm
    {
        [UIHint("txtDesc")]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        [UIHint("txtFreezeRef")]
        public string Reference { get; set; }


        [UIHint("ddlFreezeType")]
        [RefCodeConstraint(FreezeDomainNames.FreezeType)]
        public string FreezeType { get; set; }

        /// <summary>
        /// [ASSOCIATE]
        /// </summary>
        public IEnumerable<KeyValuePair<string, string>> AvailableFreezeTypes { get; set; }

        /// <summary>
        /// [ASSOCIATE]
        /// </summary>
        public IEnumerable<KeyValuePair<int, string>> AvailableFreezeStatuses { get; set; }

        [UIHint("ddlFreezeStatus")]
        public int? FreezeStatus { get; set; }

        [UIHint("txtScheme")]
        [AutoExtenderWithContext("GetFreezableSchemes")]
        public string Scheme { get; set; }

        [UIHint("txtStartDateFrom")]
        [Display(Name = null, Prompt = @"dd/mm/yyyy")]
        [DataType(DataType.Date)]
        public DateTime? StartDateFrom { get; set; }

        [UIHint("txtStartDateFrom")]
        [Display(Name = null, Prompt = @"dd/mm/yyyy")]
        [DataType(DataType.Date)]
        public DateTime? StartDateTo { get; set; }

        [UIHint("txtExpiryDateFrom")]
        [Display(Name = null, Prompt = @"dd/mm/yyyy")]
        [DataType(DataType.Date)]
        public DateTime? ExpiryDateFrom { get; set; }

        [UIHint("txtExpiryDateTo")]
        [Display(Name = null, Prompt = @"dd/mm/yyyy")]
        [DataType(DataType.Date)]
        public DateTime? ExpiryDateTo { get; set; }
    }
}
