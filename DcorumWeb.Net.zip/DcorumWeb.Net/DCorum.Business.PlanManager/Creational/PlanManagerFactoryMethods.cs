﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using DCorum.Business.PlanManager.Bundles;
using DCorum.Business.PlanManager.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.Business.PlanManager.Logic;
using DCorum.Business.PlanManager.Sql;
using DCorum.Business.PlanManager.View.Controller;
using DCorum.Business.PlanManager.View.Model;
using DCorum.BusinessFoundation.Bases;
using DCorum.BusinessFoundation.Contractual;
using System;

using System.Data;

namespace DCorum.Business.PlanManager.Creational
{
    public class PlanManagerFactoryMethods
    {
        public static readonly PlanManagerFactoryMethods Singleton = new PlanManagerFactoryMethods(CoreAbstractFactoryMethods.Singleton);

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        private PlanManagerFactoryMethods(ICoreAbstractFactory coreAbstractFactory)
        {
            CoreAbstractFactory = coreAbstractFactory;
            DataAccessFactory1 = PortalDataAccessFactoryMethods.Singleton ;
        }

        private ICoreAbstractFactory CoreAbstractFactory { get; }
        private PortalDataAccessFactoryMethods DataAccessFactory1 { get; }


        public BLDirectReport CreateDirectReportController(IAuditingArgumentsReadOnly caller)
        {
            Func<IDataReader,RptDirectReport> howToCreate = @reader => new RptDirectReportViaReader(@reader) ;

            var creation1 = new BLDirectReport(caller, new DLDirectReportCrudActor( new DirectReportSqlActor(), @howToCreate));
            return creation1 ;
        }


        public BLSchemeContact CreateSchemeContactController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new BLSchemeContact(caller, new DLSchemeContactCrudActor(new SchemeContactSqlActor()));
            return creation1;
        }

        public TransfersReadOnlyBundle.BLTransferDetail CreateTransactionDetailReadOnlyController(IAuditingArgumentsReadOnly caller)
        {
            var user1 = CoreAbstractFactory.FetchDcorumUser(caller.UserId);
            var myDbProxy = CoreAbstractFactory.CreateDbProxy();

            //caller can be null because we don't currently insert/update for this controller!
            var creation1 = new TransfersReadOnlyBundle.BLTransferDetail( user1,
                new TransfersReadOnlyBundle.DLTransferDetail(new TransfersReadOnlyBundle.TransferDetailSql(), myDbProxy)             
                );
            return creation1;
        }

        public TransferFlagBundle.Controller CreateTransactionDetailFlagController(IAuditingArgumentsReadOnly caller)
        {
            var creation1 = new TransferFlagBundle.Controller(caller, new TransferFlagBundle.CrudActor(new TransferFlagBundle.SqlMaker( TransferFlagBundle.SqlSpec)));
            return creation1;
        }

        public TransferJunctionBundle.Controller CreateTransferJunctionController(IAuditingArgumentsReadOnly caller)
        {
            var subSqlMaker = new TransferFlagBundle.SqlMaker(TransferFlagBundle.SqlSpec);


            var creation1 = new TransferJunctionBundle.Controller
                ( caller
                , new TransferJunctionBundle.CrudActor( 
                    new TransferJunctionBundle.SqlMaker(TransferJunctionBundle.SqlSpec, subSqlMaker)
                  , subSqlMaker)
                , new Lazy<TransferFlagBundle.Controller>(() => CreateTransactionDetailFlagController(caller))
                ) ;
            return creation1;
        }

        public ControllerAdapter<RrwqHeaderVm, int> CreateRrwqHeaderController(IAuditingArgumentsReadOnly caller)
        {
            var controllerImpl= new RrwqHeaderController(new RrwqHeaderDal(), new ContentDal(), new AuditService(), caller.UserId);
            return new ControllerAdapter<RrwqHeaderVm, int>(controllerImpl);
        }

        public ControllerAdapter<RrwqQuestionVm, int> CreateRrwqQuestionController(IAuditingArgumentsReadOnly caller)
        {
            var controllerImpl = new RrwqQuestionController(new RrwqQuestionDal(), new RrwqHeaderDal(), new ContentDal(), new RefCodesDal(), new AuditService(), caller.UserId);
            return new ControllerAdapter<RrwqQuestionVm, int>(controllerImpl);
        }

        public IPtfcCalculationController CreatePtfcCalculationController(IAuditingArgumentsReadOnly caller)
        {
            var user1 = CoreAbstractFactory.FetchDcorumUser(caller.UserId);
            return new PtfcCalculationController(new PtfcCalculationDal(), user1, new AuditService());
        }


        public IIOClientController GetIOClientController(int userId)
        {
            var myRemarksVessel = CoreAbstractFactory.CreateRemarksVessel();
            IAuditor auditor1 = CoreAbstractFactory.CreateAuditor<IOClient>(DomainCodes.DCorumIoclient, userId, myRemarksVessel, 1, model => model.ClientId.ToString());

            var user1 = CoreAbstractFactory.FetchDcorumUser(userId);
            return new IOClientController( DataAccessFactory1.CreateIOClientDataAccess(), user1, auditor1);
        }


        public IIOPortfolioController GetIOPortfolioController(int userId)
        {
            var myRemarksVessel = CoreAbstractFactory.CreateRemarksVessel();
            IAuditor auditor1 = CoreAbstractFactory.CreateAuditor<IOPortfolio>(DomainCodes.DCorumIoclient, userId, myRemarksVessel, 1, model => model.ClientId.ToString());

            var user1 = CoreAbstractFactory.FetchDcorumUser(userId);
            return new IOPortfolioController( DataAccessFactory1.CreateIOPortfolioDataAccess(), user1, auditor1);
        }
    }
}
