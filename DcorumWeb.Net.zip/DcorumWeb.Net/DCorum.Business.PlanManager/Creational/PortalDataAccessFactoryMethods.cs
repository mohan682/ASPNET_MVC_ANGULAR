﻿using DCorum.Business.PlanManager.DataAccess;
using DCorum.Business.PlanManager.Sql;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DCorum.Business.PlanManager.Creational
{
    public class PortalDataAccessFactoryMethods
    {
        public static readonly PortalDataAccessFactoryMethods Singleton = new PortalDataAccessFactoryMethods();

        private PortalDataAccessFactoryMethods()
        {
        }

        public IOClientDal CreateIOClientDataAccess()
        {
            return new IOClientDal(new IOClientSqlActor());
        }

        public IOPortfolioDal CreateIOPortfolioDataAccess()
        {
            return new IOPortfolioDal(new IOPortfolioSqlActor());
        }
    }
}
