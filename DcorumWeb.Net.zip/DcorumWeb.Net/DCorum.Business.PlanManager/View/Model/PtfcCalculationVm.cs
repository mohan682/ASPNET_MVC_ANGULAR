﻿using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using DCorum.BusinessFoundation.Bases;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.View.Model
{
    public class PtfcCalculationVm : IWithId<int>
    {
        public class State
        {
            public State(bool isReadOnlyMaxTaxFreeCashAt5Apr2006,
                bool isReadOnlyTotalValueOfBenefitsAt5Apr2006,
                bool isReadOnlyStandAloneLumpSumApplies,
                bool isReadOnlyValueOfPreviousPartialTransfers,                
                bool isReadOnlyProtectedTaxFreeCashForfeited,
                bool isReadOnlyMoneyPurchaseAnnualAllowanceApplies)
            {
                this.IsReadOnlyMaxTaxFreeCashAt5Apr2006 = isReadOnlyMaxTaxFreeCashAt5Apr2006;
                this.IsReadOnlyTotalValueOfBenefitsAt5Apr2006 = isReadOnlyTotalValueOfBenefitsAt5Apr2006;
                this.IsReadOnlyStandAloneLumpSumApplies = isReadOnlyStandAloneLumpSumApplies;
                this.IsReadOnlyValueOfPreviousPartialTransfers = isReadOnlyValueOfPreviousPartialTransfers;
                this.IsReadOnlyProtectedTaxFreeCashForfeited = isReadOnlyProtectedTaxFreeCashForfeited;                
                this.IsReadOnlyMoneyPurchaseAnnualAllowanceApplies = isReadOnlyMoneyPurchaseAnnualAllowanceApplies;
            }

            public bool IsReadOnlyMaxTaxFreeCashAt5Apr2006 { get; private set; }

            public bool IsReadOnlyTotalValueOfBenefitsAt5Apr2006 { get; private set; }

            public bool IsReadOnlyValueOfPreviousPartialTransfers { get; private set; }

            public bool IsReadOnlyStandAloneLumpSumApplies { get; private set; }

            public bool IsReadOnlyProtectedTaxFreeCashForfeited { get; private set; }

            public bool IsReadOnlyMoneyPurchaseAnnualAllowanceApplies { get; private set; }
        }

        public PtfcCalculationVm(int caseMemberKey)
        {
            _Id = caseMemberKey;
        }

        [Display(Name = "Max Tax free cash as at 05/04/2006 :  £  ")]
        [Editable(false)]
        [UIHint("txtMaxTaxFreeCashAt050406")]
        public decimal? MaxTaxFreeCashAt5Apr2006 { get; set; }

        [Display(Name = "Total value of benefits at 05/04/2006 :  £  ")]
        [Editable(false)]
        [UIHint("txtTotValBenAt05042006")]
        public decimal? TotalValueOfBenefitsAt5Apr2006 { get; set; }

        [Display(Name = "Value of previous partial transfers :  £  ")]
        [Editable(false)]
        [UIHint("txtPrevPartTrfs")]
        public decimal? ValueOfPreviousPartialTransfers { get; set; }

        [Display(Name = "Money Purchase Annual Allowance applies?")]
        [Editable(false)]
        [DataType(DataType.Date)]
        [UIHint("txtMonPurAnnAllApp")]
        public DateTime? MoneyPurchaseAnnualAllowanceApplies { get; set; }

        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [Display(Name = "Stand Alone Lump Sum applies?")]
        [Editable(false)]
        [UIHint("ddlStdAlLumpSumApp")]
        public int? StandAloneLumpSumApplies { get; set; }

        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [Display(Name = "Protected Tax Free Cash forfeited?")]
        [Editable(false)]
        [UIHint("ddlProtTaxFreeCashFor")]
        public int? ProtectedTaxFreeCashForfeited { get; set; }

        // Calculated Values

        [Display(Name = "Current Fund Value :  £  ")]
        [Editable(false)]
        [UIHint("txtCurrFundValue")]
        public decimal? CurrentFundValue { get; set; }

        [Display(Name = "Protected tax free cash :  £  ")]
        [Editable(false)]
        [UIHint("txtProtTaxFreeCash")]
        public decimal? ProtectedTaxFreeCash { get; set; }

        [Display(Name = "%")]
        [Editable(false)]
        [UIHint("txtProtTaxFreeCashPct")]
        public decimal? ProtectedTaxFreeCashPercent { get; set; }

        [Display(Name = "Pension commencement lump sum :  £  ")]
        [Editable(false)]
        [UIHint("txtPenCommLumpSum")]
        public decimal? PensionCommencementLumpSum { get; set; }

        [Display(Name = "Residual Fund Value :  £  ")]
        [Editable(false)]
        [UIHint("txtResFundValue")]
        public decimal? ResidualFundValue { get; set; }

        [Display(Name = "")]
        [Editable(false)]
        [UIHint("lblPtfcErrorMessage")]
        public string PtfcErrorMessage { get; set; }

        #region IWithId<int> Members

        public int _Id
        {
            get; 
        }

        #endregion
    }
}
