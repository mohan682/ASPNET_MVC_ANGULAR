﻿using Dcorum.Utilities.Contractual;
using DCorum.Business.PlanManager.Entities.Validation;
using DCorum.BusinessFoundation.Bases;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DCorum.Business.PlanManager.View.Model
{
    /// <summary>
    /// View representation of <see cref="Entities.RrwqHeader"/> 
    /// </summary>
    public class RrwqHeaderVm : IWithId<int>
    {
        public RrwqHeaderVm()
        {
        }

        public RrwqHeaderVm(int id)
        {
            Header_Id = id;
        }

        [Display(Name = "Header ID")]
        [Editable(false)]
        [UIHint("txt*")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        public int Header_Id { get; private set; }

        [Display(Name = "Section Heading Title Content Target ID")]
        [Editable(true)]
        [UIHint("ddl*")]
        public string Section_Heading_Title_Content_Target_ID { get; set; }

        [IgnoreDataMember]
        [Editable(false)]
        public IEnumerable<string> AvailableTitleTargets { get; set; }

        [Display(Name = "Section Heading Text Content Target ID")]
        [Editable(true)]
        [UIHint("ddl*")]
        public string Section_Heading_Text_Content_Target_ID { get; set; }

        [IgnoreDataMember]
        [Editable(false)]
        public IEnumerable<string> AvailableTextTargets { get; set; }

        [Display(Name = "Header Order")]
        [UIHint("txt*")]
        [Range(RwwqHeaderValidationFactory.DisplayOrderRange.Min, RwwqHeaderValidationFactory.DisplayOrderRange.Max, 
            ErrorMessage = "Header order must be a non-negative number in the range of 1-99.")]
        public int Header_Order { get; set; }

        [Display(Name = "Context Code")]
        [UiDisplayingHint(UiDisplayMode.Editable,UiDisplayMode.Displayable)]
        [UIHint("txt*")]
        public string Context_Code { get; set; }

        #region IWithId<int> Members

        [Key]
        [Editable(false)]
        public int _Id { get { return Header_Id; } }

        #endregion
    }
}
