﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities.Contractual;
using DCorum.Business.PlanManager.Entities.Validation;
using DCorum.BusinessFoundation.Bases;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DCorum.Business.PlanManager.View.Model
{
    /// <summary>
    /// View representation of <see cref="Entities.RrwqQuestion"/> 
    /// </summary>
    public class RrwqQuestionVm : IWithId<int>
    {
        #region class DefaultScreenViewComparer

        /// <summary>
        /// Defines default sorting for the grid view
        /// </summary>
        public class DefaultScreenViewComparer : IComparer<RrwqQuestionVm>
        {
            public int Compare(RrwqQuestionVm x, RrwqQuestionVm y)
            {
                var ret = x._HeaderOrder.CompareTo(y._HeaderOrder);
                if (ret != 0) return ret;

                return x.Display_Order.CompareTo(y.Display_Order);
            }
        }

        #endregion

        public RrwqQuestionVm()
        {
        }

        public RrwqQuestionVm(int id)
        {
            Question_Id = id;
        }

        [Display(Name = "Question ID")]
        [Editable(false)]
        [UIHint("txt*")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        public int Question_Id { get; private set; }

        /// <summary>
        /// This is the Id of the associated header 
        /// </summary>
        /// <remarks>
        /// This is the PK from RRWQ_HEADER table
        /// Counterpart of <see cref="Section_Heading_Content_Target_ID"/> 
        /// </remarks>
        [Display(Name = "Section Heading Content Target ID")]
        [Editable(true)]
        [UIHint("ddl*")]
        public string _Section_Heading_Content_Target_ID { get; set; }

        [IgnoreDataMember]
        [Editable(false)]
        public IDictionary<string, string> AvailableSectionHeadingContentTargets { get; set; }

        /// <summary>
        /// This is the textual representation of the associated Header
        /// </summary>
        /// <remarks>
        /// Counterpart of <see cref="_Section_Heading_Content_Target_ID"/> 
        /// </remarks>
        public string Section_Heading_Content_Target_ID { get; set; }


        [Display(Name = "Question Text Content Target ID")]
        [Editable(true)]
        [UIHint("ddl*")]
        public string Question_Text_Content_Target_ID { get; set; }

        [IgnoreDataMember]
        [Editable(false)]
        public IEnumerable<string> AvailableQuestionTargets { get; set; }

        [Required]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        [Display(Name = "Desired Answer")]
        [UIHint("ddl*")]
        [Editable(true)]
        public RefCode DesiredAnswer { get; set; }

        /// <summary>
        /// For the purpose of displaying <see cref="DesiredAnswer"/> in grid
        /// </summary>
        [IgnoreDataMember]
        [Editable(false)]
        public string Desired_Answer { get; set; }

        [Display(Name = "Linked Statement Content Target ID")]
        [Editable(true)]
        [UIHint("ddl*")]
        public string Linked_Statement_Content_Target_ID { get; set; }

        [IgnoreDataMember]
        [Editable(false)]
        public IEnumerable<string> AvailableLinkedStatementTargets { get; set; }

        [Display(Name = "Linked Declaration Content Target ID")]
        [Editable(true)]
        [UIHint("ddl*")]
        public string Linked_Declaration_Content_Target_ID { get; set; }

        [IgnoreDataMember]
        [Editable(false)]
        public IEnumerable<string> AvailableLinkedDeclarationTargets { get; set; }

        [Display(Name = "Display Order")]
        [UIHint("txt*")]
        [Range(RwwqHeaderValidationFactory.DisplayOrderRange.Min, RwwqHeaderValidationFactory.DisplayOrderRange.Max, 
            ErrorMessage = "Display order must be a non-negative number in the range of 1-99.")]
        public int Display_Order { get; set; }

        /// <summary>
        /// Added just for the purpose of default sorting...
        /// </summary>
        public int _HeaderOrder { get; set; }

        #region IWithId<int> Members

        [Key]
        [Editable(false)]
        public int _Id { get { return Question_Id; } }

        #endregion
    }
}
