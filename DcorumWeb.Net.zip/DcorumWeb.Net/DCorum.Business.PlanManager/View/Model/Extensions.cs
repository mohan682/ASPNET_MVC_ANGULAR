﻿using Dcorum.BusinessLayer.BusinesObjects;
using DCorum.Business.PlanManager.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DCorum.Business.PlanManager.View.Model
{
    public static class RwwqHeaderVmExtensions
    {
        public static RrwqHeaderVm ToViewModel(this RrwqHeader model,
            IEnumerable<string> availableTitleTargets,
            IEnumerable<string> availableTextTargets)
        {
            var vm = new RrwqHeaderVm(model.Id);
            vm.Header_Order = model.DisplayOrder;
            vm.Section_Heading_Text_Content_Target_ID = model.TextTarget;
            vm.Section_Heading_Title_Content_Target_ID = model.TitleTarget;
            vm.AvailableTextTargets = availableTextTargets;
            vm.AvailableTitleTargets = availableTitleTargets;
            vm.Context_Code = model.ContextCode;
            return vm;
        }

        public static RrwqHeader ToModel(this RrwqHeaderVm vm)
        {
            var model = new RrwqHeader()
            {
                Id = vm.Header_Id,
                DisplayOrder = vm.Header_Order,
                TextTarget = vm.Section_Heading_Text_Content_Target_ID,
                TitleTarget = vm.Section_Heading_Title_Content_Target_ID,
                ContextCode = vm.Context_Code             
            };

            return model;
        }
    }

    public static class RwwqQuestionVmExtensions
    {
        public static RrwqQuestionVm ToViewModel(this RrwqQuestion model,
            IEnumerable<RrwqHeader> headerModels,
            IEnumerable<string> availableQuestionTargets,
            IEnumerable<string> availableLinkedStatementTargets,
            IEnumerable<string> AvailableLinkedDeclarationTargets,
            IEnumerable<RefCode> refCodes)
        {
            var vm = new RrwqQuestionVm(model.Id);

            vm.AvailableLinkedDeclarationTargets = AvailableLinkedDeclarationTargets;
            vm.AvailableLinkedStatementTargets = availableLinkedStatementTargets;
            vm.AvailableQuestionTargets = availableQuestionTargets;

            vm.AvailableSectionHeadingContentTargets = new Dictionary<string, string>();
            foreach (var headerModel in headerModels)
                vm.AvailableSectionHeadingContentTargets[headerModel.Id.ToString()] = headerModel.TitleTarget;

            vm.DesiredAnswer = new RefCode(model.DesiredAnswer);
            var refCode = refCodes.FirstOrDefault(o => Convert.ToInt32(o.RefCd) == model.DesiredAnswer);
            vm.Desired_Answer = refCode != null ? refCode.Textual : "<unknown>";

            vm.Display_Order = model.DisplayOrder;
            vm._Section_Heading_Content_Target_ID = model.HeaderId.ToString();
            vm.Linked_Declaration_Content_Target_ID = model.DeclarationTarget;
            vm.Linked_Statement_Content_Target_ID = model.StatementTarget;
            vm.Question_Text_Content_Target_ID = model.QuestionTarget;

            var headerTextDesc = string.Empty;
            vm.AvailableSectionHeadingContentTargets.TryGetValue(model.HeaderId.ToString(), out headerTextDesc);
            vm.Section_Heading_Content_Target_ID = headerTextDesc;
            var header = headerModels.FirstOrDefault(o => o.Id == model.HeaderId);
            vm._HeaderOrder = header != null ? header.DisplayOrder : -1;

            return vm;
        }

        public static RrwqQuestion ToModel(this RrwqQuestionVm vm)
        {
            var model = new RrwqQuestion(vm.Question_Id);
            model.DeclarationTarget = vm.Linked_Declaration_Content_Target_ID;
            model.DesiredAnswer = Convert.ToInt32(vm.DesiredAnswer.RefCd);
            model.DisplayOrder = vm.Display_Order;
            int headerId = -1;
            if (!int.TryParse(vm._Section_Heading_Content_Target_ID, out headerId))
                headerId = -1;
            model.HeaderId = headerId;
            model.QuestionTarget = vm.Question_Text_Content_Target_ID;
            model.StatementTarget = vm.Linked_Statement_Content_Target_ID;

            return model;
        }
    }

    public static class PtfcCalculationVmExtensions
    {
        public static PtfcCalculationVm CopyDataModelDetails(this PtfcCalculationVm recipient, PtfcCalcVariables model, PtfcCalcResult calc)
        {
            if (model == null) return null;

            var vm = recipient ?? new PtfcCalculationVm(model.CaseMbrKey);
            vm.MaxTaxFreeCashAt5Apr2006 = model.MaxTfc5Apr2006;
            vm.MoneyPurchaseAnnualAllowanceApplies = model.MoneyPurchaseAnnualAllowanceApplies;
            vm.ProtectedTaxFreeCashForfeited = model.ProtTfcForfeited; //.NullableConvert(Convert.ToBoolean);
            vm.StandAloneLumpSumApplies = model.StandAloneLumpSumFlag; //.NullableConvert(Convert.ToBoolean);
            vm.TotalValueOfBenefitsAt5Apr2006 = model.TotBenVal5Apr2006;
            vm.ValueOfPreviousPartialTransfers = model.ValPrevPartTfrs;

            vm.CurrentFundValue = model.AccountBalance;

            vm.ProtectedTaxFreeCash = calc.PtfcAmount;
            vm.ProtectedTaxFreeCashPercent = calc.PtfcPercent;
            vm.PensionCommencementLumpSum = calc.PclsAmount;
            vm.ResidualFundValue = vm.CurrentFundValue == 0M ? 0M : calc.ResidualBalance;
            vm.PtfcErrorMessage = calc.ErrorMessage;         

            return vm;
        }

        public static PtfcCalcVariables CopyViewModelDetails(this PtfcCalcVariables recipient, PtfcCalculationVm vm )
        {
            var model = recipient ?? new PtfcCalcVariables();
            model.CaseMbrKey = vm._Id;
            model.MaxTfc5Apr2006 = vm.MaxTaxFreeCashAt5Apr2006;
            model.MoneyPurchaseAnnualAllowanceApplies = vm.MoneyPurchaseAnnualAllowanceApplies;
            model.ProtTfcForfeited = vm.ProtectedTaxFreeCashForfeited; //.NullableConvert( Convert.@ToInt32 ) ; 
            model.StandAloneLumpSumFlag = vm.StandAloneLumpSumApplies; //.NullableConvert( Convert.@ToInt32 ) ;
            model.TotBenVal5Apr2006 = vm.TotalValueOfBenefitsAt5Apr2006;
            model.ValPrevPartTfrs = vm.ValueOfPreviousPartialTransfers;

            return model;
        }
    }
}
