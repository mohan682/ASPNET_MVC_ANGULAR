﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.Configuration.Contractual;
using DCorum.Business.PlanManager.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace DCorum.Business.PlanManager.View.Controller
{
    public interface IIOPortfolioController
    {
        IOPortfolio Get(int id);
        IEnumerable<IOPortfolio> GetAll();
        IEnumerable<IOPortfolio> GetAll(int clientId);
        IEnumerable<IOutcomeItem> Save(IOPortfolio model);

        IEnumerable<IOutcomeItem> Delete(IOPortfolio model);

        IEnumerable<IOPortfolio> SortViewModels(IEnumerable<IOPortfolio> tableViewModel, string sortColumn, bool sortAscending);
    }

    public class IOPortfolioController : IIOPortfolioController
    {
        #region Fields

        const int UninitId = -1;

        private readonly IIOPortfolioDal _dal;
        private readonly IAuditor MyAuditor;
        private readonly IDcorumUser _activeUser;

        #endregion

        #region Properties

        private bool UserIsInSecurityGroup
        {
            get
            {
                return _activeUser.IsInGroup(GroupId.IOClientEdit);
            }
        }

        #endregion

        #region Ctor

        internal IOPortfolioController(IIOPortfolioDal dal, IDcorumUser activeUser, IAuditor auditor)
        {
            _dal = dal;
            MyAuditor = auditor ;
            _activeUser = activeUser;

            if (_dal == null) throw new ArgumentNullException(nameof(dal));
            if (_activeUser == null) throw new ArgumentNullException(nameof(activeUser));
            if (MyAuditor == null) throw new ArgumentNullException(nameof(auditor));
        }

        public IOPortfolio Get(int id)
        {
            var item = _dal.Get(id);

            item.IsReadonly = !UserIsInSecurityGroup;

            return item;
        }

        public IEnumerable<IOutcomeItem> Delete(IOPortfolio model)
        {
            var result = new List<IOutcomeItem>();

            if (UserIsInSecurityGroup)
            {
                IOPortfolio oldModel = _dal.Get(model.PortfolioId);
                int recordUpdated = _dal.Delete(model);

                if (recordUpdated <= 0)
                {
                    result.Add(new OutcomeItem("Something went wrong while deleting the data,please contact us"));
                }
                else
                {
                    var newModel = _dal.Get(model.PortfolioId) ;
                    MyAuditor.AuditChanges(newModel, oldModel);
                    result.AddRange(MyAuditor.YieldAndPurgeAllRemarks()) ; 
                }
            }
            else
            {
                result.Add(new OutcomeItem("User does not have permission to update,please contact us"));
            }

            return result;
        }

        public IEnumerable<IOPortfolio> GetAll()
        {
            var list = _dal.GetAll();

            bool isReadonly = !UserIsInSecurityGroup;

            list.ToList().ForEach(i => i.IsReadonly = isReadonly);

            return list;
        }

        public IEnumerable<IOPortfolio> GetAll(int clientId)
        {
            var list = _dal.GetAll(clientId);

            bool isReadonly = !UserIsInSecurityGroup;

            list.ToList().ForEach(i => i.IsReadonly = isReadonly);

            return list;
        }

        public IEnumerable<IOutcomeItem> Save(IOPortfolio model)
        {
            var result = new List<IOutcomeItem>();
            if (UserIsInSecurityGroup)
            {
                //Expiry Date Validation
                if (model.ExpiryDate.HasValue && model.ExpiryDate.Value < model.EffectiveDate)
                {
                    result.Add(new OutcomeItem("Expiry Date should be greater than effective date."));
                    return result;
                }

                bool refsExist = PortfolioReferenceExists(model);
                if (refsExist)
                {
                    result.Add(new OutcomeItem("Portfolio Reference already exists. Must be unique"));
                    return result;
                }

                bool portfolioNameExist = PortfolioNameExists(model);
                if (portfolioNameExist)
                {
                    result.Add(new OutcomeItem("Portfolio Name already exists. Must be unique"));
                    return result;
                }

                IOPortfolio oldModel = _dal.Get(model.PortfolioId);

                int recordUpdated = (model.PortfolioId > 0) ? _dal.Update(model) : _dal.Insert(model);

                if (recordUpdated <= 0)
                {
                    result.Add(new OutcomeItem("Something went wrong while saving the data,please contact us"));
                }
                else
                {
                    var newModel = _dal.Get(model.PortfolioId);
                    MyAuditor.AuditChanges(newModel, oldModel);
                    result.AddRange(MyAuditor.YieldAndPurgeAllRemarks());
                }
            }
            else
                result.Add(new OutcomeItem("User does not have permission to update,please contact us"));

            return result;
        }

        private bool PortfolioReferenceExists(IOPortfolio model)
        {
            bool refExists = false;

            var portfolios = _dal.GetDuplicateReferences(model.PortfolioReference);

            foreach (var portfolio in portfolios)
            {
                if (portfolio.PortfolioId != model.PortfolioId)
                {
                    refExists = true; //data already exists
                    break;
                }


            }

            return refExists;
        }

        private bool PortfolioNameExists(IOPortfolio model)
        {
            bool portfolioNameExists = false;

            var portfolios = _dal.GetDuplicatePortfolioNames(model.PortfolioName);

            foreach (var portfolio in portfolios)
            {
                if (portfolio.PortfolioId != model.PortfolioId)
                {
                    portfolioNameExists = true; //data already exists
                    break;
                }
            }

            return portfolioNameExists;
        }




        public IEnumerable<IOPortfolio> SortViewModels(IEnumerable<IOPortfolio> viewModels, string sortCol, bool sortAscending)
        {

            if (string.IsNullOrEmpty(sortCol)) return viewModels;

            Func<IOPortfolio, object> sortTechnique1 = null;

            ParameterExpression param = Expression.Parameter(typeof(IOPortfolio), sortCol);
            UnaryExpression ue1 = Expression.Convert(Expression.Property(param, sortCol), typeof(object));
            var sortby = Expression.Lambda<Func<IOPortfolio, object>>(ue1, param);

            sortTechnique1 = sortby.Compile();

            if (sortTechnique1 != null)
            {
                if (sortAscending)
                    viewModels = viewModels.OrderBy(@sortTechnique1);
                else
                    viewModels = viewModels.OrderByDescending(@sortTechnique1);
            }

            return viewModels;
        }

        #endregion
    }
}
