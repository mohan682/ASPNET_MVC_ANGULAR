﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.Configuration.Contractual;
using DCorum.Business.PlanManager.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace DCorum.Business.PlanManager.View.Controller
{

    public interface IIOClientController
    {
        bool CanSave();

        IOClient Get(int id);

        KeyValuePair<int,string>? GetIdAndName(int? id,string reference);

        IEnumerable<IOClient> GetAll();
        IEnumerable<IOutcomeItem> Save(IOClient model);
        IEnumerable<IOClient> SortViewModels(IEnumerable<IOClient> tableViewModel, string sortColumn, bool sortAscending);

        IEnumerable<IOutcomeItem> Delete(IOClient model);

        IEnumerable<IOClient> GetClientRef(int? id, string reference);



    }

    public class IOClientController : IIOClientController
    {
        #region Fields

        const int UninitId = -1;

        private readonly IIOClientDal _dal;
        private readonly IAuditor MyAuditor;
        private readonly IDcorumUser _activeUser;

        #endregion

        #region Properties

        private bool UserIsInSecurityGroup
        {
            get
            {
                return _activeUser.IsInGroup(GroupId.IOClientEdit);
            }
        }

        #endregion

        #region Ctor

        public bool CanSave()
        {
            return UserIsInSecurityGroup;
        }

        internal IOClientController(IIOClientDal dal, IDcorumUser activeUser, IAuditor auditor)
        {
            _dal = dal;
            MyAuditor = auditor;
            _activeUser = activeUser;

            if (_dal == null) throw new ArgumentNullException(nameof(dal));
            if (_activeUser == null) throw new ArgumentNullException(nameof(activeUser));
            if (MyAuditor == null) throw new ArgumentNullException(nameof(auditor));
        }

        public IOClient Get(int id)
        {
            var item= _dal.Get(id);

            item.IsReadOnly = !UserIsInSecurityGroup;

            if(!string.IsNullOrEmpty(item.MicrositeCode))
            {
                item.Microsites = _dal.GetMicrosites(item);
            }

            return item;
        }

        public KeyValuePair<int, string>? GetIdAndName(int? id, string reference)
        {
            IOClient item = null;

            if (id.HasValue && id > 0)
                item = _dal.Get(id.Value);
            else if (!string.IsNullOrEmpty(reference))
                item = _dal.Get(reference);

            if (item == null) return null;

            return new KeyValuePair<int, string>(item.ClientId, item.DisplayText);
        }

        public IEnumerable<IOClient> GetAll()
        {
            var list = _dal.GetAll();

            bool isReadonly = !UserIsInSecurityGroup;

            list.ToList().ForEach(i => i.IsReadOnly = isReadonly);

            return list;
        }

        public IEnumerable<IOClient> GetClientRef(int? id, string reference)
        {
            IEnumerable<IOClient> clients = null;

            if (id.HasValue && id > 0)
            {
                clients = _dal.GetClientRef(id.Value, reference.ToLower());
            }
            else if (!string.IsNullOrEmpty(reference))
            {
                clients = _dal.GetClientRef(reference.ToLower());
            }

            return clients;
        }

        public IEnumerable<IOutcomeItem> Delete(IOClient model)
        {
            var result = new List<IOutcomeItem>();
            if (UserIsInSecurityGroup)
            {
                IOClient oldModel = _dal.Get(model.ClientId);
                int recordUpdated = _dal.Delete(model);

                if (recordUpdated <= 0)
                {
                    result.Add(new OutcomeItem("Something went wrong while deleting the data,please contact us."));
                }
                else
                {
                    var newModel = _dal.Get(model.ClientId);
                    MyAuditor.AuditChanges(newModel, oldModel);
                    result.AddRange(MyAuditor.YieldAndPurgeAllRemarks());
                }
            }
            else
            {
                result.Add(new OutcomeItem("User does not have permission to update,please contact us."));
            }
            return result;
        }

        public IEnumerable<IOutcomeItem> Save(IOClient model)
        {
            var result = new List<IOutcomeItem>();
            if (UserIsInSecurityGroup)
            {
                //Expiry Date Validation
                if (model.ExpiryDate.HasValue && model.ExpiryDate.Value < model.EffectiveDate)
                {
                    result.Add(new OutcomeItem("Expiry Date should be greater than effective date."));
                    return result;
                }

                if (_dal.SelectDuplicates( new IOClient() { MicrositeCode = model.MicrositeCode })?.Any( _ => _.ClientId != model.ClientId) != false)
                {
                    result.Add(new OutcomeItem("Microsite code is already being used by another client!"));
                    return result;
                }

                IOClient oldModel = _dal.Get(model.ClientId);
                int recordUpdated = (model.ClientId > 0) ? _dal.Update(model) : _dal.Insert(model);

                if (recordUpdated <= 0)
                {
                    result.Add(new OutcomeItem("Something went wrong while saving the data,please contact us."));
                }
                else
                {
                    var newModel = (model.ClientId > 0) ? _dal.Get(model.ClientId): _dal.Get(model.ClientReference);
                    MyAuditor.AuditChanges(newModel, oldModel);
                    result.AddRange(MyAuditor.YieldAndPurgeAllRemarks());
                }
            }
            else
            {
                result.Add(new OutcomeItem("User does not have permission to update,please contact us."));
            }
            return result;
        }

        public IEnumerable<IOClient> SortViewModels(IEnumerable<IOClient> viewModels, string sortCol, bool sortAscending)
        {

            if (string.IsNullOrEmpty(sortCol)) return viewModels;

            Func<IOClient, object> sortTechnique1 = null;

            ParameterExpression param = Expression.Parameter(typeof(IOClient), sortCol);
            UnaryExpression ue1 = Expression.Convert(Expression.Property(param, sortCol), typeof(object));
            var sortby = Expression.Lambda<Func<IOClient, object>>(ue1, param);

            sortTechnique1 = sortby.Compile();

            if (sortTechnique1 != null)
            {
                if (sortAscending)
                    viewModels = viewModels.OrderBy(@sortTechnique1);
                else
                    viewModels = viewModels.OrderByDescending(@sortTechnique1);
            }

            return viewModels;
        }

        #endregion
    }
}
