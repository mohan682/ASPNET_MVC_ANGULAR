﻿using DCorum.Business.PlanManager.View.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DCorum.BusinessFoundation.Contractual;
using DCorum.Business.PlanManager.DataAccess;
using DCorum.Business.PlanManager.Entities.Validation;
using DCorum.Business.PlanManager.Entities;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.BusinesObjects;
using DCorum.BusinessFoundation.Validation;
using DCorum.Business.PlanManager.Logic;
using DCorum.BusinessFoundation.Auditing.Constants;

namespace DCorum.Business.PlanManager.View.Controller
{
    /// <summary>
    /// RrwqQuestionController manages interaction between view and model
    /// </summary>
    public class RrwqQuestionController : IController<RrwqQuestionVm, int>
    {
        #region Fields

        private readonly IRrwqQuestionDal _rrwqQuestionDal;
        private readonly IRrwqHeaderDal _rrwqHeaderDal;
        private readonly IContentDal _contentDal;
        private readonly IRefCodesDal _refCodesDal;
        private readonly IAuditService _auditService;

        private readonly int _userId;

        private Lazy<IEnumerable<string>> _availableContentTargets;
        private Lazy<IEnumerable<RefCode>> _refCodes;

        const int UninitId = -1;
        
        #endregion

        #region Ctor

        internal RrwqQuestionController(IRrwqQuestionDal rrwqQuestionDal, 
            IRrwqHeaderDal rrwqHeaderDal, IContentDal contentDal, IRefCodesDal refCodesDal, IAuditService auditService, int userId)
        {
            if (rrwqQuestionDal == null) throw new ArgumentNullException("rrwqQuestionDal");
            if (rrwqHeaderDal == null) throw new ArgumentNullException("rrwqHeaderDal");
            if (contentDal == null) throw new ArgumentNullException("contentDal");
            if (refCodesDal == null) throw new ArgumentNullException("refCodesDal");
            if (auditService == null) throw new ArgumentNullException("auditService");

            _rrwqQuestionDal = rrwqQuestionDal;
            _rrwqHeaderDal = rrwqHeaderDal;
            _contentDal = contentDal;
            _refCodesDal = refCodesDal;
            _auditService = auditService;
            _userId = userId;

            _availableContentTargets = new Lazy<IEnumerable<string>>(() => _contentDal.Get("rrwq").Select(o => o.Target).Distinct().ToArray());
            _refCodes = new Lazy<IEnumerable<RefCode>>(() => _refCodesDal.Get(DomainNames.CompassYesNoValues).ToArray());
        }

        #endregion

        #region Non Public Methods
        
        void Audit(RrwqQuestion existing, RrwqQuestion newModel)
        {
            _auditService.Audit(true, DomainCodes.DCorumRrwq, newModel, existing, _userId,
                   (o) =>
                   {
                       var m = (RrwqQuestion)o;
                       return new Tuple<RefCode, string>(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeTableSeqId), m.Id.ToString());
                   });
        }

        #endregion

        #region IController<RrwqQuestionVm, int> Members

        public int UninitialisedId
        {
            get
            {
                return UninitId;
            }
        }

        public IEnumerable<IOutcomeItem> Add(RrwqQuestionVm viewModel)
        {
            try
            {
                var model = viewModel.ToModel();
                var rules = RwwqQuestionValidationFactory.CreateInsertValidationRules(model, 
                    _rrwqQuestionDal.GetAll(), 
                    _rrwqHeaderDal.GetAll(),
                    _refCodes.Value.Select(o=>Convert.ToInt32(o.RefCd)));
                new Validator().Validate(rules);

                var newModelId = _rrwqQuestionDal.Insert(model);
                var newModel = _rrwqQuestionDal.Get(newModelId);
#if DEBUG
                System.Diagnostics.Debug.Assert(newModel != null);
#endif

                Audit(null, newModel);

                return new IOutcomeItem[] { };
            }
            catch (Exception ex)
            {
                return new IOutcomeItem[] { new OutcomeItem(ex.Message) };
            }
        }

        public RrwqQuestionVm CreateModel()
        {
            var model = new RrwqQuestion(UninitialisedId);
            var displayOrder = 1;
            try
            {
                var existingVms = _rrwqQuestionDal.GetAll();
                displayOrder = existingVms.Any() ? existingVms.Max(o => o.DisplayOrder) + 1 : displayOrder;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
            }

            model.DeclarationTarget = string.Empty;
            model.DesiredAnswer = 0;
            model.DisplayOrder = displayOrder;
            model.HeaderId = -1;
            model.QuestionTarget = string.Empty;
            model.StatementTarget = string.Empty;

            return model.ToViewModel(_rrwqHeaderDal.GetAll(),
                _availableContentTargets.Value,
                _availableContentTargets.Value,
                _availableContentTargets.Value,
                _refCodes.Value);
        }

        public IEnumerable<IOutcomeItem> Delete(RrwqQuestionVm viewModel)
        {
            try
            {
                var model = viewModel.ToModel();

                var id = _rrwqQuestionDal.Delete(model);
                var newModel = _rrwqQuestionDal.GetForAuditing(id);
#if DEBUG
                System.Diagnostics.Debug.Assert(newModel != null);
#endif
                Audit(model, newModel);

                return new IOutcomeItem[] { };
            }
            catch (Exception ex)
            {
                return new IOutcomeItem[] { new OutcomeItem(ex.Message) };
            }
        }

        public RrwqQuestionVm Get(int id)
        {
            var model = _rrwqQuestionDal.Get(id);
            if (model == null) return null;

            return model.ToViewModel(_rrwqHeaderDal.GetAll(),
                _availableContentTargets.Value,
                _availableContentTargets.Value,
                _availableContentTargets.Value,
                _refCodes.Value);
        }

        public IEnumerable<RrwqQuestionVm> GetAll()
        {
            var models = _rrwqQuestionDal.GetAll();
            if (!models.Any()) return new RrwqQuestionVm[] { };

            return models.Select(m => m.ToViewModel(_rrwqHeaderDal.GetAll(),
                _availableContentTargets.Value,
                _availableContentTargets.Value,
                _availableContentTargets.Value,
                _refCodes.Value)).
                OrderBy(vm => vm, new RrwqQuestionVm.DefaultScreenViewComparer()).
                ToArray();
        }

        public IEnumerable<IOutcomeItem> Update(RrwqQuestionVm viewModel)
        {
            try
            {
                var model = viewModel.ToModel();
                var existingModels = _rrwqQuestionDal.GetAll();
                var rules = RwwqQuestionValidationFactory.CreateUpdateValidationRules(model,
                    _rrwqQuestionDal.GetAll(),
                    _rrwqHeaderDal.GetAll(),
                    _refCodes.Value.Select(o => Convert.ToInt32(o.RefCd)));
                new Validator().Validate(rules);
                int newModelId = _rrwqQuestionDal.Update(model);
                var newModel = _rrwqQuestionDal.Get(newModelId);
                model = _rrwqQuestionDal.GetForAuditing(model.Id);
#if DEBUG
                System.Diagnostics.Debug.Assert(newModel != null);
                System.Diagnostics.Debug.Assert(model != null);
#endif
                Audit(model, newModel);

                return new IOutcomeItem[] { };
            }
            catch (Exception ex)
            {
                return new IOutcomeItem[] { new OutcomeItem(ex.Message) };
            }
        }
        
        #endregion
    }
}
