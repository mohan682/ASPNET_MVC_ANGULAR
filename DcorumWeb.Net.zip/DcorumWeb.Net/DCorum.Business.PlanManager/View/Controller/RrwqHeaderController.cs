﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using DCorum.Business.PlanManager.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.Business.PlanManager.Entities.Validation;
using DCorum.Business.PlanManager.Logic;
using DCorum.Business.PlanManager.View.Model;
using DCorum.BusinessFoundation.Auditing.Constants;
using DCorum.BusinessFoundation.Contractual;
using DCorum.BusinessFoundation.Validation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace DCorum.Business.PlanManager.View.Controller
{
    /// <summary>
    /// RrwqHeaderController manages interaction between view and model
    /// </summary>
    public class RrwqHeaderController : IController<RrwqHeaderVm, int>
    {
        #region Fields

        private readonly IRrwqHeaderDal _rwqHeaderDal;
        private readonly IContentDal _contentDal;
        private readonly IAuditService _auditService;

        private readonly int _userId;

        private Lazy<IEnumerable<string>> _availableContentTargets;

        const int UninitId = -1;

        public int UninitialisedId
        {
            get
            {
                return UninitId;
            }
        }

        #endregion

        #region Ctor

        internal RrwqHeaderController(IRrwqHeaderDal rwqHeaderDal, IContentDal contentDal, IAuditService auditService, int userId)
        {
            if (rwqHeaderDal == null) throw new ArgumentNullException("rwqHeaderDal");
            if (contentDal == null) throw new ArgumentNullException("contentDal");
            if (auditService == null) throw new ArgumentNullException("auditService");

            _rwqHeaderDal = rwqHeaderDal;
            _contentDal = contentDal;
            _auditService = auditService;
            _userId = userId;

            _availableContentTargets = new Lazy<IEnumerable<string>>(() => _contentDal.Get("rrwq").Select(o => o.Target).Distinct().ToArray());
        }

        #endregion

        #region Non Public Methods

        void Audit(RrwqHeader existing, RrwqHeader newModel)
        {
            _auditService.Audit(true, DomainCodes.DCorumRrwqh, newModel, existing, _userId,
                   (o) =>
                   {
                       var m = (RrwqHeader)o;
                       return new Tuple<RefCode, string>(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeTableSeqId), m.Id.ToString());
                   });
        }

        #endregion

        #region IController<RrwqHeaderVm, int> Members

        public RrwqHeaderVm CreateModel()
        {
            var vm = new RrwqHeaderVm(UninitialisedId);
            var headerOrder = 1;
            try
            {
                var existingVms = _rwqHeaderDal.GetAll();
                headerOrder = existingVms.Any() ? existingVms.Max(o => o.DisplayOrder) + 1 : headerOrder;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
            }
            vm.Header_Order = headerOrder;
            vm.Section_Heading_Text_Content_Target_ID = string.Empty;
            vm.Section_Heading_Title_Content_Target_ID = string.Empty;
            vm.AvailableTextTargets = _availableContentTargets.Value;
            vm.AvailableTitleTargets = _availableContentTargets.Value;

            return vm;
        }

        public RrwqHeaderVm Get(int id)
        {
            var model = _rwqHeaderDal.Get(id);
            if (model == null) return null;

            return model.ToViewModel(_availableContentTargets.Value, _availableContentTargets.Value);
        }

        public IEnumerable<RrwqHeaderVm> GetAll()
        {
            var models = _rwqHeaderDal.GetAll();
            if (!models.Any()) return new RrwqHeaderVm[] { };

            return models.Select(m => m.ToViewModel(_availableContentTargets.Value, _availableContentTargets.Value)).ToArray();
        }

        public IEnumerable<IOutcomeItem> Add(RrwqHeaderVm viewModel)
        {
            try
            {
                Debug.Assert(viewModel?.Header_Id > 0 == false, "0" );

                var model = viewModel.ToModel();
                var existingModels = _rwqHeaderDal.GetAll();
                var rules = RwwqHeaderValidationFactory.CreateInsertValidationRules(model, existingModels);
                new Validator().Validate(rules);
                _rwqHeaderDal.Insert(model);

#if DEBUG
                Debug.Assert(model.Id > 0, "1");
#endif

                var newModel = _rwqHeaderDal.Get(model.Id);

                Audit(null, newModel);

                return new IOutcomeItem[] { };
            }
            catch (Exception ex)
            {
                return new IOutcomeItem[] { new OutcomeItem(ex.Message) };
            }
        }

        public IEnumerable<IOutcomeItem> Update(RrwqHeaderVm viewModel)
        {
            try
            {
                var model = viewModel.ToModel();
                var existingModels = _rwqHeaderDal.GetAll();
                var rules = RwwqHeaderValidationFactory.CreateUpdateValidationRules(model, existingModels);
                new Validator().Validate(rules);
                _rwqHeaderDal.Update(model);
                var newModel = _rwqHeaderDal.Get(model.Id);
#if DEBUG
                System.Diagnostics.Debug.Assert(newModel != null);
#endif
                Audit(model, newModel);

                return new IOutcomeItem[] { };
            }
            catch (Exception ex)
            {
                return new IOutcomeItem[] { new OutcomeItem(ex.Message) };
            }
        }

        public IEnumerable<IOutcomeItem> Delete(RrwqHeaderVm viewModel)
        {
            try
            {
                var model = viewModel.ToModel();
                _rwqHeaderDal.Delete(model);
                var newModel = _rwqHeaderDal.GetForAuditing(model.Id);
#if DEBUG
                System.Diagnostics.Debug.Assert(newModel != null);
#endif
                Audit(model, newModel);

                return new IOutcomeItem[] { };
            }
            catch (Exception ex)
            {
                return new IOutcomeItem[] { new OutcomeItem(ex.Message) };
            }
        }

        #endregion
    }
}
