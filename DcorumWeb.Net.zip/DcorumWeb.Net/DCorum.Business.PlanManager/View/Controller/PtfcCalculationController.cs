﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DCorum.BusinessFoundation.Contractual;
using DCorum.Business.PlanManager.View.Model;
using DCorum.Business.PlanManager.DataAccess;
using Dcorum.Configuration.Contractual;
using DCorum.Business.PlanManager.Entities.Validation;
using DCorum.Business.PlanManager.Logic;
using DCorum.Business.PlanManager.Entities;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using DCorum.BusinessFoundation.Auditing.Constants;
using DCorum.BusinessFoundation.Validation;
using Dcorum.BusinessCore.Contractual;

namespace DCorum.Business.PlanManager.View.Controller
{

    public interface IPtfcCalculationController
    {
        PtfcCalculationVm.State GetState(int id, bool isInEditMode);

        PtfcCalculationVm Get(int id);

        IEnumerable<IOutcomeItem> Update(PtfcCalculationVm viewModel);
    }

    public class PtfcCalculationController : IPtfcCalculationController
    {
        #region Fields

        const int UninitId = -1;

        private readonly IPtfcCalculationDal _dal;
        private readonly IAuditService _auditSvc;
        private readonly IDcorumUser _activeUser;

        #endregion

        #region Properties

        private bool UserIsInSecurityGroup
        {
            get
            {
                return _activeUser.IsInGroup(GroupId.RetirementBenefitsEdit);
            }
        }

        #endregion

        #region Ctor

        internal PtfcCalculationController(IPtfcCalculationDal dal, 
            IDcorumUser activeUser, IAuditService auditService)
        {
            _dal = dal;
            _auditSvc = auditService;
            _activeUser = activeUser ;

            if (_dal == null) throw new ArgumentNullException(nameof(dal));
            if (_activeUser == null) throw new ArgumentNullException(nameof(activeUser));
            if (_auditSvc == null) throw new ArgumentNullException(nameof(auditService));
        }

        #endregion

        #region Non Public Methods

        private IEnumerable<IOutcomeItem> Audit(bool success, PtfcCalcVariables existingModel, PtfcCalcVariables newModel)
        {
            return _auditSvc.Audit(success, DomainCodes.DCorumRetirementBenefits, newModel, existingModel, _activeUser.Id,
                (o) =>
                {
                    var m = (PtfcCalcVariables)o;
                    return new Tuple<RefCode, string>(new RefCode(AuditingDomainCodes.DataAuditIdentifierTypeMbr), m.CaseMbrKey.ToString());
                });
        }

        public IEnumerable<IOutcomeItem> Update(PtfcCalculationVm viewModel)
        {
            PtfcCalcVariables model = null;
            PtfcCalcVariables existingModel = null;

            try
            {
                int id = viewModel._Id ;
        
                existingModel = _dal.Get( id );

                model = _dal.Get(id).CopyViewModelDetails(viewModel);

                var rules = PtfcCalcValidationFactory.CreateUpdateValidationRules(model, existingModel, _activeUser);
              
                new Validator().Validate(rules);
                int res = _dal.Update(model);

                var results = Audit(res > 0, existingModel, model);

                return results;
            }
            catch (Exception ex)
            {
                return new IOutcomeItem[] { new OutcomeItem(ex.Message) };
            }

        }

        #endregion

        #region IPtfcCalculationController Members
        
        public PtfcCalculationVm.State GetState(int id, bool isInEditMode)
        {
            if (!isInEditMode) return new PtfcCalculationVm.State(true, true, true, true, true, true); 

            var userInSecurityGroup = UserIsInSecurityGroup;

            return new PtfcCalculationVm.State(!userInSecurityGroup,
                !userInSecurityGroup,
                !userInSecurityGroup,
                false,
                false,
                false);
        }

        public PtfcCalculationVm Get(int id)
        {
            var result = new PtfcCalculationVm(id).CopyDataModelDetails( _dal.Get(id), _dal.CalculatePtfc(id) ) ;
            return result ;
        }

        #endregion
    }
}
