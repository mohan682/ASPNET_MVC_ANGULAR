﻿using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dcorum.Utilities.Extensions;
using DCorum.Business.PlanManager.Entities;

using static DCorum.Business.PlanManager.Bundles.TransfersReadOnlyBundle;


namespace DCorum.Business.PlanManager.Structural
{
    public class BLTransferDetailAdaptor : IPersistor<TransferDetail>
    {
        public BLTransferDetailAdaptor(BLTransferDetail source )
        {
            _toAdapt = source;
        }

        private BLTransferDetail _toAdapt;

        public string GetTextualIdentityOf(TransferDetail ofInterest)
        {
            return ofInterest.StrongId.ToString();
        }

        public string TextualAmbientValue { get { return default(int).ToString(); } }


        public TransferDetail[] GetManyViaTextualId(string parentId, string augmentQueryWith = null)
        {
            throw new NotImplementedException();
        }


        public TransferDetail GetUniqueViaTextualId(string uniqueId)
        {
            IAlternativeTransferId planB = null;

            int? primaryKey = uniqueId.IntoIntN();
            if (primaryKey.HasValue)
            {
                return _toAdapt.GetTransferDetail(primaryKey.Value);
            }
            else if((planB = TransferJunction.ParseId(uniqueId)) !=null)
            {
                return _toAdapt.GetTransferDetail(planB);
            }
            else throw new ArgumentException(string.Empty, nameof(uniqueId));           
        }



        //public void Hydrate(TransferDetail toBuildUp)
        //{
        //    throw new NotImplementedException();
        //}

        public IEnumerable<IOutcomeItem> Save(TransferDetail toSave)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOutcomeItem> Erase(TransferDetail toSave)
        {
            throw new NotImplementedException();
        }
    }
}
