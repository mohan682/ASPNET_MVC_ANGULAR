﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.Entities;
using Dcorum.BusinessLayer.Logic;
using Dcorum.Utilities.Practices;
using DCorum.Business.PlanManager.Entities;

namespace DCorum.Business.PlanManager.Logic
{
    [Category(DomainCodes.DCorumComponentMiscSchemeContact)]
    public class BLSchemeContact 
        : BLPersistorTemplate<SchemeContactGraph>
    {
        //configuration
        public static string ImageUrlTemplate { get; set; }
        public static string ImageUncTempalte { get; set; }

        public BLSchemeContact(IAuditingArgumentsReadOnly tarnishSource, ICrudFull<SchemeContactGraph> crudFull)
            : base(tarnishSource, crudFull)
        {
            _deferredUser = new Lazy<DcorumUser>(() => BLDcorumUser.Singleton.GetUserById(_userId.Value));
        }

        private int? _userId;
        private Lazy<DcorumUser> _deferredUser;
        protected DcorumUser ActiveUser { get { return _deferredUser.Value; } }

        //private bool? _schemeReadOnlyModeOn = null;

        //public bool SchemeReadOnlyModeOn
        //{
        //    private get
        //    {
        //        return _schemeReadOnlyModeOn ?? false;
        //    }
        //    set
        //    {
        //        _schemeReadOnlyModeOn = _schemeReadOnlyModeOn ?? value;
        //    }
        //}

        protected override object AnonymousTableRowFacade(SchemeContactGraph model)
        {
            object result = new
            {
                _Misc_Contact_key = model.MiscContactKey,
                __canDelete = (model.CanDelete && ActiveUser.CanEditSchemeSummary).ToString(),
                NameId__ = model.NameId,
                First_Name_______ = model.Person.FirstName,
                Last_Name_______ = model.Person.LastName,
                Effective_From____ = model.EffectiveDate.ToString("dd/MM/yyyy"),
                Expires___________ = model.ExpiryDate.SafeFunc(_ => _.ToString("dd/MM/yyyy")),
                Scheme_Contact_Role________________ = model.ExternalRoleCode.SafeFunc(_ => _.Descript),
                //Image_URL______________________________ = model.ImageUrl
            };

            return result;
        }


        protected override bool InsertModeOn(SchemeContactGraph model)
        {
            return model.MiscContactKey2 == null ;
        }


        public override void Hydrate(SchemeContactGraph toHydrate)
        {
            base.Hydrate(toHydrate);

            if (InsertModeOn(toHydrate) && String.IsNullOrWhiteSpace(toHydrate.ImageUrl))
            {
                toHydrate.ImageUrl = String.Format(ImageUrlTemplate, toHydrate.NameId);
            }

            if (toHydrate.Person != null)
            {
                toHydrate.FirstName = toHydrate.Person.FirstName;
                toHydrate.LastName = toHydrate.Person.LastName;
            }

            TarnishModel(toHydrate); //will assign the userId to them model.

            Debug.Assert(_userId == null || _userId == toHydrate.UserId);

            _userId = _userId ?? toHydrate.UserId;

            toHydrate.CanPersist = (!ReadOnlyModeOn) && ActiveUser.CanEditSchemeSummary;
        }
    }
}
