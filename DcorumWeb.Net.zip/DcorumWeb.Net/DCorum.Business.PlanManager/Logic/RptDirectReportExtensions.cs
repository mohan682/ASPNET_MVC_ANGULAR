﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using DCorum.Business.PlanManager.Entities;
using Dcorum.Utilities.Extensions;

namespace DCorum.Business.PlanManager.Logic
{
    public static class RptDirectReportExtensions
    {
        public static bool CanSave(this RptDirectReport model)
        {
            if (model == null) return default(bool);

            bool result = !String.IsNullOrWhiteSpace(model.FileName);

            if (result) result &= model.Formattings != null && model.Formattings.All(_ => _.Value != null);

            if (result) result &= !GetUndefinedParameterIndexes(model).Any();

            return result;
        }

        public static bool CanTryExample(this RptDirectReport model)
        {
            if (model == null) return default(bool);

            bool result = !String.IsNullOrWhiteSpace(model.FullLocationTemplate());

            if (result) result &= model.CanSave();

            return result;
        }


        public static bool HasParameters(this RptDirectReport model)
        {
            bool result = model.Formattings.Any();
            return result;
        }


        public static int[] GetUndefinedParameterIndexes(this RptDirectReport model)
        {
            string fullLocation = model.FullLocationTemplate();

            int[] templateParams = (String.IsNullOrWhiteSpace(fullLocation)) ? Enumerable.Empty<int>().ToArray() : fullLocation.ParseParamIndexes();

            int[] result = templateParams.Except(model.Formattings.Keys).ToArray();
            return result;
        }


        public static string FullLocationTemplate(this RptDirectReport model)
        {
            if (model == null) return null;

            string result = Path.Combine(
                model.FullFolderPathTemplate() ?? String.Empty
                , model.FileName ?? String.Empty
                );

            if (String.IsNullOrWhiteSpace(result)) return null;

            return result;
        }


        public static string FullFolderPathTemplate(this RptDirectReport model)
        {
            if (model == null) return null;

            string result = Path.Combine(
                (model.IsExternal) ? String.Empty : model.ConfigPath
                , model.FolderPath ?? String.Empty
                );

            if (String.IsNullOrWhiteSpace(result)) return null;

            return result;
        }


        public static int[] ParseParamIndexes(this string withParameters)
        {
            string[] matches1 = Regex.Matches(withParameters, @"(?<=\{)[\d]{1,2}(?=\})").Cast<Match>().Select(_ => _.ToString()).ToArray();
            //int count1 = matches1.Length;
            int[] results = matches1.Select(_ => _.IntoIntN() ?? -1).ToArray();
            return results;
        }

    }
}
