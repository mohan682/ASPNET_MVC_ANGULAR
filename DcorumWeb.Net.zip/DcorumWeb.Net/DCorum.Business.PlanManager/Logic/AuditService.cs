﻿//using Dcorum.BusinessLayer.BusinesObjects;
//using Dcorum.BusinessLayer.Entities;
//using Dcorum.BusinessLayer.Logic.Helping;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace DCorum.Business.PlanManager.Logic
//{
//    public interface IAuditService
//    {
//        List<PDIMessage> Audit<T>(bool success, string category, T current1, T existing1,
//            int? userId = null, Func<object, Tuple<RefCode, string>> howToGetAuditIdentity = null)
//            where T : class;
//    }


//    public class AuditService : IAuditService
//    {
//        public List<PDIMessage> Audit<T>(bool success, string category, T current1, T existing1, 
//            int? userId = null, Func<object, Tuple<RefCode, string>> howToGetAuditIdentity = null)
//            where T : class
//        {
//            return BLHelper.Audit(success, category, current1, existing1, userId, howToGetAuditIdentity);
//        }
//    }
//}
