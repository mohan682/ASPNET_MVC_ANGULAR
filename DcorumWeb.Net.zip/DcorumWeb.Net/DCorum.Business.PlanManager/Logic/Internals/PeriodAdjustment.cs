﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.Logic.Internals
{
    public enum Period
    {   Monthly = 12
    ,   Quarterly = 4
    ,   BiAnnual = 2
    }

    public class PeriodAdjustment
    {
        private static Period[] _basedOn12 = {Period.Monthly, Period.Quarterly, Period.BiAnnual};

        private int? GetAdjustedMonth(int calendarMonth, Period period )
        {
            if (!_basedOn12.Contains(period)) return null;

            int coeff1 = (12/((int)period));

            int adjustedMonth = ((((calendarMonth - 1)/coeff1)*coeff1) + 1);

            return adjustedMonth;
        }
    }
}
