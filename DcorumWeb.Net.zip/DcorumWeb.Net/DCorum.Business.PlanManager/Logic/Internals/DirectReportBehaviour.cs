﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using DCorum.Business.PlanManager.Contractual;
using Dcorum.Utilities.Extensions;
using DCorum.Business.PlanManager.Entities;
using System.Text.RegularExpressions;

namespace DCorum.Business.PlanManager.Logic.Internals
{
    /// <summary>
    /// [STATELESS]
    /// </summary>
    public class DirectReportBehaviour
    {
        public static readonly DirectReportBehaviour Singleton = new DirectReportBehaviour();

        private DirectReportBehaviour()
        {
        }

        internal static readonly Dictionary<ParamFormat, string> EnumFormatSpecifiers = new Dictionary<ParamFormat, string>()
        {
            {ParamFormat.Year4, "yyyy"},
            {ParamFormat.Year2, "yy"},
            {ParamFormat.Month3, "MMM"},
            {ParamFormat.Month2, "MM"},
            {ParamFormat.Month1, "%M"},
            {ParamFormat.Day4, "dddd"},
            {ParamFormat.Day3, "ddd"},
            {ParamFormat.Day2, "dd"},
            {ParamFormat.Day1, "%d"},
            {ParamFormat.CaseKey, "SCHEME"},
            {ParamFormat.ShortDate, "d"},
            {ParamFormat.DayMonth, "M"}
        };

        internal const ParamFormat SchemeParamId = ParamFormat.CaseKey;


        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]
        private string DeriveFormattedPathname(RptDirectReport model, out int? caseKeyIndex)
        {
            caseKeyIndex = null;

            string toFormat = model.FullLocationTemplate();

            if (toFormat.IndexOf("{") == -1) return toFormat;

            if (model.Formattings == null || model.Formattings.Count <= 0) return null;

            caseKeyIndex = model.Formattings.FirstNullableKeyWhere(@value => @value == SchemeParamId);

            var modifiedParams = model.Formattings.ToDictionary(_ => _.Key, _ => GetFormatFragment(_.Key, _.Value));

            int maxParamIndex = model.Formattings.Max(_ => _.Key);
            int[] indexes = Enumerable.Range(0, maxParamIndex + 1).ToArray();

            object[] replacements =
                indexes.Select(@key => modifiedParams.FirstOrDefault(_ => _.Key == @key).Value).ToArray();

            string result = String.Format(toFormat, replacements);

            return result;
        }

        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]
        public string DeriveActualPathname(RptDirectReport model)
        {
            if (model == null) return null;
            if (model.ExampleDate == null) return null;
            if (model.Formattings.Any(_ => _.Value == null)) return null;

            int? caseKeyIndex;
            string toFormat = DeriveFormattedPathname(model, out caseKeyIndex);

            if (toFormat == null) return null;
            if (toFormat.IndexOf("{") == -1) return toFormat;

            int maxParamIndex = model.Formattings.Max(_ => _.Key);
            int[] indexes = Enumerable.Range(0, maxParamIndex + 1).ToArray();

            object[] replacements =
                indexes.Select(@key => GetParamObject(model, model.Formattings.FirstOrDefault(_ => _.Key == @key).Value))
                    .ToArray();

            string result = String.Format(toFormat, replacements);

            return result;
        }


        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]
        private string GetFormatFragment(int offset, ParamFormat? formatCode)
        {
            if (formatCode == SchemeParamId)
            {
                return "{" + offset + "}";
            }

            return "{" + offset + ":" + IntoFormatSpecifier(formatCode) + "}";
        }

        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]
        private object GetParamObject(RptDirectReport model, ParamFormat? formatting)
        {
            if (formatting == SchemeParamId)
            {
                return model.CaseKey;
            }

            return model.ExampleDate;
        }

        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]  
        public string DeriveReportTypeName(RptDirectReport model)
        {
            var formattings = model.Formattings;
            bool hasDatedParams = formattings.Any(_ => _.Value != null &&  _.Value != SchemeParamId);

            string ext1 = Path.GetExtension(model.FullLocationTemplate()) ?? String.Empty;

            string format1 = null;

            if (ext1.StartsWith(".xls", StringComparison.OrdinalIgnoreCase)) format1 = "EXCEL";
            else if (ext1.Equals(".pdf", StringComparison.OrdinalIgnoreCase)) format1 = "PDF";
            else format1 = "HTML";

            string result = String.Format("RT_D_{0}_{1}", (hasDatedParams) ? "DATED" : "UNDATED", format1);

            return result;
        }

        public static string IntoFormatSpecifier(ParamFormat? specifier)
        {
            if (specifier == null) return null;
            return EnumFormatSpecifiers[specifier.Value];
        }

    }
}
