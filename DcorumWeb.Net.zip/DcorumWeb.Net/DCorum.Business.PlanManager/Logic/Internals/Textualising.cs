﻿using System;
using System.Collections.Generic;
using System.Linq;
using DCorum.Business.PlanManager.Contractual;

namespace DCorum.Business.PlanManager.Logic.Internals
{
    public static class Textualising
    {
        static Textualising()
        {
            FormatKeyedEnums = DirectReportBehaviour.EnumFormatSpecifiers.ToDictionary(_ => _.Value, _ => _.Key);
        }


        private static readonly Dictionary<string, string> FormatKeyedDescriptions = new Dictionary<string, string>()
        {   { "SCHEME", "Use case-key of the selected scheme"}
        ,   { "yyyy", "The year as a four-digit number" }
        ,   { "yy", "The year, from 00 to 99" }
        ,   { "MMMM", "The full name of the month"}
        ,   { "MMM", "The abbreviated name of the month"}
        ,   { "MM", "The month, from 01 through 12"}
        ,   { "%M", "The month, from 1 through 12."}
        ,   { "dddd", "The full name of the day of the week."}
        ,   { "ddd", "The abbreviated name of the day of the week."}
        ,   { "dd", "The day of the month, from 01 through 31."}
        ,   { "%d", "The day of the month, from 1 through 31."}
        ,   { "d", "Short date, e.g. {0}"}
        ,   { "M", "Day/Month, e.g. {0}"}
        } ;

 
        private static readonly Dictionary<string, ParamFormat> FormatKeyedEnums;

        public static Dictionary<int, string> GetFormattedDescriptions()
        {
            var results = DirectReportBehaviour.EnumFormatSpecifiers.ToDictionary(_ => (int)_.Key, _ => GetFormattedDescriptionCore(_.Value));
            return results;
        }


        public static string GetFormattedDescription(ParamFormat specifier)
        {
            return GetFormattedDescriptionCore(DirectReportBehaviour.IntoFormatSpecifier(specifier));
        }


        internal static string GetFormattedDescription(ParamFormat? specifier)
        {
            if (specifier==null) return null;
            return GetFormattedDescriptionCore(DirectReportBehaviour.IntoFormatSpecifier(specifier));
        }

        private static string GetFormattedDescriptionCore(string formattingKey)
        {
            if (String.IsNullOrWhiteSpace(formattingKey)) return null;
            var result = String.Format("[{0}] {1}", formattingKey, String.Format(FormatKeyedDescriptions[formattingKey],DateTime.Now.ToString(formattingKey)));
            return result;
        }

        public static ParamFormat? IntoParamFormat(this string formatSpecifier)
        {
            if (String.IsNullOrWhiteSpace(formatSpecifier)) return null;

            ParamFormat out1;
            bool success = FormatKeyedEnums.TryGetValue(formatSpecifier, out out1);

            if (!success) return null;

            return out1;
        }

    }
}
