﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.Logic.Helping;
using Dcorum.Utilities.Extensions;
using DCorum.Business.PlanManager.Contractual;
using DCorum.Business.PlanManager.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.Business.PlanManager.Logic.Internals;
using DCorum.BusinessFoundation.Auditing;
using DCorum.BusinessFoundation.Contractual;
using DcorumWeb.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.Utilities;

namespace DCorum.Business.PlanManager.Logic
{
    using Outcome = IEnumerable<OutcomeItem>;

    [Category(DomainCodes.DCorumComponentDirectReport)]
    public class BLDirectReport : BLPersistorTemplate<RptDirectReport, int, int>
    {

#region ......creational......
        static BLDirectReport()
        {
            AuditTypeMap.Singleton.TryAdd(typeof(RptDirectReportViaReader), typeof(RptDirectReport));

            AuditTypeMap.Singleton.DeclareIgnorablesFor<RptDirectReport>(
                m => m.ConfigPath, m => m.Help1, m => m.Segment2, m => m.Segment3, m => m.ExampleDate, 
                m => m.ExampleFullPathname, m => m.FileName, m => m.FolderPath,
                m => m.ReportDiscription, m => m.ReportName
                ) ;
        }


        public BLDirectReport(IAuditingArgumentsReadOnly tarnishSource, DLDirectReportCrudActor crudFull)
            : base(tarnishSource,crudFull)
        {
            _crudFull = crudFull;
            MaxAuditDepth = 2;
        }

        private DLDirectReportCrudActor _crudFull;

#endregion

        /// <summary>
        /// [PURE,PROJECTION]
        /// </summary>
        [Pure]
        protected override object AnonymousTableRowFacade(RptDirectReport model)
        {
            object result = new
            {
                _id = model.RptDirectReportId,

                Id_______________ = model.RptDirectReportId,

                Report_Display_Name_______________ = model.ReportDisplayName,

                Case_Key_ = model.CaseKey,

                External = model.IsExternal,

                File_Name______________________________ = model.FileName
            };

            return result;
        }


        protected override void Validate(RptDirectReport model)
        {
            base.Validate(model);

            if (model.Formattings.Count(_ => _.Value == null) > 0)
            {
                RemarksVessel.IncludeCustomRemarks( new string[]{"Only a single parameter can be without formatting (which implies using the scheme instead)!"});
            }     
        }


        public override void Hydrate(RptDirectReport toHydrate)
        {
            //base.Hydrate(toHydrate);   

            bool success = new DirectReportJsonProxy(toHydrate).TryDeserialize();
            toHydrate.ConfigPath = ConfigHelp.Singleton.GetString("DirectReportPath");
        }


        protected override void TarnishModel(RptDirectReport toModify)
        {
            base.TarnishModel(toModify);

            toModify.JSon = new DirectReportJsonProxy(toModify).Serialize();
            toModify.UserId = Caller.UserId ;
            toModify.ConfigPath = ConfigHelp.Singleton.GetString("DirectReportPath");
        }

        public override IEnumerable<IOutcomeItem> Save(RptDirectReport model)
        {
            int[] undefinedParams = model.GetUndefinedParameterIndexes();

            if (undefinedParams.Any())
            {
                return new [] {new OutcomeItem("The path/URL defintion contains undefined parameters!")};
            }
          
            model.ReportName = model.ReportName ?? Guid.NewGuid().ToString();

            model.ReportDisplayName = model.ReportDisplayName ?? ("Direct Report " + Guid.NewGuid()).Truncate(50);
   
            return base.Save(model);
        }

        public Outcome BeginParameterDefinition(RptDirectReport toModify)
        {
            //var remarksVessel = new RemarksVessel();
            //if (toModify == null) remarksVessel.RemarkNoItemSpecified = true;

            int maxParams = 15;

            string toExamine = toModify.FullLocationTemplate();

            var collection1 = toModify.Formattings;
            //collection1.Clear();

            for(var i=0;i<=15;i++)
            {
                if (toExamine.Contains("{" + i + "}"))
                {
                    if (!collection1.ContainsKey(i)) collection1.Add(i,null);
                }
                else
                {
                    collection1.Remove(i);
                }
            }

            toModify.Formattings = collection1.OrderBy(_ => _.Key).IntoDictionary();

            yield break;
        }

        public Outcome DefineParameter(RptDirectReport toModify, int? activeParameterIndex)
        {
            //var remarksVessel = new RemarksVessel();
            //if (toModify == null) remarksVessel.RemarkNoItemSpecified = true;

            var collection1 = toModify.Formattings;

            if (activeParameterIndex.HasValue && collection1.ContainsKey(activeParameterIndex.Value))
            {
                collection1[activeParameterIndex.Value] = toModify.ActiveArgumentFormat;        
            }
            else
            {
                yield return new OutcomeItem("That is not a valid parameter index!");
            }
        }

        /// <summary>
        /// TODO: Need to override to support hard and soft delete
        /// </summary>
        public override IEnumerable<IOutcomeItem> Erase(RptDirectReport toErase)
        {
            if (ReferenceEquals(toErase, null)) RemarksVessel.RemarkNoItemSpecified = true;

            if (IsAnActualId(GetPrimaryId(toErase)))
            {
                _crudFull.SoftDeleteModeOn = (CrudThru.DetectAnyDependants(toErase));
                Delete(toErase);
            }
            else
            {
                RemarksVessel.RemarkInvalidIdentityDetected = true;
            }

            return RemarksVessel.YieldAndPurgeAll();
        }


        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]
        public string GetFormatDescription(int parameterIndex, ParamFormat? formattingKey)
        {
            string desc1 = Textualising.GetFormattedDescription(formattingKey);

            if (desc1 == null) return null;

            string result = String.Format("{0} = {1}", parameterIndex, desc1);

            return result;
        }

        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]
        public string DeriveActualPathname(RptDirectReport model)
        {
            return DirectReportBehaviour.Singleton.DeriveActualPathname(model);
        }

        /// <summary>
        /// [PURE]
        /// </summary>
        [Pure]
        public string DeriveReportTypeName(RptDirectReport model)
        {
            return DirectReportBehaviour.Singleton.DeriveReportTypeName(model);
        }

        protected override Tuple<RefCode, string> GetAuditFriendlyId(RptDirectReport toUse)
        {
            return BaseEntityExtensions.GetAuditFriendlyIdentity(null, toUse.CaseKey, () => GetTextualIdentityOf(toUse));
        }
    }
}
