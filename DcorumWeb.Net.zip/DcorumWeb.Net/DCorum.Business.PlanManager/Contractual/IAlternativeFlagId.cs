﻿using Dcorum.BusinessLayer.BusinesObjects;

namespace DCorum.Business.PlanManager.Contractual
{
    internal interface IAlternativeFlagId
    {
        int ParentId { get; }

        RefCode FlagCode { get; }
    }
}
