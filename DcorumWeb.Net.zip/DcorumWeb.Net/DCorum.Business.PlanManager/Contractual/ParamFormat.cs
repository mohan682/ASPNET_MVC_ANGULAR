﻿using System.ComponentModel;

namespace DCorum.Business.PlanManager.Contractual
{
    public enum ParamFormat
    {
        [Description("yyyy")]//("The year as a four-digit number")]
        Year4,
        [Description("yy")]//("The year, from 00 to 99")]
        Year2,
        [Description("MMM")]//("The abbreviated name of the month")]
        Month3,
        [Description("MM")]//("The month, from 01 through 12")]
        Month2,
        [Description("%M")]//("The month, from 1 through 12.")]
        Month1,
        [Description("dddd")]//("The full name of the day of the week.")]
        Day4,
        [Description("ddd")]//("The abbreviated name of the day of the week.")]
        Day3,
        [Description("dd")]//("The day of the month, from 01 through 31.")]
        Day2,
        [Description("%d")]//("The day of the month, from 1 through 31.")]
        Day1,
        [Description("SCHEME")]//("Use case-key of the selected scheme")]
        CaseKey,
        [Description("d")]
        ShortDate,
        [Description("M")]
        DayMonth
    }
}
