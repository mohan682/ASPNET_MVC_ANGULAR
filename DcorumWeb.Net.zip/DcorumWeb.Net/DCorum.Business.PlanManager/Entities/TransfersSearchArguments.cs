﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DCorum.Business.PlanManager.Entities
{
    public class TransfersSearchArguments
    {
        public TransfersSearchArguments()
        {
        }

        public TransfersSearchArguments(DateTime uptoDate)
        {
            FromDate = uptoDate.AddMonths(-3);
            UptoDate = uptoDate;
        }

        [UIHint("txt*", "search")]
        [Display(Name = "Start")]
        [DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FromDate { get; set; }

        [UIHint("txt*", "search")]
        [Display(Name = "End")]
        [DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? UptoDate { get; set; }
    }
}
