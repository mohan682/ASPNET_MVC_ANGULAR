﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.Entities
{
    public class PtfcCalcResult
    {
        internal protected PtfcCalcResult()
        {

        }

        public decimal? AccountBalance { get; protected set; }

        public decimal? PtfcAmount { get; protected set; }

        public decimal? PtfcPercent { get; protected set; }

        public decimal? PclsAmount{ get; protected set; }

        public decimal? ResidualBalance { get; protected set; }

        internal protected string ErrorMessage { get; set; }
    }


    public class PtfcCalcResult2 : PtfcCalcResult
    {
        internal protected PtfcCalcResult2(IDictionary<string,object> resValues)
        {
            var result = this;
            result.AccountBalance = Convert.ToDecimal(resValues["i_o_account_balance"]);
            result.PtfcAmount = Convert.ToDecimal(resValues["o_ptfc_amt"]);
            result.PtfcPercent = Convert.ToDecimal(resValues["o_ptfc_pct"]);
            result.PclsAmount = Convert.ToDecimal(resValues["o_pcls_amt"]);
            result.ResidualBalance = Convert.ToDecimal(resValues["o_residual_balance"]);
        }
    }

}
