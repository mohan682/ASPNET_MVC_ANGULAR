﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.Business.PlanManager.Contractual;
using DCorum.DataAccessFoundation.Contractual;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics.Contracts;
using System.Runtime.Serialization;

namespace DCorum.Business.PlanManager.Entities
{
    public class TransferFlagDataRow
    {
        [Key]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        public int Id { get; protected internal set; }

        public int ParentId { get; internal set; } //can be set as part of a a husk entity

        [Required]
        [RefCodeConstraint(SpecialDomainNames.TransferFlagKeys)]
        [UiDisplayingHint(UiDisplayMode.Editable, UiDisplayMode.Displayable)]
        public RefCode FlagCode { get; protected set; }

        [Required]
        [UIHint("ddlTicked")]
        [RefCodeConstraint(DomainNames.CompassYesNoValues)]
        public RefCode Ticked { get; protected set; }

        internal static void Build(TransferFlag model, IDataReader reader, string[] columnNames)
        {
            model.Id = reader.FetchAsValue<int>(columnNames[0]);
            model.ParentId = reader.FetchAsValue<int>(columnNames[1]);
            model.FlagCode = reader.FetchTextualRefCode(columnNames[2]);
            model.Ticked = reader.FetchTextualRefCode(columnNames[3]);
        }
    }


    public class TransferFlag : TransferFlagDataRow, IAlternativeFlagId
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public TransferFlag()
        : this(null, null)
        {
        }

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        public TransferFlag(IDataReader reader = null, string[] columnNames = null)
        {
            if (reader == null) return;
            if (columnNames == null) throw new ArgumentNullException("columnNames"); //must hold values when reader is specified.
            Build(this, reader, columnNames);
        }

        /// <summary>
        /// [CONSTRUCTOR] for alternative key only
        /// </summary>
        private TransferFlag(int parentId, string flagKeyRefCd)
        {
            ParentId = parentId;
            FlagCode = new RefCode(flagKeyRefCd);
        }


        [IgnoreDataMember]
        public string FlagIdDescription
        {
            get
            {
                string result = FlagCode.SafeFunc(_ => _.Descript);
                if (result.Trim().EndsWith(":") == false)
                {
                    result = result.Trim() + ":";
                }
                if (FlagCode.Disabled)
                {
                    return result + "*";
                }
                return result;
            }
        }

        [IgnoreDataMember]
        public string FlagIdCode
        {
            get
            {
                return FlagCode.SafeFunc(_ => _.RefCd);
            }
        }

        [IgnoreDataMember]
        public string FlagValueDescription
        {
            get
            {
                return Ticked.SafeFunc(_ => _.Descript);
            }
        }

        //[IgnoreDataMember]
        //public bool CanDelete { get { return Id > 0 && CanPersist; } }

        //[IgnoreDataMember]
        //public bool CanEdit { get { return CanPersist; } }

        //[IgnoreDataMember]
        //public bool CanPersist { get; internal set; }

        /// <summary>
        /// [PROJECTION METHOD|PARSE]
        /// </summary>
        [Pure]
        internal static IAlternativeFlagId ParseId(string compositeCandidate)
        {
            string[] parts1 = compositeCandidate.Split('|');

            if (parts1.Length != 2) return null;

            var built1 = new TransferFlag(parts1[0].IntoIntN().Value, parts1[1]);
            return built1;
        }
    }
}
