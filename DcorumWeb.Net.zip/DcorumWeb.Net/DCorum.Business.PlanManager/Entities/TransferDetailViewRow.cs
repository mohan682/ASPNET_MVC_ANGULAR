﻿using Dcorum.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.Serialization;

namespace DCorum.Business.PlanManager.Entities
{
    public sealed  class TransferDetailDataRow : TransferJunction
    {
        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal TransferDetailDataRow(IDataReader reader)
            : base(reader)
        {
            if (reader != null) Build(this, reader);
        }

        //[UIHint("txt*")]
        //[Display(Name = "Date Received:")]
        //[Editable(false)]
        //[DataType(DataType.Date)]
        public DateTime DateReceived { get; private set; }

        //[UIHint("txt*")]
        //[Display(Name = "Amount (£):")]
        //[Editable(false)]
        public decimal Amount { get; private set; }

        //[UIHint("txt*")]
        //[Display(Name = "Transaction code description:")]
        //[Editable(false)]
        public string TrCodeDesc { get; private set; }


        public int TranDtlTally { get; private set; }
        public int CaseKey { get; private set; }


        private static void Build(TransferDetailDataRow toBuild, IDataReader reader)
        {
            toBuild.DateReceived = reader.FetchAsValue<DateTime>("EFF_DT");
            toBuild.Amount = reader.FetchAsValue<decimal>("AMT");
            toBuild.TrCodeDesc = reader.FetchAsString("TR_CD_DESC");

            toBuild.TranDtlTally = reader.FetchAsValue<int>("TALLY");
            toBuild.CaseKey = reader.FetchAsValue<int>("CASE_KEY");
        }
    }

    /// <summary>
    /// [VIEW_MODEL]
    /// </summary>
    public sealed class TransferDetail
    {
        public TransferDetail( TransferDetailDataRow dataModel, bool canEdit, bool canDelete)
        {
            StrongId = dataModel.StrongId;
            CaseMemberKey = dataModel.CaseMemberKey;
            TransactionCode = dataModel.TransactionCode;
            TransactionRefNumber = dataModel.TransactionRefNumber;
            DateReceived = dataModel.DateReceived;
            Amount = dataModel.Amount;
            TrCodeDesc = dataModel.TrCodeDesc;
            CanEdit = canEdit; //AWS - 7282
            CanDelete = canDelete; //AWS - 7282
        }

        [Key]
        public int? StrongId { get; set; }

        public int CaseMemberKey { get; private set; }
        public string TransactionCode { get; private set; }
        public string TransactionRefNumber { get; private set; }


        [UIHint("txt*")]
        [Display(Name = "Date Received:")]
        [Editable(false)]
        [DataType(DataType.Date)]
        public DateTime DateReceived { get; private set; }

        [UIHint("txt*")]
        [Display(Name = "Amount (£):")]
        [Editable(false)]
        public decimal Amount { get; private set; }

        [UIHint("txt*")]
        [Display(Name = "Transaction code description:")]
        [Editable(false)]
        public string TrCodeDesc { get; private set; }


        // ------derived

        public bool TransferOutModeOn { get { return Amount < 0; } }

        [IgnoreDataMember]
        public bool CanCreateFlags { get { return StrongId == null && CanEdit; } }

        [IgnoreDataMember]
        public bool CanViewOrEdit { get { return StrongId.HasValue; } }


        public bool CanDelete { get; }

        public bool CanEdit { get; }

        
    }

}
