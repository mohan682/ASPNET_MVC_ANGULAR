﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.Serialization;
using DCorum.Business.MessageCentre.Entities;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Practices;
using DCorum.ViewModelling.Annotations;

namespace DCorum.Business.PlanManager.Entities
{
    public class SchemeContactGraph : ExtMiscContact, IAuditingArguments, IAuditingArgumentsReadOnly
    {
        public SchemeContactGraph() : this(null, null)
        {
        }

        public SchemeContactGraph(IDataReader reader, IEnumerable<string> columnNames)
        {
            var columnSet1 = columnNames.Take(6).ToArray();
            var columnSet2 = columnNames.Skip(6).ToArray();

            Build(this, reader, columnSet1);

            ExtMiscContact.Build(this, reader, columnSet2);

            Debug.Assert(MiscContactKey2 == null || MiscContactKey2.Value == MiscContactKey);
        }

        [IgnoreDataMember]
        [UIHint("chkOnlyWithRole","search")]
        [Display(Name="Include unmapped Scheme Contacts :")]
        [SearchWhereNull("j1.msct_key")]
        public bool ShowOnlyContactsWithRole { get; set; }

        [IgnoreDataMember]
        public int? MiscContactKey2 { get; set; }

        [UIHint("litNameId")]
        [Display(Name = "Name Id:")]
        //[Required] does nothing on literal controls
        [ReadOnly(true)]
        public int NameId { get; set; }

        public int? CaseKey { get; set; }

        [IgnoreDataMember]
        public int? MbGpKey { get; set; }

        [IgnoreDataMember]
        public int UserId { get; set; }

        [IgnoreDataMember]
        [RefCodeConstraint("MSCT CONTACT TYP CD")]
        [Required]
        public RefCode ContactType { get; set; }

        [UIHint("litDescription")]
        [Display(Name = "Description:")]
        [Editable(false)]
        public string Description { get { return ContactType.Descript; }}

        [UIHint("litEffectiveFrom")]
        [Display(Name="Effective From:")]
        [Editable(false)]
        [DisplayFormat(DataFormatString = "{0:D}")]
        public DateTime EffectiveDate { get; set; }

        [UIHint("litExpiry")]
        [Display(Name = "Expires:")]
        [Editable(false)]
        [DisplayFormat(DataFormatString = "{0:D}")]
        public DateTime? ExpiryDate { get; set; }

        [IgnoreDataMember]
        private Lazy<Person> _deferredPerson;

        public Person Person { get { return _deferredPerson.Value; }}


        [IgnoreDataMember]
        public bool CanPersist { set; private get; }

        [IgnoreDataMember]
        public bool CanSave { get { return CanPersist; } }

        [IgnoreDataMember]
        public bool CanDelete { get { return CanPersist && MiscContactKey2.HasValue; } }


        internal static void Build(SchemeContactGraph model, IDataReader reader, string[] columnNames)
        {
            if (reader == null) return;

            model.MiscContactKey2 = reader.FetchAsNullable<int>(columnNames[0]);

            model.CaseKey = reader.FetchAsValue<int>(columnNames[1]);

            model.EffectiveDate = reader.FetchAsValue<DateTime>(columnNames[2]);
            model.ExpiryDate = reader.FetchAsNullable<DateTime>(columnNames[3]);

            model.NameId = reader.FetchAsValue<int>(columnNames[4]);

            //model.Description = reader.FetchAsString(columnNames[5]);
            model.ContactType = reader.FetchTextualRefCode(columnNames[5]);
        }


        internal class Editor : IDisposable
        {
            public Editor(SchemeContactGraph toEdit)
            {
                Contract.Assert(toEdit != null);
                _toEdit = toEdit;
            }

            private SchemeContactGraph _toEdit;


            public void SetPerson(Func<int, Person> howToGet)
            {
                _toEdit._deferredPerson = new Lazy<Person>(() => howToGet(_toEdit.NameId));
            }

            public void SetPersonNow(Person toAssign)
            {
                _toEdit._deferredPerson = new Lazy<Person>(() => toAssign);
            }

            public void Dispose()
            {
                _toEdit = null;
            }
        }
    }
}
