﻿using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DCorum.Business.PlanManager.Entities
{
    internal interface IAlternativeTransferId
    {
        int CaseMemberKey { get; }
        string TransactionCode { get; }
        string TransactionRefNumber { get; }

        string IntoIdentityString(string template);
    }


    public class TransferJunction : IAlternativeTransferId
    {
        /// <summary>
        /// [CONSTRUCTOR] Used to facilitate weak alternative key selection
        /// </summary>
        protected TransferJunction(int caseMemberKey, string transactionCode, string transactionRefNumber)
        {
            CaseMemberKey = caseMemberKey;
            TransactionCode = transactionCode;
            TransactionRefNumber = transactionRefNumber;
        }

        [Key]
        public int? StrongId { get; set; }

        public int CaseMemberKey { get; private set; }
        public string TransactionCode { get; private set; }
        public string TransactionRefNumber { get; private set; }

        protected internal TransferJunction(IDataReader reader)
        {
            bool readerSuccess = TryBuild(this, reader);
        }

        internal static IAlternativeTransferId ParseId(string compositeCandidate)
        {
            string[] parts1 = compositeCandidate.Split('|');
            if (parts1.Length != 3) return null;

            var built1 = new TransferJunction(parts1[0].IntoIntN().Value, parts1[1], parts1[2]);
            return built1;
        }

        private static bool TryBuild(TransferJunction toBuild, IDataReader reader)
        {
            if (toBuild == null || reader == null) return false;

            toBuild.StrongId = reader.FetchAsNullable<int>("UEXT_TRANSFER_JUNCTION_ID");
            toBuild.CaseMemberKey = reader.FetchAsValue<int>("CASE_MBR_KEY");
            toBuild.TransactionCode = reader.FetchAsString("TR_CD");
            toBuild.TransactionRefNumber = reader.FetchAsString("Proposed_Ref");

            return true;
        }

        /// <summary>
        /// [PURE]
        /// </summary>
        string IAlternativeTransferId.IntoIdentityString(string template)
        {
            string result = string.Format(template, CaseMemberKey, TransactionCode.SqlQuotify(), TransactionRefNumber.SqlQuotify());
            return result;
        }
    }


    public sealed class TransferJunctionWithChildren : TransferJunction
    {
        [IgnoreDataMember]
        public bool CanPersist { get; internal set; }

        public TransferFlag[] Flags { get; internal set; }

        public TransferJunctionWithChildren()
            :base(null)
        {
        }

        protected internal TransferJunctionWithChildren(IDataReader reader)
            : base(reader)
        {
        }

        /// <summary>
        /// Shell
        /// </summary>
        /// <param name="id"></param>
        internal TransferJunctionWithChildren(IAlternativeTransferId id)
            :base(id.CaseMemberKey, id.TransactionCode, id.TransactionRefNumber)
        {
        }
    }

}
