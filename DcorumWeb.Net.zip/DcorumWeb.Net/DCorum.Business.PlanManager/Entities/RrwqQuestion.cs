﻿using Dcorum.BusinessLayer.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.Entities
{
    /// <summary>
    /// Retirement Risk Warning Question Model (Models RRWQ_QUESTION Table)
    /// </summary>
    public class RrwqQuestion
    {
        /*"UEXT"."RRWQ_QUESTION" 
   	"RRWQ_QUESTION_ID" NUMBER NOT NULL ENABLE, 
	"RRWQ_HEADER_ID" NUMBER NOT NULL ENABLE, 
	"QUESTION_TARGET" VARCHAR2(100) NOT NULL ENABLE, 
	"DESIRED_ANSWER" NUMBER(2,0) NOT NULL ENABLE, 
	"STATEMENT_TARGET" VARCHAR2(100), 
	"DECLARATION_TARGET" VARCHAR2(100), 
	"DISPLAY_ORDER" NUMBER(2,0) NOT NULL ENABLE, 
	"EFF_DT" DATE NOT NULL ENABLE, 
	"XPIR_DT" DATE */
        public RrwqQuestion(int id)
        {
            Id = id;
        }
        

        public int Id { get; private set; }

        public int HeaderId { get; set; }

        public string QuestionTarget { get; set; }

        public int DesiredAnswer { get; set; }

        public string StatementTarget { get; set; }

        public string DeclarationTarget { get; set; }

        public int DisplayOrder { get; set; }

        public DateTime EffectiveDate { get; set; }

        public DateTime? ExpiryDate { get; set; }
    }
}