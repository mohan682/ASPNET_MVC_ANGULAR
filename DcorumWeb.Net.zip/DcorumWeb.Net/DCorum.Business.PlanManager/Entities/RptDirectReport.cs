﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using DCorum.Business.PlanManager.Logic;

using Dcorum.Utilities;
using Dcorum.Utilities.Contractual;
using Dcorum.Utilities.Practices;
using DCorum.Business.PlanManager.Contractual;
using DCorum.ViewModelling.Annotations;
using DcorumWeb.Utilities;
using Dcorum.BusinessCore.Helping;
using System.Collections.ObjectModel;

namespace DCorum.Business.PlanManager.Entities
{
    public class RptDirectReportViaReader :RptDirectReport
    {
        public RptDirectReportViaReader(IDataReader reader, IReadOnlyList<string> columnNames = null )
            :base()
        {
            ConfigPath = ConfigHelp.Singleton.GetString("DirectReportPath");

            columnNames = columnNames ?? ColumnNames ;

            if (reader == null) return ;

            RptDirectReportId = reader.FetchAsValue<int>(columnNames[0]);

            ReportId = reader.FetchAsValue<int>(columnNames[1]);

            CaseKey = reader.FetchAsValue<int>(columnNames[2]);

            IsExternal = reader.FetchBooleanN(columnNames[3]) ?? false;

            FolderPath = reader.FetchAsString(columnNames[4]);

            FileName = reader.FetchAsString(columnNames[5]);

            JSon = reader.FetchAsString(columnNames[6]);

            ReportId = reader.FetchAsValue<int>("Report_Id");
            EffectiveEntityKey = reader.FetchAsValue<int>("REPORT_EFFECTIVE_BASE_Id");
            ReportTypeName = reader.FetchAsString("ReportTypeName");

            ReportDisplayName = reader.FetchAsString("Display_Name");

            ReportName = reader.FetchAsString("ReportName");
        }


        protected static IReadOnlyList<string> ColumnNames { get; } = new ReadOnlyCollection<string>(
            new string[]
            {
                        "RPT_DIRECT_REPORT_ID",
                        "Report_Id",
                        "CASE_KEY",
                        "IS_EXTERNAL",
                        "ABSOLUTE_PATH",
                        "FILENAME",
                        "JSon"
            }
            );

    }


    public class RptDirectReportSearchVm
    {
        [UIHint("txtReportNameId")]
        [Display(Name = "Report Display Name:")]
        [UiSearchable("j2.Display_Name", "LIKE")]
        public string ReportDisplayName { get; set; }

        [UIHint("txtFilenameTemplate")]
        [Display(Name = "Filename Template:")]
        [UiSearchable("FILENAME", "LIKE")]
        public string FileName { get; set; }

        [UIHint("txtCaseKey")]
        [Display(Name = "Case Key:")]
        [UiSearchable("CASE_KEY", "=")]
        public int? CaseKey { get; set; }
    }


    public class RptDirectReport
    {
        public RptDirectReport() { }
       
        [Key]
        [UIHint("txtSchemaId")]
        [Display(Name = "Direct Report ID:")]
        [Editable(false)]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        public int RptDirectReportId { get; set; }

        [UIHint("txtReportId")]
        [Display(Name = "Report ID:")]
        [UiDisplayingHint(UiDisplayMode.Invisible, UiDisplayMode.Displayable)]
        public int ReportId { get; set; }
    
        public string ReportName { get; set; }

        public string ReportDiscription { get; set; }

        [UIHint("txtReportNameId")]
        [Display(Name = "Report Display Name:", Prompt = "Enter a value otherwise a default will be used.")]
        [StringLength(50)]
        public string ReportDisplayName { get; set; }

        [UIHint("txtScheme")]
        [Display(Name = "Scheme:")]
        [AutoExtender("GetSchemeList")]
        [IgnoreDataMember]
        [Required] 
        [ScaffoldColumn(true)]
        public string SchemeDisplayName {
            get
            {
                if (CaseKey == null) return null;
                return CoreInjectedMechanics.IntoSchemeDisplayName(CaseKey);
            }
            set
            {
                if (String.IsNullOrWhiteSpace(value)) CaseKey = null;
                CaseKey = CoreInjectedMechanics.ConvertSchemeDisplayNameToCaseKey(value);
            }
        }

        [UIHint("chkExternal")]
        [Display(Name = "External Flag:", Description = "<i>Tick this item when the the report is a published URL rather than a file served via a PlanManager webserver.</i>")]
        [RefreshProperties(RefreshProperties.Repaint)]
        public bool IsExternal { get; set; }

        [UIHint("litHelp1")]
        [UiBypassXssDefence]
        public string Help1
        {
            get
            {
                return
                    "<i>Enter an example path to either an html/pdf/excel file<br> and replace each variable part with unique number placed inside <strong>{ }</strong> brackets.<i>";
            }
        }

        [UIHint("txtFixedPath")]
        [Display(Name = "Report(s) Origin:")]
        [Required]
        [ReadOnly(true)]
        public string ConfigPath { get; set; }


        private string _folderPath;

        [UIHint("txtPathTemplate")]
        [Display(Name = "Subfolder(s) Template:")]
        public string FolderPath
        {
            get { return _folderPath; }
            set
            {
                var removeablePrefixes = new List<string>()
                {   this.ConfigPath
                ,   @"N:\UKDC2\UKDC\Business Analysis\Pre AEGON transition_220816\Plan Manager\System Testing\Direct Report Samples"
                };

                _folderPath = value;

                if (value == null) return;

                foreach (var removeablePrefix in removeablePrefixes)
                {
                    string remediedPath1 = value.QueryAfterFirstN(removeablePrefix, null);

                    if (remediedPath1 == null) continue;

                    _folderPath = remediedPath1;

                    if (_folderPath.StartsWith(Path.DirectorySeparatorChar.ToString()))
                    {
                        _folderPath = remediedPath1.QueryAfterFirstN(Path.DirectorySeparatorChar.ToString());
                    }
                    break;
                }
            }
        }

        [UIHint("txtFilenameTemplate")]
        [Display(Name = "Filename Template:")]
        [Required]
        public string FileName { get; set; }


        [UIHint("txtFullTemplate")]
        [Display(Name = "Url Template:")]
        [Required]
        public string FullTemplate {
            get
            {
                return this.FullLocationTemplate();
            }
            set
            {
                string filename = Path.GetFileName(value);
                string path = value.QueryBeforeLastN(filename);

                Debug.Assert(Path.Combine(path ?? String.Empty, filename ?? String.Empty).EqualsOIC(value));

                FolderPath = path;
                FileName = filename;
            }
        }



        [UIHint("labSegment2")]
        public string Segment2 {get {return "Parameters/Arguments";}}

        [DataMember]
        [UIHint("rblFormattings")]
        [Display(Name = "Parameter Format(s):", Description = "<i>Select a radio button then assign, your desired format for that selected parameter, from the choices in the drop-down list that appears below.</i>")]
        [RefreshProperties(RefreshProperties.Repaint)]
        public Dictionary<int, ParamFormat?> Formattings { get; set; }

        [UIHint("ddlActiveParameterFormat")]
        [Display(Name = "Active Parameter Format:")]
        [Required]
        [IgnoreDataMember]
        public ParamFormat ActiveArgumentFormat { get; set; }


        [UIHint("txtReportTypeId", "debug")]
        [Display(Name = "Report Type:")]
        [ReadOnly(true)]
        public string ReportTypeName { get; set; }


        [UIHint("labSegment3")]
        public string Segment3 { get { return "Example"; } }

        [UIHint("txtExampleDate")]
        [Display(Name = "Example Date:")]
        [RefreshProperties(RefreshProperties.Repaint)]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ExampleDate { get; set; }

        [UIHint("txtExamplePathname")]
        [Display(Name = "Example Pathname:")]
        [ReadOnly(true)]
        public string ExampleFullPathname { get; set; }


        internal int? CaseKey { get; set; }

        internal string JSon { get; set; }
    
        internal int EffectiveEntityKey { get; set; }
        internal int ReportTypeId { get; set; }

        [IgnoreDataMember]
        [ScaffoldColumn(false)]
        public int UserId { get; set; }
    }

}
