﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;

namespace DCorum.Business.PlanManager.Entities
{
    public class MiscContact
    {
        //nameId
        [Key]
        public int MiscContactKey { get; set; }

        [RefCodeConstraint("MSCT CONTACT TYP CD")]
        [Required]
        public RefCode ContactType { get; set; }

        [RefCodeConstraint("MSCT REF TYP CD")]
        [Required]
        public RefCode RefType { get; set; }

        [StringLength(80)]
        [RefCodeConstraint("MSCT PROF CD")]   
        public RefCode Prof { get; set; }

        [DefaultValue("00")]
        [RefCodeConstraint("MSCT REC STAT CD")]
        [Required]
        public RefCode RecStat { get; set; }

        [StringLength(80)]
        public string Description { get; set; }

        public DateTime EffectiveDate { get; set; }
        public DateTime? ExpiryDate { get; set; }

        public decimal OwnerPct { get; set; }
        public bool IsPrimaryContact { get; set; }
        public int RefKey { get; set; }

        [StringLength(12)]
        public string TrRefNo { get; set; }
        public int? AgyKey { get; set; }
        public int? ReplacmentMiscContactKey { get; set; }

        [StringLength(30)]
        public string LastModifiedBy { get; set; }
        public DateTime LastModifiedDate { get; set; }

        internal static void Build(MiscContact model, IDataReader reader, string[] columnNames)
        {
            throw new NotImplementedException();

            model.MiscContactKey = reader.FetchAsValue<int>(columnNames[0]);
            model.ContactType = reader.FetchTextualRefCode(columnNames[1]);
            model.RefType = reader.FetchTextualRefCode(columnNames[1]);
            model.Prof = reader.FetchTextualRefCode(columnNames[1]);

            model.RecStat = reader.FetchTextualRefCode(columnNames[1]);

            model.Description = reader.FetchAsString(columnNames[6]);

            model.EffectiveDate = reader.FetchAsValue<DateTime>(columnNames[3]);
            model.ExpiryDate = reader.FetchAsNullable<DateTime>(columnNames[3]);
            
            model.OwnerPct = reader.FetchAsValue<Decimal>(columnNames[3]);
            model.IsPrimaryContact = reader.FetchAsValue<Boolean>(columnNames[3]);
            model.RefKey = reader.FetchAsValue<int>(columnNames[3]);


            model.TrRefNo = reader.FetchAsString(columnNames[5]);
            model.AgyKey = reader.FetchAsValue<int>(columnNames[3]);
            model.ReplacmentMiscContactKey = reader.FetchAsValue<int>(columnNames[3]);


            model.LastModifiedBy = reader.FetchAsString(columnNames[6]);
            model.LastModifiedDate = reader.FetchAsValue<DateTime>(columnNames[3]);
        }
    }
}
