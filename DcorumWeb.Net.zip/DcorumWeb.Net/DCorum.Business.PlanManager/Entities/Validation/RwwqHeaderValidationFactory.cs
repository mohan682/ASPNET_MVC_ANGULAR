﻿using DCorum.BusinessFoundation.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.Entities.Validation
{
    public static class RwwqHeaderValidationFactory
    {
        public static class DisplayOrderRange
        {
            public const int Min = 1;
            public const int Max = 99;
        }

        public static IEnumerable<IRule> CreateInsertValidationRules(RrwqHeader model,
            IEnumerable<RrwqHeader> existingModels)
        {
            return new IRule[]
            {
                CreateRequiredFieldsRule(model),
                CreateValidateDisplayOrderWithinRangeRule(model),
                CreateValidateDisplayOrderUniqueRule(model, existingModels)
            };
        }

        public static IEnumerable<IRule> CreateUpdateValidationRules(RrwqHeader model,
            IEnumerable<RrwqHeader> existingModels)
        {
            return new IRule[]
            {
                CreateRequiredFieldsRule(model),
                CreateValidateDisplayOrderWithinRangeRule(model),
                CreateValidateDisplayOrderUniqueRule(model, existingModels)
            };
        }

        public static IRule CreateRequiredFieldsRule(RrwqHeader model)
        {
            return new Rule(
                () =>
                {
                    if (string.IsNullOrEmpty(model.TitleTarget)) throw new ValidationException("Section Heading Title Content Target ID not set");
                    if (string.IsNullOrEmpty(model.TextTarget)) throw new ValidationException("Section Heading Text Content Target ID not set");
                });
        }

        public static IRule CreateValidateDisplayOrderWithinRangeRule(RrwqHeader model)
        {
            return new Rule(
                () =>
                {
                    if (model.DisplayOrder < DisplayOrderRange.Min || model.DisplayOrder > DisplayOrderRange.Max)
                        throw new ValidationException(string.Format("Header order must be between the range of {0} and {1}", DisplayOrderRange.Min, DisplayOrderRange.Max));
                });
        }

        public static IRule CreateValidateDisplayOrderUniqueRule(RrwqHeader model, IEnumerable<RrwqHeader> existingModels)
        {
            return new Rule(
                () =>
                {
                    var existing = existingModels.FirstOrDefault(o => o.DisplayOrder == model.DisplayOrder && o.ContextCode == model.ContextCode && o.Id != model.Id);
                    if (existing != null)
                        throw new ValidationException(string.Format("Header order ({0}) already defined for item '{1}'.", 
                            model.DisplayOrder, existing.TitleTarget));
                });
        }
    }
}
