﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.BusinessLayer.Entities;
using Dcorum.Configuration.Contractual;
using DCorum.BusinessFoundation.Validation;
using System;
using System.Collections.Generic;

namespace DCorum.Business.PlanManager.Entities.Validation
{
    public static class PtfcCalcValidationFactory
    {
        private static ValidationHelp Help1 { get; } = new ValidationHelp();

        public static class MaxTfc5Apr2006Constants
        {
            public const decimal Min = 0;
            public const decimal Max = 9999999999;
            public const int MaxDps = 2;
        }

        public static class TotBenVal5Apr2006Constants
        {
            public const decimal Min = 0;
            public const decimal Max = 9999999999;
            public const int MaxDps = 2;
        }

        public static class ValPrevPartTfrsConstants
        {
            public const decimal Min = 0;
            public const decimal Max = 9999999999;
            public const int MaxDps = 2;
        }

        public static IEnumerable<IRule> CreateUpdateValidationRules(PtfcCalcVariables model,
            PtfcCalcVariables existingModel,
            IDcorumUser user)
        {
            yield return new Rule(() => CreateHasPermissionRule(user, model, existingModel));
            yield return new Rule(() => CreateIsMaxTfc5Apr2006ValueValid(model));
            yield return new Rule(() => CreateIsTotBenVal5Apr2006Valid(model));
            yield return new Rule(() => CreateIsValPrevPartTfrsValid(model));
        }

        public static void CreateHasPermissionRule(IDcorumUser user,
            PtfcCalcVariables updated,
            PtfcCalcVariables existing)
        {
            if (user.IsInGroup(GroupId.RetirementBenefitsEdit)) return;

            if (Help1.HasChanged(existing.MaxTfc5Apr2006, updated.MaxTfc5Apr2006))
                throw new ValidationException("User does not have permissions to update Max Tax Free Cash as at 05/04/2006.");

            if (Help1.HasChanged(existing.TotBenVal5Apr2006, updated.TotBenVal5Apr2006))
                throw new ValidationException("User does not have permissions to update Total Value of Benefits as at 05/04/2006.");

            //if (existing.StandAloneLumpSumFlag == null && updated.StandAloneLumpSumFlag== default(deci))
            if (Help1.HasChanged(existing.StandAloneLumpSumFlag, updated.StandAloneLumpSumFlag))
                throw new ValidationException("User does not have permissions to update Stand Alone Lump Sum flag.");
        }


        public static void CreateIsMaxTfc5Apr2006ValueValid(PtfcCalcVariables model)
        {
            try
            {
                Help1.ValidateValue(model.MaxTfc5Apr2006, MaxTfc5Apr2006Constants.Min, MaxTfc5Apr2006Constants.Max, MaxTfc5Apr2006Constants.MaxDps);
            }
            catch (ValidationException)
            {
                throw new ValidationException(string.Format(
                    "'Max tax free cash as at 05/04/2006' is invalid. Must be within the range of {0}-{1} and a maximum of {2} decimal places.",
                    MaxTfc5Apr2006Constants.Min, MaxTfc5Apr2006Constants.Max, MaxTfc5Apr2006Constants.MaxDps));
            }
        }

        public static void CreateIsTotBenVal5Apr2006Valid(PtfcCalcVariables model)
        {
            try
            {
                Help1.ValidateValue(model.TotBenVal5Apr2006, TotBenVal5Apr2006Constants.Min, TotBenVal5Apr2006Constants.Max, TotBenVal5Apr2006Constants.MaxDps);
            }
            catch (ValidationException)
            {
                throw new ValidationException(string.Format(
                    "'Total benefits value at 05/04/2006' is invalid. Must be within the range of {0}-{1} and a maximum of {2} decimal places.",
                    TotBenVal5Apr2006Constants.Min, TotBenVal5Apr2006Constants.Max, TotBenVal5Apr2006Constants.MaxDps));
            }
        }

        public static void CreateIsValPrevPartTfrsValid(PtfcCalcVariables model)
        {
            try
            {
                Help1.ValidateValue(model.ValPrevPartTfrs, ValPrevPartTfrsConstants.Min, ValPrevPartTfrsConstants.Max, ValPrevPartTfrsConstants.MaxDps);
            }
            catch (ValidationException)
            {
                throw new ValidationException(string.Format(
                    "'Value of previous partial transfers' is invalid. Must be within the range of {0}-{1} and a maximum of {2} decimal places.",
                    ValPrevPartTfrsConstants.Min, ValPrevPartTfrsConstants.Max, ValPrevPartTfrsConstants.MaxDps));
            }
        }

    }



    /// <summary>
    /// [STATELESS]
    /// </summary>
    public class ValidationHelp
    {
        public bool HasChanged<T>(Nullable<T> current, Nullable<T> updated)
            where T : struct
        {
            if (!current.HasValue && !updated.HasValue) return false;
            if (!current.HasValue) return true;
            if (!updated.HasValue) return true;

            return !current.Value.Equals(updated.Value);
        }

        public void ValidateValue(decimal? value, decimal minValue, decimal maxValue, int maxDps)
        {
            if (!value.HasValue) return;

            if (value < minValue || value > maxValue)
                throw new ValidationException(string.Empty);

            var strValue = value.ToString();
            var index = strValue.IndexOf(".");
            if (index < 0) return;

            var numDps = strValue.Length - index - 1;

            if (numDps > maxDps)
                throw new ValidationException(string.Empty);
        }
    }
}
