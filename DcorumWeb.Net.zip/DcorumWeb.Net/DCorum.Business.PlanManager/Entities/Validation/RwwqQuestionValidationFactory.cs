﻿using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.Entities.Validation
{
    public static class RwwqQuestionValidationFactory
    {
        public static class DisplayOrderRange
        {
            public const int Min = 1;
            public const int Max = 99;
        }

        public static IEnumerable<IRule> CreateInsertValidationRules(RrwqQuestion model,
            IEnumerable<RrwqQuestion> existingModels,
            IEnumerable<RrwqHeader> headerModels,
            IEnumerable<int> validReqAnswerRefCodes)
        {
            return new IRule[]
            {
                CreateRequiredFieldsRule(model),
                CreateValidateRequiredAnswerRule(model, validReqAnswerRefCodes),
                CreateValidateHeaderExistsRule(model, headerModels),
                CreateValidateDisplayOrderWithinRangeRule(model),
                CreateValidateDisplayOrderUniqueRule(model, existingModels)
            };
        }

        public static IEnumerable<IRule> CreateUpdateValidationRules(RrwqQuestion model,
            IEnumerable<RrwqQuestion> existingModels,
            IEnumerable<RrwqHeader> headerModels,
            IEnumerable<int> validReqAnswerRefCodes)
        {
            return new IRule[]
            {
                CreateRequiredFieldsRule(model),
                CreateValidateRequiredAnswerRule(model, validReqAnswerRefCodes),
                CreateValidateHeaderExistsRule(model, headerModels),
                CreateValidateDisplayOrderWithinRangeRule(model),
                CreateValidateDisplayOrderUniqueRule(model, existingModels)
            };
        }

        public static IRule CreateRequiredFieldsRule(RrwqQuestion model)
        {
            return new Rule(
                () =>
                {
                    if (string.IsNullOrEmpty(model.QuestionTarget)) throw new ValidationException("Question Text Content Target ID not set");                    
                });
        }

        public static IRule CreateValidateRequiredAnswerRule(RrwqQuestion model, IEnumerable<int> validRefCodes)
        {
            return new Rule(
                () =>
                {
                    if (!validRefCodes.Contains(model.DesiredAnswer)) throw new ValidationException("Required Answer not valid");
                });
        }

        public static IRule CreateValidateDisplayOrderWithinRangeRule(RrwqQuestion model)
        {
            return new Rule(
                () =>
                {
                    if (model.DisplayOrder < DisplayOrderRange.Min || model.DisplayOrder > DisplayOrderRange.Max)
                        throw new ValidationException(string.Format("Display order must be between the range of {0} and {1}", DisplayOrderRange.Min, DisplayOrderRange.Max));
                });
        }

        /// <summary>
        /// Validates that the Display Order is unqiue within the same Header group
        /// </summary>
        /// <param name="model"></param>
        /// <param name="existingModels"></param>
        /// <returns></returns>
        public static IRule CreateValidateDisplayOrderUniqueRule(RrwqQuestion model, IEnumerable<RrwqQuestion> existingModels)
        {
            return new Rule(
                () =>
                {
                    var existing = existingModels.FirstOrDefault(o => o.DisplayOrder == model.DisplayOrder && o.HeaderId == model.HeaderId && o.Id != model.Id);
                    if (existing != null)
                        throw new ValidationException(string.Format("Display order ({0}) already defined for item '{1}'.",
                            model.DisplayOrder, existing.QuestionTarget));
                });
        }

        public static IRule CreateValidateHeaderExistsRule(RrwqQuestion model, IEnumerable<RrwqHeader> headers)
        {
            return new Rule(
                () =>
                {
                    if(headers.FirstOrDefault(o=>o.Id == model.HeaderId) == null) throw new ValidationException("Section Heading Content Target ID is not valid");
                });
        }
    }
}
