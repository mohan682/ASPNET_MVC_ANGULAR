﻿using Dcorum.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCorum.Business.PlanManager.Entities
{
    [Serializable]
    public class IOPortfolio
    {
        [Key]
        public int PortfolioId { get; set; }

        [Required]
        public int ClientId { get; set; }

        [Required]
        public string PortfolioReference { get; set; }

        [Required]
        public string PortfolioName { get; set; }     

        public DateTime EffectiveDate { get; set; }

        public DateTime? ExpiryDate { get; set; }

        public bool IsReadonly { get; set; }

        internal static void Build(IOPortfolio model, IDataReader reader, string[] columnNames)
        {
            model.PortfolioId = reader.FetchAsValue<int>(columnNames[0]);
            model.ClientId = reader.FetchAsValue<int>(columnNames[1]);
            model.PortfolioReference = reader.FetchAsString(columnNames[2]);
            model.PortfolioName = reader.FetchAsString(columnNames[3]);         
            model.EffectiveDate = reader.FetchAsValue<DateTime>(columnNames[4]);
            model.ExpiryDate = reader.FetchAsNullable<DateTime>(columnNames[5]);
        }
    }
}
