﻿using Dcorum.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace DCorum.Business.PlanManager.Entities
{
    public class PtfcCalcVariables
    {
        internal protected PtfcCalcVariables() { }

        [Key]
        public int CaseMbrKey { get; set; }

        public decimal? MaxTfc5Apr2006 { get; set; }

        public decimal? TotBenVal5Apr2006 { get; set; }

        public decimal? ValPrevPartTfrs { get; set; }

        public int? ProtTfcForfeited { get; set; }

        public int? StandAloneLumpSumFlag { get; set; }

        public DateTime? MoneyPurchaseAnnualAllowanceApplies { get; set; }

        //# note: we don't want to modify from the view or audit this value.
        public decimal AccountBalance { get; protected set; }
    }


    public class PtfcCalcVariables2 : PtfcCalcVariables
    {
        internal protected PtfcCalcVariables2(IDataReader reader)
        {
            var model = this;
            /*
             * CASE_MBR_KEY
             * MAX_TFC_5APR2006
             * TOT_BEN_VAL_5APR2006
             * VAL_PREV_PART_TFRS
             * STANDALONE_LS_FLG
             * PROT_TFC_FORFEITED
             * MPAA
             */
            model.CaseMbrKey = reader.FetchAsValue<int>("CASE_MBR_KEY");
            model.MaxTfc5Apr2006 = reader.FetchAsNullable<decimal>("MAX_TFC_5APR2006");
            model.MoneyPurchaseAnnualAllowanceApplies = reader.FetchAsNullable<DateTime>("MPAA");
            model.ProtTfcForfeited = reader.FetchAsNullable<int>("PROT_TFC_FORFEITED");
            model.StandAloneLumpSumFlag = reader.FetchAsNullable<int>("STANDALONE_LS_FLG");
            model.TotBenVal5Apr2006 = reader.FetchAsNullable<decimal>("TOT_BEN_VAL_5APR2006");
            model.ValPrevPartTfrs = reader.FetchAsNullable<decimal>("VAL_PREV_PART_TFRS");
            model.AccountBalance = reader.FetchAsValue<decimal>("ACCOUNT_BALANCE");
        }
    }

}
