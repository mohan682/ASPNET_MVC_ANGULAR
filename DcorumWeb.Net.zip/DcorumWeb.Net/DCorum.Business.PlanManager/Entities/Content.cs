﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.Entities
{
    public class Content
    {
        public Content(int id)
        {
            Id = id;
        }

        public int Id { get; private set; }

        public string Provider { get; set; }

        public int? Product { get; set; }

        public int? Scheme { get; set; }

        public int? MemberGrp { get; set; }

        public string Component { get; set; }

        public string Type { get; set; }

        public string Value { get; set; }

        public DateTime EffectiveDate { get; set; }

        public DateTime? ExpiryDate { get; set; }

        public bool? IsApproved { get; set; }

        public string CreatedUserId { get; set; }

        public string AuthUserId { get; set; }

        public bool? IsPublished { get; set; }

        public string Target { get; set; }

        public int? BaseId { get; set; }

        public string Plan { get; set; }
    }
}
