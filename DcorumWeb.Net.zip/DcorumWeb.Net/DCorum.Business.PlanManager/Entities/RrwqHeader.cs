﻿using Dcorum.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.Entities
{
    /// <summary>
    /// Retirement Risk Warning Question Header Model (Models RRWQ_HEADER Table)
    /// </summary>
    public class RrwqHeader
    {
        public RrwqHeader()
        {
            CurrentModelState = EntityState.Detached ;
        }
        
        protected EntityState CurrentModelState { get; set; }

        public int Id { get; internal protected set; }

        public string TitleTarget { get; set; }

        public string TextTarget { get; set; }

        public int DisplayOrder { get; set; }

        public DateTime EffectiveDate { get; set; }

        public DateTime? ExpiryDate { get; set; }

        public string ContextCode { get; set; }

    }


    public class RrwqHeaderViaReader : RrwqHeader
    {
        public RrwqHeaderViaReader(IDataReader reader)
        :base()
        {
            if (reader != null)
            {
                Build(reader);
                CurrentModelState = EntityState.Unchanged;
            }
        }

        private void Build(IDataReader reader)
        {
            /*
             "RRWQ_HEADER_ID" NUMBER NOT NULL ENABLE, 
            "TITLE_TARGET" VARCHAR2(100) NOT NULL ENABLE, 
            "TEXT_TARGET" VARCHAR2(100), 
            "DISPLAY_ORDER" NUMBER(2,0) NOT NULL ENABLE, 
            "EFF_DT" DATE NOT NULL ENABLE, 
            "XPIR_DT" DATE, 
             */
            Id = reader.FetchAsValue<int>("RRWQ_HEADER_ID");

            TitleTarget = reader.FetchAsString("TITLE_TARGET");
            TextTarget = reader.FetchAsString("TEXT_TARGET");
            DisplayOrder = reader.FetchAsValue<int>("DISPLAY_ORDER");
            EffectiveDate = reader.FetchAsValue<DateTime>("EFF_DT");
            ExpiryDate = reader.FetchAsNullable<DateTime>("XPIR_DT");
            ContextCode = reader.FetchAsString("CONTEXT_CODE");
        }
    }

}
