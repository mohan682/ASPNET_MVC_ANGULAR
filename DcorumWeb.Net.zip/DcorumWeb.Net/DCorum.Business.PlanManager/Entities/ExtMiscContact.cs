﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.Utilities;
using Dcorum.Utilities.Practices;
using DcorumWeb.Utilities;

namespace DCorum.Business.PlanManager.Entities
{
    public class ExtMiscContact
    {
        //[Injected, Config]
        public static string ContentPrefixUrl { get; set; }

        public ExtMiscContact() : this(null, null) { }

        public ExtMiscContact(IDataReader reader, IEnumerable<string> columnNames)
        {        
            Build(this, reader, columnNames.SafeLinq().ToArray());
        }


        [Key]
        [UIHint("txtMsctKey")]
        [Display(Name = "Misc Contact Id:", Order = 10)]
        [Required]
        [ReadOnly(true)]
        public int MiscContactKey { get; set; }

        [UIHint("ddlContactRole")]
        [Display(Name = "Scheme Contact Role:")]
        [Required]
        [RefCodeConstraint("EXTERNAL_SCHEMECONTACT_ROLE")]
        public RefCode ExternalRoleCode { get; set; }

        [UIHint("txtFName")]
        [Display(Name = "First Name:")]
        [ReadOnly(true)]
        [IgnoreDataMember]
        public string FirstName { get; set; }

        [UIHint("txtLName")]
        [Display(Name = "Last Name:")]
        [ReadOnly(true)]
        [IgnoreDataMember]
        public string LastName { get; set; }

        [UIHint("txtImageUrl")]
        [Display(Name = "Image URL:")]
        public string ImageUrl { get; set; }

        [UIHint("txtImage")]
        [Display(Name = "Image:")]
        [DataType(DataType.ImageUrl)]
        public string FullImageUrl
        {
            get
            {
                //note: When ImageUrl starts with a '/' we still want Path.Combine to use both arguments.
                string result = ImageUrl.CombinePathSafely(ContentPrefixUrl, Path.AltDirectorySeparatorChar);

                return result;
            }
        }

        internal static void Build(ExtMiscContact model, IDataReader reader, string[] columnNames)
        {
            if (reader == null) return;
            model.MiscContactKey = reader.FetchAsValue<int>(columnNames[0]);

            model.ExternalRoleCode = reader.FetchTextualRefCode(columnNames[1]);
            model.ImageUrl = reader.FetchAsString(columnNames[2]);
        }
    }
}
