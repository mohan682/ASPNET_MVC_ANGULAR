﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DCorum.Business.PlanManager.Entities
{
    [Serializable]
    public class IOClient
    {
        //nameId
        [Key]
        public int ClientId { get; set; }

        [Required]
        public string ClientReference { get; set; }

        [Required]
        public string ClientName { get; set; }

        public string Address { get; set; }

        public string PhoneNumber { get; set; }

        public string Email { get; set; }

        public DateTime EffectiveDate { get; set; }

        public DateTime? ExpiryDate { get; set; }     

        public string MicrositeCode { get; set; }

        public RefCode[] Microsites { get; set; }

        public bool IsValid { get; set; }

        public bool HasRoles { get; set; }

        public bool IsReadOnly { get; set; }

        [IgnoreDataMember]
        public string DisplayText
        {
            get { return string.Format("[{0}] {1}", ClientReference, ClientName); }
        }

        [IgnoreDataMember]
        public bool Deletable
        {
            get
            {
                bool result = !IsValid && !IsReadOnly && !HasRoles;
                return result;
            }
        }

    }
}
