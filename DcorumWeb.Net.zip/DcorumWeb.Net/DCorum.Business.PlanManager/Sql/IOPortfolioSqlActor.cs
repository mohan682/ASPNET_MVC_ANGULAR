﻿using System;
using System.Collections.Generic;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.DataAccess;

namespace DCorum.Business.PlanManager.Sql
{
    public class IOPortfolioSqlActor : ISqlFullCrud<IOPortfolio, int>
    {
        internal const string SelectSql = @"SELECT IP.* FROM IO_PORTFOLIO IP";

        internal protected IOPortfolioSqlActor() { }

        public IEnumerable<string> DeleteSql(IOPortfolio toDelete)
        {
            yield return $"DELETE FROM IO_PORTFOLIO WHERE PORTFOLIO_ID={toDelete.PortfolioId}";
        }

        public IEnumerable<string> DetectAnyDependants(IOPortfolio ofInterest)
        {
            yield break;
        }

        public string GetSequenceIdForInsert()
        {
            return "IO_PORTFOLIO_ID_SEQ";
        }

        public IEnumerable<string> InsertSql(IOPortfolio toInsert)
        {
           yield return  $@"Insert into IO_PORTFOLIO (PORTFOLIO_ID,CLIENT_ID,PORTFOLIO_REFERENCE,PORTFOLIO_NAME,EFF_DT,EXPIR_DT) 
                            values({toInsert.PortfolioId},{toInsert.ClientId},{toInsert.PortfolioReference.SqlQuotify()},{toInsert.PortfolioName.SqlQuotify()}, {toInsert.EffectiveDate.ToSqlDateTimeString()},{toInsert.ExpiryDate.ToSqlDateTimeString()})";
        }

        public string SelectDuplicatesSql(IOPortfolio similar)
        {
            return $"SELECT * FROM IO_PORTFOLIO WHERE PORTFOLIO_REFERENCE={similar.PortfolioReference.SqlQuotify()} AND CLIENT_ID={similar.ClientId}";
        }

        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            if (string.IsNullOrEmpty(appendWhereClauseWith)) appendWhereClauseWith = "1=1";

            if (parentKey > 0) appendWhereClauseWith += " AND IP.CLIENT_ID = " + parentKey;

            yield return SelectSql + $@" WHERE {appendWhereClauseWith}";
        }

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            yield return $"SELECT * FROM IO_PORTFOLIO WHERE PORTFOLIO_ID={primaryKey}";
        }

        public IEnumerable<string> UpdateSql(IOPortfolio toUpdate)
        {
            yield return $@"Update IO_PORTFOLIO SET EFF_DT= {toUpdate.EffectiveDate.ToSqlDateTimeString()}
                            ,EXPIR_DT= {toUpdate.ExpiryDate.ToSqlDateTimeString()}
                            ,PORTFOLIO_NAME={toUpdate.PortfolioName.SqlQuotify()}
                            ,PORTFOLIO_REFERENCE={toUpdate.PortfolioReference.SqlQuotify()}
                          WHERE  PORTFOLIO_ID={toUpdate.PortfolioId}";
        }
    }
}
