﻿using System;
using System.Collections.Generic;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.DataAccess;
using System.Linq;

namespace DCorum.Business.PlanManager.Sql
{
    public class IOClientSqlActor : ISqlFullCrud<IOClient, int>
    {
        public const string SelectSql1 = @"SELECT
    IC.*,NVL(IO.PORTFOLIO_COUNT,0) PORTFOLIO_COUNT,  NVL(IOR.ROLE_COUNT,0) ROLE_COUNT
FROM IO_CLIENT IC
LEFT JOIN (SELECT CLIENT_ID, COUNT(1) PORTFOLIO_COUNT FROM IO_PORTFOLIO GROUP BY CLIENT_ID ) IO 
    ON IO.CLIENT_ID = IC.CLIENT_ID
LEFT JOIN (SELECT IO_CLIENT_ID, COUNT(1) ROLE_COUNT FROM PDI_IO_CLIENT_PERM_ROLE GROUP BY IO_CLIENT_ID ) IOR 
    ON IOR.IO_CLIENT_ID = IC.CLIENT_ID
";

        /// <summary>
        /// [CONSTRUCTOR]
        /// </summary>
        internal protected IOClientSqlActor() { }


        public IEnumerable<string> DeleteSql(IOClient toDelete)
        {
            yield return $"DELETE FROM IO_CLIENT_MICROSITES WHERE CLIENT_ID={toDelete.ClientId}";

            yield return $"DELETE FROM IO_CLIENT WHERE CLIENT_ID={toDelete.ClientId}";
        }

        public IEnumerable<string> DetectAnyDependants(IOClient ofInterest)
        {
            yield return $@"SELECT IC.*,NVL(IO.PORTFOLIO_COUNT,0) PORTFOLIO_COUNT FROM IO_CLIENT IC
                            LEFT JOIN (SELECT CLIENT_ID, COUNT(1) PORTFOLIO_COUNT FROM IO_PORTFOLIO GROUP BY CLIENT_ID ) IO ON IO.CLIENT_ID = IC.CLIENT_ID 
                            WHERE IC.CLIENT_REFERENCE={ofInterest.ClientReference.SqlQuotify()}";
        }

        public string GetSequenceIdForInsert()
        {
           return "IO_CLIENT_ID_SEQ" ;
        }

        public IEnumerable<string> InsertSql(IOClient toInsert)
        {
            yield return $@"Insert into IO_CLIENT(CLIENT_ID, CLIENT_REFERENCE,CLIENT_NAME, ADDRESS, PHONE_NO, EMAIL, EFF_DT,EXPIR_DT, MICROSITE_CODE)
                        values(IO_CLIENT_ID_SEQ.Nextval, {toInsert.ClientReference.SqlQuotify()}, {toInsert.ClientName.SqlQuotify()},
                        {toInsert.Address.SqlQuotify()},{toInsert.PhoneNumber.SqlQuotify()},{toInsert.Email.SqlQuotify()},
                        {toInsert.EffectiveDate.ToSqlDateTimeString()},{toInsert.ExpiryDate.ToSqlDateTimeString()}, {toInsert.MicrositeCode.SqlQuotify()}) ";

            if (toInsert.Microsites!=null && toInsert.Microsites.Length > 0)
            {
                foreach (var item in toInsert.Microsites)
                {
                    yield return $@"Insert into IO_CLIENT_MICROSITES(IO_CLIENT_MICROSITES_ID,CLIENT_ID,MICROSITE_CODE)
                                values(IO_CLIENT_MICROSITES_ID_SEQ.Nextval,IO_CLIENT_ID_SEQ.CurrVal,{item.RefCd.SqlQuotify()})";
                }
            }
        }


        public string SelectDuplicatesSql(IOClient similar)
        {
            string clause1 = null ;
            string clause2 = null ;

            if (string.IsNullOrEmpty(similar.ClientReference) == false)
            {
                clause1 = $@"IC.CLIENT_REFERENCE={similar.ClientReference.SqlQuotify()}";
            }

            if (string.IsNullOrEmpty(similar.MicrositeCode) == false)
            {
                 clause2 = $@"IC.MICROSITE_CODE={similar.MicrositeCode.SqlQuotify()}";
            }

            string[] clauses = new[] { clause1, clause2 }.Where(_ => string.IsNullOrWhiteSpace(_) == false).ToArray() ;

            if (clauses.Any())
            {
                string orClause = string.Join(" OR ", clauses) ;
                string result = SelectSql1 + "WHERE " + orClause ;
                return result ;
            }

            return null ;
        }


        public IEnumerable<string> SelectManySql(int parentKey = default(int), string appendWhereClauseWith = null)
        {
            if (string.IsNullOrEmpty(appendWhereClauseWith)) appendWhereClauseWith = "1=1";

            if (parentKey>0) appendWhereClauseWith+= " IO.CLIENT_ID = "+ parentKey;         

            yield return SelectSql1 + $@"WHERE {appendWhereClauseWith}" + " ORDER BY LOWER(IC.CLIENT_REFERENCE) asc";
            
        }     

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            yield return SelectSql1 + $@"WHERE IC.CLIENT_ID={primaryKey}";
        }

        public IEnumerable<string> UpdateSql(IOClient toUpdate)
        {
            yield return $@"UPDATE IO_CLIENT SET  CLIENT_REFERENCE={toUpdate.ClientReference.SqlQuotify()}
                                        ,CLIENT_NAME={toUpdate.ClientName.SqlQuotify()}
                                        , ADDRESS={toUpdate.Address.SqlQuotify()}
                                        , PHONE_NO={toUpdate.PhoneNumber.SqlQuotify()}
                                        , EMAIL={toUpdate.Email.SqlQuotify()}
                                        , EFF_DT={toUpdate.EffectiveDate.ToSqlDateTimeString()}
                                        , EXPIR_DT={toUpdate.ExpiryDate.ToSqlDateTimeString()}                                     
                                        , MICROSITE_CODE ={toUpdate.MicrositeCode.SqlQuotify()}
                                                                WHERE CLIENT_ID={toUpdate.ClientId}";

            yield return $"DELETE FROM IO_CLIENT_MICROSITES WHERE CLIENT_ID={toUpdate.ClientId}";

            if (toUpdate.Microsites != null && toUpdate.Microsites.Length > 0)
            {
                foreach (var item in toUpdate.Microsites)
                {
                    yield return $@"Insert into IO_CLIENT_MICROSITES(IO_CLIENT_MICROSITES_ID,CLIENT_ID,MICROSITE_CODE)
                                values(IO_CLIENT_MICROSITES_ID_SEQ.Nextval,{toUpdate.ClientId},{item.RefCd.SqlQuotify()})";
                }
            }
        }

        public string GetMicrosites(IOClient owner)
        {
            return $@"SELECT ICM.* FROM IO_CLIENT_MICROSITES ICM
                INNER JOIN IO_CLIENT IC ON ICM.CLIENT_ID = IC.CLIENT_ID
                WHERE IC.CLIENT_ID={owner.ClientId}";
        }
    }
}
