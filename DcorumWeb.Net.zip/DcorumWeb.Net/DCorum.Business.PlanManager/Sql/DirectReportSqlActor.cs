﻿using System;
using System.Collections.Generic;
using DCorum.Business.PlanManager.Logic;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using System.Collections.ObjectModel;
using System.Linq;

namespace DCorum.Business.PlanManager.Sql
{
    /// <summary>
    /// [CLOSED_TYPE]
    /// </summary>
    public class DirectReportSqlActor : ISqlOpenFullCrud<RptDirectReport, int, int>
    {
        internal protected DirectReportSqlActor()
        {
        }


        public bool SoftDeleteModeOn { get; set; } //mini code smell!

        private const string SelectTemplate1 = @"
                                            SELECT 
                                                from1.*, j1.Report_Id, j2.REPORT_EFFECTIVE_BASE_Id, j2.Display_Name,j2.name as ReportName, j3.name as ReportTypeName 
                                            FROM RPT_DIRECT_REPORT from1 
                                                inner join REPORT j1 on j1.Report_Id = from1.Report_Id
                                                inner join REPORT_EFFECTIVE_BASE j2 on j2.REPORT_EFFECTIVE_BASE_Id = j1.REPORT_EFFECTIVE_BASE_Id
                                                inner join REPORT_TYPE j3 on j3.REPORT_TYPE_id = j1.REPORT_TYPE_Id
                                            ";

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            string result = SelectTemplate1 + "WHERE (j2.XPIR_DT is null or j2.XPIR_DT > SYSDATE) and from1.RPT_DIRECT_REPORT_ID = " + primaryKey;
            yield return result;
        }


        public IEnumerable<string> SelectManySql(int parentKey = 0, string appendWhereClauseWith = null)
        {
            string result = SelectTemplate1 + "WHERE (j2.XPIR_DT is null or j2.XPIR_DT > SYSDATE) " + appendWhereClauseWith;
            yield return result;
        }


        public string SelectDuplicatesSql(RptDirectReport similar)
        {
            string clauseTmp1 = " where j2.Display_Name = {0} and j2.Classification = 3 and j2.PDI_PERMISSION_ROLE_ID = 0 and (j2.XPIR_DT is null or j2.XPIR_DT > SYSDATE)";

            string clause1 = String.Format(clauseTmp1, similar.ReportDisplayName.SqlQuotify());

            string result = SelectTemplate1 + clause1 ;

            return result;
        }


        public IEnumerable<string> DetectAnyDependants(RptDirectReport ofInterest)
        {
            yield return string.Format(@"select REPORT_INSTANCE_ID from REPORT_INSTANCE where Report_Id = {0} ", ofInterest.ReportId);
        }


        public IEnumerable<string> InsertSql(RptDirectReport toInsert)
        {

          // toInsert.ReportName= toInsert.ReportName ?? ("Direct Report " + Guid.NewGuid().ToString()).Truncate(50);

            string template1 = @"INSERT INTO REPORT_EFFECTIVE_BASE
                                (   REPORT_EFFECTIVE_BASE_Id,Name,Display_Name,Descript,PDI_PERMISSION_ROLE_ID, 	
	                                Is_ReadOnly,Classification,Created_By_User_Acc_Id)
                                VALUES
                                ({0},{1},{2},{3},0,0,4,(SELECT ADMIN_USER_ACC_ID FROM USERS WHERE USER_ID={4})) 
                                ";         

            string toYield1 = String.Format(template1, toInsert.EffectiveEntityKey, toInsert.ReportName.SqlQuotify(), toInsert.ReportDisplayName.SqlQuotify(), toInsert.ReportDiscription.SqlQuotify(), toInsert.UserId);

            yield return toYield1;


            string template2 = @"INSERT INTO REPORT
                                        (Report_Id,REPORT_EFFECTIVE_BASE_Id,Report_Type_Id,Default_Scope_Id,Default_Filter_Id)
                                        VALUES ({0},{1},(select report_type_id from report_type where name={2}),1,1) ";
            string toYield2 = String.Format(template2, toInsert.ReportId, toInsert.EffectiveEntityKey, toInsert.ReportTypeName.SqlQuotify());

            yield return toYield2;


            string template3 = @"INSERT INTO RPT_DIRECT_REPORT (   RPT_DIRECT_REPORT_ID,Report_Id, CASE_KEY,IS_EXTERNAL,ABSOLUTE_PATH,FILENAME, JSON)
                                    VALUES({0},{1},{2},{3},{4},{5},{6}) ";
            string toYield3 = String.Format(template3, toInsert.RptDirectReportId, toInsert.ReportId, toInsert.CaseKey, toInsert.IsExternal.IntoSqlBool(), toInsert.FullFolderPathTemplate().SqlQuotify(), toInsert.FileName.SqlQuotify(), toInsert.JSon.SqlQuotify());
            yield return toYield3;
        }


        public IEnumerable<string> UpdateSql(RptDirectReport model)
        {
            string template1 = @"UPDATE REPORT_EFFECTIVE_BASE SET
                                  --  Name = {0},
                                    Display_Name = {1},
                                    Descript = {2} --,  
	                              --  Created_By_User_Acc_Id =(SELECT ADMIN_USER_ACC_ID FROM USERS WHERE USER_ID={3}) 
                                where
                                    REPORT_EFFECTIVE_BASE_Id = {4}";
            //string name = (model.ReportTypeName + model.CaseKey);
            //string description = "Direct Report for " + model.FileName;
            string toYield1 = String.Format(template1, model.ReportName.SqlQuotify(), model.ReportDisplayName.SqlQuotify(), model.ReportDiscription.SqlQuotify(), model.UserId, model.EffectiveEntityKey);

            yield return toYield1;

            string template2 = @"UPDATE REPORT SET
                                    Report_Type_Id = (select report_type_id from report_type where name={0})
                                where    Report_Id = {1}";
            string toYield2 = String.Format(template2, model.ReportTypeName.SqlQuotify(), model.ReportId);

            yield return toYield2;


            string template3 = @"UPDATE RPT_DIRECT_REPORT SET 
                                    CASE_KEY = {0}, IS_EXTERNAL = {1},ABSOLUTE_PATH = {2},FILENAME = {3},JSON = {4}
                                where RPT_DIRECT_REPORT_ID = {5}";
           
            string toYield3 = String.Format(template3, model.CaseKey, model.IsExternal.IntoSqlBool(), model.FullFolderPathTemplate().SqlQuotify(), model.FileName.SqlQuotify(), model.JSon.SqlQuotify(), model.RptDirectReportId);
           
            yield return toYield3;
        }


        public IEnumerable<string> DeleteSql(RptDirectReport model)
        {
            return (SoftDeleteModeOn) ? SoftDeleteSql(model) : HardDeleteSql(model);
        }

        private IEnumerable<string> HardDeleteSql(RptDirectReport model)
        {
            yield return String.Format("delete RPT_DIRECT_REPORT where RPT_DIRECT_REPORT_ID  = {0}", model.RptDirectReportId);
            yield return String.Format("delete REPORT where Report_Id = {0}", model.ReportId);
            yield return String.Format("delete REPORT_EFFECTIVE_BASE where REPORT_EFFECTIVE_BASE_Id = {0}", model.EffectiveEntityKey);
        }

        private IEnumerable<string> SoftDeleteSql(RptDirectReport model)
        {
            //yield return String.Format("update REPORT_INSTANCE set XPIR_DT = sysdate where Report_Id = {0}", model.ReportId);
            yield return String.Format("update REPORT_EFFECTIVE_BASE set XPIR_DT = sysdate where REPORT_EFFECTIVE_BASE_Id = {0}", model.EffectiveEntityKey);
        }

        public string GetSequenceIdForInsert()
        {
            return "RPT_DIRECT_REPORT_ID_SEQ";
        }
    }
}
