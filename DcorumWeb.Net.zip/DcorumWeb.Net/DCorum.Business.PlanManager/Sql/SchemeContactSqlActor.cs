﻿using System;
using System.Collections.Generic;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using Dcorum.Utilities.DataAccess;

namespace DCorum.Business.PlanManager.Sql
{
    public class SchemeContactSqlActor : ISqlFullCrud<SchemeContactGraph,int>
    {
        public static readonly IList<string> ColumnNames = Array.AsReadOnly(new[] { "MSCT_KEY_1", "REF_KEY", "EFF_DT", "XPIR_DT", "NAMEID", "CONTACT_TYP_CD", "MSCT_KEY", "EXTERNAL_ROLE_CD", "IMAGE_URL" });

        private const string TableName = "uext_misc_contacts";

        private const string SelectTemplate1 = @"
SELECT
    from1.* , j1.*, j2.nameid, j1.msct_key as msct_key_1 
FROM misc_contacts from1
    left join uext_misc_contacts j1 on j1.msct_key = from1.MSCT_KEY
    inner join partyxref j2 on j2.refkey = from1.MSCT_KEY and j2.reftype = 'MSCT' 
";

        private const string Clause1 = @"
WHERE 
    from1.msct_key = {0} 
";

        private const string Clause2 = @"
WHERE 
    ref_key = {0} 
";

        private const string Clause3 = @"
WHERE 
    (ref_key = {0} and j1.external_role_cd = {1})
";

        public IEnumerable<string> DetectAnyDependants(SchemeContactGraph ofInterest)
        {
            yield break;
        }


        public IEnumerable<string> DeleteSql(SchemeContactGraph toDelete)
        {
            string template1 = "delete from {0} where msct_key = {1}";
            string sql1 = String.Format(template1, TableName, toDelete.MiscContactKey);
            yield return sql1;
        }

        public IEnumerable<string> InsertSql(SchemeContactGraph toInsert)
        {
            const string sqlTemplate = @"  INSERT INTO {0} (
                                                MSCT_KEY, EXTERNAL_ROLE_CD, IMAGE_URL)  
                                                VALUES ( {1},{2},{3})";

            yield return string.Format(sqlTemplate, TableName, toInsert.MiscContactKey, toInsert.ExternalRoleCode.IntoSqlValue(), toInsert.ImageUrl.SqlQuotify());

        }

        public IEnumerable<string> UpdateSql(SchemeContactGraph toUpdate)
        {
            const string sqlTemplate = @"UPDATE {0} 
    SET EXTERNAL_ROLE_CD={1}
    , IMAGE_URL = {3}
    WHERE MSCT_KEY = {2}
";
            string sql1 = String.Format(sqlTemplate, TableName, toUpdate.ExternalRoleCode.IntoSqlValue(), toUpdate.MiscContactKey, toUpdate.ImageUrl.SqlQuotify());
            yield return sql1;
        }

        public IEnumerable<string> SelectOneSql(int primaryKey)
        {
            string sql1 = String.Format(SelectTemplate1 + Clause1, primaryKey);
            yield return sql1;
        }

        public IEnumerable<string> SelectManySql(int parentKey = 0, string appendWhereClauseWith = null)
        {
            string appendClause = String.IsNullOrWhiteSpace(appendWhereClauseWith) || appendWhereClauseWith.ToLower().Contains(" not ") ? "and j1.msct_key is not null " : "";
            string sql1 = String.Format(SelectTemplate1 + Clause2 + appendClause + "ORDER BY j1.msct_key, NAMEID desc", parentKey);
            yield return sql1;
        }

        public string SelectDuplicatesSql(SchemeContactGraph similar)
        {
            string sql1 = String.Format(SelectTemplate1 + Clause3, similar.CaseKey, similar.ExternalRoleCode.IntoSqlValue());
            return sql1;
        }

        public string GetSequenceIdForInsert()
        {
            return null;
        }
    }
}
