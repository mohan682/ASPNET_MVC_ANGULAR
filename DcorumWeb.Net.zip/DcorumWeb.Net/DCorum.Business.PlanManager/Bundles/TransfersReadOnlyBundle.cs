﻿using Dcorum.BusinessCore.Contractual;
using Dcorum.Configuration.Contractual;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;

namespace DCorum.Business.PlanManager.Bundles
{


    /// <summary>
    /// [STATELESS]
    /// </summary>
    public static class TransfersReadOnlyBundle
    {
        public class BLTransferDetail
        {
            internal BLTransferDetail(IDcorumUser user, DLTransferDetail dataAccess)
            {
                _dataAccess = dataAccess;
                Debug.Assert(_dataAccess != null);

                CanBeModified = user.IsInGroup(GroupId.TVDetailsEditUsers) ;
            }

            public bool CanBeModified { get; }

            private readonly DLTransferDetail _dataAccess;

            public TransferDetail[] GetTransferDetails(int? caseMemberKey, TransfersSearchArguments arguments)
            {
                return _dataAccess.GetTransactionDetails(caseMemberKey, arguments).Select( _ => ProjectToViewModel(_)).ToArray() ;
            }


            public TransferDetail GetTransferDetail(int primaryKey)
            {
                return ProjectToViewModel( _dataAccess.GetStrongModel(primaryKey) );
            }


            internal TransferDetail GetTransferDetail(IAlternativeTransferId id)
            {
                TransferDetail result = ProjectToViewModel( _dataAccess.GetWeakModel(id) );
                return result;
            }

            private TransferDetail ProjectToViewModel(TransferDetailDataRow source)
            {
                bool canModify = CanBeModified ;
                return new TransferDetail(source, canModify, canModify );
            }
        }

        internal class DLTransferDetail
        {
            public DLTransferDetail(TransferDetailSql sqlActor, IDbProxy dbProxy)
            {
                _sqlActor = sqlActor;
                DbProxy = dbProxy;

                if (_sqlActor == null) throw new ArgumentNullException(nameof(sqlActor));
                if (DbProxy == null) throw new ArgumentNullException(nameof(dbProxy));
            }

            private readonly TransferDetailSql _sqlActor;
            private IDbProxy DbProxy { get; }

            public TransferDetailDataRow[] GetTransactionDetails(int? caseMemberKey, TransfersSearchArguments arguments)
            {
                string subClause1 = string.Join(" ", _sqlActor.GetSubClauseSql(arguments));
                var sql = _sqlActor.GetSelectManySql(caseMemberKey, subClause1 );
                var results = DbProxy.GetMany(sql, @CreateModel);
                return results ;
            }

            public TransferDetailDataRow GetStrongModel(int primarKey)
            {
                var sql = _sqlActor.GetStrongSelectOneSql(primarKey);
                var result = DbProxy.GetSingle(sql, @CreateModel);
                return result;
            }

            public TransferDetailDataRow GetWeakModel(IAlternativeTransferId id)
            {
                var sql = _sqlActor.GetWeakSelectOneSql(id);
                var result = DbProxy.GetSingle(sql, @CreateModel);
                return result;
            }

            private TransferDetailDataRow CreateModel(IDataReader reader)
            {
                return new TransferDetailDataRow(reader);
            }
        }

        /// <summary>
        /// [STATELESS]
        /// </summary>
        internal class TransferDetailSql
        {
            private const string sqlSelectTemplate = @"
SELECT 
  f1.EFF_DT, SUM (f1.AMT) AMT, j1.TR_CD_DESC,
  COUNT (f1.AMT) TALLY, f1.CASE_KEY, 
  f1.CASE_MBR_KEY, f1.TR_CD, j4.UEXT_TRANSFER_JUNCTION_ID,
  nvl(j3.tr_ref_no, f1.tr_ref_no) as Proposed_Ref

FROM
  TRANSACT_DETAILS f1
INNER JOIN 
  TR_CODE_RULES j1 on f1.TR_CD = j1.TR_CD 
INNER JOIN
  CONTRIB_USAGE j2 on (f1.CASE_KEY = j2.CASE_KEY AND f1.MNY_TYP_NO = j2.MNY_TYP_NO) 
left join 
  bucket_data j3 
    on f1.scat_key = j3.Swp_Scat_Key
LEFT JOIN 
    UEXT_TRANSFER_JUNCTION j4 
    on j4.CASE_MBR_KEY = f1.CASE_MBR_KEY and j4.TR_CD = f1.TR_CD and j4.Proposed_Ref = nvl(j3.tr_ref_no, f1.tr_ref_no)
inner join 
  fund_desc j5 
  on f1.fd_desc_id = j5.fd_desc_id
WHERE 
 
  {0}
    
GROUP BY
  f1.CASE_MBR_KEY, f1.CASE_KEY,
  j1.TR_CD_DESC, f1.TR_CD, f1.EFF_DT, j4.UEXT_TRANSFER_JUNCTION_ID
  , nvl(j3.tr_ref_no, f1.tr_ref_no)
order by
  f1.case_mbr_key, nvl(j3.tr_ref_no, f1.tr_ref_no), f1.eff_dt desc
";

            private const string sqlWhereTemplate1 = @" 
  f1.STAT_CD = 0 
  AND 
    (
       (j1.tr_typ_cd = '01' and j1.MNY_CAT_NUM = 3) --must not be f1!!!! will return to many row otherwise.
    OR 
      f1.TR_CD IN (3070,3071,3072,3073,3074,3075) 
    )

  AND f1.UNIT_CT <> 0 AND f1.AMT <> 0 and j5.FD_TYP_CD = '0' 
  AND F1.CASE_MBR_KEY {0}
    {1}
";

            private const string sqlWhereTemplate2 = @" 
    f1.CASE_MBR_KEY = {0} and f1.TR_CD = {1} and nvl(j3.tr_ref_no, f1.tr_ref_no) = {2}
";

            private const string sqlWhereTemplate3 = @" 
    j4.UEXT_TRANSFER_JUNCTION_ID = {0}
";

            public IEnumerable<string> GetSubClauseSql(TransfersSearchArguments arguments)
            {
                if (arguments == null || (arguments.FromDate ?? arguments.UptoDate) == null) yield break;

                if (arguments.FromDate.HasValue)
                {
                    yield return string.Format("and F1.EFF_DT >= {0}", arguments.FromDate.Value.ToSqlShortDateString());
                }

                if (arguments.UptoDate.HasValue)
                {
                    yield return string.Format("and F1.EFF_DT <= {0}", arguments.UptoDate.Value.ToSqlShortDateString());
                }
            }


            public string GetSelectManySql(int? caseMemberKey, string subClauseSql1)
            {
                string sqlWhere1 = string.Format(sqlWhereTemplate1, caseMemberKey.ToString().SqlPrefixWithOperator(), subClauseSql1);
                string result = string.Format(sqlSelectTemplate, sqlWhere1);
                return result;
            }

            public string GetStrongSelectOneSql(int primaryKey)
            {
                string sqlWhere1 = string.Format(sqlWhereTemplate3, primaryKey.ToString());
                string result = string.Format(sqlSelectTemplate, sqlWhere1);
                return result;
            }

            public string GetWeakSelectOneSql(IAlternativeTransferId id)
            {
                string sqlWhere1 = id.IntoIdentityString(sqlWhereTemplate2);
                string result = string.Format(sqlSelectTemplate, sqlWhere1);
                return result;
            }
        }

    }
}
