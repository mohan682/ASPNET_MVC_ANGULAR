﻿using Dcorum.BusinessCore.Creational;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.BusinessLayer.DataAccess;
using Dcorum.Utilities.DataAccess;
using Dcorum.Utilities.Extensions;
using Dcorum.Utilities.Practices;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using DCorum.DataAccessFoundation.Extensions;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;

using ModelAlias = DCorum.Business.PlanManager.Entities.TransferJunctionWithChildren;

namespace DCorum.Business.PlanManager.Bundles
{
    public static class TransferJunctionBundle
    {
        [Category(DomainCodes.DCorumTransferFlag)]
        public class Controller : BLPersistorTemplate<ModelAlias, int, int>, IPersistor<ModelAlias>
        {
            internal Controller(IAuditingArgumentsReadOnly caller, CrudActor injectedCrud, Lazy<TransferFlagBundle.Controller> deferredChildrenController)
            : base(caller, injectedCrud)
            {
                _injectedCrud = injectedCrud;
                _deferredChildrenController = deferredChildrenController;
            }

            private readonly CrudActor _injectedCrud;
            private readonly Lazy<TransferFlagBundle.Controller> _deferredChildrenController;

            protected override Tuple<RefCode, string> GetAuditFriendlyId(ModelAlias toUse)
            {
                return Tuple.Create<RefCode, string>(null, toUse.StrongId.ToString());
            }


            public override void Hydrate(ModelAlias toHydrate)
            {
                if (toHydrate == null) return ;

                base.Hydrate(toHydrate); //hydrate ref_codes

                foreach(var current1 in toHydrate?.Flags.SafeLinq())
                {
                    _deferredChildrenController.Value.Hydrate(current1);
                }

                toHydrate.CanPersist = (!ReadOnlyModeOn);
            }


            protected override void Insert(ModelAlias model)
            {
                int strongId = model?.StrongId ?? AmbientValue;

                Debug.Assert(!(model.StrongId > AmbientValue));

                ModelAlias modelBefore = Fetch(strongId);

                Debug.Assert(modelBefore == null);

                int rowsAffected = _injectedCrud.Insert(model);

                Debug.Assert(model.StrongId > AmbientValue);

                ModelAlias modelAfter = Fetch(model.StrongId.Value);

                Audit(rowsAffected, modelBefore, modelAfter);
            }


            protected override void Update(ModelAlias model)
            {
                int strongId = model?.StrongId ?? AmbientValue;

                Debug.Assert(model.StrongId > AmbientValue);

                ModelAlias modelBefore = Fetch(strongId);

                int rowsAffected = _injectedCrud.Update(model);

                ModelAlias modelAfter = Fetch(model.StrongId.Value);

                Audit(rowsAffected, modelBefore, modelAfter);
            }


            protected override void Delete(ModelAlias model)
            {
                int strongId = model?.StrongId ?? AmbientValue;

                Debug.Assert(model.StrongId > AmbientValue);

                model.Flags = _deferredChildrenController.Value.GetMany(strongId).Where(_ => _.Id > 0).SafeLinq().ToArray();
      
                int rowsAffected = _injectedCrud.Delete(model);

                ModelAlias modelAfter = Fetch(strongId);

                Debug.Assert(modelAfter==null);

                Audit(rowsAffected, model, modelAfter);
            }


            public ModelAlias GetUniqueViaTextualId(string uniqueId)
            {
                ModelAlias result = null;
                IAlternativeTransferId planB = null;

                int? primaryKey = uniqueId.IntoIntN();
                if (primaryKey.HasValue)
                {
                    result =  _injectedCrud.SelectViaPrimaryKey(primaryKey.Value);
                    result.Flags = _deferredChildrenController.Value.GetMany(primaryKey.Value);             
                }
                else if ((planB = TransferJunction.ParseId(uniqueId)) != null)
                {
                    result = new ModelAlias(planB);
                    result.Flags = _deferredChildrenController.Value.GetMany(0);
                }
                else throw new ArgumentException(string.Empty, nameof(uniqueId));

                Hydrate(result);

                return result;
            }


            private void Audit(int rowsAffected, ModelAlias modelBefore, ModelAlias modelAfter)
            {
                int strongId = (modelBefore ?? modelAfter).StrongId.Value;

                var auditor = BusinessCoreFactoryMethods.CreateAuditor(Category, Caller.UserId, RemarksVessel, 3, _ => Tuple.Create<RefCode, string>(null, strongId.ToString()));

                bool good = RemarksVessel.RemarkUponRowsAffected(rowsAffected, 0, int.MaxValue);

                auditor.AuditChanges(good, modelAfter, modelBefore, null);
            }


            private ModelAlias Fetch(int strongId)
            {
                ModelAlias fetched1 = GetUnique(strongId);

                fetched1.Flags = _deferredChildrenController.Value.GetMany(strongId).Where(_ => _.Id > 0).SafeLinq().ToArray();

                if (fetched1.Flags.Any() == false && !(fetched1.StrongId > AmbientValue)) fetched1 = null ;

                return fetched1;
            }
        }


        internal class CrudActor : CrudActor<ModelAlias, int, int>
        {
            internal CrudActor(SqlMaker sqlMaker, TransferFlagBundle.SqlMaker flagSqlMaker)
                : base(@reader => new ModelAlias(@reader), sqlMaker)
            {
                _sqlMaker = sqlMaker;
                _flagSqlMaker = flagSqlMaker;
            }

            private readonly SqlMaker _sqlMaker;
            private readonly TransferFlagBundle.SqlMaker _flagSqlMaker;

            public override int Delete(ModelAlias model)
            {
                Debug.Assert(model?.Flags.SafeLinq().Any(_ => _.ParentId != model.StrongId) == false);

                return base.Delete(model);
            }

            protected override void PreInsert( ModelAlias model )
            {
                Debug.Assert(model?.Flags.SafeLinq().Any(_ => _.ParentId != 0) == false);

                base.PreInsert(model); //will assign value to StrongId ;

                Debug.Assert(model.StrongId > 0);

                foreach (var current1 in model?.Flags.SafeLinq())
                {
                    if (current1.ParentId <= 0 && current1.Id <= 0)
                    {
                        Debug.Assert(current1.ParentId == 0 && current1.Id == 0);

                        current1.Id = SequenceGetter.GetNextVal(_flagSqlMaker.GetSequenceIdForInsert());
                    }
                    else
                    {
                       throw new InvalidProgramException();
                    }
                }
            }


            protected override void PreUpdate( ModelAlias model )
            {
                Debug.Assert(model?.Flags.SafeLinq().Any( _ => _.ParentId != model.StrongId)==false);

                Debug.Assert(model.StrongId > 0);

                base.PreUpdate(model); //probably does nothing!

                foreach (var current1 in model?.Flags.SafeLinq())
                {
                    if (current1.ParentId <= 0 && current1.Id <= 0)
                    {
                        Debug.Assert(current1.ParentId == 0 && current1.Id == 0);

                        current1.Id = SequenceGetter.GetNextVal(_flagSqlMaker.GetSequenceIdForInsert());
                    }
                    else if(current1.ParentId > 0 && current1.Id > 0)
                    {
                        //nothing to do!
                    }
                    else
                    {
                        throw new InvalidProgramException();
                    }
                }
            }


            public override int Insert(ModelAlias model)
            {
                return base.Insert(model);
            }

            public override int Update(ModelAlias model)
            {
                return base.Update(model);
            }
        }


        internal class SqlMaker : SimpleSqlFullCrud<ModelAlias, int, int>
        {
            internal SqlMaker(ISqlSpecification<ModelAlias> injectedSqlSpec, TransferFlagBundle.SqlMaker flagSqlMaker)
                : base(injectedSqlSpec, new SimpleSqlCrudTemplateBuilder(injectedSqlSpec))
            {
                //_injectedSqlSpec = injectedSqlSpec;
                _flagSqlMaker = flagSqlMaker;

               // if (_injectedSqlSpec == null) throw new ArgumentNullException(nameof(injectedSqlSpec));
                if (_flagSqlMaker == null) throw new ArgumentNullException(nameof(flagSqlMaker));
            }

            //private readonly ISqlSpecification<ModelAlias> _injectedSqlSpec;
            private readonly TransferFlagBundle.SqlMaker _flagSqlMaker;


            public override IEnumerable<string> DeleteSql(ModelAlias toDelete)
            {
                Debug.Assert(toDelete.Flags.All(_ => _.ParentId > 0));
                Debug.Assert(toDelete.Flags.All(_ => _.Id > 0));

                //var results = toDelete?.Flags.SafeLinq().SelectMany(_ => _flagSqlMaker.DeleteSql(_)).ToList();
                var results =  _flagSqlMaker.GetDeleteManyViaParentIdSql(toDelete.StrongId.Value).ToList();
                results.AddRange(base.DeleteSql(toDelete));
                return results;
            }

            public override IEnumerable<string> InsertSql(ModelAlias toInsert)
            {
                Debug.Assert(toInsert.Flags.All(_ => _.ParentId == 0));
                Debug.Assert(toInsert.Flags.All(_ => _.Id > 0));

                var results = base.InsertSql(toInsert).ToList();

                foreach (var current1 in toInsert.Flags)
                {
                    current1.ParentId = toInsert.StrongId.Value;
                }

                var childInserts = toInsert?.Flags.SafeLinq().Where(_ => !string.IsNullOrWhiteSpace(_.Ticked?.RefCd)).ToArray();

                results.AddRange(childInserts.SelectMany(_ => _flagSqlMaker.InsertSql(_)));
                return results;
            }

            public override IEnumerable<string> UpdateSql(ModelAlias toUpdate)
            {
                Debug.Assert(toUpdate.Flags.All(_ => _.ParentId >= 0));
                Debug.Assert(toUpdate.Flags.All(_ => _.Id > 0));

                var results = new List<string>();
             
                if (SqlSpec.UpdatableIndexes.SafeLinq().Any())
                {
                    results.AddRange(base.UpdateSql(toUpdate));
                }

                //1
                var toRemove = toUpdate?.Flags.SafeLinq().Where(_ => string.IsNullOrWhiteSpace(_.Ticked?.RefCd)).ToArray();
                results.AddRange(toRemove.SelectMany(_ => _flagSqlMaker.DeleteSql(_)).ToList());

                //2
                var others = toUpdate?.Flags.SafeLinq().Where(_ => !string.IsNullOrWhiteSpace(_.Ticked?.RefCd));
                results.AddRange(others.Where( _ => _.ParentId > 0).SelectMany(_ => _flagSqlMaker.UpdateSql(_)).ToList());

                //3
                var toInsert = others.Where(_ => !(_.ParentId > 0)).ToArray();
                foreach (var current1 in toInsert)
                {
                    current1.ParentId = toUpdate.StrongId.Value;
                }
                results.AddRange(toInsert.SelectMany(_ => _flagSqlMaker.InsertSql(_)).ToList());

                return results;
            }
        }


        internal static readonly ISqlSpecification<ModelAlias> SqlSpec =
            new SqlSpecification<ModelAlias>
            {
                TableName = "UEXT_TRANSFER_JUNCTION",
                ColumnNames = new[] { "UEXT_TRANSFER_JUNCTION_ID", "CASE_MBR_KEY", "TR_CD", "Proposed_Ref", "LAST_UPDATED" }.ToArray(),
                
                MyIdentityIndexes = new[] { new[] { 0 }, new[] { 1, 2, 3 } },
                UpdatableIndexes = new int[] {},

                ParentKeyIndex = null,
                SqlSequenceName = "UEXT_TRANSFER_JUNCTION_ID_SEQ",

                GettersForSql = new Func<ModelAlias, object>[]
                {
                    _ => _.StrongId,
                    _ => _.CaseMemberKey,
                    _ => _.TransactionCode.SqlQuotify(),
                    _ => _.TransactionRefNumber.SqlQuotify(),
                    _ => DateTime.UtcNow.ToSqlDateTimeString()
                },
            };
    }
}
