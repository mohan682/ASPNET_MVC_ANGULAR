﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Linq;
using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.BusinessLayer.Constants;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.Core;
using Dcorum.Utilities.DataAccess;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using Dcorum.Utilities.Extensions;
using DCorum.Business.PlanManager.Entities;
using DCorum.Business.PlanManager.Contractual;

using ModelAlias = DCorum.Business.PlanManager.Entities.TransferFlag;


namespace DCorum.Business.PlanManager.Bundles
{
    public static class TransferFlagBundle
    {
        [Category(DomainCodes.DCorumTransferFlag)]
        public class Controller : BLPersistorTemplate<ModelAlias, int,int>, IPersistor<ModelAlias>
        {
            internal Controller(IAuditingArgumentsReadOnly caller, CrudActor injectedCrud  )
            : base(caller, injectedCrud)
            {
                _injectedCrud = injectedCrud;
            }

            private readonly CrudActor _injectedCrud;

            public bool TransferOutModeOn { get; set; }

            protected override Tuple<RefCode, string> GetAuditFriendlyId(ModelAlias toUse)
            {
                return Tuple.Create<RefCode, string>(null, toUse.Id.ToString());
            }


            public override void Hydrate(ModelAlias toHydrate)
            {
                base.Hydrate(toHydrate); //hydrate ref_codes

                //toHydrate.CanPersist = (!ReadOnlyModeOn);
            }


            public override ModelAlias[] GetMany(int parentId = default(int), string augmentQueryWith = null)
            {
                var result = base.GetMany(parentId, augmentQueryWith);

                if (TransferOutModeOn) result = result.Where(_ => _.FlagCode.Disabled == false).ToArray() ;

                return result;
            }


            public ModelAlias GetUniqueViaTextualId(string uniqueId)
            {
                ModelAlias result = null;
                IAlternativeFlagId planB = null;

                int? primaryKey = uniqueId.IntoIntN();
                if (primaryKey.HasValue)
                {
                    result = _injectedCrud.SelectViaPrimaryKey(primaryKey.Value);
                }
                else if ((planB = ModelAlias.ParseId(uniqueId)) != null)
                {
                    result = _injectedCrud.SelectViaOtherIdentity(planB);
                }
                else throw new ArgumentException(string.Empty, nameof(uniqueId));

                Hydrate(result);

                return result;
            }
        }



        internal class CrudActor : CrudActor<ModelAlias, int, int>
        {
            internal CrudActor(SqlMaker sqlMaker)
                : base(@reader => new ModelAlias(@reader, SqlSpec.ColumnNames.ToArray()), sqlMaker )
            {
                _sqlMaker = sqlMaker; 
            }

            private readonly SqlMaker _sqlMaker;

            public ModelAlias SelectViaOtherIdentity(IAlternativeFlagId identity)
            {
                string sql1 = String.Format(
                    CustomSqlCrudTemplates.SelectMissingOneTemplate
                    , SqlSpec.TableName
                    , identity.ParentId
                    , identity.FlagCode.IntoSqlValue()
                    );

                string finalSql1 = new[] {sql1}.IntoWellFormedSql();

                return DataAccessHelp.GetSingle(finalSql1, @Make);
            }

            //public int DeleteSiblingsAndSelf(ModelAlias hasParent)
            //{
            //    string sql = _sqlMaker.GetDeleteManyViaParentIdSql(hasParent.ParentId).IntoWellFormedSql();
            //    int result = DataAccessHelp.SimpleExecuteNonQuery(sql);
            //    return result;
            //}
        }


        internal class SqlMaker : SimpleSqlFullCrud<ModelAlias, int, int>
        {
            internal SqlMaker(ISqlSpecification<ModelAlias> injectedSqlSpec)
                : base(injectedSqlSpec, new SimpleSqlCrudTemplateBuilder(injectedSqlSpec, CustomSqlCrudTemplates.Singleton))
            {
                _injectedSqlSpec = injectedSqlSpec ;
            }

            private readonly ISqlSpecification<ModelAlias> _injectedSqlSpec;

            private const string sqlDeleteTemplate = @"
DELETE
    FROM {0} F1
WHERE 
    F1.UEXT_TRANSFER_JUNCTION_ID = {1}
";
            public IEnumerable<string> GetDeleteManyViaParentIdSql(int parentId)
            {
                string result = string.Format(sqlDeleteTemplate, SqlSpec.TableName,  parentId.ToString());
                yield return result;
            }
        }


        internal class CustomSqlCrudTemplates :SqlCrudTemplates 
        {
            internal static readonly CustomSqlCrudTemplates Singleton = new CustomSqlCrudTemplates();

            private CustomSqlCrudTemplates()
            {
                SimpleSelectManyTemplate = @"
SELECT 
    j1.REF_CD as FLAG_CODE, from1.* 
FROM
    {0} from1
RIGHT JOIN  ref_codes j1 
ON j1.ref_cd = from1.FLAG_CODE and {1}

WHERE domain_name = 'UEXT_TRANS_DTL_FLAGS' --and DISABLE_CD=0

ORDER BY j1.LINE_NO asc
";
            }

            internal const string SelectMissingOneTemplate = @"
SELECT 
    j1.REF_CD as FLAG_CODE, from1.* 
FROM
    {0} from1
RIGHT JOIN  ref_codes j1 
ON j1.ref_cd = from1.FLAG_CODE and UEXT_TRANSFER_JUNCTION_ID = {1}
WHERE 
    domain_name = 'UEXT_TRANS_DTL_FLAGS'
    and REF_CD = {2}
";

        }

        //private readonly static string[] NamesOfColumns = new[] { "UEXT_TRANSACT_DETAILS_FLAGS_ID", "UXTD_KEY", "Flag_Code", "FLAG_Value"  }.ToArray(); 

        internal static readonly ISqlSpecification<ModelAlias> SqlSpec =
            new SqlSpecification<ModelAlias>
            {
                TableName = "UEXT_TRANSFER_FLAGS",
                ColumnNames = new[] { "UEXT_TRANSFER_FLAGS_ID", "UEXT_TRANSFER_JUNCTION_ID", "Flag_Code", "FLAG_Value", "LAST_UPDATED" }.ToArray(),

                MyIdentityIndexes = new[] {new[] {0}, new[] {1, 2}},
                UpdatableIndexes = new int[] {3,4 },

                ParentKeyIndex = 1,
                SqlSequenceName = "UEXT_TRANSFER_FLAGS_ID_SEQ",

                GettersForSql = new Func<ModelAlias, object>[]
                {
                    _ => _.Id,
                    _ => _.ParentId,
                    _ => _.FlagCode.IntoSqlValue(),
                    _ => _.Ticked.IntoSqlValue(),
                    _ => DateTime.UtcNow.ToSqlDateTimeString()
                },
            };
    }
}
