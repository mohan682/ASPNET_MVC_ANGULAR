﻿using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.DataAccess
{
    public interface IContentDal
    {
        IEnumerable<Content> Get(string componentName);
    }

    public class ContentDal : IContentDal
    {
        public IEnumerable<Content> Get(string componentName)
        {
            const string SqlTemplate = @"
SELECT * from UEXT.CONTENT 
WHERE 
    COMPONENT = {0}
    AND (EXPIR_DT IS NULL OR (EXPIR_DT IS NOT NULL AND EXPIR_DT > SYSDATE))";

            return DataAccessHelp.GetMany(string.Format(SqlTemplate, componentName.SqlQuotify()), Create);
        }

        private static Content Create(IDataReader reader)
        {
            /*
             "CONTENT_ID" NUMBER(*,0) NOT NULL ENABLE, 
	        "PROVIDER" VARCHAR2(20), 
	        "PRODUCT" NUMBER(*,0), 
	        "SCHEME" NUMBER(*,0), 
	        "MBR_GRP" NUMBER(*,0), 
	        "COMPONENT" VARCHAR2(50) NOT NULL ENABLE, 
	        "TYPE" VARCHAR2(20) NOT NULL ENABLE, 
	        "VALUE" VARCHAR2(1000), 
	        "EFF_DT" DATE, 
	        "EXPIR_DT" DATE, 
	        "APPROVED" NUMBER(1,0), 
	        "CREATED_USER_ID" VARCHAR2(50), 
	        "AUTH_USER_ID" VARCHAR2(50), 
	        "PUBLISHED" NUMBER(1,0), 
	        "TARGET" VARCHAR2(100) NOT NULL ENABLE, 
	        "BASE_ID" NUMBER(*,0), 
	        "PLAN" VARCHAR2(20)
             */
            var id = reader.FetchAsValue<int>("CONTENT_ID");
            var model = new Content(id);
            model.Provider = reader.FetchAsString("PROVIDER");
            model.Product = reader.FetchAsNullable<int>("PRODUCT");
            model.Scheme = reader.FetchAsNullable<int>("SCHEME");
            model.MemberGrp = reader.FetchAsNullable<int>("MBR_GRP");
            model.Component = reader.FetchAsString("COMPONENT");
            model.Type = reader.FetchAsString("TYPE");
            model.Value = reader.FetchAsString("VALUE");
            model.EffectiveDate = reader.FetchAsValue<DateTime>("EFF_DT");
            model.ExpiryDate = reader.FetchAsNullable<DateTime>("EXPIR_DT");
            model.IsApproved = reader.FetchBooleanN("APPROVED");
            model.CreatedUserId = reader.FetchAsString("CREATED_USER_ID");
            model.AuthUserId = reader.FetchAsString("AUTH_USER_ID");
            model.IsPublished = reader.FetchBooleanN("PUBLISHED");
            model.Target = reader.FetchAsString("TARGET");
            model.BaseId = reader.FetchAsNullable<int>("BASE_ID");
            model.Plan = reader.FetchAsString("PLAN");

            return model;
        }
    }
}
