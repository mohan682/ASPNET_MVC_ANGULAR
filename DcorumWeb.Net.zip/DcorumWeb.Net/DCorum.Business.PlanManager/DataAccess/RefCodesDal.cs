﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.Utilities.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.DataAccess
{
    public interface IRefCodesDal
    {
        IEnumerable<RefCode> Get(string domainName);
    }

    public class RefCodesDal : IRefCodesDal
    {
        #region IRefCodesDal Members

        public IEnumerable<RefCode> Get(string domainName)
        {
            const string SqlTemplate = @"
SELECT * FROM COMPASS.REF_CODES 
WHERE 
    DOMAIN_NAME = {0}";

            return DataAccessHelp.GetMany(string.Format(SqlTemplate, domainName.SqlQuotify()), RefCode.Create);
        }

        #endregion
    }
}
