﻿using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.DataAccessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.DataAccess
{
    public interface IRrwqQuestionDal
    {
        RrwqQuestion Get(int id);

        RrwqQuestion GetForAuditing(int id);

        IEnumerable<RrwqQuestion> GetAll();

        /// <summary> Insert a new record </summary>
        /// <param name="model"></param>
        /// <returns> Returns the Id of the new record </returns>
        int Insert(RrwqQuestion model);

        /// <summary> Updates a record </summary>
        /// <param name="model"></param>
        /// <returns> Returns the Id of the updated record </returns>
        int Update(RrwqQuestion model);

        /// <summary> Delete a record </summary>
        /// <param name="model"></param>
        /// <returns> Returns the Id of the deleted record </returns>
        int Delete(RrwqQuestion model);
    }
    
    public class RrwqQuestionDal : IRrwqQuestionDal
    {
        #region IRrwqQuestionDal Members

        public int Insert(RrwqQuestion model)
        {
            return ExecSqlTransactionally((db, trxn) =>
            {   
                var updateCount = 0;
                using(var cmd = db.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = GetInsertDml(model);
                    cmd.Transaction = trxn;
                    updateCount = cmd.ExecuteNonQuery();
                }

                if (updateCount == 0)
                    throw new Exception("Error adding new record");

                return GetPkCurrVal(db, trxn);
            });
        }

        public int Update(RrwqQuestion model)
        {
            return ExecSqlTransactionally((db, trxn) =>
            {
                var updateCount = 0;
                using (var cmd = db.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = GetDeleteDml(model);
                    cmd.Transaction = trxn;
                    updateCount = cmd.ExecuteNonQuery();
                }

                if (updateCount == 0)
                    throw new Exception("Record does not exist or is expired and can not be updated");

                updateCount = 0;
                using (var cmd = db.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = GetInsertDml(model);
                    cmd.Transaction = trxn;
                    updateCount = cmd.ExecuteNonQuery();
                }

                if (updateCount != 1)
                    throw new Exception("Error updating record");

                return GetPkCurrVal(db, trxn);
            });
        }

        public int Delete(RrwqQuestion model)
        {
            DataAccessHelp.SimpleExecuteNonQuery(GetDeleteDml(model));

            return model.Id;
        }

        public RrwqQuestion Get(int id)
        {
            return DataAccessHelp.GetSingle<RrwqQuestion>(GetSelectDml(id), Create);
        }

        public RrwqQuestion GetForAuditing(int id)
        {
            return DataAccessHelp.GetSingle<RrwqQuestion>($@"SELECT * FROM UEXT.RRWQ_QUESTION WHERE RRWQ_QUESTION_ID = {id}", Create);
        }

        public IEnumerable<RrwqQuestion> GetAll()
        {
            const string Sql = @"SELECT * FROM UEXT.RRWQ_QUESTION
                                WHERE 
                                    (XPIR_DT IS NULL OR XPIR_DT > SYSDATE)
                                ORDER BY DISPLAY_ORDER";

            return DataAccessHelp.GetMany(Sql, Create);
        }

        #endregion

        #region Non Public Methods

        private int GetPkCurrVal(IDbConnection db, IDbTransaction trxn)
        {
            int newRecordId = -1;
            using (var cmd = db.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select RRWQ_QUESTION_ID_SEQ.currval from dual";
                cmd.Transaction = trxn;

                var reader = cmd.ExecuteReader();
                if (!reader.IsClosed)
                {
                    if (reader.Read())
                    {
                        newRecordId = Convert.ToInt32(reader.GetValue(0));
                    }
                }
            }

            return newRecordId;
        }

        private int ExecSqlTransactionally(Func<IDbConnection, IDbTransaction, int> sqlToExecFunc)
        {
            Database db = DatabaseFactory.CreateDatabase("UEXT");
            var cnxn = db.CreateConnection();
            cnxn.Open();

            try
            {
                using (var trxn = cnxn.BeginTransaction(IsolationLevel.Serializable))
                {
                    try
                    {
                        var ret = sqlToExecFunc(cnxn, trxn);

                        trxn.Commit();

                        return ret;
                    }
                    catch (Exception ex)
                    {
                        trxn.Rollback();

                        throw ex;
                    }
                }
            }
            finally
            {
                if (cnxn != null) cnxn.Dispose();
            }
        }
        
        string GetSelectDml(int id)
        {
            return $@"SELECT * FROM UEXT.RRWQ_QUESTION
                    WHERE
                        RRWQ_QUESTION_ID = {id}
                        AND (XPIR_DT IS NULL OR XPIR_DT > SYSDATE)";
        }

        string GetInsertDml(RrwqQuestion model)
        {
            return $@"INSERT INTO UEXT.RRWQ_QUESTION
                    (
                        RRWQ_QUESTION_ID, 
                        RRWQ_HEADER_ID, 
                        QUESTION_TARGET, 
                        DESIRED_ANSWER, 
                        STATEMENT_TARGET, 
                        DECLARATION_TARGET, 
                        DISPLAY_ORDER, 
                        EFF_DT
                    )
                    VALUES
                    (
                        UEXT.RRWQ_QUESTION_ID_SEQ.nextval,
                        {model.HeaderId},
                        {model.QuestionTarget.SqlQuotify()},
                        {model.DesiredAnswer.SqlQuotify()},
                        {model.StatementTarget.SqlQuotify()},
                        {model.DeclarationTarget.SqlQuotify()},
                        {model.DisplayOrder},
                        sysdate
                    )";
        }

        string GetDeleteDml(RrwqQuestion model)
        {
            return $@"UPDATE UEXT.RRWQ_QUESTION
                        SET
                            XPIR_DT = sysdate
                        WHERE
                            RRWQ_QUESTION_ID = {model.Id} AND XPIR_DT IS NULL";
        }

        private static RrwqQuestion Create(IDataReader reader)
        {
            /*
                 "RRWQ_QUESTION_ID" NUMBER NOT NULL ENABLE, 
                 "RRWQ_HEADER_ID" NUMBER NOT NULL ENABLE, 
                 "QUESTION_TARGET" VARCHAR2(100) NOT NULL ENABLE, 
                 "DESIRED_ANSWER" NUMBER(2,0) NOT NULL ENABLE, 
                 "STATEMENT_TARGET" VARCHAR2(100), 
                 "DECLARATION_TARGET" VARCHAR2(100), 
                 "DISPLAY_ORDER" NUMBER(2,0) NOT NULL ENABLE, 
                 "EFF_DT" DATE NOT NULL ENABLE, 
                 "XPIR_DT" DATE 
             */
            var id = reader.FetchAsValue<int>("RRWQ_QUESTION_ID");
            var model = new RrwqQuestion(id);
            model.HeaderId = reader.FetchAsValue<int>("RRWQ_HEADER_ID");
            model.QuestionTarget = reader.FetchAsString("QUESTION_TARGET");
            model.DesiredAnswer = reader.FetchAsValue<int>("DESIRED_ANSWER");
            model.StatementTarget = reader.FetchAsString("STATEMENT_TARGET");
            model.DeclarationTarget = reader.FetchAsString("DECLARATION_TARGET");
            model.DisplayOrder = reader.FetchAsValue<int>("DISPLAY_ORDER");
            model.EffectiveDate = reader.FetchAsValue<DateTime>("EFF_DT");
            model.ExpiryDate = reader.FetchAsNullable<DateTime>("XPIR_DT");

            return model;
        }

        #endregion
    }
}
