﻿using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.DataAccess
{
    public interface IRrwqHeaderDal
    {
        RrwqHeader Get(int id);

        RrwqHeader GetForAuditing(int id);

        IEnumerable<RrwqHeader> GetAll();

        /// <summary> Insert a new record </summary>
        /// <param name="model"></param>
        /// <returns> Returns the Id </returns>
        void Insert(RrwqHeader model);

        void Update(RrwqHeader model);

        void Delete(RrwqHeader model);
    }

    public class RrwqHeaderDal : IRrwqHeaderDal
    {
        internal protected RrwqHeaderDal()
        {
            Create = @reader => new RrwqHeaderViaReader(@reader) ;
        }

        private Func<IDataReader, RrwqHeader> Create { get; }

        public void Insert(RrwqHeader model)
        {
            var sql = $@"INSERT INTO UEXT.RRWQ_HEADER
                        (
                            RRWQ_HEADER_ID, 
                            TITLE_TARGET, 
                            TEXT_TARGET, 
                            DISPLAY_ORDER, 
                            EFF_DT,
                            CONTEXT_CODE
                        )
                        VALUES
                        (
                            UEXT.RRWQ_HEADER_ID_SEQ.nextval,
                            {model.TitleTarget.SqlQuotify()}, 
                            {model.TextTarget.SqlQuotify()}, 
                            {model.DisplayOrder},
                            sysdate,
                            {model.ContextCode.SqlQuotify()}
                        )";



            DataAccessHelp.TryCommitDbTransaction(
                IsolationLevel.Serializable,
                null,
                trxn =>
                {
                    using (var cmd = trxn.Connection.CreateCommand())
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = sql;
                        cmd.Transaction = trxn;
                        int updateCount = cmd.ExecuteNonQuery();

                        if (updateCount == 0)
                            throw new DataException("Error adding new record");

                        return updateCount;
                    };
                },

                trxn =>
                {
                    using (var cmd = trxn.Connection.CreateCommand())
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "select RRWQ_HEADER_ID_SEQ.currval from dual";
                        cmd.Transaction = trxn;

                        var reader = cmd.ExecuteReader();
                        if (!reader.IsClosed)
                        {
                            if (reader.Read())
                            {
                                model.Id = Convert.ToInt32(reader.GetValue(0));
                            }
                        }

                        return 0;
                    };
                }
                
                );

        }

        public void Update(RrwqHeader model)
        {
            var sql = $@"UPDATE UEXT.RRWQ_HEADER 
                        SET 
                            TITLE_TARGET = {model.TitleTarget.SqlQuotify()},
                            TEXT_TARGET = {model.TextTarget.SqlQuotify()},
                            DISPLAY_ORDER = {model.DisplayOrder},
                            XPIR_DT = {model.ExpiryDate.ToSqlDateTimeString()},
                            CONTEXT_CODE =  {model.ContextCode.SqlQuotify()}
                        WHERE 
                            RRWQ_HEADER_ID = {model.Id}";

            DataAccessHelp.SimpleExecuteNonQuery(sql);
        }

        public void Delete(RrwqHeader model)
        {
            var sql = $@"UPDATE UEXT.RRWQ_HEADER 
                        SET 
                            XPIR_DT = sysdate
                        WHERE 
                            RRWQ_HEADER_ID = {model.Id} 
                            AND XPIR_DT IS NULL";

            DataAccessHelp.SimpleExecuteNonQuery(sql);
        }

        public RrwqHeader Get(int id)
        {
            var sql = $@"SELECT * FROM UEXT.RRWQ_HEADER 
                        WHERE 
                            RRWQ_HEADER_ID = {id}
                            AND (XPIR_DT IS NULL OR XPIR_DT > SYSDATE)";

            return DataAccessHelp.GetSingle<RrwqHeader>(sql, Create);
        }

        public RrwqHeader GetForAuditing(int id)
        {
            return DataAccessHelp.GetSingle($@"SELECT * FROM UEXT.RRWQ_HEADER WHERE RRWQ_HEADER_ID = {id}", Create);
        }

        public IEnumerable<RrwqHeader> GetAll()
        {
            const string Sql = @"SELECT * FROM UEXT.RRWQ_HEADER
                                WHERE 
                                    (XPIR_DT IS NULL OR XPIR_DT > SYSDATE)
                                ORDER BY DISPLAY_ORDER";

            return DataAccessHelp.GetMany(Sql, Create);
        }
    }
}
