﻿using Dcorum.BusinessLayer.DataAccess;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.BusinessFoundation.Contractual;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.DataAccess
{
    public interface IIOPortfolioDal
    {
        IOPortfolio Get(int clientId);
        IEnumerable<IOPortfolio> GetAll();

        IEnumerable<IOPortfolio> GetAll(int clientId);
        IEnumerable<IOPortfolio> GetDuplicateReferences(string portfolioReference);
        IEnumerable<IOPortfolio> GetDuplicatePortfolioNames(string portfolioName);

        int Insert(IOPortfolio model);

        int Update(IOPortfolio model);
        int Delete(IOPortfolio model);
    }

    public class IOPortfolioDal : IIOPortfolioDal
    {    
        string[] _columns = new string[] {
            "PORTFOLIO_ID",
            "CLIENT_ID",
            "PORTFOLIO_REFERENCE",
            "PORTFOLIO_NAME",
            "EFF_DT",
            "EXPIR_DT"
        };
        internal protected IOPortfolioDal(ISqlFullCrud<IOPortfolio, int> sqlCrudActor)
        {
            _sqlCrudActor = sqlCrudActor;
        }

        private ISqlFullCrud<IOPortfolio, int> _sqlCrudActor;

        IOPortfolio IIOPortfolioDal.Get(int portfolioId)
        {
           return DBHelper.ExecuteReader(_sqlCrudActor.SelectOneSql(portfolioId).First(), (dr) => Build(dr));
        }

        public IEnumerable<IOPortfolio> GetAll()
        {
            return DBHelper.ExecuteReaderReturnList(_sqlCrudActor.SelectManySql().First(), (dr) => Build(dr));
        }

        public IEnumerable<IOPortfolio> GetDuplicateReferences(string portfolioReference)
        {
            return DBHelper.ExecuteReaderReturnList(_sqlCrudActor.SelectManySql(appendWhereClauseWith: $"LOWER(IP.PORTFOLIO_REFERENCE)=LOWER({portfolioReference.SqlQuotify()}) AND IP.EXPIR_DT IS NULL").First(), (dr) => Build(dr));
        }
        public IEnumerable<IOPortfolio> GetDuplicatePortfolioNames(string portfolioName)
        {
            return DBHelper.ExecuteReaderReturnList(_sqlCrudActor.SelectManySql(appendWhereClauseWith: $"LOWER(IP.PORTFOLIO_NAME)=LOWER({portfolioName.SqlQuotify()}) AND IP.EXPIR_DT IS NULL").First(), (dr) => Build(dr));
        }

        public IEnumerable<IOPortfolio> GetAll(int clientId)
        {
            return DBHelper.ExecuteReaderReturnList(_sqlCrudActor.SelectManySql(clientId).First(), (dr) => Build(dr));
        }

        public int Delete(IOPortfolio model)
        {
            return DBHelper.ExecuteNonQuery(_sqlCrudActor.DeleteSql(model).First());
        }

        public int Insert(IOPortfolio model)
        {
            model.PortfolioId = SequenceGetter.GetNextVal(_sqlCrudActor.GetSequenceIdForInsert());
            return DBHelper.ExecuteNonQuery(_sqlCrudActor.InsertSql(model).First());
        }

        public int Update(IOPortfolio model)
        {
            return DBHelper.ExecuteNonQuery(_sqlCrudActor.UpdateSql(model).First());
        }

        private IOPortfolio Build(IDataReader reader)
        {
            var model = new IOPortfolio();
            model.PortfolioId = reader.FetchAsValue<int>(_columns[0]);
            model.ClientId = reader.FetchAsValue<int>(_columns[1]);
            model.PortfolioReference = reader.FetchAsString(_columns[2]);
            model.PortfolioName = reader.FetchAsString(_columns[3]);
            model.EffectiveDate = reader.FetchAsValue<DateTime>(_columns[4]);
            model.ExpiryDate = reader.FetchAsNullable<DateTime>(_columns[5]);

            return model;
        }
    }
}
