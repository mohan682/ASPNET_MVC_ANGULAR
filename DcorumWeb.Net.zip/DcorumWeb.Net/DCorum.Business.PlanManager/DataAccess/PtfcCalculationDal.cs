﻿using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.DataAccess
{
    public interface IPtfcCalculationDal
    {
        PtfcCalcVariables Get(int caseMbrKey);

        int Update(PtfcCalcVariables model);

        PtfcCalcResult CalculatePtfc(int caseMbrKey);
    }

    public class PtfcCalculationDal : IPtfcCalculationDal
    {
        public PtfcCalcVariables Get(int caseMbrKey)
        {
            var sql = $@"SELECT
                            ucm.CASE_MBR_KEY, 
                            ucm.MAX_TFC_5APR2006, 
                            ucm.TOT_BEN_VAL_5APR2006, 
                            ucm.VAL_PREV_PART_TFRS, 
                            ucm.STANDALONE_LS_FLG, 
                            ucm.PROT_TFC_FORFEITED, 
                            up.MPAA,
                            GET_ACCOUNT_BALANCE(ucm.CASE_MBR_KEY, SYSDATE) AS ACCOUNT_BALANCE
                        FROM
                            UEXT.UEXT_CASE_MEMBERS ucm
                            INNER JOIN V_ACCOUNT va on va.CASE_MBR_KEY = ucm.CASE_MBR_KEY
                            LEFT JOIN UEXT_PERSON up on up.NAMEID = va.NAMEID
                        WHERE
                            ucm.CASE_MBR_KEY = {caseMbrKey}";

            return DataAccessHelp.GetSingle<PtfcCalcVariables>(sql, @reader => new PtfcCalcVariables2(@reader));
        }

        public int Update(PtfcCalcVariables model)
        {
            var sql = $@"DECLARE
                          existingRecords int;
                          userNameId int;
                        BEGIN
                            UPDATE UEXT.UEXT_CASE_MEMBERS ucm
                            SET
                                ucm.MAX_TFC_5APR2006 = {model.MaxTfc5Apr2006.IntoSqlValue()},
                                ucm.TOT_BEN_VAL_5APR2006 = {model.TotBenVal5Apr2006.IntoSqlValue()}, 
                                ucm.VAL_PREV_PART_TFRS = {model.ValPrevPartTfrs.IntoSqlValue()}, 
                                ucm.STANDALONE_LS_FLG = {model.StandAloneLumpSumFlag.IntoSqlValue()}, 
                                ucm.PROT_TFC_FORFEITED = {model.ProtTfcForfeited.IntoSqlValue()}
                            WHERE
                                ucm.CASE_MBR_KEY = {model.CaseMbrKey};

                            SELECT NAMEID into userNameId from V_ACCOUNT where CASE_MBR_KEY = {model.CaseMbrKey};
                            SELECT COUNT(*) into existingRecords from UEXT_PERSON where NAMEID = userNameId;
  
                            if(existingRecords > 0) THEN 
                                UPDATE UEXT_PERSON 
                                SET
                                    MPAA = {model.MoneyPurchaseAnnualAllowanceApplies.ToSqlShortDateString()}
                                WHERE 
                                    NAMEID = userNameId;
                            ELSE
                                INSERT INTO UEXT_PERSON(NAMEID,MPAA) 
                                VALUES
                                (
                                    userNameId,
                                    {model.MoneyPurchaseAnnualAllowanceApplies.ToSqlShortDateString()}
                                );
                            END IF;
                        END;";

            return DataAccessHelp.SimpleExecuteNonQuery(sql);
        }

        public PtfcCalcResult CalculatePtfc(int caseMbrKey)
        {
            const string Sproc = "UEXT.CALCULATE_PTFC";

            var result = new PtfcCalcResult();
            
            try
            {
                var resValues = DBHelper.ExecuteSPReaderNoResultset(Sproc, YieldPtfcCalcParams(caseMbrKey).ToList() );

                result = new PtfcCalcResult2(resValues);
            }
            catch(Exception ex)
            {
                // NB. Exception can be thrown when account balance is zero
                // RAISE_APPLICATION_ERROR(-20000,'These calculations cannot be carried out due to the account balance of the member being zero.');
                if (ex.Message.StartsWith("ORA-20000:"))
                    result.ErrorMessage = ex.Message.Substring(11,ex.Message.IndexOf("\n")-11);
                else
                    result.ErrorMessage = ex.Message.Replace("\n", "<br>");
            }

            return result;
        }

        private IEnumerable<DbParam> YieldPtfcCalcParams(int caseMbrKey)
        {     
            yield return new DbParam() { Name = "i_case_mbr_key", Type = DbType.Int32, Value = caseMbrKey, Direction = ParameterDirection.Input } ;
            yield return new DbParam() { Name = "i_o_account_balance", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.InputOutput };
            yield return new DbParam() { Name = "i_tfc_pct_selected", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.Input };
            yield return new DbParam() { Name = "i_pot_type", Type = DbType.String, Value = DBNull.Value, Direction = ParameterDirection.Input };

            yield return new DbParam() { Name = "o_ptfc_amt", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.Output, Size = 10 };
            yield return new DbParam() { Name = "o_ptfc_pct", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.Output, Size = 10 };
            yield return new DbParam() { Name = "o_pcls_amt", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.Output, Size = 10 };
            yield return new DbParam() { Name = "o_residual_balance", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.Output, Size = 10 };
            yield return new DbParam() { Name = "o_tax_free_amt", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.Output, Size = 10 };
            yield return new DbParam() { Name = "o_taxable_amt", Type = DbType.Decimal, Value = DBNull.Value, Direction = ParameterDirection.Output, Size = 10 };
        }

    }
}
