﻿using Dcorum.BusinessLayer.Contractual;
using DCorum.Business.MessageCentre.Creational;
using DCorum.Business.MessageCentre.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.Business.PlanManager.Sql;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;

namespace DCorum.Business.PlanManager.DataAccess
{
    public class DLSchemeContactCrudActor : CrudActor<SchemeContactGraph, int, int>, ICrudFull<SchemeContactGraph>
    {
        public DLSchemeContactCrudActor(ISqlOpenFullCrud<SchemeContactGraph, int, int> sqlCrudActor) 
            : base(@reader => new SchemeContactGraph(@reader, SchemeContactSqlActor.ColumnNames), sqlCrudActor) 
        { }


        //protected override void PreInsert(SchemeContactGraph model, Database db)
        //{
        //    Debug.Assert(model.MiscContactKey==null);
        //    model.MiscContactKey = model.MiscContactKey2;
        //}


        public override SchemeContactGraph SelectViaPrimaryKey(int primaryId)
        {
            var creation1 = base.SelectViaPrimaryKey(primaryId);

            if (creation1 == null) return creation1;

            using (var editor1 = new SchemeContactGraph.Editor(creation1))
            {
                SchemeContactGraph current2 = creation1;
                editor1.SetPersonNow( MessageCentreFactory.Singleton.NewPersonDataAccess().SelectViaPrimaryKey(current2.NameId));
            }

            return creation1;
        }


        public override SchemeContactGraph[] SelectManyViaParentKey(int parentId, string appendWhereClauseWith = null)
        {
            var creations = base.SelectManyViaParentKey(parentId, appendWhereClauseWith);

            foreach (var current1 in creations)
            {
                SchemeContactGraph current2 = current1;
                using (var editor1 = new SchemeContactGraph.Editor(current2))
                {
                    editor1.SetPersonNow(MessageCentreFactory.Singleton.NewPersonDataAccess().SelectViaPrimaryKey(current2.NameId));
                }
            }

            return creations;
        }

    }
}
