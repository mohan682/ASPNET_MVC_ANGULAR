﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Dcorum.Utilities.Practices;
using DCorum.Business.PlanManager.Contractual;
using DCorum.Business.PlanManager.Entities;

namespace DCorum.Business.PlanManager.DataAccess
{
    [DataContract]
    internal class DirectReportJsonProxy
    {
        /// <summary>
        /// [Constructor]
        /// </summary>
        public DirectReportJsonProxy(RptDirectReport toFacade)
        {
            if (toFacade == null) throw new ArgumentNullException();
            _toFacade1 = toFacade;
        }

        [IgnoreDataMember]
        private RptDirectReport _toFacade1;

        [DataMember]
        public Dictionary<int, ParamFormat?> Formattings { get; set; }


        public string Serialize()
        {
            if (_toFacade1.Formattings == null) return null;

            Formattings = _toFacade1.Formattings;

            string json = Serializing.JsonSerialize(this);
            return json;
        }

        public bool TryDeserialize()
        {
            if (String.IsNullOrWhiteSpace(_toFacade1.JSon)) return false;
            var toProject1 = Serializing.JsonDeserialize<DirectReportJsonProxy>(_toFacade1.JSon);

            if (toProject1 != null)
            {
                _toFacade1.Formattings = toProject1.Formattings;
            }

            return toProject1 != null;
        }
    }
}
