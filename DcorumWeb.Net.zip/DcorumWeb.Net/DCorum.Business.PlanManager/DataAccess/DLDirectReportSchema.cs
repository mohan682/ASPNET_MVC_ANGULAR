﻿using System.Diagnostics;
using Dcorum.BusinessLayer.Contractual;
using Dcorum.BusinessLayer.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.Business.PlanManager.Sql;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Data;

namespace DCorum.Business.PlanManager.DataAccess
{
    public class DLDirectReportCrudActor : CrudActor<RptDirectReport, int, int>
    {
        public DLDirectReportCrudActor(DirectReportSqlActor sqlCrudActor, Func<IDataReader, RptDirectReport> howToCreate )
            : base( @howToCreate, sqlCrudActor)
        {
            _sqlCrudActor = sqlCrudActor;
        }

        private DirectReportSqlActor _sqlCrudActor;


        public bool SoftDeleteModeOn
        {
            set
            {
                _sqlCrudActor.SoftDeleteModeOn = value;
            }
        }


        protected override void PreInsert(RptDirectReport model)
        {
            base.PreInsert(model);
            model.EffectiveEntityKey = SequenceGetter.GetNextVal("REPORT_EFFECTIVE_BASE_ID_SEQ");
            model.ReportId = SequenceGetter.GetNextVal("REPORT_ID_SEQ");

            Debug.Assert(model.RptDirectReportId > 0);
            Debug.Assert(model.EffectiveEntityKey > 0);
            Debug.Assert(model.ReportId > 0);
        }
    }
}
