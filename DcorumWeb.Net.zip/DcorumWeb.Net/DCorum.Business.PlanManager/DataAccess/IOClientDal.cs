﻿using Dcorum.BusinessLayer.BusinesObjects;
using Dcorum.Utilities;
using Dcorum.Utilities.DataAccess;
using DCorum.Business.PlanManager.Entities;
using DCorum.Business.PlanManager.Sql;
using DCorum.BusinessFoundation.Contractual;
using DCorum.DataAccessFoundation.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DCorum.Business.PlanManager.DataAccess
{
    public interface IIOClientDal
    {
        IOClient Get(int clientId);

        IOClient Get(string reference);

        IEnumerable<IOClient> GetAll();

        IEnumerable<IOClient> GetClientRef(int clientId, string clientReference);

        IEnumerable<IOClient> GetClientRef(string clientReference);

        int Insert(IOClient model);

        int Update(IOClient model);

        int Delete(IOClient model);

        IOClient[] SelectDuplicates(IOClient model);

        RefCode[] GetMicrosites(IOClient model);
    }

    public class IOClientDal : IIOClientDal
    {
        string[] _columns = new string[] {
            "CLIENT_ID",
            "CLIENT_REFERENCE",
            "CLIENT_NAME",
            "ADDRESS",
            "PHONE_NO",
            "EMAIL",
            "EFF_DT",
            "EXPIR_DT",          
            "MICROSITE_CODE",
            "PORTFOLIO_COUNT",
            "ROLE_COUNT"
        };

        internal protected IOClientDal(IOClientSqlActor sqlCrudActor)
        {
            _sqlCrudActor = sqlCrudActor;
            if (_sqlCrudActor == null) throw new ArgumentNullException(nameof(sqlCrudActor)) ;
        }

        protected IDbProxy DbProxy { get; } = new DataAccessContext();


        private IOClientSqlActor _sqlCrudActor;

        public IOClient Get(int clientId)
        {
            return DBHelper.ExecuteReader(_sqlCrudActor.SelectOneSql(clientId).First(), (dr) => Build(dr));
        }

        public IOClient Get(string clientReference)
        {
            return DBHelper.ExecuteReader(_sqlCrudActor.SelectManySql(appendWhereClauseWith: $"IC.CLIENT_REFERENCE={clientReference.SqlQuotify()}" ).First(), (dr) => Build(dr));
        }

        public IEnumerable<IOClient> GetAll()
        {
            var results = new List<IOClient>() ;
            string sql1 = _sqlCrudActor.SelectManySql().First() ;
            DBHelper.ExecuteReader(sql1, (dr) => results.Add(Build(dr)));
            return results;
        }

        public IEnumerable<IOClient> GetClientRef(int clientId, string clientReference)
        {
            string sql1 = _sqlCrudActor.SelectManySql(appendWhereClauseWith: $"LOWER(IC.CLIENT_REFERENCE)={clientReference.SqlQuotify()} AND IC.CLIENT_ID <> {clientId.SqlQuotify()}").First() ;
            return DBHelper.ExecuteReaderReturnList( sql1, (dr) => Build(dr));
        }
   
        public IEnumerable<IOClient> GetClientRef(string clientReference)
        {
            string sql1 = _sqlCrudActor.SelectManySql(appendWhereClauseWith: $"LOWER(IC.CLIENT_REFERENCE)={clientReference.SqlQuotify()}").First() ;
            return DBHelper.ExecuteReaderReturnList(sql1, (dr) => Build(dr));
        }

        public int Delete(IOClient model)
        {
            return DBHelper.ExecuteNonQuery(DataAccessHelp.Layout(_sqlCrudActor.DeleteSql(model)));
        }

        public int Insert(IOClient model)
        {
            return DBHelper.ExecuteNonQuery(DataAccessHelp.Layout(_sqlCrudActor.InsertSql(model)));
        }

        public int Update(IOClient model)
        {
            return DBHelper.ExecuteNonQuery(DataAccessHelp.Layout(_sqlCrudActor.UpdateSql(model)));
        }


        /// <summary>
        /// Returns an empty arry by default.
        /// </summary>
        public virtual IOClient[] SelectDuplicates(IOClient model)
        {
            string sql1 = _sqlCrudActor.SelectDuplicatesSql(model);

            if (string.IsNullOrWhiteSpace(sql1)) return new IOClient[] { };

            return DbProxy.GetMany(sql1, @Build);
        }


        public RefCode[] GetMicrosites(IOClient model)
        {
            var result = new List<RefCode>();

            DBHelper.ExecuteReader(_sqlCrudActor.GetMicrosites(model), (dr) =>
            {
                result.Add(new RefCode(DBHelper.GetIDataReaderString(dr, "MICROSITE_CODE")));
            });

            return result.ToArray();
        }

        private IOClient Build(IDataReader reader)
        {
            var model = new IOClient();
            model.ClientId = reader.FetchAsValue<int>(_columns[0]);
            model.ClientReference = reader.FetchAsString(_columns[1]);
            model.ClientName = reader.FetchAsString(_columns[2]);
            model.Address = reader.FetchAsString(_columns[3]);
            model.PhoneNumber = reader.FetchAsString(_columns[4]);
            model.Email = reader.FetchAsString(_columns[5]);
            model.EffectiveDate = reader.FetchAsValue<DateTime>(_columns[6]);
            model.ExpiryDate = reader.FetchAsNullable<DateTime>(_columns[7]);         
            model.MicrositeCode = reader.FetchAsString(_columns[8]);
            model.IsValid = reader.FetchAsValue<int>(_columns[9]) > 0;
            model.HasRoles = reader.FetchAsValue<int>(_columns[10]) > 0;

            return model;
        }
    }
}
