﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Bullseye.UI.DTO;

namespace Bullseye.UI.Controllers
{
    public class SettingsController : ApiController
    {
        public SettingDTO GetSettings()
        {
            var settings = new SettingDTO
            {
                WebApiBaseUrl = ConfigurationManager.AppSettings["WebApiBaseUrl"],
                SignalRBaseUrl = ConfigurationManager.AppSettings["SignalRBaseUrl"],
                Environment = ConfigurationManager.AppSettings["DisplayEnvironment"]
            };

            return settings;
        }
    }
}
