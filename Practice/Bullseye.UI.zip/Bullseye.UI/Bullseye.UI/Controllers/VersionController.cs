﻿using Bullseye.UI.DTO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;

namespace Bullseye.UI.Controllers
{
    public class VersionController : ApiController
    {        
        public SystemVersionDTO GetSettings()
        {
            var assemblyName = new AssemblyName(Assembly.GetExecutingAssembly().FullName);
            FileInfo fileInfo = new FileInfo(Assembly.GetExecutingAssembly().Location);
            return new SystemVersionDTO { Version = assemblyName.Version.ToString(), LastUpdated = fileInfo.LastWriteTime };            
        }
    }
}