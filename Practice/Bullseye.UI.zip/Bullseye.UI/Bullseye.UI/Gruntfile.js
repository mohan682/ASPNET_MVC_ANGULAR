/*global module:false*/
module.exports = function (grunt) {

    // Project configuration.
    grunt.initConfig({
        // Metadata.
        pkg: grunt.file.readJSON('package.json'),
        banner: '/*! <%= pkg.title || pkg.name %> - v<%= pkg.version %> - ' +
            '<%= grunt.template.today("yyyy-mm-dd") %>\n' +
            '<%= pkg.homepage ? "* " + pkg.homepage + "\\n" : "" %>' +
            '* Copyright (c) <%= grunt.template.today("yyyy") %> <%= pkg.author.name %>;' +
            ' Licensed <%= _.pluck(pkg.licenses, "type").join(", ") %> */\n',
        bowercopy: {
            options: {
                // Bower components folder will be removed afterwards 
                clean: false                
            },
            bower: {
                options: {
                    destPrefix: 'components'
                },
                files: {
                    'angular/angular.js': 'angular/angular.js',
                    'angular-animate/angular-animate.js': 'angular-animate/angular-animate.js',
                    'angular-aria/angular-aria.js': 'angular-aria/angular-aria.js',
                    'angular-bootstrap/ui-bootstrap-tpls.js': 'angular-bootstrap/ui-bootstrap-tpls.js',
                    'angular-busy/angular-busy.js': 'angular-busy/dist/angular-busy.js',
                    'angular-busy/angular-busy.css': 'angular-busy/dist/angular-busy.css',
                    'angular-cookies/angular-cookies.js': 'angular-cookies/angular-cookies.js',
                    'angular-material/angular-material.js': 'angular-material/angular-material.js',
                    'angular-material/angular-material.css': 'angular-material/angular-material.css',
                    'angular-mocks/angular-mocks.js': 'angular-mocks/angular-mocks.js',
                    'angular-resource/angular-resource.js': 'angular-resource/angular-resource.js',
                    'angular-route/angular-route.js': 'angular-route/angular-route.js',
                    'angular-sanitize/angular-sanitize.js': 'angular-sanitize/angular-sanitize.js',
                    'angular-touch/angular-touch.js': 'angular-touch/angular-touch.js',                    
                    'angular-ui-grid/ui-grid.css': 'angular-ui-grid/ui-grid.css',
                    'angular-ui-grid/ui-grid.eot': 'angular-ui-grid/ui-grid.eot',
                    'angular-ui-grid/ui-grid.js': 'angular-ui-grid/ui-grid.js',
                    'angular-ui-grid/ui-grid.svg': 'angular-ui-grid/ui-grid.svg',
                    'angular-ui-grid/ui-grid.ttf': 'angular-ui-grid/ui-grid.ttf',
                    'angular-ui-grid/ui-grid.woff': 'angular-ui-grid/ui-grid.woff',
                    'angular-messages/angular-messages.js': 'angular-messages/angular-messages.js',
                    'bootstrap/js/bootstrap.js': 'bootstrap/dist/js/bootstrap.js',
                    'bootstrap/css/bootstrap.css': 'bootstrap/dist/css/bootstrap.css',
                    'bootstrap/fonts/glyphicons-halflings-regular.eot': 'bootstrap/fonts/glyphicons-halflings-regular.eot',
                    'bootstrap/fonts/glyphicons-halflings-regular.svg': 'bootstrap/fonts/glyphicons-halflings-regular.svg',
                    'bootstrap/fonts/glyphicons-halflings-regular.ttf': 'bootstrap/fonts/glyphicons-halflings-regular.ttf',
                    'bootstrap/fonts/glyphicons-halflings-regular.woff': 'bootstrap/fonts/glyphicons-halflings-regular.woff',
                    'bootstrap/fonts/glyphicons-halflings-regular.woff2': 'bootstrap/fonts/glyphicons-halflings-regular.woff2',
                    'bootstrap-treeview/bootstrap-treeview.min.js': 'bootstrap-treeview/dist/bootstrap-treeview.min.js',
                    'bootstrap-treeview/bootstrap-treeview.min.css': 'bootstrap-treeview/dist/bootstrap-treeview.min.css',
                    'ngSticky/sticky.min.js': 'ngSticky/dist/sticky.min.js',
					'angular-multi-select-tree/dist/angular-multi-select-tree-0.1.0.js':'angular-multi-select-tree/dist/angular-multi-select-tree-0.1.0.js',
					'angular-multi-select-tree/dist/angular-multi-select-tree-0.1.0.tpl.js':'angular-multi-select-tree/dist/angular-multi-select-tree-0.1.0.tpl.js',
					'angular-multi-select-tree/dist/angular-multi-select-tree-0.1.0.css':'angular-multi-select-tree/dist/angular-multi-select-tree-0.1.0.css',
					'angular-ivh-treeview/dist/ivh-treeview.js':'angular-ivh-treeview/dist/ivh-treeview.js',
					'angular-ivh-treeview/dist/ivh-treeview.css':'angular-ivh-treeview/dist/ivh-treeview.css',
					'angular-ivh-treeview/dist/ivh-treeview-theme-basic.css':'angular-ivh-treeview/dist/ivh-treeview-theme-basic.css',
					'jquery/jquery.js': 'jquery/dist/jquery.js'					
                }
            },
            libs: {
                options: {
                    destPrefix: 'components',
                    srcPrefix: 'Scripts'
                },
                files: {                    
                    'signalr/jquery.signalR-2.2.0.min.js': 'jquery.signalR-2.2.0.min.js'
                }
            }
        },
        connect: {
            server: {
                options: {
                    keepalive: true,
                    open: true,
                    port: 8001,
                    index: 'index.html'
                }
            }
        }
    });

    // These plugins provide necessary tasks.    
    grunt.loadNpmTasks('grunt-bowercopy');
    grunt.loadNpmTasks('grunt-contrib-connect');

    // Default task.
    grunt.registerTask('default', ['bowercopy']);

    grunt.registerTask('serve', ['connect']);

};
