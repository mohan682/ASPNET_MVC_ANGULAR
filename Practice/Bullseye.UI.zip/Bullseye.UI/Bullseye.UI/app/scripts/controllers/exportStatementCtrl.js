﻿angular.module('bullseyeApp').controller('exportStatementCtrl', ['$rootScope', '$scope', '$mdDialog', 'exportOptions', 'downloadDirectoryDataFactory',
    function ($rootScope, $scope, $mdDialog, exportOptions, downloadDirectoryDataFactory) {
        $scope.exportDirectories = [];
        $scope.exportOptions = exportOptions;
        $scope.selectedPathName = '';

        $scope.message = "Please Wait...";
        //Assuming 1 is the export type
        //$rootScope.promise = downloadDirectoryDataFactory.getDownloadDirectoryListByDownloadTypeId(1)
        //    .then(function (response) {
        //        $scope.exportDirectories = response.data;
        //        if ($scope.exportDirectories.length === 1) {
        //            $scope.selectedExportDirectory = $scope.exportDirectories[0];
        //            $scope.export();
        //        }
        //    });

        $scope.export = function () {
            $mdDialog.hide($scope.selectedExportOption);
        }

        //$scope.ok = function () {
        //    //TODO: Send request to export
        //    $mdDialog.hide($scope.selectedPathName);
        //};

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);