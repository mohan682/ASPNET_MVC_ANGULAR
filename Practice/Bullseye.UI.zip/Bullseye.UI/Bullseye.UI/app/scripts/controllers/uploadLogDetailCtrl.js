﻿angular.module('bullseyeApp').controller('uploadLogDetailCtrl', ['$scope', '$mdDialog', 'recordLogDetails',
    function ($scope, $mdDialog, recordLogDetails) {
        $scope.logfileName = '';
        $scope.status = '';
        $scope.sourcefileName = '';

        if (recordLogDetails && recordLogDetails.length > 0) {
            $scope.logfileName = recordLogDetails[0].LogfileName;
            $scope.status = recordLogDetails[0].Status;
            $scope.uploadType = recordLogDetails[0].SourceType;
            $scope.sourcefileName = recordLogDetails[0].SourceFileName;
        }        
        $scope.uploadLogDetails = recordLogDetails;

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);