﻿angular.module('bullseyeApp').controller('saveAsNewVersionConfirmationCtrl', ['$scope', '$mdDialog',
    function ($scope, $mdDialog) {
                
        $scope.saveAsNewVersion = function () {
            $mdDialog.hide(true);
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);