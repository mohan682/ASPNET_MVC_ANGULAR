﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:FinancialStatementCtrl
 * @description
 * # FinancialStatementCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('summaryFinancialsCtrl', ['$scope', '$rootScope', '$q', '$location', '$routeParams', '$mdDialog', '$mdSidenav', '$mdUtil', '$interval',
      'hierarchySetService', 'summaryFinancialsDataFactory',
      function ($scope, $rootScope, $q, $location, $routeParams, $mdDialog, $mdSidenav, $mdUtil, $interval
         , hierarchySetService, summaryFinancialsDataFactory
        ) {

          $scope.showSummaryTable = false;         

          $scope.showQ1MontlyColumns = false;

          $scope.showQ2MontlyColumns = false;

          $scope.showQ3MontlyColumns = false;

          $scope.showQ4MontlyColumns = false;       


          $scope.showMontlyValues = function (quarterNumber) {
              if (quarterNumber === 1) $scope.showQ1MontlyColumns = !$scope.showQ1MontlyColumns;
              if (quarterNumber === 2) $scope.showQ2MontlyColumns = !$scope.showQ2MontlyColumns;
              if (quarterNumber === 3) $scope.showQ3MontlyColumns = !$scope.showQ3MontlyColumns;
              if (quarterNumber === 4) $scope.showQ4MontlyColumns = !$scope.showQ4MontlyColumns;
          };

          $scope.$on('isRBHierarchyLoaded', function () {
            $scope.rbSingleSelectableTree1 = hierarchySetService.getMultiSelectableTree($scope.rbHierarchy);
          });          
        
         $scope.selectOnlyN = function (item, selectedItems, count) {
              if (selectedItems != null && selectedItems.length >= count) {
                  return false;
              } else {
                  return true;
              }
          };

          $scope.getFormattedValue = function (IsKPINode, value) {

              if (isNaN(value) || !angular.isNumber(value)) return '';

              if (IsKPINode) {
                  if (value < 0)
                      return '(' + Math.round(Math.abs(value * 100)).toLocaleString() + ')' + '%';
                  else
                      return Math.round(Math.abs(value * 100)).toLocaleString() + '%';
              } else {

                  if (value < 0)
                      return '(' + Math.round(Math.abs(value)).toLocaleString() + ')';
                  else
                      return Math.round(Math.abs(value)).toLocaleString();
              }

          };

          $scope.GetFinancialSummary = function (selectedNode) {
              if (selectedNode != null && selectedNode[0] != null) {
                  // alert($scope.currentRecord.Id, selectedNode[0].id);
                  $rootScope.promise = summaryFinancialsDataFactory
                    .getFinancialInformation($scope.currentRecord.Id, selectedNode[0].id)
                    .then(function (response) {

                        $scope.showSummaryTable = response.data.length > 0;
                        $scope.summaryFinancialRecords = response.data;
                    });

              } else {
                  $scope.showSummaryTable = false;
                  $scope.summaryFinancialRecords = null;
              }
          };

      }]);