﻿angular.module('bullseyeApp').controller('defaultToggleMatrixCtrl', ['$rootScope', '$scope', '$filter', 'defaultToggleTypeDataFactory', 'hierarchyDataFactory',
function ($rootScope, $scope, $filter, defaultToggleTypeDataFactory, hierarchyDataFactory) {

    //Get Feed nodes from fs hierarchy
    getFeedFsNodes = function () {
        $scope.feedFsNodes = [];
        angular.forEach($scope.fsHierarchy.RootNodes, function (rootNode) {
            addFeedNodes(rootNode);
        });
    };

    var addFeedNodes = function (node) {
        var isFeedNode = false;
        var feedSources = [];
        angular.forEach(node.SourceDataTypes, function (sourceDataType) {
            if (sourceDataType.SourceEditType === 0) {
                isFeedNode = true;
                feedSources.push(sourceDataType);
            }
        });
        if (isFeedNode)
            $scope.feedFsNodes.push({ node: node, feedSources: feedSources });
        if (node.Children && node.Children.length) {
            angular.forEach(node.Children, function (childNode) {
                addFeedNodes(childNode);
            });
        }
    };

    $rootScope.promise = defaultToggleTypeDataFactory.getDefaultToggleTypes().then(function (defaultToggleTypeList) {
        $scope.defaultToggleTypeList = defaultToggleTypeList;
    });

    $scope.selectedDefaultToggleTypeChanged = function (sel) {
        var isDirty = $scope.hierarchySetDetailForm['defaultToggleMatrix'].$dirty;
        if (isDirty && $scope.oldSelection) {
            //TODO: Save the toggles;
            var itemsToSave = [];
            angular.forEach($scope.feedFsNodes, function (feedNode) {
                if (feedNode.selectedOption) {
                    var defaultToggleMapping = {
                        DefaultToggleType: $scope.oldSelection,
                        Toggle: feedNode.selectedOption.SourceType.Name,
                        HierarchyNode: feedNode.node
                    };
                    if (feedNode.mapping && feedNode.mapping.Toggle === feedNode.selectedOption.SourceType.Name)
                        defaultToggleMapping.Id = feedNode.mapping.Id;
                    itemsToSave.push(defaultToggleMapping);
                };
            });

            $rootScope.promise = hierarchyDataFactory.saveDefaultToggleMappings($scope.fsHierarchy.Id, $scope.oldSelection.Id, itemsToSave);
        };
        angular.forEach($scope.feedFsNodes, function (feedNode) {
            feedNode.selectedOption = "";
        });
        if (sel && sel.Id) {
            $rootScope.promise = hierarchyDataFactory.getDefaultToggleMappings($scope.fsHierarchy.Id, sel.Id).then(function (response) {
                angular.forEach(response.data, function (item) {
                    angular.forEach($scope.feedFsNodes, function (feedNode) {
                        if (item.HierarchyNode.Id === feedNode.node.Id) {
                            angular.forEach(feedNode.feedSources, function (feedSource) {
                                if (feedSource.SourceType.Name === item.Toggle) {
                                    feedNode.selectedOption = feedSource;
                                    feedNode.mapping = item;
                                }
                            });
                        }
                    });
                });
            });
        }

        $scope.hierarchySetDetailForm['defaultToggleMatrix'].$setPristine();
        $scope.oldSelection = sel;
    };

    function executeAsync(func) {
        setTimeout(func, 0);
    };
    //hierarchySetSelectedTabIndex
    $scope.$watch('fsHierarchy', function () {
        //if ($scope.hierarchySetSelectedTabIndex === 2) {
        if ($scope.fsHierarchy) {
            //getFeedFsNodes();
            executeAsync(function () {
                if ($scope.oldSelection)
                    $scope.selectedDefaultToggleTypeChanged($scope.oldSelection);
                $scope.feedFsNodes = [];
                angular.forEach($scope.fsHierarchy.RootNodes, function (rootNode) {
                    addFeedNodes(rootNode);
                });
                if ($scope.oldSelection)
                    $scope.selectedDefaultToggleTypeChanged($scope.oldSelection);
            });
        }
    });

    $scope.$watch('saveHierarchySetTriggered', function (isTriggered) {
        if (isTriggered)
            $scope.selectedDefaultToggleTypeChanged("");
    });
}]);