﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:FinancialStatementCtrl
 * @description
 * # FinancialStatementCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('gridViewStatementCtrl', ['$scope', '$rootScope', '$q', '$location', '$routeParams', '$mdDialog',
      '$mdSidenav', '$mdUtil',
      'hierarchyDataFactory', 'statementService', 'hierarchySetService', 'sourceTypeDataFactory', 'applicationConfigDataFactory',
      'regionsDataFactory', 'dividendPartnerDataFactory', 'defaultToggleTypeDataFactory', 'tagDataFactory',
      function ($scope, $rootScope, $q, $location, $routeParams, $mdDialog,
          $mdSidenav, $mdUtil,
          hierarchyDataFactory, statementService, hierarchySetService, sourceTypeDataFactory, applicationConfigDataFactory,
          regionsDataFactory, dividendPartnerDataFactory, defaultToggleTypeDataFactory, tagDataFactory) {

          $scope.selectOnlyN = function (item, selectedItems, count) {
              if (selectedItems != null && selectedItems.length >= count) {
                  return false;
              } else {
                  return true;
              }
          };                    

          var loadDividendPartners = function () {
              return dividendPartnerDataFactory.getDividendPartners().then(function (response) {
                  if ($scope.dividendPartners == undefined)
                      $scope.dividendPartners = [];
                  var localDividendPartners = response;
                  var existingDpIdList = [];
                  angular.forEach($scope.dividendPartners, function (item) {
                      existingDpIdList.push(item.Id);
                  });
                  angular.forEach(localDividendPartners, function (dp) {
                      var index = existingDpIdList.indexOf(dp.Id);
                      if (index === -1) {
                          dp.children = [];
                          dp.name = dp.Name;
                          dp.id = dp.Id;
                          $scope.dividendPartners.push(dp);
                      }
                  });
              });
          };

          var loadRegions = function () {
              return regionsDataFactory.getRegions().then(function (response) {
                  if ($scope.regions == undefined)
                      $scope.regions = [];
                  var localRegions = response;
                  var existingRegionIdList = [];
                  angular.forEach($scope.regions, function (item) {
                      existingRegionIdList.push(item.Id);
                  });
                  angular.forEach(localRegions, function (region) {
                      var index = existingRegionIdList.indexOf(region.Id);
                      if (index === -1) {
                          region.children = [];
                          region.name = region.Name;
                          region.id = region.Id;
                          $scope.regions.push(region);
                      }
                  });
              });
          };

          var loadTags = function () {
              return tagDataFactory.getTags().then(function (response) {
                  if ($scope.tags == undefined)
                      $scope.tags = [];
                  var localTags = response;
                  var existingTagIdList = [];
                  angular.forEach($scope.tags, function (item) {
                      existingTagIdList.push(item.Id);
                  });
                  angular.forEach(localTags, function (tag) {
                      var index = existingTagIdList.indexOf(tag.Id);
                      if (index === -1) {
                          tag.children = [];
                          tag.name = tag.Name;
                          tag.id = tag.Id;
                          $scope.tags.push(tag);
                      }
                  });
              });
          };

          $scope.levelList = [{ id: 1, name: 1 },
              { id: 2, name: 2 },
              { id: 3, name: 3 },
              { id: 4, name: 4 },
              { id: 5, name: 5 },
              { id: 6, name: 6 },
              { id: 7, name: 7 },
              { id: 8, name: 8 },
              { id: 9, name: 9 },
              { id: 10, name: 10 }
          ];

          var loadDefaultToggleTypes = function () {
              return defaultToggleTypeDataFactory.getDefaultToggleTypes().then(function (response) {
                  if ($scope.defaultToggleTypeList == undefined)
                      $scope.defaultToggleTypeList = [];
                  var localItems = response;
                  var existingDefaultToggleTypeIdList = [];
                  angular.forEach($scope.defaultToggleTypeList, function (item) {
                      existingDefaultToggleTypeIdList.push(item.Id);
                  });
                  angular.forEach(localItems, function (dtt) {
                      var index = existingDefaultToggleTypeIdList.indexOf(dtt.Id * 100);
                      if (index === -1) {
                          dtt.children = [];
                          dtt.name = dtt.Name;
                          dtt.id = dtt.Id * 100;
                          dtt.group = 'Default Toggle';
                          dtt.isDefaultToggle = true;
                          $scope.defaultToggleTypeList.push(dtt);
                      }
                  });
                  $scope.newSourceTypeList[1].children = $scope.defaultToggleTypeList;
              });

          };

          $scope.canSelectToggle = function (item, selectedItems) {
              if (item.name === "Mass Toggle" || item.name === "Default Toggle")
                  return false;
              return true;
          };

          $rootScope.promise = loadDividendPartners();

          $rootScope.promise = loadRegions();

          $rootScope.promise = loadTags();

          $rootScope.promise = loadDefaultToggleTypes();

          $scope.showRecordGeneration = false;
          
          $scope.newRecordNodeValues = [];

          var setColumnVisibility = function () {
              if ($scope.selectedDividendPartners && $scope.selectedDividendPartners.length)
                  $scope.isDivPartnerColumnVisible = true;
              else
                  $scope.isDivPartnerColumnVisible = false;
              if ($scope.selectedRegions && $scope.selectedRegions.length)
                  $scope.isRegionColumnVisible = true;
              else
                  $scope.isRegionColumnVisible = false;
              if ($scope.selectedTags && $scope.selectedTags.length)
                  $scope.isTagColumnVisible = true;
              else
                  $scope.isTagColumnVisible = false;
          };

          $scope.calculateKpiConfirmation = function (type) {
              $rootScope.promise = statementService.saveAdjustments().then(function () {
                  $mdDialog.show({
                      controller: 'calculateKpiConfirmationCtrl',
                      templateUrl: 'app/templates/calculateKpiConfirmation.tmpl.html',
                      parent: angular.element(document.body),
                      locals: {
                          selectedRecord: $scope.currentRecord,
                          rbHierarchy: angular.copy($scope.rbMultiSelectableTree)
                      }
                  })
                      .then(function (kpiOptions) {
                          $rootScope.promise = statementService.saveAdjustments().then(function () {
                              statementService.calculateKpi($scope.currentRecord.Id, type, kpiOptions.selectedRbNodeIdList, kpiOptions.selectedLevel);
                              $mdDialog.show(
                                  $mdDialog.alert()
                                  .parent(document.body)
                                  .clickOutsideToClose(false)
                                  .title('Calculate KPI in progress')
                                  .content('Calculate KPI is initiated on the server and you will be notified when it is complete.')
                                  .ariaLabel('Calculate KPI initiated')
                                  .ok('OK')
                              ).then(function () {
                                  $location.path('/');
                              });
                          })
                      }, function () {
                      });
              });
          };

          var setClientReadOnly = function (row) {
              if (row.ParentFsNodeId != null) {
                  var parentFsNodeIdList = [row.ParentFsNodeId];
                  for (var i = 0; i < $scope.newRecordNodeValues.length; i++) {
                      var record = $scope.newRecordNodeValues[i];
                      for (var j = 0; j < parentFsNodeIdList.length; j++) {
                          var parentId = parentFsNodeIdList[j];
                          if (record.FsNodeId === parentId && record.Date === row.Date) {
                              if (row.Adjustment !== null && row.Toggle !== null)
                                  record.clientReadOnly = true;
                              else
                                  record.clientReadOnly = false;
                              if (record.ParentFsNodeId != null && parentFsNodeIdList.indexOf(record.ParentFsNodeId) === -1) {
                                  parentFsNodeIdList.push(record.ParentFsNodeId);
                                  i = 0;
                                  break;
                              }
                          }
                      }
                  }
              }

              if (row.ParentRbNodeId != null) {
                  var parentRbNodeIdList = [row.ParentRbNodeId];
                  for (var i = 0; i < $scope.newRecordNodeValues.length; i++) {
                      var record = $scope.newRecordNodeValues[i];
                      for (var j = 0; j < parentRbNodeIdList.length; j++) {
                          var parentId = parentRbNodeIdList[j];
                          if (record.RbNodeId === parentId && record.Date === row.Date) {
                              if (row.Adjustment !== null && row.Toggle !== null)
                                  record.clientReadOnly = true;
                              else
                                  record.clientReadOnly = false;
                              if (record.ParentRbNodeId != null && parentRbNodeIdList.indexOf(record.ParentRbNodeId) === -1) {
                                  parentRbNodeIdList.push(record.ParentRbNodeId);
                                  i = 0;
                                  break;
                              }
                          }
                      }
                  }
              }

              var childFsNodeIdList = [row.FsNodeId];
              for (var i = 0; i < $scope.newRecordNodeValues.length; i++) {
                  var record = $scope.newRecordNodeValues[i];
                  for (var j = 0; j < childFsNodeIdList.length; j++) {
                      var childId = childFsNodeIdList[j];
                      if (record.ParentFsNodeId === childId && record.Date === row.Date) {
                          if (row.Adjustment !== null && row.Toggle !== null)
                              record.clientReadOnly = true;
                          else
                              record.clientReadOnly = false;
                          if (record.FsNodeId != null && childFsNodeIdList.indexOf(record.FsNodeId) === -1) {
                              childFsNodeIdList.push(record.FsNodeId);
                              i = 0;
                              break;
                          }
                      }
                  }
              }

              var childRbNodeIdList = [row.RbNodeId];
              for (var i = 0; i < $scope.newRecordNodeValues.length; i++) {
                  var record = $scope.newRecordNodeValues[i];
                  for (var j = 0; j < childRbNodeIdList.length; j++) {
                      var childId = childRbNodeIdList[j];
                      if (record.ParentRbNodeId === childId && record.Date === row.Date) {
                          if (row.Adjustment !== null && row.Toggle !== null)
                              record.clientReadOnly = true;
                          else
                              record.clientReadOnly = false;
                          if (record.RbNodeId != null && childRbNodeIdList.indexOf(record.RbNodeId) === -1) {
                              childRbNodeIdList.push(record.RbNodeId);
                              i = 0;
                              break;
                          }
                      }
                  }
              }
          }

          var initializeExcelData = function (data) {
              angular.forEach(data, function (item) {
                  if (item.Toggle !== null) {
                      angular.forEach($scope.sourceTypeList, function (sourceType) {
                          if (angular.lowercase(sourceType.Name) === angular.lowercase(item.Toggle)) {
                              item.ToggleValue = sourceType;
                          }
                      });
                  }
                  if (item.AdjustedValue != null) {
                      item.selectedSourceValue = item.AdjustedValue - item.Adjustment;
                      item.clientReadOnly = false;
                      item.allowAdjustment = true;
                  }
                  if (item.Info != null && item.Info !== "" && !($scope.selectedTags && $scope.selectedTags.length)) {
                      item.infoToExpand = true;
                  }
              });
          };

          $scope.showSourceTypeInformation = function (item) {

              var selectedAdjustment = {
                  recordId: item.RecordId,
                  fsNodeId: item.FsNodeId,
                  rbNodeId: item.RbNodeId,
                  dividendPartnerId: item.DividendPartnerId,
                  regionId: item.RegionId,
                  date: item.Date,
                  sourceDataTypes: item.SourceDataType,
                  has1OrMoreCalcSourceDataType:item.Has1OrMoreCalcSourceDataType
              };

              $mdDialog.show({
                  controller: 'sourceTypeInformationForNodeCtrl',
                  templateUrl: 'app/templates/sourceTypeInformationForNode.tmpl.html',
                  parent: angular.element(document.body),
                  locals: {
                      selectedAdjustment: selectedAdjustment
                  }
              }).then(function () { });
          };

          $scope.showInfoDetails = function (item) {
              if (item.infoToExpand) {
                  var infoDetailRequest = {
                      recordId: item.RecordId,
                      fsNodeId: item.FsNodeId,
                      rbNodeId: item.RbNodeId,
                      dividendPartnerId: item.DividendPartnerId,
                      regionId: item.RegionId,
                      date: item.Date
                  };
                  $mdDialog.show({
                      controller: 'recordNodeInfoDetailCtrl',
                      templateUrl: 'app/templates/recordNodeInfoDetail.tmpl.html',
                      parent: angular.element(document.body),
                      locals: {
                          request: infoDetailRequest
                      }
                  }).then(function () { });
              }
          };

          $scope.excelToggleChanged = function (row) {

              row.allowAdjustment = true;
              var selectedSource = row.ToggleValue;
              if (row.ReadOnly)
                  row.allowAdjustament = false;
              if (selectedSource != null) {
                  row.AdjustmentType = selectedSource.Id;
                  row.AdjustmentTypeName = selectedSource.Name;
                  row.Toggle = selectedSource.Name;

                  switch (angular.lowercase(selectedSource.Name)) {
                      case 'plan':
                          row.selectedSourceValue = row.PlanValue;
                          break;
                      case 'forecast':
                          row.selectedSourceValue = row.ForecastValue;
                          break;
                      case "tpr":
                          row.selectedSourceValue = row.TprValue;
                          break;
                      case "fbw":
                          row.selectedSourceValue = row.FbwValue;
                          break;
                      case "wc":
                          row.selectedSourceValue = row.WcValue;
                          break;
                  }
                  var currentFsNode = {};
                  angular.forEach($scope.selectedFsNodes, function (node) {
                      if (node.id === row.FsNodeId)
                          currentFsNode = node;
                  });
                  if (row.allowAdjustment && currentFsNode.OriginalNode.SourceDataTypes.length) {
                      var allowAdjustment = false;
                      angular.forEach(currentFsNode.OriginalNode.SourceDataTypes, function (sourceDataType) {
                          if (sourceDataType.SourceType.Name === selectedSource.Name) {
                              allowAdjustment = sourceDataType.SourceEditType !== 2;
                              row.Info = "Sum node";
                          }
                      }, this);
                      row.allowAdjustment = allowAdjustment;
                  }
              }
              if (!row.allowAdjustment) {
                  row.Adjustment = null;
              } else if (row.Adjustment == null) {
                  row.Adjustment = 0;
                  row.Info = "";
              }

              if (selectedSource != null && row.allowAdjustment)
                  $scope.$parent.allowSave = true;
              if (row.Adjustment != null && !row.ReadOnly && row.allowAdjustment)
                  setClientReadOnly(row);
          };

          $scope.getExcelValue = function (item) {
              var total = 0;
              var original = item.AdjustedValue;
              //var adjustment = isNaN(parseFloat(item.Adjustment)) ? 0 : parseFloat(item.Adjustment);
              var adjustment = parseFloat(item.Adjustment);
              if (item.Toggle != null) {
                  if (angular.lowercase(item.Toggle) === "fbw") {
                      total = item.FbwValue != null ? parseFloat(item.FbwValue) + adjustment : adjustment;
                  } else if (angular.lowercase(item.Toggle) === "forecast") {
                      total = item.ForecastValue != null ? parseFloat(item.ForecastValue) + adjustment : adjustment;
                  } else if (angular.lowercase(item.Toggle) === "plan") {
                      total = item.PlanValue != null ? parseFloat(item.PlanValue) + adjustment : adjustment;
                  } else if (angular.lowercase(item.Toggle) === "tpr") {
                      total = item.TprValue != null ? parseFloat(item.TprValue) + adjustment : adjustment;
                  } else if (angular.lowercase(item.Toggle) === "wc") {
                      total = item.WcValue != null ? parseFloat(item.WcValue) + adjustment : adjustment;
                  }
                  item.AdjustedValue = isNaN(total) ? null : total;
              }
              if (item.AdjustedValue == null && item.AdjustedValue !== original)
                  setClientReadOnly(item);
              return item.AdjustedValue;
          };

          var resetGrids = function () {
              $scope.newRecordNodeValues = [];
              //$scope.existingRecordNodeValues = [];              
          };

          var applyMassToggle = function () {
              $scope.newRecordNodeValues = [];
              var selectedFsNodeIdList = [];
              var selectedRbNodeIdList = [];
              var selectedMonthList = [];
              var selectedDividendPartnerIdList = [];
              var selectedRegionIdList = [];
              angular.forEach($scope.selectedFsNodes, function (fsNode) {
                  selectedFsNodeIdList.push(fsNode.id);
              });
              angular.forEach($scope.selectedRbNodes, function (rbNode) {
                  selectedRbNodeIdList.push(rbNode.id);
              });
              angular.forEach($scope.selectedMonths, function (month) {
                  selectedMonthList.push(month.id);
              });
              angular.forEach($scope.selectedDividendPartners, function (dp) {
                  selectedDividendPartnerIdList.push(dp.id);
              });
              angular.forEach($scope.selectedRegions, function (region) {
                  selectedRegionIdList.push(region.id);
              });
              var selectedSourceType = "";
              if ($scope.selectedSourceType != null && $scope.selectedSourceType.length)
                  selectedSourceType = $scope.selectedSourceType[0].name;
              var recordId = statementService.selectedRecord().Id;
              if (recordId === undefined && $scope.currentRecord != null && $scope.currentRecord !== undefined)
                  recordId = $scope.currentRecord.Id;
              if (recordId != null && selectedFsNodeIdList.length && selectedRbNodeIdList.length && selectedMonthList.length) {
                  $rootScope.promise = statementService.getNewAdjustments(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList,
                      selectedRegionIdList, selectedSourceType).then(function () {
                          $scope.newRecordNodeValues = statementService.newRecordNodeValues();
                          setColumnVisibility();
                          initializeExcelData($scope.newRecordNodeValues);
                          //loadExistingAdjustments();
                          if ($scope.selectedSourceType != null && $scope.selectedSourceType.length)
                              $scope.$parent.allowSave = true;
                      }, function (error) {
                          console.log(error);
                      });
              }
          };

          var clearData = function () {
              $scope.newRecordNodeValues = [];
              var selectedFsNodeIdList = [];
              var selectedRbNodeIdList = [];
              var selectedMonthList = [];
              var selectedDividendPartnerIdList = [];
              var selectedRegionIdList = [];
              angular.forEach($scope.selectedFsNodes, function (fsNode) {
                  selectedFsNodeIdList.push(fsNode.id);
              });
              angular.forEach($scope.selectedRbNodes, function (rbNode) {
                  selectedRbNodeIdList.push(rbNode.id);
              });
              angular.forEach($scope.selectedMonths, function (month) {
                  selectedMonthList.push(month.id);
              });
              angular.forEach($scope.selectedDividendPartners, function (dp) {
                  selectedDividendPartnerIdList.push(dp.id);
              });
              angular.forEach($scope.selectedRegions, function (region) {
                  selectedRegionIdList.push(region.id);
              });
              var recordId = statementService.selectedRecord().Id;
              if (recordId === undefined && $scope.currentRecord != null && $scope.currentRecord !== undefined)
                  recordId = $scope.currentRecord.Id;
              if (recordId != null && selectedFsNodeIdList.length && selectedRbNodeIdList.length && selectedMonthList.length) {
                  $rootScope.promise = statementService.clearAdjustments(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList,
                      selectedRegionIdList).then(function () {
                          $scope.newRecordNodeValues = statementService.newRecordNodeValues();
                          setColumnVisibility();
                          initializeExcelData($scope.newRecordNodeValues);
                          $scope.$parent.allowSave = true;
                      }, function (error) {
                          console.log(error);
                      });
              }
          };

          var applyDefaultToggle = function () {
              $scope.newRecordNodeValues = [];
              var selectedFsNodeIdList = [];
              var selectedRbNodeIdList = [];
              var selectedMonthList = [];
              angular.forEach($scope.selectedFsNodes, function (fsNode) {
                  selectedFsNodeIdList.push(fsNode.id);
              });
              angular.forEach($scope.selectedRbNodes, function (rbNode) {
                  selectedRbNodeIdList.push(rbNode.id);
              });
              angular.forEach($scope.selectedMonths, function (month) {
                  selectedMonthList.push(month.id);
              });
              var selectedSourceType = "";
              if ($scope.selectedSourceType != null && $scope.selectedSourceType.length)
                  selectedSourceType = $scope.selectedSourceType[0].name;
              var recordId = statementService.selectedRecord().Id;
              if (recordId === undefined && $scope.currentRecord != null && $scope.currentRecord !== undefined)
                  recordId = $scope.currentRecord.Id;
              if (recordId != null && selectedFsNodeIdList.length && selectedRbNodeIdList.length && selectedMonthList.length) {
                  var selectedLevel = null;
                  if ($scope.selectedLevel && $scope.selectedLevel.length)
                      selectedLevel = $scope.selectedLevel[0].id;
                  statementService.applyDefaultToggle(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedSourceType, selectedLevel);

                  $mdDialog.show(
                              $mdDialog.alert()
                              .parent(document.body)
                              .clickOutsideToClose(false)
                              .title('Applying Default Toggle in progress')
                              .content('Default Toggle is initiated on the server and you will be notified when it is complete.')
                              .ariaLabel('Applying Default Toggle')
                              .ok('OK')
                          ).then(function () {
                              $location.path('/');
                          });
              }
          };

          var getData = function () {
              if ($scope.selectedTags && $scope.selectedTags.length) {
                  getTaggedData();
              }
              else {
                  getJustData();
              }
          };

          var getJustData = function () {
              $scope.newRecordNodeValues = [];
              var selectedFsNodeIdList = [];
              var selectedRbNodeIdList = [];
              var selectedMonthList = [];
              var selectedDividendPartnerIdList = [];
              var selectedRegionIdList = [];
              angular.forEach($scope.selectedFsNodes, function (fsNode) {
                  selectedFsNodeIdList.push(fsNode.id);
              });
              angular.forEach($scope.selectedRbNodes, function (rbNode) {
                  selectedRbNodeIdList.push(rbNode.id);
              });
              angular.forEach($scope.selectedMonths, function (month) {
                  selectedMonthList.push(month.id);
              });
              angular.forEach($scope.selectedDividendPartners, function (dp) {
                  selectedDividendPartnerIdList.push(dp.id);
              });
              angular.forEach($scope.selectedRegions, function (region) {
                  selectedRegionIdList.push(region.id);
              });
              var selectedSourceType = "";
              var recordId = statementService.selectedRecord().Id;
              if (recordId === undefined && $scope.currentRecord != null && $scope.currentRecord !== undefined)
                  recordId = $scope.currentRecord.Id;
              if (recordId != null && selectedFsNodeIdList.length && selectedRbNodeIdList.length && selectedMonthList.length) {
                  $rootScope.promise = statementService.getNewAdjustments(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList,
                      selectedRegionIdList, selectedSourceType).then(function () {
                          $scope.newRecordNodeValues = statementService.newRecordNodeValues();
                          setColumnVisibility();
                          initializeExcelData($scope.newRecordNodeValues);
                          //loadExistingAdjustments();                          
                      }, function (error) {
                          console.log(error);
                      });
              }
          };

          var getTaggedData = function () {
              $scope.newRecordNodeValues = [];
              var selectedFsNodeIdList = [];
              var selectedRbNodeIdList = [];
              var selectedMonthList = [];
              var selectedTagIdList = [];
              angular.forEach($scope.selectedFsNodes, function (fsNode) {
                  selectedFsNodeIdList.push(fsNode.id);
              });
              angular.forEach($scope.selectedRbNodes, function (rbNode) {
                  selectedRbNodeIdList.push(rbNode.id);
              });
              angular.forEach($scope.selectedMonths, function (month) {
                  selectedMonthList.push(month.id);
              });
              angular.forEach($scope.selectedTags, function (tag) {
                  selectedTagIdList.push(tag.id);
              });

              var recordId = statementService.selectedRecord().Id;
              if (recordId === undefined && $scope.currentRecord != null && $scope.currentRecord !== undefined)
                  recordId = $scope.currentRecord.Id;
              if (recordId != null && selectedFsNodeIdList.length && selectedRbNodeIdList.length && selectedMonthList.length && selectedTagIdList.length) {
                  $rootScope.promise = statementService.getTaggedData(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedTagIdList).then(function () {
                      $scope.newRecordNodeValues = statementService.taggedData();
                      setColumnVisibility();
                      initializeExcelData($scope.newRecordNodeValues);
                      //loadExistingAdjustments();                          
                  }, function (error) {
                      console.log(error);
                  });
              }
          };

          var processGenerateGridData = function (isDefaultToggle) {
              if ($scope.newRecordNodeValues != null) {
                  var valuesToSend = [];
                  angular.forEach($scope.newRecordNodeValues, function (item) {
                      if (item.AdjustedValue != null) {
                          if (item.Adjustment == null)
                              item.Adjustment = 0;
                          valuesToSend.push(item);
                      }
                  });
                  if (valuesToSend.length) {
                      $rootScope.promise = statementService.saveAdjustments().then(function () {
                          if (isDefaultToggle)
                              applyDefaultToggle();
                          else
                              applyMassToggle();
                      });
                  } else {
                      if (isDefaultToggle)
                          applyDefaultToggle();
                      else
                          applyMassToggle();
                  }
              } else {
                  if (isDefaultToggle)
                      applyDefaultToggle();
                  else
                      applyMassToggle();
              }
              $scope.showRecordGeneration = true;
          };

          $scope.generateGridData = function () {
              var isDefaultToggle = false;
              if ($scope.selectedSourceType != null && $scope.selectedSourceType.length) {
                  isDefaultToggle = $scope.selectedSourceType[0].isDefaultToggle;
              }
              if (isDefaultToggle) {
                  var confirm = $mdDialog.confirm()
                  .title('Do you want to Continue?')
                  .textContent('Previous adjustments will be deleted before applying the default toggle. Do you want to continue?')
                  .ariaLabel('Defualt Adjustment Confirmation')
                  .ok('Yes')
                  .cancel('No');
                  $mdDialog.show(confirm).then(function () { processGenerateGridData(isDefaultToggle) });
              }
              else {
                  processGenerateGridData(isDefaultToggle);
              }

          };

          $scope.clearData = function () {
              var confirm = $mdDialog.confirm()
              .title('Do you want to clear Adjustments?')
              .textContent('All the adjustments made under the given selection will be deleted. Do you want to continue?')
              .ariaLabel('Clear Adjustments Confirmation')
              .ok('Yes')
              .cancel('No');
              $mdDialog.show(confirm).then(function () {
                  if ($scope.newRecordNodeValues != null) {
                      var valuesToSend = [];
                      angular.forEach($scope.newRecordNodeValues, function (item) {
                          if (item.AdjustedValue != null) {
                              if (item.Adjustment == null)
                                  item.Adjustment = 0;
                              valuesToSend.push(item);
                          }
                      });
                      if (valuesToSend.length) {
                          $rootScope.promise = statementService.saveAdjustments().then(function () {
                              clearData();
                          });
                      } else {
                          clearData();
                      }
                  } else {
                      clearData();
                  }
                  $scope.showRecordGeneration = true;
              });
          };

          $scope.navigateGrid = function () {
              if ($scope.newRecordNodeValues != null && $scope.viewType != 'view') {
                  var valuesToSend = [];
                  angular.forEach($scope.newRecordNodeValues, function (item) {
                      if (item.AdjustedValue != null && !item.ReadOnly) {
                          if (item.Adjustment == null)
                              item.Adjustment = 0;
                          valuesToSend.push(item);
                      }
                  });
                  if (valuesToSend.length) {
                      $rootScope.promise = statementService.saveAdjustments().then(function () {
                          getData();
                      });
                  } else {
                      getData();
                  }
              } else {
                  getData();
              }
              $scope.showRecordGeneration = true;
          };

          $scope.saveData = function () {
              if ($scope.newRecordNodeValues != null) {
                  var valuesToSend = [];
                  angular.forEach($scope.newRecordNodeValues, function (item) {
                      if (item.AdjustedValue != null)
                          valuesToSend.push(item);
                  });
                  if (valuesToSend.length) {
                      $rootScope.promise = statementService.saveAdjustments();
                  }
              }
          };          

          $scope.newColumns = [
              {
                  data: "FsNodeName",
                  title: "FS Node",
                  type: "text",
                  readOnly: true
              }, {
                  data: "RbNodeName", title: "RB Node", readOnly: true
              }, {
                  data: "DividendPartnerName", title: "Dividend Partner", readOnly: true
              },
          {
              data: "Toggle", title: "Toggle", type: "autocomplete", optionList: { object: ["TPR", "PLAN"], strict: true }
          }
          ];
          $scope.sourceTypeNameList = ["TPR"];

          $scope.newSourceTypeList = [
              {
                  id: 10000, name: "Mass Toggle", children: [
                      { id: 1, name: "TPR", children: [] }, { id: 2, name: "Plan", children: [] }, { id: 3, name: "Forecast", children: [] },
                      { id: 4, name: "FBW", children: [] }, { id: 5, name: "WC", children: [] }
                  ]
              },
              {
                  id: 20000, name: "Default Toggle", children: [
                  ]
              }
          ];

          $scope.allowNavigation = function () {
              if ($scope.selectedFsNodes != null && $scope.selectedFsNodes.length
                  && $scope.selectedRbNodes != null && $scope.selectedRbNodes.length
                  && $scope.selectedMonths != null && $scope.selectedMonths.length) {
                  return true;
              }
              return false;
          }

          $scope.allowGeneratingNewData = function () {
              if ($scope.selectedDividendPartners != null && !$scope.selectedDividendPartners.length
                  && $scope.selectedRegions != null && !$scope.selectedRegions.length
                  && $scope.selectedFsNodes != null && $scope.selectedFsNodes.length
                  && $scope.selectedRbNodes != null && $scope.selectedRbNodes.length
                  && $scope.selectedMonths != null && $scope.selectedMonths.length
                  && $scope.selectedSourceType != null && $scope.selectedSourceType.length
                  && ($scope.selectedTags == null || !($scope.selectedTags != null && $scope.selectedTags.length))) {
                  return true;
              }
              return false;
          };

          $scope.allowClearingData = function () {
              if ($scope.selectedDividendPartners != null && !$scope.selectedDividendPartners.length
                  && $scope.selectedRegions != null && !$scope.selectedRegions.length
                  && $scope.selectedFsNodes != null && $scope.selectedFsNodes.length
                  && $scope.selectedRbNodes != null && $scope.selectedRbNodes.length
                  && $scope.selectedMonths != null && $scope.selectedMonths.length
                  && !isTagSelected()) {
                  return true;
              }
              return false;
          };

          $scope.allowMassToggle = function () {
              if ($scope.selectedDividendPartners != null && !$scope.selectedDividendPartners.length &&
                  $scope.selectedRegions != null && !$scope.selectedRegions.length
                  && !isTagSelected())
                  return true;
              return false;
          };

          $scope.allowLevelSelection = function () {
              var isDefaultToggle = false;
              if ($scope.selectedSourceType != null && $scope.selectedSourceType.length) {
                  isDefaultToggle = $scope.selectedSourceType[0].isDefaultToggle;
              }
              if (isDefaultToggle)
                  return true;
              return false;
          };

          var isTagSelected = function () {
              return $scope.selectedTags != null && $scope.selectedTags.length;
          };

          var isDividendPartnerSelected = function () {
              return $scope.selectedDividendPartners != null && $scope.selectedDividendPartners.length;
          };

          var isRegionSelected = function () {
              return $scope.selectedRegions != null && $scope.selectedRegions.length;
          };

          $scope.showDividendPartnerSelection = function () {
              return !isTagSelected();
          };

          $scope.showRegionSelection = function () {
              return !isTagSelected();
          };

          $scope.showTagSelection = function () {
              return !isDividendPartnerSelected() && !isRegionSelected();
          };

          $scope.allowApplyDefaultToggle = function () {
              if ($scope.selectedFsNodes != null && $scope.selectedFsNodes.length
                  && $scope.selectedRbNodes != null && $scope.selectedRbNodes.length
                  && $scope.selectedMonths != null && $scope.selectedMonths.length) {
                  return true;
              }
              return false;

          };

          $scope.settings = {};

          $scope.colHeaders = true;

          $scope.getValidLevels = function (selectedRbNodes) {              
              return $scope.levelList;
          };

          $scope.$watch("isFSHierarchyLoaded", function (isLoaded) {
              if (isLoaded) {
                  $scope.fsMultiSelectableTree = hierarchySetService.getMultiSelectableTree($scope.financialStatementHierarchy);
              }
          });

          $scope.$watch("isRBHierarchyLoaded", function (isLoaded) {
              if (isLoaded) {
                  $scope.rbMultiSelectableTree = hierarchySetService.getMultiSelectableTree($scope.rbHierarchy);
              }
          });

          $scope.$watch("updateGridView", function (update) {
              if (update) {
                  getData();
              }
          });

          $scope.$watch("showTreeView", function (isTreeView) {
              if (isTreeView && $scope.viewType != 'view') {
                  $scope.saveData();
              } else {
                  resetGrids();
              }
          });
      }]);