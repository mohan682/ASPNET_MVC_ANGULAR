﻿angular.module('bullseyeApp').controller('moveNodeCtrl', ['$scope', '$mdDialog', 'nodeToMove', 'tree',
    function ($scope, $mdDialog, nodeToMove, tree) {
        $scope.node = nodeToMove;
        $scope.originNode = undefined;
        $scope.selectedNode = undefined;
        //$scope.sameParentNodeSelected = false;
        var hierarchyTree = $('#hierarchyTree').treeview({
            data: [],
            showBorder: false
        });

        var getBranchWithoutNodeToMove = function (node) {
            var convertedNode = { };
            if (node.nodes && node.nodes.length) {
                convertedNode.nodes = [];
                angular.forEach(node.nodes, function (childNode) {
                    if (childNode.Id !== nodeToMove.Id)
                        convertedNode.nodes.push(getBranchWithoutNodeToMove(childNode));
                    else
                    {
                        $scope.originNode = node;                        
                    }
                });
            }

            convertedNode.text = node.text;            
            convertedNode.Id = node.Id;
            return convertedNode;
        };

        var createTreeWithoutNodeToMove = function (treeData) {
            var tree = [];
            angular.forEach(treeData, function (rootNode) {
                if (rootNode.Id !== nodeToMove.Id)
                    tree.push(getBranchWithoutNodeToMove(rootNode));                
            });
            return tree;
        };

        function executeAsync(func) {
            setTimeout(func, 0);
        };

        executeAsync(function () {
            var updatedTree = createTreeWithoutNodeToMove(tree);
            hierarchyTree = $('#hierarchyTree').treeview({
                data: [],
                showBorder: false
            });
            hierarchyTree.treeview({
                data: updatedTree,
                onNodeUnselected: function (event, node) {
                    nodeSelectionChanged(node, false);
                },
                onNodeSelected: function (event, node) {
                    nodeSelectionChanged(node, true);
                }
            });
        });

        function prepareAndSetTree(tree) {
            var updatedTree = createTreeWithoutNodeToMove(tree);
            hierarchyTree = $('#hierarchyTree').treeview({
                data: [],
                showBorder: false
            });
            hierarchyTree.treeview({
                data: updatedTree,
                onNodeUnselected: function (event, node) {
                    nodeSelectionChanged(node, false);
                },
                onNodeSelected: function (event, node) {
                    nodeSelectionChanged(node, true);
                }
            });
        };

        //new prepareAndSetTree(tree);
        
        //setTimeout(prepareAndSetTree(tree), 5000);
        
        $scope.onHierarchySearchChange = function () {
            hierarchyTree.treeview('search', [$scope.hierarchySearchTerm, { ignoreCase: true, exactMatch: false, revealResults: true }]);
        };
        var nodeSelectionChanged = function (node, isSelected) {
            if (isSelected) {
                if ($scope.originNode && $scope.originNode.Id !== node.Id) {
                    $scope.sameParentNodeSelected = false;
                    $scope.selectedNode = node;
                }
                else {
                    $scope.sameParentNodeSelected = true;
                }
            }
            else {
                $scope.selectedNode = undefined;
            }

            $scope.$apply();
        };

        $scope.ok = function () {            
            $mdDialog.hide($scope.selectedNode);
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);