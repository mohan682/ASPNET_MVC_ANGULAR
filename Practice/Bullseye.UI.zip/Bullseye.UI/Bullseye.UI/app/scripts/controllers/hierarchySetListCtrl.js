﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:hierarchySetListCtrl
 * @description
 * # HierarchySetListCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('hierarchySetListCtrl', ['$rootScope', '$scope', '$location', 'hierarchySetDataFactory',
      '$mdDialog',
      function ($rootScope, $scope, $location, hierarchySetDataFactory, $mdDialog) {
          $rootScope.promise.then(function () {
              $rootScope.promise = hierarchySetDataFactory.getHierarchySetList().success(function (hierarchySetList) {
                  $scope.hierarchySetList = hierarchySetList;
              }).error(function (error) {
                  console.log(error);
              });
          });

          $scope.gridOptions = {
              enableFiltering: true,
              data: 'hierarchySetList',
              columnDefs: [
                  {
                      name: 'edit',
                      displayName: 'Options',
                      width: 140,
                      cellClass: 'gridEditColumn',
                      cellTemplate: '<div layout="row"> ' +
                          ' <md-button ng-disabled="!grid.appScope.getFeatureAccess(grid.appScope.availableFeatures.EditHierarchy)" md-no-ink layout-fill id=editBtn class="grid-icon-btn" ng-click="grid.appScope.editHierarchy(row.entity)"><img class="ng-scope" src="app/images/edit-icon.png"></img><md-tooltip>Edit</md-tooltip></md-button>' +
                          ' <md-button ng-disabled="!grid.appScope.getFeatureAccess(grid.appScope.availableFeatures.ViewHierarchy)" md-no-ink layout-fill id=viewBtn class="grid-icon-btn" ng-click="grid.appScope.viewHierarchy(row.entity)"><img class="ng-scope" src="app/images/view-icon.png"></img><md-tooltip>View</md-tooltip></md-button>' +
                          ' <md-button ng-disabled="!grid.appScope.getFeatureAccess(grid.appScope.availableFeatures.EditHierarchy)" md-no-ink layout-fill id=saveasBtn class="grid-icon-btn" ng-click="grid.appScope.saveasHierarchy(row.entity)"><img class="ng-scope" src="app/images/saveas-icon.png" style="padding:2px;"></img><md-tooltip>Save As New Hierarchy</md-tooltip></md-button>' +
                          ' <md-button style="background-color:#00ff00" ' +
                          'ng-show="row.entity.IsLatest" ' +
                          'ng-disabled="!grid.appScope.getFeatureAccess(grid.appScope.availableFeatures.EditHierarchy)"' +
                          ' md-no-ink layout-fill id=latestHierarchy class="grid-icon-btn">' +
                          '<img style="background-color:#FF35E955" src="app/images/whiteWithGreenBg_flag.png" style="padding:2px;"></img>' +
                          '<md-tooltip>{{row.entity.Name}} is a latest hierarchy.</md-tooltip></md-button>' +
                          ' <md-button ng-show="!row.entity.IsLatest" ng-disabled="!grid.appScope.getFeatureAccess(grid.appScope.availableFeatures.EditHierarchy)" md-no-ink layout-fill id=notLatestHierarchy class="grid-icon-btn" ng-click="grid.appScope.saveAsLatestHierarchySet(row.entity)"><img class="ng-scope" src="app/images/grey_flag.png" style="padding:2px;"></img><md-tooltip>{{row.entity.Name}} is not a latest hierarchy.</md-tooltip></md-button>' +
                          ' </div>',
                      enableSorting: false,
                      enableFiltering: false,
                      enableHiding: false
                  },
                  { field: 'Name', displayName: 'Name' },
                  {
                      field: 'CreatedBy', displayName: 'Created By'
                  },
                  {
                      field: 'Created', displayName: 'Created Date',
                      cellTemplate: '<div class="ui-grid-cell-contents" id="createdColumn">{{grid.appScope.getCreatedDateTime(row.entity)| date:"dd MMM yyyy HH:mm:ss"}}</div>'
                  }
              ]
          };

          var hierarchyTypes =
            [{ Name: 'FS Hierarchy', Id: 0 },
            { Name: 'RB Hierarchy', Id: 1 }];

          var isDate = function (date) {
              return (!isNaN(new Date(date)));
          }

          $scope.getHierarchyType = function (rowEntity) {
              var typeId = rowEntity.Type;
              var typeName = typeId
              angular.forEach(hierarchyTypes, function (type) {
                  if (type.Id === typeId) {
                      typeName = type.Name;
                  }
              });
              return typeName;
          };

          $scope.getCreatedDateTime = function (rowEntity) {
              var date = rowEntity.Created;
              if (isDate(date))
                  return new Date(date);
              return "";
          }

          $scope.editHierarchy = function (rowEntity) {
              $location.path("/hierarchySetDetail/" + rowEntity.Id + "/edit");
          };

          $scope.viewHierarchy = function (rowEntity) {
              $location.path("/hierarchySetDetail/" + rowEntity.Id + "/view");
          };

          $scope.saveasHierarchy = function (rowEntity) {
              $mdDialog.show({
                  parent: angular.element(document.body),
                  template:
                    '<md-dialog aria-label="Nodes with Data">' +
                    '<form name ="saveAsForm">'+
                    '   <md-toolbar>' +
                    '       <div class="md-toolbar-tools">' +
                    '           <h3>Save as new</h3>' +
                    '       </div>' +
                    '   </md-toolbar>' +
                    '  <md-dialog-content layout-padding>' +
                    //'    <h4>Choose a name for the new hierarchy set</h4>' +
                    '   <div>' +
                    '    <md-input-container flex style="display: block;" ng-class="{\'has-error\':saveAsForm[newHierarchySetName].$invalid}">' +
                    '       <label>New Hierarchy Set Name</label>' +
                    '       <input name="newHierarchySetName" md-autofocus ng-model="newHierarchySetName" required ng-blur="isHierarchySetNameUnique()"/>' +
                    '       <div ng-messages="saveAsForm[\'newHierarchySetName\'].$error">' +
                    '           <div ng-message="required">Name is mandatory</div>' +
                    '           <div ng-message="unique">Chosen name is not unique.</div>' +                    
                    '       </div>' +
                    '    </md-input-container>' +
                    '    </div>' +
                    '  </md-dialog-content>' +
                    '  <md-dialog-actions>' +
                    '    <md-button ng-click="create()" class="md-primary" ng-disabled="saveAsForm.$invalid">' +
                    '      Create' +
                    '    </md-button>' +
                    '  </md-dialog-actions>' +
                    '</form>'+
                    '</md-dialog>',
                  locals: {
                      data: { selectedHierarchyName: rowEntity.Name, allHierarchySets: $scope.hierarchySetList }
                  },
                  controller: function DialogController($scope, $mdDialog, data) {
                      $scope.newHierarchySetName = data.selectedHierarchyName + '- Copy';                      
                      $scope.isUnique = true;                          
                      $scope.isHierarchySetNameUnique = function () {                          
                          $scope.isUnique = true;
                          var controlName = 'newHierarchySetName';
                          angular.forEach(data.allHierarchySets, function (hs) {
                              if (hs.Name === $scope.newHierarchySetName)
                                  $scope.isUnique = false;
                          });
                          if ($scope.isUnique) {
                              $scope.saveAsForm[controlName].$setValidity('unique', true);
                          }
                          else {
                              $scope.saveAsForm[controlName].$setValidity('unique', false);
                          }                          
                      };                      

                      $scope.create = function () {                          
                          $mdDialog.hide($scope.newHierarchySetName);
                      }
                  }
              }).then(function (newName) {
                  $rootScope.promise = hierarchySetDataFactory.saveAsNewHierarchySet(rowEntity.Id, newName).then(function () {
                      $rootScope.promise = hierarchySetDataFactory.getHierarchySetList().success(function (hierarchySetList) {
                          $scope.hierarchySetList = hierarchySetList;
                      }).error(function (error) {
                          console.log(error);
                      });
                  });
              });
          };

          $scope.saveAsLatestHierarchySet = function (rowEntity) {

              $rootScope.promise = hierarchySetDataFactory.saveAsLatestHierarchySet(rowEntity.Id).then(function () {
                  $rootScope.promise = hierarchySetDataFactory.getHierarchySetList().success(function (hierarchySetList) {
                      $scope.hierarchySetList = hierarchySetList;
                  }).error(function (error) {
                      console.log(error);
                  });
              });
          };

      }]);
