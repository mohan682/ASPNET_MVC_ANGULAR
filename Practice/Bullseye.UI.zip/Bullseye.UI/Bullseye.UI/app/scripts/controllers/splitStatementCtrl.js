﻿angular.module('bullseyeApp').controller('splitStatementCtrl', ['$rootScope', '$scope', '$mdDialog', '$q', 'record', 'hierarchyDataFactory',
    'applicationConfigDataFactory', 'statementTypeDataFactory', 'businessUnitDataFactory', 'hierarchySetService',
    function ($rootScope, $scope, $mdDialog, $q, record, hierarchyDataFactory,
        applicationConfigDataFactory, statementTypeDataFactory, businessUnitDataFactory, hierarchySetService) {               

        $scope.monthAllowed = false;
        $scope.firstQuarterMonths = [null, "JAN", "FEB", "MAR"];
        $scope.secondQuarterMonths = [null, "APR", "MAY", "JUN"];
        $scope.thirdQuarterMonths = [null, "JUL", "AUG", "SEP"];
        $scope.fourthQuarterMonths = [null, "OCT", "NOV", "DEC"];
        $scope.months = [null];
        var initializeMonths = function (quarter) {
            if (quarter) {
                if (quarter == 1)
                    $scope.months = $scope.firstQuarterMonths;
                if (quarter == 2)
                    $scope.months = $scope.secondQuarterMonths;
                if (quarter == 3)
                    $scope.months = $scope.thirdQuarterMonths;
                if (quarter == 4)
                    $scope.months = $scope.fourthQuarterMonths;
            }
        };
        initializeMonths(record.Quarter);
        if (record.Quarter === "0")
            $scope.monthAllowed = false;
        else
            $scope.monthAllowed = true;
        $scope.selectedRecord = { BusinessUnit: record.BusinessUnit, Quarter: record.Quarter, Year: record.Year, StatementType: record.StatementType, Month: record.Month };
        
        var getConfigData = function () {
            var promises = [];
            var appConfigDefer = $q.defer();
            applicationConfigDataFactory.getApplicationConfigs().success(function (data) {
                $scope.applicationConfigs = data;
                //Find Years Past and Future
                angular.forEach(data, function (item) {
                    if (item.KeyName === 'YearsFuture') {
                        $scope.YearsFuture = parseInt(item.Value, 10) || 0;
                    }
                    else if (item.KeyName === 'YearsPast') {
                        $scope.YearsPast = parseInt(item.Value, 10) || 0;
                    }
                }, this);
                appConfigDefer.resolve();
            });
            promises.push(appConfigDefer.promise);            
            return $q.all(promises);
        };

        function getValidYears() {
            var validYears = [];
            var currentYear = new Date().getFullYear();
            for (var i = $scope.YearsPast * -1; i <= $scope.YearsFuture; i++)
                validYears.push(currentYear + i);
            $scope.years = validYears;
            //$scope.selectedRecord.Year = currentYear;
        };

        $rootScope.promise = getConfigData().then(function () {
            getValidYears();
        });

        var getData = function () {
            var promises = [];
            var stDefer = $q.defer();
            statementTypeDataFactory.getStatementTypeList().success(function (data) {
                $scope.statementTypes = data;
                if ($scope.selectedRecord.StatementType == null)
                    $scope.selectedRecord.StatementType = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            var buDefer = $q.defer();
            businessUnitDataFactory.getBusinessUnitList().success(function (data) {
                $scope.businessUnits = data;
                if ($scope.selectedRecord.BusinessUnit == null)
                    $scope.selectedRecord.BusinessUnit = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            return $q.all(promises);
        };

        $rootScope.promise = getData();

        $scope.quarters =
            [{ Name: '-', Id: 0 },
            { Name: '1Q', Id: 1 },
            { Name: '2Q', Id: 2 },
            { Name: '3Q', Id: 3 },
            { Name: '4Q', Id: 4 }];

        //$scope.selectedRecord.Quarter = $scope.quarters[0].Id;        

        $scope.quarterChanged = function () {
            $scope.selectedRecord.Month = null;
            if ($scope.selectedRecord.Quarter === "0")
                $scope.monthAllowed = false;
            else {
                $scope.monthAllowed = true;

                switch ($scope.selectedRecord.Quarter) {
                    case "1":
                        $scope.months = $scope.firstQuarterMonths;
                        break;
                    case "2":
                        $scope.months = $scope.secondQuarterMonths;
                        break;
                    case "3":
                        $scope.months = $scope.thirdQuarterMonths;
                        break;
                    case "4":
                        $scope.months = $scope.fourthQuarterMonths;
                        break;
                }
            }
        };

        $rootScope.promise = hierarchyDataFactory.getHierarchy(record.RBHierarchy.Id).then(function (rbHierarchy) {
            $scope.rbHierarchy = hierarchySetService.getMultiSelectableTree(rbHierarchy.data);            
            $scope.rbHierarchy[0].selected = true;
            $scope.rbTree = hierarchySetService.getMultiSelectableTree(rbHierarchy.data);
        });

        $scope.selectOnlyN = function (item, selectedItems, count) {
            if (selectedItems != null && selectedItems.length >= count) {                
                return false;
            } else {
                return true;
            }
        };

        $scope.isValidForSave = function () {            
            if ($scope.selectedRbNode && $scope.selectedRbNode.length && $scope.selectedRbNode.length === 1) {
                if ($scope.selectedRbNode[0].name != $scope.selectedRecord.BusinessUnit)
                    $scope.nonMatchedBusinessUnitMessage = "*Business Unit and selected RB Node do not match";
                else
                    $scope.nonMatchedBusinessUnitMessage = "";
                return true;
            }
            $scope.nonMatchedBusinessUnitMessage = "";
            return false;
        };

        var isParentSelected = function (node) {
            if (node.parent && node.parent.selected)
                return true;
            else if (node.parent) {
                return isParentSelected(node.parent);
            }
            else
                return false;
        };

        $scope.allowKpiCalc = function () {
            if ($scope.selectedLevel && $scope.selectedLevel.length
                && $scope.selectedRbNodes && $scope.selectedRbNodes.length)
                return true;
            return false;
        };

        $scope.canSelectNode = function (node) {
            var canSelect = true;        
            if (canSelect && !node.selected && node.children && node.children.length) {
                angular.forEach(node.children, function (child) {
                    if (canSelect) {
                        var canSelectChild = $scope.canSelectNode(child);
                        if (child.selected) {
                            canSelect = false;
                        }
                        else if (!canSelectChild) {
                            canSelect = false;
                        }
                    }
                });
            }

            if (canSelect && !node.selected && node.parent) {
                if (node.parent.selected)
                    canSelect = false;
                else
                    canSelect = !isParentSelected(node.parent);
            }
            return canSelect;
        };


        $scope.levelList = [{ id: 1, name: 1 },
            { id: 2, name: 2 },
            { id: 3, name: 3 },
            { id: 4, name: 4, selected: true },
            { id: 5, name: 5 },
            { id: 6, name: 6 },
            { id: 7, name: 7 },
            { id: 8, name: 8 },
            { id: 9, name: 9 },
            { id: 10, name: 10 }
        ];    

        $scope.getValidLevels = function () {
            return $scope.levelList;
        };

        $scope.ok = function () {
            var selectedRbNodeIdList = [];
            angular.forEach($scope.selectedRbNodes, function (rbNode) {
                selectedRbNodeIdList.push(rbNode.id);
            });
            var selectedLevel = 4;
            angular.forEach($scope.selectedLevel, function (level) {
                selectedLevel = level.id;
            });        

            var kpiCalculationTypes = [];
            if ($scope.calculateKPIPlan)
                kpiCalculationTypes.push("plan");
            if ($scope.calculateKPIForecast)
                kpiCalculationTypes.push("forecast");
            if ($scope.calculateKPIFbw)
                kpiCalculationTypes.push("fbw");
            if ($scope.calculateKPIReportedValue)
                kpiCalculationTypes.push("reportedvalue");

            var kpiOptions = { };            
            
            var options = {
                sourceRecordId: record.Id, 
                rbNodeId: $scope.selectedRbNode[0].id, 
                year: $scope.selectedRecord.Year,
                statementType: $scope.selectedRecord.StatementType,                
                businessUnit: $scope.selectedRecord.BusinessUnit,
                quarter: $scope.selectedRecord.Quarter,
                description: $scope.selectedRecord.Description,
                month: $scope.selectedRecord.Month,
                kpiOptions: kpiCalculationTypes,
                SelectedRbNodeIdList: selectedRbNodeIdList,
                SelectedHierarchyNodeLevel: selectedLevel,
                hierarchySetName: record.HierarchySetName
            };
            if (options.month === undefined || options.month === '')
                options.month = null;
            $mdDialog.hide(options);
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);