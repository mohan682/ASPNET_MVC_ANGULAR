﻿angular.module('bullseyeApp').controller('auditLogDetailCtrl', ['$scope', '$mdDialog', 'auditLogDetails',
    function ($scope, $mdDialog, auditLogDetails) {

        $scope.showAuditLogTable = false;

        if (auditLogDetails && auditLogDetails.length > 0) {
            $scope.auditLogRecords = auditLogDetails;
            $scope.showAuditLogTable = true;         
        }      

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);