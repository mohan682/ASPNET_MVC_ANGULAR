﻿angular.module('bullseyeApp').controller('uploadHierarchyCtrl', ['$rootScope', '$scope', '$mdDialog', 'hierarchyTypes', 'rbHierarchyImportExportDataFactory',
function ($rootScope, $scope, $mdDialog, hierarchyTypes, rbHierarchyImportExportDataFactory) {
    $scope.message = "Please Wait...";

    $scope.selectedFileName = "";
    $scope.pathList = [];
    $scope.files = [];

    $scope.uploadPromise = rbHierarchyImportExportDataFactory.getRbHierarchyFileNames().then(function (response) {
        $scope.files = response.data.Result;
    });

    //$scope.hierarchyTypes = hierarchyTypes;
    
    //$scope.hierarchyTypeChanged = function () {
    //    $scope.selectedFileName = "";
    //    $scope.pathList = [];
    //    $scope.files = [];
    //    var selectedId = $scope.selectedHierarchyType.Id;
    //    switch (selectedId) {
    //        case 0:                
    //            //Fill in if FS upload is needed.         
    //            break;
    //        case 1:
             
    //            break;
    //    }
    //};
    
    //$scope.selectedFileName = "";
    $scope.totalDisplayed = 20;

    $scope.upload = function () {
        $scope.totalDisplayed = 20;        
        $mdDialog.hide({ hierarchyTypeId: 1, selectedFileName: $scope.selectedFileName });
    };

    $scope.showMore = function () {
        $scope.totalDisplayed += 20;
    };

    $scope.areAllItemsDisplayed = function () {
        return $scope.uploadErrors == null || $scope.totalDisplayed >= $scope.uploadErrors.length;
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };
}]);