﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:hierarchyDetailCtrl
 * @description
 * # HiearchyDetailCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('hierarchySetDetailCtrl', ['$q', '$rootScope', '$scope', '$location', '$routeParams', '$timeout', '$mdToast', '$mdDialog',
      'hierarchySetDataFactory', 'hierarchyNodeDataFactory', 'accountTypeDataFactory', 'dividendPartnerDataFactory', 'regionsDataFactory', 'tagDataFactory',
      'tprMappingDataFactory', 'fbwMappingDataFactory', 'rbHierarchyImportExportDataFactory',
      function ($q, $rootScope, $scope, $location, $routeParams, $timeout, $mdToast, $mdDialog,
          hierarchySetDataFactory, hierarchyNodeDataFactory, accountTypeDataFactory, dividendPartnerDataFactory, regionsDataFactory, tagDataFactory,
          tprMappingDataFactory, fbwMappingDataFactory, rbHierarchyImportExportDataFactory) {

          var hierarchyTypes = { FsHierarchy: 1, RbHierarchy: 2 };

          $scope.sourceEditTypeList = [
            {
                Id: 0, Name: "Feed"
            },
            {
                Id: 1, Name: "Calc"
            },
            {
                Id: 2, Name: "Sum"
            }
          ];

          $scope.fsNodeEnumList = [
            { Id: 0, Name: "Gross Margin" },
            { Id: 1, Name: "Fixed Assets" },
            { Id: 2, Name: "Fixed Assets PP" },
            { Id: 3, Name: "Underlying WC Balance" },
            { Id: 4, Name: "Underlying WC Balance PP" },
            { Id: 5, Name: "Discounting WC Balance" },
            { Id: 6, Name: "Discounting WC Balance PP" },
            { Id: 7, Name: "Long Term Provisions" },
            { Id: 8, Name: "Long Term Provisions PP" },
            { Id: 9, Name: "Other Balance Sheet Items" },
            { Id: 10, Name: "Other Balance Sheet Items PP" },
            { Id: 11, Name: "TWC Balance" },
            { Id: 12, Name: "TWC Balance PP" },
            { Id: 13, Name: "Return on WC" },
            { Id: 14, Name: "Return on Avg Capital Employed" },
            { Id: 15, Name: "Cost Cover Ratio" },
            { Id: 21, Name: "Pre Bonus GM" },
            { Id: 23, Name: "Underlying RCOP" },
            { Id: 24, Name: "Fixed Cash Costs (Direct)" },
            { Id: 25, Name: "Fixed Cash Costs (Allocated)" }
          ];

          $scope.rbNodeEnumList = [
            { Id: 16, Name: "IST" },
            { Id: 17, Name: "Treasury" },
            { Id: 18, Name: "Gas" },
            { Id: 19, Name: "GO" },
            { Id: 22, Name: "RB Adjustment (Oil)" },
          ];

          $scope.nodeTagList = [];
          $scope.nodeDividendPartnerTagList = [];

          $scope.showNodeUpdate = function (message) {
              if ($scope.viewType != 'view') {
                  $mdToast.show(
                      $mdToast.simple()
                        .textContent(message)
                        .position('bottom right')
                        .hideDelay(3000)
                    );
              }
          };

          var fsHierarchyTree = $('#fsHierarchyTree').treeview({
              data: [],
              showBorder: false
          });

          var rbHierarchyTree = $('#rbHierarchyTree').treeview({
              data: [],
              showBorder: false
          });

          var nextGeneratedId = 0;

          var addTreeNode = function (node) {
              var convertedNode = { generatedId: nextGeneratedId };
              if (node.Children && node.Children.length) {
                  convertedNode.nodes = [];
                  angular.forEach(node.Children, function (childNode) {
                      nextGeneratedId = nextGeneratedId + 1;
                      convertedNode.nodes.push(addTreeNode(childNode));
                  });
              }

              convertedNode.text = node.Name;
              convertedNode.OriginalNode = node;
              convertedNode.Id = node.Id;
              return convertedNode;
          };

          var getTree = function (treeData) {
              var tree = [];
              angular.forEach(treeData.RootNodes, function (rootNode) {
                  nextGeneratedId = nextGeneratedId + 1;
                  tree.push(addTreeNode(rootNode));
              });
              return tree;
          };
          var processNodeDetails = function (nodeDetails, hierarchyType) {
              if (hierarchyType === hierarchyTypes.FsHierarchy) {
                  $scope.rbNodeDetails = null;
                  $scope.fsNodeDetails = nodeDetails;
                  angular.forEach(nodeDetails.FbwHierarchyNodeMapList, function (item) {
                      if (item.Region == null)
                          item.Region = { Name: '' };
                  });
              }
              else if (hierarchyType === hierarchyTypes.RbHierarchy) {
                  $scope.fsNodeDetails = null;
                  $scope.rbNodeDetails = nodeDetails;
              }
              $scope.nodeDetails = nodeDetails;
              angular.forEach(nodeDetails.HierarchyNode.SourceDataTypes, function (sourceDataType) {
                  if (sourceDataType.SourceType.Name.toLowerCase() === "tpr")
                      $scope.tprEditType = sourceDataType;
                  else if (sourceDataType.SourceType.Name.toLowerCase() === "fbw")
                      $scope.fbwEditType = sourceDataType;
                  else if (sourceDataType.SourceType.Name.toLowerCase() === "plan")
                      $scope.planEditType = sourceDataType;
                  else if (sourceDataType.SourceType.Name.toLowerCase() === "forecast")
                      $scope.forecastEditType = sourceDataType;
                  else if (sourceDataType.SourceType.Name.toLowerCase() === "wc")
                      $scope.wcEditType = sourceDataType;
              });
              $scope.nodeTagList = [];
              $scope.nodeDividendPartnerTagList = [];
              angular.forEach(nodeDetails.HierarchyNodeDivPartnerTagList, function (tag) {
                  if (tag.DividendPartner == null) {
                      $scope.nodeTagList.push(tag);
                  }
                  else {
                      $scope.nodeDividendPartnerTagList.push(tag);
                  }
              });
              $scope.setDivPartnerTags();
          };

          var getNodeData = function (nodeId, hierarchyType, isTempNode) {
              $rootScope.promise = hierarchyNodeDataFactory.getNodeDetails(nodeId, isTempNode).success(
                      function (nodeDetails) {
                          processNodeDetails(nodeDetails, hierarchyType);
                          if ($scope.fsNodeDetails)
                              $scope.accountTypeChanged($scope.fsNodeDetails.HierarchyNode.AccountType.Id);
                      });
          };

          $scope.isFormValid = function () {
              return !$scope.hierarchySetDetailForm.$invalid;
          };

          $scope.showNodesWithData = function () {
              $mdDialog.show({
                  parent: angular.element(document.body),
                  template:
                    '<md-dialog aria-label="Nodes with Data">' +
                    '   <md-toolbar style="background-color:rgb(255,87,34)">' +
                    '       <div class="md-toolbar-tools">' +
                    '           <h3>Nodes with Data</h3>' +
                    '       </div>' +
                    '   </md-toolbar>' +
                    '  <md-dialog-content layout-padding>' +
                    '    <div><ul><li ng-repeat="item in items track by $index">' +
                    '       {{item}}' +
                    '    </li></ul></div>' +
                    '  </md-dialog-content>' +
                    '  <md-dialog-actions>' +
                    '    <md-button ng-click="closeDialog()" class="md-warn">' +
                    '      Close' +
                    '    </md-button>' +
                    '  </md-dialog-actions>' +
                    '</md-dialog>',
                  locals: {
                      items: $scope.nodeDetails.NodeDataReferences
                  },
                  controller: function DialogController($scope, $mdDialog, items) {
                      $scope.items = items;
                      $scope.closeDialog = function () {
                          $mdDialog.hide();
                      }
                  }
              });
          };

          var fsNodeSelectionChanged = function (node, isSelected) {
              if ($scope.isFormValid()) {
                  if (isSelected) {
                      $scope.fsTreeNode = node;
                      if ($scope.nodeDetails && $scope.viewType != 'view') {
                          //fsHierarchyTree.treeview('updateNodeText', [node, $scope.nodeDetails.HierarchyNode.Name]);
                          $scope.nodeBeingSaved = $scope.nodeDetails.HierarchyNode.Name;
                          $rootScope.promise = hierarchyNodeDataFactory.saveNodeDetails($scope.nodeDetails).success(function () {
                              getNodeData(node.Id, hierarchyTypes.FsHierarchy, node.OriginalNode.IsTempNode);
                              $scope.showNodeUpdate($scope.nodeBeingSaved + " saved.");
                          });
                      }
                      else {
                          getNodeData(node.Id, hierarchyTypes.FsHierarchy, node.OriginalNode.IsTempNode);
                      }
                  }
                  else {
                      if ($scope.viewType != 'view') {
                          fsHierarchyTree.treeview('updateNodeText', [node, $scope.fsNodeDetails.HierarchyNode.Name]);
                          $scope.nodeBeingSaved = $scope.nodeDetails.HierarchyNode.Name;
                          $rootScope.promise = hierarchyNodeDataFactory.saveNodeDetails($scope.nodeDetails).success(function () {
                              $scope.showNodeUpdate($scope.nodeBeingSaved + " saved.");
                          });
                      }
                      $scope.fsNodeDetails = null;
                      //$scope.rbNodeDetails = null;
                      $scope.nodeDetails = null;
                  }
              }
          };

          var loadTagsBackToNode = function () {
              $scope.nodeDetails.HierarchyNodeDivPartnerTagList = [];
              angular.forEach($scope.nodeTagList, function (item) {
                  if (!item.HierarchyNodeId)
                      item.HierarchyNodeId = $scope.nodeDetails.HierarchyNode.Id;
                  $scope.nodeDetails.HierarchyNodeDivPartnerTagList.push(item);
              });

              angular.forEach($scope.dividendPartnerList, function (divPartner) {
                  angular.forEach(divPartner.TagList, function (item) {
                      if (!item.HierarchyNodeId)
                          item.HierarchyNodeId = $scope.nodeDetails.HierarchyNode.Id;
                      item.DividendPartner = angular.copy(divPartner);
                      $scope.nodeDetails.HierarchyNodeDivPartnerTagList.push(item);
                  });
              });
          };

          $scope.isHierarchySetNameUnique = function () {
              $scope.isUnique = true;
              var controlName = 'txtHierarchySetName';
              angular.forEach($scope.hierarchySetList, function (hs) {
                  if (hs.Name === $scope.hierarchySet.Name && hs.Id !== $scope.hierarchySet.Id)
                      $scope.isUnique = false;
              });
              if ($scope.isUnique) {
                  $scope.hierarchySetDetailForm[controlName].$setValidity('unique', true);
              }
              else {
                  $scope.hierarchySetDetailForm[controlName].$setValidity('unique', false);
              }
          };

          $scope.nodeNameUpdated = function (node, controlName, hierarchyType) {
              var nodes = [];
              if (hierarchyType === hierarchyTypes.FsHierarchy) {
                  nodes = fsHierarchyTree.treeview('getNodes');
              }
              else if (hierarchyType === hierarchyTypes.RbHierarchy) {
                  nodes = rbHierarchyTree.treeview('getNodes');
              }
              var isUnique = true;
              var isEmpty = false;
              angular.forEach(nodes, function (existingNode) {
                  if (existingNode.text === node.Name && existingNode.Id !== node.Id) {
                      //isUnique = false;
                        //disabling this check, remove duplicate nodes check for the new 2017 hierarchy. PBI-78234.
                  }
              });

              if (!node.Name)
                  isEmpty = true;

              $scope.hierarchySetDetailForm[controlName].$setValidity('unique', isUnique);
              $scope.hierarchySetDetailForm[controlName].$setValidity('required', !isEmpty);
          };

          var rbNodeSelectionChanged = function (node, isSelected) {
              if ($scope.isFormValid()) {
                  if (isSelected) {
                      $scope.rbTreeNode = node;
                      if ($scope.nodeDetails && $scope.viewType != 'view') {
                          //rbHierarchyTree.treeview('updateNodeText', [node, $scope.nodeDetails.HierarchyNode.Name]);
                          $scope.nodeBeingSaved = $scope.nodeDetails.HierarchyNode.Name;
                          //Load tags
                          loadTagsBackToNode();
                          $rootScope.promise = hierarchyNodeDataFactory.saveNodeDetails($scope.nodeDetails).success(function () {
                              getNodeData(node.Id, hierarchyTypes.RbHierarchy, node.OriginalNode.IsTempNode);
                              $scope.showNodeUpdate($scope.nodeBeingSaved + " saved.");
                          });
                      }
                      else {
                          getNodeData(node.Id, hierarchyTypes.RbHierarchy, node.OriginalNode.IsTempNode)
                      }
                  }
                  else {
                      if ($scope.viewType != 'view') {
                          rbHierarchyTree.treeview('updateNodeText', [node, $scope.rbNodeDetails.HierarchyNode.Name]);
                          $scope.nodeBeingSaved = $scope.nodeDetails.HierarchyNode.Name;
                          //Load tags
                          loadTagsBackToNode();
                          $rootScope.promise = hierarchyNodeDataFactory.saveNodeDetails($scope.nodeDetails).success(function () {
                              $scope.showNodeUpdate($scope.nodeBeingSaved + " saved.");
                          });
                      }
                      //$scope.fsNodeDetails = null;
                      $scope.rbNodeDetails = null;
                      $scope.nodeDetails = null;
                  }
              }
          };

          var findNode = function (generatedId, nodes) {
              var foundNode = null;
              angular.forEach(nodes, function (node) {
                  if (node.generatedId === generatedId)
                      foundNode = node;
                  if (foundNode == null) {
                      if (node.nodes && node.nodes.length) {
                          //angular.forEach(node.nodes, function (childNode) {
                          var foundChildNode = findNode(generatedId, node.nodes);
                          if (foundChildNode != null)
                              foundNode = foundChildNode;
                          //});
                      }
                  }
              });
              return foundNode;
          };

          var findTreeNode = function (tree, id) {
              var nodes = tree.getEnabled();
              var response = {};
              angular.forEach(nodes, function (node) {
                  if (node.Id === id)
                      response = node;
              });
              return response;
          }

          var fsAddNode = function (parentNode) {
              var node = findNode(parentNode.generatedId, $scope.fsTreeView);
              nextGeneratedId = nextGeneratedId + 1;
              var newNode = { text: node.text + " - Child", selectable: true, generatedId: nextGeneratedId, state: {} };
              newNode.OriginalNode = parentNode.OriginalNode;
              newNode.OriginalNode.NodeEnum = null;

              $mdDialog.show({
                  controller: 'addNodeCtrl',
                  templateUrl: 'app/templates/addNode.tmpl.html',
                  parent: angular.element(document.body),
                  locals: {
                      newNode: newNode,
                      isFsNode: true,
                      accountTypeList: $scope.accountTypeList,
                      sourceEditTypeList: $scope.sourceEditTypeList
                  }
              }).then(function (newNode) {
                  newNode.OriginalNode.Name = newNode.text;
                  newNode.OriginalNode.AccountType = parentNode.OriginalNode.AccountType;
                  newNode.OriginalNode.Reverse = parentNode.OriginalNode.Reverse;
                  newNode.OriginalNode.TempParentId = null;
                  newNode.OriginalNode.OriginalParentId = null;
                  newNode.OriginalNode.OriginalParentId = parentNode.OriginalNode.Id;
                  newNode.OriginalNode.IsTempNode = true;
                  newNode.OriginalNode.Id = null;
                  $rootScope.promise = hierarchyNodeDataFactory.createNode(newNode.OriginalNode).success(function (createResult) {
                      if (createResult.IsSuccessful) {
                          var newNodeId = createResult.NodeId;
                          getHierarchySetDetail().then(function () {
                              var node = findTreeNode(fsHierarchyTree.treeview(true), newNodeId);
                              fsHierarchyTree.treeview('revealNode', [node]);
                              fsHierarchyTree.treeview('selectNode', [node])
                          });
                      }
                      else {
                          $mdDialog.show(
                              $mdDialog.alert()
                              .parent(document.body)
                              .clickOutsideToClose(false)
                              .title('Error in Creating Node')
                              .content(createResult.Message)
                              .ariaLabel('Error')
                              .ok('OK')
                          );
                      }
                  }).error(function (message) {
                      console.log(message);
                  });


              }, function () {
              });
          };

          var rbAddNode = function (parentNode) {
              var node = findNode(parentNode.generatedId, $scope.rbTreeView);
              nextGeneratedId = nextGeneratedId + 1;
              var newNode = { text: node.text + " - Child", selectable: true, generatedId: nextGeneratedId, state: {} };
              newNode.OriginalNode = parentNode.OriginalNode;
              newNode.OriginalNode.NodeEnum = null;

              $mdDialog.show({
                  controller: 'addNodeCtrl',
                  templateUrl: 'app/templates/addNode.tmpl.html',
                  parent: angular.element(document.body),
                  locals: {
                      newNode: newNode,

                      isFsNode: false,
                      accountTypeList: $scope.accountTypeList,
                      sourceEditTypeList: $scope.sourceEditTypeList
                  }
              }).then(function (newNode) {
                  newNode.OriginalNode.Name = newNode.text;
                  newNode.OriginalNode.AccountType = parentNode.OriginalNode.AccountType;
                  newNode.OriginalNode.Reverse = parentNode.OriginalNode.Reverse;
                  newNode.OriginalNode.TempParentId = null;
                  newNode.OriginalNode.OriginalParentId = null;
                  newNode.OriginalNode.OriginalParentId = parentNode.OriginalNode.Id;
                  newNode.OriginalNode.IsTempNode = true;
                  newNode.OriginalNode.Id = null;

                  $rootScope.promise = hierarchyNodeDataFactory.createNode(newNode.OriginalNode).success(function (createResult) {
                      if (createResult.IsSuccessful) {
                          var newNodeId = createResult.NodeId;
                          getHierarchySetDetail().then(function () {
                              var node = findTreeNode(rbHierarchyTree.treeview(true), newNodeId);
                              rbHierarchyTree.treeview('revealNode', [node]);
                              rbHierarchyTree.treeview('selectNode', [node])
                          });
                      }
                      else {
                          $mdDialog.show(
                              $mdDialog.alert()
                              .parent(document.body)
                              .clickOutsideToClose(false)
                              .title('Error in Creating Node')
                              .content(createResult.Message)
                              .ariaLabel('Error')
                              .ok('OK')
                          );
                      }
                  }).error(function (message) {
                      console.log(message);
                  });


              }, function () {
              });
          };

          var fsDeleteNode = function (node) {
              deleteNode(node);
          };

          var rbDeleteNode = function (node) {
              deleteNode(node);
          };

          var deleteNode = function (node) {
              var confirm = $mdDialog.confirm()
                                          .title('Confirmation')
                                          .content('Are you sure you want to delete this node?')
                                          .ariaLabel('Confirmation')
                                          .ok('OK')
                                          .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  $rootScope.promise = hierarchyNodeDataFactory.deleteNode(node.Id).success(function (deleteResult) {
                      if (deleteResult.length) {
                          //Show the list of nodes that have data
                          $mdDialog.show({
                              parent: angular.element(document.body),
                              template:
                                '<md-dialog aria-label="Nodes with Data">' +
                                '   <md-toolbar style="background-color:rgb(255,87,34)">' +
                                '       <div class="md-toolbar-tools">' +
                                '           <h3>Unable to delete</h3>' +
                                '       </div>' +
                                '   </md-toolbar>' +
                                '  <md-dialog-content layout-padding>' +
                                '    <h4>Selected node couldn\'t be deleted:</h4>' +
                                '    <div><ul><li ng-repeat="item in items track by $index">' +
                                '       {{item}}' +
                                '    </li></ul></div>' +
                                '  </md-dialog-content>' +
                                '  <md-dialog-actions>' +
                                '    <md-button ng-click="closeDialog()" class="md-warn">' +
                                '      Close' +
                                '    </md-button>' +
                                '  </md-dialog-actions>' +
                                '</md-dialog>',
                              locals: {
                                  items: deleteResult
                              },
                              controller: function DialogController($scope, $mdDialog, items) {
                                  $scope.items = items;
                                  $scope.closeDialog = function () {
                                      $mdDialog.hide();
                                  }
                              }
                          });
                      }
                      else {
                          $scope.fsNodeDetails = null;
                          $scope.rbNodeDetails = null;
                          $scope.nodeDetails = null;
                          var confirm = $mdDialog.alert()
                                                 .title('Delete Successful')
                                                 .content('Selected node has been deleted. Hierarchy set will be refreshed.')
                                                 .ariaLabel('Deleted')
                                                 .ok('OK');
                          $mdDialog.show(confirm).then(function () {
                              getHierarchySetDetail();
                          });
                      }
                  });
              });
          }

          var fsMoveNode = function (node) {
              moveNode(node, hierarchyTypes.FsHierarchy);
          };

          var rbMoveNode = function (node) {
              moveNode(node, hierarchyTypes.RbHierarchy);
          };

          var moveNode = function (node, hierarchyType) {
              $rootScope.promise = hierarchyNodeDataFactory.getNodeDataReferences(node.Id).success(function (nodeDataReferences) {
                  if (nodeDataReferences.length) {
                      //Show the list of nodes that have data
                      $mdDialog.show({
                          parent: angular.element(document.body),
                          template:
                            '<md-dialog aria-label="Nodes with Data">' +
                            '   <md-toolbar style="background-color:rgb(255,87,34)">' +
                            '       <div class="md-toolbar-tools">' +
                            '           <h3>Unable to move</h3>' +
                            '       </div>' +
                            '   </md-toolbar>' +
                            '  <md-dialog-content layout-padding>' +
                            '    <h4>Selected node couldn\'t be moved as the following nodes have data</h4>' +
                            '    <div><ul><li ng-repeat="item in items track by $index">' +
                            '       {{item}}' +
                            '    </li></ul></div>' +
                            '  </md-dialog-content>' +
                            '  <md-dialog-actions>' +
                            '    <md-button ng-click="closeDialog()" class="md-warn">' +
                            '      Close' +
                            '    </md-button>' +
                            '  </md-dialog-actions>' +
                            '</md-dialog>',
                          locals: {
                              items: nodeDataReferences
                          },
                          controller: function DialogController($scope, $mdDialog, items) {
                              $scope.items = items;
                              $scope.closeDialog = function () {
                                  $mdDialog.hide();
                              }
                          }
                      });
                  }
                  else {
                      var selectedTree = undefined;
                      if (hierarchyType === hierarchyTypes.FsHierarchy)
                          selectedTree = $scope.fsTreeView;
                      else if (hierarchyType === hierarchyTypes.RbHierarchy)
                          selectedTree = $scope.rbTreeView;
                      $mdDialog.show({
                          controller: 'moveNodeCtrl',
                          templateUrl: 'app/templates/moveNode.tmpl.html',
                          parent: angular.element(document.body),
                          locals: {
                              nodeToMove: node,
                              tree: selectedTree
                          }
                      }).then(function (destinationNode) {
                          $rootScope.promise = hierarchyNodeDataFactory.moveNode(node.Id, destinationNode.Id).success(function (nodeDataReferences) {

                              $scope.fsNodeDetails = null;
                              $scope.rbNodeDetails = null;
                              $scope.nodeDetails = null;
                              var confirm = $mdDialog.alert()
                                                     .title('Node move Successful')
                                                     .content('Selected node has been moved. Hierarchy set will be refreshed.')
                                                     .ariaLabel('Node move successful')
                                                     .ok('OK');
                              $mdDialog.show(confirm).then(function () {
                                  getHierarchySetDetail();
                              });
                          });
                      });

                  }
              });
          }

          var getHierarchySetDetail = function () {
              var defer = $q.defer();
              $rootScope.promise = hierarchySetDataFactory.getHierarchySet($scope.selectedHierarchySetId).success(function (hierarchySet) {
                  $rootScope.promise = regionsDataFactory.getRegions().then(function (regions) {
                      $scope.regions = regions;
                      var emptyRegion = { Name: '' };
                      $scope.regions.splice(0, 0, emptyRegion);
                  });
                  $scope.hierarchySet = hierarchySet;
                  $scope.fsHierarchy = hierarchySet.FinancialStatementHierarchy;
                  $scope.rbHierarchy = hierarchySet.RBHierarchy;
                  $scope.fsTreeView = getTree($scope.fsHierarchy);
                  $scope.rbTreeView = getTree($scope.rbHierarchy);
                  fsHierarchyTree = $('#fsHierarchyTree').treeview({
                      data: [],
                      showBorder: false
                  });
                  fsHierarchyTree.treeview(
                          {
                              data: $scope.fsTreeView,
                              onNodeUnselected: function (event, node) {
                                  fsNodeSelectionChanged(node, false);
                              },
                              onNodeSelected: function (event, node) {
                                  if ($scope.rbNodeDetails) {
                                      rbHierarchyTree.treeview('unselectNode', [$scope.rbTreeNode.nodeId]);
                                  }
                                  fsNodeSelectionChanged(node, true);
                              },
                              showAddNode: $scope.viewType !== 'view',
                              showDeleteNode: $scope.viewType !== 'view',
                              showMoveNode: $scope.viewType !== 'view',
                              onAddNodeClicked: function (event, node) { fsAddNode(node); },
                              onDeleteNodeClicked: function (event, node) { fsDeleteNode(node); },
                              onMoveNodeClicked: function (event, node) { fsMoveNode(node); }
                          });
                  rbHierarchyTree = $('#rbHierarchyTree').treeview({
                      data: [],
                      showBorder: false
                  });
                  rbHierarchyTree.treeview(
                          {
                              data: $scope.rbTreeView,
                              onNodeUnselected: function (event, node) {
                                  rbNodeSelectionChanged(node, false);
                              },
                              onNodeSelected: function (event, node) {
                                  if ($scope.fsNodeDetails) {
                                      fsHierarchyTree.treeview('unselectNode', [$scope.fsTreeNode.nodeId]);
                                  }
                                  rbNodeSelectionChanged(node, true);
                              },
                              showAddNode: $scope.viewType !== 'view',
                              showDeleteNode: $scope.viewType !== 'view',
                              showMoveNode: $scope.viewType !== 'view',
                              onAddNodeClicked: function (event, node) { rbAddNode(node); },
                              onDeleteNodeClicked: function (event, node) { rbDeleteNode(node); },
                              onMoveNodeClicked: function (event, node) { rbMoveNode(node); }
                          });

                  accountTypeDataFactory.getAccountTypeList().then(function (response) {
                      $scope.accountTypeList = response.data;
                      angular.forEach($scope.accountTypeList, function (accountType) {
                          if (accountType.Name === "CashFlow")
                              accountType.Info = "Sums up the monthly values to calculate time dimensions";
                          else if (accountType.Name === "BalanceSheet")
                              accountType.Info = "Treats monthly values as YTD figures while calculating the time dimensions";
                          else if (accountType.Name === "PriorPeriod")
                              accountType.Info = "1Q: Jan, 2Q: April, 3Q: July, 4Q: Oct, 1H: Jan, 2H: July, 3QTD: Jan, FY: Jan";
                      });
                  });

                  dividendPartnerDataFactory.getDividendPartners().then(function (response) {
                      angular.forEach(response, function (item) { item.TagList = [] });
                      $scope.dividendPartnerList = response;
                  });

                  defer.resolve();

              }).error(function (error) {
                  console.log(error);
                  defer.reject();
              });
              return defer.promise;
          };

          $scope.accountTypeChanged = function (accountTypeId) {
              angular.forEach($scope.accountTypeList, function (accountType) {
                  if (accountType.Id === accountTypeId) {
                      $scope.accountTypeInfo = accountType.Info;
                  }
              });
          };

          $scope.showInfoDetails = function () {
              $mdDialog.show({
                  parent: angular.element(document.body),
                  template:
                    '<md-dialog aria-label="Account type details">' +
                    '   <md-toolbar>' +
                    '       <div class="md-toolbar-tools">' +
                    '           <h3>Account Type Details</h3>' +
                    '       </div>' +
                    '   </md-toolbar>' +
                    '  <md-dialog-content layout-padding>' +
                    '    <h5><strong>CashFlow:</strong> Sums up the monthly values to calculate time dimensions</h5>' +
                    '    <h5><strong>BalanceSheet:</strong> Treats monthly values as YTD figures while calculating the time dimensions</h5>' +
                    '    <h5><strong>PriorPeriod:</strong> 1Q: Jan, 2Q: April, 3Q: July, 4Q: Oct, 1H: Jan, 2H: July, 3QTD: Jan, FY: Jan</h5>' +
                    '  </md-dialog-content>' +
                    '  <md-dialog-actions>' +
                    '    <md-button ng-click="closeDialog()" class="md-primary">' +
                    '      OK' +
                    '    </md-button>' +
                    '  </md-dialog-actions>' +
                    '</md-dialog>',
                  //locals: {
                  //    //items: deleteResult
                  //},
                  controller: function DialogController($scope, $mdDialog) {
                      $scope.closeDialog = function () {
                          $mdDialog.hide();
                      }
                  }
              });
          };

          $rootScope.promise.then(function () {
              if ($routeParams.hierarchySetId === undefined) {
                  //TODO:Creating a hierarchy              
              } else {
                  $scope.selectedHierarchySetId = $routeParams.hierarchySetId;
                  $scope.viewType = $routeParams.viewType;
                  $scope.areTagsReadOnly = $scope.viewType === 'view';
                  $rootScope.promise = hierarchySetDataFactory.getHierarchySetList().success(function (hierarchySetList) {
                      $scope.hierarchySetList = hierarchySetList;
                  }).error(function (error) {
                      console.log(error);
                  });
                  getHierarchySetDetail();
              }
          });

          $scope.onFSHierarchySearchChange = function () {
              fsHierarchyTree.treeview('search', [$scope.fsHierarchySearchTerm, { ignoreCase: true, exactMatch: false, revealResults: true }]);
          }

          $scope.onRBHierarchySearchChange = function () {
              rbHierarchyTree.treeview('search', [$scope.rbHierarchySearchTerm, { ignoreCase: true, exactMatch: false, revealResults: true }]);
          }

          var saveHierarchySet = function () {
              $rootScope.promise = hierarchySetDataFactory.saveHierarchySet($scope.selectedHierarchySetId, $scope.hierarchySet.Name)
                        .success(function () {
                            $location.path("/hierarchySetList/");
                        })
                        .error(function (error) {
                            console.log(error);
                        });
          };

          $scope.navigateToList = function () {
              if ($scope.fsNodeDetails)
                  $scope.nodeDetails = $scope.fsNodeDetails;
              else if ($scope.rbNodeDetails)
                  $scope.nodeDetails = $scope.rbNodeDetails;
              if ($scope.nodeDetails) {
                  $rootScope.promise = hierarchyNodeDataFactory.saveNodeDetails($scope.nodeDetails).success(function () { $location.path('/hierarchySetList/'); });
              }
              else {
                  $location.path('/hierarchySetList/');
              }
          }          

          $scope.saveHierarchySet = function () {
              $scope.saveHierarchySetTriggered = true;
              if ($scope.fsNodeDetails)
                  $scope.nodeDetails = $scope.fsNodeDetails;
              else if ($scope.rbNodeDetails) {
                  $scope.nodeDetails = $scope.rbNodeDetails;
                  loadTagsBackToNode();
              }
              if ($scope.nodeDetails) {
                  $rootScope.promise = hierarchyNodeDataFactory.saveNodeDetails($scope.nodeDetails).success(function () { saveHierarchySet() });
              }
              else {
                  saveHierarchySet();
              }
          };

          $scope.setDivPartnerTags = function () {
              angular.forEach($scope.dividendPartnerList, function (divPartner) {
                  var response = [];
                  angular.forEach($scope.nodeDividendPartnerTagList, function (item) {
                      if (item.DividendPartner.Id == divPartner.Id)
                          response.push(item);
                  });
                  divPartner.TagList = response;
              });
          };

          var loadTags = function () {
              return tagDataFactory.getTags().then(function (response) {
                  $scope.tags = response;
              });
          };

          $scope.dividendPartnerChanged = function (selectedDp) {
              $scope.dividendPartner = selectedDp;
          };

          $rootScope.promise = loadTags();

          $scope.querySearch = function (searchText, addedTags) {
              var results = [];
              var tagList = angular.copy($scope.tags);
              angular.forEach(tagList, function (tag) {
                  tag.isAvailable = true;
                  angular.forEach(addedTags, function (addedTag) {
                      if (tag.Name === addedTag.Tag.Name) {
                          tag.isAvailable = false;
                      }
                  });
              });
              if (searchText) {
                  var query = angular.lowercase(searchText);
                  //angular.forEach($scope.tags, function (tag) {
                  angular.forEach(tagList, function (tag) {
                      var tagName = angular.lowercase(tag.Name);
                      if (tagName.indexOf(query) === 0 && tag.isAvailable)
                          results.push({ Tag: tag });
                  });
              }

              return results;
          };
          $scope.mappingTypes = [
            {
                Id: 0, Name: "TPR"
            },
            {
                Id: 1, Name: "FBW RB"
            },
            {
                Id: 2, Name: "FBW FS"
            }
          ];
          $scope.uploadMappings = function()
          {
              //Show choice of types to upload              
                  $mdDialog.show({
                      controller: 'uploadMappingCtrl',
                      templateUrl: 'app/templates/uploadMapping.tmpl.html',
                      parent: angular.element(document.body),
                      locals: {
                          mappingTypes: $scope.mappingTypes
                      }
                  })
                      .then(function (selectionData) {
                          var mappingTypeId = selectionData.mappingTypeId;
                          var selectedFileName = selectionData.selectedFileName;
                          switch(mappingTypeId)
                          {
                              case 0:                                                                    
                                  $rootScope.promise = tprMappingDataFactory.loadTprMappingFile($scope.selectedHierarchySetId, selectedFileName).then(function (response) {
                                      $scope.tprMappingUpload = { loadResponse : response.data}
                                      $scope.isTprMappingUpload = true;
                                  });
                                  break;
                              case 1:
                                  $rootScope.promise = fbwMappingDataFactory.loadFbwMappingFileForRb($scope.selectedHierarchySetId, selectedFileName).then(function (response) {
                                      $scope.fbwMappingUpload = { loadResponse: response.data }
                                      $scope.isFbwMappingUpload = true;
                                  });
                                  break;
                              case 2:
                                  $rootScope.promise = fbwMappingDataFactory.loadFbwMappingFileForFs($scope.selectedHierarchySetId, selectedFileName).then(function (response) {
                                      $scope.fbwMappingUpload = { loadResponse: response.data }
                                      $scope.isFsFbwMappingUpload = true;
                                  });
                                  break;

                          }                          
                      }, function () {
                      });                            
          }

          $scope.cancelTprMappingUpload = function()
          {
              $scope.isTprMappingUpload = false;
              $scope.rbNodeDetails = null;
              $scope.nodeDetails = null;
              getHierarchySetDetail();
          }

          $scope.cancelFbwMappingUpload = function () {
              $scope.isFbwMappingUpload = false;
              $scope.isFsFbwMappingUpload = false;
              $scope.rbNodeDetails = null;
              $scope.nodeDetails = null;
              getHierarchySetDetail();
          }

          $scope.cancelRbHierarchyUpload = function () {
              $scope.isRbHierarchyUpload = false;
              $scope.rbNodeDetails = null;
              $scope.nodeDetails = null;
              getHierarchySetDetail();
          }

          $scope.exportMappings = function () {
              //Show choice of types to Export              
              $mdDialog.show({
                  controller: 'exportMappingCtrl',
                  templateUrl: 'app/templates/exportMapping.tmpl.html',
                  parent: angular.element(document.body),
                  locals: {
                      mappingTypes: $scope.mappingTypes
                  }
              })
                  .then(function (selectionData) {
                      var mappingTypeId = selectionData.mappingTypeId;
                      switch (mappingTypeId) {
                          case 0:
                              $rootScope.promise = tprMappingDataFactory.exportTprMappings($scope.selectedHierarchySetId).success(function(response) {
                                  var confirm = $mdDialog.alert()
                                                     .title('Export')
                                                     .content('TPR mappings successfully exported.')
                                                     .ariaLabel('TPR mappings successfully exported')
                                                     .ok('OK');

                                  $mdDialog.show(confirm);
                              });
                              break;
                          case 1:
                              $rootScope.promise = fbwMappingDataFactory.exportFbwMappingsForRb($scope.selectedHierarchySetId).success(function(response) {
                                  var confirm = $mdDialog.alert()
                                                     .title('Export')
                                                     .content('FBW RB mappings successfully exported.')
                                                     .ariaLabel('FBW RB mappings successfully exported')
                                                     .ok('OK');

                                  $mdDialog.show(confirm);
                              });
                              break;
                          case 2:
                              $rootScope.promise = fbwMappingDataFactory.exportFbwMappingsForFs($scope.selectedHierarchySetId).success(function (response) {
                                  var confirm = $mdDialog.alert()
                                                     .title('Export')
                                                     .content('FBW FS mappings successfully exported.')
                                                     .ariaLabel('FBW FS mappings successfully exported')
                                                     .ok('OK');

                                  $mdDialog.show(confirm);
                              });
                              break;
                      }
                  }, function () {
                  });
          }

          $scope.hierarchyTypes = [
          {
              Id: 0, Name: "FS"
          },
          {
              Id: 1, Name: "RB"
          }
                  ];

          $scope.uploadHierarchy = function () {
              //Show choice of types to upload              
              $mdDialog.show({
                  controller: 'uploadHierarchyCtrl',
                  templateUrl: 'app/templates/uploadHierarchy.tmpl.html',
                  parent: angular.element(document.body),
                  locals: {
                      hierarchyTypes: $scope.hierarchyTypes
                  }
              })
                  .then(function (selectionData) {
                      var hierarchyTypeId = selectionData.hierarchyTypeId;
                      var selectedFileName = selectionData.selectedFileName;
                      switch (hierarchyTypeId) {
                          case 0:
                              //If an FS upload is required in future, fill in the blanks here.
                              break;
                          case 1:
                              $rootScope.promise = rbHierarchyImportExportDataFactory.loadRbHierarchyFile($scope.selectedHierarchySetId, selectedFileName).then(function (response) {
                                  $scope.rbHierarchyUpload = { loadResponse: response.data }
                                  $scope.isRbHierarchyUpload = true;
                              });
                              break;

                      }
                  }, function () {
                  });
          }
          // Export RbHierarchy
          $scope.exportHierarchy = function () {
              $rootScope.promise = rbHierarchyImportExportDataFactory.exportRbHierarchy($scope.selectedHierarchySetId).success(function (response) {
                  var confirm = $mdDialog.alert()
                                     .title('Export')
                                     .content('RB hierarchy successfully exported.')
                                     .ariaLabel('RB hierarchy successfully exported')
                                     .ok('OK');

                  $mdDialog.show(confirm);
              });
          }
          // End - Export RbHierarchy


          var reloadHierarchySetDetail = function () {
              var defer = $q.defer();
              $rootScope.promise = hierarchySetDataFactory.getHierarchySet($scope.selectedHierarchySetId).success(function (hierarchySet) {
                  $rootScope.promise = regionsDataFactory.getRegions().then(function (regions) {
                      $scope.regions = regions;
                      var emptyRegion = { Name: '' };
                      $scope.regions.splice(0, 0, emptyRegion);
                  });
                  $scope.hierarchySet = hierarchySet;
                  $scope.fsHierarchy = hierarchySet.FinancialStatementHierarchy;
                  $scope.rbHierarchy = hierarchySet.RBHierarchy;
                  $scope.fsTreeView = getTree($scope.fsHierarchy);
                  $scope.rbTreeView = getTree($scope.rbHierarchy);
                  fsHierarchyTree = $('#fsHierarchyTree').treeview({
                      data: [],
                      showBorder: false
                  });
                  fsHierarchyTree.treeview(
                          {
                              data: $scope.fsTreeView,
                              onNodeUnselected: function (event, node) {
                                 // fsNodeSelectionChanged(node, false);
                              },
                              onNodeSelected: function (event, node) {
                                  if ($scope.rbNodeDetails) {
                                      rbHierarchyTree.treeview('unselectNode', [$scope.rbTreeNode.nodeId]);
                                  }
                               //   fsNodeSelectionChanged(node, true);
                              },
                              showAddNode: $scope.viewType !== 'view',
                              showDeleteNode: $scope.viewType !== 'view',
                              showMoveNode: $scope.viewType !== 'view',
                              onAddNodeClicked: function (event, node) { fsAddNode(node); },
                              onDeleteNodeClicked: function (event, node) { fsDeleteNode(node); },
                              onMoveNodeClicked: function (event, node) { fsMoveNode(node); }
                          });
                  rbHierarchyTree = $('#rbHierarchyTree').treeview({
                      data: [],
                      showBorder: false
                  });
                  rbHierarchyTree.treeview(
                          {
                              data: $scope.rbTreeView,
                              onNodeUnselected: function (event, node) {
                                //  rbNodeSelectionChanged(node, false);
                              },
                              onNodeSelected: function (event, node) {
                                  if ($scope.fsNodeDetails) {
                                      fsHierarchyTree.treeview('unselectNode', [$scope.fsTreeNode.nodeId]);
                                  }
                                //  rbNodeSelectionChanged(node, true);
                              },
                              showAddNode: $scope.viewType !== 'view',
                              showDeleteNode: $scope.viewType !== 'view',
                              showMoveNode: $scope.viewType !== 'view',
                              onAddNodeClicked: function (event, node) { rbAddNode(node); },
                              onDeleteNodeClicked: function (event, node) { rbDeleteNode(node); },
                              onMoveNodeClicked: function (event, node) { rbMoveNode(node); }
                          });

                  accountTypeDataFactory.getAccountTypeList().then(function (response) {
                      $scope.accountTypeList = response.data;
                      angular.forEach($scope.accountTypeList, function (accountType) {
                          if (accountType.Name === "CashFlow")
                              accountType.Info = "Sums up the monthly values to calculate time dimensions";
                          else if (accountType.Name === "BalanceSheet")
                              accountType.Info = "Treats monthly values as YTD figures while calculating the time dimensions";
                          else if (accountType.Name === "PriorPeriod")
                              accountType.Info = "1Q: Jan, 2Q: April, 3Q: July, 4Q: Oct, 1H: Jan, 2H: July, 3QTD: Jan, FY: Jan";
                      });
                  });

                  dividendPartnerDataFactory.getDividendPartners().then(function (response) {
                      angular.forEach(response, function (item) { item.TagList = [] });
                      $scope.dividendPartnerList = response;
                  });

                  defer.resolve();

              }).error(function (error) {
                  console.log(error);
                  defer.reject();
              });
              return defer.promise;
          };

      }]);
