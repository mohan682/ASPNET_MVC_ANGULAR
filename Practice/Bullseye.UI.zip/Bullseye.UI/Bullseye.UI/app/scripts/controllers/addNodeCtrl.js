﻿angular.module('bullseyeApp').controller('addNodeCtrl', ['$scope', '$mdDialog','newNode', 'isFsNode', 'accountTypeList','sourceEditTypeList',
    function ($scope, $mdDialog, newNode, isFsNode, accountTypeList, sourceEditTypeList) {
        $scope.node = newNode;
        $scope.isFsNode = isFsNode;
        $scope.accountTypeList = accountTypeList;
        $scope.sourceEditTypeList = sourceEditTypeList;

        angular.forEach($scope.node.OriginalNode.SourceDataTypes, function (sourceDataType) {
            if (sourceDataType.SourceType.Name.toLowerCase() === "tpr")
                $scope.tprEditType = sourceDataType;
            else if (sourceDataType.SourceType.Name.toLowerCase() === "fbw")
                $scope.fbwEditType = sourceDataType;
            else if (sourceDataType.SourceType.Name.toLowerCase() === "plan")
                $scope.planEditType = sourceDataType;
            else if (sourceDataType.SourceType.Name.toLowerCase() === "forecast")
                $scope.forecastEditType = sourceDataType;
            else if (sourceDataType.SourceType.Name.toLowerCase() === "wc")
                $scope.wcEditType = sourceDataType;
            sourceDataType.Id = null;
        });

        $scope.ok = function () {
            $mdDialog.hide($scope.node);
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);