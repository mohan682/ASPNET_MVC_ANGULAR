﻿angular.module('bullseyeApp').controller('deleteStatementConfirmationCtrl', ['$scope','$mdDialog',
    function ($scope, $mdDialog) {        
        $scope.deleteOption = 'JustThisStatement';        

        $scope.ok = function () {
            $mdDialog.hide($scope.deleteOption);
        };        

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);