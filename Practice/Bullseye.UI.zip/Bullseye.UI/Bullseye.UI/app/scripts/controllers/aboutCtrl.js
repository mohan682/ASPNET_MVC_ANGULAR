"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('aboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
