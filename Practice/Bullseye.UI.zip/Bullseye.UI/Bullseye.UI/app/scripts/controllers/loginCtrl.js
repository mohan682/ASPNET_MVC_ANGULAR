﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:LoginCtrl
 * @description
 * # LoginCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
    .controller('loginCtrl', [
        '$rootScope', '$scope', '$location', 'settingsDataFactory', 'rolesDataFactory', function ($rootScope, $scope, $location, settingsDataFactory, rolesDataFactory) {
            $scope.isUnauthorised = false;            
            $scope.isAuthorisingUser = false;            
            $rootScope.promise = settingsDataFactory.loadSettings().then(function (data) {
                if (data.Environment) {
                    $rootScope.environment = data.Environment;
                    $rootScope.title = "Bullseye - " + data.Environment;
                }
                else {
                    $rootScope.title = "Bullseye";
                }
                $scope.isAuthorisingUser = true;                
                rolesDataFactory.getUserRoles()
                    .then(function (roleObjects) {
                        var roles = [];
                        angular.forEach(roleObjects, function(role) {
                            roles.push(role.Name);
                        });
                        if (roles.length && $.inArray('BULLSEYE_PLATFORM', roles) !== -1) {
                            $rootScope.globals.roles = roles;
                            $location.path('/');
                        } else {
                            $scope.isUnauthorised = true;
                            //$location.path('/unauthorised');
                        }
                    });
            });
        }]);