﻿angular.module('bullseyeApp').controller('recordNodeInfoDetailCtrl', ['$rootScope','$scope', '$mdDialog', 'request', 'recordNodeInfoDataFactory',
    function ($rootScope, $scope, $mdDialog, request, recordNodeInfoDataFactory) {
        var getDetails = function (request) {
            $rootScope.promise = recordNodeInfoDataFactory.getRecordNodeInfoDetail(request).then(function (response) {
                $scope.recordNodeInfo = response.data;
                $scope.gridOptions.data = response.data.RecordNodeInfoItems;
            });
        }

        $scope.gridOptions = {
            enableFiltering: true,
            paginationPageSizes: [15, 25, 50],
            paginationPageSize: 15,
            columnDefs: [                
                {
                    field: 'FSNodeName', displayName: 'FS Node', cellTooltip: true
                },
                {
                    field: 'RBNodeName', displayName: 'RB Node', cellTooltip: true
                },
                {
                    field: 'DividendPartnerName', displayName: 'Div. Partner', cellTooltip: true
                },
                {
                    field: 'RegionName', displayName: 'Region', cellTooltip: true
                },
                {
                    field: 'Toggle', displayName: 'Toggle', cellTooltip: true
                },
                {
                    field: 'Value', displayName: 'Value', cellTooltip: true
                }
            ]
        };

        $scope.ExcludeZeros = false;

        $scope.ChangeExcludeZeros = function () {

            $scope.gridOptions.data = $scope.recordNodeInfo.RecordNodeInfoItems.filter(function(recordNodeInfo) {
                return ($scope.ExcludeZeros) ? recordNodeInfo.Value !== 0 : true;
            });
        };

        getDetails(request);
        $scope.ok = function () {
            $mdDialog.hide();
        };
    }]);