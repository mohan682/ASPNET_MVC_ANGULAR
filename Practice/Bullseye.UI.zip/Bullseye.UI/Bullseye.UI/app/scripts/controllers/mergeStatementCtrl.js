﻿"use strict"
angular.module('bullseyeApp')
.controller('mergeStatementCtrl', ['$q', '$rootScope', '$scope', '$mdDialog', '$location',
    'applicationConfigDataFactory',
    'statementTypeDataFactory', 'hierarchySetDataFactory', 'businessUnitDataFactory', 'recordsService', 'statementService',
    'uiGridConstants', 'hierarchySetService',
    function ($q, $rootScope, $scope, $mdDialog, $location,
        applicationConfigDataFactory,
        statementTypeDataFactory, hierarchySetDataFactory, businessUnitDataFactory, recordsService, statementService,
        uiGridConstants, hierarchySetService) {
        var getData = function () {
            var promises = [];
            var stDefer = $q.defer();
            statementTypeDataFactory.getStatementTypeList().success(function (data) {
                $scope.statementTypes = data;
                if ($scope.selectedStatementType == null)
                    $scope.selectedStatementType = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            var buDefer = $q.defer();
            businessUnitDataFactory.getBusinessUnitList().success(function (data) {
                $scope.businessUnits = data;
                if ($scope.selectedBusinessUnit == null)
                    $scope.selectedBusinessUnit = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            var hsDefer = $q.defer();
            hierarchySetDataFactory.getHierarchySetList().success(function (data) {
                $scope.hierarchySetList = data;
                if ($scope.selectedHierarchySet == null)
                    $scope.selectedHierarchySet = data[0];
                hsDefer.resolve();
            });
            promises.push(hsDefer.promise);

            return $q.all(promises);
        };
        $scope.collapseGrid = false;
        $scope.expandCollapseGrid = 'Collapse Statement Selection';
        $scope.toggleCollapseGrid = function () {            
            $scope.collapseGrid = !$scope.collapseGrid;

            if($scope.collapseGrid)
            {
                $scope.expandCollapseGrid = 'Expand Statement Selection';
            }
            else
            {
                $scope.expandCollapseGrid = 'Collapse Statement Selection';
            }
        };

        $rootScope.promise = getData();

        $scope.gridOptions = {
            enableFiltering: true,
            showTreeExpandNoChildren: false,
            enableRowSelection: true,
            enableRowHeaderSelection: true,
            enableSelectAll: false,
            selectionRowHeaderWidth: 35,
            rowHeight: 35,
            showGridFooter: true,
            columnDefs: [
                {
                    field: 'Version', displayName: 'Version',
                    cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                        if (row.entity.IsPublished) {
                            return 'publishedStatement';
                        }
                    },
                    width: 81
                },
                {
                    field: 'Name', displayName: 'Name', cellTooltip: true
                },
                {
                    field: 'Description', cellTooltip: true, displayName: 'Description',
                    cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                        if (row.entity.IsPublished) {
                            return 'publishedStatement';
                        }
                    }
                },
                {
                    field: 'CreatedBy', displayName: 'Created By',
                    cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                        if (row.entity.IsPublished) {
                            return 'publishedStatement';
                        }
                    }
                },
                {
                    field: 'Created', displayName: 'Created Date',
                    cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                        if (row.entity.IsPublished) {
                            return 'publishedStatement';
                        }
                    },
                    width: 185,
                    sort: { direction: uiGridConstants.DESC, priority: 1 },
                    cellTemplate: '<div class="ui-grid-cell-contents" id="createdColumn">{{grid.appScope.getCreatedDateTime(row.entity)| date:"dd MMM yyyy HH:mm:ss"}}</div>'
                }
            ]
        };

        $scope.gridOptions.multiSelect = true;

        var isDate = function (date) {
            return (!isNaN(new Date(date)));
        }

        $scope.getCreatedDateTime = function (rowEntity) {
            var date = rowEntity.Created;
            if (isDate(date))
                return new Date(date);
            return "";
        };

        var disableChildren = function (selectedNode) {
            angular.forEach(selectedNode.children, function (child) {
                child.isDisabled = true;
                if (child.children && child.children.length)
                    disableChildren(child);
            });
        };

        var setNodeState = function (node) {
            node.isDisabled = false;
            if (node.selected) {
                disableChildren(node);
            }
            else if (node.children && node.children.length) {
                angular.forEach(node.children, function (child) {
                    setNodeState(child);
                    if (child.selected) {
                        node.isDisabled = true;
                    }
                    else if (child.isDisabled) {
                        node.isDisabled = true;
                    }
                });
            }
        };

        var isParentSelected = function (node) {
            if (node.parent && node.parent.selected)
                return true;
            else if (node.parent) {
                return isParentSelected(node.parent);
            }
            else
                return false;
        }

        var getNodeState = function (node, isDifferentStatement) {
            var isDisabled = false;
            if (isDifferentStatement && node.selected)
                isDisabled = true;
            if (!isDisabled && !node.selected && node.children && node.children.length) {
                angular.forEach(node.children, function (child) {
                    if (!isDisabled) {
                        var isChildDisabled = getNodeState(child);
                        if (child.selected) {
                            isDisabled = true;
                        }
                        else if (isChildDisabled) {
                            isDisabled = true;
                        }
                    }
                });
            }

            if (!isDisabled && !node.selected && node.parent) {
                if (node.parent.selected)
                    isDisabled = true;
                else
                    isDisabled = isParentSelected(node.parent);
            }
            return isDisabled;
        };

        $scope.selectedStatements = [];

        var resetTree = function (statement) {
            setNodeState(statement.tree[0]);
        };

        var resetTrees = function () {
            angular.forEach($scope.selectedStatements, function (item) {
                resetTree(item);
            });
        };

        var findNode = function (node, nodeId) {
            if (node.id == nodeId)
                return node;
            else if (node.children && node.children.length) {
                var foundNode = null;
                angular.forEach(node.children, function (child) {
                    if (foundNode == null)
                        foundNode = findNode(child, nodeId);
                });
                return foundNode;
            }
            return null;
        }

        $scope.allowSave = function () {
            var statementNodesSelectedCount = 0;
            angular.forEach($scope.selectedStatements, function (item) {
                if (item.selectedRbNodes && item.selectedRbNodes.length)
                    statementNodesSelectedCount++;
            });

            if (statementNodesSelectedCount > 1)
                return true;
            return false;
        };

        $scope.save = function () {

            var recordId = $scope.currentRecord.Id;
            var mergeStatementData = [];
            angular.forEach($scope.selectedStatements, function (item) {
                if (item.selectedRbNodes && item.selectedRbNodes.length) {
                    var stmtData = { RecordId: item.Id, SelectedRbNodeIdList: [] };
                    angular.forEach(item.selectedRbNodes, function (rbNode) {
                        stmtData.SelectedRbNodeIdList.push(rbNode.id);
                    });
                    mergeStatementData.push(stmtData);
                }
            });

            $mdDialog.show({
                controller: 'mergeStatementKpiConfirmationCtrl',
                templateUrl: 'app/templates/mergeStatementKpiConfirmation.tmpl.html',
                parent: angular.element(document.body),
                locals: {
                    selectedRecord: $scope.currentRecord,
                    rbHierarchy: hierarchySetService.getMultiSelectableTree($scope.rbHierarchy)
                }
            })
          .then(function (kpiOptions) {
              statementService.mergeStatement(recordId, mergeStatementData, kpiOptions);
                  mergeProgressMessage().then(function () {
                      $location.path('/');
                  })
          });
        };

        var mergeProgressMessage = function () {
            $mdDialog.show(
                            $mdDialog.alert()
                            .parent(document.body)
                            .clickOutsideToClose(false)
                            .title('Merge in progress')
                            .content('Merge is initiated on the server and you will be notified when it is complete.')
                            .ariaLabel('Merge initiated')
                            .ok('OK')
                        ).then(function () {
                            $location.path('/');
                        });
        };

        $scope.cancel = function () {
            $rootScope.promise = statementService.cancel().then(function () {
                $location.path('/');
            });
        };

        $scope.setSelectable = function () {
            $scope.gridOptions.isRowSelectable = function (row) {
                if ($scope.selectedStatements.length == 20)
                    return false;
                else
                    return true;

            };
            $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.OPTIONS);
            $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.EDIT);
        };

        $scope.allowNodeSelection = function (node, selectedNodes, statement) {
            //if (selectedNodes && selectedNodes.length) {
            //resetTrees();
            var allowSelection = !getNodeState(node, false);
            if (allowSelection) {
                angular.forEach($scope.selectedStatements, function (item) {
                    if (item !== statement && allowSelection) {
                        var foundNode = findNode(item.tree[0], node.id);
                        if (foundNode != null)
                            allowSelection = !getNodeState(foundNode, true);
                    }
                });
            }
            return allowSelection;
            //}
            //return true;
        };

        $scope.gridOptions.onRegisterApi = function (gridApi) {
            //set gridApi on scope
            $scope.gridApi = gridApi;
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                //var newTree = angular.copy(getIvhTree($scope.rbHierarchy));
                var newTree = getMultiSelectableTree($scope.rbHierarchy);
                row.entity.tree = newTree;
                if (row.isSelected)
                    $scope.selectedStatements.push(row.entity);
                else {
                    var index = $scope.selectedStatements.indexOf(row.entity);
                    if (index > -1) {
                        $scope.selectedStatements.splice(index, 1);
                    }
                }

                if ($scope.selectedStatements.length == 20 || $scope.selectedStatements.length == 19)
                    $scope.setSelectable();

            });
        };

        var getConfigData = function () {
            var promises = [];
            var appConfigDefer = $q.defer();
            applicationConfigDataFactory.getApplicationConfigs().success(function (data) {
                $scope.applicationConfigs = data;
                //Find Years Past and Future
                angular.forEach(data, function (item) {
                    if (item.KeyName === 'YearsFuture') {
                        $scope.YearsFuture = parseInt(item.Value, 10) || 0;
                    }
                    else if (item.KeyName === 'YearsPast') {
                        $scope.YearsPast = parseInt(item.Value, 10) || 0;
                    }
                }, this);
                appConfigDefer.resolve();
            });

            promises.push(appConfigDefer.promise);
            return $q.all(promises);
        };

        function getValidYears() {
            var validYears = [];
            var currentYear = new Date().getFullYear();
            for (var i = $scope.YearsPast * -1; i <= $scope.YearsFuture; i++)
                validYears.push(currentYear + i);
            return { validYears: validYears, currentYear: currentYear }
        };

        function setRbTree(hierarchy) {
            $scope.rbHierarchy = hierarchy;
            $scope.isRBHierarchyLoaded = true;
        };

        function setFsTree(hierarchy) {
            $scope.financialStatementHierarchy = hierarchy;
            $scope.isFSHierarchyLoaded = true;
        };

        function setValidStatements() {
            var existingStatements = recordsService.recordsprop;
            var validStatements = [];
            angular.forEach(existingStatements, function (item) {
                if (item.Year == $scope.selectedYear &&
                    item.FinancialStatementHierarchy.Id == $scope.financialStatementHierarchy.Id &&
                    item.RBHierarchy.Id == $scope.rbHierarchy.Id)
                    validStatements.push(item);
            });
            $scope.gridOptions.data = validStatements;
        };

        function createRecord() {
            $scope.isNew = true;
            $rootScope.promise = statementService.createRecord(false, $scope.hierarchySet.Name, $scope.financialStatementHierarchy.Id, $scope.rbHierarchy.Id, $scope.selectedYear,
                $scope.statementType, $scope.businessUnit, $scope.quarter, $scope.description, $scope.month).then(function (data) {
                    if (data.ValidationMessageList) {
                        angular.forEach(data.ValidationMessageList, function (validationMessage) {
                            if (validationMessage.Message.indexOf("Duplicate") > -1) {
                                $mdDialog.show({
                                    controller: 'saveAsNewVersionConfirmationCtrl',
                                    templateUrl: 'app/templates/saveAsNewVersionConfirmation.tmpl.html',
                                    parent: angular.element(document.body)
                                })
                              .then(function () {
                                  $rootScope.promise = statementService.createRecord(true, $scope.hierarchySet.Name, $scope.financialStatementHierarchy.Id, $scope.rbHierarchy.Id,
                                      $scope.selectedYear, $scope.statementType, $scope.businessUnit, $scope.quarter, $scope.description, $scope.month).then(function (data) {
                                          $scope.currentRecord = statementService.selectedRecord();

                                          setValidStatements();
                                      });
                              }, function () {
                                  showNewRecordDialog();
                              });
                            }
                        });
                    }
                    else {
                        $scope.currentRecord = statementService.selectedRecord();
                        setValidStatements();
                    }
                });
        };

        function getInitialData() {
            $scope.isFSHierarchyLoaded = false;
            $scope.isRBHierarchyLoaded = false;
            var promises = [];

            var hierarchySetDefer = $q.defer();
            hierarchySetDataFactory.getHierarchySet($scope.hierarchySet.Id).success(function (data) {
                setFsTree(data.FinancialStatementHierarchy);
                setRbTree(data.RBHierarchy);
                $scope.rbTreeView = getTree(data.RBHierarchy);
                rbHierarchyTree.treeview(
                          {
                              data: $scope.rbTreeView,
                              onNodeUnselected: function (event, node) {
                                  //rbNodeSelectionChanged(node, false);
                              },
                              onNodeSelected: function (event, node) {
                                  //rbNodeSelectionChanged(node, true);
                              }
                          });
                if ($scope.selectedRecordId === undefined) {
                    createRecord();
                }
                hierarchySetDefer.resolve();
            });
            promises.push(hierarchySetDefer.promise);
            return $q.all(promises);
        };

        var showNewRecordDialog = function () {
            $mdDialog.show({
                controller: 'createStatementInitiateCtrl',
                templateUrl: 'app/templates/createStatementInitiate.tmpl.html',
                parent: angular.element(document.body),
                //targetEvent: ev,
                locals: {
                    years: getValidYears()
                }
            })
                .then(function (selectedRecord) {
                    $scope.selectedYear = selectedRecord.Year;
                    $scope.statementType = selectedRecord.StatementType;
                    $scope.businessUnit = selectedRecord.BusinessUnit;
                    $scope.quarter = selectedRecord.Quarter;
                    $scope.description = selectedRecord.Description;
                    $scope.month = selectedRecord.Month;
                    $scope.hierarchySet = selectedRecord.HierarchySet;
                    //get trees
                    $rootScope.promise = getInitialData();
                }, function () {
                    //modal dismissed
                    $location.path('/');
                });
        };

        $rootScope.promise.then(function () {
            $rootScope.promise = getConfigData().then(function () {
                showNewRecordDialog();
            });
        });

        var rbHierarchyTree = $('#rbHierarchyTree').treeview({
            data: [],
            showBorder: false
        });

        var nextGeneratedId = 0;

        var addTreeNode = function (node) {
            var convertedNode = { generatedId: nextGeneratedId };
            if (node.Children && node.Children.length) {
                convertedNode.nodes = [];
                angular.forEach(node.Children, function (childNode) {
                    nextGeneratedId = nextGeneratedId + 1;
                    convertedNode.nodes.push(addTreeNode(childNode));
                });
            }

            convertedNode.text = node.Name;
            convertedNode.OriginalNode = node;
            convertedNode.Id = node.Id;
            return convertedNode;
        };

        var getTree = function (treeData) {
            var tree = [];
            angular.forEach(treeData.RootNodes, function (rootNode) {
                nextGeneratedId = nextGeneratedId + 1;
                tree.push(addTreeNode(rootNode));
            });
            return tree;
        };

        var addIvhTreeNode = function (node) {
            var convertedNode = {};
            if (node.Children && node.Children.length) {
                convertedNode.children = [];
                angular.forEach(node.Children, function (childNode) {
                    convertedNode.children.push(addIvhTreeNode(childNode));
                });
            }

            convertedNode.label = node.Name;
            convertedNode.value = node.Name;
            convertedNode.OriginalNode = node;
            convertedNode.Id = node.Id;
            return convertedNode;
        };

        var getIvhTree = function (treeData) {
            var tree = [];
            angular.forEach(treeData.RootNodes, function (rootNode) {
                tree.push(addIvhTreeNode(rootNode));
            });
            return tree;
        };

        var addMultiSelectableTreeNode = function (node, level, parentNode) {
            var convertedNode = { children: [] };
            if (node.Children && node.Children.length) {
                angular.forEach(node.Children, function (childNode) {
                    convertedNode.children.push(addMultiSelectableTreeNode(childNode, level + 1, convertedNode));
                });
            }
            convertedNode.name = node.Name;
            convertedNode.OriginalNode = node;
            convertedNode.id = node.Id;
            convertedNode.level = level;
            convertedNode.parent = parentNode;
            return convertedNode;
        };

        function getMultiSelectableTree(treeData) {
            var tree = [];
            angular.forEach(treeData.RootNodes, function (rootNode) {
                tree.push(addMultiSelectableTreeNode(rootNode, 1));
            });
            return tree;
        };

    }]);