﻿angular.module('bullseyeApp').controller('uploadMappingCtrl', ['$rootScope', '$scope', '$mdDialog', 'mappingTypes', 'tprMappingDataFactory', 'fbwMappingDataFactory',
function ($rootScope, $scope, $mdDialog, mappingTypes, tprMappingDataFactory, fbwMappingDataFactory) {
    $scope.message = "Please Wait...";
    $scope.mappingTypes = mappingTypes;

    $scope.mappingTypeChanged = function () {
        $scope.selectedFileName = "";
        $scope.pathList = [];
        $scope.files = [];
        var selectedId = $scope.selectedMappingType.Id;
        switch (selectedId) {
            case 0:                
                $scope.uploadPromise = tprMappingDataFactory.getTprMappingFileNames().then(function (response) {
                        $scope.files = response.data.Result;
                    });                                
                break;
            case 1:
                $scope.uploadPromise = fbwMappingDataFactory.getFbwMappingFileNamesForRb().then(function (response) {
                    $scope.files = response.data.Result;
                });
                break;
            case 2:
                $scope.uploadPromise = fbwMappingDataFactory.getFbwMappingFileNamesForFs().then(function (response) {
                    $scope.files = response.data.Result;
                });
                break;
        }
    };
    
    $scope.selectedFileName = "";
    $scope.totalDisplayed = 20;

    $scope.upload = function () {
        $scope.totalDisplayed = 20;        
        $mdDialog.hide({ mappingTypeId: $scope.selectedMappingType.Id, selectedFileName: $scope.selectedFileName });
    };

    $scope.showMore = function () {
        $scope.totalDisplayed += 20;
    };

    $scope.areAllItemsDisplayed = function () {
        return $scope.uploadErrors == null || $scope.totalDisplayed >= $scope.uploadErrors.length;
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };
}]);