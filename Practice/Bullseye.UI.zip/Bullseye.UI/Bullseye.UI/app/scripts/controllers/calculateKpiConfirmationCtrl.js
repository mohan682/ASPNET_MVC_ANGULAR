﻿"use strict"
angular.module('bullseyeApp')
.controller('calculateKpiConfirmationCtrl', ['$mdDialog', '$scope', 'hierarchySetService', 'rbHierarchy',
function ($mdDialog, $scope, hierarchySetService, rbHierarchy) {
    var resetSelections = function (nodes) {
        angular.forEach(nodes, function (node) {
            node.selected = false;
            if (node.children && node.children.length) {
                resetSelections(node.children);
            }
        });
    };

    $scope.rbHierarchy = rbHierarchy;
    resetSelections($scope.rbHierarchy);
    if (!$scope.selectedKpiRbNodes || !$scope.selectedKpiRbNodes.length)
        rbHierarchy[0].selected = true;
    $scope.ok = function () {
        var selectedRbNodeIdList = [];
        angular.forEach($scope.selectedKpiRbNodes, function (rbNode) {
            selectedRbNodeIdList.push(rbNode.id);
        });
        var selectedLevel = 4;
        angular.forEach($scope.selectedLevel, function (level) {
            selectedLevel = level.id;
        });
        var kpiOptions = { selectedRbNodeIdList: selectedRbNodeIdList, selectedLevel: selectedLevel };
        $mdDialog.hide(kpiOptions);
    };



    var isParentSelected = function (node) {
        if (node.parent && node.parent.selected)
            return true;
        else if (node.parent) {
            return isParentSelected(node.parent);
        }
        else
            return false;
    };

    $scope.allowKpiCalc = function () {
        if ($scope.selectedLevel && $scope.selectedLevel.length
            && $scope.selectedKpiRbNodes && $scope.selectedKpiRbNodes.length)
            return true;
        return false;
    };

    $scope.canSelectNode = function (node) {
        var canSelect = true;        
        if (canSelect && !node.selected && node.children && node.children.length) {
            angular.forEach(node.children, function (child) {
                if (canSelect) {
                    var canSelectChild = $scope.canSelectNode(child);
                    if (child.selected) {
                        canSelect = false;
                    }
                    else if (!canSelectChild) {
                        canSelect = false;
                    }
                }
            });
        }

        if (canSelect && !node.selected && node.parent) {
            if (node.parent.selected)
                canSelect = false;
            else
                canSelect = !isParentSelected(node.parent);
        }
        return canSelect;
    };


    $scope.levelList = [{ id: 1, name: 1 },
        { id: 2, name: 2 },
        { id: 3, name: 3 },
        { id: 4, name: 4, selected: true },
        { id: 5, name: 5 },
        { id: 6, name: 6 },
        { id: 7, name: 7 },
        { id: 8, name: 8 },
        { id: 9, name: 9 },
        { id: 10, name: 10 }
    ];    

    $scope.getValidLevels = function () {
        return $scope.levelList;
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };
}]);