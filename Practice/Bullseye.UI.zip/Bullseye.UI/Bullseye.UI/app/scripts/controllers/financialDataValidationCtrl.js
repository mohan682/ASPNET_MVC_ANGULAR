﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:FinancialStatementCtrl
 * @description
 * # FinancialStatementCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('financialDataValidationCtrl', ['$scope', '$rootScope', '$q', '$location', '$routeParams', '$mdDialog', '$mdSidenav', '$mdUtil', '$interval',
      'hierarchySetService', 'financialDataValidationDataFactory',
      function ($scope, $rootScope, $q, $location, $routeParams, $mdDialog, $mdSidenav, $mdUtil, $interval
         , hierarchySetService, financialDataValidationDataFactory
        ) {

        $scope.showSection1 = true;
        $scope.showSection2 = false;

        $scope.quartersList = ["1Q", "2Q", "3Q", "4Q"];
        $scope.selectedQuarter = "1Q";
        $scope.month1 =  'JAN';
        $scope.month2 =  'FEB' ;
        $scope.month3 = 'MAR'

        $scope.showQ1MontlyColumns  =$scope.showQ2MontlyColumns  =$scope.showQ3MontlyColumns = $scope.showQ4MontlyColumns = false;

        $scope.showFinanacialDataTable = false;

        $scope.updateSectionVisibility = function (section, sectionValue) {
          if (section == 1) $scope.showSection1 = !sectionValue;
          else $scope.showSection2 = !sectionValue;
        }

        $scope.selectOnlyN = function (item, selectedItems, count) {
          if (selectedItems != null && selectedItems.length >= count) {
            return false;
          } else {
            return true;
          }
        };

        $scope.$on('isRBHierarchyLoaded', function () {
          $scope.rbSingleSelectableTree1 = hierarchySetService.getMultiSelectableTree($scope.rbHierarchy);
          $scope.rbSingleSelectableTree2 = hierarchySetService.getMultiSelectableTree($scope.rbHierarchy);
        });

        //$scope.getValueByQuarter = function (selectedQuarter, rec,monthNumSet, isRVQuarterValue,
        //    isFBWQuarterValue, isWCQuarterValue, isFBWQuarterVarinaceValue, isWCQuarterVarinaceValue) {
        //    return
        //    if (isRVQuarterValue) {
        //        (selectedQuarter == '1Q') ? rec.RVQuarterOne : (selectedQuarter == '2Q') ?
        //            rec.RVQuarterTwo : (selectedQuarter == '3Q') ? rec.RVQuarterThree : rec.RVQuarterFour;
        //    } else if (isFBWQuarterValue) {
        //        (selectedQuarter == '1Q') ? rec.FBWQuarterOne : (selectedQuarter == '2Q') ? rec.FBWQuarterTwo : (selectedQuarter == '3Q') ? rec.FBWQuarterThree : rec.FBWQuarterFour;
        //    } else if (isWCQuarterValue) {
        //        (selectedQuarter == '1Q') ? rec.WCQuarterOne : (selectedQuarter == '2Q') ? rec.WCQuarterTwo : (selectedQuarter == '3Q') ? rec.WCQuarterThree : rec.WCQuarterFour;
        //    } else if (isFBWQuarterVarinaceValue) {
        //        (selectedQuarter == '1Q') ? rec.FBWQuarterOneVariance : (selectedQuarter == '2Q') ? rec.FBWQuarterTwoVariance : (selectedQuarter == '3Q') ? rec.FBWQuarterThreeVariance : rec.FBWQuarterFourVariance;
        //    } if (isWCQuarterVarinaceValue) {
        //        (selectedQuarter == '1Q') ? rec.WCQuarterOneVariance : (selectedQuarter == '2Q') ? rec.WCQuarterTwoVariance : (selectedQuarter == '3Q') ? rec.WCQuarterThreeVariance : rec.WCQuarterFourVariance;
        //    } else {
        //        if (monthNumSet == 1) {
        //            (selectedQuarter == '1Q') ? rec.January : (selectedQuarter == '2Q') ? rec.April : (selectedQuarter == '3Q') ? rec.July : rec.October;
        //        } else
        //            if (monthNumSet == 2) {
        //                (selectedQuarter == '1Q') ? rec.February : (selectedQuarter == '2Q') ? rec.May : (selectedQuarter == '3Q') ? rec.August : rec.November;
        //            } else (selectedQuarter == '1Q') ? rec.March : (selectedQuarter == '2Q') ? rec.June : (selectedQuarter == '3Q') ? rec.September : rec.December;
        //    }
        //};

        $scope.quarterSelectedChanged = function (selectedQuarter) {

          $scope.month1 = (selectedQuarter == '1Q') ? 'JAN' : (selectedQuarter == '2Q') ? 'APR' : (selectedQuarter == '3Q') ? 'JUL' : 'OCT';

          $scope.month2 = (selectedQuarter == '1Q') ? 'FEB' : (selectedQuarter == '2Q') ? 'MAY' : (selectedQuarter == '3Q') ? 'AUG' : 'NOV';

          $scope.month3 = (selectedQuarter == '1Q') ? 'MAR' : (selectedQuarter == '2Q') ? 'JUN' : (selectedQuarter == '3Q') ? 'SEP' : 'DEC';
        };

        $scope.getFormattedValue = function (value) {

            if (isNaN(value) || !angular.isNumber(value)) return '';

            if (value < 0)
                return '(' + Math.round(Math.abs(value)).toLocaleString() + ')';
            else
                return Math.round(Math.abs(value)).toLocaleString();
        };

        $scope.GetFinancialDataValidationData = function (selectedNodesForSection1, selectedNodeForSection2, selectedPeriod) {

          if (selectedNodesForSection1 != null && selectedNodesForSection1.length > 0 && selectedNodeForSection2 != null && selectedNodeForSection2.length > 0) {
            // alert($scope.currentRecord.Id, selectedNode[0].id);

            var rBHierarchyNodeIdsForFirstSectionString='';

            for (var index = 0; index < selectedNodesForSection1.length; index++) {
              rBHierarchyNodeIdsForFirstSectionString += "&rBHierarchyNodeIdsForFirstSection=" + selectedNodesForSection1[index].id;
            }

            $rootScope.promise = financialDataValidationDataFactory
              .getVarianceData($scope.currentRecord.Id, rBHierarchyNodeIdsForFirstSectionString,
              '&rBHierarchyNodeIdsForSecondSection=' + selectedNodeForSection2[0].id)
              .then(function (response) {
                  $scope.showFinanacialDataTable = response.data.Section1 != null && response.data.Section2 != null;
                  $scope.finanacialDataTableSourceSection1 = response.data.Section1;
                  $scope.finanacialDataTableSourceSection2 = response.data.Section2;
              });

          } else {
            $scope.showFinanacialDataTable = false;
            $scope.finanacialDataTableSourceSection1 = null;
            $scope.finanacialDataTableSourceSection2 = null;
          }
        };
      }]);