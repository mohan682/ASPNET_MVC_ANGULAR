﻿angular.module('bullseyeApp').controller('uploadTprMappingCtrl', ['$rootScope', '$scope', 'tprMappingDataFactory', 
function ($rootScope, $scope, tprMappingDataFactory) {
    $scope.message = $scope.tprMappingUpload.loadResponse.Message;
    $scope.success = $scope.tprMappingUpload.loadResponse.Success;
    $scope.rows = $scope.tprMappingUpload.loadResponse.Result;
    if ($scope.tprMappingUpload.loadResponse.Exception)
        console.log($scope.tprMappingUpload.loadResponse.Exception);

    //$scope.resizeMode = "OverflowResizer";    

    $scope.deleteTprMappingRow = function (item) {
        var index = $scope.rows.indexOf(item);
        if (index > -1) {
            $scope.rows.splice(index, 1);
        }
    };

    $scope.processText = 'Process';

    $scope.processTprMappingUpload = function () {
        var confirmSave = null;
        angular.forEach($scope.rows, function (item) {
            if (item.Status === 1 && confirmSave == null) {
                confirmSave = true;
            }
            if (item.Status === 2)
                confirmSave = false;
        });
        if (confirmSave == null)
            confirmSave = false;
        $rootScope.promise = tprMappingDataFactory.processTprMappings($scope.selectedHierarchySetId, $scope.rows, confirmSave).then(function (response) {
            $scope.message = response.data.Message;
            $scope.success = response.data.Success;
            $scope.rows = response.data.Result;
            if (response.data.Exception)
                console.log(response.data.Exception);

            var warningRowCount = $scope.rowCount(1);
            var errorRowCount = $scope.rowCount(2);
            if (warningRowCount === 0 && errorRowCount === 0) {
                //Process completed
                $scope.processCompleted = true;
                $scope.setSaveStatus = true;
            }
            else {
                $scope.processCompleted = false;
            }           
        });
    };

    $scope.getProcessText = function()
    {
        var processText = "Process";
        var warningRowCount = $scope.rowCount(1);
        var errorRowCount = $scope.rowCount(2);
        if (warningRowCount > 0 && errorRowCount === 0) {
            processText = "Confirm & Process";
        }
        return processText;
    }

    $scope.allowProcess = function () {
        if ($scope.rows && $scope.rows.length && ($scope.processCompleted == null || !$scope.processCompleted))
            return true;
        return false;        
    }

    $scope.rowClass = function (item) {
        if (item.Status === 0) //Valid
        {
            return "uploadRowValid";
        }
        else if (item.Status === 1) //Warning
        {
            return "uploadRowWarning";
        }
        else if (item.Status === 2) //Error
        {
            return "uploadRowError";
        }
    }

    $scope.rowCount = function (status) {
        var count = 0;
        if ($scope.rows) {
            angular.forEach($scope.rows, function (item) {
                if (item.Status === status)
                    count++
            });
        }
        return count;
    }

    $scope.currentPage = 0;
    $scope.pageSize = 25;

    $scope.setCurrentPage = function (currentPage) {
        $scope.currentPage = currentPage;
        $scope.pages = $scope.getNumberAsArray($scope.numberOfPages());
    }

    $scope.getNumberAsArray = function (num) {
        if (num > 3) {
            if ($scope.currentPage === num - 1) {
                $scope.startPage = $scope.currentPage - 2;
                $scope.endPage = $scope.currentPage;
            }
            else if ($scope.currentPage === 0) {
                $scope.startPage = $scope.currentPage;
                $scope.endPage = $scope.currentPage + 2;
            }
            else {
                $scope.startPage = $scope.currentPage - 1;
                $scope.endPage = $scope.currentPage + 1;
            }

            var pages = [];
            for (var i = $scope.startPage; i <= $scope.endPage; i++) {
                pages.push(i);
            }
            return pages;
        }
        else {
            var pages = [];
            for (var i = 0; i < num; i++) {
                pages.push(i);
            }
            return pages;
        }
    };

    $scope.numberOfPages = function () {
        if ($scope.rows && $scope.rows.length)
            return Math.ceil($scope.rows.length / $scope.pageSize);
        return 0;
    };

    $scope.$watch('rows', function () {
        if ($scope.rows)
            $scope.pages = $scope.getNumberAsArray($scope.numberOfPages());
    });


    $scope.setLastPage = function () {
        var pageCount = $scope.numberOfPages();
        $scope.setCurrentPage(pageCount - 1);
    };

    $scope.isFirstPageDisabled = function () {
        if ($scope.currentPage === 0)
            return true;
        return false;
    };

    $scope.isLastPageDisabled = function () {
        var pageCount = $scope.numberOfPages();
        if ($scope.currentPage === pageCount - 1)
            return true;
        return false;
    }
}]);