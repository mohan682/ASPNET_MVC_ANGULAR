"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:headerCtrl
 * @description
 * # headerCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('headerCtrl', ['$scope', '$rootScope', 'systemDataFactory','settingsDataFactory', 'applicationConfigDataFactory',
      function ($scope, $rootScope, systemDataFactory,settingsDataFactory, applicationConfigDataFactory) {
          $rootScope.promise = settingsDataFactory.loadSettings().then(
              function () {
                  applicationConfigDataFactory.getDocumentationPath().then(function (res) {

                      if (res.data != null) {
                          $scope.linkToDocumentationPath = res.data.Value;
                      }
                  });
              } );
      $rootScope.message = 'Please Wait...';

      systemDataFactory.getVersion().then(function (versionInfo) {
          $scope.Version = versionInfo.Version;
          $scope.LastUpdated = versionInfo.LastUpdated;
      });    

  }]);
