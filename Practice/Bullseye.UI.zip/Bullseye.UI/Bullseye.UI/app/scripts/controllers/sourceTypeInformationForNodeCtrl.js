﻿angular.module('bullseyeApp')
    .controller('sourceTypeInformationForNodeCtrl',
        [
            '$rootScope', '$scope', '$mdDialog', 'statementService', 'selectedAdjustment',
            function($rootScope, $scope, $mdDialog, statementService, selectedAdjustment) {

                $scope.showCalculatedInformation = false;
                $scope.has1OrMoreCalcSourceDataType = selectedAdjustment.has1OrMoreCalcSourceDataType;

                $scope.ok = function() {
                    $mdDialog.cancel();
                };

                   //Add Adjusted source
                if (selectedAdjustment.has1OrMoreCalcSourceDataType) {
                    selectedAdjustment.sourceDataTypes.push({
                        SourceType: { Name: "Adjusted" },
                        SourceEditTypeText: "",
                        formula: ""
                    });

                    $rootScope.promise = statementService.getCalculationData(selectedAdjustment.recordId,
                            selectedAdjustment.fsNodeId,
                            selectedAdjustment.rbNodeId,
                            selectedAdjustment.dividendPartnerId,
                            selectedAdjustment.regionId,
                            selectedAdjustment.date)
                        .then(function() {

                                var data = statementService.calculationData();

                                if (data.CalculationFormulae != null && data.FeedValues != null) {

                                    $scope.showCalculatedInformation = true;

                                    $scope.calculationFormulas = data.CalculationFormulae;

                                    $scope.feedValues = data.FeedValues;

                                    angular.forEach($scope.sourceDataTypes,
                                        function(sourceDataType) {

                                            sourceDataType.formula = "";

                                            angular.forEach($scope.calculationFormulas,
                                                function(calculationFormula) {

                                                    if (sourceDataType.SourceType.Name.toLowerCase() ===
                                                        calculationFormula.SourceType.toLowerCase())
                                                        sourceDataType.formula = calculationFormula.Formula;
                                                    else if (sourceDataType.SourceType.Name.toLowerCase() ===
                                                        'adjusted' &&
                                                        calculationFormula.SourceType.toLowerCase() === 'reportedvalue')
                                                        sourceDataType.formula = calculationFormula.Formula;
                                                });

                                        });
                                }

                            },
                            function(error) {
                                console.log(error);
                            });

                };

                $scope.sourceDataTypes = selectedAdjustment.sourceDataTypes;

            }
        ]);