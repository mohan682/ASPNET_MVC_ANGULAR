﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:rootCtrl
 * @description
 * # rootCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('rootCtrl', ['$scope', '$rootScope', '$mdDialog', '$http', '$interval', function ($scope, $rootScope, $mdDialog, $http, $interval) {
      $scope.availableFeatures = {
          ViewStatement: 'View Statement',
          EditStatement: 'Edit Statement',
          CreateStatement: 'Create Statement',
          PublishStatement: 'Publish Statement',
          ViewHierarchy: 'View Hierarchy',
          EditHierarchy: 'Edit Hierarchy',
          ViewConfig: 'View Config',
          EditConfig: 'Edit Config'
      };

      var validRoles = {
          BULLSEYE_PLATFORM: 'BULLSEYE_PLATFORM',
          FIN_STMT_RO: 'FIN_STMT_RO',
          FIN_STMT_RW: 'FIN_STMT_RW',
          CONFIG_MGMT_RO: 'CONFIG_MGMT_RO',
          CONFIG_MGMT_RW: 'CONFIG_MGMT_RW',
          HIERARCHY_MGMT_RO: 'HIERARCHY_MGMT_RO',
          HIERARCHY_MGMT_RW: 'HIERARCHY_MGMT_RW'
      };

        $rootScope.$on('$routeChangeStart', function() { $mdDialog.cancel(); });

      $scope.getFeatureAccess = function (feature) {
          var allowAccess = false;
          if ($.inArray(validRoles.BULLSEYE_PLATFORM, $rootScope.globals.roles) === -1)
              return false;
          switch (feature) {
              case $scope.availableFeatures.ViewStatement:
                  if ($.inArray(validRoles.FIN_STMT_RO, $rootScope.globals.roles) !== -1
                      || $.inArray(validRoles.FIN_STMT_RW, $rootScope.globals.roles) !== -1)
                      allowAccess = true;
                  break;
              case $scope.availableFeatures.EditStatement:
              case $scope.availableFeatures.CreateStatement:
              case $scope.availableFeatures.PublishStatement:
                  if ($.inArray(validRoles.FIN_STMT_RW, $rootScope.globals.roles) !== -1)
                      allowAccess = true;
                  break;
              case $scope.availableFeatures.ViewHierarchy:
                  if ($.inArray(validRoles.HIERARCHY_MGMT_RO, $rootScope.globals.roles) !== -1
                      || $.inArray(validRoles.HIERARCHY_MGMT_RW, $rootScope.globals.roles) !== -1)
                      allowAccess = true;
                  break;
              case $scope.availableFeatures.CreateHierarchy:
              case $scope.availableFeatures.EditHierarchy:
                  if ($.inArray(validRoles.HIERARCHY_MGMT_RW, $rootScope.globals.roles) !== -1)
                      allowAccess = true;
                  break;
              case $scope.availableFeatures.ViewConfig:
                  if ($.inArray(validRoles.CONFIG_MGMT_RO, $rootScope.globals.roles) !== -1
                      || $.inArray(validRoles.CONFIG_MGMT_RW, $rootScope.globals.roles) !== -1)
                      allowAccess = true;
                  break;
              case $scope.availableFeatures.EditConfig:
                  if ($.inArray(validRoles.CONFIG_MGMT_RW, $rootScope.globals.roles) !== -1)
                      allowAccess = true;
                  break;
          }
          return allowAccess;
      };

      //var logPendingHttpRequestsFn = function () {
      //    console.log($http.pendingRequests)
      //};

      //$interval(logPendingHttpRequestsFn, 10000);
  }]);
