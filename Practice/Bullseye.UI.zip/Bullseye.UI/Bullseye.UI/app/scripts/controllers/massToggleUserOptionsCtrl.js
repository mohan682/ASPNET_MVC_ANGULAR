﻿angular.module('bullseyeApp').controller('massToggleUserOptionsCtrl', ['$scope', '$mdDialog',
    function ($scope, $mdDialog) {
        $scope.massToggleOption = 'AtLowerVersion';

        $scope.ok = function () {
            $mdDialog.hide($scope.massToggleOption);
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);