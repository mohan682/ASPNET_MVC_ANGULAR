﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:metadataCtrl
 * @description
 * # metadataCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('metadataCtrl', ['$rootScope', '$scope', '$q', '$location', '$mdDialog',
      'statementTypeDataFactory', 'applicationConfigDataFactory', 'businessUnitDataFactory', 'sourceDirectoryDataFactory',
      function ($rootScope, $scope, $q, $location, $mdDialog,
          statementTypeDataFactory, applicationConfigDataFactory, businessUnitDataFactory, sourceDirectoryDataFactory) {
          var statementTypesToDelete = [];
          var statementTypesToCreate = [];

          var businessUnitsToDelete = [];
          var businessUnitsToCreate = [];

          var isUniqueStatementType = function (statementType) {
              var isUnique = true;
              angular.forEach($scope.statementTypes, function (type) {
                  if (angular.lowercase(type.Name) === angular.lowercase(statementType))
                      isUnique = false;
              });
              return isUnique;
          };

          var isUniqueBusinessUnit = function (businessUnit) {
              var isUnique = true;
              angular.forEach($scope.businessUnits, function (type) {
                  if (angular.lowercase(type.Name) === angular.lowercase(businessUnit))
                      isUnique = false;
              });
              return isUnique;
          };

          var getData = function () {
              var promises = [];
              var stDefer = $q.defer();
              statementTypeDataFactory.getStatementTypeList().success(function (data) {
                  $scope.statementTypes = data;
                  stDefer.resolve();
              });
              promises.push(stDefer.promise);

              var buDefer = $q.defer();
              businessUnitDataFactory.getBusinessUnitList().success(function (data) {
                  $scope.businessUnits = data;
                  buDefer.resolve();
              });
              promises.push(buDefer.promise);

              var appConfigDefer = $q.defer();
              applicationConfigDataFactory.getApplicationConfigs().success(function (data) {
                  $scope.applicationConfigs = data;
                  //Find Years Past and Future
                  angular.forEach(data, function (item) {
                      if (item.KeyName === 'YearsFuture') {
                          $scope.YearsFuture = parseInt(item.Value, 10) || 0;
                      }
                      else if (item.KeyName === 'YearsPast') {
                          $scope.YearsPast = parseInt(item.Value, 10) || 0;
                      }
                      else
                      {
                          $scope[item.KeyName] = item.Value;
                      }
                      //else if (item.KeyName === 'AdjustmentFileDirectory')
                      //{
                      //    $scope.AdjustmentFileDirectory = item.Value;                          
                      //}
                      //else if (item.KeyName === 'TprMappingFileDirectory') {
                      //    $scope.TprMappingFileDirectory = item.Value;
                      //}
                      //else if (item.KeyName === 'FbwMappingFileDirectory') {
                      //    $scope.FbwMappingFileDirectory = item.Value;
                      //}
                  }, this);
                  appConfigDefer.resolve();
              });

              promises.push(appConfigDefer.promise);

              return $q.all(promises);
          };

          $rootScope.promise = getData();

          $scope.itemInEdit = undefined;

          $scope.addStatementType = function () {
              //if ($scope.newStatementType !== undefined && isUniqueStatementType($scope.newStatementType)) {
              //    var newStatementType = { Name: $scope.newStatementType, Id: null, IsEditMode: false };
              //    statementTypesToCreate.push(newStatementType);
              //    $scope.statementTypes.push(newStatementType);
              //    $scope.newStatementType = undefined;
              //} else {
              //    //TODO: Raise a validation error
              //}

              var newStatementType = { Name: null, Id: null };
              statementTypesToCreate.push(newStatementType);
              $scope.statementTypes.push(newStatementType);
          };

          $scope.addBusinessUnit = function () {
              var newBusinessUnit = { Name: null, Id: null };
              businessUnitsToCreate.push(newBusinessUnit);
              $scope.businessUnits.push(newBusinessUnit);
          };

          //$scope.editStatementType = function (statementType) {
          //    $scope.itemInEdit = statementType.Name;
          //    angular.forEach($scope.statementTypes, function (item) {
          //        if (item.Id === statementType.Id) {
          //            item.IsEditMode = true;

          //        } else
          //            item.IsEditMode = false;
          //    });
          //};

          var deleteStatementTypes = function () {
              var stPromises = statementTypesToDelete.map(function (stId) {
                  return statementTypeDataFactory.deleteStatementType(stId);
              });
              //return $q.all(stPromises);
              return stPromises;
          };

          var createStatementTypes = function () {
              var stPromises = statementTypesToCreate.map(function (st) {
                  return statementTypeDataFactory.createStatementType(st);
              });
              //return $q.all(stPromises);
              return stPromises;
          }

          var updateStatementTypes = function () {
              //Update each statement type
              var statementTypesToUpdate = [];
              angular.forEach($scope.statementTypes, function (st) {
                  if (st.Id != null)
                      statementTypesToUpdate.push(st);
              });
              var stPromises = statementTypesToUpdate.map(function (statementType) {
                  return statementTypeDataFactory.updateStatementType(statementType);
              });

              //return $q.all(stPromises);
              return stPromises;
          };

          var deleteBusinessUnits = function () {
              var buPromises = businessUnitsToDelete.map(function (buId) {
                  return businessUnitDataFactory.deleteBusinessUnit(buId);
              });
              //return $q.all(buPromises);
              return buPromises;
          };

          var createBusinessUnits = function () {
              var buPromises = businessUnitsToCreate.map(function (bu) {
                  return businessUnitDataFactory.createBusinessUnit(bu);
              });
              //return $q.all(buPromises);
              return buPromises;
          }

          var updateBusinessUnits = function () {              
              var businessUnitsToUpdate = [];
              angular.forEach($scope.businessUnits, function (bu) {
                  if (bu.Id != null)
                      businessUnitsToUpdate.push(bu);
              });
              var buPromises = businessUnitsToUpdate.map(function (businessUnit) {
                  return businessUnitDataFactory.updateBusinessUnit(businessUnit);
              });

              //return $q.all(buPromises);
              return buPromises;
          };

          var saveApplicationConfigs = function () {
              angular.forEach($scope.applicationConfigs, function (item) {
                  if (item.KeyName === 'YearsFuture') {
                      item.Value = $scope.YearsFuture;
                  }
                  else if (item.KeyName === 'YearsPast') {
                      item.Value = $scope.YearsPast;
                  }
                  else
                  {
                      item.Value = $scope[item.KeyName];
                  }
                  //else if (item.KeyName === 'AdjustmentFileDirectory') {
                  //    item.Value = $scope.AdjustmentFileDirectory;
                  //}                  
              }, this);

              var configPromises = $scope.applicationConfigs.map(function (config) {
                  return applicationConfigDataFactory.updateApplicationConfig(config);
              });

              //return $q.all(configPromises);
              return configPromises;
          };

          $scope.menuSelected = function (menuitem, index) {
              $scope.menu = menuitem;
              $scope.selectedIndex = index;
          }

          $scope.isSelectedItem = function (index) {
              return index === $scope.selectedIndex;
          }

          $scope.save = function () {
              var confirm = $mdDialog.confirm()
                            .title('Confirmation')
                            .content('Would you like to Save changes to configuration data?')
                            .ariaLabel('Confirmation')
                            .ok('OK')
                            .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  var promises = [];
                  promises = promises.concat(deleteStatementTypes());
                  promises = promises.concat(createStatementTypes());
                  promises = promises.concat(updateStatementTypes());
                  promises = promises.concat(deleteBusinessUnits());
                  promises = promises.concat(createBusinessUnits());
                  promises = promises.concat(updateBusinessUnits());
                  promises = promises.concat(saveApplicationConfigs());

                  $rootScope.promise = $q.all(promises);
                  $rootScope.promise.then(function () {
                      $mdDialog.show(
                              $mdDialog.alert()
                              .parent(angular.element(document.body))
                              .clickOutsideToClose(false)
                              .title('Success')
                              .content('Changes are successfully saved')
                              .ariaLabel('Success')
                              .ok('OK')
                          )
                          .catch(function (error) {
                              console.log(error);
                          })
                          .finally(function () {
                              //$location.path('/');
                              statementTypesToDelete = [];
                              statementTypesToCreate = [];
                              
                              businessUnitsToDelete = [];
                              businessUnitsToCreate = [];
                              getData();
                          });
                  }).catch(function (error) {
                      console.log(error);
                  });
              }, function () {
              });              
          };

          $scope.cancel = function () {
              var confirm = $mdDialog.confirm()
                            .title('Confirmation')
                            .content('You will lose all the changes you made in the current session. Do you want to continue?')
                            .ariaLabel('Confirmation')
                            .ok('OK')
                            .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  $location.path('/');
              });
          };

          $scope.deleteStatementType = function (statementType) {
              var index = $scope.statementTypes.indexOf(statementType);
              if (index > -1) {
                  if (statementType.Id == null)
                      statementTypesToCreate.pop(statementType);
                  else {
                      statementTypesToDelete.push(statementType.Id);
                  }
                  $scope.statementTypes.splice(index, 1);
              }
          };

          $scope.deleteBusinessUnit = function (businessUnit) {
              var index = $scope.businessUnits.indexOf(businessUnit);
              if (index > -1) {
                  if (businessUnit.Id == null)
                      businessUnitsToCreate.pop(businessUnit);
                  else {
                      businessUnitsToDelete.push(businessUnit.Id);
                  }
                  $scope.businessUnits.splice(index, 1);
              }
          };

          $scope.isStatementTypeUnique = function (statementType, index) {
              var isValid = true;
              angular.forEach($scope.statementTypes, function (st) {
                  if (statementType !== st && st.Name === statementType.Name) {
                      isValid = false;
                  }
              });
              var controlName = 'name_';
              if(statementType.Name)
                  controlName= controlName + statementType.Name;
              controlName= controlName+'_'+index;              
              if (isValid) {
                  $scope.metadataForm[controlName].$setValidity('unique', true);
              }
              else {
                  $scope.metadataForm[controlName].$setValidity('unique', false);
              }
          };

          $scope.isBusinessUnitUnique = function (businessUnit, index) {
              var isValid = true;
              angular.forEach($scope.businessUnits, function (bu) {
                  if (businessUnit !== bu && bu.Name === businessUnit.Name) {
                      isValid = false;
                  }
              });
              var controlName = 'name_';
              if (businessUnit.Name)
                  controlName = controlName + businessUnit.Name;
              controlName = controlName + '_' + index;
              if (isValid) {
                  $scope.metadataForm[controlName].$setValidity('unique', true);
              }
              else {
                  $scope.metadataForm[controlName].$setValidity('unique', false);
              }
          };

          $scope.isDirectoryAccessible = function (directoryPath, controlId) {
              var isAccessible = true;

              $rootScope.promise = sourceDirectoryDataFactory.hasDirectoryAccess(directoryPath).success(function (response) {
                  isAccessible = response;
                  if (isAccessible) {
                      $scope.metadataForm[controlId].$setValidity('accessible', true);
                  }
                  else {
                      $scope.metadataForm[controlId].$setValidity('accessible', false);
                  }
              });

          }
      }]);
