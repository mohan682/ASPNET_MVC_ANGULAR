"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('mainCtrl', ['$rootScope', '$scope', '$interval', '$location', '$mdDialog', 'uiGridConstants', 'recordsService', 'statementService',
      'reportdataDataFactory', 'statementPublishDataFactory', 'downloadDirectoryDataFactory', 'recordEditLogDataFactory', 'reStatementDataFactory',
function ($rootScope, $scope, $interval, $location, $mdDialog, uiGridConstants, recordsService, statementService,
    reportdataDataFactory, statementPublishDataFactory, downloadDirectoryDataFactory, recordEditLogDataFactory, reStatementDataFactory) {

    var getRecords = function () {
        $rootScope.promise = recordsService.getAllRecords().then(function (records) {
            $scope.gridOptions.data = recordsService.recordsprop;
            refreshEditInfoFn();
            startRefreshingEditInfo();
        }, function (error) {
            console.log(error);
        });
    };

    $scope.refreshRecords = function () {
        getRecords();
    }

    $scope.$watch(recordsService.records, function () {
        $scope.gridOptions.data = recordsService.recordsprop;
    });

    $rootScope.promise.then(function () {
        getRecords();        
    });

    $scope.gridOptions = {
        enableFiltering: true,
        showTreeExpandNoChildren: false,
        columnDefs: [
            {
                name: 'edit',
                displayName: 'Statement options',
                width: 200,
                cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                    if (row.entity.IsPublished) {
                        return 'publishedStatement';
                    }
                },

                cellTemplate: '<div layout="row"> ' +
                    ' <md-button ng-disabled="grid.appScope.isEditDisabled(row.entity)" md-no-ink layout-fill id=deleteBtn class="grid-icon-btn md-warn md-hue-2" ng-click="grid.appScope.deleteStatement(row.entity)">X<md-tooltip>Delete</md-tooltip></md-button>' +
                    ' <md-button ng-disabled="grid.appScope.isPublishDisabled(row.entity)" md-no-ink layout-fill id=publishBtn class="grid-icon-btn md-primary md-hue-2" ng-click="grid.appScope.publishStatement(row.entity)">{{grid.appScope.getPublishText(row.entity)}}<md-tooltip>{{grid.appScope.getPublishTooltip(row.entity)}}</md-tooltip></md-button>' +
                    ' <md-button ng-disabled="grid.appScope.isEditDisabled(row.entity)" md-no-ink layout-fill id=editBtn class="grid-icon-btn" ng-click="grid.appScope.editStatement(row.entity)"><img class="ng-scope" src="app/images/edit-icon.png"></img><md-tooltip>Edit</md-tooltip></md-button>' +
                    ' <md-button ng-disabled="grid.appScope.isViewDisabled(row.entity)" md-no-ink layout-fill id=viewBtn class="grid-icon-btn" ng-click="grid.appScope.viewStatement(row.entity)"><img class="ng-scope" src="app/images/view-icon.png"></img><md-tooltip>View</md-tooltip></md-button>' +
                    ' <md-button ng-disabled="grid.appScope.isExportDisabled(row.entity)" md-no-ink layout-fill id=exportBtn class="grid-icon-btn md-warn md-hue-2" ng-click="grid.appScope.exportStatement(row.entity)"><img class="ng-scope" src="app/images/download-icon.png"></img><md-tooltip>Export</md-tooltip></md-button>' +
                    ' <md-button ng-disabled="grid.appScope.isSplitDisabled(row.entity)" md-no-ink layout-fill id=splitBtn class="grid-icon-btn md-warn md-hue-2" ng-click="grid.appScope.splitStatement(row.entity)"><img class="ng-scope" src="app/images/split-icon.png"></img><md-tooltip>Split</md-tooltip></md-button>' +
                    //'<div style="margin:6px;" class="led-box"><div class="led-yellow"><md-tooltip>Record being edited</md-tooltip></div></div>' +
                    '<div id="inEditAnimation" ng-show="grid.appScope.isRecordBeingEdited(row.entity)" style="margin:6px;"><md-tooltip>Record being edited</md-tooltip></div>' +
                    ' </div>',
                enableSorting: false,
                enableFiltering: false,
                enableHiding: false
            },
            {
                field: 'Name', displayName: 'Name', cellTooltip: true
            },
            {
                field: 'HierarchySetName', displayName: 'Hierarchy Set', cellTooltip: true
            },
            {
                field: 'Description', cellTooltip: true, displayName: 'Description',
                cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                    if (row.entity.IsPublished) {
                        return 'publishedStatement';
                    }
                }
            },
            {
                field: 'Version', displayName: 'Version', width: 90,
                cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                    if (row.entity.IsPublished) {
                        return 'publishedStatement';
                    }
                }
            },
            {
                field: 'CreatedBy', displayName: 'Created By', width: 105,
                cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                    if (row.entity.IsPublished) {
                        return 'publishedStatement';
                    }
                }
            },
            {
                field: 'Created', displayName: 'Created Date', width: 150,
                cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                    if (row.entity.IsPublished) {
                        return 'publishedStatement';
                    }
                },
                sort: { direction: uiGridConstants.DESC, priority: 1 },
                cellTemplate: '<div class="ui-grid-cell-contents" id="createdColumn">{{grid.appScope.getCreatedDateTime(row.entity)| date:"dd MMM yyyy HH:mm:ss"}}</div>'
            },
            {
                field: 'Status', displayName: 'Status', width: 90,
                cellClass: function (grid, row, col, rowRenderIndex, colRenderIndex) {
                    if (row.entity.IsPublished) {
                        return 'publishedStatement';
                    }
                },
                cellTemplate: '<div class="ui-grid-cell-contents" id="statusColumn">' +
                    '<label class="{{grid.appScope.getStatusClass(row.entity)}}" md-tooltip={{grid.appScope.getStatusText(row.entity)}}>{{grid.appScope.getStatusText(row.entity)}}</label></div>'
            }
        ]
    };

    var quarters =
      [{ Name: '-', Id: 0 },
      { Name: '1Q', Id: 1 },
      { Name: '2Q', Id: 2 },
      { Name: '3Q', Id: 3 },
      { Name: '4Q', Id: 4 }];

    var isDate = function (date) {
        return (!isNaN(new Date(date)));
    }

    $scope.getQuarterText = function (rowEntity) {
        var quarterId = rowEntity.Quarter;
        var quarterName = quarterId
        angular.forEach(quarters, function (quarter) {
            if (quarter.Id === quarterId) {
                quarterName = quarter.Name;
            }
        });
        return quarterName;
    };

    $scope.getPublishText = function (rowEntity) {
        if (rowEntity.IsPublished) {
            return 'U';
        }
        return 'P';
    };

    $scope.getPublishTooltip = function (rowEntity) {
        if (rowEntity.IsPublished) {
            return 'Unpublish';
        }
        return 'Publish';
    };

    $scope.isPublishDisabled = function (rowEntity) {
        return (!$scope.getFeatureAccess($scope.availableFeatures.PublishStatement) || (rowEntity.Status != 2 && rowEntity.Status != 8) || !$scope.allowStatementPublished(rowEntity));
    };

    $scope.isExportDisabled = function (rowEntity) {
        return (!$scope.getFeatureAccess($scope.availableFeatures.ViewStatement) || (rowEntity.Status != 2 && rowEntity.Status != 8));
    };

    $scope.isSplitDisabled = function (rowEntity) {
        return (!$scope.getFeatureAccess($scope.availableFeatures.EditStatement) || rowEntity.Status != 2);
    };

    $scope.isEditDisabled = function (rowEntity) {
        return (!$scope.getFeatureAccess($scope.availableFeatures.EditStatement) || (rowEntity.Status != 2 && rowEntity.Status != 8));
    };

    $scope.isViewDisabled = function (rowEntity) {
        return !$scope.getFeatureAccess($scope.availableFeatures.ViewStatement);
    };

    $scope.getStatusText = function (rowEntity) {
        var statusId = rowEntity.Status;
        var statusName = 'Open';
        if (statusId == 0) {
            statusName = 'Uploading';
        }
        else if (statusId == 1) {
            statusName = 'Calculating';
        }
        else if (statusId == 2) {
            statusName = 'Open';
        }
        else if (statusId == 3 || statusId == 9) {
            statusName = 'Processing';
        }
        else if (statusId == 4) {
            statusName = 'Exporting';
        }
        else if (statusId == 5) {
            statusName = 'Saving';
        }
        else if (statusId == 6) {
            statusName = 'Merging';
        }
        else if (statusId == 7) {
            statusName = 'Splitting';
        }
        else if (statusId == 8) {
            statusName = 'Error';
        }
        return statusName;
    };

    $scope.getStatusClass = function (rowEntity) {
        var statusId = rowEntity.Status;
        var className = 'openStatus';
        if (statusId == 0) {
            className = 'uploadingStatus';
        }
        else if (statusId == 1) {
            className = 'calculatingStatus';
        }
        else if (statusId == 2) {
            className = 'openStatus';
        }
        else if (statusId == 8) {
            className = 'errorStatus';
        }
        else {
            className = 'processingStatus';
        }
        return className;
    };

    $scope.getCreatedDateTime = function (rowEntity) {
        var date = rowEntity.Created;
        if (isDate(date))
            return new Date(date);
        return "";
    };

    $scope.exportOptions = [{
        Id: 1,
        Name: "Export Statement Data"
    },
    {
        Id: 2,
        Name: "Export for Re-Statement"
    }];

    $scope.exportStatement = function (rowEntity) {

        $rootScope.promise = downloadDirectoryDataFactory.getDownloadDirectoryListByDownloadTypeId(1)
            .then(function (response) {
                $scope.exportDirectories = response.data;
                if ($scope.exportDirectories.length === 1) {
                    $scope.selectedExportDirectory = $scope.exportDirectories[0];
                    var selectedDirectoryId = $scope.selectedExportDirectory.Id;
                    //Show export options
                    $mdDialog.show({
                        controller: 'exportStatementCtrl',
                        templateUrl: 'app/templates/exportStatement.tmpl.html',
                        parent: angular.element(document.body),
                        locals: {
                            exportOptions: $scope.exportOptions
                        }
                    }).then(function (selectedOption) {
                        switch (selectedOption.Id) {
                            case 1:
                                reportdataDataFactory.generateExport(rowEntity.Id, selectedDirectoryId);
                                break;
                            case 2:
                                reStatementDataFactory.generateExport(rowEntity.Id, selectedDirectoryId);
                                break;
                        };                        
                        getRecords();
                    });                    
                }
            });
    };

    $scope.splitStatement = function (rowEntity) {
        $mdDialog.show({
            controller: 'splitStatementCtrl',
            templateUrl: 'app/templates/splitStatement.tmpl.html',
            parent: angular.element(document.body),
            locals: {
                record: rowEntity
            }
        }).then(function (options) {
            $rootScope.promise = statementService.isDuplicateRecord(options.hierarchySetName, options.year, options.businessUnit, options.quarter, options.statementType, options.month).then(function (isDuplicate) {
                if (isDuplicate) {
                    $mdDialog.show({
                        controller: 'saveAsNewVersionConfirmationCtrl',
                        templateUrl: 'app/templates/saveAsNewVersionConfirmation.tmpl.html',
                        parent: angular.element(document.body)
                    })
                  .then(function () {
                      splitRecord(options, true);
                  });
                }
                else {
                    splitRecord(options, false);
                }
            });

        }, function () {
        });
    };

    var splitProgressMessage = function () {
        $mdDialog.show(
                        $mdDialog.alert()
                        .parent(document.body)
                        .clickOutsideToClose(false)
                        .title('Split in progress')
                        .content('Split is initiated on the server and you will be notified when it is complete.')
                        .ariaLabel('Split initiated')
                        .ok('OK')
                    ).then(function () {
                        getRecords();
                    });
    };

    function splitRecord(options, asNewVersion) {        
        statementService.splitRecord(options, asNewVersion);
        splitProgressMessage();
    };

    $scope.allowStatementPublished = function (rowEntity) {
        if (rowEntity.IsPublished)
            return true; //As statement can be unpublished
        else {
            //Check if any other version of the statement is published and return false if so
            var records = $scope.gridOptions.data;
            var allowPublish = true;
            angular.forEach(records, function (record) {
                if (allowPublish)
                    if (record.Name === rowEntity.Name
                        && record.IsPublished) {
                        allowPublish = false;
                    }
            });
            return allowPublish;
        }
    };

    $scope.publishStatement = function (rowEntity) {
        if (rowEntity.IsPublished)
            $rootScope.promise = statementPublishDataFactory.unpublishStatement(rowEntity.Id).then(function () {
                getRecords();
            });
        else
            $rootScope.promise = statementPublishDataFactory.publishStatement(rowEntity.Id).then(function () {
                getRecords();
            });
    };

    $scope.deleteStatement = function (rowEntity) {
        $mdDialog.show({
            controller: 'deleteStatementConfirmationCtrl',
            templateUrl: 'app/templates/deleteStatementConfirmation.tmpl.html',
            parent: angular.element(document.body)
        }).then(function (deleteOption) {
            $rootScope.promise = recordsService.deleteRecord(rowEntity.Id, deleteOption === 'AllLowerVersions').then(function (records) {
                getRecords();
            }, function (error) {
                console.log(error);
            });
        }, function () {
        });
    };

    $scope.editStatement = function (rowEntity) {
        $location.path("/financialstatement/" + rowEntity.Id + "/edit");
    };

    $scope.viewStatement = function (rowEntity) {
        $location.path("/financialstatement/" + rowEntity.Id + "/view");
    };

    $scope.newStatement = function () {
        $location.path("/financialstatement/");
    };

    $scope.mergeStatement = function () {
        $location.path("/mergestatement/");
    };
    $scope.latestData = {};

    $scope.isRecordBeingEdited = function (rowEntity) {
        var isInEdit = false;
        angular.forEach($scope.recordsInEdit, function (item) {
            if (!isInEdit) {
                if (item === rowEntity.Id)
                    isInEdit = true;
            }
        });
        return isInEdit;
    };

    var refreshEditInfo;
    var refreshEditInfoFn = function () {
        recordEditLogDataFactory.getAllRecordEditLogs().then(function (response) {
            $scope.recordsInEdit = response.data;
            //console.log($scope.recordsInEdit);
        });

    };

    var startRefreshingEditInfo = function () {
        if (angular.isDefined(refreshEditInfo))
            return;
        refreshEditInfo = $interval(refreshEditInfoFn, 30000); //seconds
    };
    
    $scope.stopRefresh = function () {
        if (angular.isDefined(refreshEditInfo)) {
            $interval.cancel(refreshEditInfo);
            refreshEditInfo = undefined;
        }
    };

    $scope.$on('$destroy', function () {        
        $scope.stopRefresh();
    });
}]);
