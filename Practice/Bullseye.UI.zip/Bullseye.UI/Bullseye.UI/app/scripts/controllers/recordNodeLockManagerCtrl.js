﻿angular.module('bullseyeApp')
  .controller('recordNodeLockManagerCtrl', ['$rootScope', '$scope', '$mdDialog', 'recordNodeLockDataFactory', 'selectedRecord', 'viewType','hasEditPermission',
      function ($rootScope, $scope, $mdDialog, recordNodeLockDataFactory, selectedRecord, viewType, hasEditPermission) {
          $scope.decemberPreviousText = 'December(' + (selectedRecord.Year - 1) + ')';
          $scope.viewType = viewType;
          $scope.hasEditPermission = hasEditPermission;
          var statementId = selectedRecord.Id;
          var statementYear = selectedRecord.Year;
          var currentLockData = [];
          $rootScope.promise = recordNodeLockDataFactory.getRecordNodeLocks(statementId).then(
              function (result) {
                  currentLockData = result.data;
                  angular.forEach(result.data, function (item) {
                      var date = new Date(item.Date)
                      var month = date.getMonth();
                      var year = date.getFullYear();
                      if (year === selectedRecord.Year) {
                          switch (month) {
                              case 0:
                                  $scope.janLocked = true;
                                  break;
                              case 1:
                                  $scope.febLocked = true;
                                  break;
                              case 2:
                                  $scope.marLocked = true;
                                  break;
                              case 3:
                                  $scope.aprLocked = true;
                                  break;
                              case 4:
                                  $scope.mayLocked = true;
                                  break;
                              case 5:
                                  $scope.junLocked = true;
                                  break;
                              case 6:
                                  $scope.julLocked = true;
                                  break;
                              case 7:
                                  $scope.augLocked = true;
                                  break;
                              case 8:
                                  $scope.sepLocked = true;
                                  break;
                              case 9:
                                  $scope.octLocked = true;
                                  break;
                              case 10:
                                  $scope.novLocked = true;
                                  break;
                              case 11:
                                  $scope.decLocked = true;
                                  break;
                          }
                      }
                      else if (year === (selectedRecord.Year - 1) && month === 11) {
                          $scope.decPrevLocked = true;
                      }
                  });

              },
              function () { });

          var getExistingItem = function (month, year) {
              var existingItem = null;
              angular.forEach(currentLockData, function (item) {
                  var date = new Date(item.Date);
                  if (month === date.getMonth() && year === date.getFullYear())
                      existingItem = item;
              });
              return existingItem;
          };

          var addNewItem = function (newItems, year, month, timePeriodEnum) {
              newItems.push({
                  Record_Id: statementId,
                  Date: new Date(year, month, 2),
                  TimePeriodEnum: timePeriodEnum
              });
              return newItems
          };

          $scope.ok = function () {
              var newItems = [];
              var prevYear = statementYear - 1;
              if ($scope.decPrevLocked) {
                  var existingItem = getExistingItem(11, prevYear);
                  if (!existingItem)
                      newItems = addNewItem(newItems, prevYear, 11, 0);
                  else
                      newItems.push(existingItem);
              }
              for (var month = 0; month < 12; month++) {                  
                  switch (month) {
                      case 0:
                          if ($scope.janLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 1:
                          if ($scope.febLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 2:
                          if ($scope.marLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 3:
                          if ($scope.aprLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 4:
                          if ($scope.mayLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 5:
                          if ($scope.junLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 6:
                          if ($scope.julLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 7:
                          if ($scope.augLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 8:
                          if ($scope.sepLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 9:
                          if ($scope.octLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 10:
                          if ($scope.novLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                      case 11:
                          if ($scope.decLocked) {
                              var existingItem = getExistingItem(month, statementYear);
                              if (!existingItem)
                                  newItems = addNewItem(newItems, statementYear, month, 0);
                              else
                                  newItems.push(existingItem);
                          }
                          break;
                  }
              }

              $rootScope.promise = recordNodeLockDataFactory.saveRecordNodeLocks(statementId, newItems).then(function () { $mdDialog.hide(); });
          }
          $scope.cancel = function () {
              $mdDialog.cancel();
          }
      }]);