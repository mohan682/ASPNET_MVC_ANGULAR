﻿angular.module('bullseyeApp').controller('createStatementInitiateCtrl', ['$rootScope', '$scope', '$q', '$mdDialog', 'years', 'statementTypeDataFactory',
    'hierarchySetDataFactory', 'businessUnitDataFactory',
    function ($rootScope, $scope, $q, $mdDialog, years, statementTypeDataFactory, hierarchySetDataFactory, businessUnitDataFactory) {
        $scope.years = years.validYears;
        $scope.monthAllowed = false;
        $scope.firstQuarterMonths = [null, "JAN", "FEB", "MAR"];
        $scope.secondQuarterMonths = [null, "APR", "MAY", "JUN"];
        $scope.thirdQuarterMonths = [null, "JUL", "AUG", "SEP"];
        $scope.fourthQuarterMonths = [null, "OCT", "NOV", "DEC"];
        $scope.months = [null];
        $scope.selectedRecord = {};
        $scope.selectedRecord.Year = years.currentYear;
        

        $scope.ok = function () {            
            if ($scope.selectedRecord.Month === '')
                $scope.selectedRecord.Month = null;
            $mdDialog.hide($scope.selectedRecord);
        };

        var getData = function () {
            var promises = [];
            var stDefer = $q.defer();
            statementTypeDataFactory.getStatementTypeList().success(function (data) {
                $scope.statementTypes = data;
                if ($scope.selectedRecord.StatementType == null)
                    $scope.selectedRecord.StatementType = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            var buDefer = $q.defer();
            businessUnitDataFactory.getBusinessUnitList().success(function (data) {
                $scope.businessUnits = data;
                if ($scope.selectedRecord.BusinessUnit == null)
                    $scope.selectedRecord.BusinessUnit = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            var hsDefer = $q.defer();
            hierarchySetDataFactory.getHierarchySetList().success(function (data) {
                $scope.hierarchySetList = data;
                //if ($scope.selectedRecord.HierarchySet == null)
                //    $scope.selectedRecord.HierarchySet = data[0];
                hsDefer.resolve();
            });

            promises.push(hsDefer.promise);

            return $q.all(promises);
        };

        $rootScope.promise = getData();

        $scope.quarters =
            [{ Name: '-', Id: 0 },
            { Name: '1Q', Id: 1 },
            { Name: '2Q', Id: 2 },
            { Name: '3Q', Id: 3 },
            { Name: '4Q', Id: 4 }];

        $scope.selectedRecord.Quarter = $scope.quarters[0].Id;

        $scope.quarterChanged = function () {
            $scope.selectedRecord.Month = null;
            if ($scope.selectedRecord.Quarter === "0")
                $scope.monthAllowed = false;
            else {
                $scope.monthAllowed = true;

                switch ($scope.selectedRecord.Quarter) {
                    case "1":
                        $scope.months = $scope.firstQuarterMonths;
                        break;
                    case "2":
                        $scope.months = $scope.secondQuarterMonths;
                        break;
                    case "3":
                        $scope.months = $scope.thirdQuarterMonths;
                        break;
                    case "4":
                        $scope.months = $scope.fourthQuarterMonths;
                        break;
                }
            }
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };        
    }]);