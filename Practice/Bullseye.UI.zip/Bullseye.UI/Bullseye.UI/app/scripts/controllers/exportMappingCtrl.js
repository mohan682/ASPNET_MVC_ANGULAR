﻿angular.module('bullseyeApp').controller('exportMappingCtrl', ['$rootScope', '$scope', '$mdDialog', 'mappingTypes', 'tprMappingDataFactory', 'fbwMappingDataFactory',
function ($rootScope, $scope, $mdDialog, mappingTypes, tprMappingDataFactory, fbwMappingDataFactory) {
    $scope.message = "Please Wait...";
    $scope.mappingTypes = mappingTypes;

    $scope.mappingTypeChanged = function () {
        var selectedId = $scope.selectedMappingType.Id;
        switch (selectedId) {
            case 0:
                //if an intermediate method or process needs to be performed on selection changed, it can be plugged in here
                //$scope.exportPromise = tprMappingDataFactory.exportTprMappings().then(function (response) {
                  //  $mdDialog.cancel();
                    //});                                
                break;
            case 1:
                //TODO
                break;
        }
    };
    
    $scope.export = function () {
        $mdDialog.hide({ mappingTypeId: $scope.selectedMappingType.Id });
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };
}]);