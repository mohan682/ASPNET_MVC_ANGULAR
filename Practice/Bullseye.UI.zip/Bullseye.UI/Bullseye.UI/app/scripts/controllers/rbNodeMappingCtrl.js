﻿angular.module('bullseyeApp').controller('rbNodeMappingCtrl', ['$rootScope', '$scope', '$filter',
function ($rootScope, $scope, $filter) {
    $scope.addTprMapping = function () {
        $scope.rbNodeDetails.tprFilter = undefined;
        $scope.filterTprMapList();
        $scope.rbNodeDetails.TprHierarchyNodeMapList.push({
            BusinessCode: '',
            SourceNodeCode: ''
        });

        $scope.setLastTprPage();
    };

    $scope.addFbwMapping = function()
    {
        $scope.rbNodeDetails.fbwFilter = undefined;
        $scope.filterFbwMapList()
        $scope.rbNodeDetails.FbwHierarchyNodeMapList.push({
            BusinessCode: '',
            SourceNodeCode: ''
        });

        $scope.setLastFbwPage();
    }

    $scope.deleteTprMapping = function (mapping) {
        var index = $scope.rbNodeDetails.TprHierarchyNodeMapList.indexOf(mapping);
        if (index > -1) {
            $scope.rbNodeDetails.TprHierarchyNodeMapList.splice(index, 1);
        }
    };

    $scope.deleteFbwMapping = function (mapping) {
        var index = $scope.rbNodeDetails.FbwHierarchyNodeMapList.indexOf(mapping);
        if (index > -1) {
            $scope.rbNodeDetails.FbwHierarchyNodeMapList.splice(index, 1);
        }
    };

    $scope.isTprMappingUnique = function (givenMapping, index) {
        var isValid = true;
        var newMap = null;
        if (givenMapping.SourceNodeCode)
            newMap = givenMapping.SourceNodeCode.toLowerCase();
        angular.forEach($scope.rbNodeDetails.TprHierarchyNodeMapList, function (map) {
            var mapped = null;
            if (map.SourceNodeCode)
                mapped = map.SourceNodeCode.toLowerCase();            

            if (givenMapping !== map && mapped === newMap) {
                isValid = false;
            }
        });
        var namePart = '';
        if (givenMapping.SourceNodeCode)
            namePart = givenMapping.SourceNodeCode;
        if (isValid) {
            $scope.hierarchySetDetailForm['tprname_' + namePart + '_' + index].$setValidity('unique', true);
        }
        else {
            $scope.hierarchySetDetailForm['tprname_' + namePart + '_' + index].$setValidity('unique', false);
        }
    };

    $scope.isFbwMappingUnique = function (givenMapping, index) {
        var isValid = true;
        var newMap = null;
        if (givenMapping.SourceNodeCode)
            newMap = givenMapping.SourceNodeCode.toLowerCase();
        angular.forEach($scope.rbNodeDetails.FbwHierarchyNodeMapList, function (map) {
            var mapped = null;
            if (map.SourceNodeCode)
                mapped = map.SourceNodeCode.toLowerCase();
            
            if (givenMapping !== map && mapped === newMap) {
                isValid = false;
            }
        });
        if (isValid) {
            var namePart = '';
            if (givenMapping.SourceNodeCode)
                namePart = givenMapping.SourceNodeCode;
            $scope.hierarchySetDetailForm['fbwname_' + namePart + '_' + index].$setValidity('unique', true);
        }
        else {
            var namePart = '';
            if (givenMapping.SourceNodeCode)
                namePart = givenMapping.SourceNodeCode;
            $scope.hierarchySetDetailForm['fbwname_' + namePart + '_' + index].$setValidity('unique', false);
        }
    };

    $scope.filteredTprMappings = [];
    $scope.filteredFbwMappings = [];
    $scope.currentTprPage = 0;
    $scope.currentFbwPage = 0;
    $scope.tprPageSize = 5;
    $scope.fbwPageSize = 5;

    $scope.setCurrentTprPage = function (currentTprPage) {
        $scope.currentTprPage = currentTprPage;
        $scope.tprPages = $scope.getTprNumberAsArray($scope.numberOfTprPages($scope.rbNodeDetails.tprFilter));
    }

    $scope.setCurrentFbwPage = function (currentFbwPage) {
        $scope.currentFbwPage = currentFbwPage;
        $scope.fbwPages = $scope.getFbwNumberAsArray($scope.numberOfFbwPages($scope.rbNodeDetails.fbwFilter));
    }

    $scope.getTprNumberAsArray = function (num) {
        if (num > 3) {
            if ($scope.currentTprPage === num - 1) {
                $scope.startTprPage = $scope.currentTprPage - 2;
                $scope.endTprPage = $scope.currentTprPage;
            }
            else if ($scope.currentTprPage === 0) {
                $scope.startTprPage = $scope.currentTprPage;
                $scope.endTprPage = $scope.currentTprPage + 2;
            }
            else {
                $scope.startTprPage = $scope.currentTprPage - 1;
                $scope.endTprPage = $scope.currentTprPage + 1;
            }

            var pages = [];
            for (var i = $scope.startTprPage; i <= $scope.endTprPage; i++) {
                pages.push(i);
            }
            return pages;
        }
        else {
            var pages = [];
            for (var i = 0; i < num; i++) {
                pages.push(i);
            }
            return pages;
        }
    };

    $scope.getFbwNumberAsArray = function (num) {
        if (num > 3) {
            if ($scope.currentFbwPage === num - 1) {
                $scope.startFbwPage = $scope.currentFbwPage - 2;
                $scope.endFbwPage = $scope.currentFbwPage;
            }
            else if ($scope.currentFbwPage === 0) {
                $scope.startFbwPage = $scope.currentFbwPage;
                $scope.endFbwPage = $scope.currentFbwPage + 2;
            }
            else {
                $scope.startFbwPage = $scope.currentFbwPage - 1;
                $scope.endFbwPage = $scope.currentFbwPage + 1;
            }

            var pages = [];
            for (var i = $scope.startFbwPage; i <= $scope.endFbwPage; i++) {
                pages.push(i);
            }
            return pages;
        }
        else {
            var pages = [];
            for (var i = 0; i < num; i++) {
                pages.push(i);
            }
            return pages;
        }
    };

    $scope.numberOfTprPages = function (filter) {
        if ($scope.rbNodeDetails) {
            $scope.filteredTprMappings = $filter('filter')($scope.rbNodeDetails.TprHierarchyNodeMapList, { SourceNodeCode: filter });
            return Math.ceil($scope.filteredTprMappings.length / $scope.tprPageSize);
        }
        else
            return 0;
    };

    $scope.numberOfFbwPages = function (filter) {
        if ($scope.rbNodeDetails) {
            $scope.filteredFbwMappings = $filter('filter')($scope.rbNodeDetails.FbwHierarchyNodeMapList, { SourceNodeCode: filter });
            return Math.ceil($scope.filteredFbwMappings.length / $scope.fbwPageSize);
        }
        else
            return 0;
    };

    $scope.filterTprMapList = function () {
        $scope.currentTprPage = 0;
        $scope.tprPages = $scope.getTprNumberAsArray($scope.numberOfTprPages($scope.rbNodeDetails.tprFilter));
    };

    $scope.filterFbwMapList = function () {
        $scope.currentFbwPage = 0;
        $scope.fbwPages = $scope.getFbwNumberAsArray($scope.numberOfFbwPages($scope.rbNodeDetails.fbwFilter));
    };

    $scope.$watch('rbNodeDetails', function () {
        if ($scope.rbNodeDetails) {
            $scope.tprPages = $scope.getTprNumberAsArray($scope.numberOfTprPages(''));
            $scope.fbwPages = $scope.getFbwNumberAsArray($scope.numberOfFbwPages(''));
        }
    });

    $scope.setLastTprPage = function () {
        if ($scope.rbNodeDetails) {
            var pageCount = $scope.numberOfTprPages($scope.rbNodeDetails.tprFilter);
            $scope.setCurrentTprPage(pageCount - 1);
        }
    };

    $scope.setLastFbwPage = function () {
        if ($scope.rbNodeDetails) {
            var pageCount = $scope.numberOfFbwPages($scope.rbNodeDetails.fbwFilter);
            $scope.setCurrentFbwPage(pageCount - 1);
        }
    };

    $scope.isFirstTprPageDisabled = function () {
        if ($scope.currentTprPage === 0)
            return true;
        return false;
    };

    $scope.isFirstFbwPageDisabled = function () {
        if ($scope.currentFbwPage === 0)
            return true;
        return false;
    };

    $scope.isLastTprPageDisabled = function () {
        if ($scope.rbNodeDetails) {
            var pageCount = $scope.numberOfTprPages($scope.rbNodeDetails.tprFilter);
            if ($scope.currentTprPage === pageCount - 1)
                return true;
        }
        return false;
    };

    $scope.isLastFbwPageDisabled = function () {
        if ($scope.rbNodeDetails) {
            var pageCount = $scope.numberOfFbwPages($scope.rbNodeDetails.fbwFilter);
            if ($scope.currentFbwPage === pageCount - 1)
                return true;
        }
        return false;
    };    
}]);