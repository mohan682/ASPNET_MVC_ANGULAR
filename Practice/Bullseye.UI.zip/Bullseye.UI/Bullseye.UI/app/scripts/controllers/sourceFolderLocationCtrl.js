﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:sourcefolderlocationCtrl
 * @description
 * # sourcefolderlocationCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('sourcefolderlocationCtrl', ['$q', '$rootScope', '$scope', '$location', '$mdDialog', 'sourceTypeDataFactory', 'sourceDirectoryDataFactory',
      function ($q, $rootScope, $scope, $location, $mdDialog, sourceTypeDataFactory, sourceDirectoryDataFactory) {

          $rootScope.promise = sourceTypeDataFactory.getSourceTypeList().success(function (sourceTypeList) {
              $scope.sourceTypeList = [];
              angular.forEach(sourceTypeList, function(sourceType) {
                  sourceType.sourceDirectoryList = [];
                  $rootScope.promise = sourceDirectoryDataFactory.getSourceDirectoryListBySourceTypeId(sourceType.Id).success(function(data) {
                      sourceType.sourceDirectoryList = data;
                  });
                  $scope.sourceTypeList.push(sourceType);
              });
          });

          $rootScope.promise = sourceDirectoryDataFactory.getServiceAccountName().success(function (accountName) {
              $scope.serviceAccountName = accountName;
          });        

          var saveSourceDirectories = function () {
              ////Update each statement type - Only works for updating
              //var stPromises = $scope.sourceDirectoryList.map(function (sourceDirectory) {
              //    return sourceDirectoryDataFactory.updateSourceDirectory(sourceDirectory);
              //});

              //return $q.all(stPromises);
              var sourceDirectoryList = [];
              angular.forEach($scope.sourceTypeList, function (sourceType) {
                  angular.forEach(sourceType.sourceDirectoryList, function (sourceDirectory) {
                      sourceDirectoryList.push(sourceDirectory);                     
                  });
              });
              return sourceDirectoryDataFactory.saveSourceDirectoryList(sourceDirectoryList);
          };

          $scope.save = function () {
              var confirm = $mdDialog.confirm()
                                .title('Confirmation')
                                .content('Would you like to Save changes to folder locations?')
                                .ariaLabel('Confirmation')
                                .ok('OK')
                                .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  var promises = [];
                  promises.push(saveSourceDirectories());

                  $rootScope.promise = $q.all(promises);
                  $rootScope.promise.then(function () {
                      $mdDialog.show(
                              $mdDialog.alert()
                              .parent(angular.element(document.body))
                              .clickOutsideToClose(false)
                              .title('Success')
                              .content('Changes are successfully saved')
                              .ariaLabel('Success')
                              .ok('OK')
                          )
                          .finally(function () {
                              //$location.path('/');
                          });
                  });
              });
          };

          $scope.cancel = function () {
              var confirm = $mdDialog.confirm()
                                .title('Confirmation')
                                .content('You will lose all the changes you made in the current session. Do you want to continue?')
                                .ariaLabel('Confirmation')
                                .ok('OK')
                                .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  $location.path('/');
              });
          };

          $scope.addSourceTypeLocation = function (sourceType) {
              var newSourceTypeLocation = {
                  SourceTypeId: sourceType.Id,
                  SourceTypeName: sourceType.Name
              };
              sourceType.sourceDirectoryList.push(newSourceTypeLocation);
          };

          $scope.removeSourceTypeLocation = function (sourceType, sourceDirectory) {
              var index = sourceType.sourceDirectoryList.indexOf(sourceDirectory);
              if (index > -1) {
                  sourceType.sourceDirectoryList.splice(index, 1);
              }
          };

          $scope.sourceTypeSelected = function (sourceType, index) {
              $scope.selectedSourceType = sourceType;
              $scope.selectedIndex = index;
          };

          $scope.isSelectedItem = function (index) {
              return index === $scope.selectedIndex;
          }

          $scope.isDirectoryAccessible = function (givenDirectory, index) {
              var isAccessible = true;

              $rootScope.promise = sourceDirectoryDataFactory.hasDirectoryAccess(givenDirectory.DirectoryPath).success(function (response) {
                  isAccessible = response;
                  if (isAccessible) {
                      $scope.sourceDirectoryForm['path_' + givenDirectory.SourceTypeName + '_' + index].$setValidity('accessible', true);
                  }
                  else {
                      $scope.sourceDirectoryForm['path_' + givenDirectory.SourceTypeName + '_' + index].$setValidity('accessible', false);
                  }
              });

          }

          $scope.isNameUnique = function (givenDirectory, index) {
              var isValid = true;
              angular.forEach($scope.selectedSourceType.sourceDirectoryList, function (directory) {
                  if (givenDirectory !== directory && directory.Name === givenDirectory.Name) {
                      isValid = false;
                  }
              });
              if (isValid) {
                  $scope.sourceDirectoryForm['name_' + givenDirectory.SourceTypeName + '_' + index].$setValidity('unique', true);
              }
              else {
                  $scope.sourceDirectoryForm['name_' + givenDirectory.SourceTypeName + '_' + index].$setValidity('unique', false);
              }
          };
      }]);
