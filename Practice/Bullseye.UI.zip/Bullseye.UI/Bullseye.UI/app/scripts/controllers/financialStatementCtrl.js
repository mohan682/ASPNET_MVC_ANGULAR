﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:FinancialStatementCtrl
 * @description
 * # FinancialStatementCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('financialStatementCtrl', ['$scope', '$rootScope', '$q', '$location', '$routeParams', '$mdDialog',
      '$mdSidenav', '$mdUtil', '$interval',
      'hierarchyDataFactory', 'hierarchySetDataFactory', 'sourceTypeDataFactory', 'applicationConfigDataFactory',
      'statementService', 'recordsService', 'reportdataDataFactory', 'recordStatusDataFactory', 'recordEditLogDataFactory',
      'adjustmentFileUploadDataFactory',
      function ($scope, $rootScope, $q, $location, $routeParams, $mdDialog,
          $mdSidenav, $mdUtil, $interval,
          hierarchyDataFactory, hierarchySetDataFactory, sourceTypeDataFactory, applicationConfigDataFactory,
          statementService, recordsService, reportdataDataFactory, recordStatusDataFactory, recordEditLogDataFactory,
          adjustmentFileUploadDataFactory) {
          $scope.isFSHierarchyLoaded = false;
          $scope.isRBHierarchyLoaded = false;
          //var selectedRecordId;
          var decPrevYear = "December(Prev)";
          $scope.monthNames = [decPrevYear, "January", "February", "March", "April", "May", "June",
              "July", "August", "September", "October", "November", "December"
          ];

          $scope.quarterNames = ["1Q", "2Q", "3Q", "4Q"];

          $scope.halfYearNames = ["1H", "2H"];

          $scope.selectedTabIndex = 2;

          $scope.months = [];
          for (var i = 0; i < $scope.monthNames.length; i++) {
              var id = i;
              if ($scope.monthNames[i] === decPrevYear)
                  id = -1;
              $scope.months.push({
                  name: $scope.monthNames[i],
                  id: id,
                  children: [],
                  selected: true
              });
          }         

          function createRecord() {
              $scope.isNew = true;
              $rootScope.promise = statementService.createRecord(false, $scope.hierarchySet.Name, $scope.financialStatementHierarchy.Id, $scope.rbHierarchy.Id, $scope.selectedYear,
                  $scope.statementType, $scope.businessUnit, $scope.quarter, $scope.description, $scope.month).then(function (data) {
                      $scope.currentRecord = statementService.selectedRecord();
                      if (data.ValidationMessageList) {
                          angular.forEach(data.ValidationMessageList, function (validationMessage) {
                              if (validationMessage.Message.indexOf("Duplicate") > -1) {
                                  $mdDialog.show({
                                      controller: 'saveAsNewVersionConfirmationCtrl',
                                      templateUrl: 'app/templates/saveAsNewVersionConfirmation.tmpl.html',
                                      parent: angular.element(document.body)
                                  })
                                .then(function () {
                                    $rootScope.promise = statementService.createRecord(true, $scope.hierarchySet.Name, $scope.financialStatementHierarchy.Id, $scope.rbHierarchy.Id,
                                        $scope.selectedYear, $scope.statementType, $scope.businessUnit, $scope.quarter, $scope.description, $scope.month).then(function (data) {
                                            $scope.currentRecord = statementService.selectedRecord();
                                        });
                                }, function () {
                                    showNewRecordDialog();
                                });
                              }
                          });
                      }
                  });
          };

          function fetchRecord(statementId) {
              var promises = [];
              var sourceTypeDefer = $q.defer();
              sourceTypeDataFactory.getSourceTypeList().success(function (data) {
                  $scope.sourceTypeList = data;
                  angular.forEach($scope.sourceTypeList, function (sourceType) {
                      sourceType.ShowSourceColumn = true;
                  });
                  sourceTypeDefer.resolve();
              });
              promises.push(sourceTypeDefer.promise);

              var deferred = $q.defer();
              $rootScope.promise = statementService.getRecord(statementId).then(function () {
                  if (statementService.selectedRecord() == null)
                      $location.path('/');
                  else {
                      $scope.currentRecord = statementService.selectedRecord();
                      setFsTree($scope.currentRecord.FinancialStatementHierarchy);
                      setRbTree($scope.currentRecord.RBHierarchy);
                      $scope.sideNavPromise = statementService.getRecordLogs(statementId).then(
                          function (data) {
                              $scope.recordLogEntries = data;
                          },
                          function (error) {
                              console.log(error);
                          });;
                  }
                  deferred.resolve();
              }, function (error) {
                  //TODO: Error handling
                  console.log(error);
                  deferred.reject();
              });
              promises.push(deferred.promise);

              return $q.all(promises);
          };

          $scope.showLogDetails = function (groupId) {
              $rootScope.promise = statementService.getRecordLogDetails($scope.selectedRecordId, groupId).then(
                  function (data) {
                      $mdDialog.show({
                          controller: 'uploadLogDetailCtrl',
                          templateUrl: 'app/templates/uploadLogDetail.tmpl.html',
                          parent: angular.element(document.body),
                          locals: {
                              recordLogDetails: data
                          }
                      })
                  },
                  function (error) {
                      console.log(error);
                  });
          };

          $scope.showAuditLogDetails = function () {
              $rootScope.promise = statementService.getAuditLogs($scope.selectedRecordId).then(
                     function (data) {
                         $mdDialog.show({
                             controller: 'auditLogDetailCtrl',
                             templateUrl: 'app/templates/auditLogDetail.tmpl.html',
                             parent: angular.element(document.body),
                             locals: {
                                 auditLogDetails: data
                             }
                         })
                     },
                  function (error) {
                      console.log(error);
                  });
          };

          function setFsTree(hierarchy) {
              $scope.financialStatementHierarchy = hierarchy;              
              $scope.isFSHierarchyLoaded = true;
          }

          function setRbTree(hierarchy) {
              $scope.rbHierarchy = hierarchy;              
              $scope.isRBHierarchyLoaded = true;
              $rootScope.$broadcast("isRBHierarchyLoaded");
          }

          function getInitialData() {
              $scope.isFSHierarchyLoaded = false;
              $scope.isRBHierarchyLoaded = false;

              var promises = [];
              var sourceTypeDefer = $q.defer();
              sourceTypeDataFactory.getSourceTypeList().success(function (data) {
                  $scope.sourceTypeList = data;
                  angular.forEach($scope.sourceTypeList, function (sourceType) {
                      sourceType.ShowSourceColumn = true;
                  });
                  sourceTypeDefer.resolve();
              });
              promises.push(sourceTypeDefer.promise);

              var hierarchySetDefer = $q.defer();
              hierarchySetDataFactory.getHierarchySet($scope.hierarchySet.Id).success(function (data) {
                  setFsTree(data.FinancialStatementHierarchy);
                  setRbTree(data.RBHierarchy);
                  if ($scope.selectedRecordId === undefined) {
                      createRecord();
                  }
                  hierarchySetDefer.resolve();
              });
              promises.push(hierarchySetDefer.promise);
              return $q.all(promises);
          };

          var showNewRecordDialog = function () {
              if ($routeParams.statementId === undefined) {
                  $mdDialog.show({
                      controller: 'createStatementInitiateCtrl',
                      templateUrl: 'app/templates/createStatementInitiate.tmpl.html',
                      parent: angular.element(document.body),
                      //targetEvent: ev,
                      locals: {
                          years: getValidYears()
                      }
                  })
                      .then(function (selectedRecord) {
                          $scope.selectedYear = selectedRecord.Year;
                          $scope.statementType = selectedRecord.StatementType;
                          $scope.businessUnit = selectedRecord.BusinessUnit;
                          $scope.quarter = selectedRecord.Quarter;
                          $scope.description = selectedRecord.Description;
                          $scope.month = selectedRecord.Month;
                          $scope.hierarchySet = selectedRecord.HierarchySet;
                          //get trees
                          $rootScope.promise = getInitialData().then(function () { startRecordEditLogging() });
                      }, function () {
                          //modal dismissed
                          $location.path('/');
                      });

              } else {
                  $scope.selectedRecordId = $routeParams.statementId;
                  if ($scope.viewType === 'edit')
                      $scope.allowSave = true;
                  fetchRecord($scope.selectedRecordId).then(function () {
                      startRecordEditLogging();
                  });
              }
          };

          var saveStatement = function () {
              if ($scope.isNew) {
                  statementService.save();
                  saveProgressMessage();
              }
              else {
                  $mdDialog.show({
                      controller: 'savestatementconfirmationCtrl',
                      templateUrl: 'app/templates/savestatementconfirmation.tmpl.html',
                      parent: angular.element(document.body),
                      locals: {
                          isNew: ($scope.selectedRecordId === undefined)
                      }
                  })
                  .then(function () {
                      if (statementService.selectedRecord().SaveType === "SaveNew") {
                          $rootScope.promise = statementService.isValidNewRecord().then(function (isValid) {
                              if (!isValid) {
                                  $mdDialog.show({
                                      controller: 'saveAsNewVersionConfirmationCtrl',
                                      templateUrl: 'app/templates/saveAsNewVersionConfirmation.tmpl.html',
                                      parent: angular.element(document.body)
                                  })
                                .then(function () {
                                    statementService.saveAsNewVersion();
                                    saveProgressMessage();
                                });
                              } else {
                                  statementService.saveAsNewRecord();
                                  saveProgressMessage();
                              }

                          });
                      }
                      else {
                          statementService.saveAsNewVersion();
                          saveProgressMessage();
                      }
                  }, function () {
                  });
              }
          };

          var saveProgressMessage = function (record) {
              $mdDialog.show(
                              $mdDialog.alert()
                              .parent(document.body)
                              .clickOutsideToClose(false)
                              .title('Save in progress')
                              .content('Save is initiated on the server and you will be notified when it is complete.')
                              .ariaLabel('Save initiated')
                              .ok('OK')
                          ).then(function () {
                              $location.path('/');
                          });
          };

          function buildSideNavigation(navId) {
              var debounceFn = $mdUtil.debounce(function () {
                  $mdSidenav(navId)
                    .toggle()
                    .then(function () {
                    });
              }, 300);
              return debounceFn;
          };

          var getConfigData = function () {
              var promises = [];
              var appConfigDefer = $q.defer();
              applicationConfigDataFactory.getApplicationConfigs().success(function (data) {
                  $scope.applicationConfigs = data;
                  //Find Years Past and Future
                  angular.forEach(data, function (item) {
                      if (item.KeyName === 'YearsFuture') {
                          $scope.YearsFuture = parseInt(item.Value, 10) || 0;
                      }
                      else if (item.KeyName === 'YearsPast') {
                          $scope.YearsPast = parseInt(item.Value, 10) || 0;
                      }
                  }, this);
                  appConfigDefer.resolve();
              });

              promises.push(appConfigDefer.promise);
              return $q.all(promises);
          }

          function getValidYears() {
              var validYears = [];
              var currentYear = new Date().getFullYear();
              for (var i = $scope.YearsPast * -1; i <= $scope.YearsFuture; i++)
                  validYears.push(currentYear + i);
              return { validYears: validYears, currentYear: currentYear }
          };          

          $scope.closeProperties = function () {
              $mdSidenav('properties').close()
                .then(function () {
                    //$log.debug("close RIGHT is done");
                });
          };

          $scope.toggleProperties = buildSideNavigation('properties');

          $scope.selectedToggle = {};

          $scope.showTreeView = false;

          $scope.getMonthName = function (value) {
              switch (value.TimePeriodEnum) {
                  case 0:
                      var date = new Date(value.Date);
                      if ($scope.currentRecord.Year != date.getFullYear())
                          return $scope.monthNames[new Date(value.Date).getMonth() + 1] + '(' + new Date(value.Date).getFullYear() + ')';
                      else
                          return $scope.monthNames[date.getMonth() + 1];
                      break;
                  case 1:
                      return $scope.quarterNames[new Date(value.Date).getMonth() / 3];
                      break;
                  case 2:
                      return $scope.halfYearNames[new Date(value.Date).getMonth() / 6];
                      break;
                  case 3:
                      return "3QTD";
                      break;
                  case 4:
                      return "FY";
                      break;
              }
          };

          $scope.showUploadSource = function () {
              $rootScope.promise = statementService.saveAdjustments().then(function () {
                  $mdDialog.show({
                      controller: 'uploadSourceCtrl',
                      templateUrl: 'app/templates/uploadsource.tmpl.html',
                      parent: angular.element(document.body),
                      locals: {
                          selectedRecord: $scope.currentRecord
                      }
                  })
                      .then(function (selectionData) {
                          var selectedId = selectionData.sourceTypeId;                          
                          var selectedFileName = selectionData.selectedFileName;
                          if (selectionData.isAdjustmentUpload)
                          {
                              $scope.updateGridView = false;
                              $scope.adjustmentUpload = {};
                              $rootScope.promise = adjustmentFileUploadDataFactory.loadAdjustmentsFile($scope.currentRecord.Id, selectedFileName).then(function (response) {                                                                    
                                  $scope.adjustmentUpload.loadResponse = response.data;
                                  $scope.isAdjustmentUpload = selectionData.isAdjustmentUpload;                                      
                              });                              
                          }
                          else
                          {
                              $mdDialog.show(
                                  $mdDialog.alert()
                                  .parent(document.body)
                                  .clickOutsideToClose(false)
                                  .title('Upload in progress')
                                  .content('Upload is initiated on the server and you will be notified when it is complete.')
                                  .ariaLabel('Upload initiated')
                                  .ok('OK')
                              ).then(function () {
                                  $location.path('/');
                              });
                          }
                      }, function () {
                      });
              });
          };

          $scope.cancelAdjustmentUpload = function () {              
              $scope.isAdjustmentUpload = false;
              $scope.updateGridView = true;
          };

          $scope.setSaveStatus = function(status)
          {
              $scope.allowSave = status;
          }

          $scope.calculateKpi = function (type) {
              $rootScope.promise = statementService.saveAdjustments().then(function () {
                  statementService.calculateKpi($scope.currentRecord.Id, type);                  
                  $mdDialog.show(
                              $mdDialog.alert()
                              .parent(document.body)
                              .clickOutsideToClose(false)
                              .title('KPI Calculation in progress')
                              .content('KPI Calculation is initiated on the server and you will be notified when it is complete.')
                              .ariaLabel('KPI Calculation initiated')
                              .ok('OK')
                          ).then(function () {
                              $location.path('/');
                          });
              });
          };

          $scope.$watch(recordsService.recordStatus, function () {
              var recordStatus = recordsService.recordStatus();
              if ($scope.currentRecord && recordStatus.StatementId == $scope.currentRecord.Id) {
                  $scope.isBackgroundProcessRunning = false;
              }
          });

          $scope.calculateReportedValue = function () {
              $rootScope.promise = statementService.saveAdjustments().then(function () {
                  statementService.calculate($scope.currentRecord.Id, 'reportedvalue');

                  $mdDialog.show(
                              $mdDialog.alert()
                              .parent(document.body)
                              .clickOutsideToClose(false)
                              .title('Calculation started')
                              .content('Calculation is initiated on the server and you will be notified when it is complete.')
                              .ariaLabel('Calculation initiated')
                              .ok('OK')
                          ).then(function () {
                              $location.path('/');
                          });
              });
          };

          $scope.save = function () {                            
                  //Call save function
                  saveStatement();              
          };                    

          $scope.cancel = function () {
              var confirm = $mdDialog.confirm()
                            .title('Confirmation')
                            .content('You will lose all the changes you made in the current session. Do you want to continue?')
                            .ariaLabel('Confirmation')
                            .ok('OK')
                            .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  $rootScope.promise = statementService.cancel().then(function () {
                      $location.path('/');
                  });
              });
          };                    

          var setSourceValue = function (item) {
              if (item.AdjustmentValue != null && item.Value != null)
                  item.selectedSourceValue = item.Value - item.AdjustmentValue;
          };         

          $scope.showLockMonths = function () {
              $mdDialog.show({
                  controller: 'recordNodeLockManagerCtrl',
                  templateUrl: 'app/templates/recordNodeLockManager.tmpl.html',
                  parent: angular.element(document.body),
                  locals: {
                      selectedRecord: $scope.currentRecord,
                      viewType: $scope.viewType,
                      hasEditPermission: $scope.getFeatureAccess($scope.availableFeatures.CreateStatement)
                  }
              })
          };
          
          $scope.unlockStatement = function () {
		      var msg = 'This statement version (' + $scope.currentRecord.Version + ') will now be unlocked. Please re-do the previous operation (Upload, Calculation or Default Toggle).';
              var confirm = $mdDialog.confirm()
                            .title('Are you sure?')
                            .content(msg)
                            .ariaLabel('Confirmation')
                            .ok('Unlock')
                            .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  recordStatusDataFactory.setStatus($scope.currentRecord.Id, 'Completed').then(function () {
                      $location.path('/');
                  });
              });

          };

          $scope.allowUnlockStatement = function () {
              if ($scope.currentRecord) {
                  if ($scope.getFeatureAccess($scope.availableFeatures.CreateStatement)
                      && $scope.viewType === 'view' && $scope.currentRecord.Status !== 2)
                      return true;
              }
              return false;
          };

          $rootScope.promise.then(function () {
              $scope.viewType = $routeParams.viewType;
              $rootScope.promise = getConfigData().then(function () {
                  showNewRecordDialog();
              });
          });

          $scope.showOtherEditingUsers = function () {
              $rootScope.promise = recordEditLogDataFactory.GetAllOtherEditsForRecord($scope.currentRecord.Id).then(function (otherEditingUsers) {
                  var otherUsers = '';
                  angular.forEach(otherEditingUsers.data, function (item) {
                      otherUsers += '\r\n' + item.UpdatedBy;
                  });
                  //$mdDialog.show($mdDialog.alert()
                  //    .parent(document.body)
                  //          .title('Other Editing Users')                      
                  //          .content(otherUsers)
                  //          .ariaLabel('Confirmation')
                  //          .ok('OK')
                  //);

                  $mdDialog.show({
                      parent: document.body,
                      title: 'Other Editing Users',
                      template: 
                            '<md-dialog aria-label="List Of Users">' +
                            ' <md-toolbar>'+
                            ' <div class="md-toolbar-tools">'+
                            '  <h3>Other Editing User(s)</h3>'+
                            ' </div>' +
                            '</md-toolbar>' +
                            '  <md-dialog-content layout-padding>' +
                            '    <md-list>' +
                            '      <md-list-item ng-repeat="item in users">' +
                            '       <p>{{item.UpdatedBy}}</p>' +
                            '      ' +
                            '    </md-list-item></md-list>' +
                            '  </md-dialog-content>' +
                            '  <md-dialog-actions>' +
                            '    <md-button ng-click="closeDialog()" class="md-primary">' +
                            '      OK' +
                            '    </md-button>' +
                            '  </md-dialog-actions>' +
                            '</md-dialog>',
                      locals: {
                          users: otherEditingUsers.data
                      },
                      controller: otherUserController
                  });
                  function otherUserController($scope, $mdDialog, users) {
                      $scope.users = users;
                      $scope.closeDialog = function () {
                          $mdDialog.hide();
                      };
                  };
              });
          };




          var startRecordEditLogging = function () {
              if (angular.isDefined($scope.currentRecord) && $scope.viewType === 'edit') {
                  //recordEditLogDataFactory.logRecordEdit($routeParams.statementId);

                  refreshEditInfoFn();
                  startRefreshingEditInfo();
              }
          };

          var refreshEditInfo;
          var refreshEditInfoFn = function () {
              if (angular.isDefined($scope.currentRecord)) {
                  recordEditLogDataFactory.logRecordEdit($scope.currentRecord.Id);
                  recordEditLogDataFactory.isAnotherUserInEdit($scope.currentRecord.Id).then(function (response) {
                      $scope.isAnotherUserEditing = response.data;
                      //console.log($scope.recordsInEdit);
                  });
              }
          };

          var startRefreshingEditInfo = function () {
              if (angular.isDefined(refreshEditInfo))
                  return;
              refreshEditInfo = $interval(refreshEditInfoFn, 30000); //1 min in seconds
          };

          $scope.stopRefresh = function () {
              if (angular.isDefined(refreshEditInfo)) {
                  $interval.cancel(refreshEditInfo);
                  refreshEditInfo = undefined;
              }
          };

          $scope.$on('$destroy', function () {
              $scope.stopRefresh();
          });
      }]);