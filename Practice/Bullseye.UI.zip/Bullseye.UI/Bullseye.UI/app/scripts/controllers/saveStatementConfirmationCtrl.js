﻿angular.module('bullseyeApp').controller('savestatementconfirmationCtrl', ['$rootScope', '$scope', '$q', '$mdDialog', 'isNew', 'statementService', 'statementTypeDataFactory',
    'businessUnitDataFactory',
    function ($rootScope, $scope, $q, $mdDialog, isNew, statementService, statementTypeDataFactory, businessUnitDataFactory) {
        $scope.monthAllowed = false;
        $scope.firstQuarterMonths = [null, "JAN", "FEB", "MAR"];
        $scope.secondQuarterMonths = [null, "APR", "MAY", "JUN"];
        $scope.thirdQuarterMonths = [null, "JUL", "AUG", "SEP"];
        $scope.fourthQuarterMonths = [null, "OCT", "NOV", "DEC"];
        $scope.months = [null];               

        $scope.isNew = isNew;        
        $scope.selectedRecord = statementService.selectedRecord();
        $scope.originalStatementType = $scope.selectedRecord.StatementType;
        $scope.originalQuarter = $scope.selectedRecord.Quarter;
        $scope.originalDescription = $scope.selectedRecord.Description;
        $scope.originalMonth = $scope.selectedRecord.Month;
        $scope.originalBusinessUnit = $scope.selectedRecord.BusinessUnit;

        $scope.selectedRecord.SaveType = "SaveAsNewVersion";

        $scope.disableMetadataChange = function () {
            return (!isNew && $scope.selectedRecord.SaveType !== "SaveNew");
        };

        $scope.saveTypeChanged = function () {
            if($scope.selectedRecord.SaveType === "SaveAsNewVersion")
            {
                //Reset to original values
                $scope.selectedRecord.StatementType = $scope.originalStatementType;
                $scope.selectedRecord.Quarter = $scope.originalQuarter;
                $scope.selectedRecord.Description = $scope.originalDescription;
                $scope.selectedRecord.Month = $scope.originalMonth;
                $scope.selectedRecord.BusinessUnit = $scope.originalBusinessUnit;
                $scope.setMonths();
            }
        };

        var getData = function () {
            var promises = [];
            var stDefer = $q.defer();
            statementTypeDataFactory.getStatementTypeList().success(function (data) {
                $scope.statementTypes = data;
                if ($scope.selectedRecord.StatementType == null)
                    $scope.selectedRecord.StatementType = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            var buDefer = $q.defer();
            businessUnitDataFactory.getBusinessUnitList().success(function (data) {
                $scope.businessUnits = data;
                if ($scope.selectedRecord.BusinessUnit == null)
                    $scope.selectedRecord.BusinessUnit = data[0].Name;
                stDefer.resolve();
            });
            promises.push(stDefer.promise);

            return $q.all(promises);
        };

        $rootScope.promise = getData();

        $scope.quarters =
            [{ Name: '-', Id: 0 },
            { Name: '1Q', Id: 1 },
            { Name: '2Q', Id: 2 },
            { Name: '3Q', Id: 3 },
            { Name: '4Q', Id: 4 }];

        $scope.setMonths = function () {
            if ($scope.selectedRecord.Quarter === "0" || 0)
                $scope.monthAllowed = false;
            else {
                $scope.monthAllowed = true;

                switch ($scope.selectedRecord.Quarter) {
                    case "1":
                    case 1:
                        $scope.months = $scope.firstQuarterMonths;
                        break;
                    case "2":
                    case 2:
                        $scope.months = $scope.secondQuarterMonths;
                        break;
                    case "3":
                    case 3:
                        $scope.months = $scope.thirdQuarterMonths;
                        break;
                    case "4":
                    case 4:
                        $scope.months = $scope.fourthQuarterMonths;
                        break;
                }
            }
        };

        $scope.quarterChanged = function () {
            $scope.selectedRecord.Month = null;
            $scope.setMonths();
        };

        $scope.setMonths();

        $scope.ok = function () {
            if ($scope.selectedRecord.Description != null)
                $scope.selectedRecord.Description = $scope.selectedRecord.Description.trim();
            if ($scope.selectedRecord.Month === '')
                $scope.selectedRecord.Month = null;
            $mdDialog.hide();
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };
    }]);