﻿"use strict";

/**
 * @ngdoc function
 * @name bullseyeApp.controller:downloadfolderlocationCtrl
 * @description
 * # downloadfolderlocationCtrl
 * Controller of the bullseyeApp
 */
angular.module('bullseyeApp')
  .controller('downloadDirectoriesCtrl', ['$q', '$rootScope', '$scope', '$location', '$mdDialog', 'downloadTypeDataFactory', 'downloadDirectoryDataFactory', 'sourceDirectoryDataFactory',
      function ($q, $rootScope, $scope, $location, $mdDialog, downloadTypeDataFactory, downloadDirectoryDataFactory, sourceDirectoryDataFactory) {

          $rootScope.promise = downloadTypeDataFactory.getDownloadTypeList().success(function (downloadTypeList) {
              $scope.downloadTypeList = [];
              angular.forEach(downloadTypeList, function (downloadType) {
                  downloadType.downloadDirectoryList = [];
                  $rootScope.promise = downloadDirectoryDataFactory.getDownloadDirectoryListByDownloadTypeId(downloadType.Id).success(function (data) {
                      downloadType.downloadDirectoryList = data;
                  });
                  $scope.downloadTypeList.push(downloadType);
              })
          });


          var saveDownloadDirectories = function () {
              ////Update each statement type - Only works for updating
              //var stPromises = $scope.downloadDirectoryList.map(function (downloadDirectory) {
              //    return downloadDirectoryDataFactory.updateDownloadDirectory(downloadDirectory);
              //});

              //return $q.all(stPromises);
              var downloadDirectoryList = [];
              angular.forEach($scope.downloadTypeList, function (downloadType) {
                  angular.forEach(downloadType.downloadDirectoryList, function (downloadDirectory) {
                      downloadDirectoryList.push(downloadDirectory);
                  });
              });
              return downloadDirectoryDataFactory.saveDownloadDirectoryList(downloadDirectoryList);
          };

          $scope.save = function () {
              var confirm = $mdDialog.confirm()
                                .title('Confirmation')
                                .content('Would you like to Save changes to folder locations?')
                                .ariaLabel('Confirmation')
                                .ok('OK')
                                .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  var promises = [];
                  promises.push(saveDownloadDirectories());

                  $rootScope.promise = $q.all(promises);
                  $rootScope.promise.then(function () {
                      $mdDialog.show(
                              $mdDialog.alert()
                              .parent(angular.element(document.body))
                              .clickOutsideToClose(false)
                              .title('Success')
                              .content('Changes are successfully saved')
                              .ariaLabel('Success')
                              .ok('OK')
                          )
                          .finally(function () {
                              //$location.path('/');
                          });
                  });
              });
          };

          $scope.cancel = function () {
              var confirm = $mdDialog.confirm()
                                .title('Confirmation')
                                .content('You will lose all the changes you made in the current session. Do you want to continue?')
                                .ariaLabel('Confirmation')
                                .ok('OK')
                                .cancel('Cancel');
              $mdDialog.show(confirm).then(function () {
                  $location.path('/');
              });
          };

          $scope.addDownloadTypeLocation = function (downloadType) {
              var newDownloadTypeLocation = {
                  DownloadTypeId: downloadType.Id,
                  DownloadTypeName: downloadType.Name
              };
              downloadType.downloadDirectoryList.push(newDownloadTypeLocation);
          };

          $scope.removeDownloadTypeLocation = function (downloadType, downloadDirectory) {
              var index = downloadType.downloadDirectoryList.indexOf(downloadDirectory);
              if (index > -1) {
                  downloadType.downloadDirectoryList.splice(index, 1);
              }              
          };

          $scope.downloadTypeSelected = function (downloadType, index) {
              $scope.selectedDownloadType = downloadType;
              $scope.selectedIndex = index;
          };

          $scope.isSelectedItem = function(index)
          {
              return index === $scope.selectedIndex;
          }

          $scope.isNameUnique = function (givenDirectory, index) {
              var isValid = true;
              angular.forEach($scope.selectedDownloadType.downloadDirectoryList, function (directory) {
                  if(givenDirectory!== directory && directory.Name === givenDirectory.Name)
                  {
                      isValid = false;
                  }                  
              });
              if(isValid)
              {
                  $scope.downloadDirectoryForm['name_' + givenDirectory.DownloadTypeName + '_' + index].$setValidity('unique', true);
              }
              else
              {
                  $scope.downloadDirectoryForm['name_' + givenDirectory.DownloadTypeName + '_' + index].$setValidity('unique', false);
              }
          };

          $scope.isDirectoryAccessible = function (givenDirectory, index) {
              var isAccessible = true;

              $rootScope.promise = sourceDirectoryDataFactory.hasDirectoryAccess(givenDirectory.DirectoryPath).success(function (response) {
                  isAccessible = response;
                  if (isAccessible) {
                      $scope.downloadDirectoryForm['path_' + givenDirectory.DownloadTypeName + '_' + index].$setValidity('accessible', true);
                  }
                  else {
                      $scope.downloadDirectoryForm['path_' + givenDirectory.DownloadTypeName + '_' + index].$setValidity('accessible', false);
                  }
              });

          }
      }]);
