﻿angular.module('bullseyeApp').controller('fsNodeMappingCtrl', ['$rootScope', '$scope', '$filter',
function ($rootScope, $scope, $filter) {
    $scope.addFbwMapping = function () {
        $scope.fsNodeDetails.sourceNodeFilter = undefined;
        $scope.fsNodeDetails.businessCodeFilter = undefined;
        $scope.fsNodeDetails.regionFilter = undefined;
        $scope.filterMapList();

        $scope.fsNodeDetails.FbwHierarchyNodeMapList.push({
            BusinessCode: '',
            SourceNodeCode: '',
            Region: { Name: '' }
        });

        $scope.setLastPage();
    }

    $scope.deleteFbwMapping = function (mapping) {
        var index = $scope.fsNodeDetails.FbwHierarchyNodeMapList.indexOf(mapping);
        if (index > -1) {
            $scope.fsNodeDetails.FbwHierarchyNodeMapList.splice(index, 1);
        }
    };

    $scope.isFbwMappingUnique = function (givenMapping, index) {
        if (givenMapping) {
            var isValid = true;
            angular.forEach($scope.fsNodeDetails.FbwHierarchyNodeMapList, function (map) {
                var mapSourceNodeCode = null;
                var mapBusinessCode = null;
                var mapRegionName = null;
                var newMapSourceNodeCode = null;
                var newMapBusinessCode = null;
                var newMapRegionName = null;
                if (map.SourceNodeCode)
                    mapSourceNodeCode = map.SourceNodeCode.toLowerCase();
                if (map.BusinessCode)
                    mapBusinessCode = map.BusinessCode.toLowerCase();
                if (map.Region && map.Region.Name)
                    mapRegionName = map.Region.Name;

                if (givenMapping.SourceNodeCode)
                    newMapSourceNodeCode = givenMapping.SourceNodeCode.toLowerCase();
                if (givenMapping.BusinessCode)
                    newMapBusinessCode = givenMapping.BusinessCode.toLowerCase();
                if (givenMapping.Region && givenMapping.Region.Name)
                    newMapRegionName = givenMapping.Region.Name;

                if (givenMapping !== map && mapSourceNodeCode === newMapSourceNodeCode && mapBusinessCode === newMapBusinessCode && mapRegionName === newMapRegionName) {
                    isValid = false;
                }
            });
            if (isValid) {
                //this.$parent.fsNodeMappingForm['fbwname_' + givenMapping.SourceNodeCode + '_' + index].$setValidity('unique', true);
                //$scope.fsNodeMappingForm['fbwname_' + givenMapping.SourceNodeCode + '_' + index].$setValidity('unique', true);
                var namePart = '';
                if (givenMapping.SourceNodeCode)
                    namePart = givenMapping.SourceNodeCode;
                $scope.hierarchySetDetailForm['fbwname_' + namePart + '_' + index].$setValidity('unique', true);
            }
            else {
                //this.$parent.fsNodeMappingForm['fbwname_' + givenMapping.SourceNodeCode + '_' + index].$setValidity('unique', false);
                //$scope.fsNodeMappingForm['fbwname_' + givenMapping.SourceNodeCode + '_' + index].$setValidity('unique', false);
                var namePart = '';
                if (givenMapping.SourceNodeCode)
                    namePart = givenMapping.SourceNodeCode;
                $scope.hierarchySetDetailForm['fbwname_' + namePart + '_' + index].$setValidity('unique', false);
            }
        }
    };

    $scope.filteredMappings = [];
    $scope.currentPage = 0;
    $scope.pageSize = 10;

    $scope.setCurrentPage = function (currentPage) {
        $scope.currentPage = currentPage;
        $scope.pages = $scope.getNumberAsArray($scope.numberOfPages($scope.fsNodeDetails.sourceNodeFilter,
        $scope.fsNodeDetails.businessCodeFilter, $scope.fsNodeDetails.regionFilter));
    }

    $scope.getNumberAsArray = function (num) {
        if (num > 3) {
            if ($scope.currentPage === num - 1) {
                $scope.startPage = $scope.currentPage - 2;
                $scope.endPage = $scope.currentPage;
            }
            else if ($scope.currentPage === 0) {
                $scope.startPage = $scope.currentPage;
                $scope.endPage = $scope.currentPage + 2;
            }
            else {
                $scope.startPage = $scope.currentPage - 1;
                $scope.endPage = $scope.currentPage + 1;
            }

            var pages = [];
            for (var i = $scope.startPage; i <= $scope.endPage; i++) {
                pages.push(i);
            }
            return pages;
        }
        else {
            var pages = [];
            for (var i = 0; i < num; i++) {
                pages.push(i);
            }
            return pages;
        }
    };

    $scope.numberOfPages = function (sourceNodeFilter, businessCodeFilter, regionFilter) {
        if ($scope.fsNodeDetails) {
            $scope.filteredMappings = $filter('filter')($scope.fsNodeDetails.FbwHierarchyNodeMapList, { SourceNodeCode: sourceNodeFilter, BusinessCode: businessCodeFilter, Region: { Name: regionFilter } });
            return Math.ceil($scope.filteredMappings.length / $scope.pageSize);
        }
        else
            return 0;
    };

    $scope.filterMapList = function () {
        $scope.currentPage = 0;
        $scope.pages = $scope.getNumberAsArray($scope.numberOfPages($scope.fsNodeDetails.sourceNodeFilter,
        $scope.fsNodeDetails.businessCodeFilter, $scope.fsNodeDetails.regionFilter));
    }

    $scope.$watch('fsNodeDetails', function () {
        if ($scope.fsNodeDetails)
            $scope.pages = $scope.getNumberAsArray($scope.numberOfPages('', '', ''));
    });


    $scope.setLastPage = function () {
        if ($scope.fsNodeDetails) {
            var pageCount = $scope.numberOfPages($scope.fsNodeDetails.sourceNodeFilter,
            $scope.fsNodeDetails.businessCodeFilter, $scope.fsNodeDetails.regionFilter);
            $scope.setCurrentPage(pageCount - 1);
        }
    };

    $scope.isFirstPageDisabled = function () {
        if ($scope.currentPage === 0)
            return true;
        return false;
    };

    $scope.isLastPageDisabled = function () {
        if ($scope.fsNodeDetails) {
            var pageCount = $scope.numberOfPages($scope.fsNodeDetails.sourceNodeFilter,
            $scope.fsNodeDetails.businessCodeFilter, $scope.fsNodeDetails.regionFilter);
            if ($scope.currentPage === pageCount - 1)
                return true;
        }
        return false;
    };

}]);

// Start from filter
angular.module('bullseyeApp').filter('startFrom', function () {
    return function (input, start) {
        if (input)
            return input.slice(start);
    }
});
