﻿angular.module('bullseyeApp').controller('uploadSourceCtrl', ['$rootScope', '$scope', '$mdDialog',
    'selectedRecord',
    'sourceDirectoryDataFactory', 'sourceTypeDataFactory', 'adjustmentFileUploadDataFactory',
    'statementService',
function ($rootScope, $scope, $mdDialog,
    selectedRecord,
    sourceDirectoryDataFactory, sourceTypeDataFactory, adjustmentFileUploadDataFactory,
    statementService) {
    $scope.selectedRecord = selectedRecord;
    $scope.message = "Please Wait...";
    $rootScope.promise = sourceTypeDataFactory.getSourceTypeList()
        .then(function (response) {
            $scope.sourceTypes = response.data;

            $scope.sourceTypes.push({ Id: -1, Name: 'Adjustments' });
        });

    var isAdjustmentUpload = function () {
        return $scope.selectedSourceType.Id === -1;
    }

    $scope.sourceTypeChanged = function () {
        $scope.selectedFileName = "";
        $scope.pathList = [];
        $scope.files = [];
        var selectedId = $scope.selectedSourceType.Id;
        if (isAdjustmentUpload()) {
            $scope.uploadPromise = adjustmentFileUploadDataFactory.getAdjustmentFileNames().then(function (response) {
                $scope.files = response.data.Result;
            });
        }
        else {
            $scope.uploadPromise = sourceDirectoryDataFactory.getSourceDirectoryListBySourceTypeId(selectedId).success(function (data) {
                $scope.pathList = data;
                if ($scope.pathList.length >= 1) {
                    $scope.selectedDirectory = $scope.pathList[0];
                    $scope.pathNameChanged();
                }
            });
        }
    };

    $scope.pathNameChanged = function () {
        $scope.selectedFileName = "";
        $scope.files = [];
        $scope.uploadPromise = sourceDirectoryDataFactory.getFileNames($scope.selectedDirectory.Id)
            .then(function (response) {
                $scope.files = response.data;
            });
    };

    $scope.selectedFileName = "";
    $scope.totalDisplayed = 20;

    $scope.upload = function () {
        $scope.totalDisplayed = 20;
        if (!isAdjustmentUpload()) {
            $scope.uploadPromise = statementService.uploadSource($scope.selectedFileName, $scope.selectedDirectory.SourceTypeName, $scope.selectedRecord.Id, $scope.selectedDirectory.Id, $scope.isIncrementalUpload);
        }
        $mdDialog.hide({ sourceTypeId: $scope.selectedSourceType.Id, isAdjustmentUpload: isAdjustmentUpload(), selectedFileName: $scope.selectedFileName });
    };

    $scope.showMore = function () {
        $scope.totalDisplayed += 20;
    };

    $scope.areAllItemsDisplayed = function () {
        return $scope.uploadErrors == null || $scope.totalDisplayed >= $scope.uploadErrors.length;
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };
}]);