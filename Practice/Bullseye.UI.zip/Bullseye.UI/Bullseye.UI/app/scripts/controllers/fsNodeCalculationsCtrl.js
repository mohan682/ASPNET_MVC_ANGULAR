﻿"use strict";
angular.module('bullseyeApp')
    .controller('fsNodeCalculationsCtrl', ['$rootScope', '$scope', 'dividendPartnerDataFactory',
        function ($rootScope, $scope, dividendPartnerDataFactory) {
            //$scope.isCalcDisabled = !($scope.getFeatureAccess($scope.availableFeatures.CreateHierarchy) && $scope.viewType !== 'view');
            $scope.isCalcDisabled = true;
            $scope.conditionTypes = [
                { Id: 1, Name: 'Rb Node', Value: 'RbNode' },
                { Id: 2, Name: 'Rb Parent', Value: 'RbParent' },
                { Id: 3, Name: 'Dividend Partner', Value: 'DividendPartnerName' }
            ];

            $scope.operators = [
                { Id: 1, Name: 'Equals', Value: 'Equals' },
                { Id: 2, Name: 'Not Equals', Value: 'NotEquals' },
                { Id: 3, Name: 'Is Empty', Value: 'IsNull' },
                { Id: 4, Name: 'Is Not Empty', Value: 'IsNotNull' }
            ];
            var rbNodes = [];
            var fsNodes = [];

            function createFilterFor(query, property) {
                var lowercaseQuery = angular.lowercase(query);

                return function filterFn(item) {
                    return (item[property].toLowerCase().indexOf(lowercaseQuery) === 0);
                };
            }

            function getIndicesOf(searchStr, str, caseSensitive) {
                var searchStrLen = searchStr.length;
                if (searchStrLen == 0) {
                    return [];
                }
                var startIndex = 0, index, indices = [];
                if (!caseSensitive) {
                    str = str.toLowerCase();
                    searchStr = searchStr.toLowerCase();
                }
                while ((index = str.indexOf(searchStr, startIndex)) > -1) {
                    indices.push(index);
                    startIndex = index + searchStrLen;
                }
                return indices;
            }

            function getIdList(indices, str, searchString) {
                var searchStrLength = searchString.length;
                var idList = []
                angular.forEach(indices, function (index) {
                    index = index + searchStrLength;
                    var closeIndex = str.indexOf(')', index);
                    idList.push(str.substring(index, closeIndex).trim());
                });
                return idList;
            }

            function escapeRegExp(str) {
                return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
            }

            function replaceAll(str, find, replace) {
                return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
            }

            var initialize = function () {
                //get dividend partners
                dividendPartnerDataFactory.getDividendPartners().then(function (response) {
                    $scope.dividendPartners = response;

                    $scope.existingCalculations = [];
                    var rvCalcObj = { Calculation: { Expressions: [{}] } };
                    angular.forEach($scope.fsNodeDetails.HierarchyNode.SourceDataTypes, function (sourceDataType) {
                        if (sourceDataType.SourceEditType === 1) //Only allow Calc Source Types
                        {
                            var calcObj = { SourceType: sourceDataType.SourceType, Calculation: { Expressions: [{}] } };

                            angular.forEach($scope.fsNodeDetails.HierarchyNodeCalculations, function (calc) {
                                if (calc.SourceType && calc.SourceType.Name === sourceDataType.SourceType.Name) {
                                    calcObj.Calculation = JSON.parse(calc.CalculationJson);
                                }
                                else if (!calc.SourceType) {
                                    rvCalcObj.Calculation = JSON.parse(calc.CalculationJson);
                                }
                            });
                            $scope.existingCalculations.push(calcObj);
                        }
                    });
                    $scope.existingCalculations.push(rvCalcObj);
                    rbNodes = $('#rbHierarchyTree').treeview('getNodes');
                    fsNodes = $('#fsHierarchyTree').treeview('getNodes');
                    angular.forEach(rbNodes, function (n) {
                        n.Name = n.text;
                        angular.forEach($scope.existingCalculations, function (calc) {
                            angular.forEach(calc.Calculation.Expressions, function (expression) {
                                angular.forEach(expression.Conditions, function (condition) {
                                    if (condition.Value == n.Id)
                                        condition.selectedConditionValue = n;
                                });
                            });
                        });
                    });

                    angular.forEach($scope.dividendPartners, function (divPartner) {
                        angular.forEach($scope.existingCalculations, function (calc) {
                            angular.forEach(calc.Calculation.Expressions, function (expression) {
                                angular.forEach(expression.Conditions, function (condition) {
                                    if (condition.Value == divPartner.Name)
                                        condition.selectedConditionValue = divPartner;

                                    $scope.conditionUpdated(condition);
                                });
                            });
                        });
                    });

                    var fsNodeIdList = [];
                    angular.forEach($scope.existingCalculations, function (calc) {
                        angular.forEach(calc.Calculation.Expressions, function (expression) {
                            if (expression.Value) {
                            var valIndexes = getIndicesOf('ValueOf(', expression.Value, false);
                            fsNodeIdList = getIdList(valIndexes, expression.Value, 'ValueOf(');
                            var priorIndexes = getIndicesOf('PriorPeriodValue(', expression.Value, false);
                                var priorIds = getIdList(priorIndexes, expression.Value, 'PriorPeriodValue(');
                                if (fsNodeIdList.length)
                                    fsNodeIdList.push.apply(priorIds);
                                else
                                    fsNodeIdList = priorIds;
                            }
                        });
                    });
                    var uniqueNodeIdList = [];
                    for (var i = 0 ; i < fsNodeIdList.length; i++) {
                        if (uniqueNodeIdList.indexOf(fsNodeIdList[i]) == -1)
                            uniqueNodeIdList.push(fsNodeIdList[i]);
                    }
                    if (uniqueNodeIdList.length) {
                        angular.forEach(fsNodes, function (node) {
                            angular.forEach(uniqueNodeIdList, function (id) {
                                if (node.Id == id) {
                                    angular.forEach($scope.existingCalculations, function (calc) {
                                        angular.forEach(calc.Calculation.Expressions, function (expression) {
                                            if (expression.Value) {
                                            expression.Value = replaceAll(expression.Value, 'ValueOf(' + id + ')', 'ValueOf(' + node.text + ')');
                                            expression.Value = replaceAll(expression.Value, 'PriorPeriodValue(' + id + ')', 'PriorPeriodValue(' + node.text + ')');
                                            }
                                        });
                                    });
                                }
                            })
                        });
                    }
                });
            };

            $scope.addSourceFileFilter = function (calc) {
                if (!calc.Calculation.SourceFileFilters)
                    calc.Calculation.SourceFileFilters = [];
                calc.Calculation.SourceFileFilters.push({});
            };

            $scope.deleteSourceFileFilter = function (calc, filter) {
                var index = calc.Calculation.SourceFileFilters.indexOf(filter);
                if (index > -1)
                    calc.Calculation.SourceFileFilters.splice(index, 1);
            };

            $scope.addCondition = function (expression) {
                if (!expression.Conditions)
                    expression.Conditions = [];
                expression.Conditions.push({});
            };

            $scope.deleteCondition = function (expression, condition) {
                var index = expression.Conditions.indexOf(condition);
                if (index > -1)
                    expression.Conditions.splice(index, 1);
            };

            $scope.toggleCalcDisplay = function (calc) {
                if (!calc.Hide)
                    calc.Hide = false;
                calc.Hide = !calc.Hide;
            };

            $scope.conditionUpdated = function (condition) {
                if (condition.Type && condition.Operator && (condition.Operator === 1 || condition.Operator === 2))
                    return condition.isConditionValueAllowed = true;
                return condition.isConditionValueAllowed = false;
            };

            $scope.querySearch = function (query, condition) {
                if (condition.Type === 3) {
                    //Dividend Partners
                    var results = query ? $scope.dividendPartners.filter(createFilterFor(query, 'Name')) : $scope.dividendPartners,
                    deferred;
                    return results;
                }
                else {
                    //Rb Nodes
                    var results = query ? rbNodes.filter(createFilterFor(query, 'Name')) : rbNodes,
                    deferred;
                    return results;
                }

            }

            $scope.$watch('fsNodeDetails', function () {
                if ($scope.fsNodeDetails) {
                    initialize();
                }
            });
        }]);