"use strict";

/**
 * @ngdoc overview
 * @name bullseyeApp
 * @description
 * # bullseyeApp
 *
 * Main module of the application.
 */
angular
    .module('bullseyeApp', [
        'ngAnimate',
        'ngMaterial',
        'ngCookies',
        'ngResource',
        'ngRoute',
        'ngSanitize',
        'ngTouch',
        'ngMessages',
        'ui.grid',
        'ui.grid.edit',
        'ui.grid.cellNav',
        'ui.grid.resizeColumns',
        'ui.grid.treeView',
        'ui.grid.pagination',
        'ui.grid.selection',
        'ui.bootstrap',        
        'anguFixedHeaderTable',
        'cgBusy',
        'sticky',
        'multi-select-tree'
    ])
    .config(function ($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: 'app/views/main.html',
                controller: 'mainCtrl'
            })
            .when('/financialstatement/:statementId?/:viewType?', {
                templateUrl: 'app/views/financialStatement.html',
                controller: 'financialStatementCtrl'
            })
            .when('/hierarchySetDetail/:hierarchySetId?/:viewType?', {
                templateUrl: 'app/views/hierarchySetDetail.html',
                controller: 'hierarchySetDetailCtrl'
            })
            .when('/hierarchySetList', {
                templateUrl: 'app/views/hierarchySetList.html',
                controller: 'hierarchySetListCtrl'
            })
            .when('/about', {
                templateUrl: 'app/views/about.html',
                controller: 'aboutCtrl'
            })
            .when('/metadata', {
                templateUrl: 'app/views/metadata.html',
                controller: 'metadataCtrl'
            })
            .when('/sourcefolderlocation',
            {
                templateUrl: 'app/views/sourceFolderLocation.html',
                controller: 'sourcefolderlocationCtrl'
            })
            .when('/downloaddirectories',
            {
                templateUrl: 'app/views/downloadDirectories.html',
                controller: 'downloadDirectoriesCtrl'
            })
            .when('/login',
            {
                templateUrl: 'app/views/login.html',
                controller: 'loginCtrl'
            })
            .when('/mergestatement',
            {
                templateUrl: 'app/views/mergeStatement.html',
                controller: 'mergeStatementCtrl'
            })
            .otherwise({
                redirectTo: '/'
            });
    })
    .filter('mapToggle', function () {
        var genderHash = {
             1: 'TPR',
         2: 'Plan' ,
         3: 'Forecast' ,
         4: 'FBW' ,
         5: 'WC' 
        };

        return function (input) {
            if (!input) {
                return '';
            } else {
                return genderHash[input];
            }
        };
    })
    .config(function ($mdThemingProvider) {
        $mdThemingProvider.theme('default')
            .primaryPalette('green', {
                'default':'600'
            })
            .accentPalette('lime');
    })
    //.config(function ($animate) {
    //    $animate.enabled(false);
    //})
    .value('settings', {})
    .run(authenticate);

authenticate.$inject = ['$rootScope', '$location', '$cookieStore', '$http', 'settings'];
function authenticate($rootScope, $location, $cookieStore, $http, settings) {
    // keep user logged in after page refresh
    $rootScope.globals = $cookieStore.get('globals') || {};
    if ($rootScope.globals.currentUser) {
        $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
    }

    $rootScope.$on('$locationChangeStart', function (event, next, current) {
        // redirect to login page if not logged in and trying to access a restricted page
        var restrictedPage = $.inArray($location.path(), ['/login']) === -1;
        var roles = $rootScope.globals.roles;
        if (restrictedPage && (roles === undefined || roles == null || !roles.length)) {
            $location.path('/login');
        }
    });
}
