﻿angular.module('bullseyeApp')
    .factory('hierarchySetService', ['$q', '$rootScope', 'hierarchySetDataFactory',
        function ($q, $rootScope, hierarchySetDataFactory) {
            var hierarchySetService = {};            

            hierarchySetService.getHierarchySet = function (hierarchySetId) {
                var hierarchySetDefer = $q.defer();
                hierarchySetDataFactory.getHierarchySet($scope.hierarchySet.Id).success(function (data) {
                    hierarchySetDefer.resolve(data);
                });

                return hierarchySetDefer;
            };

            var addMultiSelectableTreeNode = function (node, level, parentNode) {
                var convertedNode = { children: [] };
                if (node.Children && node.Children.length) {
                    angular.forEach(node.Children, function (childNode) {
                        convertedNode.children.push(addMultiSelectableTreeNode(childNode, level + 1, convertedNode));
                    });
                }
                convertedNode.name = node.Name;
                convertedNode.OriginalNode = node;
                convertedNode.id = node.Id;
                convertedNode.level = level;
                convertedNode.parent = parentNode;
                return convertedNode;
            };

            hierarchySetService.getMultiSelectableTree = function (treeData) {
                var tree = [];
                angular.forEach(treeData.RootNodes, function (rootNode) {
                    tree.push(addMultiSelectableTreeNode(rootNode, 1));
                });
                return tree;
            };
            
            return hierarchySetService;
        }]);