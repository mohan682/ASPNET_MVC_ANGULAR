﻿//angular.module('bullseyeApp')
//    .factory('subscriptionService', ['signalRFactory',
//        function (signalRFactory) {
//            var subscriptionService = {};
//            subscriptionService.signalRFactory = signalRFactory('statementHub', { logging: true });
//            return subscriptionService;
//        }]);