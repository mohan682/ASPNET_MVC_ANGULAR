﻿angular.module('bullseyeApp')
    .factory('statementService', ['$q', '$rootScope', 'hierarchyDataFactory', 'recordDataFactory',
        'uploadSourceDataFactory',
        'adjustmentDataFactory', 'kpiCalculationDataFactory', 'recordLogDataFactory', 'calculationDataFactory', 'auditLogDetailDataFactory'
        , function ($q, $rootScope, hierarchyDataFactory, recordDataFactory, uploadSourceDataFactory,
            adjustmentDataFactory, kpiCalculationDataFactory, recordLogDataFactory, calculationDataFactory, auditLogDetailDataFactory) {
            var statementService = {};
            var selectedRecord = {};
            var recordNodeValue = {};

            var existingRecordNodeValues = {};
            var newRecordNodeValues = {};
            var taggedData = {};

            var resetData = function () {
                recordNodeValue = {};
                existingRecordNodeValues = {};
                newRecordNodeValues = {};
                taggedData = {};
            }

            statementService.createRecord = function (asNewVersion, hierarchySetName, fsHierarchyId, rbHierarchyId, selectedYear, statementType, businessUnit, quarter, description, month) {
                resetData();
                var defer = $q.defer();
                var newRecord = {
                    HierarchySetName: hierarchySetName,
                    FinancialStatementHierarchy: {
                        Type: 0,
                        Id: fsHierarchyId
                    },
                    RBHierarchy: {
                        Type: 1,
                        Id: rbHierarchyId
                    },
                    Year: selectedYear,
                    Status: 2,
                    Description: description,
                    Month: month,
                    Quarter: quarter,
                    StatementType: statementType,
                    BusinessUnit: businessUnit,
                    Version: 1
                };
                recordDataFactory.createRecord(asNewVersion, newRecord).success(function (record) {
                    if (record.ValidationMessageList) {
                        selectedRecord = newRecord;
                    }
                    else {
                        selectedRecord = record;
                    }
                    defer.resolve(record);
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.splitRecord = function (options, asNewVersion) {
                resetData();
                recordDataFactory.splitRecord(options, asNewVersion);
            };

            statementService.getRecord = function (statementId) {
                resetData();
                var defer = $q.defer();
                recordDataFactory.getRecord(statementId, true).success(function (record) {
                    selectedRecord = record;
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.cancel = function () {
                resetData();
                var defer = $q.defer();
                recordDataFactory.cancel(selectedRecord).success(function () {
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.saveAsNewRecord = function () {
                this.saveAdjustments().then(function () {
                    recordDataFactory.saveAsNewRecord(selectedRecord);
                });
            };

            statementService.saveAsNewVersion = function () {
                this.saveAdjustments().then(function () {
                    recordDataFactory.saveAsNewVersion(selectedRecord);
                });
            };

            statementService.isValidNewRecord = function () {
                var defer = $q.defer();
                recordDataFactory.isValidNewRecord(selectedRecord).success(function (response) {
                    defer.resolve(response);
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.isDuplicateRecord = function (year, businessUnit, quarter, statementType, month) {
                var defer = $q.defer();
                recordDataFactory.isDuplicateRecord(year, businessUnit, quarter, statementType, month).success(function (response) {
                    defer.resolve(response);
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.save = function () {
                this.saveAdjustments().then(function () {
                    recordDataFactory.save(selectedRecord);
                });
            };

            statementService.mergeStatement = function (recordId, mergeStatementData, kpiOptions) {
                recordDataFactory.mergeStatement(recordId, mergeStatementData, kpiOptions);
            };

            statementService.validateNewRecord = function () {
                var defer = $q.defer();
                recordDataFactory.validateNewRecord(selectedRecord).success(function (response) {
                    defer.resolve(response);
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.uploadSource = function (selectedFileName, selectedSourceTypeName, selectedRecordId, sourceDirectoryId, isIncrementalUpload) {
                this.saveAdjustments().then(function () {
                    uploadSourceDataFactory.uploadSource(selectedFileName, selectedSourceTypeName, selectedRecordId, sourceDirectoryId, isIncrementalUpload);
                });
            };

            statementService.getExistingAdjustments = function (currentRecordId) {
                var defer = $q.defer();
                adjustmentDataFactory.getExistingAdjustments(currentRecordId).success(function (response) {
                    existingRecordNodeValues = response;
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.getNewAdjustments = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList, selectedRegionIdList, selectedSourceType) {
                var defer = $q.defer();
                adjustmentDataFactory.getNewAdjustments(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList, selectedRegionIdList, selectedSourceType).success(function (response) {
                    newRecordNodeValues = response;
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });

                return defer.promise;
            };

            statementService.getTaggedData = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedTagIdList) {
                var defer = $q.defer();
                adjustmentDataFactory.getTaggedData(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedTagIdList).success(function (response) {
                    taggedData = response;
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });

                return defer.promise;
            };

            statementService.clearAdjustments = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList, selectedRegionIdList) {
                var defer = $q.defer();
                adjustmentDataFactory.clearAdjustments(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList, selectedRegionIdList).success(function (response) {
                    newRecordNodeValues = response;
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });

                return defer.promise;
            };

            statementService.applyDefaultToggle = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, defaultToggleType, selectedLevel) {
                adjustmentDataFactory.applyDefaultToggle(recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, defaultToggleType, selectedLevel);
            };

            statementService.saveAdjustments = function () {
                var defer = $q.defer();
                if (newRecordNodeValues != null) {
                    var valuesToSend = [];
                    angular.forEach(newRecordNodeValues, function (item) {
                        if (item.AdjustedValue != null && item.allowAdjustment && !item.ReadOnly)
                            valuesToSend.push(item);
                    });
                    if (valuesToSend.length) {
                        adjustmentDataFactory.saveAdjustments(valuesToSend).success(function (response) {
                            defer.resolve();
                        }).error(function (error) {
                            defer.reject(error);
                        });
                    } else {
                        defer.resolve();
                    }
                } else {
                    defer.resolve();
                }
                return defer.promise;
            };

            statementService.calculateKpi = function (selectedRecordId, type) {
                kpiCalculationDataFactory.calculate(selectedRecordId, type);
            };

            statementService.calculateKpi = function (selectedRecordId, type, selectedRbNodeIdList, selectedLevel) {
                kpiCalculationDataFactory.calculate(selectedRecordId, type, selectedRbNodeIdList, selectedLevel);
            };

            statementService.calculate = function (selectedRecordId, type) {
                calculationDataFactory.calculate(selectedRecordId, type);
            };

            statementService.getRecordLogs = function (statementId) {
                var defer = $q.defer();
                recordLogDataFactory.getRecordLogs(statementId).success(function (response) {
                    defer.resolve(response)
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.getAuditLogs = function (statementId) {
                var defer = $q.defer();
                auditLogDetailDataFactory.getAuditLogList(statementId).success(function (response) {
                    defer.resolve(response);
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.getRecordLogDetails = function (statementId, groupId) {
                var defer = $q.defer();
                recordLogDataFactory.getRecordLogDetails(statementId, groupId).success(function (response) {
                    defer.resolve(response)
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            statementService.selectedRecord = function () { return selectedRecord; };
            statementService.recordNodeValue = function () { return recordNodeValue; };

            statementService.existingRecordNodeValues = function () { return existingRecordNodeValues; };
            statementService.newRecordNodeValues = function () { return newRecordNodeValues; };
            statementService.taggedData = function () { return taggedData; };
            return statementService;
        }]);