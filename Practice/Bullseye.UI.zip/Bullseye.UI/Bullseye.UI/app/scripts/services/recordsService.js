﻿angular.module('bullseyeApp')
    .factory('recordsService', ['$q', '$rootScope', 'recordDataFactory', 'signalRFactory',        
        function ($q, $rootScope, recordDataFactory, signalRFactory) {
            var recordsService = {};
            var records = {};
            var recordStatus = {};

            var getRecords = function () {
                var defer = $q.defer();
                recordDataFactory.getAllRecords().success(function (data) {
                    records = data;                    
                    var prevRecord = null;
                    angular.forEach(records, function (record) {
                        if (prevRecord == null) {
                            record.$$treeLevel = 0;
                        }
                        //else if (prevRecord.Year !== record.Year || prevRecord.Description !== record.Description || prevRecord.Quarter !== record.Quarter ||
                        //    prevRecord.StatementType !== record.StatementType) {
                        //    record.$$treeLevel = 0;
                            //}
                        else if (prevRecord.Name == record.Name && prevRecord.HierarchySetName !== record.HierarchySetName) {
                            record.$$treeLevel = 0;
                        }
                        else if (prevRecord.Name !== record.Name) {
                            record.$$treeLevel = 0;
                        }
                        prevRecord = record;
                    });
                    recordsService.recordsprop = records;
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            };

            var deleteRecord = function(statementId, deleteLowerVersions)
            {
                var defer = $q.defer();
                recordDataFactory.delete(statementId, deleteLowerVersions).success(function (data) {
                    defer.resolve();
                }).error(function (error) {
                    defer.reject(error);
                });
                return defer.promise;
            }

            var signalRFactory = signalRFactory('statementHub', { logging: true });
            $rootScope.signalRFactory = signalRFactory;
            signalRFactory.on('statementUpdated', function (statementId) {
                getRecords();
            });

            signalRFactory.on('calculationCompleted', function (statementId, calcStatus) {
                recordStatus = { StatementId: statementId, Operation: 'Calculation', Status: calcStatus };
            });

            recordsService.getAllRecords = function () {                
                return getRecords();
            };
            recordsService.deleteRecord = function (statementId, deleteLowerVersions) {
                return deleteRecord(statementId, deleteLowerVersions);
            };
            recordsService.records = function () { return records };
            recordsService.recordStatus = function () { return recordStatus };
            return recordsService;
        }]);