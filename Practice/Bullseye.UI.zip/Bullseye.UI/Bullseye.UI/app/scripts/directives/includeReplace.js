﻿angular.module('bullseyeApp')
    .directive("includeReplace", function ($http, $templateCache, $compile) {
    return {
        restrict: 'A',
        link: function (scope, element, attributes) {
            var templateUrl = scope.$eval(attributes.includeReplace);
            $http.get(templateUrl, { cache: $templateCache }).success(
                function (tplContent) {
                    element.replaceWith(tplContent);
                }
            );
        }
    };
});