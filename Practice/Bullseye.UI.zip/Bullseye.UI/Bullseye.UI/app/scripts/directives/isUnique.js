﻿angular.module('bullseyeApp')
    .directive('isUnique', [function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ngModel) {
                element.bind('blur', function () {
                    if (!ngModel || !element.val()) return;
                    ngModel.$setValidity('unique', true);
                    var keyPropertyName = attrs.isUnique;
                    var source = scope.$eval(attrs.source);
                    var currentValue = element.val();
                    var similarItemCount = 0;
                    angular.forEach(source, function(item) {
                        if (angular.lowercase(currentValue) === angular.lowercase(item[keyPropertyName]))
                            similarItemCount++;
                    });
                    if (similarItemCount > 1) {
                        ngModel.$setValidity('unique', false);
                        console.log("error" + similarItemCount);
                    } else {
                        ngModel.$setValidity('unique', true);
                        console.log("pass" + similarItemCount);
                    }                    
                    scope.$apply();
                });
            }
        }
    }]);