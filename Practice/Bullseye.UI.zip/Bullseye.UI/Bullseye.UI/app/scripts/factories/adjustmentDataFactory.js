﻿angular.module('bullseyeApp')
    .factory('adjustmentDataFactory', ['$http', 'settings', 'webApiProxy', function ($http, settings, webApiProxy) {
        var dataFactory = {};

        dataFactory.getExistingAdjustments = function (recordId) {
            return $http.get(settings.data.WebApiBaseUrl + '/adjustment/get?recordid=' + recordId);
        };

        dataFactory.getNewAdjustments = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList,
            selectedRegionIdList, selectedToggle) {
            var request = {
                recordId: recordId,
                selectedFsNodeIdList: selectedFsNodeIdList,
                selectedRbNodeIdList: selectedRbNodeIdList,
                selectedMonthList: selectedMonthList,
                selectedDividendPartnerIdList: selectedDividendPartnerIdList,
                selectedRegionIdList: selectedRegionIdList,
                selectedToggle: selectedToggle
            };
            return $http.get(settings.data.WebApiBaseUrl + '/adjustment/getNewAdjustments', { params: request });
        };        

        dataFactory.getTaggedData = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedTagIdList) {
            var request = {
                recordId: recordId,
                selectedFsNodeIdList: selectedFsNodeIdList,
                selectedRbNodeIdList: selectedRbNodeIdList,
                selectedMonthList: selectedMonthList,
                selectedTagIdList: selectedTagIdList
            };
            return $http.get(settings.data.WebApiBaseUrl + '/adjustment/getTaggedData', { params: request });
        };

        dataFactory.clearAdjustments = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, selectedDividendPartnerIdList,
            selectedRegionIdList) {
            var request = {
                recordId: recordId,
                selectedFsNodeIdList: selectedFsNodeIdList,
                selectedRbNodeIdList: selectedRbNodeIdList,
                selectedMonthList: selectedMonthList,
                selectedDividendPartnerIdList: selectedDividendPartnerIdList,
                selectedRegionIdList: selectedRegionIdList                
            };
            return $http.get(settings.data.WebApiBaseUrl + '/adjustment/ClearSourceToggle', { params: request });
        };

        dataFactory.applyDefaultToggle = function (recordId, selectedFsNodeIdList, selectedRbNodeIdList, selectedMonthList, defaultToggleType, selectedLevel) {
            var request = {
                RecordId: recordId,
                SelectedFsNodeIdList: selectedFsNodeIdList,
                SelectedRbNodeIdList: selectedRbNodeIdList,
                SelectedMonthList: selectedMonthList,
                SelectedToggle: defaultToggleType,
                SelectedHierarchyNodeLevel: selectedLevel
            };
            return webApiProxy.postAndForget('/adjustment/ApplyDefaultToggle', request)
            //$http.get(settings.data.WebApiBaseUrl + '/adjustment/ApplyDefaultToggle', { params: request });
        };

        dataFactory.saveAdjustments = function(adjustmentDtos) {
            return $http.post(settings.data.WebApiBaseUrl + '/adjustment/SaveValues', adjustmentDtos);
        };

        return dataFactory;
    }]);