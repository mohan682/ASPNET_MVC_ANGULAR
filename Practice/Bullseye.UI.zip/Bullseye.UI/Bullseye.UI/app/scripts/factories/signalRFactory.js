﻿//angular.module('bullseyeApp')
//    .factory('signalrDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

//        var signalRFactory = {};

//        var connection = $.hubConnection();
//        var defaultHubProxy = connection.createHubProxy('defaultHub');
//        defaultHubProxy.on('statementUpdated', function (statementId) {
//            console.log(statementId);
//        });

//        signalRFactory.startListening = function () {
//            try{
//                connection.url = settings.data.SignalRBaseUrl;
//                connection.start();
//            }
//            catch(ex)
//            {
//                console.log(ex);
//            }
//        }

//        return signalRFactory;
//    }]);


angular.module('bullseyeApp')
    .factory('signalRFactory', ['$rootScope', 'settings',
    function ($rootScope, settings) {
        function signalRFactory(hubName, startOptions) {
            var connection = $.hubConnection();
            connection.disconnected(function (data) {
                console.log("SignalR disconnected");
                connection.start().done(function () { $rootScope.connectionId = connection.id; });
            });
            var proxy = connection.createHubProxy(hubName);
            proxy.on('statementUpdated', function (statementId) {
                //console.log(statementId);
            });
            connection.url = settings.data.SignalRBaseUrl;
            connection.start().done(function () { $rootScope.connectionId = connection.id; });

            return {
                on: function (eventName, callback) {
                    proxy.on(eventName, function (result) {
                        $rootScope.$apply(function () {
                            if (callback) {
                                callback(result);
                            }
                        });
                    });
                },
                off: function (eventName, callback) {
                    proxy.off(eventName, function (result) {
                        $rootScope.$apply(function () {
                            if (callback) {
                                callback(result);
                            }
                        });
                    });
                },
                invoke: function (methodName, callback) {
                    proxy.invoke(methodName)
                        .done(function (result) {
                            $rootScope.$apply(function () {
                                if (callback) {
                                    callback(result);
                                }
                            });
                        });
                },
                connection: connection
            };
        };

        return signalRFactory;
    }]);