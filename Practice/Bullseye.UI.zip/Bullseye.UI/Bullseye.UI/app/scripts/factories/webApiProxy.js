﻿angular.module('bullseyeApp')
    .factory('webApiProxy', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.post = function (postPath) {
            return $http.post(settings.data.WebApiBaseUrl + postPath);
        };

        dataFactory.post = function (postPath, data) {
            return $http.post(settings.data.WebApiBaseUrl + postPath, data);
        };

        dataFactory.postAndForget = function (postPath) {            
            var canceler = $q.defer();
            $http({
                method: 'POST',
                url: settings.data.WebApiBaseUrl + postPath,
                timeout: 29000,
            }).then(function (data) {
                canceler.resolve();
            },
            function () {
                canceler.resolve();
            });
            canceler.resolve();
        };

        dataFactory.postAndForget = function (postPath, data) {            
            var canceler = $q.defer();
            $http({
                method: 'POST',
                url: settings.data.WebApiBaseUrl + postPath,
                data: data,
                timeout: 29000,
            }).then(function (data) {
                canceler.resolve();
            },
            function () {
                canceler.resolve();
            });
            canceler.resolve();
        };

        dataFactory.get = function (getPath) {
            return $http.get(settings.data.WebApiBaseUrl + getPath);
        };

        dataFactory.getWithParams = function (getPath, request) {
            return $http.get(settings.data.WebApiBaseUrl + getPath, { params: request });
        };        

        return dataFactory;
    }]);