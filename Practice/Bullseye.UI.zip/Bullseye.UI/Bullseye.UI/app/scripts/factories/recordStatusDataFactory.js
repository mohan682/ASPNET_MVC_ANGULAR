﻿angular.module('bullseyeApp')
    .factory('recordStatusDataFactory', ['$http', '$q', 'settings', 'webApiProxy', function ($http, $q, settings, webApiProxy) {

        var dataFactory = {};        

        dataFactory.setStatus = function (statementId, status) {
            var path = '/recordStatus?recordId=' + statementId+'&status='+status;
            return webApiProxy.post(path);            
        };

        return dataFactory;
    }]);