﻿angular.module('bullseyeApp')
    .factory('summaryFinancialsDataFactory',
        [
            '$http', 'settings', 
            function($http, settings) {

                var dataFactory = {};

                dataFactory.getFinancialInformation = function(statementId, rbNodeId) {
                   // alert("you made a call");

                    //return null;
                    return $http.get(settings.data.WebApiBaseUrl +
                        '/StatementData/GetStatementSummary?statementId=' +
                        statementId +
                        "&rBHierarchyNodeIds=" +
                        rbNodeId);
                };

                return dataFactory;
            }
        ]);