﻿angular.module('bullseyeApp')
    .factory('tagDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.getTags = function () {
            var deferred = $q.defer();
            $http.get(settings.data.WebApiBaseUrl + '/tag').success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);