﻿angular.module('bullseyeApp')
    .factory('settingsDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var urlBase = '/api';
        var dataFactory = {};

        dataFactory.loadSettings = function () {
            var deferred = $q.defer();
            $http.get(urlBase + '/settings').success(function(response)
            {
                settings.data = response;
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);