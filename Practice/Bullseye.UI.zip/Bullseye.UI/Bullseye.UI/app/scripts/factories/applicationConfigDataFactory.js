﻿angular.module('bullseyeApp')
    .factory('applicationConfigDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getApplicationConfigs = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/ApplicationConfigs');
        };

        dataFactory.updateApplicationConfig = function (config) {
            return $http.put(settings.data.WebApiBaseUrl + '/ApplicationConfigs/put/' + config.Id, config);
        };

        dataFactory.getDocumentationPath = function () {
          return $http.get(settings.data.WebApiBaseUrl + "/ApplicationConfigs/Get?keyNam=DocumentsDirectory");
        };
        return dataFactory;
    }]);