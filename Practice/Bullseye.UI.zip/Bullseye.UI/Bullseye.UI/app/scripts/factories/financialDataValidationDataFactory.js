﻿angular.module('bullseyeApp')
    .factory('financialDataValidationDataFactory', ['$http', 'settings', function ($http, settings) {

        var dataFactory = {};

        dataFactory.getVarianceData = function (statementId, rbNodesForFirstSection, rbNodeForSecondSection) {
          return $http.get(settings.data.WebApiBaseUrl +
                        '/StatementData/GetStatementSummaryForVariance?statementId=' +
                        statementId + rbNodesForFirstSection + rbNodeForSecondSection);

          
          //return $http.get(settings.data.WebApiBaseUrl +
          //  '/StatementData/GetStatementSummaryForVariance?statementId=182355&rBHierarchyNodeIdsForFirstSection=1133880&rBHierarchyNodeIdsForFirstSection=1133881&rBHierarchyNodeIdsForSecondSection=1133880');


        };

        return dataFactory;
    }]);