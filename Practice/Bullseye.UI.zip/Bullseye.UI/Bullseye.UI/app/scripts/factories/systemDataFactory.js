﻿angular.module('bullseyeApp')
    .factory('systemDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {
        var urlBase = '/api';
        var dataFactory = {};

        dataFactory.getVersion = function () {
            var deferred = $q.defer();
            $http.get(urlBase + '/version').success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;            
        };

        return dataFactory;
    }]);