﻿angular.module('bullseyeApp')
    .factory('rolesDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.getUserRoles = function () {                        
            var deferred = $q.defer();                        
            $http.get(settings.data.WebApiBaseUrl + '/securityroles').success(function (response) {
                deferred.resolve(response);            
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);