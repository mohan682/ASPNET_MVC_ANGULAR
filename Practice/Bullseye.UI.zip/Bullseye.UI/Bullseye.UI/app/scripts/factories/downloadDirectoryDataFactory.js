﻿angular.module('bullseyeApp')
    .factory('downloadDirectoryDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getDownloadDirectoryList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/downloaddirectories');
        };

        dataFactory.getDownloadDirectoryListByDownloadTypeId = function (downloadTypeId) {
            return $http.get(settings.data.WebApiBaseUrl + '/downloaddirectories/getByDownloadType/?downloadTypeId=' + downloadTypeId);
        };

        dataFactory.updateDownloadDirectory = function (downloadDirectory) {
            return $http.put(settings.data.WebApiBaseUrl + '/downloaddirectories/put/' + downloadDirectory.Id, downloadDirectory);
        };

        dataFactory.saveDownloadDirectoryList = function (downloadDirectoryList) {
            return $http.post(settings.data.WebApiBaseUrl + '/downloaddirectories/post/', downloadDirectoryList);
        };

        return dataFactory;
    }]);