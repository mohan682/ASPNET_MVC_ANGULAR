﻿angular.module('bullseyeApp')
    .factory('hierarchySetDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getHierarchySetList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchyset');
        };

        dataFactory.getHierarchySet = function (hierarchySetId) {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchySet/get/' + hierarchySetId);
        };

        dataFactory.getWorkInProgressHierarchySet = function (hierarchySetId) {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchySet/GetWorkInProgressHierarchySet?hierarchySetId=' + hierarchySetId);
        }

        dataFactory.saveHierarchySet = function (hierarchySetId, name) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchySet/saveHierarchySet?hierarchySetId=' + hierarchySetId + '&Name=' + encodeURIComponent(name));
        };

        dataFactory.saveAsNewHierarchySet = function (hierarchySetId, newName) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchySet/saveAsNewHierarchySet?hierarchySetId=' + hierarchySetId + '&Name=' + encodeURIComponent(newName));
        };

        dataFactory.saveAsLatestHierarchySet = function (hierarchySetId) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchySet/SaveAsLatestHierarchySet?hierarchySetId=' + hierarchySetId);
        };

        return dataFactory;
    }]);