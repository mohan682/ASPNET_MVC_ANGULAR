﻿angular.module('bullseyeApp')
    .factory('hierarchyDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getFinancialStatementHierarchy = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/financialstatementhierarchy');
        };

        dataFactory.getRBHierarchy = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/rbhierarchy');
        };

        dataFactory.getHierarchyList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchy');
        };

        dataFactory.getHierarchy = function (hierarchyId) {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchy/get/' + hierarchyId);
        };

        dataFactory.getDefaultToggleMappings = function (hierarchyId, defaultToggleTypeId) {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchy/getDefaultToggleMappings?hierarchyId=' + hierarchyId + '&defaultToggleTypeId=' + defaultToggleTypeId);
        };

        dataFactory.saveDefaultToggleMappings = function (hierarchyId, defaultToggleTypeId, itemsToSave) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchy/saveDefaultToggleMappings?hierarchyId=' + hierarchyId + '&defaultToggleTypeId=' + defaultToggleTypeId, itemsToSave);
        };

        return dataFactory;
    }]);