﻿angular.module('bullseyeApp')
    .factory('auditLogDetailDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getAuditLogList = function (statementId) {
            return $http.get(settings.data.WebApiBaseUrl + '/AuditData/GetAuditData?statementId='+statementId);
        };

        return dataFactory;
    }]);