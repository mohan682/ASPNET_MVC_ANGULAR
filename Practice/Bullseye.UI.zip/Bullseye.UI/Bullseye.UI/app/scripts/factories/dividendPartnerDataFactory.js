﻿angular.module('bullseyeApp')
    .factory('dividendPartnerDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.getDividendPartners = function () {
            var deferred = $q.defer();
            $http.get(settings.data.WebApiBaseUrl + '/dividendPartners').success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);