﻿angular.module('bullseyeApp')
    .factory('recordNodeInfoDataFactory', ['$http', 'settings', function ($http, settings) {

        var dataFactory = {};

        dataFactory.getRecordNodeInfoDetail = function (request) {
            return $http.get(settings.data.WebApiBaseUrl + '/recordnodeinfo/get/', { params: request });
        };
        
        return dataFactory;
    }]);