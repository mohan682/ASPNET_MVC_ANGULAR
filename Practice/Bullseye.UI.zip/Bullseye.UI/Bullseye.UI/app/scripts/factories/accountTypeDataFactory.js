﻿angular.module('bullseyeApp')
    .factory('accountTypeDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getAccountTypeList = function (statementId, type) {
            return $http.get(settings.data.WebApiBaseUrl + '/accountType');
        };

        return dataFactory;
    }]);