﻿angular.module('bullseyeApp')
    .factory('statementPublishDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.publishStatement = function (statementId) {
            var deferred = $q.defer();
            $http.post(settings.data.WebApiBaseUrl + '/statementpublish/publish?statementId=' + statementId).success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        dataFactory.unpublishStatement = function (statementId) {
            var deferred = $q.defer();
            $http.post(settings.data.WebApiBaseUrl + '/statementpublish/unpublish?statementId=' + statementId).success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);