﻿angular.module('bullseyeApp')
    .factory('kpiCalculationDataFactory', ['$http', 'settings', 'webApiProxy', function ($http, settings, webApiProxy) {
        var dataFactory = {};

        dataFactory.calculate = function (statementId, type) {
            var path = '/kpicalculation?statementId=' + statementId + '&type=' + type;
            webApiProxy.postAndForget(path);            
        };

        dataFactory.calculate = function (statementId, type, selectedRbNodeIdList, selectedLevel) {
            var request = {
                statementId: statementId,
                type: type,
                selectedRbNodeIdList: selectedRbNodeIdList,
                selectedHierarchyNodeLevel: selectedLevel
            };
            var path = '/kpicalculation';
            webApiProxy.postAndForget(path, request);            
        };

        return dataFactory;
    }]);