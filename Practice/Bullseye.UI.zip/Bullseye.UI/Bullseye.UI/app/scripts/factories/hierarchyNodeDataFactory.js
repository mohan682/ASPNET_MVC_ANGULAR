﻿angular.module('bullseyeApp')
    .factory('hierarchyNodeDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getNodeDetails = function (hierarchyNodeId, isTempNode) {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchyNode/get/' + hierarchyNodeId + '?istempnode=' + isTempNode);
        };

        dataFactory.saveNodeDetails = function (nodeData) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchyNode/savenodedetail/', nodeData);
        };

        dataFactory.createNode = function (node) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchyNode/createNode/', node);
        };

        dataFactory.deleteNode = function (nodeId) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchyNode/deleteNode?hierarchyNodeId=' + nodeId);
        };

        dataFactory.getNodeDataReferences = function (nodeId) {
            return $http.get(settings.data.WebApiBaseUrl + '/hierarchyNode/getNodeDataReferences?hierarchyNodeId=' + nodeId);
        };

        dataFactory.moveNode = function (nodeId, newParentNodeId) {
            return $http.post(settings.data.WebApiBaseUrl + '/hierarchyNode/moveNode?sourceNodeId=' + nodeId + '&destinationNodeId=' + newParentNodeId);
        };

        return dataFactory;
    }]);