﻿angular.module('bullseyeApp')
    .factory('adjustmentFileUploadDataFactory', ['$http', '$q', 'webApiProxy', function ($http, $q, webApiProxy) {
        var dataFactory = {};
        var basePath = '/adjustmentFileUpload/';

        dataFactory.getAdjustmentFileNames = function () {
            var path = basePath + 'getAdjustmentFileNames';
            return webApiProxy.get(path);            
        };

        dataFactory.loadAdjustmentsFile = function (statementId, fileName) {            
            var path = basePath + 'loadAdjustmentsFile/?statementId=' + statementId + '&fileName=' + fileName;
            return webApiProxy.get(path);
        };

        dataFactory.processAdjustments = function (statementId, data, confirmSave) {
            var path = basePath + 'processAdjustments/?statementId=' + statementId + '&confirmSave=' + confirmSave;
            return webApiProxy.post(path, data);
        };

        return dataFactory;
    }]);