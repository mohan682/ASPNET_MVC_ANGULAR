﻿angular.module('bullseyeApp')
    .factory('recordNodeLockDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getRecordNodeLocks = function (statementId) {
            return $http.get(settings.data.WebApiBaseUrl + '/RecordNodeLock?Id=' + statementId);
        };

        dataFactory.saveRecordNodeLocks = function (statementId, data) {
            return $http.post(settings.data.WebApiBaseUrl + '/RecordNodeLock?recordId=' + statementId, data);
        };

        return dataFactory;
    }]);