﻿angular.module('bullseyeApp')
    .factory('businessUnitDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {
        var dataFactory = {};

        dataFactory.getBusinessUnitList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/businessUnit');
        };

        dataFactory.updateBusinessUnit = function (businessUnit) {
            return $http.put(settings.data.WebApiBaseUrl + '/businessUnit/put/' + businessUnit.Id, businessUnit);
        };

        dataFactory.deleteBusinessUnit = function (businessUnitId) {
            return $http.delete(settings.data.WebApiBaseUrl + '/businessUnit/delete/' + businessUnitId);
        };

        dataFactory.createBusinessUnit = function (businessUnit) {
            var deferred = $q.defer();
            $http.post(settings.data.WebApiBaseUrl + '/businessUnit', businessUnit).success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);