﻿angular.module('bullseyeApp')
    .factory('tprMappingDataFactory', ['$http', '$q', 'webApiProxy', function ($http, $q, webApiProxy) {
        var dataFactory = {};
        var basePath = '/tprMappings/';

        dataFactory.getTprMappingFileNames = function () {
            var path = basePath + 'getMappingsFileNames';
            return webApiProxy.get(path);            
        };

        dataFactory.loadTprMappingFile = function (hierarchySetId, fileName) {            
            var path = basePath + 'loadMappingsFile/?hierarchySetId=' + hierarchySetId + '&fileName=' + fileName;
            return webApiProxy.get(path);
        };

        dataFactory.processTprMappings = function (hierarchySetId, data, confirmSave) {
            var path = basePath + 'processMappings/?hierarchySetId=' + hierarchySetId + '&confirmSave=' + confirmSave;
            return webApiProxy.post(path, data);
        };

        dataFactory.exportTprMappings = function (hierarchySetId) {
            var path = basePath + 'exportMappings/?hierarchySetId=' + hierarchySetId;
            return webApiProxy.post(path);
        };

        return dataFactory;
    }]);