﻿angular.module('bullseyeApp')
    .factory('downloadTypeDataFactory', ['$http', 'settings', function ($http, settings) {        
        var dataFactory = {};

        dataFactory.getDownloadTypeList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/downloadtype');
        };

        return dataFactory;
    }]);