﻿angular.module('bullseyeApp')
    .factory('statementTypeDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {
        var dataFactory = {};

        dataFactory.getStatementTypeList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/statementtypes');
        };

        dataFactory.updateStatementType = function(statementType) {
            return $http.put(settings.data.WebApiBaseUrl + '/statementtypes/put/' + statementType.Id, statementType);
        };

        dataFactory.deleteStatementType = function(statementTypeId) {
            return $http.delete(settings.data.WebApiBaseUrl + '/statementtypes/delete/' + statementTypeId);
        };

        dataFactory.createStatementType = function (statementType) {
            var deferred = $q.defer();
            $http.post(settings.data.WebApiBaseUrl + '/statementtypes', statementType).success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };        

        return dataFactory;
    }]);