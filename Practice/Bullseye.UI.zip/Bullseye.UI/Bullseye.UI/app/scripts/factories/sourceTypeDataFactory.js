﻿angular.module('bullseyeApp')
    .factory('sourceTypeDataFactory', ['$http', 'settings', function ($http, settings) {        
        var dataFactory = {};

        dataFactory.getSourceTypeList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/sourcetype');
        };

        return dataFactory;
    }]);