﻿angular.module('bullseyeApp')
    .factory('reportdataDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.generateExport = function (statementId, directoryId) {
            var deferred = $q.defer();
            $http.post(settings.data.WebApiBaseUrl + '/reportdata/post/?id=' + statementId+'&downloadDirectoryId='+ directoryId).success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);