﻿angular.module('bullseyeApp')
    .factory('reStatementDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.generateExport = function (statementId, directoryId) {
            var deferred = $q.defer();
            $http.get(settings.data.WebApiBaseUrl + '/restatement/exporttocsv?id=' + statementId+'&downloadDirectoryId='+ directoryId).success(function (response) {
                deferred.resolve(response);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);