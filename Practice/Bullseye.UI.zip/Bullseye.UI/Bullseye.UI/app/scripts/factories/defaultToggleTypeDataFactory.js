﻿angular.module('bullseyeApp')
    .factory('defaultToggleTypeDataFactory', ['$http', '$q', 'settings', function ($http, $q, settings) {

        var dataFactory = {};

        dataFactory.getDefaultToggleTypes = function () {
            var deferred = $q.defer();
            $http.get(settings.data.WebApiBaseUrl + '/DefaultToggleType/get').success(function (response) {
                deferred.resolve(response);
            }).error(function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        };

        return dataFactory;
    }]);