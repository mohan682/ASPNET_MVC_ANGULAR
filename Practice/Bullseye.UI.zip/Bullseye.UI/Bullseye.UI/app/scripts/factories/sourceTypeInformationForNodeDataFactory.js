﻿angular.module('bullseyeApp')
    .factory('sourceTypeInformationForNodeDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getCalculationData = function (recordId, fsNodeId, rbNodeId, dividendPartnerId, regionId, date) {
            var request = {
                recordId: recordId,
                date: date,
                fsNodeId: fsNodeId,
                rbNodeId: rbNodeId,
                dividendPartnerId: dividendPartnerId,
                regionId: regionId
            };
            return $http.get(settings.data.WebApiBaseUrl + '/adjustment/GetCalculationDetails', { params: request });
        };

        return dataFactory;
    }]);