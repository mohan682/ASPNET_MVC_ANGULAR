﻿angular.module('bullseyeApp')
    .factory('recordDataFactory', ['$http', 'settings', 'webApiProxy', function ($http, settings, webApiProxy) {

        var dataFactory = {};

        dataFactory.getAllRecords = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/records/get');
        };

        dataFactory.getRecord = function (statementId, loadHierarchy) {
            return $http.get(settings.data.WebApiBaseUrl + '/records/get?id=' + statementId + '&loadHierarchy=' + loadHierarchy);
        };

        dataFactory.createRecord = function (asNewVersion, newRecord) {
            return $http.post(settings.data.WebApiBaseUrl + '/records/post?asNewVersion=' + asNewVersion, newRecord);
        };

        dataFactory.validateNewRecord = function (record) {
            return $http.post(settings.data.WebApiBaseUrl + '/records/ValidateNewRecord/', record);
        };

        dataFactory.saveAsNewRecord = function (record) {
            var path = '/records/SaveAsNew/';
            webApiProxy.postAndForget(path, record);            
        };

        dataFactory.saveAsNewVersion = function (record) {
            var path = '/records/SaveAsNewVersion/';
            webApiProxy.postAndForget(path, record);            
        };

        dataFactory.mergeStatement = function (statementId, mergeStatementData, kpiOptions) {
            var mergeRequest = {
                targetRecordId: statementId,
                sourceRecords: mergeStatementData,
                KpiCalculationTypes: kpiOptions.kpiCalculationTypes,
                SelectedRbNodeIdList: kpiOptions.selectedRbNodeIdList,
                SelectedHierarchyNodeLevel: kpiOptions.selectedHierarchyNodeLevel
            };
            var path = '/records/MergeStatements/';
            webApiProxy.postAndForget(path, mergeRequest);            
        };

        dataFactory.splitRecord = function (options, asNewVersion) {
            var splitRequest = options;
            splitRequest.AsNewVersion = asNewVersion;
            var path = '/records/SplitStatement';
            webApiProxy.postAndForget(path, splitRequest);            
        }

        dataFactory.isValidNewRecord = function (record) {
            var request = {
                recordId: record.Id,
                year: record.Year,
                businessUnit: record.BusinessUnit,
                quarter: record.Quarter,
                statementType: record.StatementType,
                month: record.Month
            };
            return $http.get(settings.data.WebApiBaseUrl + '/records/IsValidNewRecord/', { params: request });
        };

        dataFactory.isDuplicateRecord = function (hierarchySetName, year, businessUnit, quarter, statementType, month) {
            var request = {
                year: year,
                businessUnit: businessUnit,
                quarter: quarter,
                statementType: statementType,
                month: month,
                hierarchySetName: hierarchySetName
            };
            return $http.get(settings.data.WebApiBaseUrl + '/records/IsDuplicateRecord/', { params: request });
        };

        dataFactory.save = function (record) {
            var path = '/records/Save/';
            webApiProxy.postAndForget(path, record);            
        };

        dataFactory.cancel = function (record) {
            return $http.post(settings.data.WebApiBaseUrl + '/records/Cancel/', record);
        };

        dataFactory.delete = function (statementId, deleteLowerVersions) {
            return $http.delete(settings.data.WebApiBaseUrl + '/records/delete/?id=' + statementId + '&deleteLowerVersions=' + deleteLowerVersions);
        };

        return dataFactory;
    }]);