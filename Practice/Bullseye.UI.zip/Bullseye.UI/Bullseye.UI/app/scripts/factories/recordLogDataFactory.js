﻿angular.module('bullseyeApp')
    .factory('recordLogDataFactory', ['$http', 'settings', function ($http, settings) {

        var dataFactory = {};

        dataFactory.getRecordLogs = function (statementId) {
            return $http.get(settings.data.WebApiBaseUrl + '/recorduploadlog/get/'+ statementId);
        };

        dataFactory.getRecordLogDetails = function (statementId, groupId) {
            return $http.get(settings.data.WebApiBaseUrl + '/recorduploadlog/get/?id=' + statementId + '&groupId=' + groupId);
        };

        return dataFactory;
    }]);