﻿angular.module('bullseyeApp')
    .factory('calculationDataFactory', ['$http', 'settings', 'webApiProxy', function ($http, settings, webApiProxy) {
        var dataFactory = {};

        dataFactory.calculate = function (statementId, type) {
            var path = '/calculation?statementId=' + statementId + '&type=' + type;
            webApiProxy.postAndForget(path);            
        };

        return dataFactory;
    }]);