﻿angular.module('bullseyeApp')
    .factory('uploadSourceDataFactory', ['$http', '$q', 'settings', 'webApiProxy', function ($http, $q, settings, webApiProxy) {
        var dataFactory = {};

        dataFactory.uploadSource = function (fileName, uploadType, statementId, sourceDirectoryId, isIncrementalUpload) {
            var path = '/upload?filename=' + fileName + '&uploadType=' + uploadType + '&statementId=' + statementId + '&sourceDirectoryId=' + sourceDirectoryId + '&incrementalUpload=' + isIncrementalUpload;
            webApiProxy.postAndForget(path);
            //webApiProxy.post(path);            
        };

        dataFactory.uploadMultipleSources = function (files, statementId) {

                var path = '/Upload/UploadMultipleFiles?statementId=' + statementId;

            webApiProxy.postAndForget(path,  files);
        };
        
        return dataFactory;
    }]);