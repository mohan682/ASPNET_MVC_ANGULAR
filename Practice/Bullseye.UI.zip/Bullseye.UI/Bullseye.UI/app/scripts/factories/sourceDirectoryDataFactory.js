﻿angular.module('bullseyeApp')
    .factory('sourceDirectoryDataFactory', ['$http', 'settings', function ($http, settings) {
        var dataFactory = {};

        dataFactory.getSourceDirectoryList = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/sourcedirectories');
        };

        dataFactory.getSourceDirectoryListBySourceTypeId = function (sourceTypeId) {
            return $http.get(settings.data.WebApiBaseUrl + '/sourcedirectories/getBySourceType/?sourceTypeId=' + sourceTypeId);
        };

        dataFactory.updateSourceDirectory = function (sourceDirectory) {
            return $http.put(settings.data.WebApiBaseUrl + '/sourcedirectories/put/' + sourceDirectory.Id, sourceDirectory);
        };

        dataFactory.saveSourceDirectoryList = function (sourceDirectoryList) {
            return $http.post(settings.data.WebApiBaseUrl + '/sourcedirectories/post/', sourceDirectoryList);
        };

        dataFactory.getFileNames = function (sourceDirectoryId) {
            return $http.get(settings.data.WebApiBaseUrl + "/sourcedirectories/getfilenames/" + sourceDirectoryId);
        };

        dataFactory.getServiceAccountName = function () {
            return $http.get(settings.data.WebApiBaseUrl + "/sourcedirectories/getserviceaccountname/");
        };

        dataFactory.hasDirectoryAccess = function (directoryPath) {
            return $http.get(settings.data.WebApiBaseUrl + "/sourcedirectories/hasdirectoryaccess/?directoryPath=" + directoryPath);
        };

        return dataFactory;
    }]);