﻿angular.module('bullseyeApp')
    .factory('recordEditLogDataFactory', ['$http', 'settings', function ($http, settings) {

        var dataFactory = {};

        dataFactory.getRecordEditLogs = function (statementId) {
            return $http.get(settings.data.WebApiBaseUrl + '/recordeditlog/get?recordId=' + statementId);
        };

        dataFactory.getAllRecordEditLogs = function () {
            return $http.get(settings.data.WebApiBaseUrl + '/recordeditlog/get');
        };        

        dataFactory.isAnotherUserInEdit = function (statementId) {
            return $http.get(settings.data.WebApiBaseUrl + '/recordeditlog/getIfAnotherUserInEdit?recordId=' + statementId);
        };

        dataFactory.logRecordEdit = function (statementId) {
            return $http.post(settings.data.WebApiBaseUrl + '/recordeditlog/post?recordId=' + statementId);
        };

        dataFactory.GetAllOtherEditsForRecord = function (statementId) {
            return $http.get(settings.data.WebApiBaseUrl + '/recordeditlog/GetAllOtherEditsForRecord?recordId=' + statementId);
        };

        return dataFactory;
    }]);