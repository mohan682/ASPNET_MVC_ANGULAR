﻿angular.module('bullseyeApp')
    .factory('fbwMappingDataFactory', ['$http', '$q', 'webApiProxy', function ($http, $q, webApiProxy) {
        var dataFactory = {};
        var basePath = '/fbwMappings/';

        dataFactory.getFbwMappingFileNamesForRb = function () {
            var path = basePath + 'getMappingsFileNamesForRb';
            return webApiProxy.get(path);            
        };

        dataFactory.loadFbwMappingFileForRb = function (hierarchySetId, fileName) {            
            var path = basePath + 'loadMappingsFileForRb/?hierarchySetId=' + hierarchySetId + '&fileName=' + fileName;
            return webApiProxy.get(path);
        };

        dataFactory.processFbwMappingsForRb = function (hierarchySetId, data, confirmSave) {
            var path = basePath + 'processMappingsForRb/?hierarchySetId=' + hierarchySetId + '&confirmSave=' + confirmSave;
            return webApiProxy.post(path, data);
        };

        dataFactory.exportFbwMappingsForRb = function (hierarchySetId) {
            var path = basePath + 'exportMappingsForRb/?hierarchySetId=' + hierarchySetId;
            return webApiProxy.post(path);
        };

        // FS Nodes


        dataFactory.getFbwMappingFileNamesForFs = function () {
            var path = basePath + 'getMappingsFileNamesForFs';
            return webApiProxy.get(path);
        };

        dataFactory.loadFbwMappingFileForFs = function (hierarchySetId, fileName) {
            var path = basePath + 'loadMappingsFileForFs/?hierarchySetId=' + hierarchySetId + '&fileName=' + fileName;
            return webApiProxy.get(path);
        };

        dataFactory.processFbwMappingsForFs = function (hierarchySetId, data, confirmSave) {
            var path = basePath + 'processMappingsForFs/?hierarchySetId=' + hierarchySetId + '&confirmSave=' + confirmSave;
            return webApiProxy.post(path, data);
        };

        dataFactory.exportFbwMappingsForFs = function (hierarchySetId) {
            var path = basePath + 'exportMappingsForFs/?hierarchySetId=' + hierarchySetId;
            return webApiProxy.post(path);
        };
        return dataFactory;
    }]);