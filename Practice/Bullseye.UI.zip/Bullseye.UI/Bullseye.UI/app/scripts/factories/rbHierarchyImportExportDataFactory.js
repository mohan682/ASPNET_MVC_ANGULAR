﻿angular.module('bullseyeApp')
    .factory('rbHierarchyImportExportDataFactory', ['$http', '$q', 'webApiProxy', function ($http, $q, webApiProxy) {
        var dataFactory = {};
        var basePath = '/rbHierarchyImportExport/';

        dataFactory.getRbHierarchyFileNames = function () {
            var path = basePath + 'getHierarchyFileNames';
            return webApiProxy.get(path);            
        };

        dataFactory.loadRbHierarchyFile = function (hierarchySetId, fileName) {
            var path = basePath + 'loadHierarchyFile/?hierarchySetId=' + hierarchySetId + '&fileName=' + fileName;
            return webApiProxy.get(path);
        };

        dataFactory.processRbHierarchyUpload = function (hierarchySetId, data, confirmSave) {
            var path = basePath + 'processHierarchy/?hierarchySetId=' + hierarchySetId + '&confirmSave=' + confirmSave;
            return webApiProxy.post(path, data);
        };

        dataFactory.exportRbHierarchy = function (hierarchySetId) {
            var path = basePath + 'exportHierarchy/?hierarchySetId=' + hierarchySetId;
            return webApiProxy.post(path);
        };

        return dataFactory;
    }]);