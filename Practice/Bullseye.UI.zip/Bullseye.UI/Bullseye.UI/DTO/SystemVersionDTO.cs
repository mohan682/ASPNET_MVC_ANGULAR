﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bullseye.UI.DTO
{
    public class SystemVersionDTO
    {
        public string Version { get; set; }
        public DateTime LastUpdated { get; set; }
    }
}