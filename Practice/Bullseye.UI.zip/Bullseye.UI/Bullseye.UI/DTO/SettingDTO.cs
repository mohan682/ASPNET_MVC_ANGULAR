﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bullseye.UI.DTO
{
    public class SettingDTO
    {
        public string WebApiBaseUrl { get; set; }
        public string SignalRBaseUrl { get; set; }
        public string Environment { get; set; }
    }
}