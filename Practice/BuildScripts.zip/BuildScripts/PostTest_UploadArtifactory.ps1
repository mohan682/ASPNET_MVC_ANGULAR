[Environment]::SetEnvironmentVariable("EnableNuGetPackageRestore", "true", "Process")

# Enable -Verbose option
#[CmdletBinding()]

#$uri = [URI]$ENV:TF_BUILD_COLLECTIONURI
#Write-Output "Connecting to TFS Collection $uri"
#$pathToAss2 = "C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE\ReferenceAssemblies\v2.0"
#$pathToAss4 = "C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE\ReferenceAssemblies\v4.5"
#Add-Type -Path "$pathToAss2\Microsoft.TeamFoundation.Client.dll"
#Add-Type -Path "$pathToAss2\Microsoft.TeamFoundation.Build.Client.dll"
#Add-Type -Path "$pathToAss2\Microsoft.TeamFoundation.Build.Common.dll"
#Add-Type -Path "$pathToAss2\Microsoft.TeamFoundation.TestManagement.Client.dll"

#$tfs = [Microsoft.TeamFoundation.Client.TfsTeamProjectCollectionFactory]::GetTeamProjectCollection($uri)
#$tms = $tfs.GetService("Microsoft.TeamFoundation.TestManagement.Client.ITestManagementService")
#$testResults = $tms.QueryTestRuns("select * from TestResult where TestRun.BuildNumber='$($ENV:TF_BUILD_BUILDURI)'")
#Write-Output "Retrieving test results for $($ENV:TF_BUILD_BUILDURI)"

#if($testResults.PassedTests -lt $testResults.TotalTests) {
#	write-error "Not all tests have passed ( $($testResults.PassedTests) out of $($testResults.TotalTests)). No packaging and uploading"
#	exit 1
#} else {
#	write-output "All tests passed ($($testResults.PassedTests) out of $($testResults.TotalTests))"
#}

# The package output folder
# $nupkgFolder = (join-path (split-path $Env:BUILD_SOURCESDIRECTORY -parent) "artifacts")
$nupkgFolder = (join-path (split-path $Env:BUILD_SOURCESDIRECTORY -parent) "a")

Write-Host "Upload nuget packages to Artifactory, using PushNupkg.ps1 [$nupkgFolder]"
	
# push the output package to Artifactory
$artifactoryURL = "http://dml.bpweb.bp.com:8088/artifactory/api/nuget/bp-frt-dpl-nuget-snapshot-local/TPR"

& "C:\Program Files (x86)\NuGet\Visual Studio 2012\PushNupkg.ps1" -artifactoryUrl $artifactoryURl -PackageFolder $nupkgFolder

Exit 0