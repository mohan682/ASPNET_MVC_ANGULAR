param
(
	[string] $ExpectedEnv,
	[string] $config
)

if($ExpectedEnv -eq "ST")
{
	Copy-Item $config \\bp1xtxii491\tpr.inta$\wwwroot\TPR\TPR.Services.Host\Web.config
	Copy-Item $config \\bp1xtxii492\tpr.inta$\wwwroot\TPR\TPR.Services.Host\Web.config
}