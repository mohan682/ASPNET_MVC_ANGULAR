# Script to update the version number in the AssemblyInfo files
# and update the version number in the nuspec files
	
# Regular expression pattern to find the version in the build number 
# and then apply it to the assemblies
$VersionRegex = "\d+\.\d+\.\d+\.\d+"
	
# If this script is not running on a build server, remind user to 
# set environment variables so that this script can be debugged
if(-not $Env:TF_BUILD -and -not ($Env:TF_BUILD_SOURCESDIRECTORY -and $Env:TF_BUILD_BUILDNUMBER))
{
	Write-Error "You must set the following environment variables"
	Write-Error "to test this script interactively."
	Write-Host '$Env:TF_BUILD_SOURCESDIRECTORY - For example, enter something like:'
	Write-Host '$Env:TF_BUILD_SOURCESDIRECTORY = "C:\code\HelloWorld"'
	Write-Host '$Env:TF_BUILD_BUILDNUMBER - For example, enter something like:'
	Write-Host '$Env:TF_BUILD_BUILDNUMBER = "Build HelloWorld_0000.00.00.0"'
	exit 1
}
	
# Make sure path to source code directory is available
if (-not $Env:TF_BUILD_SOURCESDIRECTORY) {
	Write-Error ("TF_BUILD_SOURCESDIRECTORY environment variable is missing.")
	exit 1
}
elseif (-not (Test-Path $Env:TF_BUILD_SOURCESDIRECTORY)) {
	Write-Error "TF_BUILD_SOURCESDIRECTORY does not exist: $Env:TF_BUILD_SOURCESDIRECTORY"
	exit 1
}
write-host "TF_BUILD_SOURCESDIRECTORY: $Env:TF_BUILD_SOURCESDIRECTORY"
	
# Make sure there is a build number
if (-not $Env:TF_BUILD_BUILDNUMBER) {
	Write-Error ("TF_BUILD_BUILDNUMBER environment variable is missing.")
	exit 1
}
Write-Verbose "TF_BUILD_BUILDNUMBER: $Env:TF_BUILD_BUILDNUMBER"
	
# Get and validate the version data
$VersionData = [regex]::matches($Env:TF_BUILD_BUILDNUMBER,$VersionRegex)
switch($VersionData.Count) {
   0 { 
         Write-Error "Could not find version number data in TF_BUILD_BUILDNUMBER: $($env:TF_BUILD_BUILDNUMBER)"
         exit 1
      }
   1 {}
   default { 
         Write-Warning "Found more than 1 instance of version data in TF_BUILD_BUILDNUMBER." 
         Write-Warning "Will assume first instance is version."
      }
}
$NewVersion = $VersionData[0]
write-host "Version: $NewVersion"
	
# Apply the version to the assembly property files
$files = gci $Env:TF_BUILD_SOURCESDIRECTORY -recurse | where {$_.name -match "AssemblyInfo"}

if($files) {
	write-host "Will apply $NewVersion to $($files.count) files."
	
	foreach ($file in $files) {
		if(-not $Disable) {
			$filecontent = Get-Content $file.fullname
			$file.IsReadOnly = $false
			$filecontent -replace $VersionRegex, $NewVersion | Out-File $file.fullname
			write-host "$($file.FullName) - version applied"
		}
	}
}
else {
	Write-Warning "Found no files."
}


# attempt to insert version into nuspec file
$version=$($env:TF_BUILD_BUILDNUMBER).split("_")[1]
$srcPath=$env:TF_BUILD_SOURCESDIRECTORY
$outPath=(join-path (split-path $srcPath -parent) "bin")
write-host $outPath
$nuspecFiles = gci $srcPath -Filter "*.nuspec" -Recurse
foreach($n in $nuspecFiles) {
    write-host "Updating file $($n.fullname)"
    $n.IsReadOnly = $false
    $nuspec=[xml](gc $n.fullname)
    $nuspec.package.metadata.version=$version.ToString()
    $nuspec.package.files.FirstChild.setAttribute("src", (join-path $outPath "**\*.*").tostring())
    $nuspec.Save($n.FullName)
} 


