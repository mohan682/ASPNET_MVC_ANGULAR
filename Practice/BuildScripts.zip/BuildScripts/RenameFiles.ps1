param
(
	[string] $FilePath,
	[string] $NewName
)

rename-item -path $FilePath $NewName