import { TPRPage } from './app.po';

describe('tpr App', function() {
  let page: TPRPage;

  beforeEach(() => {
    page = new TPRPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
