"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
//importing angular modules
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var forms_1 = require('@angular/forms');
var http_1 = require('@angular/http');
var router_1 = require('@angular/router');
// importing the services
var NodetypeService = require("./service/app.TPRNodeTypeService");
var regionService = require("./service/app.regionService");
var TreeviewService = require("./service/app.TPRHierarchyservice");
var TagService = require("./service/app.TPRTagsService");
var DividendPartnersService = require("./service/app.TPRDividendPartnersService");
var BusinessSegmentsService = require("./service/app.TPRBusinessSegmentsService");
var HolidayService = require("./service/app.TPRHolidayService");
var CommonService = require("./service/app.TPRCommonService");
var app_dashboardData_service_1 = require('./service/app.dashboardData.service');
var ProfitAlertGroupService = require("./service/app.TPRProfitAlertGroupsService");
var ServiceHelper = require("./service/app.serviceHelper");
var TPRViewService = require("./service/app.reportsView.service");
var TPRDataSourcesService = require("./service/app.dataSources.service");
var TPRJobService = require("./service/app.jobs.service");
var TPRFileUploadService = require("./service/app.fileUpload.service");
var TPRServersService = require("./service/app.server.service");
var WorkDayService = require("./service/app.workDayService");
var app_customRoute_1 = require('./service/app.customRoute');
// Guards
var app_can_deactivate_guard_service_1 = require('./service/app.can-deactivate-guard.service');
var app_can_activate_guard_service_1 = require('./service/app.can-activate-guard.service');
// importing modules from primeng
var primeng_1 = require('primeng/primeng');
// importing the components
var app_component_1 = require("../app/app.component");
var TPRNodeTypeComponent = require("./components/nodeTypes/app.nodetypes.component");
var TPRDashboardComponent = require("./components/dashboard/app.dashboard.component");
var TPRRegionComponent = require("./components/regions/app.regions.component");
var TPRHolidayComponent = require("./components/holiday/app.holiday.component");
var TPRBusinessSegmentsComponent = require("./components/BusinessSegments/app.businessSegments.component");
var TPRHierarchyComponent = require("./components/treeView/app.treeView.component");
var AppTprHierarchyEditNodeComponent = require("./components/treeView/app.treeViewEditNode.component");
var AppTprHierarchyAddChildComponent = require("./components/treeView/app.treeViewAddChild.component");
var AppTprHierarchyEnterValueComponent = require("./components/treeView/app.treeViewEnterValue.component");
var TPRTagsComponent = require("./components/Tags/app.tags.component");
var TPRDividendPartnersComponent = require("./components/DividendPartners/app.dividendPartners.component");
var TPRAppReportsViewComponent = require("./components/reportsView/app.reportsView.component");
var TPRAppDataSourcesComponent = require("./components/dataSources/app.dataSources.component");
var TPRAppJobsComponent = require("./components/feeds/app.jobs.component");
var TPRAppFileUploadComponent = require("./components/feeds/app.fileUpload.component");
var TPRAppPageNotFoundComponent = require("./app.PageNotFound.component");
var DialogComponent = require("./components/common/app.dialogComponent");
var SpinnerComponent = require("./components/common/app.spinnerComponent");
var TPRAppProfitAlertGroupComponent = require("./components/ProfitAlertGroup/app.profitAlertGroup.component");
var AppErrorComponent = require("./components/error/app.error.component");
var app_routing_module_1 = require('../app/app-routing.module');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                primeng_1.CalendarModule,
                platform_browser_1.BrowserModule,
                forms_1.FormsModule,
                http_1.HttpModule,
                http_1.JsonpModule,
                primeng_1.CarouselModule,
                primeng_1.GrowlModule,
                primeng_1.ButtonModule,
                primeng_1.MenuModule,
                primeng_1.ContextMenuModule,
                primeng_1.AccordionModule,
                primeng_1.SharedModule,
                app_routing_module_1.routes,
                primeng_1.PanelMenuModule,
                primeng_1.DataTableModule,
                primeng_1.TreeModule,
                primeng_1.DropdownModule,
                primeng_1.DialogModule,
                primeng_1.ConfirmDialogModule,
                primeng_1.CheckboxModule,
                primeng_1.AutoCompleteModule,
                primeng_1.RadioButtonModule,
                primeng_1.FieldsetModule,
                primeng_1.FileUploadModule,
                primeng_1.TooltipModule,
                primeng_1.DragDropModule,
                primeng_1.PanelModule,
                primeng_1.InputTextModule,
                primeng_1.LightboxModule,
                primeng_1.InplaceModule
            ],
            declarations: [
                app_component_1.AppComponent,
                TPRHierarchyComponent.AppTprHierarchyComponent,
                TPRNodeTypeComponent.AppNodeTypeComponent,
                TPRDashboardComponent.AppDashboard,
                TPRRegionComponent.AppRegionComponent,
                TPRHolidayComponent.AppHolidayComponent,
                TPRBusinessSegmentsComponent.AppBusinessSegmentsComponent,
                TPRTagsComponent.AppTagsTypeComponent,
                TPRDividendPartnersComponent.AppDividendPartnersComponent,
                TPRAppReportsViewComponent.AppReportsViewComponent,
                TPRAppDataSourcesComponent.AppDataSourcesComponent,
                TPRAppPageNotFoundComponent.AppPageNotFoundComponent,
                AppTprHierarchyEditNodeComponent.AppTprHierarchyEditNodeComponent,
                AppTprHierarchyEnterValueComponent.AppTprHierarchyEnterValueComponent,
                TPRAppJobsComponent.AppJobsComponent,
                DialogComponent.DialogComponent,
                SpinnerComponent.SpinnerComponent,
                TPRAppFileUploadComponent.AppFileUploadComponent,
                AppErrorComponent.AppErrorComponent,
                TPRAppProfitAlertGroupComponent.AppProfitAlertGroupComponent,
                AppTprHierarchyAddChildComponent.AppTprHierarchyAddChildComponent
            ],
            providers: [
                TreeviewService.TPRHierarchyservice,
                NodetypeService.TPRNodeTypeService,
                app_dashboardData_service_1.DashboardDataService,
                regionService.RegionsService,
                TagService.TPRTagsService,
                DividendPartnersService.TPRDividendPartnersService,
                BusinessSegmentsService.TPRBusinessSegmentsService,
                HolidayService.TPRHolidayService,
                ServiceHelper.ServiceHelper,
                ProfitAlertGroupService.TPRProfitAlertGroupsService,
                CommonService.TPRCommonService,
                primeng_1.ConfirmationService,
                app_can_deactivate_guard_service_1.CanDeactivateGuard,
                app_can_activate_guard_service_1.CanActivateGuard,
                { provide: router_1.RouteReuseStrategy, useClass: app_customRoute_1.CustomReuseStrategy },
                TPRViewService.ViewsService,
                TPRDataSourcesService.DataSourcesService,
                TPRJobService.JobService,
                TPRFileUploadService.FileUploadService,
                TPRServersService.ServerService,
                WorkDayService.WorkDayService
            ],
            bootstrap: [app_component_1.AppComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map