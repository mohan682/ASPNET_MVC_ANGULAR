//importing angular modules
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { RouterModule } from '@angular/router'
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import { RouteReuseStrategy } from '@angular/router';

// importing the services
import { TPRNodeTypeService } from "./service/app.TPRNodeTypeService";
import { RegionsService } from "./service/app.regionService";
import { TPRHierarchyservice } from "./service/app.TPRHierarchyservice";
import { TPRTagsService } from "./service/app.TPRTagsService";
import { TPRDividendPartnersService } from "./service/app.TPRDividendPartnersService";
import { TPRBusinessSegmentsService } from "./service/app.TPRBusinessSegmentsService";
import { TPRHolidayService } from "./service/app.TPRHolidayService";
import { TPRCommonService } from "./service/app.TPRCommonService";
import { CalculateService } from "./service/app.calculate.service";
import { DashboardDataService } from './service/app.dashboardData.service';
import { TPRProfitAlertGroupsService } from "./service/app.TPRProfitAlertGroupsService";
import { ServiceHelper } from "./service/app.serviceHelper";
import { ViewsService } from "./service/app.reportsView.service";
import { DataSourcesService } from "./service/app.dataSources.service";
import { JobService } from "./service/app.jobs.service";
import { FileUploadService } from "./service/app.fileUpload.service";
import { ServerService } from "./service/app.server.service";
import { WorkDayService } from "./service/app.workDayService";

import { CustomReuseStrategy } from './service/app.customRoute';

// Guards
import { CanDeactivateGuard } from './service/app.can-deactivate-guard.service';
import { CanActivateGuard } from './service/app.can-activate-guard.service';

// importing modules from primeng
import {
    DataTableModule,
    AccordionModule,
    CalendarModule,
    CarouselModule,
    GrowlModule,
    ButtonModule,
    DataGridModule,
    PanelMenuModule,
    DialogModule,
    MenuModule,
    TreeModule,
    ContextMenuModule,
    SharedModule,
    DropdownModule,
    CheckboxModule,
    ConfirmDialogModule,
    ConfirmationService,
    AutoCompleteModule,
    RadioButtonModule,
    FieldsetModule,
    FileUploadModule,
    TooltipModule,
    DragDropModule,
    PanelModule,
    InputTextModule,
    LightboxModule,
    InplaceModule
} from 'primeng/primeng';


// importing the components
import { AppComponent } from "../app/app.component";
import { AppNodeTypeComponent } from "./components/nodeTypes/app.nodetypes.component";
import { AppDashboard } from "./components/dashboard/app.dashboard.component";
import { AppRegionComponent } from "./components/regions/app.regions.component";
import { AppHolidayComponent } from "./components/holiday/app.holiday.component";
import { AppBusinessSegmentsComponent } from "./components/BusinessSegments/app.businessSegments.component";
import { AppTprHierarchyComponent } from "./components/treeView/app.treeView.component";
import { AppTprHierarchyEditNodeComponent } from "./components/treeView/app.treeViewEditNode.component";
import { AppTprHierarchyAddChildComponent } from "./components/treeView/app.treeViewAddChild.component";
import { AppTprHierarchyEnterValueComponent } from "./components/treeView/app.treeViewEnterValue.component"
import { AppTagsTypeComponent } from "./components/Tags/app.tags.component";
import { AppDividendPartnersComponent } from "./components/DividendPartners/app.dividendPartners.component";
import { AppReportsViewComponent } from "./components/reportsView/app.reportsView.component";
import { AppDataSourcesComponent } from "./components/dataSources/app.dataSources.component";
import { AppJobsComponent } from "./components/feeds/app.jobs.component";
import { AppFileUploadComponent } from "./components/feeds/app.fileUpload.component";
import { AppPageNotFoundComponent } from "./app.PageNotFound.component";
import { DialogComponent } from "./components/common/app.dialogComponent";
import { SpinnerComponent } from "./components/common/app.spinnerComponent";
import { AppProfitAlertGroupComponent } from "./components/ProfitAlertGroup/app.profitAlertGroup.component";
import { AppErrorComponent } from "./components/error/app.error.component";
import { AppFlatViewComponent } from "./components/flatView/app.flatView.component";

//importing various other application javascript modules
import { routes } from '../app/app-routing.module';

@NgModule({
    imports: [
        CalendarModule,
        BrowserModule,
        FormsModule,
        HttpModule,
        JsonpModule,
        CarouselModule,
        GrowlModule,
        ButtonModule,
        MenuModule,
        ContextMenuModule,
        AccordionModule,
        SharedModule,
        routes,
        PanelMenuModule,
        DataTableModule,
        TreeModule,
        DropdownModule,
        DialogModule,
        ConfirmDialogModule,
        CheckboxModule,
        AutoCompleteModule,
        RadioButtonModule,
        FieldsetModule,
        FileUploadModule,
        TooltipModule,
        DragDropModule,
        PanelModule,
        InputTextModule,
        LightboxModule,
        InplaceModule
    ],
    declarations: [
        AppComponent,
        AppTprHierarchyComponent,
        AppNodeTypeComponent,
        AppDashboard,
        AppRegionComponent,
        AppHolidayComponent,
        AppBusinessSegmentsComponent,
        AppTagsTypeComponent,
        AppDividendPartnersComponent,
        AppReportsViewComponent,
        AppDataSourcesComponent,
        AppPageNotFoundComponent,
        AppTprHierarchyEditNodeComponent,
        AppTprHierarchyEnterValueComponent,
        AppJobsComponent,
        DialogComponent,
        SpinnerComponent,
        AppFileUploadComponent,
        AppErrorComponent,
        AppProfitAlertGroupComponent,
        AppTprHierarchyAddChildComponent,
        AppFlatViewComponent
    ],
    providers: [
        TPRHierarchyservice,
        TPRNodeTypeService,
        DashboardDataService,
        RegionsService,
        TPRTagsService,
        TPRDividendPartnersService,
        TPRBusinessSegmentsService,
        TPRHolidayService,
        ServiceHelper,
        TPRProfitAlertGroupsService,
        TPRCommonService,
        ConfirmationService,
        CanDeactivateGuard,
        CanActivateGuard,
        { provide: RouteReuseStrategy, useClass: CustomReuseStrategy },
        ViewsService,
        DataSourcesService,
        JobService,
        FileUploadService,
        ServerService,
        WorkDayService
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }

