"use strict";
var router_1 = require('@angular/router');
var app_treeView_component_1 = require('./components/treeView/app.treeView.component');
var app_treeViewEditNode_component_1 = require('./components/treeView/app.treeViewEditNode.component');
var app_treeViewAddChild_component_1 = require('./components/treeView/app.treeViewAddChild.component');
var app_treeViewEnterValue_component_1 = require('./components/treeView/app.treeViewEnterValue.component');
var app_nodetypes_component_1 = require('./components/nodeTypes/app.nodetypes.component');
var app_dashboard_component_1 = require('./components/dashboard/app.dashboard.component');
var app_regions_component_1 = require('./components/regions/app.regions.component');
var app_holiday_component_1 = require('./components/holiday/app.holiday.component');
var app_businessSegments_component_1 = require('./components/BusinessSegments/app.businessSegments.component');
var app_tags_component_1 = require('./components/Tags/app.tags.component');
var app_dividendPartners_component_1 = require('./components/DividendPartners/app.dividendPartners.component');
var app_reportsView_component_1 = require('./components/reportsView/app.reportsView.component');
var app_dataSources_component_1 = require('./components/dataSources/app.dataSources.component');
var app_PageNotFound_component_1 = require('./app.PageNotFound.component');
var app_jobs_component_1 = require('./components/feeds/app.jobs.component');
var app_fileUpload_component_1 = require("./components/feeds/app.fileUpload.component");
var app_can_deactivate_guard_service_1 = require('./service/app.can-deactivate-guard.service');
var app_can_activate_guard_service_1 = require('./service/app.can-activate-guard.service');
var app_profitAlertGroup_component_1 = require("./components/ProfitAlertGroup/app.profitAlertGroup.component");
var app_error_component_1 = require("./components/error/app.error.component");
//import { AppFlatViewComponent } from './components/flatView/app.flatView.component';
// route configuration order matters as the design is such that the first-match wins strtegy is used to match the routes.
exports.router = [
    { path: 'error', component: app_error_component_1.AppErrorComponent },
    {
        path: 'hierarchy',
        component: app_treeView_component_1.AppTprHierarchyComponent,
        canActivate: [app_can_activate_guard_service_1.CanActivateGuard],
        children: [
            {
                path: 'editNode/:nodeId', component: app_treeViewEditNode_component_1.AppTprHierarchyEditNodeComponent
            },
            {
                path: 'enterValue/:nodeId', component: app_treeViewEnterValue_component_1.AppTprHierarchyEnterValueComponent
            },
            {
                path: 'addChild/:nodeId', component: app_treeViewAddChild_component_1.AppTprHierarchyAddChildComponent
            }
        ]
    },
    { path: 'nodeTypes', component: app_nodetypes_component_1.AppNodeTypeComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'dashboard', component: app_dashboard_component_1.AppDashboard, canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'region', component: app_regions_component_1.AppRegionComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'holidays', component: app_holiday_component_1.AppHolidayComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'businessSegments', component: app_businessSegments_component_1.AppBusinessSegmentsComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'tags', component: app_tags_component_1.AppTagsTypeComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'dividendPartners', component: app_dividendPartners_component_1.AppDividendPartnersComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'reportsView', component: app_reportsView_component_1.AppReportsViewComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'dataSources', component: app_dataSources_component_1.AppDataSourcesComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'jobs', component: app_jobs_component_1.AppJobsComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'fileUpload', component: app_fileUpload_component_1.AppFileUploadComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: 'profitAlert', component: app_profitAlertGroup_component_1.AppProfitAlertGroupComponent, canDeactivate: [app_can_deactivate_guard_service_1.CanDeactivateGuard], canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: '', redirectTo: '/dashboard', pathMatch: 'full', canActivate: [app_can_activate_guard_service_1.CanActivateGuard] },
    { path: '**', component: app_PageNotFound_component_1.AppPageNotFoundComponent }
];
exports.routes = router_1.RouterModule.forRoot(exports.router, { useHash: true });
//# sourceMappingURL=app-routing.module.js.map