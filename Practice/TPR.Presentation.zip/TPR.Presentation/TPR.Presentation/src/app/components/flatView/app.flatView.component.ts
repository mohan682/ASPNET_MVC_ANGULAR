﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-app',
    templateUrl: "app.flatView.component.html"
})
export class AppFlatViewComponent  {
    message: string = "";
    ngOnInit() {
        this.message = "Work in progress";
    }
}
