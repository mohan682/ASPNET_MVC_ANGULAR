"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_fileUpload_service_1 = require('../../service/app.fileUpload.service');
var FileUploadStatusEnum;
(function (FileUploadStatusEnum) {
    FileUploadStatusEnum[FileUploadStatusEnum["None"] = 0] = "None";
    FileUploadStatusEnum[FileUploadStatusEnum["Loaded"] = 1] = "Loaded";
    FileUploadStatusEnum[FileUploadStatusEnum["Reading"] = 2] = "Reading";
    FileUploadStatusEnum[FileUploadStatusEnum["Processing"] = 3] = "Processing";
    FileUploadStatusEnum[FileUploadStatusEnum["Complete"] = 4] = "Complete";
    FileUploadStatusEnum[FileUploadStatusEnum["Errors"] = 5] = "Errors";
})(FileUploadStatusEnum || (FileUploadStatusEnum = {}));
var AppFileUploadComponent = (function () {
    function AppFileUploadComponent(fileUploadService, confirmationService) {
        this.fileUploadService = fileUploadService;
        this.confirmationService = confirmationService;
        this.blnShowErrorModal = false;
        this.arrErrorDetails = [];
        this.arrCompleteErrorDetails = [];
        this.uploadedFiles = [];
        this.postURL = "";
        this.blnDisableUpload = true;
        this.selectedFileType = "";
        this.fileTypes = [];
        this.blnValidFileSelected = false;
        this.blnShowDialog = false;
        this.invalidFileTypeMessage = "";
    }
    AppFileUploadComponent.prototype.ngOnInit = function () {
        this.loadData();
        this.fileTypes.push({ label: "PnL", value: "PnL" });
        this.fileTypes.push({ label: "MVar", value: "MVar" });
        this.fileTypes.push({ label: "WorkingCapital", value: "WorkingCapital" });
        this.fileTypes.push({ label: "MVarLimit", value: "MVarLimit" });
        this.fileTypes.push({ label: "MVarTemporaryLimit", value: "MVarTemporaryLimit" });
        this.fileTypes.push({ label: "PnlPPA", value: "PnlPPA" });
        this.fileTypes.push({ label: "DividendPPA", value: "DividendPPA" });
        this.fileTypes.push({ label: "RegionAllocation", value: "RegionAllocation" });
        this.selectedFileType = this.fileTypes[0].value;
    };
    AppFileUploadComponent.prototype.loadData = function () {
        var _this = this;
        this.fileUploadService.getFileUploadDetails()
            .subscribe(function (data) { return _this.setFileUploadData(data); });
    };
    AppFileUploadComponent.prototype.setFileUploadData = function (data) {
        this.filesUploaded = data.Result.StagingSources.$values;
        //console.log("filesUploaded ->", this.filesUploaded);
        this.filesUploaded.forEach(function (file) {
            file.Status = FileUploadStatusEnum[file.Status];
        });
    };
    AppFileUploadComponent.prototype.canDeactivate = function () {
        return true;
    };
    AppFileUploadComponent.prototype.onStatusClick = function (fileUploadedDetail) {
        var _this = this;
        //console.log(data);
        this.arrErrorDetails = [];
        this.fileUploadService.getErrorDetails(fileUploadedDetail.Id)
            .subscribe(function (data) {
            _this.getErrorDetails(data);
            _this.blnShowErrorModal = fileUploadedDetail.Status == "Errors" ? true : false;
        });
    };
    AppFileUploadComponent.prototype.getErrorDetails = function (data) {
        var _this = this;
        this.arrCompleteErrorDetails = [];
        //debugger;
        this.arrCompleteErrorDetails = data.Result.Errors.$values;
        this.arrCompleteErrorDetails.forEach(function (error) { return _this.arrErrorDetails.push({ ErrorDescription: error.ErrorMessage }); });
    };
    AppFileUploadComponent.prototype.fileChange = function (event) {
        //debugger;
        var eventObj = event;
        var target = eventObj.target;
        var files = target.files;
        var selectedFile = files[0];
        var selectedFileName = selectedFile.name;
        this.selectedFileUploadName = selectedFileName;
        var extension = selectedFileName.split(".")[1];
        this.checkFileValidity(selectedFileName, extension);
        if (!this.blnValidFileSelected) {
            // let message: string = "Invalid file name!\n\n";
            // message = message.concat("Expected file format:\n\n");
            // message = message.concat("PnL:                 PnL<file_name>.csv\n");
            // message = message.concat("MVar:                MVar<file_name>.csv\n");
            // message = message.concat("Working Capital:     WorkingCapital<file_name>.csv\n");
            // message = message.concat("MVarLimit:           MVarLimit<file_name>.csv\n");
            // message = message.concat("MVarTemporaryLimit:  MVarTemporaryLimit<file_name>.csv\n");
            // message = message.concat("PnL PPA:             PnlPPA<file_name>.csv\n");
            // message = message.concat("Dividend PPA:        DividendPPA<file_name>.csv\n");
            //alert(message);
            // this.invalidFileTypeMessage = message;
            this.blnShowDialog = true;
            this.reset();
        }
        else {
            if (files.length > 0) {
                var uploadedFile = files[0];
                if (uploadedFile) {
                    this.documentFileType = 0;
                    var reader = new FileReader();
                    reader.onload = this._handleReaderLoadedArray.bind(this);
                    reader.readAsArrayBuffer(uploadedFile);
                }
            }
            this.blnDisableUpload = false;
        }
    };
    // private _handleReaderLoaded(readerEvt: any) {
    //     debugger;
    //     var binaryString = readerEvt.target.result;
    //     this.fileData = btoa(binaryString);  // Converting binary string data. 
    //     var arrayBuffer = readerEvt.target.result;
    //     var base64ConvertedString = btoa(
    //         new Uint8Array(arrayBuffer)
    //             .reduce((data, byte) => data + String.fromCharCode(byte), '')
    //     );
    //     console.log(base64ConvertedString);
    // }
    AppFileUploadComponent.prototype._handleReaderLoadedArray = function (readerEvt) {
        var arrayBuffer = readerEvt.target.result;
        var base64ConvertedString = btoa(new Uint8Array(arrayBuffer)
            .reduce(function (data, byte) { return data + String.fromCharCode(byte); }, ''));
        this.fileData = base64ConvertedString;
        //console.log(base64ConvertedString);
    };
    AppFileUploadComponent.prototype.checkFileValidity = function (selectedFileName, extn) {
        //debugger;
        switch (this.selectedFileType) {
            case "PnL":
                selectedFileName.startsWith("PnL") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVar":
                selectedFileName.startsWith("MVar") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "WorkingCapital":
                selectedFileName.startsWith("WorkingCapital") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVarLimit":
                selectedFileName.startsWith("MVarLimit") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "MVarTemporaryLimit":
                selectedFileName.startsWith("MVarTemporaryLimit") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "PnlPPA":
                selectedFileName.startsWith("PnlPPA") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "DividendPPA":
                selectedFileName.startsWith("DividendPPA") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            case "RegionAllocation":
                selectedFileName.startsWith("RegionAllocation") && selectedFileName.endsWith(".csv") && extn == "csv" ? this.blnValidFileSelected = true : this.blnValidFileSelected = false;
                break;
            default:
                this.blnValidFileSelected = false;
                break;
        }
    };
    AppFileUploadComponent.prototype.reset = function () {
        //console.log(this.myInputVariable.nativeElement.files);
        this.myInputVariable.nativeElement.value = "";
        //console.log(this.myInputVariable.nativeElement.files);
    };
    AppFileUploadComponent.prototype.submitFile = function (event) {
        //debugger;
        //console.log(event);
        var _this = this;
        var clsFileUploadModelObj = new clsFileUploadModel();
        clsFileUploadModelObj.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Loading.LoadFileRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        clsFileUploadModelObj.FileName = this.selectedFileUploadName;
        clsFileUploadModelObj.FileType = this.documentFileType;
        var clsFileUploadModel_FileBytesObj = new clsFileUploadModel_FileBytes();
        clsFileUploadModel_FileBytesObj.$type = "System.Byte[], mscorlib";
        clsFileUploadModel_FileBytesObj.$value = this.fileData;
        clsFileUploadModelObj.FileBytes = clsFileUploadModel_FileBytesObj;
        //console.log("obj in component ->", clsFileUploadModelObj);
        this.fileUploadService.uploadFile(clsFileUploadModelObj)
            .subscribe(function (response) {
            //debugger;
            //console.log(response);
            if (response.Error) {
                alert(response.Error);
            }
            else {
                _this.loadData();
                _this.reset();
            }
        }, function (error) {
            //debugger;
            console.log(error);
        });
    };
    AppFileUploadComponent.prototype.onFileTypeChange = function (strFileType) {
        //console.log(strFileType);
        this.selectedFileType = strFileType;
    };
    __decorate([
        core_1.ViewChild('myInputFile'), 
        __metadata('design:type', Object)
    ], AppFileUploadComponent.prototype, "myInputVariable", void 0);
    AppFileUploadComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/feeds/app.fileUpload.component.html'
        }), 
        __metadata('design:paramtypes', [app_fileUpload_service_1.FileUploadService, primeng_1.ConfirmationService])
    ], AppFileUploadComponent);
    return AppFileUploadComponent;
}());
exports.AppFileUploadComponent = AppFileUploadComponent;
var clsFileUploadModel = (function () {
    function clsFileUploadModel($type, FileType, FileBytes, FileName) {
        if ($type === void 0) { $type = null; }
        if (FileType === void 0) { FileType = 0; }
        if (FileBytes === void 0) { FileBytes = null; }
        if (FileName === void 0) { FileName = null; }
        this.$type = $type;
        this.FileType = FileType;
        this.FileBytes = FileBytes;
        this.FileName = FileName;
    }
    return clsFileUploadModel;
}());
exports.clsFileUploadModel = clsFileUploadModel;
var clsFileUploadModel_FileBytes = (function () {
    function clsFileUploadModel_FileBytes($type, $value) {
        if ($type === void 0) { $type = null; }
        if ($value === void 0) { $value = null; }
        this.$type = $type;
        this.$value = $value;
    }
    return clsFileUploadModel_FileBytes;
}());
exports.clsFileUploadModel_FileBytes = clsFileUploadModel_FileBytes;
//# sourceMappingURL=app.fileUpload.component.js.map