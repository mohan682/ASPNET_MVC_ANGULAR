"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_jobs_service_1 = require('../../service/app.jobs.service');
var JobStatusEnum;
(function (JobStatusEnum) {
    JobStatusEnum[JobStatusEnum["None"] = 0] = "None";
    JobStatusEnum[JobStatusEnum["Running"] = 1] = "Running";
    JobStatusEnum[JobStatusEnum["Complete"] = 2] = "Complete";
    JobStatusEnum[JobStatusEnum["Error"] = 3] = "Error";
    JobStatusEnum[JobStatusEnum["NoDataLoaded"] = 4] = "NoDataLoaded";
    JobStatusEnum[JobStatusEnum["UnknownJob"] = 5] = "UnknownJob";
    JobStatusEnum[JobStatusEnum["AlreadyRunning"] = 6] = "AlreadyRunning";
    JobStatusEnum[JobStatusEnum["AlreadyComplete"] = 7] = "AlreadyComplete";
    JobStatusEnum[JobStatusEnum["ScheduledTimeNotReached"] = 8] = "ScheduledTimeNotReached";
})(JobStatusEnum || (JobStatusEnum = {}));
var AppJobsComponent = (function () {
    function AppJobsComponent(jobService, confirmationService) {
        this.jobService = jobService;
        this.confirmationService = confirmationService;
        this.JobStatusEnum = JobStatusEnum;
        this.blnSavedOrDeleted = false;
        this.clsMessage = {};
        this.Message = "";
    }
    AppJobsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.jobService.getJobsObservable()
            .subscribe(function (data) { return _this.setJobsData(data); });
    };
    AppJobsComponent.prototype.setJobsData = function (data) {
        this.jobs = data.Result.Jobs.$values;
        console.log("Number of Jobs ->", this.jobs.length);
        for (var i in this.jobs) {
            console.log("Status ->", this.jobs[i].Status);
            this.jobs[i].Status = JobStatusEnum[this.jobs[i].Status];
        }
        console.log("Jobs ->", this.jobs);
    };
    AppJobsComponent.prototype.canDeactivate = function () {
        return true;
    };
    AppJobsComponent.prototype.refreshJobs = function (jobToBeRefreshed) {
        var _this = this;
        console.log(jobToBeRefreshed);
        //console.log(JobStatusEnum[jobToBeRefreshed.Status]);
        var objJobValue = new JobValue();
        objJobValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Jobs.JobDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        objJobValue.Active = jobToBeRefreshed.Active;
        objJobValue.Hour = jobToBeRefreshed.Hour;
        objJobValue.JobOrder = jobToBeRefreshed.JobOrder;
        objJobValue.LastExecuted = jobToBeRefreshed.LastExecuted;
        objJobValue.Minute = jobToBeRefreshed.Minute;
        objJobValue.Name = jobToBeRefreshed.Name;
        objJobValue.ScheduleType = jobToBeRefreshed.ScheduleType;
        objJobValue.Status = JobStatusEnum[jobToBeRefreshed.Status];
        //console.log(objJobValue);
        debugger;
        this.jobService.updateJobRefresh(jobToBeRefreshed)
            .subscribe(function (response) {
            debugger;
            console.log(response);
            var responseJob = response.Result.Job;
            var selectedJob = responseJob ? _this.jobs.find(function (item) { return item.Name == responseJob.Name; }) : null;
            if (selectedJob) {
                selectedJob.Status = JobStatusEnum[responseJob.Status];
                selectedJob.LastExecuted = responseJob.LastExecuted;
                var index = _this.jobs.indexOf(selectedJob);
                _this.jobs[index] = selectedJob;
                _this.blnSavedOrDeleted = true;
                _this.clsMessage = {};
                _this.clsMessage = {
                    successMessage: true,
                    failureMessage: false
                };
                _this.Message = "Job refreshed with status - " + selectedJob.Status;
            }
        }, function (error) {
            debugger;
            console.log(error);
        });
    };
    AppJobsComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/feeds/app.jobs.component.html'
        }), 
        __metadata('design:paramtypes', [app_jobs_service_1.JobService, primeng_1.ConfirmationService])
    ], AppJobsComponent);
    return AppJobsComponent;
}());
exports.AppJobsComponent = AppJobsComponent;
var JobValue = (function () {
    function JobValue($type, Name, LastExecuted, Active, Status, Hour, Minute, ScheduleType, JobOrder) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (LastExecuted === void 0) { LastExecuted = null; }
        if (Active === void 0) { Active = false; }
        if (Status === void 0) { Status = null; }
        if (Hour === void 0) { Hour = 0; }
        if (Minute === void 0) { Minute = 0; }
        if (ScheduleType === void 0) { ScheduleType = null; }
        if (JobOrder === void 0) { JobOrder = null; }
        this.$type = $type;
        this.Name = Name;
        this.LastExecuted = LastExecuted;
        this.Active = Active;
        this.Status = Status;
        this.Hour = Hour;
        this.Minute = Minute;
        this.ScheduleType = ScheduleType;
        this.JobOrder = JobOrder;
    }
    return JobValue;
}());
//# sourceMappingURL=app.jobs.component.js.map