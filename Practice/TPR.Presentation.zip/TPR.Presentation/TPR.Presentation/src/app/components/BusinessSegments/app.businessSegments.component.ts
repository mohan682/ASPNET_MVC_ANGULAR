﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { DataTable } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { TPRBusinessSegmentsService } from '../../service/app.TPRBusinessSegmentsService';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { ServiceHelper } from '../../service/app.serviceHelper';

import IBusinessSegmentsValue = BusinessSegmentNameSpace.IBusinessSegmentValue;

@Component({
    selector: 'my-app',
    templateUrl: 'app.businessSegments.component.html'
})
export class AppBusinessSegmentsComponent implements OnInit {
    public isRequesting: boolean;
    businessSegmentTypes: IBusinessSegmentsValue[];
    newBusinessSegmentType: boolean;
    displayDialog: boolean;
    businessSegmentsType: IBusinessSegmentsValue = new BusinessSegmentTypesValue();
    cols: any[];
    selectedBusinessSegmentType: IBusinessSegmentsValue;
    currentBusinessSegmentType: IBusinessSegmentsValue;
    msgs: Message[] = [];
    blnSavedOrDeleted: boolean = false;
    successMessage: boolean = false;
    failureMessage: boolean = false;
    Message: string = "";
    clsMessage = {};
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true;
    blnPushDataToDatabase = false;
    strErrorMessage: string = "";
    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    disableSave: boolean = false;
    canEdit: boolean = false;
    @ViewChild("businessSegmentsDataTable") businessSegmentsDataTable: DataTable;

    constructor(
        private tPRBusinessSegmentsService: TPRBusinessSegmentsService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);
        //console.log("Is Save disabled ->",localStorage.getItem("disableSave"));

        this.loadData();

        this.cols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
    }

    loadData() {
        this.isRequesting = true;
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.tPRBusinessSegmentsService.getBusinessSegmentsObservable()
            .subscribe(data => this.setBusinessSegmentTypeData(data));
    }

    private setBusinessSegmentTypeData(data: any): void {
        this.businessSegmentTypes = data.Result.BusinessSegments.$values;

        this.businessSegmentTypes.forEach(businessSegment => {
            businessSegment.Updated != null ? businessSegment.Updated = this.tprCommonService.getFormattedSystemDate(new Date(businessSegment.Updated)) : null;
        });

        this.stopRefreshing();
    }

    private stopRefreshing() {
        //console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    showDialogToAdd() {
        this.newBusinessSegmentType = true;
        this.businessSegmentsType = new BusinessSegmentTypesValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    }

    save() {
        //console.log(this.businessSegmentsType);
        if (this.businessSegmentsType.Name == null || this.businessSegmentsType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.strErrorMessage = "Please enter a valid 'Name'.";

            this.clsHighlightInvalidData = {};

            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };

            this.businessSegmentsType.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;

            if (this.newBusinessSegmentType) {
                //this.businessSegmentTypes.push(this.businessSegmentsType);
                let index: number = this.businessSegmentTypes.indexOf(this.businessSegmentTypes.find(segment => segment.Name.toLowerCase().trim() == this.businessSegmentsType.Name.toLowerCase().trim()));
                if (index == -1) {
                    this.businessSegmentTypes.push(this.businessSegmentsType);
                }
                else {
                    this.strErrorMessage = "Business Segment Name should be unique."
                    this.clsHighlightInvalidData = {};

                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };

                    //this.businessSegmentsType.Name = "";
                    return false;
                }
            }
            else
                this.businessSegmentTypes[this.findSelectedBusinessSegmentTypeIndex()] = this.businessSegmentsType;
        }
        this.businessSegmentsType = null;
        this.displayDialog = false;
    }

    saveDataToServer() {
        //debugger;
        this.isRequesting = true;
        let action: string = "save";
        this.blnPushDataToDatabase = true;
        //this.SaveDataToDataBase(action);

        let businessSegmentsArray: string[] = [];

        let emptyBusinessSegment = this.businessSegmentTypes.find(item => item.Name.trim() == "");

        if (emptyBusinessSegment) {
            this.blnShowPopUp = true;
            this.Status = "Error";
            this.ValidationMessage = "Business Segment Name should not be empty.";
        }
        else {
            this.businessSegmentTypes.forEach(segment => businessSegmentsArray.push(segment.Name.toLowerCase().trim()));

            let uniquenessResult: boolean = this.checkIfArrayIsUnique(businessSegmentsArray);

            if (uniquenessResult) {
                this.SaveDataToDataBase(action);
            }
            else {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = "Business Segment Name should be unique.";
            }
        }
    }

    delete(event: IBusinessSegmentsValue) {
        this.currentBusinessSegmentType = event;

        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Business Segment?',
            accept: () => {
                this.businessSegmentTypes.splice(this.findBusinessSegmentTypeIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });
        this.businessSegmentsType = null;
    }

    SaveDataToDataBase(action: string) {
        this.tPRBusinessSegmentsService.updateBusinessSegmentsObservable(this.businessSegmentTypes)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                    this.stopRefreshing();
                }
                else {
                    //this.ShowMessageOnSaveorDeleteData(response, action);
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    //console.log("Action ->",action);
                    if (action == "save") {
                        this.ValidationMessage = "Business Segment Data is saved successfully";
                    }
                    else if (action == "delete") {
                        this.ValidationMessage = "The Selected Business Segment is deleted successfully";
                    }
                    this.loadData();
                    this.blnSavedOrDeleted = true;
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
                this.stopRefreshing();
            });
    }

    onRowSelect(event: any) {
        this.newBusinessSegmentType = false;
        this.businessSegmentsType = this.cloneNodeType(event.data);
    }

    cloneNodeType(c: IBusinessSegmentsValue): IBusinessSegmentsValue {
        let nodeType = new BusinessSegmentTypesValue();
        for (let prop in c) {
            nodeType[prop] = c[prop];
        }
        return nodeType;
    }

    findSelectedBusinessSegmentTypeIndex(): number {
        return this.businessSegmentTypes.indexOf(this.selectedBusinessSegmentType);
    }

    findBusinessSegmentTypeIndexForDelete(): number {
        return this.businessSegmentTypes.indexOf(this.currentBusinessSegmentType);
    }

    checkIfArrayIsUnique(myArray: string[]): boolean {
        return myArray.length === new Set(myArray).size;
    }

    RefreshData(segmentsData: DataTable) {
        this.businessSegmentsDataTable.reset();
        this.loadData();
    }
}

class BusinessSegmentTypesValue implements IBusinessSegmentsValue {
    constructor
        (
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
        ) { }
}