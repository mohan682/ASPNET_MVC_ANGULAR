﻿import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppBusinessSegmentsComponent } from './app.businessSegments.component';
import { TPRBusinessSegmentsService } from '../../service/app.TPRBusinessSegmentsService';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { addMatchers, click } from '../../../testing';

import IBusinessSegmentsValue = BusinessSegmentNameSpace.IBusinessSegmentValue;


describe('AppBusinessSegmentsComponent test cases', () => {
    let de: DebugElement;
    let comp: AppBusinessSegmentsComponent;
    let fixture: ComponentFixture<AppBusinessSegmentsComponent>;
    let businessSegmentService: TPRBusinessSegmentsService;
    let spy: jasmine.Spy;

    //async before each
    beforeEach(async(() => {
        let tprbusinessSegmentServiceStub = {
            getBusinessSegmentsObservable: true,
            updateBusinessSegmentsObservable: true
        };

        TestBed.configureTestingModule({
            declarations: [AppBusinessSegmentsComponent],
            imports: [],
            providers: [TPRBusinessSegmentsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));


    beforeEach(() => {
        fixture = TestBed.createComponent(AppBusinessSegmentsComponent); // creates the fixture of the testing component

        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });

    // test whether the component got successfully initialised
    it('should create component', () => expect(comp).toBeDefined());

    // test for service mockup
    // BusinessSegment service actually injected to the component.
    businessSegmentService = fixture.debugElement.injector.get(TPRBusinessSegmentsService);

    // Create test mockup class
    let businessSegmengtMockUp: BusinessSegmentTypesValueTestMockup = new BusinessSegmentTypesValueTestMockup();
    let businessSegmentTypes: IBusinessSegmentsValue[] = [];

    it('should not call the getBusinessSegmentsObservable method before OnInit', () => {
        // Setup spy on the 'getBusinessSegmentsObservable' method
        spy = spyOn(businessSegmentService, 'getBusinessSegmentsObservable')
            .and.returnValue(Promise.resolve(businessSegmengtMockUp));

        expect(spy.calls.any()).toBe(false, 'getBusinessSegmentsObservable not yet called');
    });

    it('should call the getBusinessSegmentsObservable method after component initialized', () => {
        // Setup spy on the 'getBusinessSegmentsObservable' method
        spy = spyOn(businessSegmentService, 'getBusinessSegmentsObservable')
            .and.returnValue(Promise.resolve(businessSegmengtMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getBusinessSegmentsObservable called');
    });

    it('should raise Add button click event', () => {
        let displayDialog: boolean = true;
        let newBusinessSegmentType: boolean = true;
        let blnValidationResult: boolean = true;

        de = fixture.debugElement.query(By.css('#btnAdd'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newBusinessSegmentType).toBe(newBusinessSegmentType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });

    it('should raise Save button click event', () => {
        let businessSegmentsType: IBusinessSegmentsValue = new BusinessSegmentTypesValueTestMockup('', 'Test', false, false, '', '', '', '', 0); // Creating testmockup object
        comp.businessSegmentsType = businessSegmentsType; // initializing the tagType object with the test mockup object

        de = fixture.debugElement.query(By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.businessSegmentTypes.indexOf(businessSegmentsType)).toBeGreaterThan(-1);
    });

    it('should raise SavetoDatabase button click event', () => {
        let blnPushDataToDatabase: boolean = true;
        let blnSavedOrDeleted: boolean = true;
        let strSavedMessage: string = "Data saved successfully";

        de = fixture.debugElement.query(By.css('#btnSaveDataToServer'));

        // Setup spy on the 'updateBusinessSegmentsObservable' method
        spy = spyOn(businessSegmentService, 'updateBusinessSegmentsObservable')
            .and.returnValue(Promise.resolve(businessSegmengtMockUp));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        fixture.detectChanges();

        expect(spy.calls.any()).toBe(true, 'updateBusinessSegmentsObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});
class BusinessSegmentTypesValueTestMockup implements IBusinessSegmentsValue {
    constructor
        (
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
        ) { }
}