"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_TPRBusinessSegmentsService_1 = require('../../service/app.TPRBusinessSegmentsService');
var AppBusinessSegmentsComponent = (function () {
    function AppBusinessSegmentsComponent(tPRBusinessSegmentsService, confirmationService) {
        this.tPRBusinessSegmentsService = tPRBusinessSegmentsService;
        this.confirmationService = confirmationService;
        this.businessSegmentsType = new BusinessSegmentTypesValue();
        this.msgs = [];
        this.blnSavedOrDeleted = false;
        this.successMessage = false;
        this.failureMessage = false;
        this.Message = "";
        this.clsMessage = {};
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.blnPushDataToDatabase = false;
    }
    AppBusinessSegmentsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.tPRBusinessSegmentsService.getBusinessSegmentsObservable()
            .subscribe(function (data) { return _this.setBusinessSegmentTypeData(data); });
        this.cols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
    };
    AppBusinessSegmentsComponent.prototype.setBusinessSegmentTypeData = function (data) {
        this.businessSegmentTypes = data.Result.BusinessSegments.$values;
    };
    AppBusinessSegmentsComponent.prototype.showDialogToAdd = function () {
        this.newBusinessSegmentType = true;
        this.businessSegmentsType = new BusinessSegmentTypesValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppBusinessSegmentsComponent.prototype.save = function () {
        //console.log(this.businessSegmentsType);
        if (this.businessSegmentsType.Name == null || this.businessSegmentsType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            this.businessSegmentsType.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;
            if (this.newBusinessSegmentType)
                this.businessSegmentTypes.push(this.businessSegmentsType);
            else
                this.businessSegmentTypes[this.findSelectedBusinessSegmentTypeIndex()] = this.businessSegmentsType;
        }
        this.businessSegmentsType = null;
        this.displayDialog = false;
    };
    AppBusinessSegmentsComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = true;
        this.SaveDataToDataBase(action);
    };
    AppBusinessSegmentsComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentBusinessSegmentType = event;
        this.confirmationService.confirm({
            message: 'Are you sure that you want to perform this action?',
            accept: function () {
                _this.businessSegmentTypes.splice(_this.findBusinessSegmentTypeIndexForDelete(), 1);
            }
        });
        this.businessSegmentsType = null;
    };
    AppBusinessSegmentsComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.tPRBusinessSegmentsService.updateBusinessSegmentsObservable(this.businessSegmentTypes)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
    };
    AppBusinessSegmentsComponent.prototype.ShowMessageOnSaveorDeleteData = function (data, action) {
        //console.log(data);
        this.blnSavedOrDeleted = true;
        // applying class to the message
        this.clsMessage = {};
        this.clsMessage = {
            successMessage: true,
            failureMessage: false
        };
        this.msgs = [];
        if (action == "save") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
            this.Message = "Data saved successfully";
        }
        else if (action == "delete") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' });
            this.Message = "Data deleted successfully";
        }
        ;
    };
    AppBusinessSegmentsComponent.prototype.onRowSelect = function (event) {
        this.newBusinessSegmentType = false;
        this.businessSegmentsType = this.cloneNodeType(event.data);
    };
    AppBusinessSegmentsComponent.prototype.cloneNodeType = function (c) {
        var nodeType = new BusinessSegmentTypesValue();
        for (var prop in c) {
            nodeType[prop] = c[prop];
        }
        return nodeType;
    };
    AppBusinessSegmentsComponent.prototype.findSelectedBusinessSegmentTypeIndex = function () {
        return this.businessSegmentTypes.indexOf(this.selectedBusinessSegmentType);
    };
    AppBusinessSegmentsComponent.prototype.findBusinessSegmentTypeIndexForDelete = function () {
        return this.businessSegmentTypes.indexOf(this.currentBusinessSegmentType);
    };
    AppBusinessSegmentsComponent.prototype.canDeactivate = function () {
        //if (!this.blnPushDataToDatabase) {
        //    this.confirmationService.confirm({
        //        message: 'Are you sure that you want to navigate without saving the data?',
        //        accept: () => {
        //            let action: string = "save";
        //            this.SaveDataToDataBase(action);
        //        }
        //    });
        //}
        //return this.blnPushDataToDatabase;
        if (!this.blnPushDataToDatabase) {
            return confirm("Are you sure that you want to navigate without saving the data?");
        }
        return true;
    };
    AppBusinessSegmentsComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/BusinessSegments/app.businessSegments.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService, primeng_1.ConfirmationService])
    ], AppBusinessSegmentsComponent);
    return AppBusinessSegmentsComponent;
}());
exports.AppBusinessSegmentsComponent = AppBusinessSegmentsComponent;
var BusinessSegmentTypesValue = (function () {
    function BusinessSegmentTypesValue($type, Name, IsInUse, Editable, Created, CreatedBy, updated, updatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (updated === void 0) { updated = null; }
        if (updatedBy === void 0) { updatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.updated = updated;
        this.updatedBy = updatedBy;
        this.Id = Id;
    }
    return BusinessSegmentTypesValue;
}());
//# sourceMappingURL=app.businessSegments.component.js.map