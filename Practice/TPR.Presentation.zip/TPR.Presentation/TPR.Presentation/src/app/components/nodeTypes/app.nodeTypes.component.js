"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_TPRNodeTypeService_1 = require('../../service/app.TPRNodeTypeService');
var AppNodeTypeComponent = (function () {
    function AppNodeTypeComponent(tPRNodeTypeService, confirmationService) {
        this.tPRNodeTypeService = tPRNodeTypeService;
        this.confirmationService = confirmationService;
        this.nodeType = new NodeTypesValue();
        this.msgs = [];
        this.blnSavedOrDeleted = false;
        this.successMessage = false;
        this.failureMessage = false;
        this.Message = "";
        this.clsMessage = {};
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.blnPushDataToDatabase = false;
    }
    AppNodeTypeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.tPRNodeTypeService.getNodeTypesObservable()
            .subscribe(function (data) { return _this.setNodeTypeData(data); });
        this.cols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
    };
    AppNodeTypeComponent.prototype.setNodeTypeData = function (data) {
        this.nodeTypes = data.Result.NodeTypes.$values;
    };
    AppNodeTypeComponent.prototype.showDialogToAdd = function () {
        this.newNodeType = true;
        this.nodeType = new NodeTypesValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppNodeTypeComponent.prototype.save = function () {
        //console.log(this.tagType);
        if (this.nodeType.Name == null || this.nodeType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            this.nodeType.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;
            if (this.newNodeType)
                this.nodeTypes.push(this.nodeType);
            else
                this.nodeTypes[this.findSelectedNodeTypeIndex()] = this.nodeType;
        }
        this.nodeType = null;
        this.displayDialog = false;
    };
    AppNodeTypeComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = false;
        this.SaveDataToDataBase(action);
    };
    AppNodeTypeComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentNodeType = event;
        this.confirmationService.confirm({
            message: 'Are you sure that you want to perform this action?',
            accept: function () {
                _this.nodeTypes.splice(_this.findNodeTypeIndexForDelete(), 1);
            }
        });
        this.nodeType = null;
    };
    AppNodeTypeComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.tPRNodeTypeService.updateNodeTypesObservable(this.nodeTypes)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
    };
    AppNodeTypeComponent.prototype.ShowMessageOnSaveorDeleteData = function (data, action) {
        //console.log(data);
        this.blnSavedOrDeleted = true;
        // applying class to the message
        this.clsMessage = {};
        this.clsMessage = {
            successMessage: true,
            failureMessage: false
        };
        this.msgs = [];
        if (action == "save") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
            this.Message = "Data saved successfully";
        }
        else if (action == "delete") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' });
            this.Message = "Data deleted successfully";
        }
        ;
    };
    AppNodeTypeComponent.prototype.onRowSelect = function (event) {
        this.newNodeType = false;
        this.nodeType = this.cloneNodeType(event.data);
    };
    AppNodeTypeComponent.prototype.cloneNodeType = function (c) {
        var nodeType = new NodeTypesValue();
        for (var prop in c) {
            nodeType[prop] = c[prop];
        }
        return nodeType;
    };
    AppNodeTypeComponent.prototype.findSelectedNodeTypeIndex = function () {
        return this.nodeTypes.indexOf(this.selectedNodeType);
    };
    AppNodeTypeComponent.prototype.findNodeTypeIndexForDelete = function () {
        return this.nodeTypes.indexOf(this.currentNodeType);
    };
    AppNodeTypeComponent.prototype.canDeactivate = function () {
        //if (!this.blnPushDataToDatabase) {
        //    this.confirmationService.confirm({
        //        message: 'Are you sure that you want to navigate without saving the data?',
        //        accept: () => {
        //            let action: string = "save";
        //            this.SaveDataToDataBase(action);
        //        }
        //    });
        //}
        //return this.blnPushDataToDatabase;
        if (!this.blnPushDataToDatabase) {
            return confirm("Are you sure that you want to navigate without saving the data?");
        }
        return true;
    };
    AppNodeTypeComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/nodeTypes/app.nodeTypes.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRNodeTypeService_1.TPRNodeTypeService, primeng_1.ConfirmationService])
    ], AppNodeTypeComponent);
    return AppNodeTypeComponent;
}());
exports.AppNodeTypeComponent = AppNodeTypeComponent;
var NodeTypesValue = (function () {
    function NodeTypesValue($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return NodeTypesValue;
}());
//# sourceMappingURL=app.nodetypes.component.js.map