﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { InputText } from 'primeng/primeng';
import { DataTable } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { TPRNodeTypeService } from '../../service/app.TPRNodeTypeService';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { ServiceHelper } from '../../service/app.serviceHelper';

import INodeTypesValue = NodeTypeNamespace.INodeTypesValue;

@Component({
    selector: 'my-app',
    templateUrl: 'app.nodeTypes.component.html'
})
export class AppNodeTypeComponent implements OnInit {

    nodeTypes: INodeTypesValue[];
    newNodeType: boolean;
    displayDialog: boolean;
    nodeType: INodeTypesValue = new NodeTypesValue();
    cols: any[];
    selectedNodeType: INodeTypesValue;
    currentNodeType: INodeTypesValue;
    msgs: Message[] = [];
    blnSavedOrDeleted: boolean = false;
    successMessage: boolean = false;
    failureMessage: boolean = false;
    Message: string = "";
    clsMessage = {};
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true;
    blnPushDataToDatabase = false;
    strErrorMessage: string = "";
    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    isRequesting: boolean = false;
    blnShowDialog: boolean = false;
    disableSave: boolean = false;
    canEdit: boolean = false;

    @ViewChild('nodeTypeDataTable') nodeTypeDataTable: DataTable;

    constructor(
        private tPRNodeTypeService: TPRNodeTypeService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        this.isRequesting = true;
        this.loadData();
        //console.log("Checking local storage...");
        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);

        //console.log("Is Save Disabled ->",this.disableSave);

        this.cols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
    }

    loadData() {
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.tPRNodeTypeService.getNodeTypesObservable()
            .subscribe(data => this.setNodeTypeData(data));
    }

    private setNodeTypeData(data: any): void {
        this.nodeTypes = data.Result.NodeTypes.$values;

        //console.log("nodeTypes->", this.nodeTypes);

        this.nodeTypes = this.nodeTypes.filter(nodeType => nodeType.Editable == true);

        this.nodeTypes.forEach(node => {
            node.Updated != null ? node.Updated = this.tprCommonService.getFormattedSystemDate(new Date(node.Updated)) : null;
        });

        this.stopRefreshing();
    }

    showDialogToAdd() {
        this.newNodeType = true;
        this.nodeType = new NodeTypesValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    }

    save() {
        //console.log(this.tagType);
        if (this.nodeType.Name == null || this.nodeType.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.strErrorMessage = "'Name' should not be empty.";

            this.clsHighlightInvalidData = {};

            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };

            this.nodeType.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;

            if (this.newNodeType) {
                //this.nodeTypes.push(this.nodeType);
                let index: number = this.nodeTypes.indexOf(this.nodeTypes.find(node => node.Name.toLowerCase().trim() == this.nodeType.Name.toLowerCase().trim()));
                if (index == -1) {
                    this.nodeTypes.push(this.nodeType);
                }
                else {
                    this.strErrorMessage = this.nodeType.Name + " already exists. Name should be unique."
                    this.clsHighlightInvalidData = {};

                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };

                    //this.nodeType.Name = "";
                    return false;
                }
            }
            else
                this.nodeTypes[this.findSelectedNodeTypeIndex()] = this.nodeType;
        }
        this.nodeType = null;
        this.displayDialog = false;
    }

    saveDataToServer() {
        let action: string = "save";
        this.blnPushDataToDatabase = false;

        let nodeNamesArray: string[] = [];

        let emptyNodeType = this.nodeTypes.find(item => item.Name.trim() == "");

        if (emptyNodeType) {
            this.blnShowPopUp = true;
            this.Status = "Error";
            this.ValidationMessage = "'Name' should not be empty.";
        }
        else {
            this.nodeTypes.forEach(node => nodeNamesArray.push(node.Name.toLowerCase().trim()));

            let uniquenessResult: boolean = this.checkIfArrayIsUnique(nodeNamesArray);

            if (uniquenessResult) {
                this.SaveDataToDataBase(action);
            }
            else {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = "'Name' should be unique.";
            }
        }
    }

    delete(event: INodeTypesValue) {
        this.currentNodeType = event;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Node Type?',
            accept: () => {
                this.nodeTypes.splice(this.findNodeTypeIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });
        this.nodeType = null;
    }

    SaveDataToDataBase(action: string) {
        this.isRequesting = true;
        this.tPRNodeTypeService.updateNodeTypesObservable(this.nodeTypes)
            .subscribe(
            (response: any) => {
                //console.log("Response ->", response);
                if (response.Error) {
                    this.blnShowDialog = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                    this.stopRefreshing();
                }
                else {
                    //this.ShowMessageOnSaveorDeleteData(response, action);
                    this.blnShowDialog = true;
                    this.Status = "Success";
                    //console.log("Action ->",action);
                    if (action == "save") {
                        this.ValidationMessage = "Node Types Data is saved successfully";
                    }
                    else if (action == "delete") {
                        this.ValidationMessage = "The Selected Node Type is deleted successfully";
                    }
                    this.loadData();
                    this.blnSavedOrDeleted = true;
                }
            },
            (error) => {
                this.blnShowDialog = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
                this.stopRefreshing();
            });
    }

    onRowSelect(event: any) {
        this.newNodeType = false;
        this.nodeType = this.cloneNodeType(event.data);
    }

    cloneNodeType(c: INodeTypesValue): INodeTypesValue {
        let nodeType = new NodeTypesValue();
        for (let prop in c) {
            nodeType[prop] = c[prop];
        }
        return nodeType;
    }

    findSelectedNodeTypeIndex(): number {
        return this.nodeTypes.indexOf(this.selectedNodeType);
    }

    findNodeTypeIndexForDelete(): number {
        return this.nodeTypes.indexOf(this.currentNodeType);
    }

    checkIfArrayIsUnique(myArray: string[]): boolean {
        return myArray.length === new Set(myArray).size;
    }

    refreshData(nodeTypeDataTable: DataTable) {
        this.isRequesting = true;
        this.nodeTypeDataTable.reset();
        this.loadData();
    }

    private stopRefreshing() {
        //console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }
}

class NodeTypesValue implements INodeTypesValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}