"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var app_dashboardData_service_1 = require('../../service/app.dashboardData.service');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var primeng_1 = require('primeng/primeng');
var x2js = require('x2js');
var AppDashboard = (function () {
    function AppDashboard(dashboardDataService, tPRcommonService, confirmationService) {
        this.dashboardDataService = dashboardDataService;
        this.tPRcommonService = tPRcommonService;
        this.confirmationService = confirmationService;
        this.msgs = [];
        this.displayMessage = false;
        this.blnShowPopUp = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.disabled = false;
        this.reportingdatestatus = "";
        this.comments = [];
        this.commentsjson = [];
        this.blnShowErrorModal = false;
        this.arrErrorDetails = [];
        this.blnShowChangesModal = false;
        this.arrChangesDetails = [];
    }
    AppDashboard.prototype.ngOnInit = function () {
        var _this = this;
        this.dashboardItems1 = [
            { label: 'Calculate PnL', icon: 'fa-calculator', command: function (event) { return _this.calculatePnL(); }, disabled: false },
            { label: 'Publish', icon: 'fa-sign-out', command: null, disabled: false },
            { label: 'Roll Business Date', icon: 'fa-calendar-plus-o', disabled: false },
            { label: 'Lock Business Date', icon: 'fa-lock', disabled: false },
            { label: 'Reset Calculation Flag', icon: 'fa-flag', command: function (event) { return _this.resetCalcFlag(); }, disabled: false }
        ];
        this.cols = [
            { field: 'Source', header: 'Source' },
            { field: 'FileType', header: 'File Type' },
            { field: 'State', header: 'Status' },
            { field: 'Name', header: 'Activity log' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
        this.tPRcommonService.getSystemDateObservable().subscribe(function (data2) { return _this.setBusinessDate(data2); });
        this.dashboardDataService.getLastCalculatedObservable().subscribe(function (files) { return _this.setLastCalculatedData(files); });
        this.dashboardDataService.getPublishStatusObservable().subscribe(function (data3) { return _this.setPublishStatus(data3); });
        this.dashboardDataService.getLockedStatusObservable().subscribe(function (data) { return _this.setLockedStatus(data); });
    };
    AppDashboard.prototype.setLockedStatus = function (data) {
        var _this = this;
        this.lockstatus = data.Result.NumericValue;
        console.log("set locked status", this.lockstatus);
        if (this.lockstatus == 1) {
            this.reportingdatestatus = "Locked";
            this.dashboardItems1[3].label = "Unlock Business Date";
            this.dashboardItems1[3].command = function (event) { return _this.lockOrUnlock(); };
        }
        else if (this.lockstatus == 0) {
            this.reportingdatestatus = "Unlocked";
            this.dashboardItems1[3].label = "Lock Business Date";
            this.dashboardItems1[3].command = function (event) { return _this.lockOrUnlock(); };
        }
    };
    AppDashboard.prototype.setBusinessDate = function (data) {
        var _this = this;
        var myDate = new Date(data.Result.DateValue);
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var businessDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        var output = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        this.date4 = output.toString();
        var outputs = myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        this.date4s = outputs.toString();
        console.log("Business date as being passed to service from inside method is " + this.date4);
        this.dashboardDataService.getDashboardDataObservable(this.date4).subscribe(function (response) {
            if (response.Error) {
                _this.confirmationService.confirm({
                    header: 'Error',
                    message: response.Error.toString(),
                    rejectVisible: false
                });
                console.log(response.Error);
            }
            else {
                _this.setDashboardData(response);
            }
        });
        this.date3 = myDate;
        this.nextReportingDate = new Date();
        this.nextReportingDate.setDate(this.date3.getDate() + 1);
        var output2 = this.nextReportingDate.getDate() + ' ' + m_names[this.nextReportingDate.getMonth()] + ' ' + this.nextReportingDate.getFullYear();
        this.date5 = output2.toString();
    };
    AppDashboard.prototype.setPublishStatus = function (data) {
        var _this = this;
        this.status = data.Result.NumericValue;
        console.log("publish status", this.status);
        if (this.status == 0) {
            this.publishstatus = "Unpublished";
            this.publishButtonText = "Publish";
            this.dashboardItems1[0].label = "Calculate PnL";
            this.dashboardItems1[0].command = function (event) { return _this.calculatePnL(); };
        }
        else {
            this.publishstatus = "Published";
            this.publishButtonText = "UnPublish";
            this.dashboardItems1[0].label = "Calculate PnL for next reporting day";
            this.dashboardItems1[0].command = function (event) { return _this.calculateNextDayPnL(); };
        }
        localStorage.setItem("PublishStatus", this.publishstatus);
        this.dashboardItems1[1].label = this.publishButtonText;
        this.dashboardItems1[1].command = function (event) { return _this.publishOrUnpublishData(); };
        this.dashboardItems1[1].icon = 'fa-sign-out';
    };
    AppDashboard.prototype.setPublishData = function () {
        var _this = this;
        this.dashboardDataService.getPublishStatusObservable().subscribe(function (data3) { return _this.setPublishStatus(data3); });
    };
    AppDashboard.prototype.setLockedData = function () {
        var _this = this;
        this.dashboardDataService.getLockedStatusObservable().subscribe(function (data3) { return _this.setLockedStatus(data3); });
    };
    AppDashboard.prototype.lockOrUnlock = function () {
        var _this = this;
        this.displayMessage = true;
        console.log("lock status", this.lockstatus);
        if (this.lockstatus == 1) {
            this.confirmationService.confirm({
                header: 'Save changes',
                message: 'The system reporting date - ' + this.date4s + ' - will be unlocked. Would you like to proceed?',
                accept: function () {
                    _this.dashboardDataService.getUnLockedObservable().subscribe(function (response) {
                        if (response.Error) {
                            _this.confirmationService.confirm({
                                header: 'Error',
                                message: response.Error.toString(),
                                rejectVisible: false
                            });
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                        }
                        else {
                            _this.confirmationService.confirm({
                                header: 'Locking reporting date',
                                message: 'The reporting date ' + _this.date4s + ' has been unlocked.',
                                rejectVisible: false
                            });
                            console.log("lock status", _this.lockstatus);
                            console.log("error", response.Error);
                            _this.setLockedData();
                            _this.disableLinks(false);
                        }
                    });
                },
                rejectVisible: true,
                reject: function () { _this.disableLinks(false); }
            });
        }
        else if (this.lockstatus == 0) {
            this.confirmationService.confirm({
                header: 'Save changes',
                message: 'The system reporting date - ' + this.date4s + ' - will be locked. Would you like to proceed?',
                accept: function () {
                    _this.dashboardDataService.getLockedObservable().subscribe(function (response) {
                        if (response.Error) {
                            _this.confirmationService.confirm({
                                header: 'Error',
                                message: response.Error.toString(),
                                rejectVisible: false
                            });
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                        }
                        else {
                            _this.confirmationService.confirm({
                                header: 'Data Unlocked',
                                message: 'The reporting date ' + _this.date4s + ' has been successfully locked.',
                                rejectVisible: false
                            });
                            console.log("error", response.Error);
                            console.log("lock status", _this.lockstatus);
                            _this.setLockedData();
                            _this.disableLinks(false);
                        }
                    });
                },
                rejectVisible: true,
                reject: function () { _this.disableLinks(false); }
            });
        }
    };
    AppDashboard.prototype.publishOrUnpublishData = function () {
        var _this = this;
        this.disableLinks(true);
        this.displayMessage = true;
        if (this.status == 0) {
            this.confirmationService.confirm({
                header: 'Publishing data',
                message: 'The PNL data for reporting date ' + this.date4s + ' will be published. Would you like to proceed?',
                accept: function () {
                    _this.dashboardDataService.getPublishObservable(_this.date4).subscribe(function (response) {
                        if (response.Error) {
                            _this.confirmationService.confirm({
                                header: 'Error',
                                message: response.Error.toString(),
                                rejectVisible: false
                            });
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                        }
                        else {
                            _this.confirmationService.confirm({
                                header: 'Data Published',
                                message: 'The PNL data for reporting date ' + _this.date4s + ' has been successfully published.',
                                rejectVisible: false
                            });
                            console.log("error", response.Error);
                            _this.setPublishData();
                            _this.disableLinks(false);
                        }
                    });
                },
                rejectVisible: true,
                reject: function () { _this.disableLinks(false); }
            });
        }
        else {
            this.confirmationService.confirm({
                header: 'Unpublishing data',
                message: 'The PNL data for reporting date ' + this.date4s + ' will be unpublished. Would you like to proceed?',
                accept: function () {
                    _this.dashboardDataService.getUnPublishObservable(_this.date4).subscribe(function (response) {
                        if (response.Error) {
                            _this.confirmationService.confirm({
                                header: 'Error',
                                message: response.Error.toString(),
                                rejectVisible: false
                            });
                            console.log("error", response.Error);
                            _this.disableLinks(false);
                        }
                        else {
                            _this.confirmationService.confirm({
                                header: 'Data Unpublished',
                                message: 'The PNL data for reporting date ' + _this.date4s + ' has been successfully unpublished.',
                                rejectVisible: false
                            });
                            console.log("error", response.Error);
                            _this.setPublishData();
                            _this.disableLinks(false);
                        }
                    });
                },
                rejectVisible: true,
                reject: function () { _this.disableLinks(false); }
            });
        }
    };
    AppDashboard.prototype.calculatePnL = function () {
        var _this = this;
        this.disableLinks(true);
        this.dashboardDataService.getCalculateObservable(this.date4)
            .subscribe(function (response) {
            if (response.Error) {
                _this.confirmationService.confirm({
                    header: 'Error',
                    message: response.Error.toString(),
                    rejectVisible: false
                });
                _this.disableLinks(false);
                console.log(response.Error);
            }
            else {
                _this.confirmationService.confirm({
                    header: 'Info',
                    message: 'Calculation completed successfully',
                    rejectVisible: false
                });
                console.log(response.Error);
                _this.setNodeData();
                _this.disableLinks(false);
            }
        });
    };
    AppDashboard.prototype.calculateNextDayPnL = function () {
        var _this = this;
        this.disableLinks(true);
        this.dashboardDataService.getCalculateObservable(this.date5)
            .subscribe(function (response) {
            if (response.Error) {
                _this.confirmationService.confirm({
                    header: 'Error',
                    message: response.Error.toString(),
                    rejectVisible: false
                });
                console.log(response.Error);
                _this.disableLinks(false);
            }
            else {
                _this.confirmationService.confirm({
                    header: 'Info',
                    message: 'Calculation completed successfully',
                    rejectVisible: false
                });
                console.log(response.Error);
                _this.setNodeData();
                _this.disableLinks(false);
            }
        });
    };
    AppDashboard.prototype.resetCalcFlag = function () {
        var _this = this;
        var msg = "Disclaimer:\
             \n This reset should only be performed after consulting with TPR Support Team.\
              \n The calculation flag for the buisness date " + this.date4s + " will be reset.\
             \n Pressing 'OK' confirms TPR Support Teams have confirmed this action and the calculation flag will be reset.\
             \n Pressing 'Cancel' will close this request.";
        this.confirmationService.confirm({
            header: 'Reset Calculation Flag',
            message: msg,
            accept: function () {
                _this.dashboardDataService.getResetCalculationFlagObservable(_this.date4).subscribe(function (response) {
                    if (response.Error) {
                        _this.confirmationService.confirm({
                            header: 'Error',
                            message: response.Error.toString(),
                            rejectVisible: false
                        });
                        console.log(response.Error);
                    }
                    else {
                        _this.setCalcFlag(response);
                        console.log(response);
                    }
                });
            },
            rejectVisible: true
        });
    };
    AppDashboard.prototype.doProcessing = function (event) {
        var _this = this;
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var selecteddate = this.date3.getDate() + m_names[this.date3.getMonth()] + this.date3.getFullYear();
        var selecteddate2 = selecteddate.toString();
        this.dashboardDataService.getDashboardDataObservable(selecteddate2).subscribe(function (response) {
            if (response.Error) {
                _this.confirmationService.confirm({
                    header: 'Error',
                    message: response.Error.toString(),
                    rejectVisible: false
                });
                console.log(response.Error);
            }
            else {
                _this.setDashboardData(response);
            }
        });
        // this.tPRcommonService.getSystemDateObservable().subscribe(data2 => this.setBusinessDate(data2));
        this.dashboardDataService.getLastCalculatedObservable().subscribe(function (files) { return _this.setLastCalculatedData(files); });
        this.dashboardDataService.getPublishStatusObservable().subscribe(function (data3) { return _this.setPublishStatus(data3); });
        this.dashboardDataService.getLockedStatusObservable().subscribe(function (data) { return _this.setLockedStatus(data); });
    };
    AppDashboard.prototype.setCalcFlag = function (data) {
        var reset = data.Result;
        console.log("Calc flag reset result = " + reset);
        if (reset == false) {
            this.confirmationService.confirm({
                header: 'Info',
                message: 'No change to calculation flag',
                rejectVisible: false
            });
        }
        else if (reset == true) {
            this.confirmationService.confirm({
                header: 'Info',
                message: 'Calculation flag successfully reset',
                rejectVisible: false
            });
        }
    };
    AppDashboard.prototype.setNodeData = function () {
        var _this = this;
        this.dashboardDataService.getLastCalculatedObservable().subscribe(function (files) { return _this.setLastCalculatedData(files); });
    };
    ;
    AppDashboard.prototype.onErrorsClick = function (data) {
        debugger;
        this.arrErrorDetails = [];
        this.blnShowErrorModal = true;
        if (Array.isArray(data.Comments.Errors.string))
            this.arrErrorDetails = data.Comments.Errors.string;
        else
            this.arrErrorDetails[0] = data.Comments.Errors.string;
    };
    ;
    AppDashboard.prototype.onChangesClick = function (data) {
        debugger;
        this.arrChangesDetails = [];
        this.blnShowChangesModal = true;
        if (Array.isArray(data.Comments.ActivityLog))
            this.arrChangesDetails = data.Comments.ActivityLog;
        else
            this.arrChangesDetails[0] = data.Comments.ActivityLog;
    };
    ;
    AppDashboard.prototype.setDashboardData = function (data) {
        debugger;
        this.dashboardData = data.Result.DashboardData.$values;
        if (this.dashboardData.length != 0) {
            for (var i = 0; i < this.dashboardData.length; i++) {
                this.dashboardData[i].Updated = this.tPRcommonService.getFormattedSystemDate(new Date(this.dashboardData[i].Updated));
                var inst = new x2js();
                var result = inst.xml2js(this.dashboardData[i].Comments);
                this.dashboardData[i].ShowErrorsDiv = false;
                this.dashboardData[i].ShowDefaultDiv = false;
                this.dashboardData[i].ShowChangesDiv = false;
                if (this.dashboardData[i].Type == "Manual Entry" && this.dashboardData[i].Source != "OilMVarDb") {
                    this.dashboardData[i].ShowChangesDiv = true;
                    this.dashboardData[i].Comments = result.ArrayOfActivityLog;
                }
                else if (this.dashboardData[i].Source == "OilMVarDb") {
                    this.dashboardData[i].Comments = result.FeedLoadedLog;
                    if (result.FeedLoadedLog.Errors)
                        this.dashboardData[i].ShowErrorsDiv = true;
                }
                else {
                    this.dashboardData[i].ShowDefaultDiv = true;
                    this.dashboardData[i].Comments = result.FeedLoadedLog;
                    if (result.FeedLoadedLog.Errors)
                        this.dashboardData[i].ShowErrorsDiv = true;
                }
                console.log(this.dashboardData[i]);
            }
        }
    };
    AppDashboard.prototype.setLastCalculatedData = function (data) {
        this.lastCalculated = this.tPRcommonService.getFormattedSystemDate(new Date(data.Result.DateTimeValue));
    };
    AppDashboard.prototype.disableLinks = function (bool) {
        for (var i = 0; i <= this.dashboardItems1.length - 1; i++) {
            console.log(this.dashboardItems1[i].disabled);
            this.dashboardItems1[i].disabled = bool;
        }
    };
    AppDashboard = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/dashboard/app.dashboard.component.html'
        }), 
        __metadata('design:paramtypes', [app_dashboardData_service_1.DashboardDataService, app_TPRCommonService_1.TPRCommonService, primeng_1.ConfirmationService])
    ], AppDashboard);
    return AppDashboard;
}());
exports.AppDashboard = AppDashboard;
var SystemDateValue = (function () {
    function SystemDateValue(Name, DateValue, StringValue, numericValue, BoolValue, DateTimeValue, Created, CreatedBy, Updated, UpdatedBy, Id, $type) {
        if (Name === void 0) { Name = null; }
        if (DateValue === void 0) { DateValue = null; }
        if (StringValue === void 0) { StringValue = null; }
        if (numericValue === void 0) { numericValue = null; }
        if (BoolValue === void 0) { BoolValue = null; }
        if (DateTimeValue === void 0) { DateTimeValue = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        if ($type === void 0) { $type = null; }
        this.Name = Name;
        this.DateValue = DateValue;
        this.StringValue = StringValue;
        this.numericValue = numericValue;
        this.BoolValue = BoolValue;
        this.DateTimeValue = DateTimeValue;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
        this.$type = $type;
    }
    return SystemDateValue;
}());
//# sourceMappingURL=app.dashboard.component.js.map