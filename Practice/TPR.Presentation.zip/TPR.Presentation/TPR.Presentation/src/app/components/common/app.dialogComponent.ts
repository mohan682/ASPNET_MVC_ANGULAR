import {
    Component, Input,
    OnInit,
    OnChanges
} from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { SimpleChange } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { DashboardDataService } from '../../service/app.dashboardData.service';
import { DialogModule } from 'primeng/primeng';

@Component({
    selector: 'dialog',
    templateUrl: 'app.dialogComponent.html'
})

export class DialogComponent implements OnChanges, OnInit {

    @Input() isVisible: boolean = false;
    @Input() message: string;

    constructor() { }

    ngOnChanges(changes: any) {
        if (changes.isVisible && !changes.isVisible.isFirstChange()) {
            // console.log(
            //     "Value change from",
            //     changes.isVisible.previousValue,
            //     "to",
            //     changes.isVisible.currentValue
            // );
        }

        this.isVisible = true;
    }

    ngOnInit() {
        //console.log('on init ->',this.isVisible);
    }

    // public showDialog(content:string) {
    //     this.message = content;
    //     this.isVisible = true;
    // }

    // hideDialog(){
    //     this.isVisible = false;
    // }
}

