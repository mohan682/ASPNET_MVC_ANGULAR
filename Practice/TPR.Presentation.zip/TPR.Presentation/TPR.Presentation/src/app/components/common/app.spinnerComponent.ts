'use strict';

import { Component, Input, OnDestroy, OnInit } from '@angular/core';

@Component({
    selector: 'Spinner',
    templateUrl: 'app.spinnerComponent.html'
})
export class SpinnerComponent implements OnDestroy {
    private currentTimeout: number;
    private isDelayedRunning: boolean = false;
    message: string = "Please wait";
    @Input()
    public set setMessage(value: string) {
        if (!value || value.length === 0) {
            this.message = "Please wait";
        }
        else {
            this.message = value.trim();
        }
    };

    @Input()
    public delay: number = 0;

    @Input()
    public set isRunning(value: boolean) {
        if (!value) {
            this.cancelTimeout();
            this.isDelayedRunning = false;
            return;
        }

        if (this.currentTimeout) {
            return;
        }

        this.currentTimeout = window.setTimeout(() => {
            this.isDelayedRunning = value;
            this.cancelTimeout();
        }, this.delay);
    }

    private cancelTimeout(): void {
        clearTimeout(this.currentTimeout);
        this.currentTimeout = undefined;
    }

    ngOnDestroy(): any {
        this.cancelTimeout();
    }
}