"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_regionService_1 = require('../../service/app.regionService');
var AppRegionComponent = (function () {
    function AppRegionComponent(regionsService, confirmationService) {
        this.regionsService = regionsService;
        this.confirmationService = confirmationService;
        this.region = new RegionsValue();
        this.msgs = [];
        this.blnSavedOrDeleted = false;
        this.successMessage = false;
        this.failureMessage = false;
        this.Message = "";
        this.clsMessage = {};
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.blnPushDataToDatabase = false;
        this.showMessage = false;
    }
    AppRegionComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.regionsService.getRegionsObservable()
            .subscribe(function (data) { return _this.setRegionsData(data); });
        this.cols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
    };
    AppRegionComponent.prototype.setRegionsData = function (data) {
        this.regions = data.Result.Regions.$values;
    };
    AppRegionComponent.prototype.showDialogToAdd = function () {
        this.newRegionType = true;
        this.region = new RegionsValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppRegionComponent.prototype.save = function () {
        //console.log(this.region);
        if (this.region.Name == null || this.region.Name.trim() == "") {
            //alert("Please provide valid data.");
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            this.region.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;
            if (this.newRegionType)
                this.regions.push(this.region);
            else
                this.regions[this.findSelectedRegionTypeIndex()] = this.region;
        }
        this.region = null;
        this.displayDialog = false;
    };
    AppRegionComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = true;
        console.log(this.regions);
        this.SaveDataToDataBase(action);
    };
    AppRegionComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentRegionType = event;
        this.confirmationService.confirm({
            message: 'Are you sure that you want to perform this action?',
            accept: function () {
                _this.regions.splice(_this.findRegionTypeIndexForDelete(), 1);
            }
        });
        this.region = null;
    };
    AppRegionComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.regionsService.updateRegionsObservable(this.regions)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
    };
    AppRegionComponent.prototype.ShowMessageOnSaveorDeleteData = function (data, action) {
        //console.log(data);
        this.blnSavedOrDeleted = true;
        // applying class to the message
        this.clsMessage = {};
        this.clsMessage = {
            successMessage: true,
            failureMessage: false
        };
        this.msgs = [];
        if (action == "save") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
            this.Message = "Data saved successfully";
        }
        else if (action == "delete") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' });
            this.Message = "Data deleted successfully";
        }
        ;
    };
    AppRegionComponent.prototype.onRowSelect = function (event) {
        this.newRegionType = false;
        this.region = this.cloneRegionType(event.data);
        //this.displayDialog = true;
    };
    AppRegionComponent.prototype.cloneRegionType = function (c) {
        var region = new RegionsValue();
        for (var prop in c) {
            region[prop] = c[prop];
        }
        return region;
    };
    AppRegionComponent.prototype.findSelectedRegionTypeIndex = function () {
        return this.regions.indexOf(this.selectedRegionType);
    };
    AppRegionComponent.prototype.findRegionTypeIndexForDelete = function () {
        return this.regions.indexOf(this.currentRegionType);
    };
    AppRegionComponent.prototype.canDeactivate = function () {
        //if (!this.blnPushDataToDatabase) {
        //    this.confirmationService.confirm({
        //        message: 'Are you sure that you want to navigate without saving the data?',
        //        accept: () => {
        //            let action: string = "save";
        //            this.SaveDataToDataBase(action);
        //        }
        //    });
        //}
        //return this.blnPushDataToDatabase;
        if (!this.blnPushDataToDatabase) {
            return confirm("Are you sure that you want to navigate without saving the data?");
        }
        return true;
    };
    AppRegionComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/regions/app.regions.component.html'
        }), 
        __metadata('design:paramtypes', [app_regionService_1.RegionsService, primeng_1.ConfirmationService])
    ], AppRegionComponent);
    return AppRegionComponent;
}());
exports.AppRegionComponent = AppRegionComponent;
var RegionsValue = (function () {
    function RegionsValue(Name, UpdatedBy, Updated, IsInUse, Created, CreatedBy, Id, $type) {
        if (Name === void 0) { Name = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Id === void 0) { Id = 0; }
        if ($type === void 0) { $type = null; }
        this.Name = Name;
        this.UpdatedBy = UpdatedBy;
        this.Updated = Updated;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Id = Id;
        this.$type = $type;
    }
    return RegionsValue;
}());
//# sourceMappingURL=app.regions.component.js.map