"use strict";
var testing_1 = require('@angular/core/testing');
var platform_browser_1 = require('@angular/platform-browser');
var app_regions_component_1 = require('./app.regions.component');
var app_regionService_1 = require('../../service/app.regionService');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var testing_2 = require('../../../testing');
describe('AppRegionComponent test cases', function () {
    var de;
    var comp;
    var fixture;
    var regionsService;
    var spy;
    //async before each
    beforeEach(testing_1.async(function () {
        var tprRegionsServiceStub = {
            getRegionsObservable: true,
            updateRegionsObservable: true
        };
        testing_1.TestBed.configureTestingModule({
            declarations: [app_regions_component_1.AppRegionComponent],
            imports: [],
            providers: [app_regionService_1.RegionsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(app_regions_component_1.AppRegionComponent); // creates the fixture of the testing component
        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });
    // test whether the component got successfully initialised
    it('should create component', function () { return expect(comp).toBeDefined(); });
    // test for service mockup
    // Tag service actually injected to the component.
    regionsService = fixture.debugElement.injector.get(app_regionService_1.RegionsService);
    // Create test mockup class
    var regionsMockUp = new RegionsValueTestMockup();
    var regionTypes = [];
    it('should not call the getRegionsObservable method before OnInit', function () {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionsMockUp));
        expect(spy.calls.any()).toBe(false, 'getRegionsObservable not yet called');
    });
    it('should call the getRegionsObservable method after component initialized', function () {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionsMockUp));
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getRegionsObservable called');
    });
    it('should raise Add button click event', function () {
        var displayDialog = true;
        var newTagType = true;
        var blnValidationResult = true;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAdd'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newRegionType).toBe(newTagType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });
    it('should raise Save button click event', function () {
        var regionType = new RegionsValueTestMockup('Test', '', new Date(), false, new Date(), '', 0, ''); // Creating testmockup object
        comp.region = regionType; // initializing the tagType object with the test mockup object
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.regions.indexOf(regionType)).toBeGreaterThan(-1);
    });
    it('should raise SavetoDatabase button click event', function () {
        var blnPushDataToDatabase = true;
        var blnSavedOrDeleted = true;
        var strSavedMessage = "Data saved successfully";
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnSaveDataToServer'));
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'updateRegionsObservable')
            .and.returnValue(Promise.resolve(regionsMockUp));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'updateRegionsObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});
var RegionsValueTestMockup = (function () {
    function RegionsValueTestMockup(Name, UpdatedBy, Updated, IsInUse, Created, CreatedBy, Id, $type) {
        if (Name === void 0) { Name = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Id === void 0) { Id = 0; }
        if ($type === void 0) { $type = null; }
        this.Name = Name;
        this.UpdatedBy = UpdatedBy;
        this.Updated = Updated;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Id = Id;
        this.$type = $type;
    }
    return RegionsValueTestMockup;
}());
//# sourceMappingURL=app.regions.component.spec.js.map