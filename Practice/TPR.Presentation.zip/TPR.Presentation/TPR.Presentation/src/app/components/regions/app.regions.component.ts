﻿import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { DataTable } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService, LightboxModule } from 'primeng/primeng';

import { RegionsService } from '../../service/app.regionService';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';

import { DialogComponent } from '../common/app.dialogComponent'

import { SpinnerComponent } from '../common/app.spinnerComponent'

import IRegionsValue = RegionNamespace.IRegionValue;

@Component({
    selector: 'my-app',
    templateUrl: 'app.regions.component.html'
})
export class AppRegionComponent implements OnInit {
    public isRequesting: boolean;
    regions: IRegionsValue[];
    newRegionType: boolean;
    displayDialog: boolean;
    region: IRegionsValue = new RegionsValue();
    cols: any[];
    selectedRegionType: IRegionsValue;
    currentRegionType: IRegionsValue;
    msgs: Message[] = [];
    blnSavedOrDeleted: boolean = false;
    successMessage: boolean = false;
    failureMessage: boolean = false;
    Message: string = "";
    clsMessage = {};
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true;
    blnPushDataToDatabase: boolean = false;
    showMessage: boolean = false;
    strErrorMessage: string = "";
    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    disableSave: boolean = false;
    canEdit: boolean = false;

    @ViewChild("regionsDataTable") regionsDataTable: DataTable;

    constructor(
        private regionsService: RegionsService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        this.loadData();

        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);

        this.cols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedBy', header: 'UpdatedByUser' },
            { field: 'Updated', header: 'UpdatedDate' }
        ];
    }

    loadData() {
        this.isRequesting = true;
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.regionsService.getRegionsObservable()
            .subscribe(data => this.setRegionsData(data));
    }

    private setRegionsData(data: any): void {
        this.regions = data.Result.Regions.$values;

        this.regions.forEach(region => {
            region.Updated != null ? region.Updated = this.tprCommonService.getFormattedSystemDate(new Date(region.Updated)) : null;
        });

        this.stopRefreshing();
    }

    showDialogToAdd() {
        this.newRegionType = true;
        this.region = new RegionsValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    }

    save() {
        //console.log("Saving Region..");
        if (this.region.Name == null || this.region.Name.trim() == "") {
            this.strErrorMessage = "Please enter a Region.";

            this.clsHighlightInvalidData = {};

            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };

            this.region.Name = "";
            return false;
        }
        else {
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = true;

            if (this.newRegionType) {
                //this.regions.push(this.region);
                let index: number = this.regions.indexOf(this.regions.find(region => region.Name.toLowerCase().trim() == this.region.Name.toLowerCase().trim()));
                if (index == -1) {
                    this.regions.push(this.region);
                }
                else {
                    this.strErrorMessage = "Region Name should be unique."
                    this.clsHighlightInvalidData = {};

                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };

                    return false;
                }
            }
            else
                this.regions[this.findSelectedRegionTypeIndex()] = this.region;
        }
        this.region = null;
        this.displayDialog = false;
    }

    saveDataToServer() {
        let action: string = "save";
        this.blnPushDataToDatabase = true;

        let regionsArray: string[] = [];

        let emptyRegion = this.regions.find(item => item.Name.trim() == "");

        if (emptyRegion) {
            this.blnShowPopUp = true;
            this.Status = "Error";
            this.ValidationMessage = "'Name' should not be empty.";
        }
        else {
            this.regions.forEach(region => regionsArray.push(region.Name.toLowerCase().trim()));

            let uniquenessResult: boolean = this.checkIfArrayIsUnique(regionsArray);

            if (uniquenessResult) {
                this.SaveDataToDataBase(action);
            }
            else {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = "Region Name should be unique.";
                this.stopRefreshing();
            }
        }
    }

    delete(event: IRegionsValue) {
        this.currentRegionType = event;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Region?',
            accept: () => {
                this.regions.splice(this.findRegionTypeIndexForDelete(), 1);
            },
            rejectVisible: true,
            acceptVisible: true
        });
        this.region = null;
    }

    SaveDataToDataBase(action: string) {
        this.isRequesting = true;
        this.regionsService.updateRegionsObservable(this.regions)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                    this.stopRefreshing();
                }
                else {
                    //this.ShowMessageOnSaveorDeleteData(response, action);
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    //console.log("Action ->", action);
                    if (action == "save") {
                        this.ValidationMessage = "Region Data is saved successfully";
                    }
                    else if (action == "delete") {
                        this.ValidationMessage = "The Selected Region is deleted successfully";
                    }
                    this.loadData();
                    this.blnSavedOrDeleted = true;
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
                this.stopRefreshing();
            });
    }

    private stopRefreshing() {
        //console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    onRowSelect(event: any) {
        this.newRegionType = false;
        this.region = this.cloneRegionType(event.data);
        //this.displayDialog = true;
    }

    cloneRegionType(c: IRegionsValue): IRegionsValue {
        let region = new RegionsValue();
        for (let prop in c) {
            region[prop] = c[prop];
        }
        return region;
    }

    findSelectedRegionTypeIndex(): number {
        return this.regions.indexOf(this.selectedRegionType);
    }

    findRegionTypeIndexForDelete(): number {
        return this.regions.indexOf(this.currentRegionType);
    }

    checkIfArrayIsUnique(myArray: string[]): boolean {
        return myArray.length === new Set(myArray).size;
    }

    RefreshData(regionsData: DataTable) {
        this.regionsDataTable.reset();
        this.loadData();
    }
}

class RegionsValue implements IRegionsValue {
    constructor(public Name: string = null,
        public UpdatedBy: string = null,
        public Updated: string = null,
        public IsInUse: boolean = false,
        public Created: Date = null,
        public CreatedBy: string = null,
        public Id: number = 0,
        public $type: string = null) { }
}