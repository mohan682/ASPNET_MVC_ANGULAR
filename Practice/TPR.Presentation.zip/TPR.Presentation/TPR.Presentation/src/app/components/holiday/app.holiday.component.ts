﻿import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { SelectItem, InputTextModule } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService, PanelModule } from 'primeng/primeng';

import { TPRHolidayService } from '../../service/app.TPRHolidayService';
import { RegionsService } from '../../service/app.regionService';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { TPRCommonService } from '../../service/app.TPRCommonService';

import { SpinnerComponent } from '../common/app.spinnerComponent'

import { AppComponent } from '../../app.component';

import IHolidaysValue = HolidayNamespace.IHolidayValue;
import IRegionValue = HolidayNamespace.IRegionValue;

@Component({
    selector: 'my-app',
    templateUrl: 'app.holiday.component.html'
})
export class AppHolidayComponent {

    blnDisableRegion: boolean = false;
    selectedCity: string;
    regions: IRegionValue[];
    holidays: IHolidaysValue[];
    newHolidayType: boolean;
    displayDialog: boolean;
    holiday: IHolidaysValue = new HolidayTypesValue();
    cols: any[];
    date3: string = '';
    selectedHolidayDate: string = '';
    selectedHolidayType: string = '';
    selectedRegion: string = '';
    holidayType: SelectItem[];
    region: SelectItem[];
    selectedRegionType: IRegionValue = new RegionType();
    currentHolidayType: IHolidaysValue;
    holidayDescription: string = '';
    msgs: Message[] = [];
    blnSavedOrDeleted: boolean = false;
    successMessage: boolean = false;
    failureMessage: boolean = false;
    Message: string = "";
    clsMessage = {};
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true;
    blnPushDataToDatabase = false;
    validationErrorMessage: string = "";
    minDate: Date;
    businessDate: Date;
    currentDate: Date;
    isHoliday: boolean = true;
    isRequesting: boolean;
    blnShowHolidayConfirmDialog: boolean = false;
    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    reload: boolean = false;
    disableSave: boolean = false;
    constructor(
        private regionsService: RegionsService,
        private holidayService: TPRHolidayService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private appComponent: AppComponent,
    ) { }

    ngOnInit() {
        this.isRequesting = true;
        this.loadData();

        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        // console.log("Is save disabled ->", this.disableSave);
    }

    loadData() {
        this.isRequesting = true;
        // this.blnShowHolidayConfirmDialog = true;

        this.regionsService.getRegionsObservable()
            .subscribe(data => this.setRegionsData(data));

        this.holidayService.getHolidaysObservable()
            .subscribe(data => this.setHolidayData(data));

        this.cols = [
            { field: 'HolidayType', header: 'Holiday Type' },
            { field: 'Date', header: 'Date' },
            { field: 'Description', header: 'Description' },
            { field: 'Region', header: 'Region' },
            { field: 'UpdatedbyUser', header: 'Updated by User' },
            { field: 'UpdatedDate', header: 'Updated Date' },
        ];

        this.holidayType = [];
        this.holidayType.push({ label: 'Regional', value: 'Regional' });
        this.holidayType.push({ label: 'Global', value: 'Global' });

        this.selectedHolidayType = "Regional";

        this.selectedRegion = "Select Region";
        this.holidayDescription = null;

    }

    private setRegionsData(data: any): void {
        this.regions = [];
        this.regions = data.Result.Regions.$values;

        this.region = [];
        this.region.push({ label: 'Select Region', value: 'Select Region' });

        let regionValue: string = '';

        for (var i = 0; i < this.regions.length; i++) {
            let region = this.regions[i];
            regionValue = region.Name;

            this.region.push({ label: regionValue, value: regionValue });
        }
    }

    private setHolidayData(data: any): void {
        this.holidays = data.Result.Holidays.$values;

        this.currentDate = localStorage.getItem("BusinessDate") ? new Date(localStorage.getItem("BusinessDate")) : new Date();

        for (var i = 0; i < this.holidays.length; i++) {
            this.holiday = this.holidays[i];

            let date: Date = new Date(this.holiday.Date);

            if (date > this.currentDate) {
                this.holiday.IsDeletable = false;
            }
            else {
                this.holiday.IsDeletable = true;
            }

            this.holiday.Updated = this.holiday.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(this.holiday.Updated)) : null;

            if (this.holiday.Region != null) {
                this.holiday.HolidayType = 'Regional';
            }
            else {
                this.holiday.HolidayType = 'Global';
            }
        }

        localStorage.setItem("Holidays", JSON.stringify(this.holidays));

        //console.log("Holidays ->", this.holidays);        
        this.setInitialHolidayDate();
        this.stopRefreshing();
    }

    private setInitialHolidayDate() {
        //debugger;
        this.businessDate = localStorage.getItem("BusinessDate") ? new Date(localStorage.getItem("BusinessDate")) : new Date();

        let newDate = new Date(this.businessDate);

        //this.minDate = newDate;
        //this.minDate.setDate(newDate.getDate() + 1);
        //console.log("minDate +1 ->", this.minDate);

        //if (!this.reload) {
        //this.setDefaultHoliday(this.minDate);
        this.minDate = this.appComponent.getPreviousorNextWorkingDay(newDate, false);
        let minimumSeleciveDate: Date = new Date(this.minDate);
        this.date3 = this.tprCommonService.getFormattedSystemDate_NonUTC(minimumSeleciveDate);

        // console.log("businessDate->", this.businessDate);
        // console.log("minDate ->", newDate);
        // console.log("date3 ->", this.date3);
        //}
        // this.stopRefreshing();
    }

    setDefaultHoliday(dateInConsideration: Date) {
        let currentDay: number = dateInConsideration.getDay();

        if (currentDay == 5) {
            // friday
            let item: IHolidaysValue = this.holidays.find(holiday => this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                this.tprCommonService.getFormattedSystemDate_Date(new Date(dateInConsideration)) && holiday.HolidayType == "Global");

            let index: number = this.holidays.indexOf(item);

            if (index == -1 && this.isHoliday) {
                this.isHoliday = false;
                this.minDate = dateInConsideration;
                let dateDD = this.minDate;
                //console.log("dateDD -> ", dateDD);
                this.date3 = this.tprCommonService.getFormattedSystemDate_Date(this.minDate);
            }
            else {
                dateInConsideration.setDate(dateInConsideration.getDate() + 3);
                this.setDefaultHoliday(dateInConsideration);
            }
        }
        else if (currentDay == 6) {
            // saturday
            dateInConsideration.setDate(dateInConsideration.getDate() + 2);

            let item: IHolidaysValue = this.holidays.find(holiday => this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                this.tprCommonService.getFormattedSystemDate_Date(new Date(dateInConsideration)) && holiday.HolidayType == "Global");

            let index: number = this.holidays.indexOf(item);

            if (index == -1 && this.isHoliday) {
                this.isHoliday = false;
                this.minDate = dateInConsideration;
                let dateDD = this.minDate;
                //console.log("dateDD -> ", dateDD);
                this.date3 = this.tprCommonService.getFormattedSystemDate_Date(this.minDate);
            }
            else {
                dateInConsideration.setDate(dateInConsideration.getDate() + 1);
                this.setDefaultHoliday(dateInConsideration);
            }
        }
        else if (currentDay == 0) {
            // sunday
            dateInConsideration.setDate(dateInConsideration.getDate() + 1);

            let item: IHolidaysValue = this.holidays.find(holiday => this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                this.tprCommonService.getFormattedSystemDate_Date(new Date(dateInConsideration)) && holiday.HolidayType == "Global");

            let index: number = this.holidays.indexOf(item);

            if (index == -1 && this.isHoliday) {
                this.isHoliday = false;
                this.minDate = dateInConsideration;
                let dateDD = this.minDate;
                //console.log("dateDD -> ", dateDD);
                this.date3 = this.tprCommonService.getFormattedSystemDate_Date(this.minDate);
            }
            else {
                dateInConsideration.setDate(dateInConsideration.getDate() + 1);
                this.setDefaultHoliday(dateInConsideration);
            }
        }
        else {
            // monday, tuesday, wednesday, thursday
            let item: IHolidaysValue = this.holidays.find(holiday => this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                this.tprCommonService.getFormattedSystemDate_Date(new Date(dateInConsideration)) && holiday.HolidayType == "Global");

            let index: number = this.holidays.indexOf(item);

            if (index == -1 && this.isHoliday) {
                this.isHoliday = false;
                this.minDate = dateInConsideration;
                let dateDD = this.minDate;
                //console.log("dateDD -> ", dateDD);
                this.date3 = this.tprCommonService.getFormattedSystemDate_Date(this.minDate);
            }
            else {
                dateInConsideration.setDate(dateInConsideration.getDate() + 1);
                this.setDefaultHoliday(dateInConsideration);
            }
        }
    }

    validateHolidayData(): boolean {
        // Date selection validation
        let selectedDate: string = '';
        let blnResult = true;

        selectedDate = this.date3;

        if (selectedDate == "" || selectedDate == null) {
            //alert('Provide proper date value.');
            this.clsHighlightInvalidData = {};

            this.validationErrorMessage = "Enter a date.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidDate: true
            };

            blnResult = false;
            return blnResult;
        }

        let myDate = new Date(this.date3);

        var m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        selectedDate = myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();

        this.selectedHolidayDate = selectedDate;

        if (!this.isDate(selectedDate)) {
            //alert('Provide proper date value.');

            this.clsHighlightInvalidData = {};

            this.validationErrorMessage = "Enter a date.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidDate: true
            };

            blnResult = false;
            return blnResult;
        }

        let currentBusinessDate: Date = localStorage.getItem("BusinessDate") ? new Date(localStorage.getItem("BusinessDate")) : new Date();

        if (myDate <= currentBusinessDate) {
            this.clsHighlightInvalidData = {};

            this.validationErrorMessage = "Date value should be greater than the business date.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidDate: true
            };

            blnResult = false;
            return blnResult;
        }

        if (this.selectedHolidayType.trim() == '' || this.selectedHolidayType.toLowerCase() == "select holiday") {
            //alert('Select proper holiday type.');

            this.clsHighlightInvalidData = {};

            this.validationErrorMessage = "Select a holiday type.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidHolidayData: true
            };
            blnResult = false;
            return blnResult;
        }

        if (this.selectedHolidayType.trim() != 'Global') {
            if (this.selectedRegion.trim() == '' || this.selectedRegion.toLowerCase() == "select region") {
                //alert('Select proper region type.');

                this.clsHighlightInvalidData = {};

                this.validationErrorMessage = "'Region' should not be empty.";
                this.blnValidationResult = false;
                this.clsHighlightInvalidData = {
                    highlightInvalidRegionData: true
                };
                blnResult = false;
                return blnResult;
            }
        }

        if (this.holidayDescription == null || this.holidayDescription.trim() == "") {
            //alert('Provide proper holiday description value.')

            this.clsHighlightInvalidData = {};

            this.validationErrorMessage = "'Description' should not be empty.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidDescriptionData: true
            };
            blnResult = false;
            return blnResult;
        }

        let selectedRegionItem: IRegionValue = this.regions.find(region => region.Name == this.selectedRegion);

        if (selectedRegionItem) {
            this.holidays.forEach(holiday => {
                if (
                    this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) == this.tprCommonService.getFormattedSystemDate_Date(new Date(this.date3))
                    && holiday.HolidayType.toLowerCase().trim() == this.selectedHolidayType.toLowerCase().trim()
                    && holiday.Region.Name.toLowerCase().trim() == selectedRegionItem.Name.toLowerCase().trim()
                ) {
                    // console.log("Date ->", this.tprCommonService.getFormattedSystemDate_Date(new Date(this.date3)))
                    this.clsHighlightInvalidData = {};

                    this.validationErrorMessage = "The holiday already exists.";
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidDate: true
                    };

                    blnResult = false;
                    return blnResult;
                }
            })
        }
        else {
            this.holidays.forEach(holiday => {
                if (
                    this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) == this.tprCommonService.getFormattedSystemDate_Date(new Date(this.date3))
                    && holiday.HolidayType.toLowerCase().trim() == this.selectedHolidayType.toLowerCase().trim()
                ) {
                    // console.log("Date ->", this.tprCommonService.getFormattedSystemDate_Date(new Date(this.date3)))
                    this.clsHighlightInvalidData = {};

                    this.validationErrorMessage = "The holiday already exists.";
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidDate: true
                    };

                    blnResult = false;
                    return blnResult;
                }
            })
        }
        return blnResult;
    }

    AddHoliday(event: any) {
        // setting up holiday object to be pushed to service for updating in DB
        this.msgs = [];
        this.Message = "";

        if (this.validateHolidayData()) {
            this.validationErrorMessage = "";
            this.blnShowHolidayConfirmDialog = true;
            this.confirmationService.confirm({
                header: "Save",
                message: 'Do you want to save the changes to Holidays?',
                accept: () => { this.SaveHoliday(); },
                rejectVisible: true,
                acceptVisible: true
            });
        }
        else {
            return false;
        }
    }

    SaveHoliday() {
        //if (this.validateHolidayData()) {
        this.clsHighlightInvalidData = {};
        this.validationErrorMessage = "";
        this.blnValidationResult = false;
        this.blnPushDataToDatabase = true;
        this.holiday = new HolidayTypesValue();
        this.holiday.HolidayType = this.selectedHolidayType;
        this.holiday.$type = '';
        this.holiday.Date = this.selectedHolidayDate;

        this.msgs = [];
        this.Message = "";

        if (this.selectedHolidayType.toUpperCase() === "GLOBAL") {
            this.holiday.Region = null;
        }
        else if (this.selectedHolidayType.toUpperCase() === "REGIONAL") {
            this.holiday.Region = new RegionType();
            let selectedRegionType = new RegionType();

            let regionSelected: string = this.selectedRegion;

            this.regions.forEach(function (item) {
                let region: IRegionValue = new RegionType();

                region = item;

                if (region.Name == regionSelected) {
                    selectedRegionType = region;
                }
            });
            this.holiday.Region = selectedRegionType;
        }

        this.holiday.MarkAsDeleted = false;
        this.holiday.Name = this.holidayDescription;
        this.holiday.IsUpdateTimingException = false;
        this.holiday.Created = null;
        this.holiday.CreatedBy = null;
        this.holiday.Updated = null;
        this.holiday.UpdatedBy = null;
        this.holiday.Id = 0;

        this.holidays.push(this.holiday);

        let action: string = 'add';

        this.isRequesting = true;
        this.holidayService.updateHolidayObservable(this.holiday)
            .subscribe(
            (response: any) => {
                this.blnDisableRegion = false;
                if (response.Error) {
                    this.stopRefreshing();
                    // this.blnShowHolidayConfirmDialog = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error;
                    this.blnShowPopUp = true;
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    this.ValidationMessage = "Holiday Data is saved successfully";
                    this.blnSavedOrDeleted = true;
                    this.reload = true;
                    this.loadData();
                }
            },
            (error: any) => {
                this.blnDisableRegion = false;
                this.stopRefreshing();
                // this.blnShowHolidayConfirmDialog = true;
                this.Status = "Error";
                this.ValidationMessage = error;
                this.blnShowPopUp = true;
            }
            );
        //}
        //else {
        //    alert("Data not sent.");
        //}
    }

    delete(event: IHolidaysValue) {
        //console.log(event);
        this.msgs = [];
        this.Message = "";
        this.validationErrorMessage = "";
        this.blnShowHolidayConfirmDialog = true;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Do you want to delete the selected holiday?',
            accept: () => { this.deleteHoliday(event); },
            rejectVisible: true,
            acceptVisible: true
        });
    }

    deleteHoliday(event: IHolidaysValue) {
        this.currentHolidayType = event;
        //console.log(this.currentHolidayType);
        this.holidays.splice(this.findHolidayTypeIndexForDelete(), 1);

        let action: string = 'delete'
        this.currentHolidayType.MarkAsDeleted = true;

        this.isRequesting = true;
        this.holidayService.deleteHolidayObservable(this.currentHolidayType)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.stopRefreshing();
                    // this.blnShowHolidayConfirmDialog = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error;
                    this.blnShowPopUp = true;
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    this.ValidationMessage = "The selected Holiday is deleted successfully";
                    this.blnSavedOrDeleted = true;
                    this.reload = true;
                    this.loadData();
                }
            },
            (error: any) => {
                this.stopRefreshing();
                // this.blnShowHolidayConfirmDialog = true;
                this.Status = "Error";
                this.ValidationMessage = error;
                this.blnShowPopUp = true;
            }
            );

        this.holiday = null;
    }

    findHolidayTypeIndexForDelete(): number {
        return this.holidays.indexOf(this.currentHolidayType);
    }

    findSelectedRegionIndex(): number {
        return this.regions.indexOf(this.selectedRegionType);
    }

    HolidayTypeChange(HolidayType: string): void {
        if (HolidayType.trim().toUpperCase() == "GLOBAL") {
            this.selectedRegion = "Select Region";
            let selectedRegionValue = this.region.find(region => region.value == this.selectedRegion);
            selectedRegionValue.label = "Global";
            this.blnDisableRegion = true;
        }
        else {
            this.selectedRegion = "Select Region";
            let selectedRegionValue = this.region.find(region => region.value == this.selectedRegion);
            selectedRegionValue.label = "Select Region";
            this.blnDisableRegion = false;
        }
    }

    isDate(currVal: any): boolean {
        if (currVal == '') return false;

        let test: any = '';
        //Declare Regex  
        var rxDatePattern = new RegExp(/(([0-9])|([0-2][0-9])|([3][0-1]))\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s\d{4}$/);

        var dtDate = currVal.match(rxDatePattern); // is format OK?

        if (dtDate == null) return false;

        var dtArray = dtDate[0].split(' ');

        var dtDay = parseInt(dtArray[0]);
        var dtMonth = dtArray[1];
        var dtYear = parseInt(dtArray[2]);

        // need to change to lowerCase because switch is
        // case sensitive
        switch (dtMonth.toLowerCase()) {
            case 'jan':
                dtMonth = '01';
                break;
            case 'feb':
                dtMonth = '02';
                break;
            case 'mar':
                dtMonth = '03';
                break;
            case 'apr':
                dtMonth = '04';
                break;
            case 'may':
                dtMonth = '05';
                break;
            case 'jun':
                dtMonth = '06';
                break;
            case 'jul':
                dtMonth = '07';
                break;
            case 'aug':
                dtMonth = '08';
                break;
            case 'sep':
                dtMonth = '09';
                break;
            case 'oct':
                dtMonth = '10';
                break;
            case 'nov':
                dtMonth = '11';
                break;
            case 'dec':
                dtMonth = '12';
                break;
        }

        // convert date to number
        dtMonth = parseInt(dtMonth);

        if (isNaN(dtMonth)) return false;
        else if (dtMonth < 1 || dtMonth > 12) return false;
        else if (dtDay < 1 || dtDay > 31) return false;
        else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31) return false;
        else if (dtMonth == 2) {
            var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
            if (dtDay > 29 || (dtDay == 29 && !isleap)) return false;
        }
        return true;
    }

    private stopRefreshing() {
        // console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }
}

class HolidayTypesValue implements IHolidaysValue {
    constructor(
        public IsDeletable: boolean = false,
        public HolidayType: string = null,
        public $type: string = null,
        public Date: string = null,
        public Region: IRegionValue = null,
        public MarkAsDeleted: boolean = false,
        public Name: string = null,
        public IsUpdateTimingException: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class RegionType implements IRegionValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}