﻿import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppHolidayComponent } from './app.holiday.component';
import { TPRHolidayService } from '../../service/app.TPRHolidayService';
import { RegionsService } from '../../service/app.regionService';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { addMatchers, click } from '../../../testing';

import IHolidaysValue = HolidayNamespace.IHolidayValue;
import IRegionValue = HolidayNamespace.IRegionValue;


describe('AppHolidayComponent test cases', () => {
    let de: DebugElement;
    let comp: AppHolidayComponent;
    let fixture: ComponentFixture<AppHolidayComponent>;
    let holidayService: TPRHolidayService;
    let regionsService: RegionsService;
    let spy: jasmine.Spy;

    //async before each
    beforeEach(async(() => {
        //Configure testing bed
        TestBed.configureTestingModule({
            declarations: [AppHolidayComponent],
            imports: [],
            providers: [TPRHolidayService, RegionsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AppHolidayComponent); // creates the fixture of the testing component

        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });

    // test whether the component got successfully initialised
    it('should create component', () => expect(comp).toBeDefined());

    // test for service mockup
    // Holiday service actually injected to the component.
    holidayService = fixture.debugElement.injector.get(TPRHolidayService);

    // Regions service actually injected to the component.
    regionsService = fixture.debugElement.injector.get(RegionsService);

    // Create test mockup class
    let holidayMockUp: HolidayTypesValueTestMockup = new HolidayTypesValueTestMockup();
    let regionMockUp: RegionTypeTestMockup = new RegionTypeTestMockup();
    let holidays: IHolidaysValue[];
    let regions: IRegionValue[];

    it('should not call the getHolidaysObservable method before OnInit', () => {
        // Setup spy on the 'getHolidaysObservable' method
        spy = spyOn(holidayService, 'getHolidaysObservable')
            .and.returnValue(Promise.resolve(holidayMockUp));

        expect(spy.calls.any()).toBe(false, 'getHolidaysObservable not yet called');
    });

    it('should not call the getRegionsObservable method before OnInit', () => {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionMockUp));

        expect(spy.calls.any()).toBe(false, 'getRegionsObservable not yet called');
    });

    it('should call the getHolidaysObservable method after component initialized', () => {
        // Setup spy on the 'getHolidaysObservable' method
        spy = spyOn(holidayService, 'getHolidaysObservable')
            .and.returnValue(Promise.resolve(holidayMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getHolidaysObservable called');
    });

    it('should call the getRegionsObservable method after component initialized', () => {
        // Setup spy on the 'getRegionsObservable' method
        spy = spyOn(regionsService, 'getRegionsObservable')
            .and.returnValue(Promise.resolve(regionMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'getRegionsObservable called');
    });

    it('Check for properness of the validateHolidayData for date validation (false condition)', () => {
        let dateSelected: string = ''

        comp.date3 = dateSelected;

        de = fixture.debugElement.query(By.css('#btnAddHoliday'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.validateHolidayData()).toBe(false, 'Empty date provided for date variable.');

        // setup some junk data for test
        dateSelected = "TestDate";
        comp.date3 = dateSelected;

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.validateHolidayData()).toBe(false, 'Improper date provided for date variable.');
    });

    it('Check for properness of the validateHolidayData for holiday Type validation (false condition)', () => {
        let date: Date = new Date();
        let dateSelected: string = ''
        let holidayType: string = '';

        // setup proper date
        comp.date3 = date.toDateString();

        // setup improper holiday type

        // check for holiday Type
        comp.selectedHolidayType = holidayType;

        de = fixture.debugElement.query(By.css('#btnAddHoliday'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday type provided.');

        holidayType = "select holiday";
        comp.selectedHolidayType = holidayType;

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday type provided.');
    });

    it('Check for properness of the validateHolidayData for region Type validation (false condition)', () => {
        let date: Date = new Date();
        let dateSelected: string = ''
        let holidayType: string = '';
        let regionType: string = '';

        // setup proper date
        comp.date3 = date.toDateString();

        // setup proper holiday type
        holidayType = "Test Holiday";

        // setup improper region type

        // check for region Type
        comp.selectedRegion = regionType;

        de = fixture.debugElement.query(By.css('#btnAddHoliday'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper region type provided.');

        regionType = "select region";
        comp.selectedRegion = regionType;

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper region type provided.');
    });

    it('Check for properness of the validateHolidayData for holiday Description validation (false condition)', () => {
        let date: Date = new Date();
        let dateSelected: string = ''
        let holidayType: string = '';
        let regionType: string = '';
        let holidayDescription: string = '';

        // setup proper date
        comp.date3 = date.toDateString();

        // setup proper holiday type
        holidayType = "Test Holiday";

        // setup proper region type
        regionType = "Test Region";

        // setup improper holiday description

        // check for holiday description
        comp.holidayDescription = holidayDescription;

        de = fixture.debugElement.query(By.css('#btnAddHoliday'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday desctiption provided.');

        comp.holidayDescription = null;

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(false, 'Improper holiday desctiption provided.');
    });

    it('Check for properness of the validateHolidayData (complete true condition)', () => {
        let date: Date = new Date();
        let holidayType: string = "Test Holiday Type";
        let regionType: string = "Test Region Type";
        let holidayDescription: string = "Test Description"

        comp.date3 = date.toDateString();
        comp.selectedHolidayType = holidayType;
        comp.selectedRegion = regionType;
        comp.holidayDescription = holidayDescription;

        de = fixture.debugElement.query(By.css('#btnAddHoliday'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method
        expect(comp.validateHolidayData()).toBe(true, 'Success return for validateHolidayData method call.');
    });

    it('should raise AddHoliday button click event', () => {
        let date: Date = new Date();
        let holidayType: string = "Test Holiday Type";
        let regionType: string = "Test Region Type";
        let holidayDescription: string = "Test Description"

        comp.date3 = date.toDateString();
        comp.selectedHolidayType = holidayType;
        comp.selectedRegion = regionType;
        comp.holidayDescription = holidayDescription;


        // create mockup objects to be passed to service
        let regionTypeMockup: RegionTypeTestMockup = new RegionTypeTestMockup('', 'Test region', false, '', '', '', '', 0);
        let holidayTypeMockup: HolidayTypesValueTestMockup = new HolidayTypesValueTestMockup(false, 'Test holiday Type', '', '', regionTypeMockup, false, 'Test Holiday', false, '', '', '', '', 0)

        de = fixture.debugElement.query(By.css('#btnAddHoliday'));

        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(holidayService, 'updateHolidayObservable')
            .and.returnValue(Promise.resolve(holidayTypeMockup));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        fixture.detectChanges();

        expect(spy.calls.any()).toBe(true, 'updateHolidayObservable called');

        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.holidays.indexOf(holidayTypeMockup)).toBeGreaterThan(-1);
    });
});

class HolidayTypesValueTestMockup implements IHolidaysValue {
    constructor(
        public IsDeletable: boolean = false,
        public HolidayType: string = null,
        public $type: string = null,
        public Date: string = null,
        public Region: IRegionValue = null,
        public MarkAsDeleted: boolean = false,
        public Name: string = null,
        public IsUpdateTimingException: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class RegionTypeTestMockup implements IRegionValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}