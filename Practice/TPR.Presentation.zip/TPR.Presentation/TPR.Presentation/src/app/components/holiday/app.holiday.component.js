"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_TPRHolidayService_1 = require('../../service/app.TPRHolidayService');
var app_regionService_1 = require('../../service/app.regionService');
var AppHolidayComponent = (function () {
    function AppHolidayComponent(regionsService, holidayService, confirmationService) {
        this.regionsService = regionsService;
        this.holidayService = holidayService;
        this.confirmationService = confirmationService;
        this.blnDisableRegion = false;
        this.holiday = new HolidayTypesValue();
        this.date3 = '';
        this.selectedHolidayDate = '';
        this.selectedHolidayType = '';
        this.selectedRegion = '';
        this.selectedRegionType = new RegionType();
        this.holidayDescription = '';
        this.msgs = [];
        this.blnSavedOrDeleted = false;
        this.successMessage = false;
        this.failureMessage = false;
        this.Message = "";
        this.clsMessage = {};
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.blnPushDataToDatabase = false;
        this.validationErrorMessage = "";
    }
    AppHolidayComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.regionsService.getRegionsObservable()
            .subscribe(function (data) { return _this.setRegionsData(data); });
        this.holidayService.getHolidaysObservable()
            .subscribe(function (data) { return _this.setHolidayData(data); });
        this.cols = [
            { field: 'HolidayType', header: 'Holiday Type' },
            { field: 'Date', header: 'Date' },
            { field: 'Description', header: 'Description' },
            { field: 'Region', header: 'Region' },
            { field: 'UpdatedbyUser', header: 'Updated by User' },
            { field: 'UpdatedDate', header: 'Updated Date' },
        ];
        this.holidayType = [];
        this.holidayType.push({ label: 'Select Holiday', value: 'Select Holiday' });
        this.holidayType.push({ label: 'Regional', value: 'Regional' });
        this.holidayType.push({ label: 'Global', value: 'Global' });
    };
    AppHolidayComponent.prototype.setRegionsData = function (data) {
        this.regions = [];
        this.regions = data.Result.Regions.$values;
        this.region = [];
        this.region.push({ label: 'Select Region', value: 'Select Region' });
        var regionValue = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionValue = region.Name;
            this.region.push({ label: regionValue, value: regionValue });
        }
    };
    AppHolidayComponent.prototype.setHolidayData = function (data) {
        //console.log(data);
        this.holidays = data.Result.Holidays.$values;
        for (var i = 0; i < this.holidays.length; i++) {
            this.holiday = this.holidays[i];
            if (this.holiday.Region != null) {
                this.holiday.HolidayType = 'Regional';
            }
            else {
                this.holiday.HolidayType = 'Global';
            }
        }
    };
    //showDialogToAdd() {
    //    this.newHolidayType = true;
    //    this.holiday = new HolidayTypesValue();
    //    this.displayDialog = true;
    //    this.clsHighlightInvalidData = {};
    //    this.blnValidationResult = true;
    //}
    AppHolidayComponent.prototype.validateHolidayData = function () {
        // Date selection validation
        var selectedDate = '';
        var blnResult = true;
        selectedDate = this.date3;
        if (selectedDate == "" || selectedDate == null) {
            //alert('Provide proper date value.');
            this.clsHighlightInvalidData = {};
            this.validationErrorMessage = "Provide proper date value.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidDate: true
            };
            blnResult = false;
            return blnResult;
        }
        var myDate = new Date(this.date3);
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        selectedDate = myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        this.selectedHolidayDate = selectedDate;
        if (!this.isDate(selectedDate)) {
            //alert('Provide proper date value.');
            this.clsHighlightInvalidData = {};
            this.validationErrorMessage = "Provide proper date value.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidDate: true
            };
            blnResult = false;
            return blnResult;
        }
        if (this.selectedHolidayType.trim() == '' || this.selectedHolidayType.toLowerCase() == "select holiday") {
            //alert('Select proper holiday type.');
            this.clsHighlightInvalidData = {};
            this.validationErrorMessage = "Select proper holiday type.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidHolidayData: true
            };
            blnResult = false;
            return blnResult;
        }
        if (this.selectedHolidayType.trim() != 'Global') {
            if (this.selectedRegion.trim() == '' || this.selectedRegion.toLowerCase() == "select region") {
                //alert('Select proper region type.');
                this.clsHighlightInvalidData = {};
                this.validationErrorMessage = "Select proper region type.";
                this.blnValidationResult = false;
                this.clsHighlightInvalidData = {
                    highlightInvalidRegionData: true
                };
                blnResult = false;
                return blnResult;
            }
        }
        if (this.holidayDescription == null || this.holidayDescription.trim() == "") {
            //alert('Provide proper holiday description value.')
            this.clsHighlightInvalidData = {};
            this.validationErrorMessage = "Provide proper holiday description value.";
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidDescriptionData: true
            };
            blnResult = false;
            return blnResult;
        }
        return blnResult;
    };
    AppHolidayComponent.prototype.AddHoliday = function (event) {
        // setting up holiday object to be pushed to service for updating in DB
        var _this = this;
        if (this.validateHolidayData()) {
            this.validationErrorMessage = "";
            this.confirmationService.confirm({
                message: 'Are you sure that you want to perform this action?',
                accept: function () { _this.SaveHoliday(); }
            });
        }
        else {
            return false;
        }
    };
    AppHolidayComponent.prototype.SaveHoliday = function () {
        var _this = this;
        //if (this.validateHolidayData()) {
        this.clsHighlightInvalidData = {};
        this.validationErrorMessage = "";
        this.blnValidationResult = false;
        this.blnPushDataToDatabase = true;
        this.holiday = new HolidayTypesValue();
        this.holiday.HolidayType = this.selectedHolidayType;
        this.holiday.$type = '';
        this.holiday.Date = this.selectedHolidayDate;
        if (this.selectedHolidayType.toUpperCase() === "GLOBAL") {
            this.holiday.Region = null;
        }
        else if (this.selectedHolidayType.toUpperCase() === "REGIONAL") {
            this.holiday.Region = new RegionType();
            var selectedRegionType_1 = new RegionType();
            var regionSelected_1 = this.selectedRegion;
            this.regions.forEach(function (item) {
                var region = new RegionType();
                region = item;
                if (region.Name == regionSelected_1) {
                    selectedRegionType_1 = region;
                }
            });
            this.holiday.Region = selectedRegionType_1;
        }
        this.holiday.MarkAsDeleted = false;
        this.holiday.Name = this.holidayDescription;
        this.holiday.IsUpdateTimingException = false;
        this.holiday.Created = null;
        this.holiday.CreatedBy = null;
        this.holiday.Updated = null;
        this.holiday.UpdatedBy = null;
        this.holiday.Id = 0;
        this.holidays.push(this.holiday);
        var action = 'add';
        this.holidayService.updateHolidayObservable(this.holiday)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
        //}
        //else {
        //    alert("Data not sent.");
        //}
    };
    AppHolidayComponent.prototype.delete = function (event) {
        var _this = this;
        //console.log(event);
        this.confirmationService.confirm({
            message: 'Are you sure that you want to perform this action?',
            accept: function () { _this.deleteHoliday(event); }
        });
    };
    AppHolidayComponent.prototype.deleteHoliday = function (event) {
        var _this = this;
        this.currentHolidayType = event;
        //console.log(this.currentHolidayType);
        this.holidays.splice(this.findHolidayTypeIndexForDelete(), 1);
        var action = 'delete';
        this.currentHolidayType.MarkAsDeleted = true;
        this.holidayService.deleteHolidayObservable(this.currentHolidayType)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
        this.holiday = null;
    };
    AppHolidayComponent.prototype.ShowMessageOnSaveorDeleteData = function (data, action) {
        //console.log(data);
        this.blnSavedOrDeleted = true;
        // applying class to the message
        this.clsMessage = {};
        this.clsMessage = {
            successMessage: true,
            failureMessage: false
        };
        this.msgs = [];
        if (action == "add") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
            this.Message = "Data saved successfully";
        }
        else if (action == "delete") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' });
            this.Message = "Data deleted successfully";
        }
        ;
    };
    AppHolidayComponent.prototype.findHolidayTypeIndexForDelete = function () {
        return this.holidays.indexOf(this.currentHolidayType);
    };
    AppHolidayComponent.prototype.findSelectedRegionIndex = function () {
        return this.regions.indexOf(this.selectedRegionType);
    };
    AppHolidayComponent.prototype.HolidayTypeChange = function (HolidayType) {
        if (HolidayType.toUpperCase() == "GLOBAL")
            this.blnDisableRegion = true;
        else
            this.blnDisableRegion = false;
    };
    AppHolidayComponent.prototype.isDate = function (currVal) {
        if (currVal == '')
            return false;
        var test = '';
        //Declare Regex  
        var rxDatePattern = new RegExp(/(([0-9])|([0-2][0-9])|([3][0-1]))\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s\d{4}$/);
        var dtDate = currVal.match(rxDatePattern); // is format OK?
        if (dtDate == null)
            return false;
        var dtArray = dtDate[0].split(' ');
        var dtDay = parseInt(dtArray[0]);
        var dtMonth = dtArray[1];
        var dtYear = parseInt(dtArray[2]);
        // need to change to lowerCase because switch is
        // case sensitive
        switch (dtMonth.toLowerCase()) {
            case 'jan':
                dtMonth = '01';
                break;
            case 'feb':
                dtMonth = '02';
                break;
            case 'mar':
                dtMonth = '03';
                break;
            case 'apr':
                dtMonth = '04';
                break;
            case 'may':
                dtMonth = '05';
                break;
            case 'jun':
                dtMonth = '06';
                break;
            case 'jul':
                dtMonth = '07';
                break;
            case 'aug':
                dtMonth = '08';
                break;
            case 'sep':
                dtMonth = '09';
                break;
            case 'oct':
                dtMonth = '10';
                break;
            case 'nov':
                dtMonth = '11';
                break;
            case 'dec':
                dtMonth = '12';
                break;
        }
        // convert date to number
        dtMonth = parseInt(dtMonth);
        if (isNaN(dtMonth))
            return false;
        else if (dtMonth < 1 || dtMonth > 12)
            return false;
        else if (dtDay < 1 || dtDay > 31)
            return false;
        else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
            return false;
        else if (dtMonth == 2) {
            var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
            if (dtDay > 29 || (dtDay == 29 && !isleap))
                return false;
        }
        return true;
    };
    AppHolidayComponent.prototype.canDeactivate = function () {
        //if (!this.blnPushDataToDatabase) {
        //    this.confirmationService.confirm({
        //        message: 'Are you sure that you want to navigate without saving the data?',
        //        accept: () => {
        //            let action: string = "save";
        //            this.SaveDataToDataBase(action);
        //        }
        //    });
        //}
        //return this.blnPushDataToDatabase;
        if (!this.blnPushDataToDatabase) {
            return confirm("Are you sure that you want to navigate without saving the data?");
        }
        return true;
    };
    AppHolidayComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/holiday/app.holiday.component.html'
        }), 
        __metadata('design:paramtypes', [app_regionService_1.RegionsService, app_TPRHolidayService_1.TPRHolidayService, primeng_1.ConfirmationService])
    ], AppHolidayComponent);
    return AppHolidayComponent;
}());
exports.AppHolidayComponent = AppHolidayComponent;
var HolidayTypesValue = (function () {
    function HolidayTypesValue(HolidayType, $type, Date, Region, MarkAsDeleted, Name, IsUpdateTimingException, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if (HolidayType === void 0) { HolidayType = null; }
        if ($type === void 0) { $type = null; }
        if (Date === void 0) { Date = null; }
        if (Region === void 0) { Region = null; }
        if (MarkAsDeleted === void 0) { MarkAsDeleted = false; }
        if (Name === void 0) { Name = null; }
        if (IsUpdateTimingException === void 0) { IsUpdateTimingException = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.HolidayType = HolidayType;
        this.$type = $type;
        this.Date = Date;
        this.Region = Region;
        this.MarkAsDeleted = MarkAsDeleted;
        this.Name = Name;
        this.IsUpdateTimingException = IsUpdateTimingException;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return HolidayTypesValue;
}());
var RegionType = (function () {
    function RegionType($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return RegionType;
}());
//# sourceMappingURL=app.holiday.component.js.map