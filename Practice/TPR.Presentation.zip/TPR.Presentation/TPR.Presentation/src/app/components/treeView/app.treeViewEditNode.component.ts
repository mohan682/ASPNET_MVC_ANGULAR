﻿import { Component, OnInit, PipeTransform, Pipe, Input } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';

import { Footer } from 'primeng/primeng';
import { TreeModule } from 'primeng/primeng';
import { TreeNode } from 'primeng/primeng';
import { MenuModule, MenuItem } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { TPRHierarchyservice } from '../../service/app.TPRHierarchyservice';
import { TPRNodeTypeService } from '../../service/app.TPRNodeTypeService';
import { RegionsService } from '../../service/app.regionService';
import { TPRProfitAlertGroupsService } from '../../service/app.TPRProfitAlertGroupsService';
import { TPRTagsService } from '../../service/app.TPRTagsService';
import { TPRDividendPartnersService } from '../../service/app.TPRDividendPartnersService';
import { TPRBusinessSegmentsService } from '../../service/app.TPRBusinessSegmentsService';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';

import { AppTprHierarchyComponent } from '../treeView/app.treeView.component';

import IRegionsValue = RegionNamespace.IRegionValue;
import IRootObject = HierarchyNamespace.IRootObject;
import Children = HierarchyNamespace.Children;

import IHierarchyEditNode = HierarchyNamespace.IHierarchyEditNode;
import IHierarchyEditNode_Node = HierarchyNamespace.IHierarchyEditNode_Node;
import IHierarchyEditNode_Node_NodeType = HierarchyNamespace.IHierarchyEditNode_Node_NodeType;
import IHierarchyEditNode_Node_InputData = HierarchyNamespace.IHierarchyEditNode_Node_InputData;
import IHierarchyEditNode_Node_OutputData = HierarchyNamespace.IHierarchyEditNode_Node_OutputData;
import IHierarchyEditNode_Node_AllDatesForCurrentReportingDate = HierarchyNamespace.IHierarchyEditNode_Node_AllDatesForCurrentReportingDate;
import IHierarchyEditNode_Node_InputData_Values = HierarchyNamespace.IHierarchyEditNode_Node_InputData_Values;
import IHierarchyEditNode_Node_OutputData_Values = HierarchyNamespace.IHierarchyEditNode_Node_OutputData_Values;
import IHierarchyEditNode_Node_InputNameMappings = HierarchyNamespace.IHierarchyEditNode_Node_InputNameMappings;
import IHierarchyEditNode_Node_InputNameMappings_Value = HierarchyNamespace.IHierarchyEditNode_Node_InputNameMappings_Value;
import IHierarchyNodePostData = HierarchyNamespace.IHierarchyNodePostData;
import IHierarchyNodePostData_Node = HierarchyNamespace.IHierarchyNodePostData_Node;

import IHierarchyEditNode_WorkingCapital = HierarchyNamespace.IHierarchyEditNode_WorkingCapital;

import IHierarchyEditNode_AlertGroups = HierarchyNamespace.IHierarchyEditNode_AlertGroups;
import IHierarchyEditNode_AlertGroups_Values = HierarchyNamespace.IHierarchyEditNode_AlertGroups_Values;
import IHierarchyEditNode_AlertGroups_Values_Alerts = HierarchyNamespace.IHierarchyEditNode_AlertGroups_Values_Alerts;
import IHierarchyEditNode_AlertGroups_Values_Alerts_Values = HierarchyNamespace.IHierarchyEditNode_AlertGroups_Values_Alerts_Values;
import IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts = HierarchyNamespace.IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts;
import IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values = HierarchyNamespace.IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values;
import IHierarchyEditNode_AlertGroups_Values_Members = HierarchyNamespace.IHierarchyEditNode_AlertGroups_Values_Members;
import IHierarchyEditNode_AlertGroups_Values_Members_Values = HierarchyNamespace.IHierarchyEditNode_AlertGroups_Values_Members_Values;
import IHierarchyNodePostData_Alerts = HierarchyNamespace.IHierarchyNodePostData_Alerts;

import IHierarchyEditNode_MVarRegion = HierarchyNamespace.IHierarchyEditNode_MVarRegion;

import IHierarchyEditNode_Tags = HierarchyNamespace.IHierarchyEditNode_Tags;
import IHierarchyEditNode_Tags_Values = HierarchyNamespace.IHierarchyEditNode_Tags_Values;
import ITagsValue = TagsNameSpace.ITagsValue;

import IHierarchyEditNode_RegionalAllocations = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations;
import IHierarchyEditNode_RegionalAllocations_Values = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData_Values = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData_Values;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData_Values = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData_Values;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings_Values = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings_Values;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate;
import IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate = HierarchyNamespace.IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate;
import IHierarchyNodePostData_RegionalAllocations = HierarchyNamespace.IHierarchyNodePostData_RegionalAllocations;
import IHierarchyNodePostData_RegionalAllocations_RegionNode = HierarchyNamespace.IHierarchyNodePostData_RegionalAllocations_RegionNode;

import IHierarchyEditNode_DividendPartnerAllocations = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations;
import IHierarchyEditNode_DividendPartnerAllocations_Values = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData_Values = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData_Values;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings_Values = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings_Values;
import IDividendPartnerValue = DividendPartnerNameSpace.IDividendPartnerValue;
import IBusinessSegment = DividendPartnerNameSpace.IBusinessSegment;
import IHierarchyNodePostData_DividendPartnerAllocations = HierarchyNamespace.IHierarchyNodePostData_DividendPartnerAllocations;
import IHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode = HierarchyNamespace.IHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode;

import IHierarchyEditNode_Plans = HierarchyNamespace.IHierarchyEditNode_Plans;
import IHierarchyEditNode_Plans_Values = HierarchyNamespace.IHierarchyEditNode_Plans_Values;
import IHierarchyEditNode_Plans_Values_DividendPartner = HierarchyNamespace.IHierarchyEditNode_Plans_Values_DividendPartner;
import IHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment = HierarchyNamespace.IHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment;
import IHierarchyEditNode_Plans_Values_Region = HierarchyNamespace.IHierarchyEditNode_Plans_Values_Region;
import IHierarchyEditNode_Plans_Values_PlanValues = HierarchyNamespace.IHierarchyEditNode_Plans_Values_PlanValues;
import IHierarchyEditNode_Plans_Values_PlanValues_Values = HierarchyNamespace.IHierarchyEditNode_Plans_Values_PlanValues_Values;
import IHierarchyNodePostData_Plans = HierarchyNamespace.IHierarchyNodePostData_Plans;
import IHierarchyNodePostData_Plans_DividendPartner = HierarchyNamespace.IHierarchyNodePostData_Plans_DividendPartner;
import IHierarchyNodePostData_Plans_DividendPartner_BusinessSegment = HierarchyNamespace.IHierarchyNodePostData_Plans_DividendPartner_BusinessSegment;
import IHierarchyNodePostData_Plans_Region = HierarchyNamespace.IHierarchyNodePostData_Plans_Region;
import IHierarchyNodePostData_Plans_PlanValues = HierarchyNamespace.IHierarchyNodePostData_Plans_PlanValues;

import IUserRolesValue = CommonNameSpace.IUserRolesValue;
import IUserRolesValues = CommonNameSpace.IUserRolesValues;
import IUsersValue = CommonNameSpace.IUsersValue;

@Component({
    selector: 'my-app',
    templateUrl: 'app.treeViewEditNode.component.html'
})
export class AppTprHierarchyEditNodeComponent implements OnInit {
    hierarchy: any;
    intSelectedNodeID: number;
    blnShowModalPouUp: boolean = true;
    blnNodePropertiesShow: boolean = false;
    blnMappingNamesShow: boolean = false;
    blnRegionAllocationShow: boolean = false;
    blnTagAllocationShow: boolean = false;
    blnDividendAllocationShow: boolean = false;
    blnPnLPlanShow: boolean = false;
    blnPlanForDividendPartnersShow: boolean = false;
    blnMVARShow: boolean = false;
    blnProfitAlertGroupShow: boolean = false;
    blnWorkingCapitalShow: boolean = false;
    editChildMenuItems: MenuItem[] = [];
    businessDate: string = '';
    editNodeCompleteData: IHierarchyEditNode;
    NodeName: string = ""; //added EH
    nodeTypes: IHierarchyEditNode_Node_NodeType[] = [];
    nodes: SelectItem[] = [];
    updateTimings: SelectItem[] = [];
    selectedUpdateTiming: number;
    blndisableSelectedUpdateTimingField: boolean = false;
    blnEnableregionAllocation: boolean = true;
    selectedNode: IRootObject = new RootValue();
    mainListOfTree: IRootObject[] = [];
    nodeArrays: IRootObject[] = [];
    nodeNameCorrespondingToUpdateTiming: string;
    blnPnlHolderDisabled: boolean = false;
    ytdValues: IHierarchyEditNode_Node_InputData_Values[] = [];
    mappingName: IHierarchyEditNode_Node_InputNameMappings_Value = new clsHierarchyEditNode_Node_InputNameMappings_Value();
    mappingNames: IHierarchyEditNode_Node_InputNameMappings_Value[] = [];
    mappingNamecols: any[] = [];
    clsHierarchyEditNode_WorkingCapital: IHierarchyEditNode_WorkingCapital = new clsHierarchyEditNode_WorkingCapital();
    regions: IRegionsValue[] = [];
    regionNames: SelectItem[] = [];
    blnWorkingCapitalRegion: boolean = false;
    blnDisableWorkingCapital: boolean = false;
    strSelectedWorkingCapitalRegionName: string;
    profitAlertGroupsValuesMasterData: IHierarchyEditNode_AlertGroups_Values[] = [];
    profitAlertGroupsValues: IHierarchyEditNode_AlertGroups_Values[] = [];
    profitAlertGroupNames: SelectItem[] = [];
    profitAlertGroupArrays: ProfitAlertGroupArray[] = [];
    strSelectedProfitAlertGroupName: string;
    strSelectedGroupUpdateTiming: string;
    profitAlertGroup: clsHierarchyEditNode_AlertGroups_Values = new clsHierarchyEditNode_AlertGroups_Values();
    profitAlertGroupcols: any[] = [];

    blnMVarHolder: boolean = false;
    blnMVarHolderDisabled: boolean = false;
    blnMVarUpdateTiming: boolean = false;
    strSelectedMVarUpdateTiming: string;
    MVarUpdateTimings: SelectItem[] = [];
    regionNamesMVar: SelectItem[] = [];
    strSelectedMVarRegionName: string;

    tagTypes: ITagsValue[] = [];
    tags: IHierarchyEditNode_Tags_Values[] = [];
    strSelectedTagName: string;
    tagNames: SelectItem[] = [];
    tag: clsHierarchyEditNode_Tags_Values = new clsHierarchyEditNode_Tags_Values();

    nodeDataForPostToServer: IHierarchyNodePostData = new clsHierarchyNodePostData();
    nodeAlertGroups: IHierarchyNodePostData_Alerts = new clsHierarchyNodePostData_Alerts();

    regionAllocations: IHierarchyEditNode_RegionalAllocations_Values[] = [];
    regionNamesRegionAllocation: SelectItem[] = [];
    strSelectedRegionAllocationName: string;
    strSelectedSplitType: string = "DM";
    strRegionAllocationPercentage: string = "0";
    strRegionAllocationValueCheck: string = "";
    clsRegionAllocationValueCheck = {};

    dividendPartnerTypes: IDividendPartnerValue[] = [];
    businessSegments: IBusinessSegment[] = [];
    dividendPartnerAllocations: IHierarchyEditNode_DividendPartnerAllocations_Values[] = [];
    dividendPartnerNames: SelectItem[] = [];
    strSelectedDividendAllocationName: string;
    strDividendAllocationPercentage: string = "0";
    strDividendAllocationValueCheck: string = "";
    clsDividendAllocationValueCheck = {};

    regionNamesPlanRegionAllocation: SelectItem[] = [];
    strSelectedPnlPlanRegionAllocationName: string;
    pnlPlans: IHierarchyEditNode_Plans_Values[] = [];
    pnlPlansArray: clsPlanDataPerRegion[] = [];
    selectedPnlPlan: clsPlanDataPerRegion = new clsPlanDataPerRegion();
    pnlPlanYears: SelectItem[] = [];
    completePnlPlanYearToMonthPerRegion: clsPnlPlanYearToMonthPerRegion[] = [];
    filteredPnlPlanYearToMonthPerRegion: clsPnlPlanYearToMonthPerRegion[] = [];
    filteredPnLPlanPerRegion: clsPnlPlanYearToMonthPerRegion[] = [];
    strSelectedPnlPlanYear: string;

    dividendPartnerNamesDividendPlanAllocation: SelectItem[] = [];
    strSelectedDividendPlanDividendPartnerName: string;
    regionNamesDividendPlanAllocation: SelectItem[] = [];
    strSelectedDividendPlanRegionAllocationName: string;
    dividendPlanYears: SelectItem[] = [];
    strSelectedDividendPlanYear: string;
    dividendPlans: IHierarchyEditNode_Plans_Values[] = [];
    dividendPlansArray: clsPlanDataPerDividendPartner[] = [];
    selectedDividendPlan: clsPlanDataPerDividendPartner = new clsPlanDataPerDividendPartner();
    completeDividendPlanYearToMonthPerRegion: clsDividendPlanYearToMonthPerRegion[] = [];
    filteredDividendPlanYearToMonthPerRegion: clsDividendPlanYearToMonthPerRegion[] = [];
    filteredDividendPlanPerDividendPartnerAndRegion: clsDividendPlanYearToMonthPerRegion[] = [];
    cols: any[] = [];

    blnDisableControlsTillSaveCompletes: boolean = false;
    blnShowConfirmDialog: boolean = false;

    blnShowValidationDialog: boolean = false;
    strValidationHeader: string = "";
    strValidationMessage: string = "";
    isNodeInactive: boolean;
    isRequesting: boolean;
    moveNodeArrays: string[] = [];
    blnShowSaveDialog: boolean = false;
    updateHierarchyHeader: string = "";
    updateHierarchyMessage: string = "";
    showUpdateHierarchyFooter: boolean = false;
    strLoaderMessage: string = "";

    availableRoles: IUserRolesValues = new UserRolesValues();
    userRoles: string[] = [];

    canEditNode: boolean = false;
    canEnterValue: boolean = false;
    canEditHierarchy: boolean = false;
    constants: any;

    constructor(
        private tPRHierarchyservice: TPRHierarchyservice,
        private router: Router,
        private route: ActivatedRoute,
        private tPRNodeTypeService: TPRNodeTypeService,
        private confirmationService: ConfirmationService,
        private regionsService: RegionsService,
        private tprPAGService: TPRProfitAlertGroupsService,
        private tPRTagsService: TPRTagsService,
        private tprDividendPartnersService: TPRDividendPartnersService,
        private tprBusinessSegmentsService: TPRBusinessSegmentsService,
        private tprCommonService: TPRCommonService,
        private appTprHierarchyComponent: AppTprHierarchyComponent,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        //debugger;
        this.isRequesting = true;

        this.editChildMenuItems = [
            { label: 'Node Properties', icon: 'fa fa-table', command: (event) => this.EditNodeProperties(), disabled: true },
            { label: 'Mapping Names', icon: 'fa fa-table', command: (event) => this.EditMappingNames(), disabled: true },
            { label: 'Region Allocation', icon: 'fa fa-table', command: (event) => this.EditRegionAllocation(), disabled: true },
            { label: 'Tag Allocation', icon: 'fa fa-table', command: (event) => this.EditTagAllocation(), disabled: true },
            { label: 'Dividend Allocation', icon: 'fa fa-table', command: (event) => this.EditDividendAllocation(), disabled: true },
            { label: 'Pnl Plan', icon: 'fa fa-table', command: (event) => this.EditPnLPlan(), disabled: true },
            { label: 'Plan For Dividend Partners', icon: 'fa fa-table', command: (event) => this.EditPlanForDividendPartners(), disabled: true },
            { label: 'MVAR', icon: 'fa fa-table', command: (event) => this.EditMVAR(), disabled: true },
            { label: 'Profit Alert Groups', icon: 'fa fa-table', command: (event) => this.EditProfitAlertGroups(), disabled: true },
            { label: 'Working Capital', icon: 'fa fa-table', command: (event) => this.EditWorkingCapital(), disabled: true },
        ];

        // To get the selected node ID from the route service
        this.route.params.subscribe((params: Params) => {
            this.intSelectedNodeID = +params['nodeId'];
        });

        this.businessDate = localStorage.getItem("BusinessDate");

        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            //console.log("User Roles from Local Storage ->", this.userRoles);
        }
        else {
            this.tprCommonService.getUserRolesObservable()
                .subscribe(data => this.setUserRolesData(data));
        }

        this.serviceHelper.importSettings()
            .subscribe(data => this.getConstants(data));

        // call the service to fetch the node related data
        this.tPRHierarchyservice.getNodeLevelDataForEdit(this.intSelectedNodeID, this.businessDate)
            .subscribe(data => {
                this.editNodeCompleteData = data.Result;
                this.editNodeCompleteData.Node.Updated = this.editNodeCompleteData ? this.tprCommonService.getFormattedSystemDate(new Date(this.editNodeCompleteData.Node.Updated)) : "";
                //console.log("editNodeCompleteData -->,", this.editNodeCompleteData);

                localStorage.setItem("nodeActive", JSON.stringify(this.editNodeCompleteData.Node.IsActive));
                localStorage.getItem("nodeActive") != null ? this.isNodeInactive = <boolean>JSON.parse(localStorage.getItem("nodeActive")) : null;

                // get the hierarchy data
                this.getHierarchyData();

                //setting working capital                
                if (this.editNodeCompleteData.WorkingCapitalRegion) {
                    this.blnWorkingCapitalRegion = true;
                    this.strSelectedWorkingCapitalRegionName = this.editNodeCompleteData.WorkingCapitalRegion.Name;
                }

                // disabling IsPnlHolder
                this.ytdValues = this.editNodeCompleteData ? this.editNodeCompleteData.Node.InputData.$values.filter(ytdValues => ytdValues.InputDataType == "YTD") : [];
                this.blnPnlHolderDisabled = (this.ytdValues.length > 0 || (this.editNodeCompleteData && this.editNodeCompleteData.HasChildren)) ? true : false;

                //split type
                this.strSelectedSplitType = this.editNodeCompleteData.SplitType ? this.editNodeCompleteData.SplitType : this.strSelectedSplitType;

                // to set the region allocation value;
                let totalRegionAllocation: number = 0;

                this.editNodeCompleteData.RegionalAllocations.$values.forEach(regionAllocation => {
                    totalRegionAllocation += regionAllocation.Percentage;
                });

                this.strRegionAllocationValueCheck = totalRegionAllocation.toString();

                // to set the dividend partner allocation value;
                let totalDividendPartnerAllocation: number = 0;

                this.editNodeCompleteData.DividendPartnerAllocations.$values.forEach(dividendPartnerAllocation => {
                    totalDividendPartnerAllocation += dividendPartnerAllocation.Percentage;
                });

                this.strDividendAllocationValueCheck = totalDividendPartnerAllocation.toString();

                // set initial pnlPlan for Region
                this.setPnlPlanForRegion();

                // set initial dividendPlan for DividendPartner
                this.setDividendPlanForDividendPartner();
                //added EH
                this.NodeName = this.editNodeCompleteData.Node.Name;
            });


        //get the node master data
        this.tPRNodeTypeService.getNodeTypesObservable()
            .subscribe(data => this.setNodeTypeData(data));

        //get the region master data
        //get the regions data
        this.regionsService.getRegionsObservable()
            .subscribe(data => {
                this.setRegionsData(data)
                this.setRegionsDataForMVar(data);
                this.setRegionsDataForRegionAllocation(data);
                this.setRegionsDataForPlanRegionAllocation(data);
                this.setRegionsDataForDividendPlanRegionAllocation(data);
            });

        // to get the Dividend partners data
        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(data => {
                this.setDividendPartnerData(data);
                this.setDividendPartnerDataForDividendPlanAllocation(data);
            });

        // to get the business segments data
        this.tprBusinessSegmentsService.getBusinessSegmentsObservable()
            .subscribe(data => this.setBusinessSegmentsData(data));

        //get the profit Alert group master data
        this.tprPAGService.getProfitAlertGroupsObservable()
            .subscribe(data => this.setProfitAlertGroupDate(data));

        // to set the update timing template field.
        this.updateTimings = [
            { label: "Not Set", value: null },
            { label: "R-1", value: "-1" },
            { label: "R-2", value: "-2" }
        ];

        // to set the MVarupdate timing field.        
        this.MVarUpdateTimings = [
            { label: "", value: null },
            { label: "R-1", value: "-1" },
            { label: "R-2", value: "-2" }
        ];

        // to get the list of tags
        this.tPRTagsService.getTagsObservable()
            .subscribe(data => {
                this.setTagTypeData(data)
            });

        this.setPlanYears();
        this.setDividendPlanYears();
    }

    EditNodeProperties() {
        this.ResetAllTemplate();
        this.blnNodePropertiesShow = true;
    }

    EditMappingNames() {
        this.ResetAllTemplate();
        this.blnMappingNamesShow = true;

        //debugger;
        this.mappingNames = [];
        this.mappingNames = this.editNodeCompleteData.Node.InputNameMappings.$values;
        //console.log("mapping names ->", this.mappingNames);

        this.mappingNames.forEach(mappingName => {
            if (mappingName.Updated) {
                if (mappingName.Updated.endsWith("Z")) {// called for the first time
                    mappingName.Updated = mappingName.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(mappingName.Updated)) : null;
                }
                else {// called for subsequent time to format the date
                    mappingName.Updated = mappingName.Updated + "Z";
                    mappingName.Updated = mappingName.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(mappingName.Updated)) : null;
                }
            }
        });

        this.mappingNamecols = [
            { field: 'Name', header: 'Name' },
            { field: 'FeedSource', header: 'Source' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
    }

    EditRegionAllocation() {
        this.ResetAllTemplate();
        this.blnRegionAllocationShow = true;

        this.regionAllocations = this.editNodeCompleteData.RegionalAllocations.$values;

        if (this.regionAllocations.length > 0) {
            this.regionAllocations.forEach(regionAllocation => {
                //regionAllocation.Updated = regionAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(regionAllocation.Updated)) : null;

                if (regionAllocation.Updated) {
                    if (regionAllocation.Updated.endsWith("Z")) {// called for the first time
                        regionAllocation.Updated = regionAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(regionAllocation.Updated)) : null;
                    }
                    else {// called for subsequent time to format the date
                        regionAllocation.Updated = regionAllocation.Updated + "Z";
                        regionAllocation.Updated = regionAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(regionAllocation.Updated)) : null;
                    }
                }

                let regionAllocationName = regionAllocation.RegionNode.Name;

                let regionAllocationItem = this.regionNamesRegionAllocation.find(item => item.value == regionAllocationName);

                if (regionAllocationItem) {
                    this.regionNamesRegionAllocation.splice(this.regionNamesRegionAllocation.indexOf(regionAllocationItem), 1);
                }
            });
        }
        //console.log("regionAllocations ->", this.regionAllocations);
    }

    EditTagAllocation() {
        this.ResetAllTemplate();
        this.blnTagAllocationShow = true;

        this.tags = this.editNodeCompleteData.Tags.$values;

        if (this.tags.length > 0) {
            this.tags.forEach(tag => {
                //tag.Updated = tag.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(tag.Updated)) : null;

                if (tag.Updated) {
                    if (tag.Updated.endsWith("Z")) {// called for the first time
                        tag.Updated = tag.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(tag.Updated)) : null;
                    }
                    else {// called for subsequent time to format the date
                        tag.Updated = tag.Updated + "Z";
                        tag.Updated = tag.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(tag.Updated)) : null;
                    }
                }

                let Name = tag.Name;

                let selectItem = this.tagNames.find(item => item.value == Name);

                if (selectItem) {
                    this.tagNames.splice(this.tagNames.indexOf(selectItem), 1);
                }
            });
        }
    }

    EditDividendAllocation() {
        this.ResetAllTemplate();
        this.blnDividendAllocationShow = true;

        this.dividendPartnerAllocations = this.editNodeCompleteData.DividendPartnerAllocations.$values;

        if (this.dividendPartnerAllocations.length > 0) {
            this.dividendPartnerAllocations.forEach(dividendPartnerAllocation => {
                //dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(dividendPartnerAllocation.Updated)) : null;

                if (dividendPartnerAllocation.Updated) {
                    if (dividendPartnerAllocation.Updated.endsWith("Z")) {// called for the first time
                        dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(dividendPartnerAllocation.Updated)) : null;
                    }
                    else {// called for subsequent time to format the date
                        dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated + "Z";
                        dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(dividendPartnerAllocation.Updated)) : null;
                    }
                }

                let dividendPartnerAllocationName = dividendPartnerAllocation.DividendPartnerNode.Name;

                let dividendPartnerAllocationItem = this.dividendPartnerNames.find(item => item.value == dividendPartnerAllocationName);

                if (dividendPartnerAllocationItem) {
                    this.dividendPartnerNames.splice(this.dividendPartnerNames.indexOf(dividendPartnerAllocationItem), 1);
                }
            });
        }
    }

    EditPnLPlan() {
        this.ResetAllTemplate();
        this.blnPnLPlanShow = true;

        this.setPlanYears();

        this.strSelectedPnlPlanYear = this.pnlPlanYears[0].value;

        if (this.pnlPlansArray && this.pnlPlansArray.length > 0) {
            this.selectedPnlPlan = this.pnlPlansArray[0];
        }

        this.filteredPnlPlanYearToMonthPerRegion = [];
        this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
            .filter(plnPlan => plnPlan.strYear == this.strSelectedPnlPlanYear && plnPlan.strRegionName == this.selectedPnlPlan.strRegionName);
    }

    setPlanYears() {
        let currentYear = new Date().getFullYear();

        this.pnlPlanYears = [];
        this.pnlPlanYears.push({ label: currentYear.toString(), value: currentYear.toString() });

        for (let count: number = 1; count < 10; count++) {
            let nextYear: number = ++currentYear;
            this.pnlPlanYears.push({ label: nextYear.toString(), value: nextYear.toString() });
        }
    }

    EditPlanForDividendPartners() {
        this.ResetAllTemplate();
        this.blnPlanForDividendPartnersShow = true;

        this.cols = [
            { field: 'strRegionName', header: 'Region' },
            { field: 'TotalPlan', header: 'Total Plan' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];

        this.setDividendPlanYears();

        this.strSelectedDividendPlanYear = this.dividendPlanYears[0].value;

        if (this.dividendPlansArray && this.dividendPlansArray.length > 0) {
            this.selectedDividendPlan = this.dividendPlansArray[0];
        }

        this.filteredDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .filter(dividendPlan => dividendPlan.strYear == this.strSelectedDividendPlanYear
                && dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
                && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName);
    }

    setDividendPlanYears() {
        let currentYear = new Date().getFullYear();

        this.dividendPlanYears = [];
        this.dividendPlanYears.push({ label: currentYear.toString(), value: currentYear.toString() });

        for (let count: number = 1; count < 10; count++) {
            let nextYear: number = ++currentYear;
            this.dividendPlanYears.push({ label: nextYear.toString(), value: nextYear.toString() });
        }
    }

    EditMVAR() {
        //debugger;
        this.ResetAllTemplate();
        this.blnMVARShow = true;

        this.strSelectedMVarUpdateTiming = this.editNodeCompleteData.MVarUpdateTiming ? this.editNodeCompleteData.MVarUpdateTiming.toString() : "";
        this.strSelectedMVarRegionName = this.editNodeCompleteData.MVarRegion ? this.editNodeCompleteData.MVarRegion.Name : "NotSet";
        this.blnMVarHolder = this.editNodeCompleteData.Node.HasMVaR || (this.editNodeCompleteData.MVarUpdateTiming != null && this.editNodeCompleteData.MVarUpdateTiming != 0);
        this.blnMVarHolderDisabled = this.editNodeCompleteData && this.editNodeCompleteData.Node.HasMVaR;

        if (this.blnMVarHolder) {
            let item = this.MVarUpdateTimings.find(updateTiming => updateTiming.value == null);
            if (item) {
                this.MVarUpdateTimings.splice(this.MVarUpdateTimings.indexOf(item), 1);
            }
        }
    }

    EditProfitAlertGroups() {
        this.ResetAllTemplate();
        this.blnProfitAlertGroupShow = true;

        this.profitAlertGroupsValues = this.editNodeCompleteData.AlertGroups.$values;

        this.profitAlertGroupcols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedTiming', header: 'Updated Timing' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];

        if (this.profitAlertGroupsValues.length > 0) {
            this.profitAlertGroupsValues.forEach(group => {
                //group.Updated = group.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(group.Updated)) : null;

                if (group.Updated) {
                    if (group.Updated.endsWith("Z")) {// called for the first time
                        group.Updated = group.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(group.Updated)) : null;
                    }
                    else {// called for subsequent time to format the date
                        group.Updated = group.Updated + "Z";
                        group.Updated = group.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(group.Updated)) : null;
                    }
                }

                let Name = group.Name;

                let selectItem = this.profitAlertGroupNames.find(item => item.value == Name);

                if (selectItem) {
                    this.profitAlertGroupNames.splice(this.profitAlertGroupNames.indexOf(selectItem), 1);
                }
            });
        }
    }

    EditWorkingCapital() {
        //debugger;
        this.ResetAllTemplate();
        this.blnWorkingCapitalShow = true;

        // if (!(this.editNodeCompleteData.Node.HasWorkingCapital && (this.selectedUpdateTiming < 0))) {
        //     this.blnDisableWorkingCapital = true;
        //     this.blnWorkingCapitalRegion = false;
        // }

        if (!this.editNodeCompleteData.Node.HasWorkingCapital && ((this.editNodeCompleteData.UpdateTiming && this.editNodeCompleteData.UpdateTiming != 0)
            || this.selectedUpdateTiming != null)) {
            this.blnDisableWorkingCapital = false;
        }
        else {
            this.blnDisableWorkingCapital = true;
        }

        // if (this.editNodeCompleteData.Node.HasWorkingCapital || (!this.editNodeCompleteData.UpdateTiming && this.selectedUpdateTiming == null)) {
        //     this.blnDisableWorkingCapital = true;
        // }

        if (this.editNodeCompleteData.WorkingCapitalRegion) {
            this.blnWorkingCapitalRegion = true;
            this.strSelectedWorkingCapitalRegionName = this.editNodeCompleteData.WorkingCapitalRegion.Name;
        }
        else {
            this.blnWorkingCapitalRegion = false;
        }
    }

    Cancel() {
        //this.blnShowModalPouUp = false;
        this.router.navigate(['/hierarchy']);
    }

    ValidateNodeSave(): boolean {
        //debugger;
        let result: boolean = true;
        let uniquenessResult: boolean = false;

        // Node name validation for not empty.
        if (this.editNodeCompleteData.Node.Name == null || this.editNodeCompleteData.Node.Name == undefined || this.editNodeCompleteData.Node.Name.length == 0) {
            //alert("Node name should not be empty.");
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Node name should not be empty.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }

        // Validation for verifying whether the node is active or not.
        if (!this.isNodeInactive) {
            if (!this.editNodeCompleteData.Node.IsActive) {
                this.blnShowValidationDialog = true;
                this.strValidationHeader = "Validation Error";
                this.strValidationMessage = "No changes allowed as node is inactive.";
                this.blnDisableControlsTillSaveCompletes = false;
                result = false;
                return result;
            }
        }

        // Region allocation validation for proper value for a Pnl holder
        if (this.editNodeCompleteData.Node.IsPnlHolder && this.strRegionAllocationValueCheck != "100") {
            //console.log("Node ->", this.editNodeCompleteData.Node);
            //alert("Error: The PNL holder node should have an allocated region. The total of all the region allocations has to be 100 percent.");
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "The PNL holder node should have an allocated region. The total of all the region allocations has to be 100 percent.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }

        // Dividend allocation validation for proper value
        if (Number(this.strDividendAllocationValueCheck) > 100) {
            //alert("Error: Dividend allocations for the node must not exceed 100 percent.");
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Dividend allocations for the node must not exceed 100 percent.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }

        //Mapping Name validation for empty check
        let emptyMappingName: IHierarchyEditNode_Node_InputNameMappings_Value = this.editNodeCompleteData.Node.InputNameMappings.$values.find(mappingName => mappingName.Name.trim() == "");
        if (emptyMappingName) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Mapping names must have names value.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }

        //Mapping Name validation for uniqueness check check        
        let mappingNamesArray: string[] = [];
        this.editNodeCompleteData.Node.InputNameMappings.$values.forEach(mappingName => mappingNamesArray.push(mappingName.Name.toLowerCase().trim()));
        uniquenessResult = this.checkIfArrayIsUnique(mappingNamesArray);
        if (!uniquenessResult) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Mapping names must have unique name value.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }

        //debugger;
        let blnInvalidPlanValue: boolean = false;
        this.completePnlPlanYearToMonthPerRegion.forEach(pnlPlan => {
            if (isNaN(Number(pnlPlan.strPlanValue))) {
                blnInvalidPlanValue = true;
            }
        });

        if (blnInvalidPlanValue) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Invalid plan value. Plan value should be numeric.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }

        let blnInvalidDividendPlanValue: boolean = false;
        this.completeDividendPlanYearToMonthPerRegion.forEach(dividendPlan => {
            if (isNaN(Number(dividendPlan.strPlanValue))) {
                blnInvalidDividendPlanValue = true;
            }
        });

        if (blnInvalidDividendPlanValue) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation Error";
            this.strValidationMessage = "Invalid dividend plan value. Dividend plan value should be numeric.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }

        // check for node's children with plans
        //debugger;
        this.selectedNode = this.nodeArrays.find(node => node.NodeId == this.intSelectedNodeID);
        //console.log("selected node", this.selectedNode);
        this.moveNodeArrays = [];
        if (this.selectedNode) {
            this.appTprHierarchyComponent.moveNodeArrays = [];
            this.appTprHierarchyComponent.getNodesWithPlans(this.selectedNode);
            this.moveNodeArrays = this.appTprHierarchyComponent.moveNodeArrays;
        }

        //console.log("Plan Nodes ->", this.moveNodeArrays);

        if (this.selectedNode.HasPlans && this.moveNodeArrays.length > 0) {
            this.blnShowSaveDialog = true;
            this.updateHierarchyHeader = "Save changes";
            this.updateHierarchyMessage = "One or more nodes in the hierarchy contains plans. Please review the list below and confirm that you are happy to proceed saving the node.";
            this.updateHierarchyMessage = this.updateHierarchyMessage + "\n";
            this.moveNodeArrays.forEach(planNode => {
                this.updateHierarchyMessage = (this.updateHierarchyMessage + "\n" + planNode);
            });
            this.updateHierarchyMessage = this.updateHierarchyMessage + "\n\n" + "Saving changes to the hierarchy. Are you happy to proceed?"
            this.showUpdateHierarchyFooter = true;

            result = false;
            return result;
        }

        // If all the validation is successful, then return true.
        result = true;
        return result;
    }

    Save() {
        let validationResult: boolean = this.ValidateNodeSave();

        if (!validationResult) {
            this.blnDisableControlsTillSaveCompletes = false;
            return false;
        }
        else {
            this.blnShowSaveDialog = true;
            this.updateHierarchyHeader = "Save changes";
            this.updateHierarchyMessage = "Saving changes to the hierarchy. Are you happy to proceed?"
            this.showUpdateHierarchyFooter = true;
        }
    }

    SaveNodeToDatabase() {
        this.showUpdateHierarchyFooter = false;
        this.blnShowSaveDialog = false;
        this.blnDisableControlsTillSaveCompletes = true;
        //debugger;
        //console.log("edit node complete data on save", this.editNodeCompleteData);

        // Prepare the object for saving the data back to the server.
        // The object will be of the type IHierarchyNodePostData.
        this.nodeDataForPostToServer = new clsHierarchyNodePostData();

        // set property data
        this.nodeDataForPostToServer.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.StructurePropertiesDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

        //debugger;
        this.nodeDataForPostToServer.AlertGroups = [];

        this.profitAlertGroupsValues.forEach(data => {
            //debugger;
            this.nodeAlertGroups = new clsHierarchyNodePostData_Alerts();
            this.nodeAlertGroups.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            this.nodeAlertGroups.Alerts = [];
            this.nodeAlertGroups.Name = data.Name;
            this.nodeAlertGroups.Members = [];
            this.nodeAlertGroups.IsInUse = data.IsInUse;
            this.nodeAlertGroups.UpdateTiming = data.UpdateTiming;
            this.nodeAlertGroups.TradeDate = data.TradeDate;
            this.nodeAlertGroups.ProfitAlertGroupStatusId = data.ProfitAlertGroupStatusId;
            this.nodeAlertGroups.Created = data.Created;
            this.nodeAlertGroups.CreatedBy = data.CreatedBy;
            this.nodeAlertGroups.Updated = data.Updated;
            this.nodeAlertGroups.UpdatedBy = data.UpdatedBy;
            this.nodeAlertGroups.Id = data.Id;

            this.nodeDataForPostToServer.AlertGroups.push(this.nodeAlertGroups);
            //console.log(this.nodeAlertGroups);
        });

        this.nodeDataForPostToServer.BusinessSegmentAllocations = []; // To be changed to proper datatype.
        this.nodeDataForPostToServer.Created = this.editNodeCompleteData.Created;
        this.nodeDataForPostToServer.CreatedBy = this.editNodeCompleteData.CreatedBy;


        if (this.editNodeCompleteData.Node.IsPnlHolder) {
            this.nodeDataForPostToServer.DividendPartnerAllocations = [];

            this.editNodeCompleteData.DividendPartnerAllocations.$values.forEach(dividendPartnerAllocation => {
                let dividendPartnerAllocationForPost: IHierarchyNodePostData_DividendPartnerAllocations = new clsHierarchyNodePostData_DividendPartnerAllocations();

                dividendPartnerAllocationForPost.$type = dividendPartnerAllocation.$type;
                dividendPartnerAllocationForPost.Percentage = dividendPartnerAllocation.Percentage;

                dividendPartnerAllocationForPost.DividendPartnerNode = new clsHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode();
                dividendPartnerAllocationForPost.DividendPartnerNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                dividendPartnerAllocationForPost.DividendPartnerNode.DividendPartner = dividendPartnerAllocation.DividendPartnerNode.DividendPartner;
                dividendPartnerAllocationForPost.DividendPartnerNode.Name = dividendPartnerAllocation.DividendPartnerNode.Name;
                dividendPartnerAllocationForPost.DividendPartnerNode.Description = dividendPartnerAllocation.DividendPartnerNode.Description;
                dividendPartnerAllocationForPost.DividendPartnerNode.IsMarkedForDeletion = dividendPartnerAllocation.DividendPartnerNode.IsMarkedForDeletion;

                if (dividendPartnerAllocation.DividendPartnerNode.NodeType.Name != null && dividendPartnerAllocation.DividendPartnerNode.NodeType.Name.trim() != "") {
                    dividendPartnerAllocationForPost.DividendPartnerNode.NodeType = dividendPartnerAllocation.DividendPartnerNode.NodeType;
                }
                else {
                    let systemNodeTypes: IHierarchyEditNode_Node_NodeType[] = <IHierarchyEditNode_Node_NodeType[]>JSON.parse(localStorage.getItem("systemNodeTypes"));
                    let nodeType: IHierarchyEditNode_Node_NodeType = this.nodeTypes.find(node => node.Name.toLowerCase().trim() == "dividend partner allocation");
                    if (nodeType) {
                        dividendPartnerAllocationForPost.DividendPartnerNode.NodeType = nodeType;
                    }
                }

                dividendPartnerAllocationForPost.DividendPartnerNode.IsPnlHolder = dividendPartnerAllocation.DividendPartnerNode.IsPnlHolder;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputYTD = dividendPartnerAllocation.DividendPartnerNode.InputYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputExpectedYTD = dividendPartnerAllocation.DividendPartnerNode.InputExpectedYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.DividendYTD = dividendPartnerAllocation.DividendPartnerNode.DividendYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.ReportedMEYTD = dividendPartnerAllocation.DividendPartnerNode.ReportedMEYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.CanRemove = dividendPartnerAllocation.DividendPartnerNode.CanRemove;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputData = dividendPartnerAllocation.DividendPartnerNode.InputData ? dividendPartnerAllocation.DividendPartnerNode.InputData.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.OutputData = dividendPartnerAllocation.DividendPartnerNode.InputData ? dividendPartnerAllocation.DividendPartnerNode.OutputData.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.PreviousYTDForTrueUp = dividendPartnerAllocation.DividendPartnerNode.PreviousYTDForTrueUp;
                dividendPartnerAllocationForPost.DividendPartnerNode.AllDatesForCurrentReportingDate = dividendPartnerAllocation.DividendPartnerNode.AllDatesForCurrentReportingDate ? dividendPartnerAllocation.DividendPartnerNode.AllDatesForCurrentReportingDate.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.AllMVarDatesForCurrentReportingDate = dividendPartnerAllocation.DividendPartnerNode.AllMVarDatesForCurrentReportingDate ? dividendPartnerAllocation.DividendPartnerNode.AllMVarDatesForCurrentReportingDate.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.HasPnl = dividendPartnerAllocation.DividendPartnerNode.HasPnl;
                dividendPartnerAllocationForPost.DividendPartnerNode.HasMVaR = dividendPartnerAllocation.DividendPartnerNode.HasMVaR;
                dividendPartnerAllocationForPost.DividendPartnerNode.IsActive = dividendPartnerAllocation.DividendPartnerNode.IsActive;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputNameMappings = dividendPartnerAllocation.DividendPartnerNode.InputNameMappings ? dividendPartnerAllocation.DividendPartnerNode.InputNameMappings.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.PreviousMonthEndDate = dividendPartnerAllocation.DividendPartnerNode.PreviousMonthEndDate;
                dividendPartnerAllocationForPost.DividendPartnerNode.PreviousTradeDate = dividendPartnerAllocation.DividendPartnerNode.PreviousTradeDate;
                dividendPartnerAllocationForPost.DividendPartnerNode.HasWorkingCapital = dividendPartnerAllocation.DividendPartnerNode.HasWorkingCapital;
                dividendPartnerAllocationForPost.DividendPartnerNode.Created = dividendPartnerAllocation.DividendPartnerNode.Created;
                dividendPartnerAllocationForPost.DividendPartnerNode.CreatedBy = dividendPartnerAllocation.DividendPartnerNode.CreatedBy;
                dividendPartnerAllocationForPost.DividendPartnerNode.Updated = dividendPartnerAllocation.DividendPartnerNode.Updated;
                dividendPartnerAllocationForPost.DividendPartnerNode.UpdatedBy = dividendPartnerAllocation.DividendPartnerNode.UpdatedBy;
                dividendPartnerAllocationForPost.DividendPartnerNode.Id = dividendPartnerAllocation.DividendPartnerNode.Id;

                dividendPartnerAllocationForPost.RegionNode = dividendPartnerAllocation.RegionNode;
                dividendPartnerAllocationForPost.BusinessSegmentNode = dividendPartnerAllocation.BusinessSegmentNode;
                dividendPartnerAllocationForPost.Created = dividendPartnerAllocation.Created;
                dividendPartnerAllocationForPost.CreatedBy = dividendPartnerAllocation.CreatedBy;
                dividendPartnerAllocationForPost.Updated = dividendPartnerAllocation.Updated;
                dividendPartnerAllocationForPost.UpdatedBy = dividendPartnerAllocation.UpdatedBy;
                dividendPartnerAllocationForPost.Id = dividendPartnerAllocation.Id;

                this.nodeDataForPostToServer.DividendPartnerAllocations.push(dividendPartnerAllocationForPost);
            });
        }
        else {
            this.nodeDataForPostToServer.DividendPartnerAllocations = null;
        }

        this.nodeDataForPostToServer.HasChildren = this.editNodeCompleteData.HasChildren;
        this.nodeDataForPostToServer.HierarchyInstanceId = this.editNodeCompleteData.HierarchyInstanceId;
        this.nodeDataForPostToServer.Id = this.editNodeCompleteData.Id;
        this.nodeDataForPostToServer.IsMarkedForDeletion = this.editNodeCompleteData.IsMarkedForDeletion;
        this.nodeDataForPostToServer.LastUpdatedBy = this.editNodeCompleteData.LastUpdatedBy;
        this.nodeDataForPostToServer.Level = this.editNodeCompleteData.Level;
        this.nodeDataForPostToServer.MVarLimit = this.editNodeCompleteData.MVarLimit;

        if (this.blnMVarHolder) {
            let selectedMVARRegion: IRegionsValue = this.regions.find(region => region.Name == this.strSelectedMVarRegionName);

            if (selectedMVARRegion) {
                this.nodeDataForPostToServer.MVarRegion = new clsHierarchyEditNode_MVarRegion();
                this.nodeDataForPostToServer.MVarRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                this.nodeDataForPostToServer.MVarRegion.Created = selectedMVARRegion.Created.toString();
                this.nodeDataForPostToServer.MVarRegion.CreatedBy = selectedMVARRegion.CreatedBy;
                this.nodeDataForPostToServer.MVarRegion.Id = selectedMVARRegion.Id;
                this.nodeDataForPostToServer.MVarRegion.IsInUse = selectedMVARRegion.IsInUse;
                this.nodeDataForPostToServer.MVarRegion.Name = selectedMVARRegion.Name;
                this.nodeDataForPostToServer.MVarRegion.Updated = selectedMVARRegion.Updated.toString();
                this.nodeDataForPostToServer.MVarRegion.UpdatedBy = selectedMVARRegion.UpdatedBy;
            }
            else {
                this.nodeDataForPostToServer.MVarRegion = null;
            }

            this.nodeDataForPostToServer.MVarUpdateTiming = Number(this.strSelectedMVarUpdateTiming);
        }
        else {
            this.nodeDataForPostToServer.MVarRegion = null;
            this.nodeDataForPostToServer.MVarUpdateTiming = null;
        }

        this.nodeDataForPostToServer.MVarTemporaryLimit = this.editNodeCompleteData.MVarTemporaryLimit;
        this.nodeDataForPostToServer.MVarTemporaryLimitExpiryDate = this.editNodeCompleteData.MVarTemporaryLimitExpiryDate;

        // to set Node properties
        this.nodeDataForPostToServer.Node = new clsHierarchyNodePostData_Node();
        this.nodeDataForPostToServer.Node.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        this.nodeDataForPostToServer.Node.Name = this.editNodeCompleteData.Node.Name;
        //console.log("node name to post to server", this.nodeDataForPostToServer.Node.Name);
        this.nodeDataForPostToServer.Node.Description = this.editNodeCompleteData.Node.Description;
        this.nodeDataForPostToServer.Node.IsMarkedForDeletion = this.editNodeCompleteData.Node.IsMarkedForDeletion;

        let selectNodeType = this.nodeTypes.find(item => item.Name == this.editNodeCompleteData.Node.NodeType.Name);
        this.nodeDataForPostToServer.Node.NodeType = selectNodeType;
        this.nodeDataForPostToServer.Node.NodeType.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeTypeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

        this.nodeDataForPostToServer.Node.IsPnlHolder = this.editNodeCompleteData.Node.IsPnlHolder;
        this.nodeDataForPostToServer.Node.InputYTD = this.editNodeCompleteData.Node.InputYTD;
        this.nodeDataForPostToServer.Node.InputExpectedYTD = this.editNodeCompleteData.Node.InputExpectedYTD;
        this.nodeDataForPostToServer.Node.DividendYTD = this.editNodeCompleteData.Node.DividendYTD;
        this.nodeDataForPostToServer.Node.ReportedMEYTD = this.editNodeCompleteData.Node.ReportedMEYTD;
        this.nodeDataForPostToServer.Node.CanRemove = this.editNodeCompleteData.Node.CanRemove;

        this.nodeDataForPostToServer.Node.InputData = this.editNodeCompleteData.Node.InputData.$values;
        this.nodeDataForPostToServer.Node.InputData.forEach(data => {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });

        this.nodeDataForPostToServer.Node.OutputData = this.editNodeCompleteData.Node.OutputData.$values;
        this.nodeDataForPostToServer.Node.OutputData.forEach(data => {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.OutputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });

        this.nodeDataForPostToServer.Node.PreviousYTDForTrueUp = this.editNodeCompleteData.Node.PreviousYTDForTrueUp;

        if (this.editNodeCompleteData.Node.AllDatesForCurrentReportingDate != null) {
            this.nodeDataForPostToServer.Node.AllDatesForCurrentReportingDate = this.editNodeCompleteData.Node.AllDatesForCurrentReportingDate.$values;
        }
        else {
            this.nodeDataForPostToServer.Node.AllDatesForCurrentReportingDate = [];
        }

        if (this.editNodeCompleteData.Node.AllMVarDatesForCurrentReportingDate != null) {
            this.nodeDataForPostToServer.Node.AllMVarDatesForCurrentReportingDate = this.editNodeCompleteData.Node.AllMVarDatesForCurrentReportingDate.$values;
        }
        else {
            this.nodeDataForPostToServer.Node.AllMVarDatesForCurrentReportingDate = [];
        }

        this.nodeDataForPostToServer.Node.HasPnl = this.editNodeCompleteData.Node.HasPnl;
        this.nodeDataForPostToServer.Node.HasMVaR = this.editNodeCompleteData.Node.HasMVaR;
        this.nodeDataForPostToServer.Node.IsActive = this.editNodeCompleteData.Node.IsActive;

        //mapping Names
        if (this.editNodeCompleteData.Node.InputNameMappings != null) {
            this.nodeDataForPostToServer.Node.InputNameMappings = this.editNodeCompleteData.Node.InputNameMappings.$values;

            this.nodeDataForPostToServer.Node.InputNameMappings.forEach(data => {
                data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.InputNameMappingDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            });
        }
        else {
            this.nodeDataForPostToServer.Node.InputNameMappings = [];
        }

        this.nodeDataForPostToServer.Node.PreviousMonthEndDate = this.editNodeCompleteData.Node.PreviousMonthEndDate;
        this.nodeDataForPostToServer.Node.PreviousTradeDate = this.editNodeCompleteData.Node.PreviousTradeDate;
        this.nodeDataForPostToServer.Node.HasWorkingCapital = this.editNodeCompleteData.Node.HasWorkingCapital;
        this.nodeDataForPostToServer.Node.Created = this.editNodeCompleteData.Node.Created;
        this.nodeDataForPostToServer.Node.CreatedBy = this.editNodeCompleteData.Node.CreatedBy;
        this.nodeDataForPostToServer.Node.Updated = this.editNodeCompleteData.Node.Updated;
        this.nodeDataForPostToServer.Node.UpdatedBy = this.editNodeCompleteData.Node.UpdatedBy;
        this.nodeDataForPostToServer.Node.Id = this.editNodeCompleteData.Node.Id;

        this.nodeDataForPostToServer.NodeType = this.editNodeCompleteData.NodeType;
        this.nodeDataForPostToServer.ParentId = this.editNodeCompleteData.ParentId;
        this.nodeDataForPostToServer.ParentNodeId = this.editNodeCompleteData.ParentNodeId;

        this.nodeDataForPostToServer.Plans = [];

        this.pnlPlansArray.forEach(pnlPlanArray => {
            let clsPnlPlan: IHierarchyNodePostData_Plans = new clsHierarchyNodePostData_Plans();

            clsPnlPlan.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            clsPnlPlan.DividendPartner = null;
            let pnlRegion = this.regions.find(region => region.Name == pnlPlanArray.strRegionName);

            if (pnlRegion) {
                clsPnlPlan.Region = new clsHierarchyNodePostData_Plans_Region();
                clsPnlPlan.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsPnlPlan.Region.Name = pnlRegion.Name;
                clsPnlPlan.Region.IsInUse = pnlRegion.IsInUse;
                clsPnlPlan.Region.Created = pnlRegion.Created.toString();
                clsPnlPlan.Region.CreatedBy = pnlRegion.CreatedBy.toString();
                clsPnlPlan.Region.Updated = pnlRegion.Updated.toString();
                clsPnlPlan.Region.UpdatedBy = pnlRegion.UpdatedBy.toString();
                clsPnlPlan.Region.Id = pnlRegion.Id;
            }

            clsPnlPlan.PlanValues = [];

            this.filteredPnLPlanPerRegion = [];
            this.filteredPnLPlanPerRegion = this.completePnlPlanYearToMonthPerRegion.filter(pnlPlanYearToMonthPerRegion => pnlPlanYearToMonthPerRegion.strRegionName == pnlPlanArray.strRegionName);

            let filteredPnlPlanArrayPerRegionPerYear: clsPnlPlanYearToMonthPerRegion[] = [];

            //debugger;
            this.pnlPlanYears.forEach(pnlYear => {
                if (pnlYear.value != this.pnlPlanYears[0].value) {    // this is because, the first year value is being stored irrespective of whether all the plans are having value or not. 
                    let pnlPlanPerYear: clsPnlPlanYearToMonthPerRegion[] = this.filteredPnLPlanPerRegion.filter(yearPlan => yearPlan.strYear == pnlYear.value);

                    //if (pnlPlanPerYear.length > 0 && pnlPlanPerYear.every(arrayItem => arrayItem.strPlanValue != "0" && arrayItem.strPlanValue != null)) {
                    if (pnlPlanPerYear.length > 0 && (pnlPlanPerYear.findIndex(arrayItem => arrayItem.strPlanValue.toString() != "0") != -1)) {
                        let tempArray: clsPnlPlanYearToMonthPerRegion[] = [];
                        tempArray = this.filteredPnLPlanPerRegion.filter(item => item.strYear == pnlYear.value);

                        tempArray.forEach(item => filteredPnlPlanArrayPerRegionPerYear.push(item));
                    }
                }
                else {
                    let tempArray: clsPnlPlanYearToMonthPerRegion[] = [];
                    tempArray = this.filteredPnLPlanPerRegion.filter(item => item.strYear == pnlYear.value);

                    tempArray.forEach(item => filteredPnlPlanArrayPerRegionPerYear.push(item));
                }
            });

            filteredPnlPlanArrayPerRegionPerYear.forEach(pnlArrayItem => {
                let pnlPlanValue: IHierarchyNodePostData_Plans_PlanValues = new clsHierarchyNodePostData_Plans_PlanValues();

                pnlPlanValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanValueDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                pnlPlanValue.Year = Number(pnlArrayItem.strYear);
                pnlPlanValue.Month = Number(pnlArrayItem.strMonthValue);
                if (pnlArrayItem.strMonthValue != "0" && pnlArrayItem.strMonthValue != null) {
                    pnlPlanValue.Value = Number(pnlArrayItem.strPlanValue);
                }
                else {
                    pnlPlanValue.Value = null;
                }
                clsPnlPlan.PlanValues.push(pnlPlanValue);
            });

            this.nodeDataForPostToServer.Plans.push(clsPnlPlan);
        });

        // this is for dividend plan
        this.dividendPlansArray.forEach(dividendPlanArray => {
            let clsDividendPlan: IHierarchyNodePostData_Plans = new clsHierarchyNodePostData_Plans();

            clsDividendPlan.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

            let dividendPartnerObj = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == dividendPlanArray.strDividendPartnerName);

            if (dividendPartnerObj) {
                clsDividendPlan.DividendPartner = new clsHierarchyNodePostData_Plans_DividendPartner();
                clsDividendPlan.DividendPartner.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.DividendPartner.BusinessSegment = new clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment();
                clsDividendPlan.DividendPartner.BusinessSegment = dividendPartnerObj.BusinessSegment;
                clsDividendPlan.DividendPartner.BusinessSegment.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.BusinessSegmentDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.DividendPartner.Created = dividendPartnerObj.Created;
                clsDividendPlan.DividendPartner.CreatedBy = dividendPartnerObj.CreatedBy;
                clsDividendPlan.DividendPartner.Editable = dividendPartnerObj.Editable;
                clsDividendPlan.DividendPartner.Id = dividendPartnerObj.Id;
                clsDividendPlan.DividendPartner.IsInUse = dividendPartnerObj.IsInUse;
                clsDividendPlan.DividendPartner.Name = dividendPartnerObj.Name;
                clsDividendPlan.DividendPartner.Updated = dividendPartnerObj.Updated;
                clsDividendPlan.DividendPartner.UpdatedBy = dividendPartnerObj.UpdatedBy;
            }

            let pnlRegion = this.regions.find(region => region.Name == dividendPlanArray.strRegionName);

            if (pnlRegion) {
                clsDividendPlan.Region = new clsHierarchyNodePostData_Plans_Region();
                clsDividendPlan.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.Region.Name = pnlRegion.Name;
                clsDividendPlan.Region.IsInUse = pnlRegion.IsInUse;
                clsDividendPlan.Region.Created = pnlRegion.Created.toString();
                clsDividendPlan.Region.CreatedBy = pnlRegion.CreatedBy.toString();
                clsDividendPlan.Region.Updated = pnlRegion.Updated.toString();
                clsDividendPlan.Region.UpdatedBy = pnlRegion.UpdatedBy.toString();
                clsDividendPlan.Region.Id = pnlRegion.Id;
            }

            clsDividendPlan.PlanValues = [];

            this.filteredDividendPlanPerDividendPartnerAndRegion = [];
            this.filteredDividendPlanPerDividendPartnerAndRegion = this.completeDividendPlanYearToMonthPerRegion
                .filter(dividendPlanYearToMonthPerDividendPartnerAndRegion =>
                    dividendPlanYearToMonthPerDividendPartnerAndRegion.strRegionName == dividendPlanArray.strRegionName &&
                    dividendPlanYearToMonthPerDividendPartnerAndRegion.strDividendPartnerName == dividendPlanArray.strDividendPartnerName);

            //debugger;
            let filteredDividendPlanArrayPerRegionPerYear: clsDividendPlanYearToMonthPerRegion[] = [];

            this.dividendPlanYears.forEach(dividendYear => {
                if (dividendYear.value != this.dividendPlanYears[0].value) {    // this is because, the first year value is being stored irrespective of whether all the plans are having value or not. 
                    let dividendPlanPerYear: clsDividendPlanYearToMonthPerRegion[] = this.filteredDividendPlanPerDividendPartnerAndRegion.filter(yearPlan => yearPlan.strYear == dividendYear.value);

                    if (dividendPlanPerYear.length > 0 && (dividendPlanPerYear.findIndex(arrayItem => arrayItem.strPlanValue.toString() != "0") != -1)) {
                        let tempArray: clsDividendPlanYearToMonthPerRegion[] = [];
                        tempArray = this.filteredDividendPlanPerDividendPartnerAndRegion.filter(item => item.strYear == dividendYear.value);

                        tempArray.forEach(item => filteredDividendPlanArrayPerRegionPerYear.push(item));
                    }
                }
                else {
                    let tempArray: clsDividendPlanYearToMonthPerRegion[] = [];
                    tempArray = this.filteredDividendPlanPerDividendPartnerAndRegion.filter(item => item.strYear == dividendYear.value);

                    tempArray.forEach(item => filteredDividendPlanArrayPerRegionPerYear.push(item));
                }
            });

            filteredDividendPlanArrayPerRegionPerYear.forEach(dividendArrayItem => {
                let dividendPlanValue: IHierarchyNodePostData_Plans_PlanValues = new clsHierarchyNodePostData_Plans_PlanValues();

                dividendPlanValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanValueDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                dividendPlanValue.Year = Number(dividendArrayItem.strYear);
                dividendPlanValue.Month = Number(dividendArrayItem.strMonthValue);
                if (dividendArrayItem.strMonthValue != "0" && dividendArrayItem.strMonthValue != null) {
                    dividendPlanValue.Value = Number(dividendArrayItem.strPlanValue);
                }
                else {
                    dividendPlanValue.Value = null;
                }
                clsDividendPlan.PlanValues.push(dividendPlanValue);
            });

            this.nodeDataForPostToServer.Plans.push(clsDividendPlan);
        });

        this.nodeDataForPostToServer.PnlSplitValue = null; //To be changed to proper datatype.

        if (this.editNodeCompleteData.Node.IsPnlHolder) {
            this.nodeDataForPostToServer.RegionalAllocations = [];
            this.editNodeCompleteData.RegionalAllocations.$values.forEach(regionAllocation => {
                let regionAllocationForPost: IHierarchyNodePostData_RegionalAllocations = new clsHierarchyNodePostData_RegionalAllocations();

                regionAllocationForPost.$type = regionAllocation.$type;
                regionAllocationForPost.Percentage = regionAllocation.Percentage;

                regionAllocationForPost.RegionNode = new clsHierarchyNodePostData_RegionalAllocations_RegionNode();
                regionAllocationForPost.RegionNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                regionAllocationForPost.RegionNode.Region = regionAllocation.RegionNode.Region;
                regionAllocationForPost.RegionNode.Name = regionAllocation.RegionNode.Name;
                regionAllocationForPost.RegionNode.Description = regionAllocation.RegionNode.Description;
                regionAllocationForPost.RegionNode.IsMarkedForDeletion = regionAllocation.RegionNode.IsMarkedForDeletion;

                //regionAllocationForPost.RegionNode.NodeType = regionAllocation.RegionNode.NodeType;

                if (regionAllocation.RegionNode.NodeType.Name != null && regionAllocation.RegionNode.NodeType.Name.trim() != "") {
                    regionAllocationForPost.RegionNode.NodeType = regionAllocation.RegionNode.NodeType;
                }
                else {
                    let systemNodeTypes: IHierarchyEditNode_Node_NodeType[] = <IHierarchyEditNode_Node_NodeType[]>JSON.parse(localStorage.getItem("systemNodeTypes"));
                    let nodeType: IHierarchyEditNode_Node_NodeType = this.nodeTypes.find(node => node.Name.toLowerCase().trim() == "region allocation");
                    if (nodeType) {
                        regionAllocationForPost.RegionNode.NodeType = nodeType;
                    }
                }

                regionAllocationForPost.RegionNode.IsPnlHolder = regionAllocation.RegionNode.IsPnlHolder;
                regionAllocationForPost.RegionNode.InputYTD = regionAllocation.RegionNode.InputYTD;
                regionAllocationForPost.RegionNode.InputExpectedYTD = regionAllocation.RegionNode.InputExpectedYTD;
                regionAllocationForPost.RegionNode.DividendYTD = regionAllocation.RegionNode.DividendYTD;
                regionAllocationForPost.RegionNode.ReportedMEYTD = regionAllocation.RegionNode.ReportedMEYTD;
                regionAllocationForPost.RegionNode.CanRemove = regionAllocation.RegionNode.CanRemove;
                regionAllocationForPost.RegionNode.InputData = regionAllocation.RegionNode.InputData ? regionAllocation.RegionNode.InputData.$values : [];
                regionAllocationForPost.RegionNode.OutputData = regionAllocation.RegionNode.InputData ? regionAllocation.RegionNode.OutputData.$values : [];
                regionAllocationForPost.RegionNode.PreviousYTDForTrueUp = regionAllocation.RegionNode.PreviousYTDForTrueUp;
                regionAllocationForPost.RegionNode.AllDatesForCurrentReportingDate = regionAllocation.RegionNode.AllDatesForCurrentReportingDate ? regionAllocation.RegionNode.AllDatesForCurrentReportingDate.$values : [];
                regionAllocationForPost.RegionNode.AllMVarDatesForCurrentReportingDate = regionAllocation.RegionNode.AllMVarDatesForCurrentReportingDate ? regionAllocation.RegionNode.AllMVarDatesForCurrentReportingDate.$values : [];
                regionAllocationForPost.RegionNode.HasPnl = regionAllocation.RegionNode.HasPnl;
                regionAllocationForPost.RegionNode.HasMVaR = regionAllocation.RegionNode.HasMVaR;
                regionAllocationForPost.RegionNode.IsActive = regionAllocation.RegionNode.IsActive;
                regionAllocationForPost.RegionNode.InputNameMappings = regionAllocation.RegionNode.InputNameMappings ? regionAllocation.RegionNode.InputNameMappings.$values : [];
                regionAllocationForPost.RegionNode.PreviousMonthEndDate = regionAllocation.RegionNode.PreviousMonthEndDate;
                regionAllocationForPost.RegionNode.PreviousTradeDate = regionAllocation.RegionNode.PreviousTradeDate;
                regionAllocationForPost.RegionNode.HasWorkingCapital = regionAllocation.RegionNode.HasWorkingCapital;
                regionAllocationForPost.RegionNode.Created = regionAllocation.RegionNode.Created;
                regionAllocationForPost.RegionNode.CreatedBy = regionAllocation.RegionNode.CreatedBy;
                regionAllocationForPost.RegionNode.Updated = regionAllocation.RegionNode.Updated;
                regionAllocationForPost.RegionNode.UpdatedBy = regionAllocation.RegionNode.UpdatedBy;
                regionAllocationForPost.RegionNode.Id = regionAllocation.RegionNode.Id;

                regionAllocationForPost.DividendPartnerNode = regionAllocation.DividendPartnerNode;
                regionAllocationForPost.BusinessSegmentNode = regionAllocation.BusinessSegmentNode;
                regionAllocationForPost.Created = regionAllocation.Created;
                regionAllocationForPost.CreatedBy = regionAllocation.CreatedBy;
                regionAllocationForPost.Updated = regionAllocation.Updated;
                regionAllocationForPost.UpdatedBy = regionAllocation.UpdatedBy;
                regionAllocationForPost.Id = regionAllocation.Id;

                this.nodeDataForPostToServer.RegionalAllocations.push(regionAllocationForPost);
            });
        }
        else {
            this.nodeDataForPostToServer.RegionalAllocations = null;
        }

        this.nodeDataForPostToServer.SplitType = this.editNodeCompleteData.Node.IsPnlHolder ? this.strSelectedSplitType : null;

        this.nodeDataForPostToServer.Tags = this.editNodeCompleteData.Tags.$values;
        this.nodeDataForPostToServer.Tags.forEach(data => {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.TagDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });

        this.nodeDataForPostToServer.Updated = this.editNodeCompleteData.Updated;
        this.nodeDataForPostToServer.UpdatedBy = this.editNodeCompleteData.UpdatedBy;
        this.nodeDataForPostToServer.UpdateTiming = this.editNodeCompleteData.UpdateTiming;

        // if (this.editNodeCompleteData.WorkingCapitalRegion) {
        //     this.nodeDataForPostToServer.WorkingCapitalRegion = this.editNodeCompleteData.WorkingCapitalRegion;
        //     this.nodeDataForPostToServer.WorkingCapitalRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

        //     if (this.strSelectedWorkingCapitalRegionName == "" || this.strSelectedWorkingCapitalRegionName == "NotSet") {
        //         this.nodeDataForPostToServer.WorkingCapitalRegion.Name = "";
        //     }
        //     else {
        //         this.nodeDataForPostToServer.WorkingCapitalRegion.Name = this.strSelectedWorkingCapitalRegionName;
        //     }
        // }
        // else {
        //     if (this.blnWorkingCapitalRegion) {
        //         this.nodeDataForPostToServer.WorkingCapitalRegion = new clsHierarchyEditNode_WorkingCapital();

        //         this.nodeDataForPostToServer.WorkingCapitalRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

        //         if (this.strSelectedWorkingCapitalRegionName == "" || this.strSelectedWorkingCapitalRegionName == "NotSet") {
        //             this.nodeDataForPostToServer.WorkingCapitalRegion.Name = "";
        //         }
        //         else {
        //             this.nodeDataForPostToServer.WorkingCapitalRegion.Name = this.strSelectedWorkingCapitalRegionName;
        //         }
        //     }
        // }

        //debugger;
        if (this.blnWorkingCapitalRegion) {
            this.nodeDataForPostToServer.WorkingCapitalRegion = new clsHierarchyEditNode_WorkingCapital();

            //debugger;
            let workingCapitalRegion: IRegionsValue = this.regions.find(region => region.Name == this.strSelectedWorkingCapitalRegionName);

            if (workingCapitalRegion) {
                this.nodeDataForPostToServer.WorkingCapitalRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                this.nodeDataForPostToServer.WorkingCapitalRegion.Name = workingCapitalRegion.Name;
                this.nodeDataForPostToServer.WorkingCapitalRegion.IsInUse = workingCapitalRegion.IsInUse;
                this.nodeDataForPostToServer.WorkingCapitalRegion.Created = workingCapitalRegion.Created.toString();
                this.nodeDataForPostToServer.WorkingCapitalRegion.CreatedBy = workingCapitalRegion.CreatedBy;
                this.nodeDataForPostToServer.WorkingCapitalRegion.Updated = workingCapitalRegion.Updated;
                this.nodeDataForPostToServer.WorkingCapitalRegion.UpdatedBy = workingCapitalRegion.UpdatedBy;
                this.nodeDataForPostToServer.WorkingCapitalRegion.Id = workingCapitalRegion.Id;
            }
        }
        else {
            this.nodeDataForPostToServer.WorkingCapitalRegion = null;
        }

        //debugger;
        //console.log(this.nodeDataForPostToServer);

        this.isRequesting = true;
        this.tPRHierarchyservice.updateNodeLevelDataForEdit(this.nodeDataForPostToServer)
            .subscribe((response: any) => {
                //debugger;
                //console.log(response);
                this.blnDisableControlsTillSaveCompletes = false;
                if (response.Error) {
                    //alert(response.Error);
                    this.stopRefreshing();
                    this.blnShowSaveDialog = false;
                    this.strValidationHeader = "Error";
                    this.strValidationMessage = response.Error;
                    this.blnShowValidationDialog = true;
                }
                else {
                    this.stopRefreshing();
                    this.blnShowModalPouUp = false;
                    this.blnShowSaveDialog = false;
                    this.router.navigateByUrl('/DummyComponent', { skipLocationChange: true }); //added EH 
                    this.router.navigateByUrl('/hierarchy');
                    // window.location.reload(false); //bad logic
                }
            },
            (error) => {
                //debugger;
                this.stopRefreshing();
                //console.log(error)
                this.strValidationHeader = "Error";
                this.strValidationMessage = error;
                this.blnShowValidationDialog = true;
            });
        this.appTprHierarchyComponent.loadTree();
    }

    private ResetAllTemplate() {
        this.blnNodePropertiesShow = false;
        this.blnMappingNamesShow = false;
        this.blnRegionAllocationShow = false;
        this.blnTagAllocationShow = false;
        this.blnDividendAllocationShow = false;
        this.blnPnLPlanShow = false;
        this.blnPlanForDividendPartnersShow = false;
        this.blnMVARShow = false;
        this.blnProfitAlertGroupShow = false;
        this.blnWorkingCapitalShow = false;
    }

    private setNodeTypeData(data: any): void {
        //debugger;
        this.nodeTypes = data.Result.NodeTypes.$values;

        localStorage.setItem("systemNodeTypes", JSON.stringify(this.nodeTypes));

        this.nodeTypes = this.nodeTypes.filter(nodeType => nodeType.Editable == true);

        this.nodes = [];
        let nodeName: string = ''

        for (var i = 0; i < this.nodeTypes.length; i++) {
            let node = this.nodeTypes[i];
            nodeName = node.Name;

            this.nodes.push({ label: nodeName, value: nodeName });
        }
    }

    private IsPnlHolderChange(checked: boolean) {
        this.editChildMenuItems.find(menuItem => menuItem.label == "Region Allocation").disabled = !this.editNodeCompleteData.Node.IsPnlHolder;

        if (!this.blndisableSelectedUpdateTimingField) {
            this.updateTimings = [];
            if (checked) {
                this.updateTimings = [
                    { label: "R-1", value: "-1" },
                    { label: "R-2", value: "-2" }
                ];

                if (!this.editNodeCompleteData.UpdateTiming) {
                    this.selectedUpdateTiming = -1;
                    this.editNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
                }
            }
            else {
                this.updateTimings = [
                    { label: "Not Set", value: null },
                    { label: "R-1", value: "-1" },
                    { label: "R-2", value: "-2" }
                ];

                if (this.editNodeCompleteData.UpdateTiming) {
                    this.selectedUpdateTiming = null;
                    this.editNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
                }
            }
        }
    }

    private getHierarchyData() {
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(files => this.setNodeData(files));
    }

    private setNodeData(data: any): void {
        //this.mainListOfTree = data.Result.Children.$values;
        localStorage.setItem("MainHierarchyData", JSON.stringify(data.Result.Children.$values));
        this.hierarchy = data.Result.Children.$values;
        this.hierarchy.forEach((node: any) => {
            this.updateChildrenPropRecursive(node);
        });
        //console.log("hierarchy ->", this.hierarchy);
        this.mainListOfTree = this.hierarchy;
        this.updateNodeProps();

        this.setUpdateTimingForNode();

        this.checkDisablePnlHolder();
    }

    private setEditChildMenuItems() {
        this.editChildMenuItems.forEach(menuItem => menuItem.disabled = false);

        this.editChildMenuItems.forEach(menuItem => {
            if (menuItem.label == "Region Allocation") {
                menuItem.disabled = !this.editNodeCompleteData.Node.IsPnlHolder;
            }
            else if (menuItem.label == "Dividend Allocation") {
                menuItem.disabled = (!this.editNodeCompleteData.Node.IsPnlHolder || this.editNodeCompleteData.RegionalAllocations.$values.length <= 0);
            }
            else if ((menuItem.label == "Pnl Plan") || (menuItem.label == "Plan For Dividend Partners")) {
                menuItem.disabled = (!this.editNodeCompleteData.Node.IsPnlHolder && !this.editNodeCompleteData.UpdateTiming && this.selectedUpdateTiming == null);
            }
        });

        this.blnNodePropertiesShow = true;
        this.stopRefreshing();

        // this.editChildMenuItems = [
        //     { label: 'Node Properties', icon: 'fa fa-table', command: (event) => this.EditNodeProperties() },
        //     { label: 'Mapping Names', icon: 'fa fa-table', command: (event) => this.EditMappingNames() },
        //     { label: 'Region Allocation', icon: 'fa fa-table', command: (event) => this.EditRegionAllocation(), disabled: !this.editNodeCompleteData.Node.IsPnlHolder },
        //     { label: 'Tag Allocation', icon: 'fa fa-table', command: (event) => this.EditTagAllocation() },
        //     { label: 'Dividend Allocation', icon: 'fa fa-table', command: (event) => this.EditDividendAllocation(), disabled: (!this.editNodeCompleteData.Node.IsPnlHolder || this.editNodeCompleteData.RegionalAllocations.$values.length <= 0) },
        //     { label: 'Pnl Plan', icon: 'fa fa-table', command: (event) => this.EditPnLPlan(), disabled: (!this.editNodeCompleteData.Node.IsPnlHolder && !this.editNodeCompleteData.UpdateTiming && this.selectedUpdateTiming == null) },
        //     { label: 'Plan For Dividend Partners', icon: 'fa fa-table', command: (event) => this.EditPlanForDividendPartners(), disabled: (!this.editNodeCompleteData.Node.IsPnlHolder && !this.editNodeCompleteData.UpdateTiming && this.selectedUpdateTiming == null) },
        //     { label: 'MVAR', icon: 'fa fa-table', command: (event) => this.EditMVAR() },
        //     { label: 'Profit Alert Groups', icon: 'fa fa-table', command: (event) => this.EditProfitAlertGroups() },
        //     { label: 'Working Capital', icon: 'fa fa-table', command: (event) => this.EditWorkingCapital() },
        // ];
    }

    updateChildrenPropRecursive(node: any) {
        node.Children = node.Children.$values;
        node.children = node.Children;
        node.label = node.NodeName;
        if (node.Children) {
            node.Children.forEach((childNode: any) => {
                this.updateChildrenPropRecursive(childNode);
            });
        }
    }

    updateNodeProps() {
        this.mainListOfTree.forEach(node => {
            this.AddNodeToArray(node);
            //console.log("nodeArrays -> ", this.nodeArrays);
        });
    }

    private setRegionsData(data: any): void {
        this.regions = data.Result.Regions.$values;

        this.regionNames = []

        this.regionNames.push({ label: 'Not Set', value: 'NotSet' });
        let regionName: string = ''

        for (var i = 0; i < this.regions.length; i++) {
            let region = this.regions[i];
            regionName = region.Name;

            this.regionNames.push({ label: regionName, value: regionName });
        }
    }

    private setProfitAlertGroupDate(data: any) {
        this.profitAlertGroupsValuesMasterData = data.Result.AlertGroups.$values;

        this.profitAlertGroupNames = [];

        this.profitAlertGroupNames.push({ label: 'Not Set', value: 'NotSet' });

        for (var i = 0; i < this.profitAlertGroupsValuesMasterData.length; i++) {
            let pfaGroup = this.profitAlertGroupsValuesMasterData[i];

            this.profitAlertGroupNames.push({ label: pfaGroup.Name, value: pfaGroup.Name });

            this.profitAlertGroupArrays.push({
                Name: pfaGroup.Name,
                UpdateTiming: pfaGroup.UpdateTiming,
                Id: pfaGroup.Id,
                IsInUse: pfaGroup.IsInUse,
                TradeDate: pfaGroup.TradeDate,
                ProfitAlertGroupStatusId: pfaGroup.ProfitAlertGroupStatusId,
                Created: pfaGroup.Created,
                CreatedBy: pfaGroup.CreatedBy,
                Updated: pfaGroup.Updated,
                UpdatedBy: pfaGroup.UpdatedBy
            });
        }
    }

    private setDividendPartnerData(data: any): void {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;

        //this.dividendPartnerTypes = this.dividendPartnerTypes.filter(divPartner => divPartner.Editable == true);

        this.dividendPartnerNames = [];

        this.dividendPartnerNames.push({ label: 'Not Set', value: 'NotSet' });
        let dividendPartnerName: string = ''

        for (var i = 0; i < this.dividendPartnerTypes.length; i++) {
            let dividendPartner = this.dividendPartnerTypes[i];
            dividendPartnerName = dividendPartner.Name;

            this.dividendPartnerNames.push({ label: dividendPartnerName, value: dividendPartnerName });
        }
    }

    private setDividendPartnerDataForDividendPlanAllocation(data: any): void {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;

        //this.dividendPartnerTypes = this.dividendPartnerTypes.filter(divPartner => divPartner.Editable == true);

        this.dividendPartnerNamesDividendPlanAllocation = [];

        this.dividendPartnerNamesDividendPlanAllocation.push({ label: 'Not Set', value: 'NotSet' });
        let dividendPartnerName: string = ''

        for (var i = 0; i < this.dividendPartnerTypes.length; i++) {
            let dividendPartner = this.dividendPartnerTypes[i];
            dividendPartnerName = dividendPartner.Name;

            this.dividendPartnerNamesDividendPlanAllocation.push({ label: dividendPartnerName, value: dividendPartnerName });
        }
    }

    private setBusinessSegmentsData(data: any): void {
        this.businessSegments = [];
        this.businessSegments = data.Result.BusinessSegments.$values;
    }

    private setTagTypeData(data: any): void {
        this.tagTypes = [];
        this.tagTypes = data.Result.Tags.$values;

        this.tagNames = []

        let tagName: string = ''

        this.tagNames.push({ label: 'Not Set', value: 'NotSet' });

        for (var i = 0; i < this.tagTypes.length; i++) {
            let tag = this.tagTypes[i];
            tagName = tag.Name;

            this.tagNames.push({ label: tagName, value: tagName });
        }
    }

    private setUpdateTimingForNode() {
        this.getUpdateTimingFromHierarchyForNode(this.editNodeCompleteData.Id);

        if (!this.editNodeCompleteData.UpdateTiming && this.selectedUpdateTiming == null) {
            this.blnDisableWorkingCapital = true;
            this.blnWorkingCapitalRegion = false;
        }

        this.setEditChildMenuItems();
    }

    private AddNodeToArray(node: IRootObject) {
        //debugger;
        this.nodeArrays.push({
            label: node.NodeName,
            $type: node.type,
            Children: node.Children,
            HasAnyOutputData: node.HasAnyOutputData,
            HasPlans: node.HasPlans,
            Level: node.Level,
            MVarUpdateTiming: node.MVarUpdateTiming,
            IsActive: node.IsActive,
            IsPnlHolder: node.IsPnlHolder,
            NodeId: node.NodeId,
            NodeType: node.NodeType,
            SplitType: node.SplitType,
            UpdateTiming: node.UpdateTiming,
            children: node.children,
            collapsedIcon: "fa-plus-square",
            data: node.data,
            expanded: node.expanded,
            expandedIcon: "fa-minus-square",
            icon: node.icon,
            id: node.id,
            leaf: node.leaf,
            parent: node.parent,
            Id: node.Id,
            ParentId: node.ParentId,
            NodeName: node.NodeName,
            type: node.type,
            partialSelected: node.partialSelected
        });

        node.children = node.Children;
        if (node.children) {
            node.children.forEach(childNode => {
                this.AddNodeToArray(childNode);
            });
        }
    }

    private onNodeUpdateTimingChange() {
        this.editNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
    }

    private getUpdateTimingFromHierarchyForNode(Id: number) {
        let nodeArray: IRootObject;
        nodeArray = this.nodeArrays.find(node => node.Id == Id);

        if (nodeArray && this.selectedUpdateTiming == null) {
            if (!nodeArray.UpdateTiming) {
                this.getUpdateTimingFromHierarchyForNode(nodeArray.ParentId);
            }
            else {
                this.selectedUpdateTiming = nodeArray.UpdateTiming;
                // this will identify whether to disable the field or not. If the node value which came initially was null, 
                //the field will be disabled and will be set to parent level updateTiming; else, it will not be disabled.
                if (this.editNodeCompleteData.UpdateTiming == null) {
                    this.blndisableSelectedUpdateTimingField = true;
                    this.nodeNameCorrespondingToUpdateTiming = nodeArray.NodeName;
                }
            }
        }
    }

    private checkDisablePnlHolder() {
        // if (!this.editNodeCompleteData.Node.IsPnlHolder) {
        //     let nodeId = this.editNodeCompleteData.Id;

        //     if (this.nodeArrays.filter(node => node.ParentId == nodeId).length > 0) {
        //         this.blnPnlHolderDisabled = true;
        //     }
        // }
    }

    onMappingAddClick(txtMappingName: string, txtMappingSource: string) {
        if (txtMappingName && txtMappingName.trim() != "") {

            let index: number = this.mappingNames.indexOf(
                this.mappingNames.find(mappingName => mappingName.Name.toLowerCase().trim() == txtMappingName.toLowerCase().trim())
            );

            if (index == -1) {
                let $type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.InputNameMappingDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                this.mappingNames.push(new clsHierarchyEditNode_Node_InputNameMappings_Value($type, txtMappingName, txtMappingSource, '', '', '', '', 0));
            }
            else {
                this.strValidationHeader = "Validation failed";
                this.strValidationMessage = "Error : Mapping names must have unique name value.";
                this.blnShowValidationDialog = true;
            }
        }
        else {
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error : Mapping names must have name value.";
            this.blnShowValidationDialog = true;
        }
    }

    deleteMappingName(mappingName: clsHierarchyEditNode_Node_InputNameMappings_Value) {
        if (mappingName) {
            this.mappingName = mappingName;
            this.mappingNames.splice(this.findmappingNameIndexForDelete(), 1);
        }
    }

    private findmappingNameIndexForDelete(): number {
        return this.mappingNames.indexOf(this.mappingName);
    }

    private IsWorkingCapital(checked: boolean) {
        if (checked) {
            let index = this.regionNames.findIndex(x => x.value == "NotSet");
            if (index >= 0) {
                this.regionNames.splice(index, 1);
            }
            this.strSelectedWorkingCapitalRegionName = this.regionNames.length > 0 ? this.regionNames[0].value : "";
        }
        else {
            this.strSelectedWorkingCapitalRegionName = "NotSet";
            this.regionNames.unshift({ label: 'Not Set', value: 'NotSet' });
        }
    }

    onAddProfitAlertGroup() {
        //debugger;
        let selectedGroup = this.profitAlertGroupArrays.find(group => group.Name == this.strSelectedProfitAlertGroupName);

        if (selectedGroup) {
            let $type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            this.profitAlertGroupsValues
                .push({
                    $type: $type,
                    Alerts: null,
                    Name: this.strSelectedProfitAlertGroupName,
                    Members: null,
                    IsInUse: selectedGroup.IsInUse,
                    UpdateTiming: selectedGroup.UpdateTiming,
                    TradeDate: selectedGroup.TradeDate,
                    ProfitAlertGroupStatusId: selectedGroup.ProfitAlertGroupStatusId,
                    Created: selectedGroup.Created,
                    CreatedBy: selectedGroup.CreatedBy,
                    Updated: selectedGroup.Updated,
                    UpdatedBy: selectedGroup.UpdatedBy,
                    Id: selectedGroup.Id
                });

            let selectedProfitAlertGroupMasterItem = this.profitAlertGroupNames.find(x => x.value == this.strSelectedProfitAlertGroupName);

            if (selectedProfitAlertGroupMasterItem) {
                this.profitAlertGroupNames.splice(this.profitAlertGroupNames.indexOf(selectedProfitAlertGroupMasterItem), 1);
            }

            this.strSelectedProfitAlertGroupName = "NotSet";
            this.strSelectedGroupUpdateTiming = null;
        }
    }

    private ProfitAlertGroupChange(ProfitAlertGroupName: string) {
        let selectedProfitAlertGroupMasterItem = this.profitAlertGroupNames.find(x => x.value == this.strSelectedProfitAlertGroupName);


        let selectedGroup = this.profitAlertGroupArrays.find(group => group.Name == this.strSelectedProfitAlertGroupName);
        if (selectedGroup) {
            this.strSelectedGroupUpdateTiming = selectedGroup.UpdateTiming ? "R" + selectedGroup.UpdateTiming : "";
        }
        else {
            this.strSelectedGroupUpdateTiming = "";
        }
    }

    deleteProfitAlertGroup(profitAlertGroup: clsHierarchyEditNode_AlertGroups_Values) {
        if (profitAlertGroup) {
            this.profitAlertGroup = profitAlertGroup;
            this.profitAlertGroupsValues.splice(this.findProfitAlertGroupForDelete(), 1);

            this.profitAlertGroupNames.push({ label: profitAlertGroup.Name, value: profitAlertGroup.Name });
        }
    }

    private findProfitAlertGroupForDelete(): number {
        return this.profitAlertGroupsValues.indexOf(this.profitAlertGroup);
    }

    private MVarHolderChecked(checked: boolean) {
        if (checked) {
            let item = this.MVarUpdateTimings.find(updateTiming => updateTiming.value == null);
            if (item) {
                this.MVarUpdateTimings.splice(this.MVarUpdateTimings.indexOf(item), 1);
            }
            this.strSelectedMVarUpdateTiming = "-1";
        }
        else {
            this.strSelectedMVarUpdateTiming = null;
            this.MVarUpdateTimings.unshift({ label: "", value: null });
        }
        this.blnMVarUpdateTiming = !checked;
        //this.editNodeCompleteData.Node.HasMVaR = checked;
    }

    private setRegionsDataForMVar(data: any): void {
        this.regions = data.Result.Regions.$values;

        this.regionNamesMVar = []

        this.regionNamesMVar.push({ label: 'Not Set', value: 'NotSet' });
        let regionName: string = ''

        for (var i = 0; i < this.regions.length; i++) {
            let region = this.regions[i];
            regionName = region.Name;

            this.regionNamesMVar.push({ label: regionName, value: regionName });
        }
    }

    private setRegionsDataForRegionAllocation(data: any): void {
        this.regions = data.Result.Regions.$values;

        this.regionNamesRegionAllocation = [];

        this.regionNamesRegionAllocation.push({ label: 'Not Set', value: 'NotSet' });
        let regionName: string = ''

        for (var i = 0; i < this.regions.length; i++) {
            let region = this.regions[i];
            regionName = region.Name;

            this.regionNamesRegionAllocation.push({ label: regionName, value: regionName });
        }
    }

    private setRegionsDataForPlanRegionAllocation(data: any): void {
        this.regions = data.Result.Regions.$values;

        this.regionNamesPlanRegionAllocation = [];

        this.regionNamesPlanRegionAllocation.push({ label: 'Not Set', value: 'NotSet' });
        let regionName: string = ''

        for (var i = 0; i < this.regions.length; i++) {
            let region = this.regions[i];
            regionName = region.Name;

            this.regionNamesPlanRegionAllocation.push({ label: regionName, value: regionName });
        }
    }

    private setRegionsDataForDividendPlanRegionAllocation(data: any): void {
        this.regions = data.Result.Regions.$values;

        this.regionNamesDividendPlanAllocation = [];

        this.regionNamesDividendPlanAllocation.push({ label: 'Not Set', value: 'NotSet' });
        let regionName: string = ''

        for (var i = 0; i < this.regions.length; i++) {
            let region = this.regions[i];
            regionName = region.Name;

            this.regionNamesDividendPlanAllocation.push({ label: regionName, value: regionName });
        }
    }

    onAddTags() {
        let selectedTag = this.tagTypes.find(item => item.Name == this.strSelectedTagName);

        if (selectedTag) {
            this.tags.push({
                $type: selectedTag.$type,
                Created: selectedTag.Created,
                CreatedBy: selectedTag.CreatedBy,
                Editable: selectedTag.Editable,
                Id: selectedTag.Id,
                IsInUse: selectedTag.IsInUse,
                Name: selectedTag.Name,
                Updated: selectedTag.Updated,
                UpdatedBy: selectedTag.UpdatedBy
            });

            let selectedTagNameMasterItem = this.tagNames.find(x => x.value == this.strSelectedTagName);

            if (selectedTagNameMasterItem) {
                this.tagNames.splice(this.tagNames.indexOf(selectedTagNameMasterItem), 1);
            }

            this.strSelectedTagName = "NotSet";
        }
    }

    deleteTag(selectedTagforDelete: clsHierarchyEditNode_Tags_Values) {
        if (selectedTagforDelete) {
            this.tag = selectedTagforDelete;
            this.tags.splice(this.findTagForDelete(), 1);

            this.tagNames.push({ label: selectedTagforDelete.Name, value: selectedTagforDelete.Name });
        }
    }

    private findTagForDelete(): number {
        return this.tags.indexOf(this.tag);
    }

    onRegionAllocationAddClick() {
        let selectedRegionAllocation = this.regions.find(region => region.Name == this.strSelectedRegionAllocationName);

        if (selectedRegionAllocation) {
            let regionAllocationForSave: IHierarchyEditNode_RegionalAllocations_Values = new clsHierarchyEditNode_RegionalAllocations_Values();

            regionAllocationForSave.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.AllocationStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            regionAllocationForSave.Percentage = Number(this.strRegionAllocationPercentage);

            regionAllocationForSave.RegionNode = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode();
            regionAllocationForSave.RegionNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

            regionAllocationForSave.RegionNode.Region = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region();
            let region = this.regions.find(region => region.Name == this.strSelectedRegionAllocationName)

            if (region) {
                regionAllocationForSave.RegionNode.Region.$type = region.$type;
                regionAllocationForSave.RegionNode.Region.Created = region.Created.toString();
                regionAllocationForSave.RegionNode.Region.CreatedBy = region.CreatedBy;
                regionAllocationForSave.RegionNode.Region.Id = region.Id;
                regionAllocationForSave.RegionNode.Region.IsInUse = region.IsInUse;
                regionAllocationForSave.RegionNode.Region.Name = region.Name;
                regionAllocationForSave.RegionNode.Region.Updated = region.Updated.toString();
                regionAllocationForSave.RegionNode.Region.UpdatedBy = region.UpdatedBy;
            }

            regionAllocationForSave.RegionNode.Name = this.strSelectedRegionAllocationName;
            regionAllocationForSave.RegionNode.Description = null;
            regionAllocationForSave.RegionNode.IsMarkedForDeletion = false;

            regionAllocationForSave.RegionNode.NodeType = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType();
            //let node = this.nodeTypes.find(node => node.Name.toLowerCase() == "region allocation")
            let systemNodeTypes: IHierarchyEditNode_Node_NodeType[] = <IHierarchyEditNode_Node_NodeType[]>JSON.parse(localStorage.getItem("systemNodeTypes"));
            let node = systemNodeTypes.find(node => node.Name.toLowerCase() == "region allocation")

            if (node) {
                regionAllocationForSave.RegionNode.NodeType = node;
            }

            regionAllocationForSave.RegionNode.IsPnlHolder = false;
            regionAllocationForSave.RegionNode.InputYTD = null;
            regionAllocationForSave.RegionNode.InputExpectedYTD = null;
            regionAllocationForSave.RegionNode.DividendYTD = null;
            regionAllocationForSave.RegionNode.ReportedMEYTD = null;
            regionAllocationForSave.RegionNode.CanRemove = false;

            regionAllocationForSave.RegionNode.InputData = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData();
            regionAllocationForSave.RegionNode.InputData.$values = [];

            regionAllocationForSave.RegionNode.OutputData = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData();
            regionAllocationForSave.RegionNode.OutputData.$values = [];

            regionAllocationForSave.RegionNode.PreviousYTDForTrueUp = null;
            regionAllocationForSave.RegionNode.AllDatesForCurrentReportingDate = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate();
            regionAllocationForSave.RegionNode.AllMVarDatesForCurrentReportingDate = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate();

            regionAllocationForSave.RegionNode.HasPnl = false;
            regionAllocationForSave.RegionNode.HasMVaR = false;
            regionAllocationForSave.RegionNode.IsActive = false;
            regionAllocationForSave.RegionNode.PreviousMonthEndDate = "";
            regionAllocationForSave.RegionNode.PreviousTradeDate = "";
            regionAllocationForSave.RegionNode.HasWorkingCapital = false;

            regionAllocationForSave.DividendPartnerNode = null;
            regionAllocationForSave.BusinessSegmentNode = null;

            this.regionAllocations.push(regionAllocationForSave);

            let selectedRegionAllocationItem = this.regionNamesRegionAllocation.find(item => item.value == this.strSelectedRegionAllocationName);

            if (selectedRegionAllocationItem) {
                this.regionNamesRegionAllocation.splice(this.regionNamesRegionAllocation.indexOf(selectedRegionAllocationItem), 1);
            }

            this.strSelectedRegionAllocationName = "NotSet";
            this.strRegionAllocationPercentage = "0";
        }
    }

    private calculateRegionGroupTotal() {
        let total = 0;

        if (this.regionAllocations) {
            this.regionAllocations.forEach(region => {
                total += Number(region.Percentage);
            });
        }

        this.strRegionAllocationValueCheck = total.toString();

        if (total != 100) {
            this.clsRegionAllocationValueCheck = {
                invalidData: true
            };
        }
        else {
            this.clsRegionAllocationValueCheck = {};
        }

        return total;
    }

    onDividendPartnerAddClick() {
        let selectedDividendPartnerAllocation = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == this.strSelectedDividendAllocationName);

        if (selectedDividendPartnerAllocation) {
            let dividendPartnerAllocationForSave: IHierarchyEditNode_DividendPartnerAllocations_Values = new clsHierarchyEditNode_DividendPartnerAllocations_Values();

            dividendPartnerAllocationForSave.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.AllocationStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            dividendPartnerAllocationForSave.Percentage = Number(this.strDividendAllocationPercentage);

            dividendPartnerAllocationForSave.DividendPartnerNode = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode();
            dividendPartnerAllocationForSave.DividendPartnerNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";

            dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner();
            let dividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == this.strSelectedDividendAllocationName)

            if (dividendPartner) {
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.$type = dividendPartner.$type;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Created = dividendPartner.Created;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.CreatedBy = dividendPartner.CreatedBy;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Id = dividendPartner.Id;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.IsInUse = dividendPartner.IsInUse;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Name = dividendPartner.Name;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Updated = dividendPartner.Updated;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.UpdatedBy = dividendPartner.UpdatedBy;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Editable = dividendPartner.Editable;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.BusinessSegment = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment();
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.BusinessSegment = dividendPartner.BusinessSegment;
            }

            dividendPartnerAllocationForSave.DividendPartnerNode.Name = this.strSelectedDividendAllocationName;
            dividendPartnerAllocationForSave.DividendPartnerNode.Description = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.IsMarkedForDeletion = false;

            dividendPartnerAllocationForSave.DividendPartnerNode.NodeType = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType();
            //let node = this.nodeTypes.find(node => node.Name.toLowerCase() == "dividend partner allocation")
            let systemNodeTypes: IHierarchyEditNode_Node_NodeType[] = <IHierarchyEditNode_Node_NodeType[]>JSON.parse(localStorage.getItem("systemNodeTypes"));
            let node = systemNodeTypes.find(node => node.Name.toLowerCase() == "dividend partner allocation")

            if (node) {
                dividendPartnerAllocationForSave.DividendPartnerNode.NodeType = node;
            }

            dividendPartnerAllocationForSave.DividendPartnerNode.IsPnlHolder = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.InputYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.InputExpectedYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.DividendYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.ReportedMEYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.CanRemove = false;

            dividendPartnerAllocationForSave.DividendPartnerNode.InputData = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData();
            dividendPartnerAllocationForSave.DividendPartnerNode.InputData.$values = [];

            dividendPartnerAllocationForSave.DividendPartnerNode.OutputData = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData();
            dividendPartnerAllocationForSave.DividendPartnerNode.OutputData.$values = [];

            dividendPartnerAllocationForSave.DividendPartnerNode.PreviousYTDForTrueUp = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.AllDatesForCurrentReportingDate = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate();
            dividendPartnerAllocationForSave.DividendPartnerNode.AllMVarDatesForCurrentReportingDate = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate();

            dividendPartnerAllocationForSave.DividendPartnerNode.HasPnl = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.HasMVaR = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.IsActive = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.PreviousMonthEndDate = "";
            dividendPartnerAllocationForSave.DividendPartnerNode.PreviousTradeDate = "";
            dividendPartnerAllocationForSave.DividendPartnerNode.HasWorkingCapital = false;

            dividendPartnerAllocationForSave.RegionNode = null;
            dividendPartnerAllocationForSave.BusinessSegmentNode = null;

            this.dividendPartnerAllocations.push(dividendPartnerAllocationForSave);

            let selectedDividendPartnerAllocationItem = this.dividendPartnerNames.find(item => item.value == this.strSelectedDividendAllocationName);

            if (selectedDividendPartnerAllocationItem) {
                this.dividendPartnerNames.splice(this.dividendPartnerNames.indexOf(selectedDividendPartnerAllocationItem), 1);
            }

            this.strSelectedDividendAllocationName = "NotSet";
            this.strDividendAllocationPercentage = "0";
        }

    }

    private calculateDividendPartnerGroupTotal() {
        let total = 0;

        if (this.dividendPartnerAllocations) {
            this.dividendPartnerAllocations.forEach(dividendPartner => {
                total += Number(dividendPartner.Percentage);
            });
        }

        this.strDividendAllocationValueCheck = total.toString();

        if (total > 100) {
            this.clsDividendAllocationValueCheck = {
                invalidData: true
            };
        }
        else {
            this.clsDividendAllocationValueCheck = {};
        }

        return total;
    }

    private onPnlPlanRowSelect(event: any) {
        this.selectedPnlPlan = event.data;

        this.strSelectedPnlPlanYear = this.pnlPlanYears[0].value;

        if (this.selectedPnlPlan) {
            this.filteredPnlPlanYearToMonthPerRegion = [];
            this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
                .filter(plnPlan => plnPlan.strYear == this.strSelectedPnlPlanYear && plnPlan.strRegionName == this.selectedPnlPlan.strRegionName);
        }
    }

    private setPnlPlanForRegion() {
        this.pnlPlans = this.editNodeCompleteData.Plans.$values.filter(plan => plan.DividendPartner == null);

        this.pnlPlans.forEach(plan => {
            let pnlPlan: clsPlanDataPerRegion = new clsPlanDataPerRegion();
            let totalPlanValue: number = 0;
            let selectedPnlPlanRegion: SelectItem;

            selectedPnlPlanRegion = this.regionNamesPlanRegionAllocation ? this.regionNamesPlanRegionAllocation.find(region => region.value == plan.Region.Name) : null;

            if (selectedPnlPlanRegion) {
                this.regionNamesPlanRegionAllocation.splice(this.regionNamesPlanRegionAllocation.indexOf(selectedPnlPlanRegion), 1);
            }

            pnlPlan.strRegionName = plan.Region.Name;

            plan.PlanValues.$values.forEach(planValue => {
                totalPlanValue += planValue.Value;

                let pnlPlanYearToMonthPerRegion: clsPnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();

                pnlPlanYearToMonthPerRegion.strRegionName = plan.Region.Name;
                pnlPlanYearToMonthPerRegion.strYear = planValue.Year.toString();
                pnlPlanYearToMonthPerRegion.strMonthValue = planValue.Month.toString();
                pnlPlanYearToMonthPerRegion.strPlanValue = planValue.Value ? planValue.Value.toString() : "0";

                switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                    case "1": pnlPlanYearToMonthPerRegion.strMonthDesc = "January"; break;
                    case "2": pnlPlanYearToMonthPerRegion.strMonthDesc = "February"; break;
                    case "3": pnlPlanYearToMonthPerRegion.strMonthDesc = "March"; break;
                    case "4": pnlPlanYearToMonthPerRegion.strMonthDesc = "April"; break;
                    case "5": pnlPlanYearToMonthPerRegion.strMonthDesc = "May"; break;
                    case "6": pnlPlanYearToMonthPerRegion.strMonthDesc = "June"; break;
                    case "7": pnlPlanYearToMonthPerRegion.strMonthDesc = "July"; break;
                    case "8": pnlPlanYearToMonthPerRegion.strMonthDesc = "August"; break;
                    case "9": pnlPlanYearToMonthPerRegion.strMonthDesc = "September"; break;
                    case "10": pnlPlanYearToMonthPerRegion.strMonthDesc = "October"; break;
                    case "11": pnlPlanYearToMonthPerRegion.strMonthDesc = "November"; break;
                    case "12": pnlPlanYearToMonthPerRegion.strMonthDesc = "December"; break;
                    default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }

                this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
            });
            pnlPlan.TotalPlan = totalPlanValue;

            pnlPlan.strUpdatedBy = plan.UpdatedBy;
            pnlPlan.strUpdatedDate = plan.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(plan.Updated)) : null;

            this.pnlPlansArray.push(pnlPlan);
        });
    }

    onPnlPlanAddClick() {
        // use this when passing the data for the pnlPlan vlaues to server.
        // Logic should be like, only those years data should be passed to the server which has atleast one value present for a month in that year.
        // This can be achieved by using following logic -->
        // 1. Get the first year item from the pnlPlanYears array.
        // 2. Loop through the completePnlPlanYearToMonthPerRegion array for that particular year and region and check if there exists any such entry which is having non zero or non null value.
        //    If the entry exists, then move to next year and region combination.
        //    Else, delete the set of entries for that particular region and year combination from the completePnlPlanYearToMonthPerRegion array.

        let selectedPnlPlanRegion = this.regions.find(region => region.Name == this.strSelectedPnlPlanRegionAllocationName);

        if (selectedPnlPlanRegion) {
            let newPnlPlanPerRegion: clsPlanDataPerRegion = new clsPlanDataPerRegion();

            newPnlPlanPerRegion.strRegionName = this.strSelectedPnlPlanRegionAllocationName;
            newPnlPlanPerRegion.TotalPlan = 0;
            this.pnlPlansArray.push(newPnlPlanPerRegion);

            this.selectedPnlPlan = newPnlPlanPerRegion;

            let currentYear = new Date().getFullYear();

            for (let yearCount: number = currentYear; yearCount <= (currentYear + 10); yearCount++) {
                for (let monthCount: number = 1; monthCount <= 12; monthCount++) {

                    let pnlPlanYearToMonthPerRegion: clsPnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();
                    pnlPlanYearToMonthPerRegion.strYear = yearCount.toString();
                    pnlPlanYearToMonthPerRegion.strPlanValue = "0";
                    pnlPlanYearToMonthPerRegion.strRegionName = this.selectedPnlPlan.strRegionName;
                    pnlPlanYearToMonthPerRegion.strMonthValue = monthCount.toString();

                    switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                        case "1": pnlPlanYearToMonthPerRegion.strMonthDesc = "January"; break;
                        case "2": pnlPlanYearToMonthPerRegion.strMonthDesc = "February"; break;
                        case "3": pnlPlanYearToMonthPerRegion.strMonthDesc = "March"; break;
                        case "4": pnlPlanYearToMonthPerRegion.strMonthDesc = "April"; break;
                        case "5": pnlPlanYearToMonthPerRegion.strMonthDesc = "May"; break;
                        case "6": pnlPlanYearToMonthPerRegion.strMonthDesc = "June"; break;
                        case "7": pnlPlanYearToMonthPerRegion.strMonthDesc = "July"; break;
                        case "8": pnlPlanYearToMonthPerRegion.strMonthDesc = "August"; break;
                        case "9": pnlPlanYearToMonthPerRegion.strMonthDesc = "September"; break;
                        case "10": pnlPlanYearToMonthPerRegion.strMonthDesc = "October"; break;
                        case "11": pnlPlanYearToMonthPerRegion.strMonthDesc = "November"; break;
                        case "12": pnlPlanYearToMonthPerRegion.strMonthDesc = "December"; break;
                        default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                    }
                    this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
                }
            }

            this.filteredPnlPlanYearToMonthPerRegion = [];
            this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
                .filter(plnPlan => plnPlan.strYear == this.strSelectedPnlPlanYear && plnPlan.strRegionName == this.selectedPnlPlan.strRegionName);

            this.strSelectedPnlPlanYear = currentYear.toString();

            let selectedPnlPlanRegionName = this.regionNamesPlanRegionAllocation.find(pnlPlanRegion => pnlPlanRegion.value == this.strSelectedPnlPlanRegionAllocationName);

            if (selectedPnlPlanRegionName) {
                this.regionNamesPlanRegionAllocation.splice(this.regionNamesPlanRegionAllocation.indexOf(selectedPnlPlanRegionName), 1);
            }

            this.strSelectedPnlPlanRegionAllocationName = "NotSet";
        }
    }

    private pnlPlanYearForRegionChange() {
        let PnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion.find(item => item.strRegionName == this.selectedPnlPlan.strRegionName && item.strYear == this.strSelectedPnlPlanYear);

        if (PnlPlanYearToMonthPerRegion == null) {

            for (let count: number = 1; count <= 12; count++) {

                let pnlPlanYearToMonthPerRegion: clsPnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();
                pnlPlanYearToMonthPerRegion.strYear = this.strSelectedPnlPlanYear;
                pnlPlanYearToMonthPerRegion.strPlanValue = "0";
                pnlPlanYearToMonthPerRegion.strRegionName = this.selectedPnlPlan.strRegionName;
                pnlPlanYearToMonthPerRegion.strMonthValue = count.toString();

                switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                    case "1": pnlPlanYearToMonthPerRegion.strMonthDesc = "January"; break;
                    case "2": pnlPlanYearToMonthPerRegion.strMonthDesc = "February"; break;
                    case "3": pnlPlanYearToMonthPerRegion.strMonthDesc = "March"; break;
                    case "4": pnlPlanYearToMonthPerRegion.strMonthDesc = "April"; break;
                    case "5": pnlPlanYearToMonthPerRegion.strMonthDesc = "May"; break;
                    case "6": pnlPlanYearToMonthPerRegion.strMonthDesc = "June"; break;
                    case "7": pnlPlanYearToMonthPerRegion.strMonthDesc = "July"; break;
                    case "8": pnlPlanYearToMonthPerRegion.strMonthDesc = "August"; break;
                    case "9": pnlPlanYearToMonthPerRegion.strMonthDesc = "September"; break;
                    case "10": pnlPlanYearToMonthPerRegion.strMonthDesc = "October"; break;
                    case "11": pnlPlanYearToMonthPerRegion.strMonthDesc = "November"; break;
                    case "12": pnlPlanYearToMonthPerRegion.strMonthDesc = "December"; break;
                    default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }
                this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
            }
        }

        this.filteredPnlPlanYearToMonthPerRegion = [];
        this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
            .filter(plnPlan => plnPlan.strYear == this.strSelectedPnlPlanYear && plnPlan.strRegionName == this.selectedPnlPlan.strRegionName);
    }

    deletePnlPlanForRegion(pnlPlan: clsPlanDataPerRegion) {
        this.blnShowConfirmDialog = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected Pnl Plan will be deleted. Are you sure?',
            accept: () => {
                this.pnlPlansArray.splice(this.pnlPlansArray.indexOf(pnlPlan), 1);

                this.regionNamesPlanRegionAllocation.push({ label: pnlPlan.strRegionName, value: pnlPlan.strRegionName });

                // filter the completePnlPlanYearToMonthPerRegion to remove out the items based on the region deleted.
                let filterPnlPlanArray = this.completePnlPlanYearToMonthPerRegion.filter(pnlPlanYearToMonthPerRegion => pnlPlanYearToMonthPerRegion.strRegionName != pnlPlan.strRegionName);

                // reassign the filterred array items list.
                this.completePnlPlanYearToMonthPerRegion = filterPnlPlanArray;

                this.selectedPnlPlan = this.pnlPlansArray && this.pnlPlansArray.length > 0 ? this.pnlPlansArray[0] : new clsPlanDataPerRegion();

                this.filteredPnlPlanYearToMonthPerRegion = [];
                this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
                    .filter(plnPlan => plnPlan.strYear == this.strSelectedPnlPlanYear && plnPlan.strRegionName == this.selectedPnlPlan.strRegionName);
                this.blnShowConfirmDialog = false;
            },
            reject: () => {
                this.blnShowConfirmDialog = false;
            }
        });
    }

    onCustomNumericValidation(event: any) {
        return String.fromCharCode(event.charCode).match(/[0-9]/g) != null;
    }

    onCustomNumericValidationForPositiveAndNegativeIntegers(event: any) {
        return String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null;
    }

    private calculatePnlPlanPerRegionToYearTotal() {
        let total = 0;

        let filteredPnlPlanPerRegionPerYear: clsPnlPlanYearToMonthPerRegion[] = this.completePnlPlanYearToMonthPerRegion
            .filter(plan => plan.strRegionName == this.selectedPnlPlan.strRegionName && plan.strYear == this.strSelectedPnlPlanYear);

        filteredPnlPlanPerRegionPerYear.forEach(plan => {
            total += Number(plan.strPlanValue);
        });

        return total;
    }

    private calculateTotalPnlPlanPerRegion(event: any) {
        let total = 0;

        let filteredPnlPlanPerRegion: clsPnlPlanYearToMonthPerRegion[] = this.completePnlPlanYearToMonthPerRegion
            .filter(plan => plan.strRegionName == this.selectedPnlPlan.strRegionName);

        filteredPnlPlanPerRegion.forEach(plan => {
            total += Number(plan.strPlanValue);
        });

        this.selectedPnlPlan.TotalPlan = total;
    }

    private calculatePnlPlanTotal() {
        let total = 0;

        this.completePnlPlanYearToMonthPerRegion.forEach(plan => {
            total += Number(plan.strPlanValue);
        });

        return total;
    }

    private setDividendPlanForDividendPartner() {
        this.dividendPlansArray = [];
        this.dividendPlans = this.editNodeCompleteData.Plans.$values.filter(plan => plan.DividendPartner != null);

        this.dividendPlans.forEach(plan => {
            let dividendPlan: clsPlanDataPerDividendPartner = new clsPlanDataPerDividendPartner();
            let totalPlanValue: number = 0;

            dividendPlan.strRegionName = plan.Region.Name;
            dividendPlan.strDividendPartnerName = plan.DividendPartner.Name;

            plan.PlanValues.$values.forEach(planValue => {
                totalPlanValue += planValue.Value;

                let dividendPlanYearToMonthPerRegion: clsDividendPlanYearToMonthPerRegion = new clsDividendPlanYearToMonthPerRegion();

                dividendPlanYearToMonthPerRegion.strDividendPartnerName = plan.DividendPartner.Name;
                dividendPlanYearToMonthPerRegion.strRegionName = plan.Region.Name;
                dividendPlanYearToMonthPerRegion.strYear = planValue.Year.toString();
                dividendPlanYearToMonthPerRegion.strMonthValue = planValue.Month.toString();
                dividendPlanYearToMonthPerRegion.strPlanValue = planValue.Value ? planValue.Value.toString() : "0";

                switch (dividendPlanYearToMonthPerRegion.strMonthValue) {
                    case "1": dividendPlanYearToMonthPerRegion.strMonthDesc = "January"; break;
                    case "2": dividendPlanYearToMonthPerRegion.strMonthDesc = "February"; break;
                    case "3": dividendPlanYearToMonthPerRegion.strMonthDesc = "March"; break;
                    case "4": dividendPlanYearToMonthPerRegion.strMonthDesc = "April"; break;
                    case "5": dividendPlanYearToMonthPerRegion.strMonthDesc = "May"; break;
                    case "6": dividendPlanYearToMonthPerRegion.strMonthDesc = "June"; break;
                    case "7": dividendPlanYearToMonthPerRegion.strMonthDesc = "July"; break;
                    case "8": dividendPlanYearToMonthPerRegion.strMonthDesc = "August"; break;
                    case "9": dividendPlanYearToMonthPerRegion.strMonthDesc = "September"; break;
                    case "10": dividendPlanYearToMonthPerRegion.strMonthDesc = "October"; break;
                    case "11": dividendPlanYearToMonthPerRegion.strMonthDesc = "November"; break;
                    case "12": dividendPlanYearToMonthPerRegion.strMonthDesc = "December"; break;
                    default: dividendPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }

                this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerRegion);
            });
            dividendPlan.TotalPlan = totalPlanValue;

            dividendPlan.strUpdatedBy = plan.UpdatedBy;
            dividendPlan.strUpdatedDate = plan.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(plan.Updated)) : null;

            this.dividendPlansArray.push(dividendPlan);
        });

        this.sortDividendPlanArray();
    }

    private onDividendPlanRowSelect(event: any) {
        this.selectedDividendPlan = event.data;

        this.strSelectedDividendPlanYear = this.dividendPlanYears[0].value;

        if (this.selectedDividendPlan) {
            this.filteredDividendPlanYearToMonthPerRegion = [];
            this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
                .filter(dividendPlan => dividendPlan.strYear == this.strSelectedDividendPlanYear
                    && dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
                    && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName);
        }
    }

    private deleteDividendPlanForDividendPartnerAndRegion(dividendPlan: clsPlanDataPerDividendPartner) {
        this.blnShowConfirmDialog = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected Dividend Plan will be deleted. Are you sure?',
            accept: () => {
                //debugger;
                this.dividendPlansArray.splice(this.dividendPlansArray.indexOf(dividendPlan), 1);

                // filter the completeDividendPlanYearToMonthPerRegion to remove out the items based on the region deleted.
                let filterDividendPlanArray = this.completeDividendPlanYearToMonthPerRegion
                    .filter(dividendPlanYearToMonthPerRegion => (dividendPlanYearToMonthPerRegion.strRegionName != dividendPlan.strRegionName
                        || dividendPlanYearToMonthPerRegion.strDividendPartnerName != dividendPlan.strDividendPartnerName));

                // reassign the filterred array items list.
                this.completeDividendPlanYearToMonthPerRegion = filterDividendPlanArray;

                this.selectedDividendPlan = this.dividendPlansArray && this.dividendPlansArray.length > 0 ? this.dividendPlansArray[0] : new clsPlanDataPerDividendPartner();

                this.filteredDividendPlanYearToMonthPerRegion = [];
                this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
                    .filter(dividendPlan => dividendPlan.strYear == this.strSelectedDividendPlanYear
                        && dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
                        && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName);
                this.blnShowConfirmDialog = false;
            },
            reject: () => {
                this.blnShowConfirmDialog = false;
            }
        });
    }

    private calculateDividendPlanTotal(strDivPartnerName: string) {
        let total = 0;

        let filteredPlanPerDividendPartner: clsDividendPlanYearToMonthPerRegion[] = [];

        filteredPlanPerDividendPartner = this.completeDividendPlanYearToMonthPerRegion.filter(plan => plan.strDividendPartnerName == strDivPartnerName);

        filteredPlanPerDividendPartner.forEach(plan => {
            total += Number(plan.strPlanValue);
        });

        return total;
    }

    onDividendPlanAddClick() {
        let itemToBeAddedIndex = this.completeDividendPlanYearToMonthPerRegion.
            findIndex(divPlan => divPlan.strDividendPartnerName == this.strSelectedDividendPlanDividendPartnerName
                && divPlan.strRegionName == this.strSelectedDividendPlanRegionAllocationName);

        if (itemToBeAddedIndex != -1) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Duplicate record";
            this.strValidationMessage = "The plan for selected dividend partner already exists.\n\n" +
                "You can modify the plan in the table below or delete the existing record and enter a new value.";
        }
        else {
            let selectedDividendPlanRegion = this.regions.find(region => region.Name == this.strSelectedDividendPlanRegionAllocationName);
            let selectedDividendPlanDividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == this.strSelectedDividendPlanDividendPartnerName);

            if (selectedDividendPlanRegion && selectedDividendPlanDividendPartner) {
                let newDividendPlanPerDividendPartner: clsPlanDataPerDividendPartner = new clsPlanDataPerDividendPartner();

                newDividendPlanPerDividendPartner.strRegionName = this.strSelectedDividendPlanRegionAllocationName;
                newDividendPlanPerDividendPartner.strDividendPartnerName = this.strSelectedDividendPlanDividendPartnerName;
                newDividendPlanPerDividendPartner.TotalPlan = 0;

                this.dividendPlansArray.push(newDividendPlanPerDividendPartner);

                this.selectedDividendPlan = newDividendPlanPerDividendPartner;

                let currentYear = new Date().getFullYear();

                for (let yearCount: number = currentYear; yearCount <= (currentYear + 10); yearCount++) {
                    for (let monthCount: number = 1; monthCount <= 12; monthCount++) {

                        let dividendPlanYearToMonthPerDividendPartnerAndRegion: clsDividendPlanYearToMonthPerRegion = new clsDividendPlanYearToMonthPerRegion();
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strYear = yearCount.toString();
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strPlanValue = "0";
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strRegionName = this.selectedDividendPlan.strRegionName;
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strDividendPartnerName = this.selectedDividendPlan.strDividendPartnerName
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthValue = monthCount.toString();

                        switch (dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthValue) {
                            case "1": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "January"; break;
                            case "2": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "February"; break;
                            case "3": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "March"; break;
                            case "4": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "April"; break;
                            case "5": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "May"; break;
                            case "6": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "June"; break;
                            case "7": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "July"; break;
                            case "8": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "August"; break;
                            case "9": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "September"; break;
                            case "10": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "October"; break;
                            case "11": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "November"; break;
                            case "12": dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "December"; break;
                            default: dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "Invalid Month";
                        }
                        this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerDividendPartnerAndRegion);
                    }
                }

                this.filteredDividendPlanYearToMonthPerRegion = [];
                this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
                    .filter(dividendPlan => dividendPlan.strYear == this.strSelectedDividendPlanYear
                        && dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
                        && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName);

                this.strSelectedDividendPlanYear = currentYear.toString();
                this.sortDividendPlanArray();
            }
        }
    }

    private dividendPlanYearForDividendPartnerChange() {
        let dividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .find(item => item.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName &&
                item.strRegionName == this.selectedDividendPlan.strRegionName && item.strYear == this.strSelectedDividendPlanYear);

        if (dividendPlanYearToMonthPerRegion == null) {

            for (let count: number = 1; count <= 12; count++) {

                let dividendPlanYearToMonthPerRegion: clsDividendPlanYearToMonthPerRegion = new clsDividendPlanYearToMonthPerRegion();
                dividendPlanYearToMonthPerRegion.strYear = this.strSelectedDividendPlanYear;
                dividendPlanYearToMonthPerRegion.strPlanValue = "0";
                dividendPlanYearToMonthPerRegion.strDividendPartnerName = this.selectedDividendPlan.strDividendPartnerName;
                dividendPlanYearToMonthPerRegion.strRegionName = this.selectedDividendPlan.strRegionName;
                dividendPlanYearToMonthPerRegion.strMonthValue = count.toString();

                switch (dividendPlanYearToMonthPerRegion.strMonthValue) {
                    case "1": dividendPlanYearToMonthPerRegion.strMonthDesc = "January"; break;
                    case "2": dividendPlanYearToMonthPerRegion.strMonthDesc = "February"; break;
                    case "3": dividendPlanYearToMonthPerRegion.strMonthDesc = "March"; break;
                    case "4": dividendPlanYearToMonthPerRegion.strMonthDesc = "April"; break;
                    case "5": dividendPlanYearToMonthPerRegion.strMonthDesc = "May"; break;
                    case "6": dividendPlanYearToMonthPerRegion.strMonthDesc = "June"; break;
                    case "7": dividendPlanYearToMonthPerRegion.strMonthDesc = "July"; break;
                    case "8": dividendPlanYearToMonthPerRegion.strMonthDesc = "August"; break;
                    case "9": dividendPlanYearToMonthPerRegion.strMonthDesc = "September"; break;
                    case "10": dividendPlanYearToMonthPerRegion.strMonthDesc = "October"; break;
                    case "11": dividendPlanYearToMonthPerRegion.strMonthDesc = "November"; break;
                    case "12": dividendPlanYearToMonthPerRegion.strMonthDesc = "December"; break;
                    default: dividendPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }
                this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerRegion);
            }
        }
        this.filteredDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .filter(dividendPlan => dividendPlan.strYear == this.strSelectedDividendPlanYear
                && dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
                && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName);
    }

    private calculateTotalDividendPlanPerDividendPartner(event: any) {
        let total = 0;

        let filteredPlanPerDividendPartner: clsDividendPlanYearToMonthPerRegion[] = this.completeDividendPlanYearToMonthPerRegion
            .filter(dividendPlan => dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
                && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName);

        filteredPlanPerDividendPartner.forEach(dividendPlan => {
            total += Number(dividendPlan.strPlanValue);
        });

        this.selectedDividendPlan.TotalPlan = total;
    }

    private calculateDividendPlanPerRegionToYearTotal() {
        let total = 0;

        let filteredDividendPlanPerRegionPerYear: clsDividendPlanYearToMonthPerRegion[] = this.completeDividendPlanYearToMonthPerRegion
            .filter(dividendPlan => dividendPlan.strRegionName == this.selectedDividendPlan.strRegionName
                && dividendPlan.strDividendPartnerName == this.selectedDividendPlan.strDividendPartnerName
                && dividendPlan.strYear == this.strSelectedDividendPlanYear);

        filteredDividendPlanPerRegionPerYear.forEach(dividendPlan => {
            total += Number(dividendPlan.strPlanValue);
        });

        return total;
    }

    private sortDividendPlanArray() {
        this.dividendPlansArray.sort((n1, n2) => {
            if (n1.strDividendPartnerName > n2.strDividendPartnerName) {
                return 1;
            }

            if (n1.strDividendPartnerName < n2.strDividendPartnerName) {
                return -1;
            }

            return 0;
        });
    }

    private checkIfArrayIsUnique(myArray: string[]): boolean {
        return myArray.length === new Set(myArray).size;
    }

    private stopRefreshing() {
        //console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    private setUserRolesData(data: any): void {
        this.availableRoles.$values = [];
        this.availableRoles.$values = data.Result.UserRoles.$values;

        this.availableRoles.$values.forEach((role: any) => {
            this.userRoles.push(role.Name);
        });

        //console.log("User Role ->", this.userRoles);
        localStorage.setItem("UserRole", JSON.stringify(this.userRoles));
    }

    public getConstants(data: any): void {
        //console.log("Constants ->", data);
        this.constants = data;
        this.AuthorizeUser();
    }

    private AuthorizeUser() {
        this.canEditNode = this.isUserAuthorised("EditNode");
        this.canEnterValue = this.isUserAuthorised("EnterValue");
        this.canEditHierarchy = this.isUserAuthorised("EditHierarchy");
    }

    public isUserAuthorised(action: string): boolean {
        //console.log("Authorize Action ->", action);
        switch (action) {
            case "EditNode":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        this.userRoles.some(x => x == this.constants.TPRITSupport));
            case "EnterValue":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        this.userRoles.some(x => x == this.constants.TPRMarginManagement) ||
                        this.userRoles.some(x => x == this.constants.TPRRiskManagement));
            case "EditHierarchy":
                return this.userRoles != undefined && this.constants != undefined &&
                    this.userRoles.some(x => x == this.constants.TPRSuperUser);
            default: return false;
        }
    }
}

class NodeArray {
    Id: number;
    MVarUpdateTiming: number;
    UpdateTiming: number;
    ParentId: number;
    NodeName: string;
}

class ProfitAlertGroupArray {
    Name: string;
    UpdateTiming: number;
    Id: number;
    IsInUse: boolean;
    TradeDate: string;
    ProfitAlertGroupStatusId: string;
    Created: string;
    CreatedBy: string;
    Updated: string;
    UpdatedBy: string;
}

class clsHierarchyEditNode implements IHierarchyEditNode {
    constructor(
        public $type: string = null,
        public AlertGroups: any = null,
        public BusinessSegmentAllocations: any = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public DividendPartnerAllocations: any = '',
        public HasChildren: boolean = false,
        public HierarchyInstanceId: number = 0,
        public Id: number = 0,
        public IsMarkedForDeletion: boolean = false,
        public LastUpdatedBy: string = null,
        public Level: number = 0,
        public MVarLimit: any = null,
        public MVarRegion: any = null,
        public MVarTemporaryLimit: any = null,
        public MVarTemporaryLimitExpiryDate: any = null,
        public MVarUpdateTiming: any = null,
        public Node: IHierarchyEditNode_Node = null,
        public NodeType: any = null,
        public ParentId: number = 0,
        public ParentNodeId: number = 0,
        public Plans: any = null,
        public PnlSplitValue: any = null,
        public RegionalAllocations: any = null,
        public SplitType: string = null,
        public Tags: any = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public UpdateTiming: any = null,
        public WorkingCapitalRegion: any = null
    ) { }
}

class clsHierarchyEditNode_Node implements IHierarchyEditNode_Node {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public Description: string = null,
        public IsMarkedForDeletion: boolean = false,
        public NodeType: IHierarchyEditNode_Node_NodeType = null,
        public IsPnlHolder: boolean = false,
        public InputYTD: any = null,
        public InputExpectedYTD: any = null,
        public DividendYTD: any = null,
        public ReportedMEYTD: any = null,
        public CanRemove: boolean = false,
        public InputData: IHierarchyEditNode_Node_InputData = null,
        public OutputData: IHierarchyEditNode_Node_OutputData = null,
        public PreviousYTDForTrueUp: any = null,
        public AllDatesForCurrentReportingDate: IHierarchyEditNode_Node_AllDatesForCurrentReportingDate = null,
        public AllMVarDatesForCurrentReportingDate: any = null,
        public HasPnl: boolean = false,
        public HasMVaR: boolean = false,
        public IsActive: boolean = false,
        public InputNameMappings: IHierarchyEditNode_Node_InputNameMappings = null,
        public PreviousMonthEndDate: string = null,
        public PreviousTradeDate: string = null,
        public HasWorkingCapital: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_Node_NodeType implements IHierarchyEditNode_Node_NodeType {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = '',
        public CreatedBy: string = '',
        public Updated: string = '',
        public UpdatedBy: string = '',
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_Node_InputData implements IHierarchyEditNode_Node_InputData {
    constructor(
        public $type: string = null,
        public $values: any = null,
    ) { }
}

class clsHierarchyEditNode_Node_OutputData implements IHierarchyEditNode_Node_OutputData {
    constructor(
        public $type: string = null,
        public $values: any = null,
    ) { }
}

class clsHierarchyEditNode_Node_AllDatesForCurrentReportingDate implements IHierarchyEditNode_Node_AllDatesForCurrentReportingDate {
    constructor(
        public $type: string = null,
        public $values: any = null,
    ) { }
}

class clsHierarchyEditNode_Node_InputNameMappings implements IHierarchyEditNode_Node_InputNameMappings {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_Node_InputNameMappings_Value[] = null,
    ) { }
}

class RootValue implements IRootObject {
    constructor(
        public label: string = null,
        public NodeName: string = null,
        public id: number = 0,
        public children: IRootObject[] = null,
        public Children: IRootObject[] = null,
        public data: any = null,
        public icon: any = null,
        public expandedIcon: any = null,
        public collapsedIcon: any = null,
        public leaf: boolean = null,
        public expanded: boolean = null,
        public type: string = null,
        public parent: IRootObject = null,
        public partialSelected: boolean = null,
        public $type: string = null,
        public HasAnyOutputData: boolean = null,
        public HasPlans: boolean = null,
        public UpdateTiming: any = null,
        public NodeId: number = null,
        public NodeType: string = null,
        public IsActive: boolean = null,
        public Level: number = null,
        public ParentId: number = null,
        public IsPnlHolder: boolean = null,
        public MVarUpdateTiming: number = null,
        public SplitType: string = null,
        public Id: number = 0) { }
}

class clsHierarchyEditNode_Node_InputNameMappings_Value implements IHierarchyEditNode_Node_InputNameMappings_Value {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public FeedSource: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_WorkingCapital implements IHierarchyEditNode_WorkingCapital {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_AlertGroups implements IHierarchyEditNode_AlertGroups {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_AlertGroups_Values[] = null
    ) { }
}

class clsHierarchyEditNode_AlertGroups_Values implements IHierarchyEditNode_AlertGroups_Values {
    constructor(
        public $type: string = null,
        public Alerts: IHierarchyEditNode_AlertGroups_Values_Alerts = null,
        public Name: string = null,
        public Members: IHierarchyEditNode_AlertGroups_Values_Members = null,
        public IsInUse: boolean = false,
        public UpdateTiming: number = 0,
        public TradeDate: string = null,
        public ProfitAlertGroupStatusId: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_AlertGroups_Values_Alerts implements IHierarchyEditNode_AlertGroups_Values_Alerts {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_AlertGroups_Values_Alerts_Values[] = null
    ) { }
}

class clsHierarchyEditNode_AlertGroups_Values_Alerts_Values implements IHierarchyEditNode_AlertGroups_Values_Alerts_Values {
    constructor(
        public $type: string = null,
        public ActionAlerts: IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts = null,
        public AlertGroupType: number = 0,
        public Level: number = 0,
        public AlertGroupId: number = 0,
        public CurrentActionAlertExpiryDate: string = null,
        public CurrentActionAlertLevel: string = null,
        public Actual: any = null,
        public StatusId: any = null,
        public SystemIsNew: boolean = false,
        public SystemIsTriggered: boolean = false,
        public SystemTriggeredDate: string = null,
        public UserIsNew: any = null,
        public UserIsTriggered: any = null,
        public UserTriggeredDate: any = null,
        public ReportedIsNew: boolean = false,
        public ReportedIsTriggered: boolean = false,
        public ReportedTriggeredDate: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts implements IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values[] = null
    ) { }
}

class clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values implements IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values {
    constructor(
        public $type: string = null,
        public AlertId: number = 0,
        public AlertGroupId: number = 0,
        public Level: number = 0,
        public StartDate: string = null,
        public EndDate: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_AlertGroups_Values_Members implements IHierarchyEditNode_AlertGroups_Values_Members {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_AlertGroups_Values_Members_Values[] = null
    ) { }
}

class clsHierarchyEditNode_AlertGroups_Values_Members_Values implements IHierarchyEditNode_AlertGroups_Values_Members_Values {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public NodeId: number = 0,
        public StructureId: number = 0,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_MVarRegion implements IHierarchyEditNode_MVarRegion {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_Tags_Values implements IHierarchyEditNode_Tags_Values {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class TagsValue implements ITagsValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations implements IHierarchyEditNode_RegionalAllocations {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_RegionalAllocations_Values[] = null
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values implements IHierarchyEditNode_RegionalAllocations_Values {
    constructor(
        public $type: string = null,
        public Percentage: number = 0,
        public RegionNode: IHierarchyEditNode_RegionalAllocations_Values_RegionNode = null,
        public DividendPartnerNode: any = null,
        public BusinessSegmentNode: any = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0,
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values_RegionNode implements IHierarchyEditNode_RegionalAllocations_Values_RegionNode {
    constructor(
        public $type: string = null,
        public Region: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region = null,
        public Name: string = null,
        public Description: string = null,
        public IsMarkedForDeletion: boolean = false,
        public NodeType: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType = null,
        public IsPnlHolder: boolean = false,
        public InputYTD: any = null,
        public InputExpectedYTD: any = null,
        public DividendYTD: any = null,
        public ReportedMEYTD: number = null,
        public CanRemove: boolean = false,
        public InputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData = null,
        public OutputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData = null,
        public PreviousYTDForTrueUp: number = 0,
        public AllDatesForCurrentReportingDate: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate = null,
        public AllMVarDatesForCurrentReportingDate: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate = null,
        public HasPnl: boolean = false,
        public HasMVaR: boolean = false,
        public IsActive: boolean = false,
        public InputNameMappings: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings = null,
        public PreviousMonthEndDate: string = null,
        public PreviousTradeDate: string = null,
        public HasWorkingCapital: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region implements IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType implements IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType {

    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData implements IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData_Values[] = []
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData implements IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData_Values[] = []
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate implements IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate {
    constructor(
        public $type: string = null,
        public $values: string[] = []
    ) { }
}

class clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate implements IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate {
    constructor(
        public $type: string = null,
        public $values: string[] = []
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations implements IHierarchyEditNode_DividendPartnerAllocations {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_DividendPartnerAllocations_Values[] = null
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values implements IHierarchyEditNode_DividendPartnerAllocations_Values {
    constructor(
        public $type: string = null,
        public Percentage: number = 0,
        public RegionNode: any = null,
        public DividendPartnerNode: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode = null,
        public BusinessSegmentNode: any = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0,
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode {
    constructor(
        public $type: string = null,
        public DividendPartner: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner = null,
        public Name: string = null,
        public Description: string = null,
        public IsMarkedForDeletion: boolean = false,
        public NodeType: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType = null,
        public IsPnlHolder: boolean = false,
        public InputYTD: any = null,
        public InputExpectedYTD: any = null,
        public DividendYTD: any = null,
        public ReportedMEYTD: number = null,
        public CanRemove: boolean = false,
        public InputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData = null,
        public OutputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData = null,
        public PreviousYTDForTrueUp: number = 0,
        public AllDatesForCurrentReportingDate: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate = null,
        public AllMVarDatesForCurrentReportingDate: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate = null,
        public HasPnl: boolean = false,
        public HasMVaR: boolean = false,
        public IsActive: boolean = false,
        public InputNameMappings: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings = null,
        public PreviousMonthEndDate: string = null,
        public PreviousTradeDate: string = null,
        public HasWorkingCapital: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public BusinessSegment: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment = null,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values[] = []
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData_Values[] = []
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate {
    constructor(
        public $type: string = null,
        public $values: string[] = []
    ) { }
}

class clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate implements IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate {
    constructor(
        public $type: string = null,
        public $values: string[] = []
    ) { }
}

class clsHierarchyEditNode_Plans implements IHierarchyEditNode_Plans {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_Plans_Values[] = []
    ) { }
}

class clsHierarchyEditNode_Plans_Values implements IHierarchyEditNode_Plans_Values {
    constructor(
        public $type: string = null,
        public DividendPartner: IHierarchyEditNode_Plans_Values_DividendPartner = null,
        public Region: IHierarchyEditNode_Plans_Values_Region = null,
        public PlanValues: IHierarchyEditNode_Plans_Values_PlanValues = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_Plans_Values_DividendPartner implements IHierarchyEditNode_Plans_Values_DividendPartner {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public BusinessSegment: IHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment = null,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment implements IHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_Plans_Values_Region implements IHierarchyEditNode_Plans_Values_Region {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyEditNode_Plans_Values_PlanValues implements IHierarchyEditNode_Plans_Values_PlanValues {
    constructor(
        public $type: string = null,
        public $values: IHierarchyEditNode_Plans_Values_PlanValues_Values[] = []
    ) { }
}

class clsHierarchyEditNode_Plans_Values_PlanValues_Values implements IHierarchyEditNode_Plans_Values_PlanValues_Values {
    constructor(
        public $type: string = null,
        public Year: number = 0,
        public Month: number = 0,
        public Value: number = 0,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsPlanDataPerRegion {
    constructor(
        public strRegionName: string = null,
        public TotalPlan: number = 0,
        public strUpdatedBy: string = null,
        public strUpdatedDate: string = null
    ) { }
}

class clsPnlPlanYearToMonthPerRegion {
    constructor(
        public strRegionName: string = null,
        public strYear: string = null,
        public strMonthDesc: string = null,
        public strMonthValue: string = null,
        public strPlanValue: string = null
    ) { }
}

class clsPlanDataPerDividendPartner {
    constructor(
        public strDividendPartnerName: string = '',
        public strRegionName: string = '',
        public TotalPlan: number = 0,
        public strUpdatedBy: string = null,
        public strUpdatedDate: string = null
    ) { }
}

class clsDividendPlanYearToMonthPerRegion {
    constructor(
        public strDividendPartnerName: string = null,
        public strRegionName: string = null,
        public strYear: string = null,
        public strMonthDesc: string = null,
        public strMonthValue: string = null,
        public strPlanValue: string = null
    ) { }
}


/* Post node data starts here */
class clsHierarchyNodePostData implements IHierarchyNodePostData {
    constructor(
        public $type: string = null,
        public AlertGroups: IHierarchyNodePostData_Alerts[] = [],
        public BusinessSegmentAllocations: any = null, // change later
        public Created: string = null,
        public CreatedBy: string = null,
        public DividendPartnerAllocations: IHierarchyNodePostData_DividendPartnerAllocations[] = [],
        public HasChildren: boolean = false,
        public HierarchyInstanceId: number = 0,
        public Id: number = 0,
        public IsMarkedForDeletion: boolean = false,
        public LastUpdatedBy: string = null,
        public Level: number = null,
        public MVarLimit: any = null, // change later
        public MVarRegion: IHierarchyEditNode_MVarRegion = null,
        public MVarTemporaryLimit: any = null, // change later
        public MVarTemporaryLimitExpiryDate: any = null, // change later
        public MVarUpdateTiming: number = 0,
        public Node: IHierarchyNodePostData_Node = null,
        public NodeType: any = null,//change later
        public ParentId: number = 0,
        public ParentNodeId: number = 0,
        public Plans: IHierarchyNodePostData_Plans[] = [],
        public PnlSplitValue: any = null, // change later
        public RegionalAllocations: IHierarchyNodePostData_RegionalAllocations[] = [],
        public SplitType: string = null, // change later
        public Tags: IHierarchyEditNode_Tags_Values[] = [],
        public Updated: string = null,
        public UpdatedBy: string = null,
        public UpdateTiming: number = 0,
        public WorkingCapitalRegion: IHierarchyEditNode_WorkingCapital = null
    ) { }
}

class clsHierarchyNodePostData_Alerts implements IHierarchyNodePostData_Alerts {
    constructor(
        public $type: string = null,
        public Alerts: IHierarchyEditNode_AlertGroups_Values_Alerts_Values[] = [],
        public Name: string = null,
        public Members: IHierarchyEditNode_AlertGroups_Values_Members_Values[] = [],
        public IsInUse: boolean = false,
        public UpdateTiming: number = 0,
        public TradeDate: string = null,
        public ProfitAlertGroupStatusId: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_Node implements IHierarchyNodePostData_Node {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public Description: string = null,
        public IsMarkedForDeletion: boolean = false,
        public NodeType: IHierarchyEditNode_Node_NodeType = null,
        public IsPnlHolder: boolean = false,
        public InputYTD: number = 0,
        public InputExpectedYTD: any = null,
        public DividendYTD: any = null,
        public ReportedMEYTD: any = null,
        public CanRemove: boolean = false,
        public InputData: IHierarchyEditNode_Node_InputData_Values[] = [],
        public OutputData: IHierarchyEditNode_Node_OutputData_Values[] = [],
        public PreviousYTDForTrueUp: number = 0,
        public AllDatesForCurrentReportingDate: string[] = [],
        public AllMVarDatesForCurrentReportingDate: string[] = [],
        public HasPnl: boolean = false,
        public HasMVaR: boolean = false,
        public IsActive: boolean = false,
        public InputNameMappings: IHierarchyEditNode_Node_InputNameMappings_Value[] = [],
        public PreviousMonthEndDate: string = null,
        public PreviousTradeDate: string = null,
        public HasWorkingCapital: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_RegionalAllocations implements IHierarchyNodePostData_RegionalAllocations {
    constructor(
        public $type: string = null,
        public Percentage: number = 0,
        public RegionNode: IHierarchyNodePostData_RegionalAllocations_RegionNode = null,
        public DividendPartnerNode: any = null,
        public BusinessSegmentNode: any = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_RegionalAllocations_RegionNode implements IHierarchyNodePostData_RegionalAllocations_RegionNode {
    constructor(
        public $type: string = null,
        public Region: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region = null,
        public Name: string = null,
        public Description: string = null,
        public IsMarkedForDeletion: boolean = false,
        public NodeType: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType = null,
        public IsPnlHolder: boolean = false,
        public InputYTD: any = null,
        public InputExpectedYTD: any = null,
        public DividendYTD: any = null,
        public ReportedMEYTD: any = null,
        public CanRemove: boolean = false,
        public InputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData_Values[] = [],
        public OutputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData_Values[] = [],
        public PreviousYTDForTrueUp: number = 0,
        public AllDatesForCurrentReportingDate: string[] = [],
        public AllMVarDatesForCurrentReportingDate: string[] = [],
        public HasPnl: boolean = false,
        public HasMVaR: boolean = false,
        public IsActive: boolean = false,
        public InputNameMappings: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings_Values[] = [],
        public PreviousMonthEndDate: string = null,
        public PreviousTradeDate: string = null,
        public HasWorkingCapital: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_DividendPartnerAllocations implements IHierarchyNodePostData_DividendPartnerAllocations {
    constructor(
        public $type: string = null,
        public Percentage: number = 0,
        public RegionNode: any = null,
        public DividendPartnerNode: IHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode = null,
        public BusinessSegmentNode: any = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode implements IHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode {
    constructor(
        public $type: string = null,
        public DividendPartner: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner = null,
        public Name: string = null,
        public Description: string = null,
        public IsMarkedForDeletion: boolean = false,
        public NodeType: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType = null,
        public IsPnlHolder: boolean = false,
        public InputYTD: any = null,
        public InputExpectedYTD: any = null,
        public DividendYTD: any = null,
        public ReportedMEYTD: any = null,
        public CanRemove: boolean = false,
        public InputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values[] = [],
        public OutputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData_Values[] = [],
        public PreviousYTDForTrueUp: number = 0,
        public AllDatesForCurrentReportingDate: string[] = [],
        public AllMVarDatesForCurrentReportingDate: string[] = [],
        public HasPnl: boolean = false,
        public HasMVaR: boolean = false,
        public IsActive: boolean = false,
        public InputNameMappings: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings_Values[] = [],
        public PreviousMonthEndDate: string = null,
        public PreviousTradeDate: string = null,
        public HasWorkingCapital: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_Plans implements IHierarchyNodePostData_Plans {
    constructor(
        public $type: string = null,
        public DividendPartner: IHierarchyNodePostData_Plans_DividendPartner = null,
        public Region: IHierarchyNodePostData_Plans_Region = null,
        public PlanValues: IHierarchyNodePostData_Plans_PlanValues[] = [],
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_Plans_DividendPartner implements IHierarchyNodePostData_Plans_DividendPartner {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public BusinessSegment: IHierarchyNodePostData_Plans_DividendPartner_BusinessSegment = null,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment implements IHierarchyNodePostData_Plans_DividendPartner_BusinessSegment {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_Plans_Region implements IHierarchyNodePostData_Plans_Region {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsHierarchyNodePostData_Plans_PlanValues implements IHierarchyNodePostData_Plans_PlanValues {
    constructor(
        public $type: string = null,
        public Year: number = 0,
        public Month: number = 0,
        public Value: number = 0,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

/* Post node data ends here */

class UserRolesValues implements IUserRolesValues {
    constructor(public $values: IUserRolesValue[] = null) { }
}