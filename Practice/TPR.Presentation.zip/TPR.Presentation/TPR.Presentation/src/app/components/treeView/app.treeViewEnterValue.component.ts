import { Component, OnInit, PipeTransform, Pipe, Input } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';

import { Footer } from 'primeng/primeng';
import { TreeModule } from 'primeng/primeng';
import { TreeNode } from 'primeng/primeng';
import { MenuModule, MenuItem } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { AppTprHierarchyComponent } from '../treeView/app.treeView.component';

import { DashboardDataService } from '../../service/app.dashboardData.service';
import { TPRHierarchyservice } from '../../service/app.TPRHierarchyservice';
import { TPRNodeTypeService } from '../../service/app.TPRNodeTypeService';
import { RegionsService } from '../../service/app.regionService';
import { TPRProfitAlertGroupsService } from '../../service/app.TPRProfitAlertGroupsService';
import { TPRTagsService } from '../../service/app.TPRTagsService';
import { TPRDividendPartnersService } from '../../service/app.TPRDividendPartnersService';
import { TPRBusinessSegmentsService } from '../../service/app.TPRBusinessSegmentsService';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';

// import {moment-business} from 'moment-business';

import IHierarchyEditNode = HierarchyNamespace.IHierarchyEditNode;
import IHierarchyEditNode_Node = HierarchyNamespace.IHierarchyEditNode_Node;
import IHierarchyEditNode_Node_NodeType = HierarchyNamespace.IHierarchyEditNode_Node_NodeType;
import IHierarchyEditNode_Node_InputData = HierarchyNamespace.IHierarchyEditNode_Node_InputData;
import IHierarchyEditNode_Node_InputData_Values = HierarchyNamespace.IHierarchyEditNode_Node_InputData_Values;
import IHierarchyNodePostData_Node = HierarchyNamespace.IHierarchyNodePostData_Node;
import IHierarchyNodeEnterValuePostData = HierarchyNamespace.IHierarchyNodeEnterValuePostData;
import IHierarchyNodeEnterValuePostData_UpdateData = HierarchyNamespace.IHierarchyNodeEnterValuePostData_UpdateData;
import IDividendPartnerValue = DividendPartnerNameSpace.IDividendPartnerValue;
import IHierarchyEnterValue_DividendTrueUp = HierarchyNamespace.IHierarchyEnterValue_DividendTrueUp;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values;
import IHierarchyEditNode_DividendPartnerAllocations_Values = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values;
import IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode = HierarchyNamespace.IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode;

import IHierarchyEnterValue_DividendPPA = HierarchyNamespace.IHierarchyEnterValue_DividendPPA;
import IHolidayValue = HolidayNamespace.IHolidayValue;

import IUserRolesValue = CommonNameSpace.IUserRolesValue;
import IUserRolesValues = CommonNameSpace.IUserRolesValues;
import IUsersValue = CommonNameSpace.IUsersValue;

@Component({
    selector: 'my-app',
    templateUrl: 'app.treeViewEnterValue.component.html'
})
export class AppTprHierarchyEnterValueComponent implements OnInit {
    intSelectedNodeID: number;
    blnShowModalPouUp: boolean = true;
    businessDate: string = '';
    enterValueMenuItems: MenuItem[];
    enterValueCompleteData: IHierarchyEditNode;
    blnEnterValueYTDShow: boolean = true;
    blnEnterValueDividendTrueUpShow: boolean = false;
    blnEnterValueMVARShow: boolean = false;
    blnEnterValueMVARLimitShow: boolean = false;
    blnEnterValueMVARTemporaryLimitShow: boolean = false;
    blnEnterValuePnlPPAShow: boolean = false;
    blnEnterValueDividendPartnerPPAShow: boolean = false;
    blnIsPnlHolder: boolean = false;
    updateTiming: number;
    dtTradingDate: Date;
    minDate: Date;
    ytdValues: IHierarchyEditNode_Node_InputData_Values[] = [];
    selectedYTDValue: IHierarchyEditNode_Node_InputData_Values;
    objYTDValue: clsHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    displayDialogForYTD: boolean = false;
    arrYTDUpdateData: clsUpdateData[] = [];
    objEnterValuePostData: clsHierarchyNodeEnterValuePostData = new clsHierarchyNodeEnterValuePostData();
    blnDisableSaveValue: boolean = true;

    dtTradingDateDividendPartnerTrueUp: Date;
    dividendTrueUp: IHierarchyEnterValue_DividendTrueUp[] = [];
    selectedDividendPartnerTrueUp: IHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
    lstDividendPartnerTrueUp: SelectItem[] = [];
    strSelectedDividendPartnerTrueUpName: string = "";
    strSelectedDividendPartnerPercentage: string = "0";
    dividendPartnerReportedYTDValue: number;
    blnEnableDividendTrueUp: boolean = false;
    blnHasDividendAllocations: boolean = false;
    objDividendPartnerTrueUpValue: IHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
    displayDialogForDividendTrueUp: boolean = false;
    dividendPartnerTypes: IDividendPartnerValue[];

    arrMVarDataValues: IHierarchyEditNode_Node_InputData_Values[] = [];
    selectedMVarValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    objMVarValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    dtMVarTradingDate: Date;
    MVarValue: number;
    MVarUpdateTiming: number;
    blnHasMVarUpdateTiming: boolean = false;
    MVarMinDate: Date;
    displayDialogForMVar: boolean = false;

    arrMVarLimitDataValues: IHierarchyEditNode_Node_InputData_Values[] = [];
    selectedMVarLimitValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    objMVarLimitValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    dtMVarLimitTradingDate: Date;
    MVarLimitValue: number;
    MVarLimitUpdateTiming: number;
    blnHasMVarLimitUpdateTiming: boolean = false;
    MVarLimitMinDate: Date;
    displayDialogForMVarLimit: boolean = false;

    arrMVarTempLimitDataValues: IHierarchyEditNode_Node_InputData_Values[] = [];
    selectedMVarTempLimitValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    objMVarTempLimitValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    dtMVarTempLimitTradingDate: Date;
    dtMVarTempLimitExpiryDate: Date;
    MVarTempLimitValue: number;
    MVarTempLimitUpdateTiming: number;
    blnHasMVarTempLimitUpdateTiming: boolean = false;
    MVarTempLimitMinDate: Date;
    displayDialogForMVarTempLimit: boolean = false;
    blnDisableMVarTempLimitExpiryDate: boolean = true;
    minimumSelectableDate: Date;

    arrPnlPPADataValues: IHierarchyEditNode_Node_InputData_Values[] = [];
    selectedPnlPPAValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    objPnlPPAValue: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
    dtPnlPPATradingDate: Date;
    PnlPPARestatedMEYTDValue: number;
    strPnlPPAMonthEndDate: string = "";
    strPnlPPAReportedMonthEndYTD: string = "";
    PnlPPAMinDate: Date;
    displayDialogForPnlPPA: boolean = false;
    strProjectedPPA: string = "";

    dtTradingDateDividendPartnerPPA: Date;
    DividendPPAMinDate: Date;
    dividendPPA: IHierarchyEnterValue_DividendPPA[] = [];
    selectedDividendPartnerPPA: IHierarchyEnterValue_DividendPPA = new clsHierarchyEnterValue_DividendPPA();
    lstDividendPartnerPPA: SelectItem[] = [];
    strDividendPPAMonthEndDate: string = "";
    strSelectedDividendPartnerPPAName: string = "";
    strSelectedDividendPartnerPPAPercentage: string = "0";
    strDividendPPAReportedMonthEnd: string = "0";
    DividendPPARestatedMEValue: number;
    blnEnableDividendPPA: boolean = false;
    objDividendPartnerPPAValue: IHierarchyEnterValue_DividendPPA = new clsHierarchyEnterValue_DividendPPA();
    displayDialogForDividendPPA: boolean = false;
    strProjectedDividendPPA: string = "";

    blnShowConfirmation: boolean = false;
    blnShowPopUp: boolean = false;
    ValidationStatus: string = "";
    ValidationMessage: string = "";

    isRequesting: boolean;
    blnIsLoadComplete: boolean = false;

    publishstatus: string;
    blnBusinessDateLocked: boolean = false;
    lockstatus: number;

    strDisableDateForDeletionAndModification: string = "";

    holidays: IHolidayValue[] = [];

    availableRoles: IUserRolesValues = new UserRolesValues();
    userRoles: string[] = [];

    canEditNode: boolean = false;
    canEnterValue: boolean = false;
    canEditHierarchy: boolean = false;
    canAddDividendTrueUp: boolean = false;
    canAddMvarValue: boolean = false;
    canAddMvarLimitValue: boolean = false;
    canAddMvarTempLimitValue: boolean = false;
    canAddPPA: boolean = false;
    canAddDividendPPA: boolean = false;
    constants: any;

    blnCanCalculateDivPPA: boolean = false;
    TrueUpDate: Date;

    strPreviousMonthEndDate: string = "";

    constructor(
        private tPRHierarchyservice: TPRHierarchyservice,
        private router: Router,
        private route: ActivatedRoute,
        private tPRNodeTypeService: TPRNodeTypeService,
        private confirmationService: ConfirmationService,
        private regionsService: RegionsService,
        private tprPAGService: TPRProfitAlertGroupsService,
        private tPRTagsService: TPRTagsService,
        private tprDividendPartnersService: TPRDividendPartnersService,
        private tprBusinessSegmentsService: TPRBusinessSegmentsService,
        private tprCommonService: TPRCommonService,
        private appTprHierarchyComponent: AppTprHierarchyComponent,
        private dashboardDataService: DashboardDataService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        this.isRequesting = true;
        // To get the selected node ID from the route service
        this.route.params.subscribe((params: Params) => {
            this.intSelectedNodeID = +params['nodeId'];
        });

        this.enterValueMenuItems = [
            { label: 'YTD', icon: 'fa fa-table', command: (event) => this.EnterValueYTD(), disabled: true },
            { label: 'Dividend True-Up', icon: 'fa fa-table', command: (event) => this.EnterValueDividendTrueUp(), disabled: true },
            { label: 'MVAR', icon: 'fa fa-table', command: (event) => this.EnterValueMVAR(), disabled: true },
            { label: 'MVAR Limit', icon: 'fa fa-table', command: (event) => this.EnterValueMVARLimit(), disabled: true },
            { label: 'MVAR Temporary Limit', icon: 'fa fa-table', command: (event) => this.EnterValueMVARTemporaryLimit(), disabled: true },
            { label: 'Pnl PPA', icon: 'fa fa-table', command: (event) => this.EnterValuePnlPPA(), disabled: true },
            { label: 'Dividend Partner PPA', icon: 'fa fa-table', command: (event) => this.EnterValueDividendPartnerPPA(), disabled: true },
        ];

        this.businessDate = localStorage.getItem("BusinessDate");

        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
        }
        else {
            this.tprCommonService.getUserRolesObservable()
                .subscribe(data => this.setUserRolesData(data));
        }

        this.serviceHelper.importSettings()
            .subscribe(data => this.getConstants(data));

        if (!localStorage.getItem("PublishStatus")) {
            this.dashboardDataService.getPublishStatusObservable().subscribe(data => this.setPublishStatus(data));
        }
        else {
            this.publishstatus = localStorage.getItem("PublishStatus");
            this.getPreviousMonthEndDate();
        }

        // call the service to fetch the node related data
        this.tPRHierarchyservice.getNodeLevelDataForEdit(this.intSelectedNodeID, this.businessDate)
            .subscribe(data => {
                this.enterValueCompleteData = data.Result;

                this.setEnterValueMenuItems();

                this.dashboardDataService.getLockedStatusObservable().subscribe(data => this.setLockedStatus(data));

                this.appTprHierarchyComponent.selectedUpdateTiming = null;
                this.updateTiming = this.appTprHierarchyComponent.getUpdateTimingFromHierarchyForNode(this.enterValueCompleteData.Id);

                let newDate = new Date(this.businessDate);
                this.minDate = newDate;

                this.minDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.minDate, true);

                if (this.updateTiming == -2) {
                    this.minDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.minDate, true);
                }

                //If not published, find the trade date. Otherwise, business date will be the next trade date
                if (this.publishstatus === "Published" || this.lockstatus === 1) {
                    this.strDisableDateForDeletionAndModification = this.setDate(new Date(this.minDate).toString());
                    this.minDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.minDate, false);
                }
                else {
                    localStorage.setItem("strDisableDateForDeletionAndModification", "");
                }

                this.dtTradingDate = this.minDate;
                this.dtTradingDateDividendPartnerTrueUp = this.minDate;

                this.ytdValues = this.enterValueCompleteData ? this.enterValueCompleteData.Node.InputData.$values.filter(ytdValues => ytdValues.InputDataType == "YTD") : [];

                this.ytdValues.forEach(ytdValue => {
                    ytdValue.Updated = ytdValue.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(ytdValue.Updated)) : null;
                    ytdValue.BusinessDate = this.setDate(ytdValue.BusinessDate);
                    ytdValue.IsLocked = !this.isUserAuthorised("EditYTD") || new Date(ytdValue.BusinessDate) < this.dtTradingDate;
                });

                this.sortYTDValues();

                // get the Dividend true up data and assign the values
                if (this.enterValueCompleteData) {
                    this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(dividendAllocation => {
                        dividendAllocation.DividendPartnerNode.InputData.$values.forEach(dividendNodeInput => {

                            if (dividendNodeInput.InputDataTypeEnum == 3) {
                                let objHierarchyEnterValue_DividendTrueUp: IHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
                                objHierarchyEnterValue_DividendTrueUp.BusinessDate = this.setDate(dividendNodeInput.BusinessDate);
                                objHierarchyEnterValue_DividendTrueUp.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                                objHierarchyEnterValue_DividendTrueUp.InputDataType = "YTD True Up";
                                objHierarchyEnterValue_DividendTrueUp.TrueUp = null;
                                objHierarchyEnterValue_DividendTrueUp.Updated = dividendNodeInput.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(dividendNodeInput.Updated)) : null;
                                objHierarchyEnterValue_DividendTrueUp.UpdatedBy = dividendNodeInput.UpdatedBy;
                                objHierarchyEnterValue_DividendTrueUp.Value = dividendNodeInput.Value;
                                objHierarchyEnterValue_DividendTrueUp.IsLocked = !this.isUserAuthorised("EditDividendTrueUp") || new Date(objHierarchyEnterValue_DividendTrueUp.BusinessDate) < this.dtTradingDateDividendPartnerTrueUp;

                                this.dividendTrueUp.push(objHierarchyEnterValue_DividendTrueUp);
                            }
                            else if (dividendNodeInput.InputDataTypeEnum == 10) {
                                let objHierarchyEnterValue_DividendTrueUp: IHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
                                objHierarchyEnterValue_DividendTrueUp.BusinessDate = this.setDate(dividendNodeInput.BusinessDate);
                                objHierarchyEnterValue_DividendTrueUp.DateValue = this.setDate(dividendNodeInput.DateValue);
                                objHierarchyEnterValue_DividendTrueUp.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                                objHierarchyEnterValue_DividendTrueUp.InputDataType = "PPA True Up";
                                objHierarchyEnterValue_DividendTrueUp.TrueUp = dividendNodeInput.Value;
                                objHierarchyEnterValue_DividendTrueUp.Updated = dividendNodeInput.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(dividendNodeInput.Updated)) : null;
                                objHierarchyEnterValue_DividendTrueUp.UpdatedBy = dividendNodeInput.UpdatedBy;
                                objHierarchyEnterValue_DividendTrueUp.Value = null;
                                objHierarchyEnterValue_DividendTrueUp.IsLocked = !this.isUserAuthorised("EditDividendPPA") || new Date(objHierarchyEnterValue_DividendTrueUp.BusinessDate) < this.dtTradingDateDividendPartnerTrueUp;

                                this.dividendTrueUp.push(objHierarchyEnterValue_DividendTrueUp);
                            }
                        });
                    });
                    this.blnHasDividendAllocations = this.enterValueCompleteData.DividendPartnerAllocations.$values.length > 0 ? true : false;
                    this.sortDividendTrueUpValues();
                }

                // get the MVar data and assign the values
                this.arrMVarDataValues = this.enterValueCompleteData ? this.enterValueCompleteData.Node.InputData.$values
                    .filter(ytdValues => ytdValues.InputDataType == "MVar") : [];

                this.arrMVarDataValues.forEach(mvar => {
                    mvar.Updated = mvar.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(mvar.Updated)) : null;
                    mvar.BusinessDate = this.setDate(mvar.BusinessDate);
                });

                // get the MVarLimit data and assign the values
                this.arrMVarLimitDataValues = this.enterValueCompleteData ? this.enterValueCompleteData.Node.InputData.$values
                    .filter(ytdValues => ytdValues.InputDataType == "MVarLimit") : [];

                this.arrMVarLimitDataValues.forEach(mvarLimit => {
                    mvarLimit.Updated = mvarLimit.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(mvarLimit.Updated)) : null;
                    mvarLimit.BusinessDate = this.setDate(mvarLimit.BusinessDate);
                });

                // get the MVarTempLimit data and assign the values
                this.arrMVarTempLimitDataValues = this.enterValueCompleteData ? this.enterValueCompleteData.Node.InputData.$values
                    .filter(ytdValues => ytdValues.InputDataType == "MVarTemporaryLimit") : [];

                this.arrMVarTempLimitDataValues.forEach(mvarTempLimit => {
                    mvarTempLimit.Updated = mvarTempLimit.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(mvarTempLimit.Updated)) : null;
                    mvarTempLimit.BusinessDate = this.setDate(mvarTempLimit.BusinessDate);
                    mvarTempLimit.DateValue = this.setDate(mvarTempLimit.DateValue);
                });

                // get the PnlPPA data and assign the values
                this.arrPnlPPADataValues = this.enterValueCompleteData ? this.enterValueCompleteData.Node.InputData.$values
                    .filter(ytdValues => ytdValues.InputDataType == "Prior Period Adjustment") : [];

                //debugger;
                this.arrPnlPPADataValues.forEach(pnlPPA => {
                    pnlPPA.Updated = pnlPPA.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(pnlPPA.Updated)) : null;
                    pnlPPA.BusinessDate = this.setDate(pnlPPA.BusinessDate);
                    pnlPPA.DateValue = this.setDate(pnlPPA.DateValue);

                    let obj = this.enterValueCompleteData.Node.OutputData.$values.find(x => x.Type == "PPA"
                        && this.setDate(x.BusinessDate) == this.setDate(pnlPPA.BusinessDate)
                        && x.MeasureCalculationType == 2);

                    if (obj) {
                        //debugger;
                        pnlPPA.CalculatedPPA = obj.Value != null ? +(obj.Value.toFixed(2)) : null;
                    }
                    else {
                        pnlPPA.CalculatedPPA = null;
                    }
                });

                // get the Dividend PPA data and assign the values
                if (this.enterValueCompleteData) {
                    this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(dividendAllocation => {
                        dividendAllocation.DividendPartnerNode.InputData.$values.forEach(dividendNodeInput => {

                            if (dividendNodeInput.InputDataTypeEnum == 9) {
                                let objHierarchyEnterValue_DividendPPA: IHierarchyEnterValue_DividendPPA = new clsHierarchyEnterValue_DividendPPA();
                                objHierarchyEnterValue_DividendPPA.BusinessDate = this.setDate(dividendNodeInput.BusinessDate);
                                objHierarchyEnterValue_DividendPPA.RestatedMEDate = this.setDate(dividendNodeInput.DateValue);
                                objHierarchyEnterValue_DividendPPA.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                                objHierarchyEnterValue_DividendPPA.RestatedMEYTD = dividendNodeInput.Value;

                                //debugger;
                                let obj = dividendAllocation.DividendPartnerNode.OutputData.$values.find(x => x.Type == "True Up YTD"
                                    && this.setDate(x.BusinessDate) == this.setDate(dividendNodeInput.BusinessDate)
                                    && x.MeasureCalculationType == 2);

                                if (obj) {
                                    //debugger;
                                    objHierarchyEnterValue_DividendPPA.CalculatedPPA =
                                        obj.Value != null ? +(obj.Value.toFixed(2)) : null;
                                }
                                else {
                                    objHierarchyEnterValue_DividendPPA.CalculatedPPA = null;
                                }

                                objHierarchyEnterValue_DividendPPA.Updated = dividendNodeInput.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(dividendNodeInput.Updated)) : null;
                                objHierarchyEnterValue_DividendPPA.UpdatedBy = dividendNodeInput.UpdatedBy;

                                this.dividendPPA.push(objHierarchyEnterValue_DividendPPA);
                            }
                        });
                    });
                    this.sortDividendPPAValues();
                }

                this.blnIsLoadComplete = true;
                this.stopRefreshing();
            });
    }

    public setPublishStatus(data: any): void {
        let status = data.Result.NumericValue;

        if (status == 0) {
            this.publishstatus = "Unpublished";
        } else {
            this.publishstatus = "Published";
        }
        localStorage.setItem("PublishStatus", this.publishstatus);

        if (this.publishstatus == "Published") {
            this.getPreviousMonthEndDate();
        }
    }

    public getPreviousMonthEndDate() {
        this.tPRHierarchyservice.getHierarchyEndOfPreviousMonth(this.setDate(this.businessDate)).subscribe(data => {
            this.strPreviousMonthEndDate = data.Result ? this.setDate(data.Result) : "";
        });
    }

    private setEnterValueMenuItems() {
        this.enterValueMenuItems.forEach(menuItem => menuItem.disabled = false);

        if (this.enterValueCompleteData && !this.enterValueCompleteData.Node.IsPnlHolder) {
            this.blnIsPnlHolder = false;

            this.enterValueMenuItems.forEach(menuItem => {
                if (menuItem.label == "YTD") {
                    menuItem.disabled = true;
                }
                if (menuItem.label == "Dividend True-Up") {
                    menuItem.disabled = true;
                }
                if (menuItem.label == "Pnl PPA") {
                    menuItem.disabled = true;
                }
                if (menuItem.label == "Dividend Partner PPA") {
                    menuItem.disabled = true;
                }
            });
        }
        else {
            this.blnIsPnlHolder = true;
        }
    }

    private getTrueUpDateEntryMin(): Date {
        if (!this.updateTiming)
            return this.TrueUpDate;

        let baseDay = new Date(this.TrueUpDate);
        let dayMinusOne = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(new Date(baseDay), false);
        let dayMinusTwo = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(new Date(dayMinusOne), false);

        if (this.publishstatus != "Published" && this.lockstatus === 0) {
            //Unpublished & Unlocked
            if (this.updateTiming == -1)
                return dayMinusOne;

            if (this.updateTiming == -2)
                return dayMinusTwo;
        }
        else if (this.publishstatus != "Published" && this.lockstatus === 1) {
            //Unpublished & Locked
            if (this.updateTiming == -1)
                return baseDay;

            if (this.updateTiming == -2)
                return dayMinusOne;
        }
        else if (this.publishstatus === "Published" && this.lockstatus === 0) {
            //Published & Unlocked
            if (this.updateTiming == -1)
                return baseDay;

            if (this.updateTiming == -2)
                return dayMinusOne;
        }
        else {
            //Published & Locked
            if (this.updateTiming == -1)
                return baseDay;

            if (this.updateTiming == -2)
                return dayMinusOne;
        }
    }

    private ResetAllTemplate() {
        this.blnEnterValueYTDShow = false;
        this.blnEnterValueDividendTrueUpShow = false;
        this.blnEnterValueMVARShow = false;
        this.blnEnterValueMVARLimitShow = false;
        this.blnEnterValueMVARTemporaryLimitShow = false;
        this.blnEnterValuePnlPPAShow = false;
        this.blnEnterValueDividendPartnerPPAShow = false;
    }

    EnterValueYTD() {
        this.ResetAllTemplate();
        this.blnEnterValueYTDShow = true;

        this.sortYTDValues()
    }

    EnterValueDividendTrueUp() {
        this.ResetAllTemplate();
        this.blnEnterValueDividendTrueUpShow = true;

        this.blnEnableDividendTrueUp = true;
        this.canAddDividendTrueUp = this.isUserAuthorised("EditDividendTrueUp");

        this.lstDividendPartnerTrueUp = [];
        this.lstDividendPartnerTrueUp.push({ label: "Not Set", value: "NotSet" });

        this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(dividendPartnerAllocation => {
            this.lstDividendPartnerTrueUp.push({ label: dividendPartnerAllocation.DividendPartnerNode.Name, value: dividendPartnerAllocation.DividendPartnerNode.Name });
        });

        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(data => this.setDividendPartnerData(data));

        this.sortDividendTrueUpValues();
    }

    EnterValueMVAR() {
        this.ResetAllTemplate();
        this.blnEnterValueMVARShow = true;

        this.MVarUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;

        this.blnHasMVarUpdateTiming = this.MVarUpdateTiming ? true : false;

        if (this.MVarUpdateTiming) {
            let newDate = new Date(this.businessDate);

            this.MVarMinDate = newDate;
            this.MVarMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarMinDate, true);

            if (this.MVarUpdateTiming == -2) {
                this.MVarMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarMinDate, true);
            }

            //If not published, find the trade date. Otherwise, business date will be the next trade date
            if (this.publishstatus === "Published" || this.lockstatus === 1) {
                this.MVarMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarMinDate, false);
            }
            this.dtMVarTradingDate = this.MVarMinDate;

            this.arrMVarDataValues.forEach(mvar => {
                mvar.IsLocked = !this.isUserAuthorised("EditMVar") || new Date(mvar.BusinessDate) < this.dtMVarTradingDate;
            });

            this.canAddMvarValue = this.isUserAuthorised("EditMVar");
        }

        this.sortMVarValues();
    }

    EnterValueMVARLimit() {
        this.ResetAllTemplate();
        this.blnEnterValueMVARLimitShow = true;

        this.MVarLimitUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;

        this.blnHasMVarLimitUpdateTiming = this.MVarLimitUpdateTiming ? true : false;

        if (this.MVarLimitUpdateTiming) {
            let newDate = new Date(this.businessDate);

            this.MVarLimitMinDate = newDate;
            this.MVarLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarLimitMinDate, true);
            if (this.MVarLimitUpdateTiming == -2) {
                this.MVarLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarLimitMinDate, true);
            }

            //If not published, find the trade date. Otherwise, business date will be the next trade date
            if (this.publishstatus === "Published" || this.lockstatus === 1) {
                this.MVarLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarLimitMinDate, false);
            }

            this.dtMVarLimitTradingDate = this.MVarLimitMinDate;

            this.arrMVarLimitDataValues.forEach(mvarLimit => {
                mvarLimit.IsLocked = !this.isUserAuthorised("EditMVarLimit") || new Date(mvarLimit.BusinessDate) < this.dtMVarLimitTradingDate;
            });

            this.canAddMvarLimitValue = this.isUserAuthorised("EditMVarLimit");
        }

        this.sortMVarLimitValues();
    }

    EnterValueMVARTemporaryLimit() {
        this.ResetAllTemplate();
        this.blnEnterValueMVARTemporaryLimitShow = true;

        this.MVarTempLimitUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;

        this.blnHasMVarTempLimitUpdateTiming = this.MVarTempLimitUpdateTiming ? true : false;

        if (this.MVarTempLimitUpdateTiming) {
            let newDate = new Date(this.businessDate);

            this.MVarTempLimitMinDate = newDate;
            this.MVarTempLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarTempLimitMinDate, true);
            if (this.MVarTempLimitUpdateTiming == -2) {
                this.MVarTempLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarTempLimitMinDate, true);
            }

            //If not published, find the trade date. Otherwise, business date will be the next trade date
            if (this.publishstatus === "Published" || this.lockstatus === 1) {
                this.MVarTempLimitMinDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.MVarTempLimitMinDate, false);
            }

            this.dtMVarTempLimitTradingDate = this.MVarTempLimitMinDate;
            this.setMVarTempLimitExpiryDate();
            this.blnDisableMVarTempLimitExpiryDate = true;

            this.arrMVarTempLimitDataValues.forEach(mvarLimit => {
                mvarLimit.IsLocked = !this.isUserAuthorised("EditMVarTempLimit") || new Date(mvarLimit.BusinessDate) < this.dtMVarTempLimitTradingDate;
            });

            this.canAddMvarTempLimitValue = this.isUserAuthorised("EditMVarTempLimit");
        }

        this.sortMVarTempLimitValues();
    }

    EnterValuePnlPPA() {
        this.ResetAllTemplate();
        this.blnEnterValuePnlPPAShow = true;

        this.PnlPPAMinDate = this.minDate;
        this.dtPnlPPATradingDate = this.PnlPPAMinDate;
        this.strPnlPPAMonthEndDate = this.publishstatus == "Unpublished" && this.enterValueCompleteData ? this.setDate(this.enterValueCompleteData.Node.PreviousMonthEndDate) : this.strPreviousMonthEndDate;
        this.strPnlPPAReportedMonthEndYTD = this.enterValueCompleteData ? this.enterValueCompleteData.Node.ReportedMEYTD : "";

        this.arrPnlPPADataValues.forEach(pnlPPA => {
            pnlPPA.IsLocked = !this.isUserAuthorised("EditPPA") || new Date(pnlPPA.BusinessDate) < this.PnlPPAMinDate;
        });

        this.canAddPPA = this.isUserAuthorised("EditPPA");

        this.sortPnlPPAValues();
    }

    EnterValueDividendPartnerPPA() {
        this.ResetAllTemplate();
        this.blnEnterValueDividendPartnerPPAShow = true;

        this.blnEnableDividendPPA = true;

        this.DividendPPAMinDate = this.minDate;
        this.dtTradingDateDividendPartnerPPA = this.DividendPPAMinDate;
        this.strDividendPPAMonthEndDate = this.publishstatus == "Unpublished" && this.enterValueCompleteData ? this.setDate(this.enterValueCompleteData.Node.PreviousMonthEndDate) : this.strPreviousMonthEndDate;

        this.lstDividendPartnerPPA = [];
        this.lstDividendPartnerPPA.push({ label: "Not Set", value: "NotSet" });

        this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(dividendPartnerAllocation => {
            this.lstDividendPartnerPPA.push({ label: dividendPartnerAllocation.DividendPartnerNode.Name, value: dividendPartnerAllocation.DividendPartnerNode.Name });
        });

        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(data => this.setDividendPartnerData(data));

        this.dividendPPA.forEach(divPPA => {
            divPPA.IsLocked = !this.isUserAuthorised("EditDividendPPA") || new Date(divPPA.BusinessDate) < this.DividendPPAMinDate;
        });

        this.canAddDividendPPA = false;

        this.blnCanCalculateDivPPA = (this.dtTradingDateDividendPartnerPPA &&
            (
                (this.publishstatus === "Unpublished" && this.lockstatus === 0)
                ||
                ((this.publishstatus === "Published" || this.lockstatus === 1) && this.dtTradingDateDividendPartnerPPA < this.TrueUpDate)
            )
        );

        this.sortDividendPPAValues();
    }

    Cancel() {
        this.blnShowModalPouUp = false;
        this.router.navigate(['/hierarchy']);
    }

    Save() {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Saving changes to node values. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.objEnterValuePostData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.UpdateDataCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                this.objEnterValuePostData.HierarchyType = "Main";
                this.objEnterValuePostData.Node = this.enterValueCompleteData.Node;
                this.objEnterValuePostData.UpdateData = this.arrYTDUpdateData;

                this.isRequesting = true;
                this.tPRHierarchyservice.updateNodeLevelEnterValueForPost(this.objEnterValuePostData)
                    .subscribe((response: any) => {
                        if (response.Error) {
                            this.ValidationStatus = "Error";
                            this.ValidationMessage = response.Error;
                            this.blnShowPopUp = true;
                            this.stopRefreshing();
                        }
                        else {
                            this.stopRefreshing();
                            this.blnShowModalPouUp = false;
                            this.router.navigateByUrl('/hierarchy');
                        }
                    },
                    (error) => {
                        this.ValidationStatus = "Error";
                        this.ValidationMessage = error;
                        this.blnShowPopUp = true;
                        this.stopRefreshing();
                    });
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    onAddYTDValue(txtYTDValue: string) {
        if (txtYTDValue == undefined || txtYTDValue == null || txtYTDValue.length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide YTD value";
            this.blnShowPopUp = true;
        }
        else {

            let selectedYTDDate: string = this.setDate(this.dtTradingDate.toString());

            if (this.ytdValues.findIndex(ytdValue => ytdValue.BusinessDate == selectedYTDDate) != -1) {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                this.blnShowPopUp = true;
            }
            else {
                if (!isNaN(Number(txtYTDValue))) {
                    let ytdSelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
                    ytdSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    ytdSelected.BusinessDate = selectedYTDDate;
                    ytdSelected.InputDataTypeEnum = 1;
                    ytdSelected.InputDataType = "YTD";
                    ytdSelected.Published = false;
                    ytdSelected.Value = Number(txtYTDValue);
                    this.ytdValues.push(ytdSelected);

                    this.selectedYTDValue = ytdSelected;

                    let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 1 && item.BusinessDate == selectedYTDDate);

                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }

                    let ytdUpdateData: clsUpdateData = new clsUpdateData();

                    ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    ytdUpdateData.BusinessDate = ytdSelected.BusinessDate;
                    ytdUpdateData.DateValue = null;
                    ytdUpdateData.InputDataType = 1;
                    ytdUpdateData.DividendPartner = null;
                    ytdUpdateData.Value = ytdSelected.Value;
                    this.arrYTDUpdateData.push(ytdUpdateData);

                    this.blnDisableSaveValue = false;
                    this.sortYTDValues();
                }
                else {
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "Input value is not in a correct format.";
                    this.blnShowPopUp = true;
                }
            }
        }
    }

    private setDate(data: string): string {
        let myDate = new Date(data);
        var output: string = "";

        var m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        var modifiedDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();

        output = myDate.getDate().toString().length > 1 ?
            myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear() :
            "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();

        return output;
    }

    private sortYTDValues() {
        this.ytdValues.sort((n1, n2) => {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }

            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }

            return 0;
        });
    }

    private onRowSelectForYTDValue(event: any) {
        this.objYTDValue = this.cloneYTDValue(event.data);
        this.displayDialogForYTD = true;
    }

    private cloneYTDValue(objForClone: clsHierarchyEditNode_Node_InputData_Values): clsHierarchyEditNode_Node_InputData_Values {
        let ytdValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (let prop in objForClone) {
            ytdValue[prop] = objForClone[prop];
        }
        return ytdValue;
    }

    deleteYTDValues(ytdValueDeleted: IHierarchyEditNode_Node_InputData_Values) {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected YTD amount will be deleted. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.ytdValues.splice(this.ytdValues.indexOf(ytdValueDeleted), 1);
                this.objYTDValue = null;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 1 && item.BusinessDate == ytdValueDeleted.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let ytdUpdateData: clsUpdateData = new clsUpdateData();

                ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ytdUpdateData.BusinessDate = ytdValueDeleted.BusinessDate;
                ytdUpdateData.DateValue = null;
                ytdUpdateData.DividendPartner = null;
                ytdUpdateData.InputDataType = 1;
                ytdUpdateData.Value = null;

                this.arrYTDUpdateData.push(ytdUpdateData);

                this.blnDisableSaveValue = false;
                this.sortYTDValues();
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    saveYTDValue() {
        if (this.objYTDValue.Value == undefined || this.objYTDValue.Value == null || this.objYTDValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide YTD value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objYTDValue.Value)) {
                let ytdValues = [...this.ytdValues];

                ytdValues[this.findSelectedYTDValueIndex()] = this.objYTDValue;

                this.ytdValues = ytdValues;

                this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 1 && item.BusinessDate != this.objYTDValue.BusinessDate);

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 1 && item.BusinessDate == this.objYTDValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                this.selectedYTDValue = this.objYTDValue;

                let ytdUpdateData: clsUpdateData = new clsUpdateData();

                ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ytdUpdateData.BusinessDate = this.objYTDValue.BusinessDate;
                ytdUpdateData.DateValue = null;
                ytdUpdateData.DividendPartner = null;
                ytdUpdateData.InputDataType = 1;
                ytdUpdateData.Value = this.objYTDValue.Value;

                this.arrYTDUpdateData.push(ytdUpdateData);

                this.objYTDValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForYTD = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    private findSelectedYTDValueIndex(): number {
        return this.ytdValues.indexOf(this.selectedYTDValue);
    }

    private sortDividendTrueUpValues() {
        this.dividendTrueUp.sort((n1, n2) => {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }

            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }

            return 0;
        });
    }

    private onDividendPartnerTrueUpChange() {
        let intPercentageValue: number = 0;
        let selectedDividendAllocation: IHierarchyEditNode_DividendPartnerAllocations_Values = new clsHierarchyEditNode_DividendPartnerAllocations_Values()
        let selectedTrueUpTradingDate: string = this.setDate(this.dtTradingDateDividendPartnerTrueUp.toString());

        if (this.dividendTrueUp.findIndex(trueUp => trueUp.BusinessDate == selectedTrueUpTradingDate
            && trueUp.DividendPartnerName == this.strSelectedDividendPartnerTrueUpName && trueUp.InputDataType == "YTD True Up") != -1) {
            this.blnEnableDividendTrueUp = true;
        }
        else {
            if (this.strSelectedDividendPartnerTrueUpName && this.strSelectedDividendPartnerTrueUpName.toString() != "NotSet") {
                selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find(dividendAllocation => dividendAllocation.DividendPartnerNode.Name == this.strSelectedDividendPartnerTrueUpName);
                intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                this.blnEnableDividendTrueUp = false;
            }
            else {
                intPercentageValue = 0;
                this.blnEnableDividendTrueUp = true;
            }
        }
        this.strSelectedDividendPartnerPercentage = intPercentageValue.toString();
    }

    onClickDividendTrueUpAdd() {
        if (this.dividendPartnerReportedYTDValue == undefined || this.dividendPartnerReportedYTDValue == null || this.dividendPartnerReportedYTDValue.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide Dividend TrueUp value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.dividendPartnerReportedYTDValue)) {
                let selectedTrueUpTradingDate: string = this.setDate(this.dtTradingDateDividendPartnerTrueUp.toString());

                let trueUpSelected: IHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
                trueUpSelected.BusinessDate = selectedTrueUpTradingDate;
                trueUpSelected.InputDataType = "YTD True Up";
                trueUpSelected.DividendPartnerName = this.strSelectedDividendPartnerTrueUpName;
                trueUpSelected.Value = this.dividendPartnerReportedYTDValue;
                this.dividendTrueUp.push(trueUpSelected);

                this.selectedDividendPartnerTrueUp = trueUpSelected;

                this.strSelectedDividendPartnerTrueUpName = "NotSet";
                this.dividendPartnerReportedYTDValue = null;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 3 && item.BusinessDate == selectedTrueUpTradingDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let trueUpUpdateData: clsUpdateData = new clsUpdateData();

                trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                trueUpUpdateData.BusinessDate = trueUpSelected.BusinessDate;
                trueUpUpdateData.DateValue = null;
                trueUpUpdateData.InputDataType = 3;
                trueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == trueUpSelected.DividendPartnerName);
                trueUpUpdateData.Value = trueUpSelected.Value;
                this.arrYTDUpdateData.push(trueUpUpdateData);

                this.blnDisableSaveValue = false;
                this.blnEnableDividendTrueUp = true;
                this.sortDividendTrueUpValues();
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    onClickDividendTrueUpClear() {
        this.strSelectedDividendPartnerTrueUpName = "NotSet";
        this.dividendPartnerReportedYTDValue = null;
    }

    private onRowSelectForDividendPartnerTrueUp(event: any) {
        this.objDividendPartnerTrueUpValue = this.cloneDividendTrueUpValue(event.data);

        if (this.objDividendPartnerTrueUpValue.InputDataType == "YTD True Up") {
            this.displayDialogForDividendTrueUp = true;
        }
    }

    private cloneDividendTrueUpValue(objForClone: clsHierarchyEnterValue_DividendTrueUp): clsHierarchyEnterValue_DividendTrueUp {
        let dividendTrueUpValue = new clsHierarchyEnterValue_DividendTrueUp();
        for (let prop in objForClone) {
            dividendTrueUpValue[prop] = objForClone[prop];
        }
        return dividendTrueUpValue;
    }

    deleteDividendPartnerTrueUp(dividendTrueUpRowValue: IHierarchyEnterValue_DividendTrueUp) {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected True Up amount will be deleted. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.dividendTrueUp.splice(this.dividendTrueUp.indexOf(dividendTrueUpRowValue), 1);
                this.objDividendPartnerTrueUpValue = null;

                if (dividendTrueUpRowValue.InputDataType == "YTD True Up") {
                    let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 3
                        && item.BusinessDate == dividendTrueUpRowValue.BusinessDate && item.DividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName);

                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }

                    let trueUpUpdateData: clsUpdateData = new clsUpdateData();

                    trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    trueUpUpdateData.BusinessDate = dividendTrueUpRowValue.BusinessDate;
                    trueUpUpdateData.DateValue = null;
                    trueUpUpdateData.InputDataType = 3;
                    trueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName);
                    trueUpUpdateData.Value = null;

                    this.arrYTDUpdateData.push(trueUpUpdateData);
                }
                else if (dividendTrueUpRowValue.InputDataType == "PPA True Up") {

                    let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 10
                        && item.BusinessDate == dividendTrueUpRowValue.BusinessDate && item.DividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName);

                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }

                    let trueUpUpdateData: clsUpdateData = new clsUpdateData();

                    trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaTrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    trueUpUpdateData.InputDataType = 10;
                    trueUpUpdateData.BusinessDate = dividendTrueUpRowValue.BusinessDate;
                    trueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName);
                    trueUpUpdateData.Value = null;
                    trueUpUpdateData.DateValue = dividendTrueUpRowValue.DateValue;

                    this.arrYTDUpdateData.push(trueUpUpdateData);
                }
                this.blnDisableSaveValue = false;
                this.sortDividendTrueUpValues();
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    saveDividendTrueUpValue() {
        if (this.objDividendPartnerTrueUpValue.Value == undefined || this.objDividendPartnerTrueUpValue.Value == null || this.objDividendPartnerTrueUpValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide Dividend TrueUp value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objDividendPartnerTrueUpValue.Value)) {
                let dividendTrueUpValues = [...this.dividendTrueUp];

                dividendTrueUpValues[this.findSelectedDividendTrueUpValueIndex()] = this.objDividendPartnerTrueUpValue;

                this.dividendTrueUp = dividendTrueUpValues;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 3 && item.BusinessDate == this.objDividendPartnerTrueUpValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                this.selectedDividendPartnerTrueUp = this.objDividendPartnerTrueUpValue;

                let TrueUpUpdateData: clsUpdateData = new clsUpdateData();

                TrueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                TrueUpUpdateData.BusinessDate = this.objDividendPartnerTrueUpValue.BusinessDate;
                TrueUpUpdateData.DateValue = null;
                TrueUpUpdateData.InputDataType = 3;
                TrueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == this.objDividendPartnerTrueUpValue.DividendPartnerName);
                TrueUpUpdateData.Value = this.objDividendPartnerTrueUpValue.Value;

                this.arrYTDUpdateData.push(TrueUpUpdateData);

                this.objDividendPartnerTrueUpValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForDividendTrueUp = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    onSelectDividendTrueUpTradingDate() {
        this.strSelectedDividendPartnerTrueUpName = "NotSet";
        this.blnEnableDividendTrueUp = true;
    }

    findSelectedDividendTrueUpValueIndex() {
        let objDividendTrueUpSelected: IHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();

        objDividendTrueUpSelected = this.dividendTrueUp
            .find(x => x.BusinessDate == this.objDividendPartnerTrueUpValue.BusinessDate
                && x.DividendPartnerName == this.objDividendPartnerTrueUpValue.DividendPartnerName);

        return this.dividendTrueUp.indexOf(objDividendTrueUpSelected);
    }

    private setDividendPartnerData(data: any): void {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
    }

    onAddMVarValue() {
        if (this.MVarValue == undefined || this.MVarValue == null || this.MVarValue.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide MVAR value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.MVarValue)) {
                let selectedMVarDate: string = this.setDate(this.dtMVarTradingDate.toString());

                if (this.arrMVarDataValues.findIndex(MVarValue => MVarValue.BusinessDate == selectedMVarDate) != -1) {
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                    this.blnShowPopUp = true;
                }
                else {
                    let MVarSelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
                    MVarSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    MVarSelected.BusinessDate = selectedMVarDate;
                    MVarSelected.DateValue = null;
                    MVarSelected.InputDataTypeEnum = 4;
                    MVarSelected.InputDataType = "MVar";
                    MVarSelected.Published = false;
                    MVarSelected.Value = Number(this.MVarValue);
                    this.arrMVarDataValues.push(MVarSelected);

                    this.selectedMVarValue = MVarSelected;

                    let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 4 && item.BusinessDate == selectedMVarDate);

                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }

                    let MVarUpdateData: clsUpdateData = new clsUpdateData();

                    MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    MVarUpdateData.BusinessDate = MVarSelected.BusinessDate;
                    MVarUpdateData.InputDataType = 4;
                    MVarUpdateData.DividendPartner = null;
                    MVarUpdateData.Value = this.MVarValue;
                    this.arrYTDUpdateData.push(MVarUpdateData);

                    this.MVarValue = null;
                    this.blnDisableSaveValue = false;
                    this.sortMVarValues();
                }
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    private onRowSelectForMVarValue(event: any) {
        this.objMVarValue = this.cloneMVarValue(event.data);
        this.displayDialogForMVar = true;
    }

    private cloneMVarValue(objForClone: clsHierarchyEditNode_Node_InputData_Values): clsHierarchyEditNode_Node_InputData_Values {
        let MVarValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (let prop in objForClone) {
            MVarValue[prop] = objForClone[prop];
        }
        return MVarValue;
    }

    saveMVarValue() {
        if (this.objMVarValue.Value == undefined || this.objMVarValue.Value == null || this.objMVarValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide MVAR value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objMVarValue.Value)) {
                let MVarValues = [...this.arrMVarDataValues];

                MVarValues[this.findSelectedMVarValueIndex()] = this.objMVarValue;

                this.arrMVarDataValues = MVarValues;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 4 && item.BusinessDate == this.objMVarValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                this.selectedMVarValue = this.objMVarValue;

                let MVarUpdateData: clsUpdateData = new clsUpdateData();

                MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarUpdateData.BusinessDate = this.objMVarValue.BusinessDate;
                MVarUpdateData.DateValue = null;
                MVarUpdateData.InputDataType = 4;
                MVarUpdateData.DividendPartner = null;
                MVarUpdateData.Value = this.objMVarValue.Value;

                this.arrYTDUpdateData.push(MVarUpdateData);

                this.objMVarValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForMVar = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    findSelectedMVarValueIndex() {
        let objMVarSelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();

        objMVarSelected = this.arrMVarDataValues.find(x => x.BusinessDate == this.objMVarValue.BusinessDate);

        return this.arrMVarDataValues.indexOf(objMVarSelected);
    }

    onCustomNumericValidation(event: any) {
        return (String.fromCharCode(event.charCode).match(/[0-9.]/g) != null);
    }

    onCustomNumericValidationForPositiveandNegativeIntegers(event: any) {
        return (String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null);
    }

    onCustomNumericValidationForPositiveandNegativeIntegersForDividendPPA(event: any, value: any) {
        let result: boolean;

        // to handle backspace and delete key press, left right, top, bottom arrow, contrl , backspace, shift, home, end
        if (event.keyCode === 8 || event.keyCode === 46 || event.keyCode === 35 || event.keyCode === 36 || event.keyCode === 37 || event.keyCode === 38 || event.keyCode === 39 || event.keyCode === 40
            || event.keyCode === 16 || event.keyCode === 17 || event.keyCode === 96 || event.keyCode === 97 || event.keyCode === 98 || event.keyCode === 99
            || event.keyCode === 100 || event.keyCode === 101 || event.keyCode === 102 || event.keyCode === 103 || event.keyCode === 104
            || event.keyCode === 105) {
            result = true;
        }
        else {
            result = event.charCode ? (String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null) : (String.fromCharCode(event.keyCode).match(/[0-9.-]/g) != null);
        }

        if (result) {
            if (!value) {
                this.strProjectedDividendPPA = "";
                this.DividendPPARestatedMEValue = null;
            }
            else {
                if (!isNaN(value)) {
                    let newProjectedValue: number = Number(value) - Number(this.strDividendPPAReportedMonthEnd);
                    this.strProjectedDividendPPA = newProjectedValue ? Number(newProjectedValue).toString() : "";
                }
                else {
                    this.DividendPPARestatedMEValue = Number(this.strProjectedDividendPPA);
                }
            }
            return true;
        }
        else {
            return false;
        }
    }

    onCustomNumericValidationForPositiveandNegativeIntegersForPPA(event: any, value: any) {
        let result: boolean;

        // to handle backspace and delete key press, left right, top, bottom arrow, contrl , backspace, shift, home, end, other numpad key
        if (event.keyCode === 8 || event.keyCode === 46 || event.keyCode === 35 || event.keyCode === 36 || event.keyCode === 37 || event.keyCode === 38 || event.keyCode === 39 || event.keyCode === 40
            || event.keyCode === 16 || event.keyCode === 17 || event.keyCode === 96 || event.keyCode === 97 || event.keyCode === 98 || event.keyCode === 99
            || event.keyCode === 100 || event.keyCode === 101 || event.keyCode === 102 || event.keyCode === 103 || event.keyCode === 104
            || event.keyCode === 105) {
            result = true;
        }
        else {
            result = event.charCode ? (String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null) : (String.fromCharCode(event.keyCode).match(/[0-9.-]/g) != null);
        }

        if (result) {
            if (!value) {
                this.strProjectedPPA = "";
                this.PnlPPARestatedMEYTDValue = null;
            }
            else {
                if (!isNaN(value)) {
                    let newProjectedValue: number = Number(value) - Number(this.strPnlPPAReportedMonthEndYTD);
                    this.strProjectedPPA = newProjectedValue ? Number(newProjectedValue).toString() : "";
                }
                else {
                    this.PnlPPARestatedMEYTDValue = Number(this.strProjectedPPA);
                }
            }
            return true;
        }
        else {
            return false;
        }
    }

    onCustomNumericValidationMVarTempLimit(event: any) {
        return (String.fromCharCode(event.charCode).match(/[0-9]/g) != null);
    }

    private sortMVarValues() {
        this.arrMVarDataValues.sort((n1, n2) => {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }

            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }

            return 0;
        });
    }

    deleteMVarValues(MVarValue: IHierarchyEditNode_Node_InputData_Values) {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected MVAR amount will be deleted. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.arrMVarDataValues.splice(this.arrMVarDataValues.indexOf(MVarValue), 1);

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 4 && item.BusinessDate == MVarValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let MVarUpdateData: clsUpdateData = new clsUpdateData();

                MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarUpdateData.BusinessDate = MVarValue.BusinessDate;
                MVarUpdateData.DateValue = null;
                MVarUpdateData.InputDataType = 4;
                MVarUpdateData.DividendPartner = null;
                MVarUpdateData.Value = null;
                this.arrYTDUpdateData.push(MVarUpdateData);

                this.blnDisableSaveValue = false;
                this.sortMVarValues();
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    onAddMVarLimitValue() {
        if (this.MVarLimitValue == undefined || this.MVarLimitValue == null || this.MVarLimitValue.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide MVAR Limit value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.MVarLimitValue)) {
                let selectedMVarLimitDate: string = this.setDate(this.dtMVarLimitTradingDate.toString());

                if (this.arrMVarLimitDataValues.findIndex(MVarLimitValue => MVarLimitValue.BusinessDate == selectedMVarLimitDate) != -1) {
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                    this.blnShowPopUp = true;
                }
                else {
                    let MVarLimitSelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
                    MVarLimitSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    MVarLimitSelected.BusinessDate = selectedMVarLimitDate;
                    MVarLimitSelected.DateValue = null;
                    MVarLimitSelected.InputDataTypeEnum = 5;
                    MVarLimitSelected.InputDataType = "MVarLimit";
                    MVarLimitSelected.Published = false;
                    MVarLimitSelected.Value = Number(this.MVarLimitValue);
                    this.arrMVarLimitDataValues.push(MVarLimitSelected);

                    this.selectedMVarLimitValue = MVarLimitSelected;

                    let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 5 && item.BusinessDate == selectedMVarLimitDate);

                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }

                    let MVarLimitUpdateData: clsUpdateData = new clsUpdateData();

                    MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    MVarLimitUpdateData.BusinessDate = MVarLimitSelected.BusinessDate;
                    MVarLimitUpdateData.DateValue = null;
                    MVarLimitUpdateData.InputDataType = 5;
                    MVarLimitUpdateData.DividendPartner = null;
                    MVarLimitUpdateData.Value = this.MVarLimitValue;
                    this.arrYTDUpdateData.push(MVarLimitUpdateData);

                    this.MVarLimitValue = null;
                    this.blnDisableSaveValue = false;
                    this.sortMVarLimitValues();
                }
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    onRowSelectForMVarLimitValue(event: any) {
        this.objMVarLimitValue = this.cloneMVarLimitValue(event.data);
        this.displayDialogForMVarLimit = true;
    }

    private cloneMVarLimitValue(objForClone: clsHierarchyEditNode_Node_InputData_Values): clsHierarchyEditNode_Node_InputData_Values {
        let MVarLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (let prop in objForClone) {
            MVarLimitValue[prop] = objForClone[prop];
        }
        return MVarLimitValue;
    }

    saveMVarLimitValue() {
        if (this.objMVarLimitValue.Value == undefined || this.objMVarLimitValue.Value == null || this.objMVarLimitValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide MVAR Limit value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objMVarLimitValue.Value)) {
                let MVarLimitValues = [...this.arrMVarLimitDataValues];

                MVarLimitValues[this.findSelectedMVarLimitValueIndex()] = this.objMVarLimitValue;

                this.arrMVarLimitDataValues = MVarLimitValues;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 5 && item.BusinessDate == this.objMVarLimitValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                this.selectedMVarLimitValue = this.objMVarLimitValue;

                let MVarLimitUpdateData: clsUpdateData = new clsUpdateData();

                MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarLimitUpdateData.BusinessDate = this.objMVarLimitValue.BusinessDate;
                MVarLimitUpdateData.DateValue = null;
                MVarLimitUpdateData.InputDataType = 5;
                MVarLimitUpdateData.DividendPartner = null;
                MVarLimitUpdateData.Value = this.objMVarLimitValue.Value;

                this.arrYTDUpdateData.push(MVarLimitUpdateData);

                this.objMVarLimitValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForMVarLimit = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    findSelectedMVarLimitValueIndex() {
        let objMVarLimitSelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();

        objMVarLimitSelected = this.arrMVarLimitDataValues.find(x => x.BusinessDate == this.objMVarLimitValue.BusinessDate);

        return this.arrMVarLimitDataValues.indexOf(objMVarLimitSelected);
    }

    deleteMVarLimitValues(MVarLimitValue: IHierarchyEditNode_Node_InputData_Values) {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected MVAR Limit will be deleted. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.arrMVarLimitDataValues.splice(this.arrMVarLimitDataValues.indexOf(MVarLimitValue), 1);

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 5 && item.BusinessDate == MVarLimitValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let MVarLimitUpdateData: clsUpdateData = new clsUpdateData();

                MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarLimitUpdateData.BusinessDate = MVarLimitValue.BusinessDate;
                MVarLimitUpdateData.DateValue = null;
                MVarLimitUpdateData.InputDataType = 5;
                MVarLimitUpdateData.DividendPartner = null;
                MVarLimitUpdateData.Value = null;
                this.arrYTDUpdateData.push(MVarLimitUpdateData);

                this.blnDisableSaveValue = false;
                this.sortMVarLimitValues();
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    private sortMVarLimitValues() {
        this.arrMVarLimitDataValues.sort((n1, n2) => {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }

            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }

            return 0;
        });
    }

    setMVarTempLimitExpiryDate() {
        let MVarTempLimitTradingDate: Date = this.dtMVarTempLimitTradingDate;

        localStorage.setItem("MVarTempLimitTradingDate", MVarTempLimitTradingDate.toString());

        let selectedTradingDate: string = localStorage.getItem("MVarTempLimitTradingDate");

        let dayNumber = new Date(selectedTradingDate).getDay();

        this.dtMVarTempLimitExpiryDate = new Date(selectedTradingDate);

        let newExpiryDate: Date = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(this.dtMVarTempLimitExpiryDate, false);

        this.dtMVarTempLimitExpiryDate = new Date(newExpiryDate);
    }

    private onSelectMVarTempLimitTradingDate(value: any) {
        this.setMVarTempLimitExpiryDate();
    }

    onMVarTempLimitValueKeyUp(event: any) {
        if (this.MVarTempLimitValue && this.MVarTempLimitValue.toString().length > 0) {
            this.blnDisableMVarTempLimitExpiryDate = false;
        }
        else {
            this.blnDisableMVarTempLimitExpiryDate = true;
        }
    }

    onClickMVarTempLimitAdd() {
        if (this.MVarTempLimitValue == undefined || this.MVarTempLimitValue == null || this.MVarTempLimitValue.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide MVAR Temporary Limit value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.MVarTempLimitValue)) {
                let selectedMVarTempLimitDate: string = this.setDate(this.dtMVarTempLimitTradingDate.toString());
                let selectedMVarTempLimitExpiryDate: string = this.setDate(this.dtMVarTempLimitExpiryDate.toString());

                if (this.arrMVarTempLimitDataValues.findIndex(MVarTempLimitValue => MVarTempLimitValue.BusinessDate == selectedMVarTempLimitDate) != -1) {
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                    this.blnShowPopUp = true;
                }
                else {
                    if (JSON.parse(localStorage.getItem("Holidays"))) {
                        this.holidays = JSON.parse(localStorage.getItem("Holidays"));
                    }

                    if (this.holidays.find(holiday => holiday.Region == null && this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                        this.tprCommonService.getFormattedSystemDate_Date(new Date(selectedMVarTempLimitExpiryDate))
                    )) {
                        let selectedHoliday: IHolidayValue = this.holidays.find(holiday => holiday.Region == null &&
                            this.tprCommonService.getFormattedSystemDate_Date(new Date(holiday.Date)) ==
                            this.tprCommonService.getFormattedSystemDate_Date(new Date(selectedMVarTempLimitExpiryDate)));

                        let holidayName: string = selectedHoliday && selectedHoliday.Name ? selectedHoliday.Name : "";

                        this.ValidationStatus = "Validation error";
                        this.ValidationMessage = "Cannot add a MVar Temp Limit value for global holiday \"" + holidayName + "\"";
                        this.blnShowPopUp = true;
                    }
                    else {
                        let MVarTempLimitSelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
                        MVarTempLimitSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                        MVarTempLimitSelected.BusinessDate = selectedMVarTempLimitDate;
                        MVarTempLimitSelected.DateValue = selectedMVarTempLimitExpiryDate;
                        MVarTempLimitSelected.InputDataTypeEnum = 8;
                        MVarTempLimitSelected.InputDataType = "MVarTemporaryLimit";
                        MVarTempLimitSelected.Published = false;
                        MVarTempLimitSelected.Value = Number(this.MVarTempLimitValue);
                        this.arrMVarTempLimitDataValues.push(MVarTempLimitSelected);

                        this.selectedMVarTempLimitValue = MVarTempLimitSelected;

                        let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 8 && item.BusinessDate == this.objMVarTempLimitValue.BusinessDate);

                        if (arrData) {
                            this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                        }

                        let MVarTempLimitUpdateData: clsUpdateData = new clsUpdateData();

                        MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                        MVarTempLimitUpdateData.BusinessDate = MVarTempLimitSelected.BusinessDate;
                        MVarTempLimitUpdateData.DateValue = MVarTempLimitSelected.DateValue;
                        MVarTempLimitUpdateData.InputDataType = 8;
                        MVarTempLimitUpdateData.DividendPartner = null;
                        MVarTempLimitUpdateData.Value = this.MVarTempLimitValue;
                        this.arrYTDUpdateData.push(MVarTempLimitUpdateData);

                        this.MVarLimitValue = null;
                        this.blnDisableSaveValue = false;
                        this.sortMVarTempLimitValues();
                    }
                }
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    private sortMVarTempLimitValues() {
        this.arrMVarTempLimitDataValues.sort((n1, n2) => {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }

            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }

            return 0;
        });
    }

    onRowSelectForMVarTempLimitValue(event: any) {
        this.objMVarTempLimitValue = this.cloneMVarTempLimitValue(event.data);
        this.displayDialogForMVarTempLimit = true;
        this.minimumSelectableDate = new Date(this.objMVarTempLimitValue.BusinessDate);
    }

    private cloneMVarTempLimitValue(objForClone: clsHierarchyEditNode_Node_InputData_Values): clsHierarchyEditNode_Node_InputData_Values {
        let MVarTempLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (let prop in objForClone) {
            MVarTempLimitValue[prop] = objForClone[prop];
        }
        return MVarTempLimitValue;
    }

    saveMVarTempLimitValue() {
        if (this.objMVarTempLimitValue.Value == undefined || this.objMVarTempLimitValue.Value == null || this.objMVarTempLimitValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide MVAR Temporary Limit value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objMVarTempLimitValue.Value)) {
                let MVarTempLimitValues = [...this.arrMVarTempLimitDataValues];

                MVarTempLimitValues[this.findSelectedMVarTempLimitValueIndex()] = this.objMVarTempLimitValue;

                this.arrMVarTempLimitDataValues = MVarTempLimitValues;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 8 && item.BusinessDate == this.objMVarTempLimitValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                this.selectedMVarTempLimitValue = this.objMVarTempLimitValue;

                let MVarTempLimitUpdateData: clsUpdateData = new clsUpdateData();

                MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarTempLimitUpdateData.BusinessDate = this.objMVarTempLimitValue.BusinessDate;
                MVarTempLimitUpdateData.DateValue = this.objMVarTempLimitValue.DateValue;
                MVarTempLimitUpdateData.InputDataType = 8;
                MVarTempLimitUpdateData.DividendPartner = null;
                MVarTempLimitUpdateData.Value = this.objMVarTempLimitValue.Value;

                this.arrYTDUpdateData.push(MVarTempLimitUpdateData);

                this.objMVarTempLimitValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForMVarTempLimit = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    findSelectedMVarTempLimitValueIndex() {
        let objMVarTempLimitSelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();

        objMVarTempLimitSelected = this.arrMVarTempLimitDataValues.find(x => x.BusinessDate == this.objMVarTempLimitValue.BusinessDate);

        return this.arrMVarTempLimitDataValues.indexOf(objMVarTempLimitSelected);
    }

    deleteMVarTempLimitValues(MVarTempLimitValue: IHierarchyEditNode_Node_InputData_Values) {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected MVAR Temporary Limit will be deleted. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.arrMVarTempLimitDataValues.splice(this.arrMVarTempLimitDataValues.indexOf(MVarTempLimitValue), 1);

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 8 && item.BusinessDate == MVarTempLimitValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let MVarTempLimitUpdateData: clsUpdateData = new clsUpdateData();

                MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarTempLimitUpdateData.BusinessDate = MVarTempLimitValue.BusinessDate;
                MVarTempLimitUpdateData.DateValue = MVarTempLimitValue.DateValue;
                MVarTempLimitUpdateData.InputDataType = 8;
                MVarTempLimitUpdateData.DividendPartner = null;
                MVarTempLimitUpdateData.Value = null;
                this.arrYTDUpdateData.push(MVarTempLimitUpdateData);

                this.blnDisableSaveValue = false;
                this.sortMVarTempLimitValues();
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    onClickPnlPPAAdd() {
        if (this.PnlPPARestatedMEYTDValue == undefined || this.PnlPPARestatedMEYTDValue == null || this.PnlPPARestatedMEYTDValue.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide PnL PPA value";
            this.blnShowPopUp = true;
        }
        else {
            let selectedPnlPPADate: string = this.setDate(this.dtPnlPPATradingDate.toString());
            let selectedPnlPPAMonthEndDate: string = this.strPnlPPAMonthEndDate ? this.setDate(this.strPnlPPAMonthEndDate) : "";

            if (this.arrPnlPPADataValues.findIndex(pnlPPAValue => pnlPPAValue.BusinessDate == selectedPnlPPADate) != -1) {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.";
                this.blnShowPopUp = true;
            }
            else {
                if (!isNaN(this.PnlPPARestatedMEYTDValue)) {
                    let PnlPPASelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();
                    PnlPPASelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                    PnlPPASelected.BusinessDate = selectedPnlPPADate;
                    PnlPPASelected.DateValue = selectedPnlPPAMonthEndDate;
                    PnlPPASelected.InputDataTypeEnum = 9;
                    PnlPPASelected.InputDataType = "Prior Period Adjustment";
                    PnlPPASelected.Published = false;
                    PnlPPASelected.Value = Number(this.PnlPPARestatedMEYTDValue);
                    this.arrPnlPPADataValues.push(PnlPPASelected);

                    this.selectedPnlPPAValue = PnlPPASelected;

                    let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 9 && item.BusinessDate == selectedPnlPPADate);

                    if (arrData) {
                        this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                    }

                    let PnlPPAUpdateData: clsUpdateData = new clsUpdateData();

                    PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    PnlPPAUpdateData.BusinessDate = PnlPPASelected.BusinessDate;
                    PnlPPAUpdateData.DateValue = PnlPPASelected.DateValue;
                    PnlPPAUpdateData.InputDataType = 9;
                    PnlPPAUpdateData.DividendPartner = null;
                    PnlPPAUpdateData.Value = this.PnlPPARestatedMEYTDValue;
                    this.arrYTDUpdateData.push(PnlPPAUpdateData);

                    this.PnlPPARestatedMEYTDValue = null;
                    this.blnDisableSaveValue = false;
                    this.sortPnlPPAValues();
                }
                else {
                    this.ValidationStatus = "Validation error";
                    this.ValidationMessage = "Input value is not in a correct format.";
                    this.blnShowPopUp = true;
                }
            }
        }
    }

    onClickPnlPPAClear() {
        this.PnlPPARestatedMEYTDValue = null;
    }

    sortPnlPPAValues() {
        this.arrPnlPPADataValues.sort((n1, n2) => {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }

            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }

            return 0;
        });
    }

    private onRowSelectForPnlPPAValue(event: any) {
        this.objPnlPPAValue = this.clonePnlPPAValue(event.data);
        this.displayDialogForPnlPPA = true;
    }

    private clonePnlPPAValue(objForClone: clsHierarchyEditNode_Node_InputData_Values): clsHierarchyEditNode_Node_InputData_Values {
        let PnlPPAValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (let prop in objForClone) {
            PnlPPAValue[prop] = objForClone[prop];
        }
        return PnlPPAValue;
    }

    savePnlPPAValue() {
        if (this.objPnlPPAValue.Value == undefined || this.objPnlPPAValue.Value == null || this.objPnlPPAValue.Value.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide PnL PPA value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objPnlPPAValue.Value)) {
                let PnlPPAValues = [...this.arrPnlPPADataValues];

                PnlPPAValues[this.findSelectedPnlPPAValueIndex()] = this.objPnlPPAValue;

                this.arrPnlPPADataValues = PnlPPAValues;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 9 && item.BusinessDate == this.objPnlPPAValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                this.selectedPnlPPAValue = this.objPnlPPAValue;

                let PnlPPAUpdateData: clsUpdateData = new clsUpdateData();

                PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                PnlPPAUpdateData.BusinessDate = this.objPnlPPAValue.BusinessDate;
                PnlPPAUpdateData.DateValue = this.objPnlPPAValue.DateValue;
                PnlPPAUpdateData.InputDataType = 9;
                PnlPPAUpdateData.DividendPartner = null;
                PnlPPAUpdateData.Value = this.objPnlPPAValue.Value;

                this.arrYTDUpdateData.push(PnlPPAUpdateData);

                this.objPnlPPAValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForPnlPPA = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    findSelectedPnlPPAValueIndex() {
        let objPnlPPASelected: IHierarchyEditNode_Node_InputData_Values = new clsHierarchyEditNode_Node_InputData_Values();

        objPnlPPASelected = this.arrPnlPPADataValues.find(x => x.BusinessDate == this.objPnlPPAValue.BusinessDate);

        return this.arrPnlPPADataValues.indexOf(objPnlPPASelected);
    }

    deletePnlPPAValues(PnlPPAValue: IHierarchyEditNode_Node_InputData_Values) {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected restated month end amount will be deleted. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.arrPnlPPADataValues.splice(this.arrPnlPPADataValues.indexOf(PnlPPAValue), 1);

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 9 && item.BusinessDate == PnlPPAValue.BusinessDate);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let PnlPPAUpdateData: clsUpdateData = new clsUpdateData();

                PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                PnlPPAUpdateData.BusinessDate = PnlPPAValue.BusinessDate;
                PnlPPAUpdateData.DateValue = PnlPPAValue.DateValue;
                PnlPPAUpdateData.InputDataType = 9;
                PnlPPAUpdateData.DividendPartner = null;
                PnlPPAUpdateData.Value = null;
                this.arrYTDUpdateData.push(PnlPPAUpdateData);

                this.blnDisableSaveValue = false;
                this.sortPnlPPAValues();
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    onDividendPartnerPPAChange() {
        let intPercentageValue: number = 0;
        let selectedDividendAllocation: IHierarchyEditNode_DividendPartnerAllocations_Values = new clsHierarchyEditNode_DividendPartnerAllocations_Values()
        let selectedPPATradingDate: string = this.setDate(this.dtTradingDateDividendPartnerPPA.toString());

        if (this.dividendPPA && this.dividendPPA.length > 0) {
            let divPPA: IHierarchyEnterValue_DividendPPA = this.dividendPPA.find(ppa => ppa.BusinessDate == selectedPPATradingDate
                && ppa.DividendPartnerName == this.strSelectedDividendPartnerPPAName);

            if (!divPPA && this.strSelectedDividendPartnerPPAName.toString() != "NotSet") {
                selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find(dividendAllocation => dividendAllocation.DividendPartnerNode.Name == this.strSelectedDividendPartnerPPAName);
                intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                this.strDividendPPAReportedMonthEnd = selectedDividendAllocation.DividendPartnerNode.ReportedMEYTD ?
                    selectedDividendAllocation.DividendPartnerNode.ReportedMEYTD.toString() : "0";
                this.blnEnableDividendPPA = true;
            }
            else {
                if (this.strSelectedDividendPartnerPPAName && this.strSelectedDividendPartnerPPAName.toString() != "NotSet") {
                    selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find
                        (dividendAllocation => dividendAllocation.DividendPartnerNode.Name == this.strSelectedDividendPartnerPPAName);
                    intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                    this.blnEnableDividendPPA = false;
                    this.strDividendPPAReportedMonthEnd = selectedDividendAllocation.DividendPartnerNode.ReportedMEYTD ?
                        selectedDividendAllocation.DividendPartnerNode.ReportedMEYTD.toString() : "0";
                }
                else {
                    intPercentageValue = 0;
                    this.strDividendPPAReportedMonthEnd = "0";
                    this.blnEnableDividendPPA = false;
                }
            }
        }
        else {
            if (this.strSelectedDividendPartnerPPAName && this.strSelectedDividendPartnerPPAName.toString() != "NotSet") {
                selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find(dividendAllocation => dividendAllocation.DividendPartnerNode.Name == this.strSelectedDividendPartnerPPAName);
                intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                this.blnEnableDividendPPA = true;
                this.strDividendPPAReportedMonthEnd = selectedDividendAllocation.DividendPartnerNode.ReportedMEYTD ?
                    selectedDividendAllocation.DividendPartnerNode.ReportedMEYTD.toString() : "0";
            }
            else {
                intPercentageValue = 0;
                this.strDividendPPAReportedMonthEnd = "0";
                this.blnEnableDividendPPA = false;
            }
        }

        this.canAddDividendPPA = (
            this.isUserAuthorised("EditDividendPPA")
            &&
            (
                (
                    (this.lockstatus === 0 && this.publishstatus === "Unpublished") ||
                    (
                        (this.lockstatus === 1 || this.publishstatus === "Published") &&
                        this.dtTradingDateDividendPartnerPPA >= this.getTrueUpDateEntryMin()
                    )
                )
            )
            &&
            this.blnEnableDividendPPA && this.strDividendPPAMonthEndDate != null
            &&
            this.strDividendPPAMonthEndDate.trim() != ""
        );

        this.strSelectedDividendPartnerPPAPercentage = intPercentageValue.toString();
    }

    private sortDividendPPAValues() {
        this.dividendPPA.sort((n1, n2) => {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }

            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }

            return 0;
        });
    }

    onClickDividendPPAAdd() {
        if (this.DividendPPARestatedMEValue == undefined || this.DividendPPARestatedMEValue == null || this.DividendPPARestatedMEValue.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide Dividend PPA value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.DividendPPARestatedMEValue)) {
                let selectedPPATradingDate: string = this.setDate(this.dtTradingDateDividendPartnerPPA.toString());

                let ppaSelected: IHierarchyEnterValue_DividendPPA = new clsHierarchyEnterValue_DividendPPA();
                ppaSelected.BusinessDate = selectedPPATradingDate;
                ppaSelected.DividendPartnerName = this.strSelectedDividendPartnerPPAName;
                ppaSelected.RestatedMEDate = this.strDividendPPAMonthEndDate;
                ppaSelected.RestatedMEYTD = this.DividendPPARestatedMEValue;
                this.dividendPPA.push(ppaSelected);

                this.selectedDividendPartnerPPA = ppaSelected;

                this.strSelectedDividendPartnerPPAName = "NotSet";
                this.DividendPPARestatedMEValue = null;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 9 &&
                    item.BusinessDate == selectedPPATradingDate && item.DividendPartner.Name == this.strSelectedDividendPartnerPPAName);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let ppaUpdateData: clsUpdateData = new clsUpdateData();

                ppaUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ppaUpdateData.BusinessDate = ppaSelected.BusinessDate;
                ppaUpdateData.DateValue = ppaSelected.RestatedMEDate;
                ppaUpdateData.InputDataType = 9;
                ppaUpdateData.DividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == ppaSelected.DividendPartnerName);
                ppaUpdateData.Value = ppaSelected.RestatedMEYTD;
                this.arrYTDUpdateData.push(ppaUpdateData);

                this.strDividendPPAReportedMonthEnd = "0";
                this.strProjectedDividendPPA = "";
                this.blnDisableSaveValue = false;
                this.blnEnableDividendPPA = true;
                this.canAddDividendPPA = false;
                this.sortDividendPPAValues();
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    onClickDividendPPAClear() {
        this.strSelectedDividendPartnerPPAName = "NotSet";
        this.DividendPPARestatedMEValue = null;
        this.strDividendPPAReportedMonthEnd = "0";
        this.strProjectedDividendPPA = "";
        this.blnEnableDividendPPA = true;
    }

    onRowSelectForDividendPPAValue(event: any) {
        this.objDividendPartnerPPAValue = this.cloneDividendPPAValue(event.data);
        this.displayDialogForDividendPPA = true;
    }

    private cloneDividendPPAValue(objForClone: clsHierarchyEnterValue_DividendPPA): clsHierarchyEnterValue_DividendPPA {
        let dividendPPAValue = new clsHierarchyEnterValue_DividendPPA();
        for (let prop in objForClone) {
            dividendPPAValue[prop] = objForClone[prop];
        }
        return dividendPPAValue;
    }

    saveDividendPPAValue() {
        if (this.objDividendPartnerPPAValue.RestatedMEYTD == undefined || this.objDividendPartnerPPAValue.RestatedMEYTD == null || this.objDividendPartnerPPAValue.RestatedMEYTD.toString().length == 0) {
            this.ValidationStatus = "Validation error";
            this.ValidationMessage = "Please provide Dividend PPA value";
            this.blnShowPopUp = true;
        }
        else {
            if (!isNaN(this.objDividendPartnerPPAValue.RestatedMEYTD)) {
                let dividendPPAValues = [...this.dividendPPA];

                dividendPPAValues[this.findSelectedDividendPPAValueIndex()] = this.objDividendPartnerPPAValue;

                this.dividendPPA = dividendPPAValues;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 9
                    && item.BusinessDate == this.objDividendPartnerPPAValue.BusinessDate && item.DividendPartner.Name == this.strSelectedDividendPartnerPPAName);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                this.selectedDividendPartnerPPA = this.objDividendPartnerPPAValue;

                let ppaUpdateData: clsUpdateData = new clsUpdateData();

                ppaUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ppaUpdateData.DividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == this.objDividendPartnerPPAValue.DividendPartnerName);
                ppaUpdateData.InputDataType = 9;
                ppaUpdateData.BusinessDate = this.objDividendPartnerPPAValue.BusinessDate;
                ppaUpdateData.DateValue = this.objDividendPartnerPPAValue.RestatedMEDate;
                ppaUpdateData.Value = this.objDividendPartnerPPAValue.RestatedMEYTD;

                this.arrYTDUpdateData.push(ppaUpdateData);

                this.objDividendPartnerPPAValue = null;
                this.blnDisableSaveValue = false;
                this.displayDialogForDividendPPA = false;
            }
            else {
                this.ValidationStatus = "Validation error";
                this.ValidationMessage = "Input value is not in a correct format.";
                this.blnShowPopUp = true;
            }
        }
    }

    findSelectedDividendPPAValueIndex() {
        let objDividendPPASelected: IHierarchyEnterValue_DividendPPA = new clsHierarchyEnterValue_DividendPPA();

        objDividendPPASelected = this.dividendPPA
            .find(x => x.BusinessDate == this.objDividendPartnerPPAValue.BusinessDate
                && x.DividendPartnerName == this.objDividendPartnerPPAValue.DividendPartnerName);

        return this.dividendPPA.indexOf(objDividendPPASelected);
    }

    deleteDividendPartnerPPA(dividendPPARowValue: IHierarchyEnterValue_DividendPPA) {
        this.blnShowConfirmation = true;
        this.confirmationService.confirm({
            acceptVisible: true,
            rejectVisible: true,
            message: 'Selected restated month end amount will be deleted. Are you sure?',
            accept: () => {
                this.blnShowConfirmation = false;
                this.dividendPPA.splice(this.dividendPPA.indexOf(dividendPPARowValue), 1);
                this.objDividendPartnerPPAValue = null;

                let arrData: clsUpdateData = this.arrYTDUpdateData.find(item => item.InputDataType == 9
                    && item.BusinessDate == dividendPPARowValue.BusinessDate && item.DividendPartner.Name == dividendPPARowValue.DividendPartnerName);

                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }

                let trueUpUpdateData: clsUpdateData = new clsUpdateData();

                trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                trueUpUpdateData.BusinessDate = dividendPPARowValue.BusinessDate;
                trueUpUpdateData.DateValue = dividendPPARowValue.RestatedMEDate;
                trueUpUpdateData.InputDataType = 9;
                trueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(dividendPartner => dividendPartner.Name == dividendPPARowValue.DividendPartnerName);
                trueUpUpdateData.Value = null;

                this.arrYTDUpdateData.push(trueUpUpdateData);

                this.blnDisableSaveValue = false;
                this.sortDividendPPAValues();
            },
            reject: () => {
                this.blnShowConfirmation = false;
            }
        });
    }

    onSelectDividendPartnerPPATradingDate() {
        this.strSelectedDividendPartnerPPAName = "NotSet";
        this.blnEnableDividendPPA = false;
        this.canAddDividendPPA = false;
    }

    onChangeRestatedMonthEndValue(event: any) {
        this.strProjectedDividendPPA = (this.DividendPPARestatedMEValue - Number(this.strDividendPPAReportedMonthEnd)).toString();
    }

    public setLockedStatus(data: any): void {
        this.lockstatus = data.Result.NumericValue;
        if (this.lockstatus == 1) {
            this.blnBusinessDateLocked = true;
        }
        else if (this.lockstatus == 0) {
            this.blnBusinessDateLocked = false;
        }

        if (this.lockstatus == 1) {
            this.TrueUpDate = this.appTprHierarchyComponent.getPreviousorNextWorkingDay(new Date(this.businessDate), false);
        }
        else {
            let arrDates: Date[] = [];
            let dividendPartnerNodes: IHierarchyEditNode_DividendPartnerAllocations_Values[] = this.enterValueCompleteData ?
                this.enterValueCompleteData.DividendPartnerAllocations.$values.filter(
                    divAllocation => divAllocation.DividendPartnerNode.AllDatesForCurrentReportingDate != null &&
                        divAllocation.DividendPartnerNode.AllDatesForCurrentReportingDate.$values != null
                ) : null;

            if (dividendPartnerNodes) {
                dividendPartnerNodes.forEach(allocation => {
                    allocation.DividendPartnerNode.AllDatesForCurrentReportingDate.$values.forEach(date => {
                        let dateArray: string[] = [];
                        dateArray = date.split(",");
                        dateArray.forEach(date => arrDates.push(new Date(date)));
                    });
                });

                if (arrDates && arrDates.length > 0) {
                    this.TrueUpDate = this.getMinDate(arrDates);
                }
                else {
                    this.TrueUpDate = new Date(this.businessDate);
                }
            }
            else {
                this.TrueUpDate = new Date(this.businessDate);
            }
        }
    }

    public getMinDate(all_dates: Date[]): Date {
        let min_dt: Date = all_dates[0];
        let min_dtObj: Date = new Date(all_dates[0]);

        all_dates.forEach((dt) => {
            if (new Date(dt) < min_dtObj) {
                min_dt = dt; min_dtObj = new Date(dt);
            }
        }); return min_dt;
    }

    private stopRefreshing() {
        this.isRequesting = false;
    }

    private setUserRolesData(data: any): void {
        this.availableRoles.$values = [];
        this.availableRoles.$values = data.Result.UserRoles.$values;

        this.availableRoles.$values.forEach((role: any) => {
            this.userRoles.push(role.Name);
        });

        localStorage.setItem("UserRole", JSON.stringify(this.userRoles));
    }

    public getConstants(data: any): void {
        this.constants = data;
        this.AuthorizeUser();
    }

    private AuthorizeUser() {
        this.canEnterValue = this.isUserAuthorised("EnterValue");
    }

    public isUserAuthorised(action: string): boolean {
        switch (action) {
            case "EnterValue":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        this.userRoles.some(x => x == this.constants.TPRMarginManagement) ||
                        this.userRoles.some(x => x == this.constants.TPRRiskManagement));
            case "EditYTD":
            case "EditPPA":
            case "EditDividendPPA":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser));
            case "EditMVar":
            case "EditMVarLimit":
            case "EditMVarTempLimit":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        this.userRoles.some(x => x == this.constants.TPRRiskManagement));
            case "EditDividendTrueUp":
                return this.userRoles != undefined && this.constants != undefined &&
                    (this.userRoles.some(x => x == this.constants.TPRSuperUser) ||
                        this.userRoles.some(x => x == this.constants.TPRMarginManagement));
            default: return false;
        }
    }
}

export class clsHierarchyEditNode_Node_InputData_Values implements IHierarchyEditNode_Node_InputData_Values {
    constructor(
        public $type: string = null,
        public Value: number = 0,
        public DateValue: string = null,
        public BusinessDate: string = null,
        public InputDataType: string = null,
        public Published: boolean = false,
        public InputDataTypeEnum: number = 1,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0,
        public CalculatedPPA: number = null,
        public IsLocked: boolean = false
    ) { }
}

export class clsUpdateData {
    public $type: string;
    public DividendPartner: IDividendPartnerValue;
    public InputDataType: number;
    public BusinessDate: string;
    public Value: number;
    public DateValue: string;
}

export class clsHierarchyNodeEnterValuePostData implements IHierarchyNodeEnterValuePostData {
    constructor(
        public $type: string = null,
        public Node: IHierarchyEditNode_Node = null,
        public HierarchyType: string = null,
        public UpdateData: IHierarchyNodeEnterValuePostData_UpdateData[] = []
    ) { }
}

export class clsHierarchyNodeEnterValuePostData_UpdateData implements IHierarchyNodeEnterValuePostData_UpdateData {
    constructor(
        public $type: string = null,
        public DividendPartner: IDividendPartnerValue = null,
        public InputDataType: number = 0,
        public BusinessDate: string = null,
        public Value: number = 0,
        public DateValue: string = null
    ) { }
}

export class clsHierarchyEnterValue_DividendTrueUp implements IHierarchyEnterValue_DividendTrueUp {
    constructor(
        public BusinessDate: string = null,
        public DateValue: string = null,
        public InputDataType: string = null,
        public DividendPartnerName: string = null,
        public Value: number = 0,
        public TrueUp: number = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public IsLocked: boolean = false
    ) { }
}

export class clsHierarchyEditNode_DividendPartnerAllocations_Values implements IHierarchyEditNode_DividendPartnerAllocations_Values {
    constructor(
        public $type: string = null,
        public Percentage: number = 0,
        public RegionNode: any = null,
        public DividendPartnerNode: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode = null,
        public BusinessSegmentNode: any = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0,
    ) { }
}

export class clsHierarchyEnterValue_DividendPPA implements IHierarchyEnterValue_DividendPPA {
    constructor(
        public BusinessDate: string = null,
        public DividendPartnerName: string = null,
        public RestatedMEDate: string = null,
        public RestatedMEYTD: number = 0,
        public CalculatedPPA: number = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public IsLocked: boolean = false
    ) { }
}

class UserRolesValues implements IUserRolesValues {
    constructor(public $values: IUserRolesValue[] = null) { }
}