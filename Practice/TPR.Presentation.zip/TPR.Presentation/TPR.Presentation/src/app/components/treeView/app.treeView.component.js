"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var primeng_1 = require('primeng/primeng');
var app_TPRHierarchyservice_1 = require('../../service/app.TPRHierarchyservice');
var CircularJSON = require('circular-json');
var AppTprHierarchyComponent = (function () {
    function AppTprHierarchyComponent(tPRHierarchyservice, router, confirmationService) {
        this.tPRHierarchyservice = tPRHierarchyservice;
        this.router = router;
        this.confirmationService = confirmationService;
        this.selectedNode = new RootValue();
        this.blnMoveNode = false;
        this.blnAddToFavourites = false;
        this.searchNodeResults = [];
        this.strSearchNodeText = '';
        this.nodeArrays = [];
        this.traversedPathArray = [];
        this.traversedPathArrayForNodeRemoval = [];
        this.arrFavouriteNodes = [];
        this.displayMessage = false;
        this.successMessage = '';
        this.treeMessage = 'Tree Alert goes here';
        this.Status = '';
    }
    AppTprHierarchyComponent.prototype.ngOnInit = function () {
        var _this = this;
        //debugger;
        this.loadTree();
        this.items = [
            //{ label: 'Add Child', command: (event) => this.addChildSelectedContextMenu(this.selectedNode), items: [{ label: '', items: [{ label: '', icon: '', command: null }] }] },
            { label: 'Add Child', command: function (event) { return _this.addChildSelectedContextMenu(_this.selectedNode); } },
            { label: 'Edit Node', command: function (event) { return _this.editChildSelectedContextMenu(_this.selectedNode); } },
            { label: 'Remove Node', command: function (event) { return _this.removeNodeSelectedContextMenu(_this.selectedNode); } },
            { label: 'Enter Value', command: function (event) { return _this.enterValueSelectedContextMenu(_this.selectedNode); } },
            { label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } },
            { label: 'Add To Favourites', command: function (event) { return _this.addToFavouritesSelectedContextMenu(_this.selectedNode); } },
        ];
    };
    AppTprHierarchyComponent.prototype.loadTree = function () {
        var _this = this;
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(function (files) { return _this.setNodeData(files); });
    };
    AppTprHierarchyComponent.prototype.setNodeData = function (data) {
        var _this = this;
        localStorage.setItem("MainHierarchyData", JSON.stringify(data.Result.Children.$values));
        this.hierarchy = data.Result.Children.$values;
        this.hierarchy.forEach(function (node) {
            _this.updateChildrenPropRecursive(node);
        });
        console.log("hierarchy ->", this.hierarchy);
        this.mainListOfTree = this.hierarchy;
        this.updateNodeProps();
        this.modifiedmainListOfTree = this.hierarchy;
        console.log("MainListOfTree ->", this.mainListOfTree);
        this.searchNodeResults = data.Result.NodeNames.$values;
        this.mainNodeStartDate = data.Result.StartDate;
        this.mainNodeType = data.Result.Type;
        this.mainNodeId = data.Result.Id;
        //console.log(this.searchNodeResults);
        // this.updateNodeProps();
        console.log(JSON.parse((localStorage.getItem("MainHierarchyData"))));
        this.modifiedmainListOfTree = JSON.parse((localStorage.getItem("MainHierarchyData")));
        console.log(this.modifiedmainListOfTree);
    };
    AppTprHierarchyComponent.prototype.updateChildrenPropRecursive = function (node) {
        var _this = this;
        node.Children = node.Children.$values;
        node.children = node.Children;
        node.label = node.NodeName;
        if (node.Children) {
            node.Children.forEach(function (childNode) {
                _this.updateChildrenPropRecursive(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.updatePropsRecursive = function (node) {
        // node.expandedIcon = "fa-minus-square";
        // node.collapsedIcon = "fa-plus-square"; 
        // node.label = node.NodeName;
        // node.children = node.Children.$values;
        // if (node.children) {
        //     node.children.forEach(childNode => {
        //         this.updatePropsRecursive(childNode);
        //     });
        // }
    };
    AppTprHierarchyComponent.prototype.updateNodeProps = function () {
        var _this = this;
        this.mainListOfTree.forEach(function (node) {
            _this.updatePropsRecursive(node);
            _this.AddNodeToArray(node);
        });
    };
    AppTprHierarchyComponent.prototype.AddNodeToArray = function (node) {
        var _this = this;
        this.nodeArrays.push({
            label: node.NodeName,
            $type: node.type,
            Children: node.Children,
            HasAnyOutputData: node.HasAnyOutputData,
            HasPlans: node.HasPlans,
            Level: node.Level,
            MVarUpdateTiming: node.MVarUpdateTiming,
            IsActive: node.IsActive,
            IsPnlHolder: node.IsPnlHolder,
            NodeId: node.NodeId,
            NodeType: node.NodeType,
            SplitType: node.SplitType,
            UpdateTiming: node.UpdateTiming,
            children: node.children,
            collapsedIcon: "fa-plus-square",
            data: node.data,
            expanded: node.expanded,
            expandedIcon: "fa-minus-square",
            icon: node.icon,
            id: node.id,
            leaf: node.leaf,
            parent: node.parent,
            Id: node.Id,
            ParentId: node.ParentId,
            NodeName: node.NodeName,
            type: node.type,
            partialSelected: node.partialSelected
        });
        node.children = node.Children;
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.AddNodeToArray(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.expandAll = function () {
        var _this = this;
        this.mainListOfTree.forEach(function (node) { _this.expandRecursive(node, true); });
    };
    AppTprHierarchyComponent.prototype.collapseAll = function () {
        var _this = this;
        this.mainListOfTree.forEach(function (node) {
            _this.expandRecursive(node, false);
        });
    };
    AppTprHierarchyComponent.prototype.expandRecursive = function (node, isExpand) {
        var _this = this;
        node.expanded = isExpand;
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.expandRecursive(childNode, isExpand);
            });
        }
    };
    AppTprHierarchyComponent.prototype.expandRecursiveForSearch = function (node, isExpanded) {
        var _this = this;
        node.expanded = this.traversedPathArray.find(function (item) { return item == node.Id; }) ? isExpanded : !isExpanded;
        if (node.NodeName == this.strSearchNodeText) {
            this.selectedNode = node;
            node.expanded = !isExpanded;
        }
        if (node.children) {
            node.children.forEach(function (childNode) {
                _this.expandRecursiveForSearch(childNode, isExpanded);
            });
        }
    };
    // This method will be called when the user clicks(left click) on any of the node item.
    AppTprHierarchyComponent.prototype.nodeSelect = function (event) {
        //console.log(this.selectedNode);
        this.intSelectedNodeID = this.selectedNode.NodeId;
    };
    // This method will be called when the user clicks (right click) on any of the node item.
    AppTprHierarchyComponent.prototype.nodeContextMenuSelect = function (event) {
        //console.log(this.selectedNode);
        this.intSelectedNodeID = this.selectedNode.NodeId;
        if (this.selectedNode.IsPnlHolder) {
            this.items.forEach(function (item, index) {
                if (item.label == "Add Child") {
                    item.disabled = true;
                }
                // if (item.label == "Remove Node") {
                //     item.disabled = true;
                // }
            });
        }
        else {
            this.items.forEach(function (item, index) {
                if (item.label == "Add Child") {
                    item.disabled = false;
                }
                if (item.label == "Remove Node") {
                    item.disabled = false;
                }
            });
        }
    };
    AppTprHierarchyComponent.prototype.filterNodes = function (event) {
        //debugger;
        this.filteredSearchNodeResults = [];
        for (var i = 0; i < this.searchNodeResults.length; i++) {
            var node = this.searchNodeResults[i];
            if (node.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
                this.filteredSearchNodeResults.push(node);
            }
        }
    };
    AppTprHierarchyComponent.prototype.handleFilterNodeDropdownClick = function (event) {
        this.filteredSearchNodeResults = [];
        this.filteredSearchNodeResults = this.searchNodeResults;
    };
    AppTprHierarchyComponent.prototype.OnNodeSearch = function () {
        var _this = this;
        //debugger;
        //alert(this.strSearchNodeText);
        this.traversedPathArray = [];
        var nodeSearched = this.nodeArrays.find(function (node) { return node.NodeName == _this.strSearchNodeText; });
        if (nodeSearched) {
            //this.mainListOfTree.forEach(node => this.expandRecursiveForSearch(node));
            this.appendToTraversedArray(nodeSearched.Id, nodeSearched.ParentId);
            this.mainListOfTree.forEach(function (node) { return _this.expandRecursiveForSearch(node, true); });
        }
    };
    AppTprHierarchyComponent.prototype.appendToTraversedArray = function (Id, parentId) {
        this.traversedPathArray.push(Id);
        var parentNode = this.nodeArrays.find(function (node) { return node.Id == parentId; });
        if (parentNode) {
            this.appendToTraversedArray(parentNode.Id, parentNode.ParentId);
        }
    };
    AppTprHierarchyComponent.prototype.appendToTraversedArrayForNodeRemoval = function (Id, parentId) {
        this.traversedPathArrayForNodeRemoval.push(Id);
        var parentNode = this.nodeArrays.find(function (node) { return node.Id == parentId; });
        if (parentNode) {
            this.appendToTraversedArrayForNodeRemoval(parentNode.Id, parentNode.ParentId);
        }
    };
    AppTprHierarchyComponent.prototype.OnClearNodeSearch = function () {
        this.strSearchNodeText = '';
    };
    AppTprHierarchyComponent.prototype.addChildSelectedContextMenu = function (SelectedFile) {
        //console.log(SelectedFile);
    };
    AppTprHierarchyComponent.prototype.editChildSelectedContextMenu = function (SelectedFile) {
        //console.log(SelectedFile);
        //this.blnEditChildModalShow = true;
        this.router.navigate(['/hierarchy/editNode', this.intSelectedNodeID]);
    };
    AppTprHierarchyComponent.prototype.enterValueSelectedContextMenu = function (SelectedFile) {
        //console.log(SelectedFile);
        //this.blnEnterValueModalShow = true;
        this.router.navigate(['/hierarchy/enterValue', this.intSelectedNodeID]);
    };
    AppTprHierarchyComponent.prototype.moveNodeSelectedContextMenu = function (SelectedFile) {
        var _this = this;
        console.log("Begin Moving");
        this.moveNode = SelectedFile;
        console.log("moveNodeSelectedContextMenu->", this.moveNode);
        this.items.push({ label: 'Drop Node', command: function (event) { return _this.dropNodeSelectedContextMenu(_this.selectedNode); } });
        var moveMenuitem = this.items.find(function (x) { return x.label == "Move Node"; });
        this.items.splice(this.items.indexOf(moveMenuitem), 1);
    };
    AppTprHierarchyComponent.prototype.dropNodeSelectedContextMenu = function (SelectedFile) {
        var _this = this;
        console.log("Begin Drop");
        console.log("dropNodeSelectedContextMenu->", SelectedFile);
        var dropMenuitem = this.items.find(function (x) { return x.label == "Drop Node"; });
        this.items.splice(this.items.indexOf(dropMenuitem), 1);
        this.items.push({ label: 'Move Node', command: function (event) { return _this.moveNodeSelectedContextMenu(_this.selectedNode); } });
        this.confirmationService.confirm({
            message: 'Are you sure?',
            accept: function () {
                _this.mainListOfTree.forEach(function (node) { return _this.updateArrayForNodeDrop(node); });
                _this.mainListOfTree.forEach(function (node) { return _this.preparePostTreeData(node); });
                console.log("Updated Hierarchy ->", _this.mainListOfTree);
                var objclsHierarchyRemoveNode_Post = new clsHierarchyRemoveNode_Post();
                objclsHierarchyRemoveNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightHierarchyInstanceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                console.log("mainListOfTree ->", _this.mainListOfTree);
                objclsHierarchyRemoveNode_Post.Children = _this.mainListOfTree;
                objclsHierarchyRemoveNode_Post.NodeNames = _this.searchNodeResults;
                objclsHierarchyRemoveNode_Post.Type = _this.mainNodeType;
                objclsHierarchyRemoveNode_Post.StartDate = _this.mainNodeStartDate;
                objclsHierarchyRemoveNode_Post.Id = _this.mainNodeId;
                var postData = CircularJSON.stringify(objclsHierarchyRemoveNode_Post);
                console.log("Post Data ->", postData);
                _this.tPRHierarchyservice.updateLightWeight(postData)
                    .subscribe(function (response) {
                    debugger;
                    console.log(response);
                    if (response.Error) {
                        alert(response.Error);
                    }
                    else {
                        console.log("Node is moved successfully");
                        _this.loadTree();
                        _this.Status = 'Success';
                        _this.successMessage = 'Node is moved successfully';
                        _this.displayMessage = true;
                    }
                }, function (error) {
                    debugger;
                    console.log(error);
                    _this.Status = 'Error';
                    _this.successMessage = error;
                    _this.displayMessage = true;
                });
            }
        });
    };
    AppTprHierarchyComponent.prototype.addToFavouritesSelectedContextMenu = function (SelectedFile) {
        console.log(SelectedFile);
    };
    AppTprHierarchyComponent.prototype.removeNodeSelectedContextMenu = function (SelectedFile) {
        var _this = this;
        // this method loops through all the array items. May cause performance issue.
        this.confirmationService.confirm({
            message: 'The selected node will be deleted. Are you sure?',
            accept: function () {
                console.log("Removing Node ->", SelectedFile);
                _this.mainListOfTree.forEach(function (node) { return _this.updateArrayForNodeRemoval(node); });
                console.log("Updated Hierarchy ->", _this.mainListOfTree);
                var objclsHierarchyRemoveNode_Post = new clsHierarchyRemoveNode_Post();
                objclsHierarchyRemoveNode_Post.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightHierarchyInstanceDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                console.log("mainListOfTree ->", _this.mainListOfTree);
                objclsHierarchyRemoveNode_Post.Children = _this.mainListOfTree;
                objclsHierarchyRemoveNode_Post.NodeNames = _this.searchNodeResults;
                objclsHierarchyRemoveNode_Post.Type = _this.mainNodeType;
                objclsHierarchyRemoveNode_Post.StartDate = _this.mainNodeStartDate;
                objclsHierarchyRemoveNode_Post.Id = _this.mainNodeId;
                var postData = CircularJSON.stringify(objclsHierarchyRemoveNode_Post);
                console.log("Post Data ->", postData);
                _this.tPRHierarchyservice.updateLightWeight(postData)
                    .subscribe(function (response) {
                    debugger;
                    console.log(response);
                    if (response.Error) {
                        alert(response.Error);
                    }
                    else {
                        console.log("Node deleted successfully");
                        _this.loadTree();
                        _this.Status = 'Success';
                        _this.successMessage = 'Node deleted successfully';
                        _this.displayMessage = true;
                    }
                }, function (error) {
                    debugger;
                    console.log(error);
                    _this.Status = 'Error';
                    _this.successMessage = error;
                    _this.displayMessage = true;
                });
            }
        });
    };
    AppTprHierarchyComponent.prototype.updateArrayForNodeRemoval = function (filteredNode) {
        var _this = this;
        //debugger;        
        filteredNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        if (filteredNode.Id == this.selectedNode.ParentId) {
            filteredNode.Children.splice(filteredNode.Children.indexOf(this.selectedNode), 1);
        }
        delete filteredNode.children;
        delete filteredNode.parent;
        if (filteredNode.Children) {
            filteredNode.Children.forEach(function (childNode) {
                _this.updateArrayForNodeRemoval(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.preparePostTreeData = function (node) {
        var _this = this;
        delete node.children;
        delete node.parent;
        if (node.Children) {
            node.Children.forEach(function (childNode) {
                _this.preparePostTreeData(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.updateArrayForNodeDrop = function (filteredNode) {
        var _this = this;
        filteredNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.LightWeightStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        if (filteredNode.Id == this.moveNode.ParentId) {
            delete this.moveNode.children;
            delete this.moveNode.parent;
            filteredNode.Children.splice(filteredNode.Children.indexOf(this.moveNode), 1);
            this.moveNode.ParentId = this.selectedNode.id;
            this.selectedNode.Children.push(this.moveNode);
        }
        delete filteredNode.children;
        delete filteredNode.parent;
        if (filteredNode.Children) {
            filteredNode.Children.forEach(function (childNode) {
                _this.updateArrayForNodeDrop(childNode);
            });
        }
    };
    AppTprHierarchyComponent.prototype.updateProperties = function (filteredNode) {
        debugger;
        var array = filteredNode.Children;
        //console.log(array);
        if (array.$values.length > 0) {
            var obj = JSON.parse(JSON.stringify(filteredNode));
            delete obj.Children;
            obj.Children = array.$values;
            console.log(this.modifiedmainListOfTree);
            debugger;
            console.log(obj);
            debugger;
        }
    };
    AppTprHierarchyComponent = __decorate([
        core_1.Component({
            selector: 'treeView',
            templateUrl: 'app/components/treeView/app.treeView.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRHierarchyservice_1.TPRHierarchyservice, router_1.Router, primeng_1.ConfirmationService])
    ], AppTprHierarchyComponent);
    return AppTprHierarchyComponent;
}());
exports.AppTprHierarchyComponent = AppTprHierarchyComponent;
var RootValue = (function () {
    function RootValue(label, NodeName, id, children, Children, data, icon, expandedIcon, collapsedIcon, leaf, expanded, type, parent, partialSelected, $type, HasAnyOutputData, HasPlans, UpdateTiming, NodeId, NodeType, IsActive, Level, ParentId, IsPnlHolder, MVarUpdateTiming, SplitType, Id) {
        if (label === void 0) { label = null; }
        if (NodeName === void 0) { NodeName = null; }
        if (id === void 0) { id = null; }
        if (children === void 0) { children = null; }
        if (Children === void 0) { Children = null; }
        if (data === void 0) { data = null; }
        if (icon === void 0) { icon = null; }
        if (expandedIcon === void 0) { expandedIcon = null; }
        if (collapsedIcon === void 0) { collapsedIcon = null; }
        if (leaf === void 0) { leaf = null; }
        if (expanded === void 0) { expanded = null; }
        if (type === void 0) { type = null; }
        if (parent === void 0) { parent = null; }
        if (partialSelected === void 0) { partialSelected = null; }
        if ($type === void 0) { $type = null; }
        if (HasAnyOutputData === void 0) { HasAnyOutputData = null; }
        if (HasPlans === void 0) { HasPlans = null; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (NodeId === void 0) { NodeId = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsActive === void 0) { IsActive = null; }
        if (Level === void 0) { Level = null; }
        if (ParentId === void 0) { ParentId = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Id === void 0) { Id = null; }
        this.label = label;
        this.NodeName = NodeName;
        this.id = id;
        this.children = children;
        this.Children = Children;
        this.data = data;
        this.icon = icon;
        this.expandedIcon = expandedIcon;
        this.collapsedIcon = collapsedIcon;
        this.leaf = leaf;
        this.expanded = expanded;
        this.type = type;
        this.parent = parent;
        this.partialSelected = partialSelected;
        this.$type = $type;
        this.HasAnyOutputData = HasAnyOutputData;
        this.HasPlans = HasPlans;
        this.UpdateTiming = UpdateTiming;
        this.NodeId = NodeId;
        this.NodeType = NodeType;
        this.IsActive = IsActive;
        this.Level = Level;
        this.ParentId = ParentId;
        this.IsPnlHolder = IsPnlHolder;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.SplitType = SplitType;
        this.Id = Id;
    }
    return RootValue;
}());
var clsHierarchyRemoveNode_Post = (function () {
    function clsHierarchyRemoveNode_Post($type, Children, NodeNames, Type, StartDate, EndDate, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Children === void 0) { Children = []; }
        if (NodeNames === void 0) { NodeNames = []; }
        if (Type === void 0) { Type = null; }
        if (StartDate === void 0) { StartDate = null; }
        if (EndDate === void 0) { EndDate = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Children = Children;
        this.NodeNames = NodeNames;
        this.Type = Type;
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyRemoveNode_Post;
}());
var clsTransposedRootObject = (function () {
    function clsTransposedRootObject($type, Children, HasAnyOutputData, HasPlans, UpdateTiming, NodeName, NodeId, NodeType, IsActive, Level, ParentId, IsPnlHolder, MVarUpdateTiming, SplitType, Id) {
        if ($type === void 0) { $type = null; }
        if (Children === void 0) { Children = []; }
        if (HasAnyOutputData === void 0) { HasAnyOutputData = false; }
        if (HasPlans === void 0) { HasPlans = false; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (NodeName === void 0) { NodeName = null; }
        if (NodeId === void 0) { NodeId = 0; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsActive === void 0) { IsActive = false; }
        if (Level === void 0) { Level = 0; }
        if (ParentId === void 0) { ParentId = 0; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Children = Children;
        this.HasAnyOutputData = HasAnyOutputData;
        this.HasPlans = HasPlans;
        this.UpdateTiming = UpdateTiming;
        this.NodeName = NodeName;
        this.NodeId = NodeId;
        this.NodeType = NodeType;
        this.IsActive = IsActive;
        this.Level = Level;
        this.ParentId = ParentId;
        this.IsPnlHolder = IsPnlHolder;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.SplitType = SplitType;
        this.Id = Id;
    }
    return clsTransposedRootObject;
}());
//# sourceMappingURL=app.treeView.component.js.map