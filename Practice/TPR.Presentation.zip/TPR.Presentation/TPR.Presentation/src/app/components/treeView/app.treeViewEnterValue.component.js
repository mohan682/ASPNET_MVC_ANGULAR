"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
require('rxjs/add/operator/switchMap');
var primeng_1 = require('primeng/primeng');
var app_TPRHierarchyservice_1 = require('../../service/app.TPRHierarchyservice');
var app_TPRNodeTypeService_1 = require('../../service/app.TPRNodeTypeService');
var app_regionService_1 = require('../../service/app.regionService');
var app_TPRProfitAlertGroupsService_1 = require('../../service/app.TPRProfitAlertGroupsService');
var app_TPRTagsService_1 = require('../../service/app.TPRTagsService');
var app_TPRDividendPartnersService_1 = require('../../service/app.TPRDividendPartnersService');
var app_TPRBusinessSegmentsService_1 = require('../../service/app.TPRBusinessSegmentsService');
var AppTprHierarchyEnterValueComponent = (function () {
    function AppTprHierarchyEnterValueComponent(tPRHierarchyservice, router, route, tPRNodeTypeService, confirmationService, regionsService, tprPAGService, tPRTagsService, tprDividendPartnersService, tprBusinessSegmentsService) {
        this.tPRHierarchyservice = tPRHierarchyservice;
        this.router = router;
        this.route = route;
        this.tPRNodeTypeService = tPRNodeTypeService;
        this.confirmationService = confirmationService;
        this.regionsService = regionsService;
        this.tprPAGService = tprPAGService;
        this.tPRTagsService = tPRTagsService;
        this.tprDividendPartnersService = tprDividendPartnersService;
        this.tprBusinessSegmentsService = tprBusinessSegmentsService;
        this.blnShowModalPouUp = true;
        this.businessDate = '';
        this.blnEnterValueYTDShow = true;
        this.blnEnterValueDividendTrueUpShow = false;
        this.blnEnterValueMVARShow = false;
        this.blnEnterValueMVARLimitShow = false;
        this.blnEnterValueMVARTemporaryLimitShow = false;
        this.blnEnterValuePnlPPAShow = false;
        this.blnEnterValueDividendPartnerPPAShow = false;
        this.blnIsPnlHolder = false;
        this.ytdValues = [];
        this.objYTDValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.displayDialogForYTD = false;
        this.arrYTDUpdateData = [];
        this.objEnterValuePostData = new clsHierarchyNodeEnterValuePostData();
        this.blnDisableSaveValue = true;
        this.dividendTrueUp = [];
        this.selectedDividendPartnerTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
        this.lstDividendPartnerTrueUp = [];
        this.strSelectedDividendPartnerTrueUpName = "";
        this.strSelectedDividendPartnerPercentage = "0";
        this.blnEnableDividendTrueUp = false;
        this.blnHasDividendAllocations = false;
        this.objDividendPartnerTrueUpValue = new clsHierarchyEnterValue_DividendTrueUp();
        this.displayDialogForDividendTrueUp = false;
        this.arrMVarDataValues = [];
        this.selectedMVarValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objMVarValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.blnHasMVarUpdateTiming = false;
        this.displayDialogForMVar = false;
        this.arrMVarLimitDataValues = [];
        this.selectedMVarLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objMVarLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.blnHasMVarLimitUpdateTiming = false;
        this.displayDialogForMVarLimit = false;
        this.arrMVarTempLimitDataValues = [];
        this.selectedMVarTempLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objMVarTempLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.blnHasMVarTempLimitUpdateTiming = false;
        this.displayDialogForMVarTempLimit = false;
        this.blnDisableMVarTempLimitExpiryDate = true;
        this.arrPnlPPADataValues = [];
        this.selectedPnlPPAValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.objPnlPPAValue = new clsHierarchyEditNode_Node_InputData_Values();
        this.strPnlPPAMonthEndDate = "";
        this.strPnlPPAReportedMonthEndYTD = "";
        this.displayDialogForPnlPPA = false;
        this.dividendPPA = [];
        this.selectedDividendPartnerPPA = new clsHierarchyEnterValue_DividendPPA();
        this.lstDividendPartnerPPA = [];
        this.strDividendPPAMonthEndDate = "";
        this.strSelectedDividendPartnerPPAName = "";
        this.strSelectedDividendPartnerPPAPercentage = "0";
        this.strDividendPPAReportedMonthEnd = "0";
        this.blnEnableDividendPPA = false;
        this.objDividendPartnerPPAValue = new clsHierarchyEnterValue_DividendPPA();
        this.displayDialogForDividendPPA = false;
        this.strProjectedDividendPPA = "";
    }
    AppTprHierarchyEnterValueComponent.prototype.ngOnInit = function () {
        //debugger;
        var _this = this;
        // To get the selected node ID from the route service
        this.route.params.subscribe(function (params) {
            _this.intSelectedNodeID = +params['nodeId'];
        });
        this.businessDate = localStorage.getItem("BusinessDate");
        // call the service to fetch the node related data
        this.tPRHierarchyservice.getNodeLevelDataForEdit(this.intSelectedNodeID, this.businessDate)
            .subscribe(function (data) {
            _this.enterValueCompleteData = data.Result;
            console.log(_this.enterValueCompleteData);
            _this.enterValueMenuItems = [
                { label: 'YTD', icon: 'fa fa-table', command: function (event) { return _this.EnterValueYTD(); } },
                { label: 'Dividend True-Up', icon: 'fa fa-table', command: function (event) { return _this.EnterValueDividendTrueUp(); } },
                { label: 'MVAR', icon: 'fa fa-table', command: function (event) { return _this.EnterValueMVAR(); } },
                { label: 'MVAR Limit', icon: 'fa fa-table', command: function (event) { return _this.EnterValueMVARLimit(); } },
                { label: 'MVAR Temporary Limit', icon: 'fa fa-table', command: function (event) { return _this.EnterValueMVARTemporaryLimit(); } },
                { label: 'Pnl PPA', icon: 'fa fa-table', command: function (event) { return _this.EnterValuePnlPPA(); } },
                { label: 'Dividend Partner PPA', icon: 'fa fa-table', command: function (event) { return _this.EnterValueDividendPartnerPPA(); } },
            ];
            if (_this.enterValueCompleteData && !_this.enterValueCompleteData.Node.IsPnlHolder) {
                _this.blnIsPnlHolder = false;
                _this.enterValueMenuItems.forEach(function (menuItem) {
                    if (menuItem.label == "YTD") {
                        menuItem.disabled = true;
                    }
                    if (menuItem.label == "Dividend True-Up") {
                        menuItem.disabled = true;
                    }
                    if (menuItem.label == "Pnl PPA") {
                        menuItem.disabled = true;
                    }
                    if (menuItem.label == "Dividend Partner PPA") {
                        menuItem.disabled = true;
                    }
                });
            }
            else {
                _this.blnIsPnlHolder = true;
            }
            // get the YTD values and assign and sort the values
            var newDate = new Date(_this.businessDate);
            _this.minDate = new Date();
            _this.minDate.setDate(newDate.getDate() - 1);
            _this.dtTradingDate = _this.minDate;
            _this.dtTradingDateDividendPartnerTrueUp = _this.minDate;
            _this.ytdValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values.filter(function (ytdValues) { return ytdValues.InputDataType == "YTD"; }) : [];
            _this.ytdValues.forEach(function (ytdValue) {
                ytdValue.BusinessDate = _this.setDate(ytdValue.BusinessDate);
            });
            _this.sortYTDValues();
            // get the Dividend true up data and assign the values
            if (_this.enterValueCompleteData) {
                _this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendAllocation) {
                    dividendAllocation.DividendPartnerNode.InputData.$values.forEach(function (dividendNodeInput) {
                        if (dividendNodeInput.InputDataTypeEnum == 3) {
                            var objHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
                            objHierarchyEnterValue_DividendTrueUp.BusinessDate = _this.setDate(dividendNodeInput.BusinessDate);
                            objHierarchyEnterValue_DividendTrueUp.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                            objHierarchyEnterValue_DividendTrueUp.InputDataType = "YTD True Up";
                            objHierarchyEnterValue_DividendTrueUp.TrueUp = null;
                            objHierarchyEnterValue_DividendTrueUp.Updated = dividendNodeInput.Updated;
                            objHierarchyEnterValue_DividendTrueUp.UpdatedBy = dividendNodeInput.UpdatedBy;
                            objHierarchyEnterValue_DividendTrueUp.Value = dividendNodeInput.Value;
                            _this.dividendTrueUp.push(objHierarchyEnterValue_DividendTrueUp);
                        }
                        else if (dividendNodeInput.InputDataTypeEnum == 10) {
                            var objHierarchyEnterValue_DividendTrueUp = new clsHierarchyEnterValue_DividendTrueUp();
                            objHierarchyEnterValue_DividendTrueUp.BusinessDate = _this.setDate(dividendNodeInput.BusinessDate);
                            objHierarchyEnterValue_DividendTrueUp.DateValue = _this.setDate(dividendNodeInput.DateValue);
                            objHierarchyEnterValue_DividendTrueUp.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                            objHierarchyEnterValue_DividendTrueUp.InputDataType = "PPA True Up";
                            objHierarchyEnterValue_DividendTrueUp.TrueUp = dividendNodeInput.Value;
                            objHierarchyEnterValue_DividendTrueUp.Updated = dividendNodeInput.Updated;
                            objHierarchyEnterValue_DividendTrueUp.UpdatedBy = dividendNodeInput.UpdatedBy;
                            objHierarchyEnterValue_DividendTrueUp.Value = null;
                            _this.dividendTrueUp.push(objHierarchyEnterValue_DividendTrueUp);
                        }
                    });
                });
                //console.log(this.dividendTrueUp);
                _this.blnHasDividendAllocations = _this.enterValueCompleteData.DividendPartnerAllocations.$values.length > 0 ? true : false;
                _this.sortDividendTrueUpValues();
            }
            // get the MVar data and assign the values
            _this.arrMVarDataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "MVar"; }) : [];
            _this.arrMVarDataValues.forEach(function (mvar) {
                mvar.BusinessDate = _this.setDate(mvar.BusinessDate);
            });
            // get the MVarLimit data and assign the values
            _this.arrMVarLimitDataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "MVarLimit"; }) : [];
            _this.arrMVarLimitDataValues.forEach(function (mvarLimit) {
                mvarLimit.BusinessDate = _this.setDate(mvarLimit.BusinessDate);
            });
            // get the MVarTempLimit data and assign the values
            _this.arrMVarTempLimitDataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "MVarTemporaryLimit"; }) : [];
            _this.arrMVarTempLimitDataValues.forEach(function (mvarTempLimit) {
                mvarTempLimit.BusinessDate = _this.setDate(mvarTempLimit.BusinessDate);
                mvarTempLimit.DateValue = _this.setDate(mvarTempLimit.DateValue);
            });
            // get the PnlPPA data and assign the values
            _this.arrPnlPPADataValues = _this.enterValueCompleteData ? _this.enterValueCompleteData.Node.InputData.$values
                .filter(function (ytdValues) { return ytdValues.InputDataType == "Prior Period Adjustment"; }) : [];
            _this.arrPnlPPADataValues.forEach(function (pnlPPA) {
                pnlPPA.BusinessDate = _this.setDate(pnlPPA.BusinessDate);
                pnlPPA.DateValue = _this.setDate(pnlPPA.DateValue);
            });
            // get the Dividend PPA data and assign the values
            if (_this.enterValueCompleteData) {
                _this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendAllocation) {
                    dividendAllocation.DividendPartnerNode.InputData.$values.forEach(function (dividendNodeInput) {
                        if (dividendNodeInput.InputDataTypeEnum == 9) {
                            var objHierarchyEnterValue_DividendPPA = new clsHierarchyEnterValue_DividendPPA();
                            objHierarchyEnterValue_DividendPPA.BusinessDate = _this.setDate(dividendNodeInput.BusinessDate);
                            objHierarchyEnterValue_DividendPPA.RestatedMEDate = _this.setDate(dividendNodeInput.DateValue);
                            objHierarchyEnterValue_DividendPPA.DividendPartnerName = dividendAllocation.DividendPartnerNode.Name;
                            objHierarchyEnterValue_DividendPPA.RestatedMEYTD = dividendNodeInput.Value;
                            objHierarchyEnterValue_DividendPPA.CalculatedPPA = null;
                            objHierarchyEnterValue_DividendPPA.Updated = dividendNodeInput.Updated;
                            objHierarchyEnterValue_DividendPPA.UpdatedBy = dividendNodeInput.UpdatedBy;
                            _this.dividendPPA.push(objHierarchyEnterValue_DividendPPA);
                        }
                    });
                });
                _this.sortDividendPPAValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.ResetAllTemplate = function () {
        this.blnEnterValueYTDShow = false;
        this.blnEnterValueDividendTrueUpShow = false;
        this.blnEnterValueMVARShow = false;
        this.blnEnterValueMVARLimitShow = false;
        this.blnEnterValueMVARTemporaryLimitShow = false;
        this.blnEnterValuePnlPPAShow = false;
        this.blnEnterValueDividendPartnerPPAShow = false;
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueYTD = function () {
        this.ResetAllTemplate();
        this.blnEnterValueYTDShow = true;
        this.sortYTDValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueDividendTrueUp = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnEnterValueDividendTrueUpShow = true;
        this.blnEnableDividendTrueUp = true;
        this.lstDividendPartnerTrueUp = [];
        this.lstDividendPartnerTrueUp.push({ label: "Not Set", value: "NotSet" });
        this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendPartnerAllocation) {
            _this.lstDividendPartnerTrueUp.push({ label: dividendPartnerAllocation.DividendPartnerNode.Name, value: dividendPartnerAllocation.DividendPartnerNode.Name });
        });
        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(function (data) { return _this.setDividendPartnerData(data); });
        this.sortDividendTrueUpValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueMVAR = function () {
        this.ResetAllTemplate();
        this.blnEnterValueMVARShow = true;
        //console.log(this.arrMVarDataValues);
        this.MVarUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;
        this.blnHasMVarUpdateTiming = this.MVarUpdateTiming ? true : false;
        if (this.MVarUpdateTiming) {
            var newDate = new Date(this.businessDate);
            this.MVarMinDate = new Date();
            this.MVarMinDate.setDate(newDate.getDate() + (this.MVarUpdateTiming));
            this.dtMVarTradingDate = this.MVarMinDate;
        }
        this.sortMVarValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueMVARLimit = function () {
        this.ResetAllTemplate();
        this.blnEnterValueMVARLimitShow = true;
        this.MVarLimitUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;
        this.blnHasMVarLimitUpdateTiming = this.MVarLimitUpdateTiming ? true : false;
        if (this.MVarLimitUpdateTiming) {
            var newDate = new Date(this.businessDate);
            this.MVarLimitMinDate = new Date();
            this.MVarLimitMinDate.setDate(newDate.getDate() + (this.MVarLimitUpdateTiming));
            this.dtMVarLimitTradingDate = this.MVarLimitMinDate;
        }
        this.sortMVarLimitValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueMVARTemporaryLimit = function () {
        this.ResetAllTemplate();
        this.blnEnterValueMVARTemporaryLimitShow = true;
        //debugger;
        this.MVarTempLimitUpdateTiming = this.enterValueCompleteData ? this.enterValueCompleteData.MVarUpdateTiming : null;
        this.blnHasMVarTempLimitUpdateTiming = this.MVarTempLimitUpdateTiming ? true : false;
        if (this.MVarTempLimitUpdateTiming) {
            var newDate = new Date(this.businessDate);
            this.MVarTempLimitMinDate = new Date();
            this.MVarTempLimitMinDate.setDate(newDate.getDate() + (this.MVarTempLimitUpdateTiming));
            this.dtMVarTempLimitTradingDate = this.MVarTempLimitMinDate;
            this.setMVarTempLimitExpiryDate();
            this.blnDisableMVarTempLimitExpiryDate = true;
        }
        this.sortMVarTempLimitValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValuePnlPPA = function () {
        this.ResetAllTemplate();
        this.blnEnterValuePnlPPAShow = true;
        this.PnlPPAMinDate = this.minDate;
        this.dtPnlPPATradingDate = this.PnlPPAMinDate;
        this.strPnlPPAMonthEndDate = this.enterValueCompleteData ? this.setDate(this.enterValueCompleteData.Node.PreviousMonthEndDate) : "";
        this.strPnlPPAReportedMonthEndYTD = this.enterValueCompleteData ? this.enterValueCompleteData.Node.ReportedMEYTD : "";
        this.sortPnlPPAValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.EnterValueDividendPartnerPPA = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnEnterValueDividendPartnerPPAShow = true;
        this.blnEnableDividendPPA = true;
        this.DividendPPAMinDate = this.minDate;
        this.dtTradingDateDividendPartnerPPA = this.DividendPPAMinDate;
        this.strDividendPPAMonthEndDate = this.enterValueCompleteData ? this.setDate(this.enterValueCompleteData.Node.PreviousMonthEndDate) : "";
        this.lstDividendPartnerPPA = [];
        this.lstDividendPartnerPPA.push({ label: "Not Set", value: "NotSet" });
        this.enterValueCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendPartnerAllocation) {
            _this.lstDividendPartnerPPA.push({ label: dividendPartnerAllocation.DividendPartnerNode.Name, value: dividendPartnerAllocation.DividendPartnerNode.Name });
        });
        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(function (data) { return _this.setDividendPartnerData(data); });
        this.sortDividendPPAValues();
    };
    AppTprHierarchyEnterValueComponent.prototype.Cancel = function () {
        this.blnShowModalPouUp = false;
        this.router.navigate(['/hierarchy']);
    };
    AppTprHierarchyEnterValueComponent.prototype.Save = function () {
        var _this = this;
        debugger;
        this.confirmationService.confirm({
            message: 'Saving changes to node values. Are you sure?',
            accept: function () {
                debugger;
                _this.objEnterValuePostData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.UpdateDataCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                _this.objEnterValuePostData.HierarchyType = "Main";
                _this.objEnterValuePostData.Node = _this.enterValueCompleteData.Node;
                _this.objEnterValuePostData.UpdateData = _this.arrYTDUpdateData;
                _this.tPRHierarchyservice.updateNodeLevelEnterValueForPost(_this.objEnterValuePostData)
                    .subscribe(function (response) {
                    debugger;
                    console.log(response);
                    if (response.Error) {
                        alert(response.Error);
                    }
                    else {
                        _this.blnShowModalPouUp = false;
                        _this.router.navigateByUrl('/hierarchy');
                    }
                }, function (error) {
                    debugger;
                    console.log(error);
                });
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onAddYTDValue = function (txtYTDValue) {
        if (txtYTDValue == undefined || txtYTDValue == null || txtYTDValue.length == 0) {
            alert("Value cannot be null");
        }
        else {
            //console.log(this.dtTradingDate);
            //console.log(txtYTDValue);
            var selectedYTDDate_1 = this.setDate(this.dtTradingDate.toString());
            //this.ytdValues.forEach(ytdValue => console.log(ytdValue.BusinessDate));
            if (this.ytdValues.findIndex(function (ytdValue) { return ytdValue.BusinessDate == selectedYTDDate_1; }) != -1) {
                alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
            }
            else {
                var ytdSelected = new clsHierarchyEditNode_Node_InputData_Values();
                ytdSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                ytdSelected.BusinessDate = selectedYTDDate_1;
                ytdSelected.InputDataTypeEnum = 1;
                ytdSelected.InputDataType = "YTD";
                ytdSelected.Published = false;
                ytdSelected.Value = Number(txtYTDValue);
                this.ytdValues.push(ytdSelected);
                this.selectedYTDValue = ytdSelected;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 1 && item.BusinessDate != selectedYTDDate);
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 1 && item.BusinessDate == selectedYTDDate_1; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var ytdUpdateData = new clsUpdateData();
                ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ytdUpdateData.BusinessDate = ytdSelected.BusinessDate;
                ytdUpdateData.DateValue = null;
                ytdUpdateData.InputDataType = 1;
                ytdUpdateData.DividendPartner = null;
                ytdUpdateData.Value = ytdSelected.Value;
                this.arrYTDUpdateData.push(ytdUpdateData);
                this.blnDisableSaveValue = false;
                this.sortYTDValues();
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.setDate = function (data) {
        var myDate = new Date(data);
        var output = "";
        var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var modifiedDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        output = myDate.getDate().toString().length > 1 ?
            myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear() :
            "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        return output;
    };
    AppTprHierarchyEnterValueComponent.prototype.sortYTDValues = function () {
        this.ytdValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForYTDValue = function (event) {
        //console.log(event);
        this.objYTDValue = this.cloneYTDValue(event.data);
        this.displayDialogForYTD = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneYTDValue = function (objForClone) {
        var ytdValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            ytdValue[prop] = objForClone[prop];
        }
        return ytdValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteYTDValues = function (ytdValueDeleted) {
        var _this = this;
        //console.log(ytdValueDeleted);
        //debugger;
        this.confirmationService.confirm({
            message: 'Selected YTD amount will be deleted. Are you sure?',
            accept: function () {
                _this.ytdValues.splice(_this.ytdValues.indexOf(ytdValueDeleted), 1);
                _this.objYTDValue = null;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 1 && item.BusinessDate != ytdValueDeleted.BusinessDate);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 1 && item.BusinessDate == ytdValueDeleted.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var ytdUpdateData = new clsUpdateData();
                ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                ytdUpdateData.BusinessDate = ytdValueDeleted.BusinessDate;
                ytdUpdateData.DateValue = null;
                ytdUpdateData.DividendPartner = null;
                ytdUpdateData.InputDataType = 1;
                ytdUpdateData.Value = null;
                _this.arrYTDUpdateData.push(ytdUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortYTDValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.saveYTDValue = function () {
        var _this = this;
        //debugger;
        var ytdValues = this.ytdValues.slice();
        ytdValues[this.findSelectedYTDValueIndex()] = this.objYTDValue;
        this.ytdValues = ytdValues;
        this.arrYTDUpdateData = this.arrYTDUpdateData.filter(function (item) { return item.InputDataType == 1 && item.BusinessDate != _this.objYTDValue.BusinessDate; });
        var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 1 && item.BusinessDate == _this.objYTDValue.BusinessDate; });
        if (arrData) {
            this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
        }
        this.selectedYTDValue = this.objYTDValue;
        var ytdUpdateData = new clsUpdateData();
        ytdUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        ytdUpdateData.BusinessDate = this.objYTDValue.BusinessDate;
        ytdUpdateData.DateValue = null;
        ytdUpdateData.DividendPartner = null;
        ytdUpdateData.InputDataType = 1;
        ytdUpdateData.Value = this.objYTDValue.Value;
        this.arrYTDUpdateData.push(ytdUpdateData);
        this.objYTDValue = null;
        this.blnDisableSaveValue = false;
        this.displayDialogForYTD = false;
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedYTDValueIndex = function () {
        return this.ytdValues.indexOf(this.selectedYTDValue);
    };
    AppTprHierarchyEnterValueComponent.prototype.sortDividendTrueUpValues = function () {
        this.dividendTrueUp.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onDividendPartnerTrueUpChange = function () {
        var _this = this;
        var intPercentageValue = 0;
        var selectedDividendAllocation = new clsHierarchyEditNode_DividendPartnerAllocations_Values();
        var selectedTrueUpTradingDate = this.setDate(this.dtTradingDateDividendPartnerTrueUp.toString());
        //this.dividendTrueUp.forEach(trueUp => console.log(trueUp));
        if (this.dividendTrueUp.findIndex(function (trueUp) { return trueUp.BusinessDate == selectedTrueUpTradingDate
            && trueUp.DividendPartnerName == _this.strSelectedDividendPartnerTrueUpName && trueUp.InputDataType == "YTD True Up"; }) != -1) {
            this.blnEnableDividendTrueUp = true;
        }
        else {
            if (this.strSelectedDividendPartnerTrueUpName && this.strSelectedDividendPartnerTrueUpName.toString() != "NotSet") {
                selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find(function (dividendAllocation) { return dividendAllocation.DividendPartnerNode.Name == _this.strSelectedDividendPartnerTrueUpName; });
                intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                this.blnEnableDividendTrueUp = false;
            }
            else {
                intPercentageValue = 0;
                this.blnEnableDividendTrueUp = true;
            }
        }
        this.strSelectedDividendPartnerPercentage = intPercentageValue.toString();
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendTrueUpAdd = function () {
        if (this.dividendPartnerReportedYTDValue == undefined || this.dividendPartnerReportedYTDValue == null || this.dividendPartnerReportedYTDValue.toString().length == 0) {
            alert("Value cannot be null");
        }
        else {
            // console.log(this.dtTradingDateDividendPartnerTrueUp);
            // console.log(this.strSelectedDividendPartnerTrueUpName);
            // console.log(this.dividendPartnerReportedYTDValue);
            var selectedTrueUpTradingDate_1 = this.setDate(this.dtTradingDateDividendPartnerTrueUp.toString());
            //this.dividendTrueUp.forEach(trueUp => console.log(trueUp));
            var trueUpSelected_1 = new clsHierarchyEnterValue_DividendTrueUp();
            //trueUpSelected.$type = "";
            trueUpSelected_1.BusinessDate = selectedTrueUpTradingDate_1;
            trueUpSelected_1.InputDataType = "YTD True Up";
            trueUpSelected_1.DividendPartnerName = this.strSelectedDividendPartnerTrueUpName;
            trueUpSelected_1.Value = this.dividendPartnerReportedYTDValue;
            this.dividendTrueUp.push(trueUpSelected_1);
            this.selectedDividendPartnerTrueUp = trueUpSelected_1;
            this.strSelectedDividendPartnerTrueUpName = "NotSet";
            this.dividendPartnerReportedYTDValue = null;
            var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 3 && item.BusinessDate == selectedTrueUpTradingDate_1; });
            if (arrData) {
                this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
            }
            var trueUpUpdateData = new clsUpdateData();
            trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            trueUpUpdateData.BusinessDate = trueUpSelected_1.BusinessDate;
            trueUpUpdateData.DateValue = null;
            trueUpUpdateData.InputDataType = 3;
            trueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == trueUpSelected_1.DividendPartnerName; });
            trueUpUpdateData.Value = trueUpSelected_1.Value;
            this.arrYTDUpdateData.push(trueUpUpdateData);
            this.blnDisableSaveValue = false;
            this.blnEnableDividendTrueUp = true;
            this.sortDividendTrueUpValues();
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendTrueUpClear = function () {
        this.strSelectedDividendPartnerTrueUpName = "NotSet";
        this.dividendPartnerReportedYTDValue = null;
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForDividendPartnerTrueUp = function (event) {
        //console.log(event);
        this.objDividendPartnerTrueUpValue = this.cloneDividendTrueUpValue(event.data);
        if (this.objDividendPartnerTrueUpValue.InputDataType == "YTD True Up") {
            this.displayDialogForDividendTrueUp = true;
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneDividendTrueUpValue = function (objForClone) {
        var dividendTrueUpValue = new clsHierarchyEnterValue_DividendTrueUp();
        for (var prop in objForClone) {
            dividendTrueUpValue[prop] = objForClone[prop];
        }
        return dividendTrueUpValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteDividendPartnerTrueUp = function (dividendTrueUpRowValue) {
        //console.log(dividendTrueUpRowValue);
        var _this = this;
        this.confirmationService.confirm({
            message: 'Selected True Up amount will be deleted. Are you sure?',
            accept: function () {
                _this.dividendTrueUp.splice(_this.dividendTrueUp.indexOf(dividendTrueUpRowValue), 1);
                _this.objDividendPartnerTrueUpValue = null;
                if (dividendTrueUpRowValue.InputDataType == "YTD True Up") {
                    var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 3
                        && item.BusinessDate == dividendTrueUpRowValue.BusinessDate && item.DividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    if (arrData) {
                        _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var trueUpUpdateData = new clsUpdateData();
                    trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    trueUpUpdateData.BusinessDate = dividendTrueUpRowValue.BusinessDate;
                    trueUpUpdateData.DateValue = null;
                    trueUpUpdateData.InputDataType = 3;
                    trueUpUpdateData.DividendPartner = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    trueUpUpdateData.Value = null;
                    _this.arrYTDUpdateData.push(trueUpUpdateData);
                }
                else if (dividendTrueUpRowValue.InputDataType == "PPA True Up") {
                    var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 10
                        && item.BusinessDate == dividendTrueUpRowValue.BusinessDate && item.DividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    if (arrData) {
                        _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                    }
                    var trueUpUpdateData = new clsUpdateData();
                    trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaTrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    trueUpUpdateData.InputDataType = 10;
                    trueUpUpdateData.BusinessDate = dividendTrueUpRowValue.BusinessDate;
                    trueUpUpdateData.DividendPartner = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendTrueUpRowValue.DividendPartnerName; });
                    trueUpUpdateData.Value = null;
                    trueUpUpdateData.DateValue = dividendTrueUpRowValue.DateValue;
                    _this.arrYTDUpdateData.push(trueUpUpdateData);
                }
                _this.blnDisableSaveValue = false;
                _this.sortDividendTrueUpValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.saveDividendTrueUpValue = function () {
        var _this = this;
        //debugger;
        var dividendTrueUpValues = this.dividendTrueUp.slice();
        dividendTrueUpValues[this.findSelectedDividendTrueUpValueIndex()] = this.objDividendPartnerTrueUpValue;
        this.dividendTrueUp = dividendTrueUpValues;
        var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 3 && item.BusinessDate == _this.objDividendPartnerTrueUpValue.BusinessDate; });
        if (arrData) {
            this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
        }
        this.selectedDividendPartnerTrueUp = this.objDividendPartnerTrueUpValue;
        var TrueUpUpdateData = new clsUpdateData();
        TrueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.TrueUpUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        TrueUpUpdateData.BusinessDate = this.objDividendPartnerTrueUpValue.BusinessDate;
        TrueUpUpdateData.DateValue = null;
        TrueUpUpdateData.InputDataType = 3;
        TrueUpUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.objDividendPartnerTrueUpValue.DividendPartnerName; });
        TrueUpUpdateData.Value = this.objDividendPartnerTrueUpValue.Value;
        this.arrYTDUpdateData.push(TrueUpUpdateData);
        this.objDividendPartnerTrueUpValue = null;
        this.blnDisableSaveValue = false;
        this.displayDialogForDividendTrueUp = false;
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedDividendTrueUpValueIndex = function () {
        var _this = this;
        //debugger;
        var objDividendTrueUpSelected = new clsHierarchyEnterValue_DividendTrueUp();
        objDividendTrueUpSelected = this.dividendTrueUp
            .find(function (x) { return x.BusinessDate == _this.objDividendPartnerTrueUpValue.BusinessDate
            && x.DividendPartnerName == _this.objDividendPartnerTrueUpValue.DividendPartnerName; });
        //console.log(objDividendTrueUpSelected);
        return this.dividendTrueUp.indexOf(objDividendTrueUpSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.setDividendPartnerData = function (data) {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
    };
    AppTprHierarchyEnterValueComponent.prototype.onAddMVarValue = function () {
        //console.log(this.MVarValue);
        //console.log(this.dtMVarTradingDate);
        if (this.MVarValue == undefined || this.MVarValue == null || this.MVarValue.toString().length == 0) {
            alert("Value cannot be null");
        }
        else {
            var selectedMVarDate_1 = this.setDate(this.dtMVarTradingDate.toString());
            //this.arrMVarDataValues.forEach(mvarValue => console.log(mvarValue.BusinessDate));
            if (this.arrMVarDataValues.findIndex(function (MVarValue) { return MVarValue.BusinessDate == selectedMVarDate_1; }) != -1) {
                alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
            }
            else {
                var MVarSelected = new clsHierarchyEditNode_Node_InputData_Values();
                MVarSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                MVarSelected.BusinessDate = selectedMVarDate_1;
                MVarSelected.DateValue = null;
                MVarSelected.InputDataTypeEnum = 4;
                MVarSelected.InputDataType = "MVar";
                MVarSelected.Published = false;
                MVarSelected.Value = Number(this.MVarValue);
                this.arrMVarDataValues.push(MVarSelected);
                this.selectedMVarValue = MVarSelected;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 4 && item.BusinessDate != selectedMVarDate);
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 4 && item.BusinessDate == selectedMVarDate_1; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarUpdateData = new clsUpdateData();
                MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarUpdateData.BusinessDate = MVarSelected.BusinessDate;
                MVarUpdateData.InputDataType = 4;
                MVarUpdateData.DividendPartner = null;
                MVarUpdateData.Value = this.MVarValue;
                this.arrYTDUpdateData.push(MVarUpdateData);
                this.MVarValue = null;
                this.blnDisableSaveValue = false;
                this.sortMVarValues();
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForMVarValue = function (event) {
        //console.log(event);
        this.objMVarValue = this.cloneMVarValue(event.data);
        this.displayDialogForMVar = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneMVarValue = function (objForClone) {
        var MVarValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            MVarValue[prop] = objForClone[prop];
        }
        return MVarValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveMVarValue = function () {
        //debugger;
        var _this = this;
        if (!isNaN(this.objMVarValue.Value)) {
            var MVarValues = this.arrMVarDataValues.slice();
            MVarValues[this.findSelectedMVarValueIndex()] = this.objMVarValue;
            this.arrMVarDataValues = MVarValues;
            //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 4 && item.BusinessDate != this.objMVarValue.BusinessDate);
            var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 4 && item.BusinessDate == _this.objMVarValue.BusinessDate; });
            if (arrData) {
                this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
            }
            this.selectedMVarValue = this.objMVarValue;
            var MVarUpdateData = new clsUpdateData();
            MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            MVarUpdateData.BusinessDate = this.objMVarValue.BusinessDate;
            MVarUpdateData.DateValue = null;
            MVarUpdateData.InputDataType = 4;
            MVarUpdateData.DividendPartner = null;
            MVarUpdateData.Value = this.objMVarValue.Value;
            this.arrYTDUpdateData.push(MVarUpdateData);
            this.objMVarValue = null;
            this.blnDisableSaveValue = false;
            this.displayDialogForMVar = false;
        }
        else {
            alert('Input is not in a correct format');
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedMVarValueIndex = function () {
        var _this = this;
        var objMVarSelected = new clsHierarchyEditNode_Node_InputData_Values();
        objMVarSelected = this.arrMVarDataValues.find(function (x) { return x.BusinessDate == _this.objMVarValue.BusinessDate; });
        //console.log(objMVarSelected);
        return this.arrMVarDataValues.indexOf(objMVarSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.onCustomNumericValidation = function (event) {
        return (String.fromCharCode(event.charCode).match(/[0-9.]/g) != null);
    };
    AppTprHierarchyEnterValueComponent.prototype.onCustomNumericValidationMVarTempLimit = function (event) {
        return (String.fromCharCode(event.charCode).match(/[0-9]/g) != null);
    };
    AppTprHierarchyEnterValueComponent.prototype.sortMVarValues = function () {
        this.arrMVarDataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteMVarValues = function (MVarValue) {
        //console.log(MVarValue);
        var _this = this;
        this.confirmationService.confirm({
            message: 'Selected MVAR amount will be deleted. Are you sure?',
            accept: function () {
                _this.arrMVarDataValues.splice(_this.arrMVarDataValues.indexOf(MVarValue), 1);
                //debugger;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 4 && item.BusinessDate != MVarValue.BusinessDate);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 4 && item.BusinessDate == MVarValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarUpdateData = new clsUpdateData();
                MVarUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarUpdateData.BusinessDate = MVarValue.BusinessDate;
                MVarUpdateData.DateValue = null;
                MVarUpdateData.InputDataType = 4;
                MVarUpdateData.DividendPartner = null;
                MVarUpdateData.Value = null;
                _this.arrYTDUpdateData.push(MVarUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortMVarValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onAddMVarLimitValue = function () {
        //console.log(this.dtMVarLimitTradingDate);
        //console.log(this.MVarLimitValue);
        if (this.MVarLimitValue == undefined || this.MVarLimitValue == null || this.MVarLimitValue.toString().length == 0) {
            alert("Value cannot be null");
        }
        else {
            var selectedMVarLimitDate_1 = this.setDate(this.dtMVarLimitTradingDate.toString());
            if (this.arrMVarLimitDataValues.findIndex(function (MVarLimitValue) { return MVarLimitValue.BusinessDate == selectedMVarLimitDate_1; }) != -1) {
                alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
            }
            else {
                var MVarLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
                MVarLimitSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                MVarLimitSelected.BusinessDate = selectedMVarLimitDate_1;
                MVarLimitSelected.DateValue = null;
                MVarLimitSelected.InputDataTypeEnum = 5;
                MVarLimitSelected.InputDataType = "MVarLimit";
                MVarLimitSelected.Published = false;
                MVarLimitSelected.Value = Number(this.MVarLimitValue);
                this.arrMVarLimitDataValues.push(MVarLimitSelected);
                this.selectedMVarLimitValue = MVarLimitSelected;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 5 && item.BusinessDate != selectedMVarLimitDate);
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 5 && item.BusinessDate == selectedMVarLimitDate_1; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarLimitUpdateData = new clsUpdateData();
                MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarLimitUpdateData.BusinessDate = MVarLimitSelected.BusinessDate;
                MVarLimitUpdateData.DateValue = null;
                MVarLimitUpdateData.InputDataType = 5;
                MVarLimitUpdateData.DividendPartner = null;
                MVarLimitUpdateData.Value = this.MVarLimitValue;
                this.arrYTDUpdateData.push(MVarLimitUpdateData);
                this.MVarLimitValue = null;
                this.blnDisableSaveValue = false;
                this.sortMVarLimitValues();
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForMVarLimitValue = function (event) {
        //console.log(event);
        this.objMVarLimitValue = this.cloneMVarLimitValue(event.data);
        this.displayDialogForMVarLimit = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneMVarLimitValue = function (objForClone) {
        var MVarLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            MVarLimitValue[prop] = objForClone[prop];
        }
        return MVarLimitValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveMVarLimitValue = function () {
        //debugger;
        var _this = this;
        if (!isNaN(this.objMVarLimitValue.Value)) {
            var MVarLimitValues = this.arrMVarLimitDataValues.slice();
            MVarLimitValues[this.findSelectedMVarLimitValueIndex()] = this.objMVarLimitValue;
            this.arrMVarLimitDataValues = MVarLimitValues;
            //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 5 && item.BusinessDate != this.objMVarLimitValue.BusinessDate);
            var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 5 && item.BusinessDate == _this.objMVarLimitValue.BusinessDate; });
            if (arrData) {
                this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
            }
            this.selectedMVarLimitValue = this.objMVarLimitValue;
            var MVarLimitUpdateData = new clsUpdateData();
            MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            MVarLimitUpdateData.BusinessDate = this.objMVarLimitValue.BusinessDate;
            MVarLimitUpdateData.DateValue = null;
            MVarLimitUpdateData.InputDataType = 5;
            MVarLimitUpdateData.DividendPartner = null;
            MVarLimitUpdateData.Value = this.objMVarLimitValue.Value;
            this.arrYTDUpdateData.push(MVarLimitUpdateData);
            this.objMVarLimitValue = null;
            this.blnDisableSaveValue = false;
            this.displayDialogForMVarLimit = false;
        }
        else {
            alert('Input is not in a correct format');
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedMVarLimitValueIndex = function () {
        var _this = this;
        var objMVarLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
        objMVarLimitSelected = this.arrMVarLimitDataValues.find(function (x) { return x.BusinessDate == _this.objMVarLimitValue.BusinessDate; });
        //console.log(objMVarLimitSelected);
        return this.arrMVarLimitDataValues.indexOf(objMVarLimitSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteMVarLimitValues = function (MVarLimitValue) {
        //console.log(MVarLimitValue);
        var _this = this;
        this.confirmationService.confirm({
            message: 'Selected MVAR Limit will be deleted. Are you sure?',
            accept: function () {
                _this.arrMVarLimitDataValues.splice(_this.arrMVarLimitDataValues.indexOf(MVarLimitValue), 1);
                //debugger;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 5 && item.BusinessDate != MVarLimitValue.BusinessDate);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 5 && item.BusinessDate == MVarLimitValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarLimitUpdateData = new clsUpdateData();
                MVarLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarLimitUpdateData.BusinessDate = MVarLimitValue.BusinessDate;
                MVarLimitUpdateData.DateValue = null;
                MVarLimitUpdateData.InputDataType = 5;
                MVarLimitUpdateData.DividendPartner = null;
                MVarLimitUpdateData.Value = null;
                _this.arrYTDUpdateData.push(MVarLimitUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortMVarLimitValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.sortMVarLimitValues = function () {
        this.arrMVarLimitDataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.setMVarTempLimitExpiryDate = function () {
        //debugger;
        var MVarTempLimitTradingDate = this.dtMVarTempLimitTradingDate;
        localStorage.setItem("MVarTempLimitTradingDate", MVarTempLimitTradingDate.toString());
        var selectedTradingDate = localStorage.getItem("MVarTempLimitTradingDate");
        var dayNumber = new Date(selectedTradingDate).getDay();
        this.dtMVarTempLimitExpiryDate = new Date(selectedTradingDate);
        // Monday = 1
        // Tuesday = 2
        // Wednesday = 3
        // Thursday = 4
        // Friday = 5
        // Saturday = 6
        // Sunday = 7      
        if (dayNumber < 5 || dayNumber == 7) {
            this.dtMVarTempLimitExpiryDate.setDate(this.dtMVarTempLimitExpiryDate.getDate() + 1);
        }
        else if (dayNumber == 5) {
            this.dtMVarTempLimitExpiryDate.setDate(this.dtMVarTempLimitExpiryDate.getDate() + 3);
        }
        else if (dayNumber == 6) {
            this.dtMVarTempLimitExpiryDate.setDate(this.dtMVarTempLimitExpiryDate.getDate() + 2);
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onSelectMVarTempLimitTradingDate = function (value) {
        this.setMVarTempLimitExpiryDate();
    };
    AppTprHierarchyEnterValueComponent.prototype.onMVarTempLimitValueKeyUp = function (event) {
        //debugger;
        if (this.MVarTempLimitValue && this.MVarTempLimitValue.toString().length > 0) {
            this.blnDisableMVarTempLimitExpiryDate = false;
        }
        else {
            this.blnDisableMVarTempLimitExpiryDate = true;
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickMVarTempLimitAdd = function () {
        // console.log(this.dtMVarTempLimitTradingDate);
        // console.log(this.MVarTempLimitValue);
        // console.log(this.dtMVarTempLimitExpiryDate);
        var _this = this;
        if (this.MVarTempLimitValue == undefined || this.MVarTempLimitValue == null || this.MVarTempLimitValue.toString().length == 0) {
            alert("Value cannot be null");
        }
        else {
            var selectedMVarTempLimitDate_1 = this.setDate(this.dtMVarTempLimitTradingDate.toString());
            var selectedMVarTempLimitExpiryDate = this.setDate(this.dtMVarTempLimitExpiryDate.toString());
            if (this.arrMVarTempLimitDataValues.findIndex(function (MVarTempLimitValue) { return MVarTempLimitValue.BusinessDate == selectedMVarTempLimitDate_1; }) != -1) {
                alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
            }
            else {
                var MVarTempLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
                MVarTempLimitSelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                MVarTempLimitSelected.BusinessDate = selectedMVarTempLimitDate_1;
                MVarTempLimitSelected.DateValue = selectedMVarTempLimitExpiryDate;
                MVarTempLimitSelected.InputDataTypeEnum = 8;
                MVarTempLimitSelected.InputDataType = "MVarTemporaryLimit";
                MVarTempLimitSelected.Published = false;
                MVarTempLimitSelected.Value = Number(this.MVarTempLimitValue);
                this.arrMVarTempLimitDataValues.push(MVarTempLimitSelected);
                this.selectedMVarTempLimitValue = MVarTempLimitSelected;
                //debugger;
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 8 && item.BusinessDate == _this.objMVarTempLimitValue.BusinessDate; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarTempLimitUpdateData = new clsUpdateData();
                MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarTempLimitUpdateData.BusinessDate = MVarTempLimitSelected.BusinessDate;
                MVarTempLimitUpdateData.DateValue = MVarTempLimitSelected.DateValue;
                MVarTempLimitUpdateData.InputDataType = 8;
                MVarTempLimitUpdateData.DividendPartner = null;
                MVarTempLimitUpdateData.Value = this.MVarTempLimitValue;
                this.arrYTDUpdateData.push(MVarTempLimitUpdateData);
                this.MVarLimitValue = null;
                this.blnDisableSaveValue = false;
                this.sortMVarTempLimitValues();
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.sortMVarTempLimitValues = function () {
        this.arrMVarTempLimitDataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForMVarTempLimitValue = function (event) {
        //console.log(event);
        //debugger;
        this.objMVarTempLimitValue = this.cloneMVarTempLimitValue(event.data);
        this.displayDialogForMVarTempLimit = true;
        this.minimumSelectableDate = new Date(this.objMVarTempLimitValue.BusinessDate);
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneMVarTempLimitValue = function (objForClone) {
        var MVarTempLimitValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            MVarTempLimitValue[prop] = objForClone[prop];
        }
        return MVarTempLimitValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveMVarTempLimitValue = function () {
        var _this = this;
        var MVarTempLimitValues = this.arrMVarTempLimitDataValues.slice();
        MVarTempLimitValues[this.findSelectedMVarTempLimitValueIndex()] = this.objMVarTempLimitValue;
        this.arrMVarTempLimitDataValues = MVarTempLimitValues;
        //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 8 && (item.BusinessDate != this.objMVarTempLimitValue.BusinessDate && item.DateValue != this.objMVarTempLimitValue.DateValue));
        //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType != 8 && item.BusinessDate == this.objMVarTempLimitValue.BusinessDate);
        var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 8 && item.BusinessDate == _this.objMVarTempLimitValue.BusinessDate; });
        if (arrData) {
            this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
        }
        this.selectedMVarTempLimitValue = this.objMVarTempLimitValue;
        var MVarTempLimitUpdateData = new clsUpdateData();
        MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        MVarTempLimitUpdateData.BusinessDate = this.objMVarTempLimitValue.BusinessDate;
        MVarTempLimitUpdateData.DateValue = this.objMVarTempLimitValue.DateValue;
        MVarTempLimitUpdateData.InputDataType = 8;
        MVarTempLimitUpdateData.DividendPartner = null;
        MVarTempLimitUpdateData.Value = this.objMVarTempLimitValue.Value;
        this.arrYTDUpdateData.push(MVarTempLimitUpdateData);
        this.objMVarTempLimitValue = null;
        this.blnDisableSaveValue = false;
        this.displayDialogForMVarTempLimit = false;
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedMVarTempLimitValueIndex = function () {
        var _this = this;
        var objMVarTempLimitSelected = new clsHierarchyEditNode_Node_InputData_Values();
        objMVarTempLimitSelected = this.arrMVarTempLimitDataValues.find(function (x) { return x.BusinessDate == _this.objMVarTempLimitValue.BusinessDate; });
        //console.log(objMVarTempLimitSelected);
        return this.arrMVarTempLimitDataValues.indexOf(objMVarTempLimitSelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteMVarTempLimitValues = function (MVarTempLimitValue) {
        //console.log(MVarTempLimitValue);
        var _this = this;
        this.confirmationService.confirm({
            message: 'Selected MVAR Temporary Limit will be deleted. Are you sure?',
            accept: function () {
                _this.arrMVarTempLimitDataValues.splice(_this.arrMVarTempLimitDataValues.indexOf(MVarTempLimitValue), 1);
                //debugger;
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType == 8 && (item.BusinessDate != MVarTempLimitValue.BusinessDate && item.DateValue != MVarTempLimitValue.DateValue));
                //this.arrYTDUpdateData = this.arrYTDUpdateData.filter(item => item.InputDataType != 8 && item.BusinessDate != MVarTempLimitValue.BusinessDate);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 8 && item.BusinessDate == MVarTempLimitValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var MVarTempLimitUpdateData = new clsUpdateData();
                MVarTempLimitUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.YTDUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                MVarTempLimitUpdateData.BusinessDate = MVarTempLimitValue.BusinessDate;
                MVarTempLimitUpdateData.DateValue = MVarTempLimitValue.DateValue;
                MVarTempLimitUpdateData.InputDataType = 8;
                MVarTempLimitUpdateData.DividendPartner = null;
                MVarTempLimitUpdateData.Value = null;
                _this.arrYTDUpdateData.push(MVarTempLimitUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortMVarTempLimitValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickPnlPPAAdd = function () {
        // debugger;
        // console.log(this.PnlPPARestatedMEYTDValue);
        // console.log(this.strPnlPPAMonthEndDate);
        // console.log(this.dtPnlPPATradingDate);
        if (this.PnlPPARestatedMEYTDValue == undefined || this.PnlPPARestatedMEYTDValue == null || this.PnlPPARestatedMEYTDValue.toString().length == 0) {
            alert("Value cannot be null");
        }
        else {
            var selectedPnlPPADate_1 = this.setDate(this.dtPnlPPATradingDate.toString());
            var selectedPnlPPAMonthEndDate = this.strPnlPPAMonthEndDate ? this.setDate(this.strPnlPPAMonthEndDate) : "";
            if (this.arrPnlPPADataValues.findIndex(function (pnlPPAValue) { return pnlPPAValue.BusinessDate == selectedPnlPPADate_1; }) != -1) {
                alert("The value for selected trading date and type already exists.\n\nYou can modify the amount in the table below or delete the existing record and enter a new value.");
            }
            else {
                var PnlPPASelected = new clsHierarchyEditNode_Node_InputData_Values();
                PnlPPASelected.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO, Version=16.1.1.200, Culture=neutral, PublicKeyToken=null";
                PnlPPASelected.BusinessDate = selectedPnlPPADate_1;
                PnlPPASelected.DateValue = selectedPnlPPAMonthEndDate;
                PnlPPASelected.InputDataTypeEnum = 9;
                PnlPPASelected.InputDataType = "Prior Period Adjustment";
                PnlPPASelected.Published = false;
                PnlPPASelected.Value = Number(this.PnlPPARestatedMEYTDValue);
                this.arrPnlPPADataValues.push(PnlPPASelected);
                this.selectedPnlPPAValue = PnlPPASelected;
                var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 && item.BusinessDate == selectedPnlPPADate_1; });
                if (arrData) {
                    this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var PnlPPAUpdateData = new clsUpdateData();
                PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                PnlPPAUpdateData.BusinessDate = PnlPPASelected.BusinessDate;
                PnlPPAUpdateData.DateValue = PnlPPASelected.DateValue;
                PnlPPAUpdateData.InputDataType = 9;
                PnlPPAUpdateData.DividendPartner = null;
                PnlPPAUpdateData.Value = this.PnlPPARestatedMEYTDValue;
                this.arrYTDUpdateData.push(PnlPPAUpdateData);
                this.PnlPPARestatedMEYTDValue = null;
                this.blnDisableSaveValue = false;
                this.sortPnlPPAValues();
            }
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickPnlPPAClear = function () {
        this.PnlPPARestatedMEYTDValue = null;
    };
    AppTprHierarchyEnterValueComponent.prototype.sortPnlPPAValues = function () {
        this.arrPnlPPADataValues.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForPnlPPAValue = function (event) {
        //console.log(event);
        this.objPnlPPAValue = this.clonePnlPPAValue(event.data);
        this.displayDialogForPnlPPA = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.clonePnlPPAValue = function (objForClone) {
        var PnlPPAValue = new clsHierarchyEditNode_Node_InputData_Values();
        for (var prop in objForClone) {
            PnlPPAValue[prop] = objForClone[prop];
        }
        return PnlPPAValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.savePnlPPAValue = function () {
        var _this = this;
        var PnlPPAValues = this.arrPnlPPADataValues.slice();
        PnlPPAValues[this.findSelectedPnlPPAValueIndex()] = this.objPnlPPAValue;
        this.arrPnlPPADataValues = PnlPPAValues;
        var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 && item.BusinessDate == _this.objPnlPPAValue.BusinessDate; });
        if (arrData) {
            this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
        }
        this.selectedPnlPPAValue = this.objPnlPPAValue;
        var PnlPPAUpdateData = new clsUpdateData();
        PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        PnlPPAUpdateData.BusinessDate = this.objPnlPPAValue.BusinessDate;
        PnlPPAUpdateData.DateValue = this.objPnlPPAValue.DateValue;
        PnlPPAUpdateData.InputDataType = 9;
        PnlPPAUpdateData.DividendPartner = null;
        PnlPPAUpdateData.Value = this.objPnlPPAValue.Value;
        this.arrYTDUpdateData.push(PnlPPAUpdateData);
        this.objPnlPPAValue = null;
        this.blnDisableSaveValue = false;
        this.displayDialogForPnlPPA = false;
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedPnlPPAValueIndex = function () {
        var _this = this;
        var objPnlPPASelected = new clsHierarchyEditNode_Node_InputData_Values();
        objPnlPPASelected = this.arrPnlPPADataValues.find(function (x) { return x.BusinessDate == _this.objPnlPPAValue.BusinessDate; });
        //console.log(objPnlPPASelected);
        return this.arrPnlPPADataValues.indexOf(objPnlPPASelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deletePnlPPAValues = function (PnlPPAValue) {
        //console.log(PnlPPAValue);
        var _this = this;
        this.confirmationService.confirm({
            message: 'Selected restated month end amount will be deleted. Are you sure?',
            accept: function () {
                _this.arrPnlPPADataValues.splice(_this.arrPnlPPADataValues.indexOf(PnlPPAValue), 1);
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 && item.BusinessDate == PnlPPAValue.BusinessDate; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var PnlPPAUpdateData = new clsUpdateData();
                PnlPPAUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                PnlPPAUpdateData.BusinessDate = PnlPPAValue.BusinessDate;
                PnlPPAUpdateData.DateValue = PnlPPAValue.DateValue;
                PnlPPAUpdateData.InputDataType = 9;
                PnlPPAUpdateData.DividendPartner = null;
                PnlPPAUpdateData.Value = null;
                _this.arrYTDUpdateData.push(PnlPPAUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortPnlPPAValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onDividendPartnerPPAChange = function () {
        var _this = this;
        var intPercentageValue = 0;
        var selectedDividendAllocation = new clsHierarchyEditNode_DividendPartnerAllocations_Values();
        var selectedPPATradingDate = this.setDate(this.dtTradingDateDividendPartnerPPA.toString());
        if (this.dividendPPA.findIndex(function (ppa) { return ppa.BusinessDate == selectedPPATradingDate
            && ppa.DividendPartnerName == _this.strSelectedDividendPartnerPPAName; }) != -1) {
            this.blnEnableDividendPPA = true;
        }
        else {
            if (this.strSelectedDividendPartnerPPAName && this.strSelectedDividendPartnerPPAName.toString() != "NotSet") {
                selectedDividendAllocation = this.enterValueCompleteData.DividendPartnerAllocations.$values.find(function (dividendAllocation) { return dividendAllocation.DividendPartnerNode.Name == _this.strSelectedDividendPartnerPPAName; });
                intPercentageValue = selectedDividendAllocation ? selectedDividendAllocation.Percentage : 0;
                this.blnEnableDividendPPA = false;
            }
            else {
                intPercentageValue = 0;
                this.blnEnableDividendPPA = true;
            }
        }
        this.strSelectedDividendPartnerPPAPercentage = intPercentageValue.toString();
    };
    AppTprHierarchyEnterValueComponent.prototype.sortDividendPPAValues = function () {
        this.dividendPPA.sort(function (n1, n2) {
            if (n1.BusinessDate > n2.BusinessDate) {
                return 1;
            }
            if (n1.BusinessDate < n2.BusinessDate) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendPPAAdd = function () {
        var _this = this;
        if (this.DividendPPARestatedMEValue == undefined || this.DividendPPARestatedMEValue == null || this.DividendPPARestatedMEValue.toString().length == 0) {
            alert("Value cannot be null");
        }
        else {
            var selectedPPATradingDate_1 = this.setDate(this.dtTradingDateDividendPartnerPPA.toString());
            var ppaSelected_1 = new clsHierarchyEnterValue_DividendPPA();
            ppaSelected_1.BusinessDate = selectedPPATradingDate_1;
            ppaSelected_1.DividendPartnerName = this.strSelectedDividendPartnerPPAName;
            ppaSelected_1.RestatedMEDate = this.strDividendPPAMonthEndDate;
            ppaSelected_1.RestatedMEYTD = this.DividendPPARestatedMEValue;
            this.dividendPPA.push(ppaSelected_1);
            this.selectedDividendPartnerPPA = ppaSelected_1;
            this.strSelectedDividendPartnerPPAName = "NotSet";
            this.DividendPPARestatedMEValue = null;
            var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9 &&
                item.BusinessDate == selectedPPATradingDate_1 && item.DividendPartner.Name == _this.strSelectedDividendPartnerPPAName; });
            if (arrData) {
                this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
            }
            var ppaUpdateData = new clsUpdateData();
            ppaUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            ppaUpdateData.BusinessDate = ppaSelected_1.BusinessDate;
            ppaUpdateData.DateValue = ppaSelected_1.RestatedMEDate;
            ppaUpdateData.InputDataType = 9;
            ppaUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == ppaSelected_1.DividendPartnerName; });
            ppaUpdateData.Value = ppaSelected_1.RestatedMEYTD;
            this.arrYTDUpdateData.push(ppaUpdateData);
            this.blnDisableSaveValue = false;
            this.blnEnableDividendPPA = true;
            this.sortDividendPPAValues();
        }
    };
    AppTprHierarchyEnterValueComponent.prototype.onClickDividendPPAClear = function () {
        this.strSelectedDividendPartnerPPAName = "NotSet";
        this.DividendPPARestatedMEValue = null;
    };
    AppTprHierarchyEnterValueComponent.prototype.onRowSelectForDividendPPAValue = function (event) {
        //console.log(event);
        this.objDividendPartnerPPAValue = this.cloneDividendPPAValue(event.data);
        this.displayDialogForDividendPPA = true;
    };
    AppTprHierarchyEnterValueComponent.prototype.cloneDividendPPAValue = function (objForClone) {
        var dividendPPAValue = new clsHierarchyEnterValue_DividendPPA();
        for (var prop in objForClone) {
            dividendPPAValue[prop] = objForClone[prop];
        }
        return dividendPPAValue;
    };
    AppTprHierarchyEnterValueComponent.prototype.saveDividendPPAValue = function () {
        var _this = this;
        //debugger;
        var dividendPPAValues = this.dividendPPA.slice();
        dividendPPAValues[this.findSelectedDividendPPAValueIndex()] = this.objDividendPartnerPPAValue;
        this.dividendPPA = dividendPPAValues;
        var arrData = this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9
            && item.BusinessDate == _this.objDividendPartnerPPAValue.BusinessDate && item.DividendPartner.Name == _this.strSelectedDividendPartnerPPAName; });
        if (arrData) {
            this.arrYTDUpdateData.splice(this.arrYTDUpdateData.indexOf(arrData), 1);
        }
        this.selectedDividendPartnerPPA = this.objDividendPartnerPPAValue;
        var ppaUpdateData = new clsUpdateData();
        ppaUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        ppaUpdateData.DividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.objDividendPartnerPPAValue.DividendPartnerName; });
        ppaUpdateData.InputDataType = 9;
        ppaUpdateData.BusinessDate = this.objDividendPartnerPPAValue.BusinessDate;
        ppaUpdateData.DateValue = this.objDividendPartnerPPAValue.RestatedMEDate;
        ppaUpdateData.Value = this.objDividendPartnerPPAValue.RestatedMEYTD;
        this.arrYTDUpdateData.push(ppaUpdateData);
        this.objDividendPartnerPPAValue = null;
        this.blnDisableSaveValue = false;
        this.displayDialogForDividendPPA = false;
    };
    AppTprHierarchyEnterValueComponent.prototype.findSelectedDividendPPAValueIndex = function () {
        var _this = this;
        //debugger;
        var objDividendPPASelected = new clsHierarchyEnterValue_DividendPPA();
        objDividendPPASelected = this.dividendPPA
            .find(function (x) { return x.BusinessDate == _this.objDividendPartnerPPAValue.BusinessDate
            && x.DividendPartnerName == _this.objDividendPartnerPPAValue.DividendPartnerName; });
        //console.log(objDividendPPASelected);
        return this.dividendPPA.indexOf(objDividendPPASelected);
    };
    AppTprHierarchyEnterValueComponent.prototype.deleteDividendPartnerPPA = function (dividendPPARowValue) {
        //console.log(dividendPPARowValue);
        var _this = this;
        this.confirmationService.confirm({
            message: 'Selected restated month end amount will be deleted. Are you sure?',
            accept: function () {
                _this.dividendPPA.splice(_this.dividendPPA.indexOf(dividendPPARowValue), 1);
                _this.objDividendPartnerPPAValue = null;
                var arrData = _this.arrYTDUpdateData.find(function (item) { return item.InputDataType == 9
                    && item.BusinessDate == dividendPPARowValue.BusinessDate && item.DividendPartner.Name == dividendPPARowValue.DividendPartnerName; });
                if (arrData) {
                    _this.arrYTDUpdateData.splice(_this.arrYTDUpdateData.indexOf(arrData), 1);
                }
                var trueUpUpdateData = new clsUpdateData();
                trueUpUpdateData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.PpaUpdateDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                trueUpUpdateData.BusinessDate = dividendPPARowValue.BusinessDate;
                trueUpUpdateData.DateValue = dividendPPARowValue.RestatedMEDate;
                trueUpUpdateData.InputDataType = 9;
                trueUpUpdateData.DividendPartner = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendPPARowValue.DividendPartnerName; });
                trueUpUpdateData.Value = null;
                _this.arrYTDUpdateData.push(trueUpUpdateData);
                _this.blnDisableSaveValue = false;
                _this.sortDividendPPAValues();
            }
        });
    };
    AppTprHierarchyEnterValueComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/treeView/app.treeViewEnterValue.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRHierarchyservice_1.TPRHierarchyservice, router_1.Router, router_1.ActivatedRoute, app_TPRNodeTypeService_1.TPRNodeTypeService, primeng_1.ConfirmationService, app_regionService_1.RegionsService, app_TPRProfitAlertGroupsService_1.TPRProfitAlertGroupsService, app_TPRTagsService_1.TPRTagsService, app_TPRDividendPartnersService_1.TPRDividendPartnersService, app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService])
    ], AppTprHierarchyEnterValueComponent);
    return AppTprHierarchyEnterValueComponent;
}());
exports.AppTprHierarchyEnterValueComponent = AppTprHierarchyEnterValueComponent;
var clsHierarchyEditNode_Node_InputData_Values = (function () {
    function clsHierarchyEditNode_Node_InputData_Values($type, Value, DateValue, BusinessDate, InputDataType, Published, InputDataTypeEnum, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Value === void 0) { Value = 0; }
        if (DateValue === void 0) { DateValue = null; }
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (InputDataType === void 0) { InputDataType = null; }
        if (Published === void 0) { Published = false; }
        if (InputDataTypeEnum === void 0) { InputDataTypeEnum = 1; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Value = Value;
        this.DateValue = DateValue;
        this.BusinessDate = BusinessDate;
        this.InputDataType = InputDataType;
        this.Published = Published;
        this.InputDataTypeEnum = InputDataTypeEnum;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node_InputData_Values;
}());
exports.clsHierarchyEditNode_Node_InputData_Values = clsHierarchyEditNode_Node_InputData_Values;
var clsUpdateData = (function () {
    function clsUpdateData() {
    }
    return clsUpdateData;
}());
exports.clsUpdateData = clsUpdateData;
var clsHierarchyNodeEnterValuePostData = (function () {
    function clsHierarchyNodeEnterValuePostData($type, Node, HierarchyType, UpdateData) {
        if ($type === void 0) { $type = null; }
        if (Node === void 0) { Node = null; }
        if (HierarchyType === void 0) { HierarchyType = null; }
        if (UpdateData === void 0) { UpdateData = []; }
        this.$type = $type;
        this.Node = Node;
        this.HierarchyType = HierarchyType;
        this.UpdateData = UpdateData;
    }
    return clsHierarchyNodeEnterValuePostData;
}());
exports.clsHierarchyNodeEnterValuePostData = clsHierarchyNodeEnterValuePostData;
var clsHierarchyNodeEnterValuePostData_UpdateData = (function () {
    function clsHierarchyNodeEnterValuePostData_UpdateData($type, DividendPartner, InputDataType, BusinessDate, Value, DateValue) {
        if ($type === void 0) { $type = null; }
        if (DividendPartner === void 0) { DividendPartner = null; }
        if (InputDataType === void 0) { InputDataType = 0; }
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (Value === void 0) { Value = 0; }
        if (DateValue === void 0) { DateValue = null; }
        this.$type = $type;
        this.DividendPartner = DividendPartner;
        this.InputDataType = InputDataType;
        this.BusinessDate = BusinessDate;
        this.Value = Value;
        this.DateValue = DateValue;
    }
    return clsHierarchyNodeEnterValuePostData_UpdateData;
}());
exports.clsHierarchyNodeEnterValuePostData_UpdateData = clsHierarchyNodeEnterValuePostData_UpdateData;
var clsHierarchyEnterValue_DividendTrueUp = (function () {
    function clsHierarchyEnterValue_DividendTrueUp(BusinessDate, DateValue, InputDataType, DividendPartnerName, Value, TrueUp, Updated, UpdatedBy) {
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (DateValue === void 0) { DateValue = null; }
        if (InputDataType === void 0) { InputDataType = null; }
        if (DividendPartnerName === void 0) { DividendPartnerName = null; }
        if (Value === void 0) { Value = 0; }
        if (TrueUp === void 0) { TrueUp = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        this.BusinessDate = BusinessDate;
        this.DateValue = DateValue;
        this.InputDataType = InputDataType;
        this.DividendPartnerName = DividendPartnerName;
        this.Value = Value;
        this.TrueUp = TrueUp;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
    }
    return clsHierarchyEnterValue_DividendTrueUp;
}());
exports.clsHierarchyEnterValue_DividendTrueUp = clsHierarchyEnterValue_DividendTrueUp;
var clsHierarchyEditNode_DividendPartnerAllocations_Values = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values;
}());
exports.clsHierarchyEditNode_DividendPartnerAllocations_Values = clsHierarchyEditNode_DividendPartnerAllocations_Values;
var clsHierarchyEnterValue_DividendPPA = (function () {
    function clsHierarchyEnterValue_DividendPPA(BusinessDate, DividendPartnerName, RestatedMEDate, RestatedMEYTD, CalculatedPPA, Updated, UpdatedBy) {
        if (BusinessDate === void 0) { BusinessDate = null; }
        if (DividendPartnerName === void 0) { DividendPartnerName = null; }
        if (RestatedMEDate === void 0) { RestatedMEDate = null; }
        if (RestatedMEYTD === void 0) { RestatedMEYTD = 0; }
        if (CalculatedPPA === void 0) { CalculatedPPA = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        this.BusinessDate = BusinessDate;
        this.DividendPartnerName = DividendPartnerName;
        this.RestatedMEDate = RestatedMEDate;
        this.RestatedMEYTD = RestatedMEYTD;
        this.CalculatedPPA = CalculatedPPA;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
    }
    return clsHierarchyEnterValue_DividendPPA;
}());
exports.clsHierarchyEnterValue_DividendPPA = clsHierarchyEnterValue_DividendPPA;
//# sourceMappingURL=app.treeViewEnterValue.component.js.map