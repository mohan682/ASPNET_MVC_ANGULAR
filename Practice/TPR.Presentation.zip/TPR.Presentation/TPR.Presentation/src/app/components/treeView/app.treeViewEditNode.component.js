"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
require('rxjs/add/operator/switchMap');
var primeng_1 = require('primeng/primeng');
var app_TPRHierarchyservice_1 = require('../../service/app.TPRHierarchyservice');
var app_TPRNodeTypeService_1 = require('../../service/app.TPRNodeTypeService');
var app_regionService_1 = require('../../service/app.regionService');
var app_TPRProfitAlertGroupsService_1 = require('../../service/app.TPRProfitAlertGroupsService');
var app_TPRTagsService_1 = require('../../service/app.TPRTagsService');
var app_TPRDividendPartnersService_1 = require('../../service/app.TPRDividendPartnersService');
var app_TPRBusinessSegmentsService_1 = require('../../service/app.TPRBusinessSegmentsService');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var AppTprHierarchyEditNodeComponent = (function () {
    function AppTprHierarchyEditNodeComponent(tPRHierarchyservice, router, route, tPRNodeTypeService, confirmationService, regionsService, tprPAGService, tPRTagsService, tprDividendPartnersService, tprBusinessSegmentsService, tprCommonService) {
        this.tPRHierarchyservice = tPRHierarchyservice;
        this.router = router;
        this.route = route;
        this.tPRNodeTypeService = tPRNodeTypeService;
        this.confirmationService = confirmationService;
        this.regionsService = regionsService;
        this.tprPAGService = tprPAGService;
        this.tPRTagsService = tPRTagsService;
        this.tprDividendPartnersService = tprDividendPartnersService;
        this.tprBusinessSegmentsService = tprBusinessSegmentsService;
        this.tprCommonService = tprCommonService;
        this.blnShowModalPouUp = true;
        this.blnNodePropertiesShow = true;
        this.blnMappingNamesShow = false;
        this.blnRegionAllocationShow = false;
        this.blnTagAllocationShow = false;
        this.blnDividendAllocationShow = false;
        this.blnPnLPlanShow = false;
        this.blnPlanForDividendPartnersShow = false;
        this.blnMVARShow = false;
        this.blnProfitAlertGroupShow = false;
        this.blnWorkingCapitalShow = false;
        this.editChildMenuItems = [];
        this.businessDate = '';
        this.nodeTypes = [];
        this.nodes = [];
        this.updateTimings = [];
        this.blndisableSelectedUpdateTimingField = false;
        this.blnEnableregionAllocation = true;
        this.selectedNode = new RootValue();
        this.mainListOfTree = [];
        this.nodeArrays = [];
        this.blnPnlHolderDisabled = false;
        this.ytdValues = [];
        this.mappingName = new clsHierarchyEditNode_Node_InputNameMappings_Value();
        this.mappingNames = [];
        this.mappingNamecols = [];
        this.clsHierarchyEditNode_WorkingCapital = new clsHierarchyEditNode_WorkingCapital();
        this.regions = [];
        this.regionNames = [];
        this.blnWorkingCapitalRegion = false;
        this.profitAlertGroupsValuesMasterData = [];
        this.profitAlertGroupsValues = [];
        this.profitAlertGroupNames = [];
        this.profitAlertGroupArrays = [];
        this.profitAlertGroup = new clsHierarchyEditNode_AlertGroups_Values();
        this.profitAlertGroupcols = [];
        this.blnMVarHolder = false;
        this.blnMVarHolderDisabled = false;
        this.blnMVarUpdateTiming = false;
        this.MVarUpdateTimings = [];
        this.regionNamesMVar = [];
        this.tagTypes = [];
        this.tags = [];
        this.tagNames = [];
        this.tag = new clsHierarchyEditNode_Tags_Values();
        this.nodeDataForPostToServer = new clsHierarchyNodePostData();
        this.nodeAlertGroups = new clsHierarchyNodePostData_Alerts();
        this.regionAllocations = [];
        this.regionNamesRegionAllocation = [];
        this.strSelectedSplitType = "DM";
        this.strRegionAllocationPercentage = "0";
        this.strRegionAllocationValueCheck = "";
        this.clsRegionAllocationValueCheck = {};
        this.dividendPartnerTypes = [];
        this.businessSegments = [];
        this.dividendPartnerAllocations = [];
        this.dividendPartnerNames = [];
        this.strDividendAllocationPercentage = "0";
        this.strDividendAllocationValueCheck = "";
        this.clsDividendAllocationValueCheck = {};
        this.regionNamesPlanRegionAllocation = [];
        this.pnlPlans = [];
        this.pnlPlansArray = [];
        this.selectedPnlPlan = new clsPlanDataPerRegion();
        this.pnlPlanYears = [];
        this.completePnlPlanYearToMonthPerRegion = [];
        this.filteredPnlPlanYearToMonthPerRegion = [];
        this.filteredPnLPlanPerRegion = [];
        this.dividendPartnerNamesDividendPlanAllocation = [];
        this.regionNamesDividendPlanAllocation = [];
        this.dividendPlanYears = [];
        this.dividendPlans = [];
        this.dividendPlansArray = [];
        this.selectedDividendPlan = new clsPlanDataPerDividendPartner();
        this.completeDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanPerDividendPartnerAndRegion = [];
        this.cols = [];
        this.blnDisableControlsTillSaveCompletes = false;
        this.blnShowConfirmDialog = false;
        this.blnShowValidationDialog = false;
        this.strValidationHeader = "";
        this.strValidationMessage = "";
    }
    AppTprHierarchyEditNodeComponent.prototype.ngOnInit = function () {
        //debugger;
        var _this = this;
        // To get the selected node ID from the route service
        this.route.params.subscribe(function (params) {
            _this.intSelectedNodeID = +params['nodeId'];
        });
        this.businessDate = localStorage.getItem("BusinessDate");
        // call the service to fetch the node related data
        this.tPRHierarchyservice.getNodeLevelDataForEdit(this.intSelectedNodeID, this.businessDate)
            .subscribe(function (data) {
            _this.editNodeCompleteData = data.Result;
            _this.editNodeCompleteData.Node.Updated = _this.editNodeCompleteData ? _this.tprCommonService.getFormattedSystemDate(new Date(_this.editNodeCompleteData.Node.Updated)) : "";
            console.log("editNodeCompleteData ->,", _this.editNodeCompleteData);
            _this.editChildMenuItems = [
                { label: 'Node Properties', icon: 'fa fa-table', command: function (event) { return _this.EditNodeProperties(); } },
                { label: 'Mapping Names', icon: 'fa fa-table', command: function (event) { return _this.EditMappingNames(); } },
                { label: 'Region Allocation', icon: 'fa fa-table', command: function (event) { return _this.EditRegionAllocation(); }, disabled: !_this.editNodeCompleteData.Node.IsPnlHolder },
                { label: 'Tag Allocation', icon: 'fa fa-table', command: function (event) { return _this.EditTagAllocation(); } },
                { label: 'Dividend Allocation', icon: 'fa fa-table', command: function (event) { return _this.EditDividendAllocation(); }, disabled: (!_this.editNodeCompleteData.Node.IsPnlHolder || _this.editNodeCompleteData.RegionalAllocations.$values.length <= 0) },
                { label: 'Pnl Plan', icon: 'fa fa-table', command: function (event) { return _this.EditPnLPlan(); }, disabled: !_this.editNodeCompleteData.Node.IsPnlHolder && !_this.editNodeCompleteData.UpdateTiming },
                { label: 'Plan For Dividend Partners', icon: 'fa fa-table', command: function (event) { return _this.EditPlanForDividendPartners(); }, disabled: !_this.editNodeCompleteData.Node.IsPnlHolder && !_this.editNodeCompleteData.UpdateTiming },
                { label: 'MVAR', icon: 'fa fa-table', command: function (event) { return _this.EditMVAR(); } },
                { label: 'Profit Alert Groups', icon: 'fa fa-table', command: function (event) { return _this.EditProfitAlertGroups(); } },
                { label: 'Working Capital', icon: 'fa fa-table', command: function (event) { return _this.EditWorkingCapital(); } },
            ];
            // get the hierarchy data
            _this.getHierarchyData();
            if (_this.editNodeCompleteData.WorkingCapitalRegion) {
                _this.blnWorkingCapitalRegion = true;
            }
            // disabling IsPnlHolder
            _this.ytdValues = _this.editNodeCompleteData ? _this.editNodeCompleteData.Node.InputData.$values.filter(function (ytdValues) { return ytdValues.InputDataType == "YTD"; }) : [];
            _this.blnPnlHolderDisabled = _this.ytdValues.length > 0 ? true : false;
            //split type
            _this.strSelectedSplitType = _this.editNodeCompleteData.SplitType ? _this.editNodeCompleteData.SplitType : _this.strSelectedSplitType;
            // to set the region allocation value;
            var totalRegionAllocation = 0;
            _this.editNodeCompleteData.RegionalAllocations.$values.forEach(function (regionAllocation) {
                totalRegionAllocation += regionAllocation.Percentage;
            });
            _this.strRegionAllocationValueCheck = totalRegionAllocation.toString();
            // to set the dividend partner allocation value;
            var totalDividendPartnerAllocation = 0;
            _this.editNodeCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendPartnerAllocation) {
                totalDividendPartnerAllocation += dividendPartnerAllocation.Percentage;
            });
            _this.strDividendAllocationValueCheck = totalDividendPartnerAllocation.toString();
            // set initial pnlPlan for Region
            _this.setPnlPlanForRegion();
            // set initial dividendPlan for DividendPartner
            _this.setDividendPlanForDividendPartner();
        });
        //get the node master data
        this.tPRNodeTypeService.getNodeTypesObservable()
            .subscribe(function (data) { return _this.setNodeTypeData(data); });
        //get the region master data
        //get the regions data
        this.regionsService.getRegionsObservable()
            .subscribe(function (data) {
            _this.setRegionsData(data);
            _this.setRegionsDataForMVar(data);
            _this.setRegionsDataForRegionAllocation(data);
            _this.setRegionsDataForPlanRegionAllocation(data);
            _this.setRegionsDataForDividendPlanRegionAllocation(data);
        });
        // to get the Dividend partners data
        this.tprDividendPartnersService.getDividendPartnersObservable()
            .subscribe(function (data) {
            _this.setDividendPartnerData(data);
            _this.setDividendPartnerDataForDividendPlanAllocation(data);
        });
        // to get the business segments data
        this.tprBusinessSegmentsService.getBusinessSegmentsObservable()
            .subscribe(function (data) { return _this.setBusinessSegmentsData(data); });
        //get the profit Alert group master data
        this.tprPAGService.getProfitAlertGroupsObservable()
            .subscribe(function (data) { return _this.setProfitAlertGroupDate(data); });
        // to set the update timing template field.
        this.updateTimings = [
            { label: "Not Set", value: null },
            { label: "R-1", value: "-1" },
            { label: "R-2", value: "-2" }
        ];
        // to set the MVarupdate timing field.
        this.MVarUpdateTimings = [
            { label: "R-1", value: "-1" },
            { label: "R-2", value: "-2" }
        ];
        // to get the list of tags
        this.tPRTagsService.getTagsObservable()
            .subscribe(function (data) {
            _this.setTagTypeData(data);
        });
        this.setPlanYears();
        this.setDividendPlanYears();
    };
    AppTprHierarchyEditNodeComponent.prototype.EditNodeProperties = function () {
        this.ResetAllTemplate();
        this.blnNodePropertiesShow = true;
    };
    AppTprHierarchyEditNodeComponent.prototype.EditMappingNames = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnMappingNamesShow = true;
        //debugger;
        this.mappingNames = [];
        this.mappingNames = this.editNodeCompleteData.Node.InputNameMappings.$values;
        console.log("mapping names ->", this.mappingNames);
        this.mappingNames.forEach(function (mappingName) {
            if (mappingName.Updated) {
                if (mappingName.Updated.endsWith("Z")) {
                    mappingName.Updated = mappingName.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(mappingName.Updated)) : null;
                }
                else {
                    mappingName.Updated = mappingName.Updated + "Z";
                    mappingName.Updated = mappingName.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(mappingName.Updated)) : null;
                }
            }
        });
        this.mappingNamecols = [
            { field: 'Name', header: 'Name' },
            { field: 'FeedSource', header: 'Source' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
    };
    AppTprHierarchyEditNodeComponent.prototype.EditRegionAllocation = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnRegionAllocationShow = true;
        this.regionAllocations = this.editNodeCompleteData.RegionalAllocations.$values;
        if (this.regionAllocations.length > 0) {
            this.regionAllocations.forEach(function (regionAllocation) {
                //regionAllocation.Updated = regionAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(regionAllocation.Updated)) : null;
                if (regionAllocation.Updated) {
                    if (regionAllocation.Updated.endsWith("Z")) {
                        regionAllocation.Updated = regionAllocation.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(regionAllocation.Updated)) : null;
                    }
                    else {
                        regionAllocation.Updated = regionAllocation.Updated + "Z";
                        regionAllocation.Updated = regionAllocation.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(regionAllocation.Updated)) : null;
                    }
                }
                var regionAllocationName = regionAllocation.RegionNode.Name;
                var regionAllocationItem = _this.regionNamesRegionAllocation.find(function (item) { return item.value == regionAllocationName; });
                if (regionAllocationItem) {
                    _this.regionNamesRegionAllocation.splice(_this.regionNamesRegionAllocation.indexOf(regionAllocationItem), 1);
                }
            });
        }
        console.log("regionAllocations ->", this.regionAllocations);
    };
    AppTprHierarchyEditNodeComponent.prototype.EditTagAllocation = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnTagAllocationShow = true;
        this.tags = this.editNodeCompleteData.Tags.$values;
        if (this.tags.length > 0) {
            this.tags.forEach(function (tag) {
                //tag.Updated = tag.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(tag.Updated)) : null;
                if (tag.Updated) {
                    if (tag.Updated.endsWith("Z")) {
                        tag.Updated = tag.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(tag.Updated)) : null;
                    }
                    else {
                        tag.Updated = tag.Updated + "Z";
                        tag.Updated = tag.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(tag.Updated)) : null;
                    }
                }
                var Name = tag.Name;
                var selectItem = _this.tagNames.find(function (item) { return item.value == Name; });
                if (selectItem) {
                    _this.tagNames.splice(_this.tagNames.indexOf(selectItem), 1);
                }
            });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.EditDividendAllocation = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnDividendAllocationShow = true;
        this.dividendPartnerAllocations = this.editNodeCompleteData.DividendPartnerAllocations.$values;
        if (this.dividendPartnerAllocations.length > 0) {
            this.dividendPartnerAllocations.forEach(function (dividendPartnerAllocation) {
                //dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(dividendPartnerAllocation.Updated)) : null;
                if (dividendPartnerAllocation.Updated) {
                    if (dividendPartnerAllocation.Updated.endsWith("Z")) {
                        dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(dividendPartnerAllocation.Updated)) : null;
                    }
                    else {
                        dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated + "Z";
                        dividendPartnerAllocation.Updated = dividendPartnerAllocation.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(dividendPartnerAllocation.Updated)) : null;
                    }
                }
                var dividendPartnerAllocationName = dividendPartnerAllocation.DividendPartnerNode.Name;
                var dividendPartnerAllocationItem = _this.dividendPartnerNames.find(function (item) { return item.value == dividendPartnerAllocationName; });
                if (dividendPartnerAllocationItem) {
                    _this.dividendPartnerNames.splice(_this.dividendPartnerNames.indexOf(dividendPartnerAllocationItem), 1);
                }
            });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.EditPnLPlan = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnPnLPlanShow = true;
        this.setPlanYears();
        this.strSelectedPnlPlanYear = this.pnlPlanYears[0].value;
        if (this.pnlPlansArray && this.pnlPlansArray.length > 0) {
            this.selectedPnlPlan = this.pnlPlansArray[0];
        }
        this.filteredPnlPlanYearToMonthPerRegion = [];
        this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
            .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
    };
    AppTprHierarchyEditNodeComponent.prototype.setPlanYears = function () {
        var currentYear = new Date().getFullYear();
        this.pnlPlanYears = [];
        this.pnlPlanYears.push({ label: currentYear.toString(), value: currentYear.toString() });
        for (var count = 1; count < 10; count++) {
            var nextYear = ++currentYear;
            this.pnlPlanYears.push({ label: nextYear.toString(), value: nextYear.toString() });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.EditPlanForDividendPartners = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnPlanForDividendPartnersShow = true;
        this.cols = [
            { field: 'strRegionName', header: 'Region' },
            { field: 'TotalPlan', header: 'Total Plan' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
        this.setDividendPlanYears();
        this.strSelectedDividendPlanYear = this.dividendPlanYears[0].value;
        if (this.dividendPlansArray && this.dividendPlansArray.length > 0) {
            this.selectedDividendPlan = this.dividendPlansArray[0];
        }
        this.filteredDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
            && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
            && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
    };
    AppTprHierarchyEditNodeComponent.prototype.setDividendPlanYears = function () {
        var currentYear = new Date().getFullYear();
        this.dividendPlanYears = [];
        this.dividendPlanYears.push({ label: currentYear.toString(), value: currentYear.toString() });
        for (var count = 1; count < 10; count++) {
            var nextYear = ++currentYear;
            this.dividendPlanYears.push({ label: nextYear.toString(), value: nextYear.toString() });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.EditMVAR = function () {
        this.ResetAllTemplate();
        this.blnMVARShow = true;
        this.strSelectedMVarUpdateTiming = this.editNodeCompleteData.MVarUpdateTiming ? this.editNodeCompleteData.MVarUpdateTiming.toString() : "-1";
        this.strSelectedMVarRegionName = this.editNodeCompleteData.MVarRegion ? this.editNodeCompleteData.MVarRegion.Name : "NotSet";
    };
    AppTprHierarchyEditNodeComponent.prototype.EditProfitAlertGroups = function () {
        var _this = this;
        this.ResetAllTemplate();
        this.blnProfitAlertGroupShow = true;
        this.profitAlertGroupsValues = this.editNodeCompleteData.AlertGroups.$values;
        this.profitAlertGroupcols = [
            { field: 'Name', header: 'Name' },
            { field: 'UpdatedTiming', header: 'Updated Timing' },
            { field: 'UpdatedBy', header: 'Updated By' },
            { field: 'Updated', header: 'Updated Date' }
        ];
        if (this.profitAlertGroupsValues.length > 0) {
            this.profitAlertGroupsValues.forEach(function (group) {
                //group.Updated = group.Updated != null ? this.tprCommonService.getFormattedSystemDate(new Date(group.Updated)) : null;
                if (group.Updated) {
                    if (group.Updated.endsWith("Z")) {
                        group.Updated = group.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(group.Updated)) : null;
                    }
                    else {
                        group.Updated = group.Updated + "Z";
                        group.Updated = group.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(group.Updated)) : null;
                    }
                }
                var Name = group.Name;
                var selectItem = _this.profitAlertGroupNames.find(function (item) { return item.value == Name; });
                if (selectItem) {
                    _this.profitAlertGroupNames.splice(_this.profitAlertGroupNames.indexOf(selectItem), 1);
                }
            });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.EditWorkingCapital = function () {
        this.ResetAllTemplate();
        this.blnWorkingCapitalShow = true;
        if (this.editNodeCompleteData.WorkingCapitalRegion) {
            this.strSelectedWorkingCapitalRegionName = this.editNodeCompleteData.WorkingCapitalRegion.Name;
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.Cancel = function () {
        //this.blnShowModalPouUp = false;
        this.router.navigate(['/hierarchy']);
    };
    AppTprHierarchyEditNodeComponent.prototype.ValidateNodeSave = function () {
        debugger;
        var result = true;
        var uniquenessResult = false;
        // Node name validation for not empty.
        if (this.editNodeCompleteData.Node.Name == null || this.editNodeCompleteData.Node.Name == undefined || this.editNodeCompleteData.Node.Name.length == 0) {
            //alert("Node name should not be empty.");
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error: Node name should not be empty.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        // Validation for verifying whether the node is active or not.
        if (!this.editNodeCompleteData.Node.IsActive) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error: No changes allowed as node is inactive.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        // Region allocation validation for proper value for a Pnl holder
        if (this.editNodeCompleteData.Node.IsPnlHolder && this.strRegionAllocationValueCheck != "100") {
            console.log("Node ->", this.editNodeCompleteData.Node);
            //alert("Error: The PNL holder node should have an allocated region. The total of all the region allocaitons has to be 100 percent.");
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error: The PNL holder node should have an allocated region. The total of all the region allocaitons has to be 100 percent.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        // Dividend allocation validation for proper value
        if (Number(this.strDividendAllocationValueCheck) > 100) {
            //alert("Error: Dividend allocations for the node must not exceed 100 percent.");
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error: Dividend allocations for the node must not exceed 100 percent.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        //Mapping Name validation for empty check
        var emptyMappingName = this.editNodeCompleteData.Node.InputNameMappings.$values.find(function (mappingName) { return mappingName.Name.trim() == ""; });
        if (emptyMappingName) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error: Mapping names must have names value.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        //Mapping Name validation for uniqueness check check        
        var mappingNamesArray = [];
        this.editNodeCompleteData.Node.InputNameMappings.$values.forEach(function (mappingName) { return mappingNamesArray.push(mappingName.Name.toLowerCase().trim()); });
        uniquenessResult = this.checkIfArrayIsUnique(mappingNamesArray);
        if (!uniquenessResult) {
            this.blnShowValidationDialog = true;
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Mapping names must have unique name value.";
            this.blnDisableControlsTillSaveCompletes = false;
            result = false;
            return result;
        }
        // If all the validation is successful, then return true.
        result = true;
        return result;
    };
    AppTprHierarchyEditNodeComponent.prototype.Save = function () {
        var _this = this;
        this.blnDisableControlsTillSaveCompletes = true;
        debugger;
        console.log(this.editNodeCompleteData);
        // Edit node validations
        var validationResult = this.ValidateNodeSave();
        if (!validationResult) {
            this.blnDisableControlsTillSaveCompletes = false;
            return false;
        }
        // Prepare the object for saving the data back to the server.
        // The object will be of the type IHierarchyNodePostData.
        this.nodeDataForPostToServer = new clsHierarchyNodePostData();
        // set property data
        this.nodeDataForPostToServer.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.StructurePropertiesDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        this.nodeDataForPostToServer.AlertGroups = [];
        this.nodeAlertGroups = new clsHierarchyNodePostData_Alerts();
        this.editNodeCompleteData.AlertGroups.$values.forEach(function (data) {
            _this.nodeAlertGroups.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            _this.nodeAlertGroups.Alerts = [];
            _this.nodeAlertGroups.Name = data.Name;
            _this.nodeAlertGroups.Members = [];
            _this.nodeAlertGroups.IsInUse = data.IsInUse;
            _this.nodeAlertGroups.UpdateTiming = data.UpdateTiming;
            _this.nodeAlertGroups.TradeDate = data.TradeDate;
            _this.nodeAlertGroups.ProfitAlertGroupStatusId = data.ProfitAlertGroupStatusId;
            _this.nodeAlertGroups.Created = data.Created;
            _this.nodeAlertGroups.CreatedBy = data.CreatedBy;
            _this.nodeAlertGroups.Updated = data.Updated;
            _this.nodeAlertGroups.UpdatedBy = data.UpdatedBy;
            _this.nodeAlertGroups.Id = data.Id;
            _this.nodeDataForPostToServer.AlertGroups.push(_this.nodeAlertGroups);
        });
        this.nodeDataForPostToServer.BusinessSegmentAllocations = []; // To be changed to proper datatype.
        this.nodeDataForPostToServer.Created = this.editNodeCompleteData.Created;
        this.nodeDataForPostToServer.CreatedBy = this.editNodeCompleteData.CreatedBy;
        if (this.editNodeCompleteData.Node.IsPnlHolder) {
            this.nodeDataForPostToServer.DividendPartnerAllocations = [];
            this.editNodeCompleteData.DividendPartnerAllocations.$values.forEach(function (dividendPartnerAllocation) {
                var dividendPartnerAllocationForPost = new clsHierarchyNodePostData_DividendPartnerAllocations();
                dividendPartnerAllocationForPost.$type = dividendPartnerAllocation.$type;
                dividendPartnerAllocationForPost.Percentage = dividendPartnerAllocation.Percentage;
                dividendPartnerAllocationForPost.DividendPartnerNode = new clsHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode();
                dividendPartnerAllocationForPost.DividendPartnerNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                dividendPartnerAllocationForPost.DividendPartnerNode.DividendPartner = dividendPartnerAllocation.DividendPartnerNode.DividendPartner;
                dividendPartnerAllocationForPost.DividendPartnerNode.Name = dividendPartnerAllocation.DividendPartnerNode.Name;
                dividendPartnerAllocationForPost.DividendPartnerNode.Description = dividendPartnerAllocation.DividendPartnerNode.Description;
                dividendPartnerAllocationForPost.DividendPartnerNode.IsMarkedForDeletion = dividendPartnerAllocation.DividendPartnerNode.IsMarkedForDeletion;
                if (dividendPartnerAllocation.DividendPartnerNode.NodeType.Name != null && dividendPartnerAllocation.DividendPartnerNode.NodeType.Name.trim() != "") {
                    dividendPartnerAllocationForPost.DividendPartnerNode.NodeType = dividendPartnerAllocation.DividendPartnerNode.NodeType;
                }
                else {
                    var systemNodeTypes = JSON.parse(localStorage.getItem("systemNodeTypes"));
                    var nodeType = _this.nodeTypes.find(function (node) { return node.Name.toLowerCase().trim() == "dividend partner allocation"; });
                    if (nodeType) {
                        dividendPartnerAllocationForPost.DividendPartnerNode.NodeType = nodeType;
                    }
                }
                dividendPartnerAllocationForPost.DividendPartnerNode.IsPnlHolder = dividendPartnerAllocation.DividendPartnerNode.IsPnlHolder;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputYTD = dividendPartnerAllocation.DividendPartnerNode.InputYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputExpectedYTD = dividendPartnerAllocation.DividendPartnerNode.InputExpectedYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.DividendYTD = dividendPartnerAllocation.DividendPartnerNode.DividendYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.ReportedMEYTD = dividendPartnerAllocation.DividendPartnerNode.ReportedMEYTD;
                dividendPartnerAllocationForPost.DividendPartnerNode.CanRemove = dividendPartnerAllocation.DividendPartnerNode.CanRemove;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputData = dividendPartnerAllocation.DividendPartnerNode.InputData ? dividendPartnerAllocation.DividendPartnerNode.InputData.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.OutputData = dividendPartnerAllocation.DividendPartnerNode.InputData ? dividendPartnerAllocation.DividendPartnerNode.OutputData.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.PreviousYTDForTrueUp = dividendPartnerAllocation.DividendPartnerNode.PreviousYTDForTrueUp;
                dividendPartnerAllocationForPost.DividendPartnerNode.AllDatesForCurrentReportingDate = dividendPartnerAllocation.DividendPartnerNode.AllDatesForCurrentReportingDate ? dividendPartnerAllocation.DividendPartnerNode.AllDatesForCurrentReportingDate.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.AllMVarDatesForCurrentReportingDate = dividendPartnerAllocation.DividendPartnerNode.AllMVarDatesForCurrentReportingDate ? dividendPartnerAllocation.DividendPartnerNode.AllMVarDatesForCurrentReportingDate.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.HasPnl = dividendPartnerAllocation.DividendPartnerNode.HasPnl;
                dividendPartnerAllocationForPost.DividendPartnerNode.HasMVaR = dividendPartnerAllocation.DividendPartnerNode.HasMVaR;
                dividendPartnerAllocationForPost.DividendPartnerNode.IsActive = dividendPartnerAllocation.DividendPartnerNode.IsActive;
                dividendPartnerAllocationForPost.DividendPartnerNode.InputNameMappings = dividendPartnerAllocation.DividendPartnerNode.InputNameMappings ? dividendPartnerAllocation.DividendPartnerNode.InputNameMappings.$values : [];
                dividendPartnerAllocationForPost.DividendPartnerNode.PreviousMonthEndDate = dividendPartnerAllocation.DividendPartnerNode.PreviousMonthEndDate;
                dividendPartnerAllocationForPost.DividendPartnerNode.PreviousTradeDate = dividendPartnerAllocation.DividendPartnerNode.PreviousTradeDate;
                dividendPartnerAllocationForPost.DividendPartnerNode.HasWorkingCapital = dividendPartnerAllocation.DividendPartnerNode.HasWorkingCapital;
                dividendPartnerAllocationForPost.DividendPartnerNode.Created = dividendPartnerAllocation.DividendPartnerNode.Created;
                dividendPartnerAllocationForPost.DividendPartnerNode.CreatedBy = dividendPartnerAllocation.DividendPartnerNode.CreatedBy;
                dividendPartnerAllocationForPost.DividendPartnerNode.Updated = dividendPartnerAllocation.DividendPartnerNode.Updated;
                dividendPartnerAllocationForPost.DividendPartnerNode.UpdatedBy = dividendPartnerAllocation.DividendPartnerNode.UpdatedBy;
                dividendPartnerAllocationForPost.DividendPartnerNode.Id = dividendPartnerAllocation.DividendPartnerNode.Id;
                dividendPartnerAllocationForPost.RegionNode = dividendPartnerAllocation.RegionNode;
                dividendPartnerAllocationForPost.BusinessSegmentNode = dividendPartnerAllocation.BusinessSegmentNode;
                dividendPartnerAllocationForPost.Created = dividendPartnerAllocation.Created;
                dividendPartnerAllocationForPost.CreatedBy = dividendPartnerAllocation.CreatedBy;
                dividendPartnerAllocationForPost.Updated = dividendPartnerAllocation.Updated;
                dividendPartnerAllocationForPost.UpdatedBy = dividendPartnerAllocation.UpdatedBy;
                dividendPartnerAllocationForPost.Id = dividendPartnerAllocation.Id;
                _this.nodeDataForPostToServer.DividendPartnerAllocations.push(dividendPartnerAllocationForPost);
            });
        }
        else {
            this.nodeDataForPostToServer.DividendPartnerAllocations = null;
        }
        this.nodeDataForPostToServer.HasChildren = this.editNodeCompleteData.HasChildren;
        this.nodeDataForPostToServer.HierarchyInstanceId = this.editNodeCompleteData.HierarchyInstanceId;
        this.nodeDataForPostToServer.Id = this.editNodeCompleteData.Id;
        this.nodeDataForPostToServer.IsMarkedForDeletion = this.editNodeCompleteData.IsMarkedForDeletion;
        this.nodeDataForPostToServer.LastUpdatedBy = this.editNodeCompleteData.LastUpdatedBy;
        this.nodeDataForPostToServer.Level = this.editNodeCompleteData.Level;
        this.nodeDataForPostToServer.MVarLimit = this.editNodeCompleteData.MVarLimit;
        var selectedMVARRegion = this.regions.find(function (region) { return region.Name == _this.strSelectedMVarRegionName; });
        if (selectedMVARRegion) {
            this.nodeDataForPostToServer.MVarRegion = new clsHierarchyEditNode_MVarRegion();
            this.nodeDataForPostToServer.MVarRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            this.nodeDataForPostToServer.MVarRegion.Created = selectedMVARRegion.Created.toString();
            this.nodeDataForPostToServer.MVarRegion.CreatedBy = selectedMVARRegion.CreatedBy;
            this.nodeDataForPostToServer.MVarRegion.Id = selectedMVARRegion.Id;
            this.nodeDataForPostToServer.MVarRegion.IsInUse = selectedMVARRegion.IsInUse;
            this.nodeDataForPostToServer.MVarRegion.Name = selectedMVARRegion.Name;
            this.nodeDataForPostToServer.MVarRegion.Updated = selectedMVARRegion.Updated.toString();
            this.nodeDataForPostToServer.MVarRegion.UpdatedBy = selectedMVARRegion.UpdatedBy;
        }
        this.nodeDataForPostToServer.MVarTemporaryLimit = this.editNodeCompleteData.MVarTemporaryLimit;
        this.nodeDataForPostToServer.MVarTemporaryLimitExpiryDate = this.editNodeCompleteData.MVarTemporaryLimitExpiryDate;
        this.nodeDataForPostToServer.MVarUpdateTiming = Number(this.strSelectedMVarUpdateTiming);
        // to set Node properties
        this.nodeDataForPostToServer.Node = new clsHierarchyNodePostData_Node();
        this.nodeDataForPostToServer.Node.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        this.nodeDataForPostToServer.Node.Name = this.editNodeCompleteData.Node.Name;
        this.nodeDataForPostToServer.Node.Description = this.editNodeCompleteData.Node.Description;
        this.nodeDataForPostToServer.Node.IsMarkedForDeletion = this.editNodeCompleteData.Node.IsMarkedForDeletion;
        var selectNodeType = this.nodeTypes.find(function (item) { return item.Name == _this.editNodeCompleteData.Node.NodeType.Name; });
        this.nodeDataForPostToServer.Node.NodeType = selectNodeType;
        this.nodeDataForPostToServer.Node.NodeType.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.NodeTypeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        this.nodeDataForPostToServer.Node.IsPnlHolder = this.editNodeCompleteData.Node.IsPnlHolder;
        this.nodeDataForPostToServer.Node.InputYTD = this.editNodeCompleteData.Node.InputYTD;
        this.nodeDataForPostToServer.Node.InputExpectedYTD = this.editNodeCompleteData.Node.InputExpectedYTD;
        this.nodeDataForPostToServer.Node.DividendYTD = this.editNodeCompleteData.Node.DividendYTD;
        this.nodeDataForPostToServer.Node.ReportedMEYTD = this.editNodeCompleteData.Node.ReportedMEYTD;
        this.nodeDataForPostToServer.Node.CanRemove = this.editNodeCompleteData.Node.CanRemove;
        this.nodeDataForPostToServer.Node.InputData = this.editNodeCompleteData.Node.InputData.$values;
        this.nodeDataForPostToServer.Node.InputData.forEach(function (data) {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Input.InputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });
        this.nodeDataForPostToServer.Node.OutputData = this.editNodeCompleteData.Node.OutputData.$values;
        this.nodeDataForPostToServer.Node.OutputData.forEach(function (data) {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.OutputDataDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });
        this.nodeDataForPostToServer.Node.PreviousYTDForTrueUp = this.editNodeCompleteData.Node.PreviousYTDForTrueUp;
        if (this.editNodeCompleteData.Node.AllDatesForCurrentReportingDate != null) {
            this.nodeDataForPostToServer.Node.AllDatesForCurrentReportingDate = this.editNodeCompleteData.Node.AllDatesForCurrentReportingDate.$values;
        }
        else {
            this.nodeDataForPostToServer.Node.AllDatesForCurrentReportingDate = [];
        }
        if (this.editNodeCompleteData.Node.AllMVarDatesForCurrentReportingDate != null) {
            this.nodeDataForPostToServer.Node.AllMVarDatesForCurrentReportingDate = this.editNodeCompleteData.Node.AllMVarDatesForCurrentReportingDate.$values;
        }
        else {
            this.nodeDataForPostToServer.Node.AllMVarDatesForCurrentReportingDate = [];
        }
        this.nodeDataForPostToServer.Node.HasPnl = this.editNodeCompleteData.Node.HasPnl;
        this.nodeDataForPostToServer.Node.HasMVaR = this.editNodeCompleteData.Node.HasMVaR;
        this.nodeDataForPostToServer.Node.IsActive = this.editNodeCompleteData.Node.IsActive;
        //mapping Names
        if (this.editNodeCompleteData.Node.InputNameMappings != null) {
            this.nodeDataForPostToServer.Node.InputNameMappings = this.editNodeCompleteData.Node.InputNameMappings.$values;
            this.nodeDataForPostToServer.Node.InputNameMappings.forEach(function (data) {
                data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.InputNameMappingDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            });
        }
        else {
            this.nodeDataForPostToServer.Node.InputNameMappings = [];
        }
        this.nodeDataForPostToServer.Node.PreviousMonthEndDate = this.editNodeCompleteData.Node.PreviousMonthEndDate;
        this.nodeDataForPostToServer.Node.PreviousTradeDate = this.editNodeCompleteData.Node.PreviousTradeDate;
        this.nodeDataForPostToServer.Node.HasWorkingCapital = this.editNodeCompleteData.Node.HasWorkingCapital;
        this.nodeDataForPostToServer.Node.Created = this.editNodeCompleteData.Node.Created;
        this.nodeDataForPostToServer.Node.CreatedBy = this.editNodeCompleteData.Node.CreatedBy;
        this.nodeDataForPostToServer.Node.Updated = this.editNodeCompleteData.Node.Updated;
        this.nodeDataForPostToServer.Node.UpdatedBy = this.editNodeCompleteData.Node.UpdatedBy;
        this.nodeDataForPostToServer.Node.Id = this.editNodeCompleteData.Node.Id;
        this.nodeDataForPostToServer.NodeType = this.editNodeCompleteData.NodeType;
        this.nodeDataForPostToServer.ParentId = this.editNodeCompleteData.ParentId;
        this.nodeDataForPostToServer.ParentNodeId = this.editNodeCompleteData.ParentNodeId;
        this.nodeDataForPostToServer.Plans = [];
        this.pnlPlansArray.forEach(function (pnlPlanArray) {
            var clsPnlPlan = new clsHierarchyNodePostData_Plans();
            clsPnlPlan.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            clsPnlPlan.DividendPartner = null;
            var pnlRegion = _this.regions.find(function (region) { return region.Name == pnlPlanArray.strRegionName; });
            if (pnlRegion) {
                clsPnlPlan.Region = new clsHierarchyNodePostData_Plans_Region();
                clsPnlPlan.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsPnlPlan.Region.Name = pnlRegion.Name;
                clsPnlPlan.Region.IsInUse = pnlRegion.IsInUse;
                clsPnlPlan.Region.Created = pnlRegion.Created.toString();
                clsPnlPlan.Region.CreatedBy = pnlRegion.CreatedBy.toString();
                clsPnlPlan.Region.Updated = pnlRegion.Updated.toString();
                clsPnlPlan.Region.UpdatedBy = pnlRegion.UpdatedBy.toString();
                clsPnlPlan.Region.Id = pnlRegion.Id;
            }
            clsPnlPlan.PlanValues = [];
            _this.filteredPnLPlanPerRegion = [];
            _this.filteredPnLPlanPerRegion = _this.completePnlPlanYearToMonthPerRegion.filter(function (pnlPlanYearToMonthPerRegion) { return pnlPlanYearToMonthPerRegion.strRegionName == pnlPlanArray.strRegionName; });
            var filteredPnlPlanArrayPerRegionPerYear = [];
            //debugger;
            _this.pnlPlanYears.forEach(function (pnlYear) {
                if (pnlYear.value != _this.pnlPlanYears[0].value) {
                    var pnlPlanPerYear = _this.filteredPnLPlanPerRegion.filter(function (yearPlan) { return yearPlan.strYear == pnlYear.value; });
                    //if (pnlPlanPerYear.length > 0 && pnlPlanPerYear.every(arrayItem => arrayItem.strPlanValue != "0" && arrayItem.strPlanValue != null)) {
                    if (pnlPlanPerYear.length > 0 && (pnlPlanPerYear.findIndex(function (arrayItem) { return arrayItem.strPlanValue.toString() != "0"; }) != -1)) {
                        var tempArray = [];
                        tempArray = _this.filteredPnLPlanPerRegion.filter(function (item) { return item.strYear == pnlYear.value; });
                        tempArray.forEach(function (item) { return filteredPnlPlanArrayPerRegionPerYear.push(item); });
                    }
                }
                else {
                    var tempArray = [];
                    tempArray = _this.filteredPnLPlanPerRegion.filter(function (item) { return item.strYear == pnlYear.value; });
                    tempArray.forEach(function (item) { return filteredPnlPlanArrayPerRegionPerYear.push(item); });
                }
            });
            filteredPnlPlanArrayPerRegionPerYear.forEach(function (pnlArrayItem) {
                var pnlPlanValue = new clsHierarchyNodePostData_Plans_PlanValues();
                pnlPlanValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanValueDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                pnlPlanValue.Year = Number(pnlArrayItem.strYear);
                pnlPlanValue.Month = Number(pnlArrayItem.strMonthValue);
                if (pnlArrayItem.strMonthValue != "0" && pnlArrayItem.strMonthValue != null) {
                    pnlPlanValue.Value = Number(pnlArrayItem.strPlanValue);
                }
                else {
                    pnlPlanValue.Value = null;
                }
                clsPnlPlan.PlanValues.push(pnlPlanValue);
            });
            _this.nodeDataForPostToServer.Plans.push(clsPnlPlan);
        });
        // this is for dividend plan
        this.dividendPlansArray.forEach(function (dividendPlanArray) {
            var clsDividendPlan = new clsHierarchyNodePostData_Plans();
            clsDividendPlan.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            var dividendPartnerObj = _this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == dividendPlanArray.strDividendPartnerName; });
            if (dividendPartnerObj) {
                clsDividendPlan.DividendPartner = new clsHierarchyNodePostData_Plans_DividendPartner();
                clsDividendPlan.DividendPartner.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.DividendPartner.BusinessSegment = new clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment();
                clsDividendPlan.DividendPartner.BusinessSegment = dividendPartnerObj.BusinessSegment;
                clsDividendPlan.DividendPartner.BusinessSegment.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.BusinessSegmentDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.DividendPartner.Created = dividendPartnerObj.Created;
                clsDividendPlan.DividendPartner.CreatedBy = dividendPartnerObj.CreatedBy;
                clsDividendPlan.DividendPartner.Editable = dividendPartnerObj.Editable;
                clsDividendPlan.DividendPartner.Id = dividendPartnerObj.Id;
                clsDividendPlan.DividendPartner.IsInUse = dividendPartnerObj.IsInUse;
                clsDividendPlan.DividendPartner.Name = dividendPartnerObj.Name;
                clsDividendPlan.DividendPartner.Updated = dividendPartnerObj.Updated;
                clsDividendPlan.DividendPartner.UpdatedBy = dividendPartnerObj.UpdatedBy;
            }
            var pnlRegion = _this.regions.find(function (region) { return region.Name == dividendPlanArray.strRegionName; });
            if (pnlRegion) {
                clsDividendPlan.Region = new clsHierarchyNodePostData_Plans_Region();
                clsDividendPlan.Region.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                clsDividendPlan.Region.Name = pnlRegion.Name;
                clsDividendPlan.Region.IsInUse = pnlRegion.IsInUse;
                clsDividendPlan.Region.Created = pnlRegion.Created.toString();
                clsDividendPlan.Region.CreatedBy = pnlRegion.CreatedBy.toString();
                clsDividendPlan.Region.Updated = pnlRegion.Updated.toString();
                clsDividendPlan.Region.UpdatedBy = pnlRegion.UpdatedBy.toString();
                clsDividendPlan.Region.Id = pnlRegion.Id;
            }
            clsDividendPlan.PlanValues = [];
            _this.filteredDividendPlanPerDividendPartnerAndRegion = [];
            _this.filteredDividendPlanPerDividendPartnerAndRegion = _this.completeDividendPlanYearToMonthPerRegion
                .filter(function (dividendPlanYearToMonthPerDividendPartnerAndRegion) {
                return dividendPlanYearToMonthPerDividendPartnerAndRegion.strRegionName == dividendPlanArray.strRegionName &&
                    dividendPlanYearToMonthPerDividendPartnerAndRegion.strDividendPartnerName == dividendPlanArray.strDividendPartnerName;
            });
            //debugger;
            var filteredDividendPlanArrayPerRegionPerYear = [];
            _this.dividendPlanYears.forEach(function (dividendYear) {
                if (dividendYear.value != _this.dividendPlanYears[0].value) {
                    var dividendPlanPerYear = _this.filteredDividendPlanPerDividendPartnerAndRegion.filter(function (yearPlan) { return yearPlan.strYear == dividendYear.value; });
                    if (dividendPlanPerYear.length > 0 && (dividendPlanPerYear.findIndex(function (arrayItem) { return arrayItem.strPlanValue.toString() != "0"; }) != -1)) {
                        var tempArray = [];
                        tempArray = _this.filteredDividendPlanPerDividendPartnerAndRegion.filter(function (item) { return item.strYear == dividendYear.value; });
                        tempArray.forEach(function (item) { return filteredDividendPlanArrayPerRegionPerYear.push(item); });
                    }
                }
                else {
                    var tempArray = [];
                    tempArray = _this.filteredDividendPlanPerDividendPartnerAndRegion.filter(function (item) { return item.strYear == dividendYear.value; });
                    tempArray.forEach(function (item) { return filteredDividendPlanArrayPerRegionPerYear.push(item); });
                }
            });
            filteredDividendPlanArrayPerRegionPerYear.forEach(function (dividendArrayItem) {
                var dividendPlanValue = new clsHierarchyNodePostData_Plans_PlanValues();
                dividendPlanValue.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.PlanValueDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                dividendPlanValue.Year = Number(dividendArrayItem.strYear);
                dividendPlanValue.Month = Number(dividendArrayItem.strMonthValue);
                if (dividendArrayItem.strMonthValue != "0" && dividendArrayItem.strMonthValue != null) {
                    dividendPlanValue.Value = Number(dividendArrayItem.strPlanValue);
                }
                else {
                    dividendPlanValue.Value = null;
                }
                clsDividendPlan.PlanValues.push(dividendPlanValue);
            });
            _this.nodeDataForPostToServer.Plans.push(clsDividendPlan);
        });
        this.nodeDataForPostToServer.PnlSplitValue = null; //To be changed to proper datatype.
        if (this.editNodeCompleteData.Node.IsPnlHolder) {
            this.nodeDataForPostToServer.RegionalAllocations = [];
            this.editNodeCompleteData.RegionalAllocations.$values.forEach(function (regionAllocation) {
                var regionAllocationForPost = new clsHierarchyNodePostData_RegionalAllocations();
                regionAllocationForPost.$type = regionAllocation.$type;
                regionAllocationForPost.Percentage = regionAllocation.Percentage;
                regionAllocationForPost.RegionNode = new clsHierarchyNodePostData_RegionalAllocations_RegionNode();
                regionAllocationForPost.RegionNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                regionAllocationForPost.RegionNode.Region = regionAllocation.RegionNode.Region;
                regionAllocationForPost.RegionNode.Name = regionAllocation.RegionNode.Name;
                regionAllocationForPost.RegionNode.Description = regionAllocation.RegionNode.Description;
                regionAllocationForPost.RegionNode.IsMarkedForDeletion = regionAllocation.RegionNode.IsMarkedForDeletion;
                //regionAllocationForPost.RegionNode.NodeType = regionAllocation.RegionNode.NodeType;
                if (regionAllocation.RegionNode.NodeType.Name != null && regionAllocation.RegionNode.NodeType.Name.trim() != "") {
                    regionAllocationForPost.RegionNode.NodeType = regionAllocation.RegionNode.NodeType;
                }
                else {
                    var systemNodeTypes = JSON.parse(localStorage.getItem("systemNodeTypes"));
                    var nodeType = _this.nodeTypes.find(function (node) { return node.Name.toLowerCase().trim() == "region allocation"; });
                    if (nodeType) {
                        regionAllocationForPost.RegionNode.NodeType = nodeType;
                    }
                }
                regionAllocationForPost.RegionNode.IsPnlHolder = regionAllocation.RegionNode.IsPnlHolder;
                regionAllocationForPost.RegionNode.InputYTD = regionAllocation.RegionNode.InputYTD;
                regionAllocationForPost.RegionNode.InputExpectedYTD = regionAllocation.RegionNode.InputExpectedYTD;
                regionAllocationForPost.RegionNode.DividendYTD = regionAllocation.RegionNode.DividendYTD;
                regionAllocationForPost.RegionNode.ReportedMEYTD = regionAllocation.RegionNode.ReportedMEYTD;
                regionAllocationForPost.RegionNode.CanRemove = regionAllocation.RegionNode.CanRemove;
                regionAllocationForPost.RegionNode.InputData = regionAllocation.RegionNode.InputData ? regionAllocation.RegionNode.InputData.$values : [];
                regionAllocationForPost.RegionNode.OutputData = regionAllocation.RegionNode.InputData ? regionAllocation.RegionNode.OutputData.$values : [];
                regionAllocationForPost.RegionNode.PreviousYTDForTrueUp = regionAllocation.RegionNode.PreviousYTDForTrueUp;
                regionAllocationForPost.RegionNode.AllDatesForCurrentReportingDate = regionAllocation.RegionNode.AllDatesForCurrentReportingDate ? regionAllocation.RegionNode.AllDatesForCurrentReportingDate.$values : [];
                regionAllocationForPost.RegionNode.AllMVarDatesForCurrentReportingDate = regionAllocation.RegionNode.AllMVarDatesForCurrentReportingDate ? regionAllocation.RegionNode.AllMVarDatesForCurrentReportingDate.$values : [];
                regionAllocationForPost.RegionNode.HasPnl = regionAllocation.RegionNode.HasPnl;
                regionAllocationForPost.RegionNode.HasMVaR = regionAllocation.RegionNode.HasMVaR;
                regionAllocationForPost.RegionNode.IsActive = regionAllocation.RegionNode.IsActive;
                regionAllocationForPost.RegionNode.InputNameMappings = regionAllocation.RegionNode.InputNameMappings ? regionAllocation.RegionNode.InputNameMappings.$values : [];
                regionAllocationForPost.RegionNode.PreviousMonthEndDate = regionAllocation.RegionNode.PreviousMonthEndDate;
                regionAllocationForPost.RegionNode.PreviousTradeDate = regionAllocation.RegionNode.PreviousTradeDate;
                regionAllocationForPost.RegionNode.HasWorkingCapital = regionAllocation.RegionNode.HasWorkingCapital;
                regionAllocationForPost.RegionNode.Created = regionAllocation.RegionNode.Created;
                regionAllocationForPost.RegionNode.CreatedBy = regionAllocation.RegionNode.CreatedBy;
                regionAllocationForPost.RegionNode.Updated = regionAllocation.RegionNode.Updated;
                regionAllocationForPost.RegionNode.UpdatedBy = regionAllocation.RegionNode.UpdatedBy;
                regionAllocationForPost.RegionNode.Id = regionAllocation.RegionNode.Id;
                regionAllocationForPost.DividendPartnerNode = regionAllocation.DividendPartnerNode;
                regionAllocationForPost.BusinessSegmentNode = regionAllocation.BusinessSegmentNode;
                regionAllocationForPost.Created = regionAllocation.Created;
                regionAllocationForPost.CreatedBy = regionAllocation.CreatedBy;
                regionAllocationForPost.Updated = regionAllocation.Updated;
                regionAllocationForPost.UpdatedBy = regionAllocation.UpdatedBy;
                regionAllocationForPost.Id = regionAllocation.Id;
                _this.nodeDataForPostToServer.RegionalAllocations.push(regionAllocationForPost);
            });
        }
        else {
            this.nodeDataForPostToServer.RegionalAllocations = null;
        }
        this.nodeDataForPostToServer.SplitType = this.editNodeCompleteData.Node.IsPnlHolder ? this.strSelectedSplitType : null;
        this.nodeDataForPostToServer.Tags = this.editNodeCompleteData.Tags.$values;
        this.nodeDataForPostToServer.Tags.forEach(function (data) {
            data.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.TagDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        });
        this.nodeDataForPostToServer.Updated = this.editNodeCompleteData.Updated;
        this.nodeDataForPostToServer.UpdatedBy = this.editNodeCompleteData.UpdatedBy;
        this.nodeDataForPostToServer.UpdateTiming = this.editNodeCompleteData.UpdateTiming;
        if (this.editNodeCompleteData.WorkingCapitalRegion) {
            this.nodeDataForPostToServer.WorkingCapitalRegion = this.editNodeCompleteData.WorkingCapitalRegion;
            this.nodeDataForPostToServer.WorkingCapitalRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            if (this.strSelectedWorkingCapitalRegionName == "" || this.strSelectedWorkingCapitalRegionName == "NotSet") {
                this.nodeDataForPostToServer.WorkingCapitalRegion.Name = "";
            }
            else {
                this.nodeDataForPostToServer.WorkingCapitalRegion.Name = this.strSelectedWorkingCapitalRegionName;
            }
        }
        else {
            if (this.blnWorkingCapitalRegion) {
                this.nodeDataForPostToServer.WorkingCapitalRegion = new clsHierarchyEditNode_WorkingCapital();
                this.nodeDataForPostToServer.WorkingCapitalRegion.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                if (this.strSelectedWorkingCapitalRegionName == "" || this.strSelectedWorkingCapitalRegionName == "NotSet") {
                    this.nodeDataForPostToServer.WorkingCapitalRegion.Name = "";
                }
                else {
                    this.nodeDataForPostToServer.WorkingCapitalRegion.Name = this.strSelectedWorkingCapitalRegionName;
                }
            }
        }
        debugger;
        console.log(this.nodeDataForPostToServer);
        this.tPRHierarchyservice.updateNodeLevelDataForEdit(this.nodeDataForPostToServer)
            .subscribe(function (response) {
            debugger;
            console.log(response);
            _this.blnDisableControlsTillSaveCompletes = false;
            if (response.Error) {
                alert(response.Error);
            }
            else {
                _this.blnShowModalPouUp = false;
                _this.router.navigateByUrl('/hierarchy');
            }
        }, function (error) {
            debugger;
            console.log(error);
        });
    };
    AppTprHierarchyEditNodeComponent.prototype.ResetAllTemplate = function () {
        this.blnNodePropertiesShow = false;
        this.blnMappingNamesShow = false;
        this.blnRegionAllocationShow = false;
        this.blnTagAllocationShow = false;
        this.blnDividendAllocationShow = false;
        this.blnPnLPlanShow = false;
        this.blnPlanForDividendPartnersShow = false;
        this.blnMVARShow = false;
        this.blnProfitAlertGroupShow = false;
        this.blnWorkingCapitalShow = false;
    };
    AppTprHierarchyEditNodeComponent.prototype.setNodeTypeData = function (data) {
        //debugger;
        this.nodeTypes = data.Result.NodeTypes.$values;
        localStorage.setItem("systemNodeTypes", JSON.stringify(this.nodeTypes));
        this.nodeTypes = this.nodeTypes.filter(function (nodeType) { return nodeType.Editable == true; });
        this.nodes = [];
        var nodeName = '';
        for (var i = 0; i < this.nodeTypes.length; i++) {
            var node = this.nodeTypes[i];
            nodeName = node.Name;
            this.nodes.push({ label: nodeName, value: nodeName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.IsPnlHolderChange = function (checked) {
        this.editChildMenuItems.find(function (menuItem) { return menuItem.label == "Region Allocation"; }).disabled = !this.editNodeCompleteData.Node.IsPnlHolder;
        this.updateTimings = [];
        if (checked) {
            this.updateTimings = [
                { label: "R-1", value: "-1" },
                { label: "R-2", value: "-2" }
            ];
            if (!this.editNodeCompleteData.UpdateTiming) {
                this.selectedUpdateTiming = -1;
                this.editNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
            }
        }
        else {
            this.updateTimings = [
                { label: "Not Set", value: null },
                { label: "R-1", value: "-1" },
                { label: "R-2", value: "-2" }
            ];
            if (this.editNodeCompleteData.UpdateTiming) {
                this.selectedUpdateTiming = null;
                this.editNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
            }
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.getHierarchyData = function () {
        var _this = this;
        this.tPRHierarchyservice.getHierarchyObservable().
            subscribe(function (files) { return _this.setNodeData(files); });
    };
    AppTprHierarchyEditNodeComponent.prototype.setNodeData = function (data) {
        var _this = this;
        //this.mainListOfTree = data.Result.Children.$values;
        localStorage.setItem("MainHierarchyData", JSON.stringify(data.Result.Children.$values));
        this.hierarchy = data.Result.Children.$values;
        this.hierarchy.forEach(function (node) {
            _this.updateChildrenPropRecursive(node);
        });
        console.log("hierarchy ->", this.hierarchy);
        this.mainListOfTree = this.hierarchy;
        this.updateNodeProps();
        this.setUpdateTimingForNode();
        this.checkDisablePnlHolder();
    };
    AppTprHierarchyEditNodeComponent.prototype.updateChildrenPropRecursive = function (node) {
        var _this = this;
        node.Children = node.Children.$values;
        node.children = node.Children;
        node.label = node.NodeName;
        if (node.Children) {
            node.Children.forEach(function (childNode) {
                _this.updateChildrenPropRecursive(childNode);
            });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.updateNodeProps = function () {
        var _this = this;
        this.mainListOfTree.forEach(function (node) {
            _this.AddNodeToArray(node);
            console.log("nodeArrays -> ", _this.nodeArrays);
        });
    };
    AppTprHierarchyEditNodeComponent.prototype.setRegionsData = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNames = [];
        this.regionNames.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNames.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setProfitAlertGroupDate = function (data) {
        this.profitAlertGroupsValuesMasterData = data.Result.AlertGroups.$values;
        this.profitAlertGroupNames = [];
        this.profitAlertGroupNames.push({ label: 'Not Set', value: 'NotSet' });
        for (var i = 0; i < this.profitAlertGroupsValuesMasterData.length; i++) {
            var pfaGroup = this.profitAlertGroupsValuesMasterData[i];
            this.profitAlertGroupNames.push({ label: pfaGroup.Name, value: pfaGroup.Name });
            this.profitAlertGroupArrays.push({
                Name: pfaGroup.Name,
                UpdateTiming: pfaGroup.UpdateTiming,
                Id: pfaGroup.Id,
                IsInUse: pfaGroup.IsInUse,
                TradeDate: pfaGroup.TradeDate,
                ProfitAlertGroupStatusId: pfaGroup.ProfitAlertGroupStatusId,
                Created: pfaGroup.Created,
                CreatedBy: pfaGroup.CreatedBy,
                Updated: pfaGroup.Updated,
                UpdatedBy: pfaGroup.UpdatedBy
            });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setDividendPartnerData = function (data) {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
        //this.dividendPartnerTypes = this.dividendPartnerTypes.filter(divPartner => divPartner.Editable == true);
        this.dividendPartnerNames = [];
        this.dividendPartnerNames.push({ label: 'Not Set', value: 'NotSet' });
        var dividendPartnerName = '';
        for (var i = 0; i < this.dividendPartnerTypes.length; i++) {
            var dividendPartner = this.dividendPartnerTypes[i];
            dividendPartnerName = dividendPartner.Name;
            this.dividendPartnerNames.push({ label: dividendPartnerName, value: dividendPartnerName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setDividendPartnerDataForDividendPlanAllocation = function (data) {
        this.dividendPartnerTypes = [];
        this.dividendPartnerTypes = data.Result.DividendPartners.$values;
        //this.dividendPartnerTypes = this.dividendPartnerTypes.filter(divPartner => divPartner.Editable == true);
        this.dividendPartnerNamesDividendPlanAllocation = [];
        this.dividendPartnerNamesDividendPlanAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var dividendPartnerName = '';
        for (var i = 0; i < this.dividendPartnerTypes.length; i++) {
            var dividendPartner = this.dividendPartnerTypes[i];
            dividendPartnerName = dividendPartner.Name;
            this.dividendPartnerNamesDividendPlanAllocation.push({ label: dividendPartnerName, value: dividendPartnerName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setBusinessSegmentsData = function (data) {
        this.businessSegments = [];
        this.businessSegments = data.Result.BusinessSegments.$values;
    };
    AppTprHierarchyEditNodeComponent.prototype.setTagTypeData = function (data) {
        this.tagTypes = [];
        this.tagTypes = data.Result.Tags.$values;
        this.tagNames = [];
        var tagName = '';
        this.tagNames.push({ label: 'Not Set', value: 'NotSet' });
        for (var i = 0; i < this.tagTypes.length; i++) {
            var tag = this.tagTypes[i];
            tagName = tag.Name;
            this.tagNames.push({ label: tagName, value: tagName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setUpdateTimingForNode = function () {
        this.getUpdateTimingFromHierarchyForNode(this.editNodeCompleteData.Id);
    };
    AppTprHierarchyEditNodeComponent.prototype.AddNodeToArray = function (node) {
        var _this = this;
        //debugger;
        this.nodeArrays.push({
            label: node.NodeName,
            $type: node.type,
            Children: node.Children,
            HasAnyOutputData: node.HasAnyOutputData,
            HasPlans: node.HasPlans,
            Level: node.Level,
            MVarUpdateTiming: node.MVarUpdateTiming,
            IsActive: node.IsActive,
            IsPnlHolder: node.IsPnlHolder,
            NodeId: node.NodeId,
            NodeType: node.NodeType,
            SplitType: node.SplitType,
            UpdateTiming: node.UpdateTiming,
            children: node.children,
            collapsedIcon: "fa-plus-square",
            data: node.data,
            expanded: node.expanded,
            expandedIcon: "fa-minus-square",
            icon: node.icon,
            id: node.id,
            leaf: node.leaf,
            parent: node.parent,
            Id: node.Id,
            ParentId: node.ParentId,
            NodeName: node.NodeName,
            type: node.type,
            partialSelected: node.partialSelected
        });
        node.children = node.Children;
        if (node.children) {
            //console.log("node.children ->", node.children);
            //debugger;
            node.children.forEach(function (childNode) {
                _this.AddNodeToArray(childNode);
            });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.onNodeUpdateTimingChange = function () {
        this.editNodeCompleteData.UpdateTiming = this.selectedUpdateTiming;
    };
    AppTprHierarchyEditNodeComponent.prototype.getUpdateTimingFromHierarchyForNode = function (Id) {
        //debugger;
        var nodeArray;
        nodeArray = this.nodeArrays.find(function (node) { return node.Id == Id; });
        if (nodeArray && this.selectedUpdateTiming == null) {
            if (!nodeArray.UpdateTiming) {
                this.getUpdateTimingFromHierarchyForNode(nodeArray.ParentId);
            }
            else {
                this.selectedUpdateTiming = nodeArray.UpdateTiming;
                // this will identify whether to disable the field or not. If the node value which came initially was null, 
                //the field will be disabled and will be set to parent level updateTiming; else, it will not be disabled.
                if (this.editNodeCompleteData.UpdateTiming == null) {
                    this.blndisableSelectedUpdateTimingField = true;
                    this.nodeNameCorrespondingToUpdateTiming = nodeArray.NodeName;
                }
            }
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.checkDisablePnlHolder = function () {
        // if (!this.editNodeCompleteData.Node.IsPnlHolder) {
        //     let nodeId = this.editNodeCompleteData.Id;
        //     if (this.nodeArrays.filter(node => node.ParentId == nodeId).length > 0) {
        //         this.blnPnlHolderDisabled = true;
        //     }
        // }
    };
    AppTprHierarchyEditNodeComponent.prototype.onMappingAddClick = function (txtMappingName, txtMappingSource) {
        if (txtMappingName && txtMappingName.trim() != "") {
            var index = this.mappingNames.indexOf(this.mappingNames.find(function (mappingName) { return mappingName.Name.toLowerCase().trim() == txtMappingName.toLowerCase().trim(); }));
            if (index == -1) {
                var $type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.InputNameMappingDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                this.mappingNames.push(new clsHierarchyEditNode_Node_InputNameMappings_Value($type, txtMappingName, txtMappingSource, '', '', '', '', 0));
            }
            else {
                this.strValidationHeader = "Validation failed";
                this.strValidationMessage = "Error : Mapping names must have unique name value.";
                this.blnShowValidationDialog = true;
            }
        }
        else {
            this.strValidationHeader = "Validation failed";
            this.strValidationMessage = "Error : Mapping names must have name value.";
            this.blnShowValidationDialog = true;
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.deleteMappingName = function (mappingName) {
        if (mappingName) {
            this.mappingName = mappingName;
            this.mappingNames.splice(this.findmappingNameIndexForDelete(), 1);
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.findmappingNameIndexForDelete = function () {
        return this.mappingNames.indexOf(this.mappingName);
    };
    AppTprHierarchyEditNodeComponent.prototype.IsWorkingCapital = function (checked) {
        if (checked) {
            var index = this.regionNames.findIndex(function (x) { return x.value == "NotSet"; });
            if (index >= 0) {
                this.regionNames.splice(index, 1);
            }
        }
        else {
            this.strSelectedWorkingCapitalRegionName = "NotSet";
            if (!this.editNodeCompleteData.WorkingCapitalRegion) {
                this.regionNames.unshift({ label: 'Not Set', value: 'NotSet' });
            }
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.onAddProfitAlertGroup = function () {
        var _this = this;
        var selectedGroup = this.profitAlertGroupArrays.find(function (group) { return group.Name == _this.strSelectedProfitAlertGroupName; });
        if (selectedGroup) {
            var $type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            this.profitAlertGroupsValues
                .push({
                $type: $type,
                Alerts: null,
                Name: this.strSelectedProfitAlertGroupName,
                Members: null,
                IsInUse: selectedGroup.IsInUse,
                UpdateTiming: selectedGroup.UpdateTiming,
                TradeDate: selectedGroup.TradeDate,
                ProfitAlertGroupStatusId: selectedGroup.ProfitAlertGroupStatusId,
                Created: selectedGroup.Created,
                CreatedBy: selectedGroup.CreatedBy,
                Updated: selectedGroup.Updated,
                UpdatedBy: selectedGroup.UpdatedBy,
                Id: selectedGroup.Id
            });
            var selectedProfitAlertGroupMasterItem = this.profitAlertGroupNames.find(function (x) { return x.value == _this.strSelectedProfitAlertGroupName; });
            if (selectedProfitAlertGroupMasterItem) {
                this.profitAlertGroupNames.splice(this.profitAlertGroupNames.indexOf(selectedProfitAlertGroupMasterItem), 1);
            }
            this.strSelectedProfitAlertGroupName = "NotSet";
            this.strSelectedGroupUpdateTiming = null;
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.ProfitAlertGroupChange = function (ProfitAlertGroupName) {
        var _this = this;
        var selectedProfitAlertGroupMasterItem = this.profitAlertGroupNames.find(function (x) { return x.value == _this.strSelectedProfitAlertGroupName; });
        var selectedGroup = this.profitAlertGroupArrays.find(function (group) { return group.Name == _this.strSelectedProfitAlertGroupName; });
        if (selectedGroup) {
            this.strSelectedGroupUpdateTiming = selectedGroup.UpdateTiming ? "R" + selectedGroup.UpdateTiming : "";
        }
        else {
            this.strSelectedGroupUpdateTiming = "";
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.deleteProfitAlertGroup = function (profitAlertGroup) {
        if (profitAlertGroup) {
            this.profitAlertGroup = profitAlertGroup;
            this.profitAlertGroupsValues.splice(this.findProfitAlertGroupForDelete(), 1);
            this.profitAlertGroupNames.push({ label: profitAlertGroup.Name, value: profitAlertGroup.Name });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.findProfitAlertGroupForDelete = function () {
        return this.profitAlertGroupsValues.indexOf(this.profitAlertGroup);
    };
    AppTprHierarchyEditNodeComponent.prototype.MVarHolderChecked = function (checked) {
        this.blnMVarUpdateTiming = !checked;
        this.editNodeCompleteData.Node.HasMVaR = checked;
    };
    AppTprHierarchyEditNodeComponent.prototype.setRegionsDataForMVar = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesMVar = [];
        this.regionNamesMVar.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesMVar.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setRegionsDataForRegionAllocation = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesRegionAllocation = [];
        this.regionNamesRegionAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesRegionAllocation.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setRegionsDataForPlanRegionAllocation = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesPlanRegionAllocation = [];
        this.regionNamesPlanRegionAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesPlanRegionAllocation.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setRegionsDataForDividendPlanRegionAllocation = function (data) {
        this.regions = data.Result.Regions.$values;
        this.regionNamesDividendPlanAllocation = [];
        this.regionNamesDividendPlanAllocation.push({ label: 'Not Set', value: 'NotSet' });
        var regionName = '';
        for (var i = 0; i < this.regions.length; i++) {
            var region = this.regions[i];
            regionName = region.Name;
            this.regionNamesDividendPlanAllocation.push({ label: regionName, value: regionName });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.onAddTags = function () {
        var _this = this;
        var selectedTag = this.tagTypes.find(function (item) { return item.Name == _this.strSelectedTagName; });
        if (selectedTag) {
            this.tags.push({
                $type: selectedTag.$type,
                Created: selectedTag.Created,
                CreatedBy: selectedTag.CreatedBy,
                Editable: selectedTag.Editable,
                Id: selectedTag.Id,
                IsInUse: selectedTag.IsInUse,
                Name: selectedTag.Name,
                Updated: selectedTag.Updated,
                UpdatedBy: selectedTag.UpdatedBy
            });
            var selectedTagNameMasterItem = this.tagNames.find(function (x) { return x.value == _this.strSelectedTagName; });
            if (selectedTagNameMasterItem) {
                this.tagNames.splice(this.tagNames.indexOf(selectedTagNameMasterItem), 1);
            }
            this.strSelectedTagName = "NotSet";
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.deleteTag = function (selectedTagforDelete) {
        if (selectedTagforDelete) {
            this.tag = selectedTagforDelete;
            this.tags.splice(this.findTagForDelete(), 1);
            this.tagNames.push({ label: selectedTagforDelete.Name, value: selectedTagforDelete.Name });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.findTagForDelete = function () {
        return this.tags.indexOf(this.tag);
    };
    AppTprHierarchyEditNodeComponent.prototype.onRegionAllocationAddClick = function () {
        var _this = this;
        var selectedRegionAllocation = this.regions.find(function (region) { return region.Name == _this.strSelectedRegionAllocationName; });
        if (selectedRegionAllocation) {
            var regionAllocationForSave = new clsHierarchyEditNode_RegionalAllocations_Values();
            regionAllocationForSave.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.AllocationStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            regionAllocationForSave.Percentage = Number(this.strRegionAllocationPercentage);
            regionAllocationForSave.RegionNode = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode();
            regionAllocationForSave.RegionNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            regionAllocationForSave.RegionNode.Region = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region();
            var region = this.regions.find(function (region) { return region.Name == _this.strSelectedRegionAllocationName; });
            if (region) {
                regionAllocationForSave.RegionNode.Region.$type = region.$type;
                regionAllocationForSave.RegionNode.Region.Created = region.Created.toString();
                regionAllocationForSave.RegionNode.Region.CreatedBy = region.CreatedBy;
                regionAllocationForSave.RegionNode.Region.Id = region.Id;
                regionAllocationForSave.RegionNode.Region.IsInUse = region.IsInUse;
                regionAllocationForSave.RegionNode.Region.Name = region.Name;
                regionAllocationForSave.RegionNode.Region.Updated = region.Updated.toString();
                regionAllocationForSave.RegionNode.Region.UpdatedBy = region.UpdatedBy;
            }
            regionAllocationForSave.RegionNode.Name = this.strSelectedRegionAllocationName;
            regionAllocationForSave.RegionNode.Description = null;
            regionAllocationForSave.RegionNode.IsMarkedForDeletion = false;
            regionAllocationForSave.RegionNode.NodeType = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType();
            //let node = this.nodeTypes.find(node => node.Name.toLowerCase() == "region allocation")
            var systemNodeTypes = JSON.parse(localStorage.getItem("systemNodeTypes"));
            var node = systemNodeTypes.find(function (node) { return node.Name.toLowerCase() == "region allocation"; });
            if (node) {
                regionAllocationForSave.RegionNode.NodeType = node;
            }
            regionAllocationForSave.RegionNode.IsPnlHolder = false;
            regionAllocationForSave.RegionNode.InputYTD = null;
            regionAllocationForSave.RegionNode.InputExpectedYTD = null;
            regionAllocationForSave.RegionNode.DividendYTD = null;
            regionAllocationForSave.RegionNode.ReportedMEYTD = null;
            regionAllocationForSave.RegionNode.CanRemove = false;
            regionAllocationForSave.RegionNode.InputData = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData();
            regionAllocationForSave.RegionNode.InputData.$values = [];
            regionAllocationForSave.RegionNode.OutputData = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData();
            regionAllocationForSave.RegionNode.OutputData.$values = [];
            regionAllocationForSave.RegionNode.PreviousYTDForTrueUp = null;
            regionAllocationForSave.RegionNode.AllDatesForCurrentReportingDate = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate();
            regionAllocationForSave.RegionNode.AllMVarDatesForCurrentReportingDate = new clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate();
            regionAllocationForSave.RegionNode.HasPnl = false;
            regionAllocationForSave.RegionNode.HasMVaR = false;
            regionAllocationForSave.RegionNode.IsActive = false;
            regionAllocationForSave.RegionNode.PreviousMonthEndDate = "";
            regionAllocationForSave.RegionNode.PreviousTradeDate = "";
            regionAllocationForSave.RegionNode.HasWorkingCapital = false;
            regionAllocationForSave.DividendPartnerNode = null;
            regionAllocationForSave.BusinessSegmentNode = null;
            this.regionAllocations.push(regionAllocationForSave);
            var selectedRegionAllocationItem = this.regionNamesRegionAllocation.find(function (item) { return item.value == _this.strSelectedRegionAllocationName; });
            if (selectedRegionAllocationItem) {
                this.regionNamesRegionAllocation.splice(this.regionNamesRegionAllocation.indexOf(selectedRegionAllocationItem), 1);
            }
            this.strSelectedRegionAllocationName = "NotSet";
            this.strRegionAllocationPercentage = "0";
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.calculateRegionGroupTotal = function () {
        var total = 0;
        if (this.regionAllocations) {
            this.regionAllocations.forEach(function (region) {
                total += Number(region.Percentage);
            });
        }
        this.strRegionAllocationValueCheck = total.toString();
        if (total != 100) {
            this.clsRegionAllocationValueCheck = {
                invalidData: true
            };
        }
        else {
            this.clsRegionAllocationValueCheck = {};
        }
        return total;
    };
    AppTprHierarchyEditNodeComponent.prototype.onDividendPartnerAddClick = function () {
        var _this = this;
        var selectedDividendPartnerAllocation = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.strSelectedDividendAllocationName; });
        if (selectedDividendPartnerAllocation) {
            var dividendPartnerAllocationForSave = new clsHierarchyEditNode_DividendPartnerAllocations_Values();
            dividendPartnerAllocationForSave.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.AllocationStructureDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            dividendPartnerAllocationForSave.Percentage = Number(this.strDividendAllocationPercentage);
            dividendPartnerAllocationForSave.DividendPartnerNode = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode();
            dividendPartnerAllocationForSave.DividendPartnerNode.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.DividendPartnerNodeDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner();
            var dividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.strSelectedDividendAllocationName; });
            if (dividendPartner) {
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.$type = dividendPartner.$type;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Created = dividendPartner.Created;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.CreatedBy = dividendPartner.CreatedBy;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Id = dividendPartner.Id;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.IsInUse = dividendPartner.IsInUse;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Name = dividendPartner.Name;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Updated = dividendPartner.Updated;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.UpdatedBy = dividendPartner.UpdatedBy;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.Editable = dividendPartner.Editable;
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.BusinessSegment = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment();
                dividendPartnerAllocationForSave.DividendPartnerNode.DividendPartner.BusinessSegment = dividendPartner.BusinessSegment;
            }
            dividendPartnerAllocationForSave.DividendPartnerNode.Name = this.strSelectedDividendAllocationName;
            dividendPartnerAllocationForSave.DividendPartnerNode.Description = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.IsMarkedForDeletion = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.NodeType = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType();
            //let node = this.nodeTypes.find(node => node.Name.toLowerCase() == "dividend partner allocation")
            var systemNodeTypes = JSON.parse(localStorage.getItem("systemNodeTypes"));
            var node = systemNodeTypes.find(function (node) { return node.Name.toLowerCase() == "dividend partner allocation"; });
            if (node) {
                dividendPartnerAllocationForSave.DividendPartnerNode.NodeType = node;
            }
            dividendPartnerAllocationForSave.DividendPartnerNode.IsPnlHolder = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.InputYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.InputExpectedYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.DividendYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.ReportedMEYTD = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.CanRemove = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.InputData = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData();
            dividendPartnerAllocationForSave.DividendPartnerNode.InputData.$values = [];
            dividendPartnerAllocationForSave.DividendPartnerNode.OutputData = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData();
            dividendPartnerAllocationForSave.DividendPartnerNode.OutputData.$values = [];
            dividendPartnerAllocationForSave.DividendPartnerNode.PreviousYTDForTrueUp = null;
            dividendPartnerAllocationForSave.DividendPartnerNode.AllDatesForCurrentReportingDate = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate();
            dividendPartnerAllocationForSave.DividendPartnerNode.AllMVarDatesForCurrentReportingDate = new clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate();
            dividendPartnerAllocationForSave.DividendPartnerNode.HasPnl = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.HasMVaR = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.IsActive = false;
            dividendPartnerAllocationForSave.DividendPartnerNode.PreviousMonthEndDate = "";
            dividendPartnerAllocationForSave.DividendPartnerNode.PreviousTradeDate = "";
            dividendPartnerAllocationForSave.DividendPartnerNode.HasWorkingCapital = false;
            dividendPartnerAllocationForSave.RegionNode = null;
            dividendPartnerAllocationForSave.BusinessSegmentNode = null;
            this.dividendPartnerAllocations.push(dividendPartnerAllocationForSave);
            var selectedDividendPartnerAllocationItem = this.dividendPartnerNames.find(function (item) { return item.value == _this.strSelectedDividendAllocationName; });
            if (selectedDividendPartnerAllocationItem) {
                this.dividendPartnerNames.splice(this.dividendPartnerNames.indexOf(selectedDividendPartnerAllocationItem), 1);
            }
            this.strSelectedDividendAllocationName = "NotSet";
            this.strDividendAllocationPercentage = "0";
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.calculateDividendPartnerGroupTotal = function () {
        var total = 0;
        if (this.dividendPartnerAllocations) {
            this.dividendPartnerAllocations.forEach(function (dividendPartner) {
                total += Number(dividendPartner.Percentage);
            });
        }
        this.strDividendAllocationValueCheck = total.toString();
        if (total > 100) {
            this.clsDividendAllocationValueCheck = {
                invalidData: true
            };
        }
        else {
            this.clsDividendAllocationValueCheck = {};
        }
        return total;
    };
    AppTprHierarchyEditNodeComponent.prototype.onPnlPlanRowSelect = function (event) {
        var _this = this;
        this.selectedPnlPlan = event.data;
        this.strSelectedPnlPlanYear = this.pnlPlanYears[0].value;
        if (this.selectedPnlPlan) {
            this.filteredPnlPlanYearToMonthPerRegion = [];
            this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
                .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.setPnlPlanForRegion = function () {
        var _this = this;
        this.pnlPlans = this.editNodeCompleteData.Plans.$values.filter(function (plan) { return plan.DividendPartner == null; });
        this.pnlPlans.forEach(function (plan) {
            var pnlPlan = new clsPlanDataPerRegion();
            var totalPlanValue = 0;
            var selectedPnlPlanRegion;
            selectedPnlPlanRegion = _this.regionNamesPlanRegionAllocation ? _this.regionNamesPlanRegionAllocation.find(function (region) { return region.value == plan.Region.Name; }) : null;
            if (selectedPnlPlanRegion) {
                _this.regionNamesPlanRegionAllocation.splice(_this.regionNamesPlanRegionAllocation.indexOf(selectedPnlPlanRegion), 1);
            }
            pnlPlan.strRegionName = plan.Region.Name;
            plan.PlanValues.$values.forEach(function (planValue) {
                totalPlanValue += planValue.Value;
                var pnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();
                pnlPlanYearToMonthPerRegion.strRegionName = plan.Region.Name;
                pnlPlanYearToMonthPerRegion.strYear = planValue.Year.toString();
                pnlPlanYearToMonthPerRegion.strMonthValue = planValue.Month.toString();
                pnlPlanYearToMonthPerRegion.strPlanValue = planValue.Value ? planValue.Value.toString() : "0";
                switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                    case "1":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "January";
                        break;
                    case "2":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "February";
                        break;
                    case "3":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "March";
                        break;
                    case "4":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "April";
                        break;
                    case "5":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "May";
                        break;
                    case "6":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "June";
                        break;
                    case "7":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "July";
                        break;
                    case "8":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "August";
                        break;
                    case "9":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "September";
                        break;
                    case "10":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "October";
                        break;
                    case "11":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "November";
                        break;
                    case "12":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "December";
                        break;
                    default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }
                _this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
            });
            pnlPlan.TotalPlan = totalPlanValue;
            pnlPlan.strUpdatedBy = plan.UpdatedBy;
            pnlPlan.strUpdatedDate = plan.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(plan.Updated)) : null;
            _this.pnlPlansArray.push(pnlPlan);
        });
    };
    AppTprHierarchyEditNodeComponent.prototype.onPnlPlanAddClick = function () {
        // use this when passing the data for the pnlPlan vlaues to server.
        // Logic should be like, only those years data should be passed to the server which has atleast one value present for a month in that year.
        // This can be achieved by using following logic -->
        // 1. Get the first year item from the pnlPlanYears array.
        // 2. Loop through the completePnlPlanYearToMonthPerRegion array for that particular year and region and check if there exists any such entry which is having non zero or non null value.
        //    If the entry exists, then move to next year and region combination.
        //    Else, delete the set of entries for that particular region and year combination from the completePnlPlanYearToMonthPerRegion array.
        var _this = this;
        var selectedPnlPlanRegion = this.regions.find(function (region) { return region.Name == _this.strSelectedPnlPlanRegionAllocationName; });
        if (selectedPnlPlanRegion) {
            var newPnlPlanPerRegion = new clsPlanDataPerRegion();
            newPnlPlanPerRegion.strRegionName = this.strSelectedPnlPlanRegionAllocationName;
            newPnlPlanPerRegion.TotalPlan = 0;
            this.pnlPlansArray.push(newPnlPlanPerRegion);
            this.selectedPnlPlan = newPnlPlanPerRegion;
            var currentYear = new Date().getFullYear();
            for (var yearCount = currentYear; yearCount <= (currentYear + 10); yearCount++) {
                for (var monthCount = 1; monthCount <= 12; monthCount++) {
                    var pnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();
                    pnlPlanYearToMonthPerRegion.strYear = yearCount.toString();
                    pnlPlanYearToMonthPerRegion.strPlanValue = "0";
                    pnlPlanYearToMonthPerRegion.strRegionName = this.selectedPnlPlan.strRegionName;
                    pnlPlanYearToMonthPerRegion.strMonthValue = monthCount.toString();
                    switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                        case "1":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "January";
                            break;
                        case "2":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "February";
                            break;
                        case "3":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "March";
                            break;
                        case "4":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "April";
                            break;
                        case "5":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "May";
                            break;
                        case "6":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "June";
                            break;
                        case "7":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "July";
                            break;
                        case "8":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "August";
                            break;
                        case "9":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "September";
                            break;
                        case "10":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "October";
                            break;
                        case "11":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "November";
                            break;
                        case "12":
                            pnlPlanYearToMonthPerRegion.strMonthDesc = "December";
                            break;
                        default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                    }
                    this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
                }
            }
            this.filteredPnlPlanYearToMonthPerRegion = [];
            this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
                .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
            this.strSelectedPnlPlanYear = currentYear.toString();
            var selectedPnlPlanRegionName = this.regionNamesPlanRegionAllocation.find(function (pnlPlanRegion) { return pnlPlanRegion.value == _this.strSelectedPnlPlanRegionAllocationName; });
            if (selectedPnlPlanRegionName) {
                this.regionNamesPlanRegionAllocation.splice(this.regionNamesPlanRegionAllocation.indexOf(selectedPnlPlanRegionName), 1);
            }
            this.strSelectedPnlPlanRegionAllocationName = "NotSet";
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.pnlPlanYearForRegionChange = function () {
        var _this = this;
        var PnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion.find(function (item) { return item.strRegionName == _this.selectedPnlPlan.strRegionName && item.strYear == _this.strSelectedPnlPlanYear; });
        if (PnlPlanYearToMonthPerRegion == null) {
            for (var count = 1; count <= 12; count++) {
                var pnlPlanYearToMonthPerRegion = new clsPnlPlanYearToMonthPerRegion();
                pnlPlanYearToMonthPerRegion.strYear = this.strSelectedPnlPlanYear;
                pnlPlanYearToMonthPerRegion.strPlanValue = "0";
                pnlPlanYearToMonthPerRegion.strRegionName = this.selectedPnlPlan.strRegionName;
                pnlPlanYearToMonthPerRegion.strMonthValue = count.toString();
                switch (pnlPlanYearToMonthPerRegion.strMonthValue) {
                    case "1":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "January";
                        break;
                    case "2":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "February";
                        break;
                    case "3":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "March";
                        break;
                    case "4":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "April";
                        break;
                    case "5":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "May";
                        break;
                    case "6":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "June";
                        break;
                    case "7":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "July";
                        break;
                    case "8":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "August";
                        break;
                    case "9":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "September";
                        break;
                    case "10":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "October";
                        break;
                    case "11":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "November";
                        break;
                    case "12":
                        pnlPlanYearToMonthPerRegion.strMonthDesc = "December";
                        break;
                    default: pnlPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }
                this.completePnlPlanYearToMonthPerRegion.push(pnlPlanYearToMonthPerRegion);
            }
        }
        this.filteredPnlPlanYearToMonthPerRegion = [];
        this.filteredPnlPlanYearToMonthPerRegion = this.completePnlPlanYearToMonthPerRegion
            .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
    };
    AppTprHierarchyEditNodeComponent.prototype.deletePnlPlanForRegion = function (pnlPlan) {
        var _this = this;
        this.blnShowConfirmDialog = true;
        this.confirmationService.confirm({
            message: 'Selected Pnl Plan will be deleted. Are you sure?',
            accept: function () {
                _this.pnlPlansArray.splice(_this.pnlPlansArray.indexOf(pnlPlan), 1);
                _this.regionNamesPlanRegionAllocation.push({ label: pnlPlan.strRegionName, value: pnlPlan.strRegionName });
                // filter the completePnlPlanYearToMonthPerRegion to remove out the items based on the region deleted.
                var filterPnlPlanArray = _this.completePnlPlanYearToMonthPerRegion.filter(function (pnlPlanYearToMonthPerRegion) { return pnlPlanYearToMonthPerRegion.strRegionName != pnlPlan.strRegionName; });
                // reassign the filterred array items list.
                _this.completePnlPlanYearToMonthPerRegion = filterPnlPlanArray;
                _this.selectedPnlPlan = _this.pnlPlansArray && _this.pnlPlansArray.length > 0 ? _this.pnlPlansArray[0] : new clsPlanDataPerRegion();
                _this.filteredPnlPlanYearToMonthPerRegion = [];
                _this.filteredPnlPlanYearToMonthPerRegion = _this.completePnlPlanYearToMonthPerRegion
                    .filter(function (plnPlan) { return plnPlan.strYear == _this.strSelectedPnlPlanYear && plnPlan.strRegionName == _this.selectedPnlPlan.strRegionName; });
                _this.blnShowConfirmDialog = false;
            },
            reject: function () {
                _this.blnShowConfirmDialog = false;
            }
        });
    };
    AppTprHierarchyEditNodeComponent.prototype.onCustomNumericValidation = function (event) {
        return String.fromCharCode(event.charCode).match(/[0-9]/g) != null;
    };
    AppTprHierarchyEditNodeComponent.prototype.calculatePnlPlanPerRegionToYearTotal = function () {
        var _this = this;
        var total = 0;
        var filteredPnlPlanPerRegionPerYear = this.completePnlPlanYearToMonthPerRegion
            .filter(function (plan) { return plan.strRegionName == _this.selectedPnlPlan.strRegionName && plan.strYear == _this.strSelectedPnlPlanYear; });
        filteredPnlPlanPerRegionPerYear.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyEditNodeComponent.prototype.calculateTotalPnlPlanPerRegion = function (event) {
        var _this = this;
        var total = 0;
        var filteredPnlPlanPerRegion = this.completePnlPlanYearToMonthPerRegion
            .filter(function (plan) { return plan.strRegionName == _this.selectedPnlPlan.strRegionName; });
        filteredPnlPlanPerRegion.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        this.selectedPnlPlan.TotalPlan = total;
    };
    AppTprHierarchyEditNodeComponent.prototype.calculatePnlPlanTotal = function () {
        var total = 0;
        this.completePnlPlanYearToMonthPerRegion.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyEditNodeComponent.prototype.setDividendPlanForDividendPartner = function () {
        var _this = this;
        this.dividendPlansArray = [];
        this.dividendPlans = this.editNodeCompleteData.Plans.$values.filter(function (plan) { return plan.DividendPartner != null; });
        this.dividendPlans.forEach(function (plan) {
            var dividendPlan = new clsPlanDataPerDividendPartner();
            var totalPlanValue = 0;
            dividendPlan.strRegionName = plan.Region.Name;
            dividendPlan.strDividendPartnerName = plan.DividendPartner.Name;
            plan.PlanValues.$values.forEach(function (planValue) {
                totalPlanValue += planValue.Value;
                var dividendPlanYearToMonthPerRegion = new clsDividendPlanYearToMonthPerRegion();
                dividendPlanYearToMonthPerRegion.strDividendPartnerName = plan.DividendPartner.Name;
                dividendPlanYearToMonthPerRegion.strRegionName = plan.Region.Name;
                dividendPlanYearToMonthPerRegion.strYear = planValue.Year.toString();
                dividendPlanYearToMonthPerRegion.strMonthValue = planValue.Month.toString();
                dividendPlanYearToMonthPerRegion.strPlanValue = planValue.Value ? planValue.Value.toString() : "0";
                switch (dividendPlanYearToMonthPerRegion.strMonthValue) {
                    case "1":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "January";
                        break;
                    case "2":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "February";
                        break;
                    case "3":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "March";
                        break;
                    case "4":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "April";
                        break;
                    case "5":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "May";
                        break;
                    case "6":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "June";
                        break;
                    case "7":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "July";
                        break;
                    case "8":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "August";
                        break;
                    case "9":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "September";
                        break;
                    case "10":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "October";
                        break;
                    case "11":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "November";
                        break;
                    case "12":
                        dividendPlanYearToMonthPerRegion.strMonthDesc = "December";
                        break;
                    default: dividendPlanYearToMonthPerRegion.strMonthDesc = "Invalid Month";
                }
                _this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerRegion);
            });
            dividendPlan.TotalPlan = totalPlanValue;
            dividendPlan.strUpdatedBy = plan.UpdatedBy;
            dividendPlan.strUpdatedDate = plan.Updated != null ? _this.tprCommonService.getFormattedSystemDate(new Date(plan.Updated)) : null;
            _this.dividendPlansArray.push(dividendPlan);
        });
        this.sortDividendPlanArray();
    };
    AppTprHierarchyEditNodeComponent.prototype.onDividendPlanRowSelect = function (event) {
        var _this = this;
        this.selectedDividendPlan = event.data;
        this.strSelectedDividendPlanYear = this.dividendPlanYears[0].value;
        if (this.selectedDividendPlan) {
            this.filteredDividendPlanYearToMonthPerRegion = [];
            this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
                .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
                && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
                && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.deleteDividendPlanForDividendPartnerAndRegion = function (dividendPlan) {
        var _this = this;
        this.blnShowConfirmDialog = true;
        this.confirmationService.confirm({
            message: 'Selected Dividend Plan will be deleted. Are you sure?',
            accept: function () {
                debugger;
                _this.dividendPlansArray.splice(_this.dividendPlansArray.indexOf(dividendPlan), 1);
                // filter the completeDividendPlanYearToMonthPerRegion to remove out the items based on the region deleted.
                var filterDividendPlanArray = _this.completeDividendPlanYearToMonthPerRegion
                    .filter(function (dividendPlanYearToMonthPerRegion) { return (dividendPlanYearToMonthPerRegion.strRegionName != dividendPlan.strRegionName
                    || dividendPlanYearToMonthPerRegion.strDividendPartnerName != dividendPlan.strDividendPartnerName); });
                // reassign the filterred array items list.
                _this.completeDividendPlanYearToMonthPerRegion = filterDividendPlanArray;
                _this.selectedDividendPlan = _this.dividendPlansArray && _this.dividendPlansArray.length > 0 ? _this.dividendPlansArray[0] : new clsPlanDataPerDividendPartner();
                _this.filteredDividendPlanYearToMonthPerRegion = [];
                _this.filteredDividendPlanYearToMonthPerRegion = _this.completeDividendPlanYearToMonthPerRegion
                    .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
                    && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
                    && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
                _this.blnShowConfirmDialog = false;
            },
            reject: function () {
                _this.blnShowConfirmDialog = false;
            }
        });
    };
    AppTprHierarchyEditNodeComponent.prototype.calculateDividendPlanTotal = function (strDivPartnerName) {
        var total = 0;
        var filteredPlanPerDividendPartner = [];
        filteredPlanPerDividendPartner = this.completeDividendPlanYearToMonthPerRegion.filter(function (plan) { return plan.strDividendPartnerName == strDivPartnerName; });
        filteredPlanPerDividendPartner.forEach(function (plan) {
            total += Number(plan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyEditNodeComponent.prototype.onDividendPlanAddClick = function () {
        var _this = this;
        var itemToBeAddedIndex = this.completeDividendPlanYearToMonthPerRegion.
            findIndex(function (divPlan) { return divPlan.strDividendPartnerName == _this.strSelectedDividendPlanDividendPartnerName
            && divPlan.strRegionName == _this.strSelectedDividendPlanRegionAllocationName; });
        if (itemToBeAddedIndex != -1) {
            alert("The plan for selected dividend partner already exists.\n\n" +
                "You can modify the plan in the table below or delete the existing record and enter a new value.");
        }
        else {
            var selectedDividendPlanRegion = this.regions.find(function (region) { return region.Name == _this.strSelectedDividendPlanRegionAllocationName; });
            var selectedDividendPlanDividendPartner = this.dividendPartnerTypes.find(function (dividendPartner) { return dividendPartner.Name == _this.strSelectedDividendPlanDividendPartnerName; });
            if (selectedDividendPlanRegion && selectedDividendPlanDividendPartner) {
                var newDividendPlanPerDividendPartner = new clsPlanDataPerDividendPartner();
                newDividendPlanPerDividendPartner.strRegionName = this.strSelectedDividendPlanRegionAllocationName;
                newDividendPlanPerDividendPartner.strDividendPartnerName = this.strSelectedDividendPlanDividendPartnerName;
                newDividendPlanPerDividendPartner.TotalPlan = 0;
                this.dividendPlansArray.push(newDividendPlanPerDividendPartner);
                this.selectedDividendPlan = newDividendPlanPerDividendPartner;
                var currentYear = new Date().getFullYear();
                for (var yearCount = currentYear; yearCount <= (currentYear + 10); yearCount++) {
                    for (var monthCount = 1; monthCount <= 12; monthCount++) {
                        var dividendPlanYearToMonthPerDividendPartnerAndRegion = new clsDividendPlanYearToMonthPerRegion();
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strYear = yearCount.toString();
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strPlanValue = "0";
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strRegionName = this.selectedDividendPlan.strRegionName;
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strDividendPartnerName = this.selectedDividendPlan.strDividendPartnerName;
                        dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthValue = monthCount.toString();
                        switch (dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthValue) {
                            case "1":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "January";
                                break;
                            case "2":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "February";
                                break;
                            case "3":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "March";
                                break;
                            case "4":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "April";
                                break;
                            case "5":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "May";
                                break;
                            case "6":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "June";
                                break;
                            case "7":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "July";
                                break;
                            case "8":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "August";
                                break;
                            case "9":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "September";
                                break;
                            case "10":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "October";
                                break;
                            case "11":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "November";
                                break;
                            case "12":
                                dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "December";
                                break;
                            default: dividendPlanYearToMonthPerDividendPartnerAndRegion.strMonthDesc = "Invalid Month";
                        }
                        this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerDividendPartnerAndRegion);
                    }
                }
                this.filteredDividendPlanYearToMonthPerRegion = [];
                this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
                    .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
                    && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
                    && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
                this.strSelectedDividendPlanYear = currentYear.toString();
                this.sortDividendPlanArray();
            }
        }
    };
    AppTprHierarchyEditNodeComponent.prototype.dividendPlanYearForDividendPartnerChange = function () {
        var _this = this;
        var dividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .find(function (item) { return item.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName &&
            item.strRegionName == _this.selectedDividendPlan.strRegionName && item.strYear == _this.strSelectedDividendPlanYear; });
        if (dividendPlanYearToMonthPerRegion == null) {
            for (var count = 1; count <= 12; count++) {
                var dividendPlanYearToMonthPerRegion_1 = new clsDividendPlanYearToMonthPerRegion();
                dividendPlanYearToMonthPerRegion_1.strYear = this.strSelectedDividendPlanYear;
                dividendPlanYearToMonthPerRegion_1.strPlanValue = "0";
                dividendPlanYearToMonthPerRegion_1.strDividendPartnerName = this.selectedDividendPlan.strDividendPartnerName;
                dividendPlanYearToMonthPerRegion_1.strRegionName = this.selectedDividendPlan.strRegionName;
                dividendPlanYearToMonthPerRegion_1.strMonthValue = count.toString();
                switch (dividendPlanYearToMonthPerRegion_1.strMonthValue) {
                    case "1":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "January";
                        break;
                    case "2":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "February";
                        break;
                    case "3":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "March";
                        break;
                    case "4":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "April";
                        break;
                    case "5":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "May";
                        break;
                    case "6":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "June";
                        break;
                    case "7":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "July";
                        break;
                    case "8":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "August";
                        break;
                    case "9":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "September";
                        break;
                    case "10":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "October";
                        break;
                    case "11":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "November";
                        break;
                    case "12":
                        dividendPlanYearToMonthPerRegion_1.strMonthDesc = "December";
                        break;
                    default: dividendPlanYearToMonthPerRegion_1.strMonthDesc = "Invalid Month";
                }
                this.completeDividendPlanYearToMonthPerRegion.push(dividendPlanYearToMonthPerRegion_1);
            }
        }
        this.filteredDividendPlanYearToMonthPerRegion = [];
        this.filteredDividendPlanYearToMonthPerRegion = this.completeDividendPlanYearToMonthPerRegion
            .filter(function (dividendPlan) { return dividendPlan.strYear == _this.strSelectedDividendPlanYear
            && dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
            && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
    };
    AppTprHierarchyEditNodeComponent.prototype.calculateTotalDividendPlanPerDividendPartner = function (event) {
        var _this = this;
        var total = 0;
        var filteredPlanPerDividendPartner = this.completeDividendPlanYearToMonthPerRegion
            .filter(function (dividendPlan) { return dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
            && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName; });
        filteredPlanPerDividendPartner.forEach(function (dividendPlan) {
            total += Number(dividendPlan.strPlanValue);
        });
        this.selectedDividendPlan.TotalPlan = total;
    };
    AppTprHierarchyEditNodeComponent.prototype.calculateDividendPlanPerRegionToYearTotal = function () {
        var _this = this;
        var total = 0;
        var filteredDividendPlanPerRegionPerYear = this.completeDividendPlanYearToMonthPerRegion
            .filter(function (dividendPlan) { return dividendPlan.strRegionName == _this.selectedDividendPlan.strRegionName
            && dividendPlan.strDividendPartnerName == _this.selectedDividendPlan.strDividendPartnerName
            && dividendPlan.strYear == _this.strSelectedDividendPlanYear; });
        filteredDividendPlanPerRegionPerYear.forEach(function (dividendPlan) {
            total += Number(dividendPlan.strPlanValue);
        });
        return total;
    };
    AppTprHierarchyEditNodeComponent.prototype.sortDividendPlanArray = function () {
        this.dividendPlansArray.sort(function (n1, n2) {
            if (n1.strDividendPartnerName > n2.strDividendPartnerName) {
                return 1;
            }
            if (n1.strDividendPartnerName < n2.strDividendPartnerName) {
                return -1;
            }
            return 0;
        });
    };
    AppTprHierarchyEditNodeComponent.prototype.checkIfArrayIsUnique = function (myArray) {
        return myArray.length === new Set(myArray).size;
    };
    AppTprHierarchyEditNodeComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/treeView/app.treeViewEditNode.component.html'
        }), 
        __metadata('design:paramtypes', [app_TPRHierarchyservice_1.TPRHierarchyservice, router_1.Router, router_1.ActivatedRoute, app_TPRNodeTypeService_1.TPRNodeTypeService, primeng_1.ConfirmationService, app_regionService_1.RegionsService, app_TPRProfitAlertGroupsService_1.TPRProfitAlertGroupsService, app_TPRTagsService_1.TPRTagsService, app_TPRDividendPartnersService_1.TPRDividendPartnersService, app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService, app_TPRCommonService_1.TPRCommonService])
    ], AppTprHierarchyEditNodeComponent);
    return AppTprHierarchyEditNodeComponent;
}());
exports.AppTprHierarchyEditNodeComponent = AppTprHierarchyEditNodeComponent;
var NodeArray = (function () {
    function NodeArray() {
    }
    return NodeArray;
}());
var ProfitAlertGroupArray = (function () {
    function ProfitAlertGroupArray() {
    }
    return ProfitAlertGroupArray;
}());
var clsHierarchyEditNode = (function () {
    function clsHierarchyEditNode($type, AlertGroups, BusinessSegmentAllocations, Created, CreatedBy, DividendPartnerAllocations, HasChildren, HierarchyInstanceId, Id, IsMarkedForDeletion, LastUpdatedBy, Level, MVarLimit, MVarRegion, MVarTemporaryLimit, MVarTemporaryLimitExpiryDate, MVarUpdateTiming, Node, NodeType, ParentId, ParentNodeId, Plans, PnlSplitValue, RegionalAllocations, SplitType, Tags, Updated, UpdatedBy, UpdateTiming, WorkingCapitalRegion) {
        if ($type === void 0) { $type = null; }
        if (AlertGroups === void 0) { AlertGroups = null; }
        if (BusinessSegmentAllocations === void 0) { BusinessSegmentAllocations = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (DividendPartnerAllocations === void 0) { DividendPartnerAllocations = ''; }
        if (HasChildren === void 0) { HasChildren = false; }
        if (HierarchyInstanceId === void 0) { HierarchyInstanceId = 0; }
        if (Id === void 0) { Id = 0; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (LastUpdatedBy === void 0) { LastUpdatedBy = null; }
        if (Level === void 0) { Level = 0; }
        if (MVarLimit === void 0) { MVarLimit = null; }
        if (MVarRegion === void 0) { MVarRegion = null; }
        if (MVarTemporaryLimit === void 0) { MVarTemporaryLimit = null; }
        if (MVarTemporaryLimitExpiryDate === void 0) { MVarTemporaryLimitExpiryDate = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (Node === void 0) { Node = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (ParentId === void 0) { ParentId = 0; }
        if (ParentNodeId === void 0) { ParentNodeId = 0; }
        if (Plans === void 0) { Plans = null; }
        if (PnlSplitValue === void 0) { PnlSplitValue = null; }
        if (RegionalAllocations === void 0) { RegionalAllocations = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Tags === void 0) { Tags = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (WorkingCapitalRegion === void 0) { WorkingCapitalRegion = null; }
        this.$type = $type;
        this.AlertGroups = AlertGroups;
        this.BusinessSegmentAllocations = BusinessSegmentAllocations;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.DividendPartnerAllocations = DividendPartnerAllocations;
        this.HasChildren = HasChildren;
        this.HierarchyInstanceId = HierarchyInstanceId;
        this.Id = Id;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.LastUpdatedBy = LastUpdatedBy;
        this.Level = Level;
        this.MVarLimit = MVarLimit;
        this.MVarRegion = MVarRegion;
        this.MVarTemporaryLimit = MVarTemporaryLimit;
        this.MVarTemporaryLimitExpiryDate = MVarTemporaryLimitExpiryDate;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.Node = Node;
        this.NodeType = NodeType;
        this.ParentId = ParentId;
        this.ParentNodeId = ParentNodeId;
        this.Plans = Plans;
        this.PnlSplitValue = PnlSplitValue;
        this.RegionalAllocations = RegionalAllocations;
        this.SplitType = SplitType;
        this.Tags = Tags;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.UpdateTiming = UpdateTiming;
        this.WorkingCapitalRegion = WorkingCapitalRegion;
    }
    return clsHierarchyEditNode;
}());
var clsHierarchyEditNode_Node = (function () {
    function clsHierarchyEditNode_Node($type, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = null; }
        if (OutputData === void 0) { OutputData = null; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = null; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = null; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = null; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = null; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node;
}());
var clsHierarchyEditNode_Node_NodeType = (function () {
    function clsHierarchyEditNode_Node_NodeType($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = ''; }
        if (CreatedBy === void 0) { CreatedBy = ''; }
        if (Updated === void 0) { Updated = ''; }
        if (UpdatedBy === void 0) { UpdatedBy = ''; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node_NodeType;
}());
var clsHierarchyEditNode_Node_InputData = (function () {
    function clsHierarchyEditNode_Node_InputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_InputData;
}());
var clsHierarchyEditNode_Node_OutputData = (function () {
    function clsHierarchyEditNode_Node_OutputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_OutputData;
}());
var clsHierarchyEditNode_Node_AllDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_Node_AllDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_AllDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_Node_InputNameMappings = (function () {
    function clsHierarchyEditNode_Node_InputNameMappings($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Node_InputNameMappings;
}());
var RootValue = (function () {
    function RootValue(label, NodeName, id, children, Children, data, icon, expandedIcon, collapsedIcon, leaf, expanded, type, parent, partialSelected, $type, HasAnyOutputData, HasPlans, UpdateTiming, NodeId, NodeType, IsActive, Level, ParentId, IsPnlHolder, MVarUpdateTiming, SplitType, Id) {
        if (label === void 0) { label = null; }
        if (NodeName === void 0) { NodeName = null; }
        if (id === void 0) { id = 0; }
        if (children === void 0) { children = null; }
        if (Children === void 0) { Children = null; }
        if (data === void 0) { data = null; }
        if (icon === void 0) { icon = null; }
        if (expandedIcon === void 0) { expandedIcon = null; }
        if (collapsedIcon === void 0) { collapsedIcon = null; }
        if (leaf === void 0) { leaf = null; }
        if (expanded === void 0) { expanded = null; }
        if (type === void 0) { type = null; }
        if (parent === void 0) { parent = null; }
        if (partialSelected === void 0) { partialSelected = null; }
        if ($type === void 0) { $type = null; }
        if (HasAnyOutputData === void 0) { HasAnyOutputData = null; }
        if (HasPlans === void 0) { HasPlans = null; }
        if (UpdateTiming === void 0) { UpdateTiming = null; }
        if (NodeId === void 0) { NodeId = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsActive === void 0) { IsActive = null; }
        if (Level === void 0) { Level = null; }
        if (ParentId === void 0) { ParentId = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = null; }
        if (SplitType === void 0) { SplitType = null; }
        if (Id === void 0) { Id = 0; }
        this.label = label;
        this.NodeName = NodeName;
        this.id = id;
        this.children = children;
        this.Children = Children;
        this.data = data;
        this.icon = icon;
        this.expandedIcon = expandedIcon;
        this.collapsedIcon = collapsedIcon;
        this.leaf = leaf;
        this.expanded = expanded;
        this.type = type;
        this.parent = parent;
        this.partialSelected = partialSelected;
        this.$type = $type;
        this.HasAnyOutputData = HasAnyOutputData;
        this.HasPlans = HasPlans;
        this.UpdateTiming = UpdateTiming;
        this.NodeId = NodeId;
        this.NodeType = NodeType;
        this.IsActive = IsActive;
        this.Level = Level;
        this.ParentId = ParentId;
        this.IsPnlHolder = IsPnlHolder;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.SplitType = SplitType;
        this.Id = Id;
    }
    return RootValue;
}());
var clsHierarchyEditNode_Node_InputNameMappings_Value = (function () {
    function clsHierarchyEditNode_Node_InputNameMappings_Value($type, Name, FeedSource, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (FeedSource === void 0) { FeedSource = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.FeedSource = FeedSource;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Node_InputNameMappings_Value;
}());
var clsHierarchyEditNode_WorkingCapital = (function () {
    function clsHierarchyEditNode_WorkingCapital($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_WorkingCapital;
}());
var clsHierarchyEditNode_AlertGroups = (function () {
    function clsHierarchyEditNode_AlertGroups($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_AlertGroups;
}());
var clsHierarchyEditNode_AlertGroups_Values = (function () {
    function clsHierarchyEditNode_AlertGroups_Values($type, Alerts, Name, Members, IsInUse, UpdateTiming, TradeDate, ProfitAlertGroupStatusId, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Alerts === void 0) { Alerts = null; }
        if (Name === void 0) { Name = null; }
        if (Members === void 0) { Members = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (UpdateTiming === void 0) { UpdateTiming = 0; }
        if (TradeDate === void 0) { TradeDate = null; }
        if (ProfitAlertGroupStatusId === void 0) { ProfitAlertGroupStatusId = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Alerts = Alerts;
        this.Name = Name;
        this.Members = Members;
        this.IsInUse = IsInUse;
        this.UpdateTiming = UpdateTiming;
        this.TradeDate = TradeDate;
        this.ProfitAlertGroupStatusId = ProfitAlertGroupStatusId;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_AlertGroups_Values;
}());
var clsHierarchyEditNode_AlertGroups_Values_Alerts = (function () {
    function clsHierarchyEditNode_AlertGroups_Values_Alerts($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_AlertGroups_Values_Alerts;
}());
var clsHierarchyEditNode_AlertGroups_Values_Alerts_Values = (function () {
    function clsHierarchyEditNode_AlertGroups_Values_Alerts_Values($type, ActionAlerts, AlertGroupType, Level, AlertGroupId, CurrentActionAlertExpiryDate, CurrentActionAlertLevel, Actual, StatusId, SystemIsNew, SystemIsTriggered, SystemTriggeredDate, UserIsNew, UserIsTriggered, UserTriggeredDate, ReportedIsNew, ReportedIsTriggered, ReportedTriggeredDate, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (ActionAlerts === void 0) { ActionAlerts = null; }
        if (AlertGroupType === void 0) { AlertGroupType = 0; }
        if (Level === void 0) { Level = 0; }
        if (AlertGroupId === void 0) { AlertGroupId = 0; }
        if (CurrentActionAlertExpiryDate === void 0) { CurrentActionAlertExpiryDate = null; }
        if (CurrentActionAlertLevel === void 0) { CurrentActionAlertLevel = null; }
        if (Actual === void 0) { Actual = null; }
        if (StatusId === void 0) { StatusId = null; }
        if (SystemIsNew === void 0) { SystemIsNew = false; }
        if (SystemIsTriggered === void 0) { SystemIsTriggered = false; }
        if (SystemTriggeredDate === void 0) { SystemTriggeredDate = null; }
        if (UserIsNew === void 0) { UserIsNew = null; }
        if (UserIsTriggered === void 0) { UserIsTriggered = null; }
        if (UserTriggeredDate === void 0) { UserTriggeredDate = null; }
        if (ReportedIsNew === void 0) { ReportedIsNew = false; }
        if (ReportedIsTriggered === void 0) { ReportedIsTriggered = false; }
        if (ReportedTriggeredDate === void 0) { ReportedTriggeredDate = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.ActionAlerts = ActionAlerts;
        this.AlertGroupType = AlertGroupType;
        this.Level = Level;
        this.AlertGroupId = AlertGroupId;
        this.CurrentActionAlertExpiryDate = CurrentActionAlertExpiryDate;
        this.CurrentActionAlertLevel = CurrentActionAlertLevel;
        this.Actual = Actual;
        this.StatusId = StatusId;
        this.SystemIsNew = SystemIsNew;
        this.SystemIsTriggered = SystemIsTriggered;
        this.SystemTriggeredDate = SystemTriggeredDate;
        this.UserIsNew = UserIsNew;
        this.UserIsTriggered = UserIsTriggered;
        this.UserTriggeredDate = UserTriggeredDate;
        this.ReportedIsNew = ReportedIsNew;
        this.ReportedIsTriggered = ReportedIsTriggered;
        this.ReportedTriggeredDate = ReportedTriggeredDate;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_AlertGroups_Values_Alerts_Values;
}());
var clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts = (function () {
    function clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts;
}());
var clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values = (function () {
    function clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values($type, AlertId, AlertGroupId, Level, StartDate, EndDate, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (AlertId === void 0) { AlertId = 0; }
        if (AlertGroupId === void 0) { AlertGroupId = 0; }
        if (Level === void 0) { Level = 0; }
        if (StartDate === void 0) { StartDate = null; }
        if (EndDate === void 0) { EndDate = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.AlertId = AlertId;
        this.AlertGroupId = AlertGroupId;
        this.Level = Level;
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values;
}());
var clsHierarchyEditNode_AlertGroups_Values_Members = (function () {
    function clsHierarchyEditNode_AlertGroups_Values_Members($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_AlertGroups_Values_Members;
}());
var clsHierarchyEditNode_AlertGroups_Values_Members_Values = (function () {
    function clsHierarchyEditNode_AlertGroups_Values_Members_Values($type, Name, NodeId, StructureId, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (NodeId === void 0) { NodeId = 0; }
        if (StructureId === void 0) { StructureId = 0; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.NodeId = NodeId;
        this.StructureId = StructureId;
        this.Id = Id;
    }
    return clsHierarchyEditNode_AlertGroups_Values_Members_Values;
}());
var clsHierarchyEditNode_MVarRegion = (function () {
    function clsHierarchyEditNode_MVarRegion($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_MVarRegion;
}());
var clsHierarchyEditNode_Tags_Values = (function () {
    function clsHierarchyEditNode_Tags_Values($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Tags_Values;
}());
var TagsValue = (function () {
    function TagsValue($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return TagsValue;
}());
var clsHierarchyEditNode_RegionalAllocations = (function () {
    function clsHierarchyEditNode_RegionalAllocations($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations;
}());
var clsHierarchyEditNode_RegionalAllocations_Values = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode($type, Region, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Region === void 0) { Region = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = null; }
        if (OutputData === void 0) { OutputData = null; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = null; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = null; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = null; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Region = Region;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_DividendPartnerAllocations = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = null; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode($type, DividendPartner, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (DividendPartner === void 0) { DividendPartner = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = null; }
        if (OutputData === void 0) { OutputData = null; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = null; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = null; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = null; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.DividendPartner = DividendPartner;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner($type, Name, IsInUse, BusinessSegment, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (BusinessSegment === void 0) { BusinessSegment = null; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.BusinessSegment = BusinessSegment;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate = (function () {
    function clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate;
}());
var clsHierarchyEditNode_Plans = (function () {
    function clsHierarchyEditNode_Plans($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Plans;
}());
var clsHierarchyEditNode_Plans_Values = (function () {
    function clsHierarchyEditNode_Plans_Values($type, DividendPartner, Region, PlanValues, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (DividendPartner === void 0) { DividendPartner = null; }
        if (Region === void 0) { Region = null; }
        if (PlanValues === void 0) { PlanValues = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.DividendPartner = DividendPartner;
        this.Region = Region;
        this.PlanValues = PlanValues;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Plans_Values;
}());
var clsHierarchyEditNode_Plans_Values_DividendPartner = (function () {
    function clsHierarchyEditNode_Plans_Values_DividendPartner($type, Name, IsInUse, BusinessSegment, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (BusinessSegment === void 0) { BusinessSegment = null; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.BusinessSegment = BusinessSegment;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Plans_Values_DividendPartner;
}());
var clsHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment = (function () {
    function clsHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment;
}());
var clsHierarchyEditNode_Plans_Values_Region = (function () {
    function clsHierarchyEditNode_Plans_Values_Region($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Plans_Values_Region;
}());
var clsHierarchyEditNode_Plans_Values_PlanValues = (function () {
    function clsHierarchyEditNode_Plans_Values_PlanValues($type, $values) {
        if ($type === void 0) { $type = null; }
        if ($values === void 0) { $values = []; }
        this.$type = $type;
        this.$values = $values;
    }
    return clsHierarchyEditNode_Plans_Values_PlanValues;
}());
var clsHierarchyEditNode_Plans_Values_PlanValues_Values = (function () {
    function clsHierarchyEditNode_Plans_Values_PlanValues_Values($type, Year, Month, Value, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Year === void 0) { Year = 0; }
        if (Month === void 0) { Month = 0; }
        if (Value === void 0) { Value = 0; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Year = Year;
        this.Month = Month;
        this.Value = Value;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyEditNode_Plans_Values_PlanValues_Values;
}());
var clsPlanDataPerRegion = (function () {
    function clsPlanDataPerRegion(strRegionName, TotalPlan, strUpdatedBy, strUpdatedDate) {
        if (strRegionName === void 0) { strRegionName = null; }
        if (TotalPlan === void 0) { TotalPlan = 0; }
        if (strUpdatedBy === void 0) { strUpdatedBy = null; }
        if (strUpdatedDate === void 0) { strUpdatedDate = null; }
        this.strRegionName = strRegionName;
        this.TotalPlan = TotalPlan;
        this.strUpdatedBy = strUpdatedBy;
        this.strUpdatedDate = strUpdatedDate;
    }
    return clsPlanDataPerRegion;
}());
var clsPnlPlanYearToMonthPerRegion = (function () {
    function clsPnlPlanYearToMonthPerRegion(strRegionName, strYear, strMonthDesc, strMonthValue, strPlanValue) {
        if (strRegionName === void 0) { strRegionName = null; }
        if (strYear === void 0) { strYear = null; }
        if (strMonthDesc === void 0) { strMonthDesc = null; }
        if (strMonthValue === void 0) { strMonthValue = null; }
        if (strPlanValue === void 0) { strPlanValue = null; }
        this.strRegionName = strRegionName;
        this.strYear = strYear;
        this.strMonthDesc = strMonthDesc;
        this.strMonthValue = strMonthValue;
        this.strPlanValue = strPlanValue;
    }
    return clsPnlPlanYearToMonthPerRegion;
}());
var clsPlanDataPerDividendPartner = (function () {
    function clsPlanDataPerDividendPartner(strDividendPartnerName, strRegionName, TotalPlan, strUpdatedBy, strUpdatedDate) {
        if (strDividendPartnerName === void 0) { strDividendPartnerName = ''; }
        if (strRegionName === void 0) { strRegionName = ''; }
        if (TotalPlan === void 0) { TotalPlan = 0; }
        if (strUpdatedBy === void 0) { strUpdatedBy = null; }
        if (strUpdatedDate === void 0) { strUpdatedDate = null; }
        this.strDividendPartnerName = strDividendPartnerName;
        this.strRegionName = strRegionName;
        this.TotalPlan = TotalPlan;
        this.strUpdatedBy = strUpdatedBy;
        this.strUpdatedDate = strUpdatedDate;
    }
    return clsPlanDataPerDividendPartner;
}());
var clsDividendPlanYearToMonthPerRegion = (function () {
    function clsDividendPlanYearToMonthPerRegion(strDividendPartnerName, strRegionName, strYear, strMonthDesc, strMonthValue, strPlanValue) {
        if (strDividendPartnerName === void 0) { strDividendPartnerName = null; }
        if (strRegionName === void 0) { strRegionName = null; }
        if (strYear === void 0) { strYear = null; }
        if (strMonthDesc === void 0) { strMonthDesc = null; }
        if (strMonthValue === void 0) { strMonthValue = null; }
        if (strPlanValue === void 0) { strPlanValue = null; }
        this.strDividendPartnerName = strDividendPartnerName;
        this.strRegionName = strRegionName;
        this.strYear = strYear;
        this.strMonthDesc = strMonthDesc;
        this.strMonthValue = strMonthValue;
        this.strPlanValue = strPlanValue;
    }
    return clsDividendPlanYearToMonthPerRegion;
}());
/* Post node data starts here */
var clsHierarchyNodePostData = (function () {
    function clsHierarchyNodePostData($type, AlertGroups, BusinessSegmentAllocations, // change later
        Created, CreatedBy, DividendPartnerAllocations, HasChildren, HierarchyInstanceId, Id, IsMarkedForDeletion, LastUpdatedBy, Level, MVarLimit, // change later
        MVarRegion, MVarTemporaryLimit, // change later
        MVarTemporaryLimitExpiryDate, // change later
        MVarUpdateTiming, Node, NodeType, //change later
        ParentId, ParentNodeId, Plans, PnlSplitValue, // change later
        RegionalAllocations, SplitType, // change later
        Tags, Updated, UpdatedBy, UpdateTiming, WorkingCapitalRegion) {
        if ($type === void 0) { $type = null; }
        if (AlertGroups === void 0) { AlertGroups = []; }
        if (BusinessSegmentAllocations === void 0) { BusinessSegmentAllocations = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (DividendPartnerAllocations === void 0) { DividendPartnerAllocations = []; }
        if (HasChildren === void 0) { HasChildren = false; }
        if (HierarchyInstanceId === void 0) { HierarchyInstanceId = 0; }
        if (Id === void 0) { Id = 0; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (LastUpdatedBy === void 0) { LastUpdatedBy = null; }
        if (Level === void 0) { Level = null; }
        if (MVarLimit === void 0) { MVarLimit = null; }
        if (MVarRegion === void 0) { MVarRegion = null; }
        if (MVarTemporaryLimit === void 0) { MVarTemporaryLimit = null; }
        if (MVarTemporaryLimitExpiryDate === void 0) { MVarTemporaryLimitExpiryDate = null; }
        if (MVarUpdateTiming === void 0) { MVarUpdateTiming = 0; }
        if (Node === void 0) { Node = null; }
        if (NodeType === void 0) { NodeType = null; }
        if (ParentId === void 0) { ParentId = 0; }
        if (ParentNodeId === void 0) { ParentNodeId = 0; }
        if (Plans === void 0) { Plans = []; }
        if (PnlSplitValue === void 0) { PnlSplitValue = null; }
        if (RegionalAllocations === void 0) { RegionalAllocations = []; }
        if (SplitType === void 0) { SplitType = null; }
        if (Tags === void 0) { Tags = []; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (UpdateTiming === void 0) { UpdateTiming = 0; }
        if (WorkingCapitalRegion === void 0) { WorkingCapitalRegion = null; }
        this.$type = $type;
        this.AlertGroups = AlertGroups;
        this.BusinessSegmentAllocations = BusinessSegmentAllocations;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.DividendPartnerAllocations = DividendPartnerAllocations;
        this.HasChildren = HasChildren;
        this.HierarchyInstanceId = HierarchyInstanceId;
        this.Id = Id;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.LastUpdatedBy = LastUpdatedBy;
        this.Level = Level;
        this.MVarLimit = MVarLimit;
        this.MVarRegion = MVarRegion;
        this.MVarTemporaryLimit = MVarTemporaryLimit;
        this.MVarTemporaryLimitExpiryDate = MVarTemporaryLimitExpiryDate;
        this.MVarUpdateTiming = MVarUpdateTiming;
        this.Node = Node;
        this.NodeType = NodeType;
        this.ParentId = ParentId;
        this.ParentNodeId = ParentNodeId;
        this.Plans = Plans;
        this.PnlSplitValue = PnlSplitValue;
        this.RegionalAllocations = RegionalAllocations;
        this.SplitType = SplitType;
        this.Tags = Tags;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.UpdateTiming = UpdateTiming;
        this.WorkingCapitalRegion = WorkingCapitalRegion;
    }
    return clsHierarchyNodePostData;
}());
var clsHierarchyNodePostData_Alerts = (function () {
    function clsHierarchyNodePostData_Alerts($type, Alerts, Name, Members, IsInUse, UpdateTiming, TradeDate, ProfitAlertGroupStatusId, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Alerts === void 0) { Alerts = []; }
        if (Name === void 0) { Name = null; }
        if (Members === void 0) { Members = []; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (UpdateTiming === void 0) { UpdateTiming = 0; }
        if (TradeDate === void 0) { TradeDate = null; }
        if (ProfitAlertGroupStatusId === void 0) { ProfitAlertGroupStatusId = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Alerts = Alerts;
        this.Name = Name;
        this.Members = Members;
        this.IsInUse = IsInUse;
        this.UpdateTiming = UpdateTiming;
        this.TradeDate = TradeDate;
        this.ProfitAlertGroupStatusId = ProfitAlertGroupStatusId;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Alerts;
}());
var clsHierarchyNodePostData_Node = (function () {
    function clsHierarchyNodePostData_Node($type, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = 0; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = []; }
        if (OutputData === void 0) { OutputData = []; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = []; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = []; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = []; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Node;
}());
var clsHierarchyNodePostData_RegionalAllocations = (function () {
    function clsHierarchyNodePostData_RegionalAllocations($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_RegionalAllocations;
}());
var clsHierarchyNodePostData_RegionalAllocations_RegionNode = (function () {
    function clsHierarchyNodePostData_RegionalAllocations_RegionNode($type, Region, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Region === void 0) { Region = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = []; }
        if (OutputData === void 0) { OutputData = []; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = []; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = []; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = []; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Region = Region;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_RegionalAllocations_RegionNode;
}());
var clsHierarchyNodePostData_DividendPartnerAllocations = (function () {
    function clsHierarchyNodePostData_DividendPartnerAllocations($type, Percentage, RegionNode, DividendPartnerNode, BusinessSegmentNode, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Percentage === void 0) { Percentage = 0; }
        if (RegionNode === void 0) { RegionNode = null; }
        if (DividendPartnerNode === void 0) { DividendPartnerNode = null; }
        if (BusinessSegmentNode === void 0) { BusinessSegmentNode = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Percentage = Percentage;
        this.RegionNode = RegionNode;
        this.DividendPartnerNode = DividendPartnerNode;
        this.BusinessSegmentNode = BusinessSegmentNode;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_DividendPartnerAllocations;
}());
var clsHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode = (function () {
    function clsHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode($type, DividendPartner, Name, Description, IsMarkedForDeletion, NodeType, IsPnlHolder, InputYTD, InputExpectedYTD, DividendYTD, ReportedMEYTD, CanRemove, InputData, OutputData, PreviousYTDForTrueUp, AllDatesForCurrentReportingDate, AllMVarDatesForCurrentReportingDate, HasPnl, HasMVaR, IsActive, InputNameMappings, PreviousMonthEndDate, PreviousTradeDate, HasWorkingCapital, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (DividendPartner === void 0) { DividendPartner = null; }
        if (Name === void 0) { Name = null; }
        if (Description === void 0) { Description = null; }
        if (IsMarkedForDeletion === void 0) { IsMarkedForDeletion = false; }
        if (NodeType === void 0) { NodeType = null; }
        if (IsPnlHolder === void 0) { IsPnlHolder = false; }
        if (InputYTD === void 0) { InputYTD = null; }
        if (InputExpectedYTD === void 0) { InputExpectedYTD = null; }
        if (DividendYTD === void 0) { DividendYTD = null; }
        if (ReportedMEYTD === void 0) { ReportedMEYTD = null; }
        if (CanRemove === void 0) { CanRemove = false; }
        if (InputData === void 0) { InputData = []; }
        if (OutputData === void 0) { OutputData = []; }
        if (PreviousYTDForTrueUp === void 0) { PreviousYTDForTrueUp = 0; }
        if (AllDatesForCurrentReportingDate === void 0) { AllDatesForCurrentReportingDate = []; }
        if (AllMVarDatesForCurrentReportingDate === void 0) { AllMVarDatesForCurrentReportingDate = []; }
        if (HasPnl === void 0) { HasPnl = false; }
        if (HasMVaR === void 0) { HasMVaR = false; }
        if (IsActive === void 0) { IsActive = false; }
        if (InputNameMappings === void 0) { InputNameMappings = []; }
        if (PreviousMonthEndDate === void 0) { PreviousMonthEndDate = null; }
        if (PreviousTradeDate === void 0) { PreviousTradeDate = null; }
        if (HasWorkingCapital === void 0) { HasWorkingCapital = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.DividendPartner = DividendPartner;
        this.Name = Name;
        this.Description = Description;
        this.IsMarkedForDeletion = IsMarkedForDeletion;
        this.NodeType = NodeType;
        this.IsPnlHolder = IsPnlHolder;
        this.InputYTD = InputYTD;
        this.InputExpectedYTD = InputExpectedYTD;
        this.DividendYTD = DividendYTD;
        this.ReportedMEYTD = ReportedMEYTD;
        this.CanRemove = CanRemove;
        this.InputData = InputData;
        this.OutputData = OutputData;
        this.PreviousYTDForTrueUp = PreviousYTDForTrueUp;
        this.AllDatesForCurrentReportingDate = AllDatesForCurrentReportingDate;
        this.AllMVarDatesForCurrentReportingDate = AllMVarDatesForCurrentReportingDate;
        this.HasPnl = HasPnl;
        this.HasMVaR = HasMVaR;
        this.IsActive = IsActive;
        this.InputNameMappings = InputNameMappings;
        this.PreviousMonthEndDate = PreviousMonthEndDate;
        this.PreviousTradeDate = PreviousTradeDate;
        this.HasWorkingCapital = HasWorkingCapital;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode;
}());
var clsHierarchyNodePostData_Plans = (function () {
    function clsHierarchyNodePostData_Plans($type, DividendPartner, Region, PlanValues, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (DividendPartner === void 0) { DividendPartner = null; }
        if (Region === void 0) { Region = null; }
        if (PlanValues === void 0) { PlanValues = []; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.DividendPartner = DividendPartner;
        this.Region = Region;
        this.PlanValues = PlanValues;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans;
}());
var clsHierarchyNodePostData_Plans_DividendPartner = (function () {
    function clsHierarchyNodePostData_Plans_DividendPartner($type, Name, IsInUse, BusinessSegment, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (BusinessSegment === void 0) { BusinessSegment = null; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.BusinessSegment = BusinessSegment;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_DividendPartner;
}());
var clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment = (function () {
    function clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_DividendPartner_BusinessSegment;
}());
var clsHierarchyNodePostData_Plans_Region = (function () {
    function clsHierarchyNodePostData_Plans_Region($type, Name, IsInUse, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_Region;
}());
var clsHierarchyNodePostData_Plans_PlanValues = (function () {
    function clsHierarchyNodePostData_Plans_PlanValues($type, Year, Month, Value, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Year === void 0) { Year = 0; }
        if (Month === void 0) { Month = 0; }
        if (Value === void 0) { Value = 0; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Year = Year;
        this.Month = Month;
        this.Value = Value;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return clsHierarchyNodePostData_Plans_PlanValues;
}());
/* Post node data ends here */ 
//# sourceMappingURL=app.treeViewEditNode.component.js.map