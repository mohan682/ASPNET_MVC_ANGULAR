"use strict";
var testing_1 = require('@angular/core/testing');
var platform_browser_1 = require('@angular/platform-browser');
var app_dividendPartners_component_1 = require('./app.dividendPartners.component');
var app_TPRDividendPartnersService_1 = require('../../service/app.TPRDividendPartnersService');
var app_TPRBusinessSegmentsService_1 = require('../../service/app.TPRBusinessSegmentsService');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var testing_2 = require('../../../testing');
describe('AppDividendPartnersComponent test cases', function () {
    var de;
    var comp;
    var fixture;
    var dividendPartnerService;
    var businessSegmentService;
    var spy;
    //async before each
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [app_dividendPartners_component_1.AppDividendPartnersComponent],
            imports: [],
            providers: [app_TPRDividendPartnersService_1.TPRDividendPartnersService, app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(app_dividendPartners_component_1.AppDividendPartnersComponent); // creates the fixture of the testing component
        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });
    // test whether the component got successfully initialised
    it('should create component', function () { return expect(comp).toBeDefined(); });
    // test for service mockup
    // DividendPartner service actually injected to the component.
    dividendPartnerService = fixture.debugElement.injector.get(app_TPRDividendPartnersService_1.TPRDividendPartnersService);
    // BusinessPartner service actually injected to the component.
    businessSegmentService = fixture.debugElement.injector.get(app_TPRBusinessSegmentsService_1.TPRBusinessSegmentsService);
    // Create test mockup class
    var dividendPartnerMockUp = new DividendPartnerTypesValueMockup();
    var businessPartnerMockUp = new BusinessSegmentTypeMockup();
    var dividendPartnerTypes;
    var businessSegments;
    it('should not call the getDividendPartnersObservable method before OnInit', function () {
        // Setup spy on the 'getDividendPartnersObservable' method
        spy = spyOn(dividendPartnerService, 'getDividendPartnersObservable')
            .and.returnValue(Promise.resolve(dividendPartnerMockUp));
        expect(spy.calls.any()).toBe(false, 'getDividendPartnersObservable not yet called');
    });
    it('should not call the getBusinessSegmentsObservable method before OnInit', function () {
        // Setup spy on the 'getBusinessSegmentsObservable' method
        spy = spyOn(businessSegmentService, 'getBusinessSegmentsObservable')
            .and.returnValue(Promise.resolve(businessPartnerMockUp));
        expect(spy.calls.any()).toBe(false, 'getBusinessSegmentsObservable not yet called');
    });
    it('should not call the getDividendPartnersObservable method before OnInit', function () {
        // Setup spy on the 'getDividendPartnersObservable' method
        spy = spyOn(dividendPartnerService, 'getDividendPartnersObservable')
            .and.returnValue(Promise.resolve(dividendPartnerMockUp));
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(false, 'getDividendPartnersObservable not yet called');
    });
    it('should not call the getBusinessSegmentsObservable method before OnInit', function () {
        // Setup spy on the 'getBusinessSegmentsObservable' method
        spy = spyOn(businessSegmentService, 'getBusinessSegmentsObservable')
            .and.returnValue(Promise.resolve(businessPartnerMockUp));
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(false, 'getBusinessSegmentsObservable not yet called');
    });
    it('should raise Add button click event', function () {
        var displayDialog = true;
        var newDividendPartnerType = true;
        var blnValidationResult = true;
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnAdd'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newDividendPartnerType).toBe(newDividendPartnerType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });
    it('should raise Save button click event', function () {
        // Creating testmockup object
        var businessPartnerType = new BusinessSegmentTypeMockup('', 'Test', false, false, '', '', '', '', 0);
        var dividendPartnersType = new DividendPartnerTypesValueMockup('', 'Test', false, businessPartnerType, false, '', '', '', '', 0);
        comp.dividendPartnersType = dividendPartnersType; // initializing the dividendPartnersType object with the test mockup object
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.dividendPartnerTypes.indexOf(dividendPartnersType)).toBeGreaterThan(-1);
    });
    it('should raise SavetoDatabase button click event', function () {
        var blnPushDataToDatabase = true;
        var blnSavedOrDeleted = true;
        var strSavedMessage = "Data saved successfully";
        de = fixture.debugElement.query(platform_browser_1.By.css('#btnSaveDataToServer'));
        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(dividendPartnerService, 'updateDividendPartnersObservable')
            .and.returnValue(Promise.resolve(dividendPartnerMockUp));
        //de.triggerEventHandler('click', null);
        testing_2.click(de); // click triggerEventHandler helper method
        fixture.detectChanges();
        expect(spy.calls.any()).toBe(true, 'updateDividendPartnersObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});
var DividendPartnerTypesValueMockup = (function () {
    function DividendPartnerTypesValueMockup($type, Name, IsInUse, BusinessSegment, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = true; }
        if (BusinessSegment === void 0) { BusinessSegment = null; }
        if (Editable === void 0) { Editable = true; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.BusinessSegment = BusinessSegment;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return DividendPartnerTypesValueMockup;
}());
var BusinessSegmentTypeMockup = (function () {
    function BusinessSegmentTypeMockup($type, Name, IsInUse, Editable, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Editable === void 0) { Editable = false; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Editable = Editable;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return BusinessSegmentTypeMockup;
}());
//# sourceMappingURL=app.dividendPartners.component.spec.js.map