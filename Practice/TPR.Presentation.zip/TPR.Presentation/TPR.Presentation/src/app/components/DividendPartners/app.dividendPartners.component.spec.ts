﻿import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AppDividendPartnersComponent } from './app.dividendPartners.component';
import { TPRDividendPartnersService } from '../../service/app.TPRDividendPartnersService';
import { TPRBusinessSegmentsService } from '../../service/app.TPRBusinessSegmentsService';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { addMatchers, click } from '../../../testing';

import IDividendPartnerValue = DividendPartnerNameSpace.IDividendPartnerValue;
import IBusinessSegment = DividendPartnerNameSpace.IBusinessSegment;


describe('AppDividendPartnersComponent test cases', () => {
    let de: DebugElement;
    let comp: AppDividendPartnersComponent;
    let fixture: ComponentFixture<AppDividendPartnersComponent>;
    let dividendPartnerService: TPRDividendPartnersService;
    let businessSegmentService: TPRBusinessSegmentsService;
    let spy: jasmine.Spy;

    //async before each
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AppDividendPartnersComponent],
            imports: [],
            providers: [TPRDividendPartnersService, TPRBusinessSegmentsService],
            schemas: []
        }).compileComponents(); // compiles the external templates and css files into inline
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AppDividendPartnersComponent); // creates the fixture of the testing component

        comp = fixture.componentInstance; // creates the instance of the fixture under consideration
    });

    // test whether the component got successfully initialised
    it('should create component', () => expect(comp).toBeDefined());

    // test for service mockup
    // DividendPartner service actually injected to the component.
    dividendPartnerService = fixture.debugElement.injector.get(TPRDividendPartnersService);

    // BusinessPartner service actually injected to the component.
    businessSegmentService = fixture.debugElement.injector.get(TPRBusinessSegmentsService);

    // Create test mockup class
    let dividendPartnerMockUp: DividendPartnerTypesValueMockup = new DividendPartnerTypesValueMockup();
    let businessPartnerMockUp: BusinessSegmentTypeMockup = new BusinessSegmentTypeMockup();

    let dividendPartnerTypes: IDividendPartnerValue[];
    let businessSegments: IBusinessSegment[];

    it('should not call the getDividendPartnersObservable method before OnInit', () => {
        // Setup spy on the 'getDividendPartnersObservable' method
        spy = spyOn(dividendPartnerService, 'getDividendPartnersObservable')
            .and.returnValue(Promise.resolve(dividendPartnerMockUp));

        expect(spy.calls.any()).toBe(false, 'getDividendPartnersObservable not yet called');
    });

    it('should not call the getBusinessSegmentsObservable method before OnInit', () => {
        // Setup spy on the 'getBusinessSegmentsObservable' method
        spy = spyOn(businessSegmentService, 'getBusinessSegmentsObservable')
            .and.returnValue(Promise.resolve(businessPartnerMockUp));

        expect(spy.calls.any()).toBe(false, 'getBusinessSegmentsObservable not yet called');
    });

    it('should not call the getDividendPartnersObservable method before OnInit', () => {
        // Setup spy on the 'getDividendPartnersObservable' method
        spy = spyOn(dividendPartnerService, 'getDividendPartnersObservable')
            .and.returnValue(Promise.resolve(dividendPartnerMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(false, 'getDividendPartnersObservable not yet called');
    });

    it('should not call the getBusinessSegmentsObservable method before OnInit', () => {
        // Setup spy on the 'getBusinessSegmentsObservable' method
        spy = spyOn(businessSegmentService, 'getBusinessSegmentsObservable')
            .and.returnValue(Promise.resolve(businessPartnerMockUp));

        fixture.detectChanges();
        expect(spy.calls.any()).toBe(false, 'getBusinessSegmentsObservable not yet called');
    });

    it('should raise Add button click event', () => {
        let displayDialog: boolean = true;
        let newDividendPartnerType: boolean = true;
        let blnValidationResult: boolean = true;

        de = fixture.debugElement.query(By.css('#btnAdd'));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        expect(comp.displayDialog).toBe(displayDialog);
        expect(comp.newDividendPartnerType).toBe(newDividendPartnerType);
        expect(comp.blnValidationResult).toBe(blnValidationResult);
    });

    it('should raise Save button click event', () => {
         // Creating testmockup object
        let businessPartnerType: IBusinessSegment = new BusinessSegmentTypeMockup('', 'Test', false, false, '', '', '', '', 0);
        let dividendPartnersType: IDividendPartnerValue = new DividendPartnerTypesValueMockup('', 'Test', false, businessPartnerType, false, '', '', '', '', 0);


        comp.dividendPartnersType = dividendPartnersType; // initializing the dividendPartnersType object with the test mockup object

        de = fixture.debugElement.query(By.css('#btnSave'));
        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        // test to ensure that the object was added to array. Asserted by checking for the index value of the inserted item.
        expect(comp.dividendPartnerTypes.indexOf(dividendPartnersType)).toBeGreaterThan(-1);
    });

    it('should raise SavetoDatabase button click event', () => {
        let blnPushDataToDatabase: boolean = true;
        let blnSavedOrDeleted: boolean = true;
        let strSavedMessage: string = "Data saved successfully";

        de = fixture.debugElement.query(By.css('#btnSaveDataToServer'));

        // Setup spy on the 'getTagsObservable' method
        spy = spyOn(dividendPartnerService, 'updateDividendPartnersObservable')
            .and.returnValue(Promise.resolve(dividendPartnerMockUp));

        //de.triggerEventHandler('click', null);
        click(de); // click triggerEventHandler helper method

        fixture.detectChanges();

        expect(spy.calls.any()).toBe(true, 'updateDividendPartnersObservable called');
        expect(comp.blnPushDataToDatabase).toBe(blnPushDataToDatabase);
        expect(comp.blnSavedOrDeleted).toBe(blnSavedOrDeleted);
        expect(comp.msgs[0].detail).toContain(strSavedMessage);
    });
});

class DividendPartnerTypesValueMockup implements IDividendPartnerValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = true,
        public BusinessSegment: IBusinessSegment = null,
        public Editable: boolean = true,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class BusinessSegmentTypeMockup implements IBusinessSegment {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Editable: boolean = false,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}