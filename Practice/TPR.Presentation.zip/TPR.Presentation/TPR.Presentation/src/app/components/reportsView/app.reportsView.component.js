"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var primeng_1 = require('primeng/primeng');
var app_reportsView_service_1 = require('../../service/app.reportsView.service');
var app_server_service_1 = require('../../service/app.server.service');
var RefreshStatusEnum;
(function (RefreshStatusEnum) {
    RefreshStatusEnum[RefreshStatusEnum["None"] = 0] = "None";
    RefreshStatusEnum[RefreshStatusEnum["Complete"] = 1] = "Complete";
    RefreshStatusEnum[RefreshStatusEnum["Error"] = 2] = "Error";
    RefreshStatusEnum[RefreshStatusEnum["Refreshing"] = 3] = "Refreshing";
    RefreshStatusEnum[RefreshStatusEnum["NotDoneDueToDataSourceErrors"] = 4] = "NotDoneDueToDataSourceErrors";
})(RefreshStatusEnum || (RefreshStatusEnum = {}));
var ViewTypeEnum;
(function (ViewTypeEnum) {
    ViewTypeEnum[ViewTypeEnum["WorkBook"] = 0] = "WorkBook";
    ViewTypeEnum[ViewTypeEnum["View"] = 1] = "View";
})(ViewTypeEnum || (ViewTypeEnum = {}));
var AppReportsViewComponent = (function () {
    function AppReportsViewComponent(viewsService, serverService, confirmationService) {
        this.viewsService = viewsService;
        this.serverService = serverService;
        this.confirmationService = confirmationService;
        this.view = new ViewsValue();
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.msgs = [];
        this.selectedViewType = new ViewsValue();
        this.Message = "";
        this.blnPushDataToDatabase = false;
        this.blnSavedOrDeleted = false;
        this.clsMessage = {};
        this.selectedServerValue = '';
        this.validationErrorMessage = "";
        this.selectedViewTypeName = '';
        this.refviews = [];
        this.RefreshStatusEnum = RefreshStatusEnum;
        this.ViewTypeEnum = ViewTypeEnum;
    }
    AppReportsViewComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.viewsService.getViewsObservable()
            .subscribe(function (data) { return _this.setViewsData(data); });
        this.serverService.getServersObservable()
            .subscribe(function (data) { return _this.setServersData(data); });
    };
    AppReportsViewComponent.prototype.reload = function () {
        var _this = this;
        this.viewsService.getViewsObservable()
            .subscribe(function (data) { return _this.setViewsData(data); });
        this.serverService.getServersObservable()
            .subscribe(function (data) { return _this.setServersData(data); });
        console.log("reload clicked");
        console.log(this.views);
    };
    AppReportsViewComponent.prototype.setViewsData = function (data) {
        this.views = data.Result.TableauViews.$values;
        for (var i in this.views) {
            this.views[i].RefreshState = RefreshStatusEnum[this.views[i].RefreshState];
            this.views[i].ViewType = ViewTypeEnum[this.views[i].ViewType];
        }
        console.log("Views->", this.views);
    };
    AppReportsViewComponent.prototype.setServersData = function (data) {
        this.servers = [];
        this.servers = data.Result.TableauServers.$values;
        this.serverValues = [];
        this.serverValues.push({ label: 'Select Servers', value: 'SelectServers' });
        var serverData = '';
        for (var i = 0; i < this.servers.length; i++) {
            var server = this.servers[i];
            serverData = server.Name;
            this.serverValues.push({ label: serverData, value: serverData });
        }
    };
    AppReportsViewComponent.prototype.canDeactivate = function () {
        if (!this.blnPushDataToDatabase) {
            return confirm("Are you sure that you want to navigate without saving the data?");
        }
        return true;
    };
    AppReportsViewComponent.prototype.showDialogToAdd = function () {
        this.newViewType = true;
        this.view = new ViewsValue();
        this.selectedServerValue = '';
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppReportsViewComponent.prototype.save = function () {
        if (this.view.Name == null || this.view.Name.trim() == "") {
            this.validationErrorMessage = "Please provide valid Tableau view data.";
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            this.view.Name = "";
            return false;
        }
        else {
            if (this.newViewType) {
                if (this.selectedServerValue.trim() == "" || this.selectedServerValue.toUpperCase() == "SELECT SERVER") {
                    this.validationErrorMessage = "Please select a server.";
                    this.clsHighlightInvalidData = {};
                    this.blnValidationResult = false;
                    this.clsHighlightInvalidData = {
                        highlightInvalidData: true
                    };
                    this.selectedServerValue = '';
                    return false;
                }
                else {
                    this.view.Server = new ServersValue();
                    var serverType_1 = new ServersValue();
                    var serverTypeSelected_1 = this.selectedServerValue;
                    this.servers.forEach(function (item) {
                        var serverTypes = new ServersValue();
                        serverTypes = item;
                        if (serverTypes.Name == serverTypeSelected_1) {
                            serverType_1 = serverTypes;
                        }
                    });
                    this.view.Server = serverType_1;
                }
                console.log("saved");
                this.views.push(this.view);
            }
            else {
                this.view.Server = new ServersValue();
                var serverType_2 = new ServersValue();
                var serverTypeSelected_2 = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    var serverTypes = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected_2) {
                        serverType_2 = serverTypes;
                    }
                });
                this.view.Server = serverType_2;
                this.views[this.findSelectedViewTypeIndex()] = this.view;
            }
        }
        this.view = null;
        this.displayDialog = false;
        console.log(this.views);
    };
    AppReportsViewComponent.prototype.findSelectedViewTypeIndex = function () {
        var ViewName = this.selectedViewTypeName;
        var indexOut;
        var tempView;
        this.views.forEach(function (item, index) {
            if (ViewName == item.Name) {
                tempView = item;
            }
        });
        indexOut = this.views.indexOf(tempView);
        return indexOut;
    };
    AppReportsViewComponent.prototype.findViewTypeIndexForDelete = function () {
        return this.views.indexOf(this.currentViewType);
    };
    AppReportsViewComponent.prototype.findViewTypeIndexForRefresh = function () {
        return this.views.indexOf(this.currentViewType);
    };
    AppReportsViewComponent.prototype.refreshViews = function (action) {
        var _this = this;
        this.viewsService.refreshTableauViewsObservable(this.views)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
        console.log(this.views);
        console.log("refresh views method called");
        console.log(this.views[0].RefreshState);
    };
    AppReportsViewComponent.prototype.refreshViews3 = function (event, action) {
        var _this = this;
        this.refviews = [];
        this.currentViewType = event;
        this.refviews.push(event);
        var index = this.findViewTypeIndexForRefresh();
        this.viewsService.refreshTableauViewsObservable(this.refviews)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
    };
    AppReportsViewComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentViewType = event;
        this.confirmationService.confirm({
            message: 'Are you sure that you want to perform this action?',
            accept: function () {
                _this.views.splice(_this.findViewTypeIndexForDelete(), 1);
            }
        });
        this.view = null;
        console.log(this.views);
    };
    AppReportsViewComponent.prototype.onRowSelect = function (event) {
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.validationErrorMessage = '';
        this.newViewType = false;
        this.view = new ViewsValue();
        this.view = this.cloneView(event.data);
        this.selectedViewType = this.view;
        this.selectedViewTypeName = this.selectedViewType.Name;
        if (this.view.Server != null) {
            this.selectedServerValue = this.view.Server.Name;
        }
        else {
            this.selectedServerValue = '';
        }
        console.log("row selected");
        this.displayDialog = true;
    };
    AppReportsViewComponent.prototype.cloneView = function (c) {
        var viewsval = new ViewsValue();
        for (var prop in c) {
            viewsval[prop] = c[prop];
        }
        console.log("row select");
        console.log(viewsval);
        return viewsval;
    };
    AppReportsViewComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = true;
        console.log("Save to server");
        this.SaveDataToDataBase(action);
    };
    AppReportsViewComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.newViews = this.views;
        this.viewsService.updateViewsObservable(this.newViews)
            .subscribe(function (response) { return _this.ShowMessageOnSaveorDeleteData(response, action); });
        console.log(this.newViews);
        console.log("Save to database");
        this.newViews = null;
        this.viewsService.getViewsObservable()
            .subscribe(function (data) { return _this.setViewsData(data); });
        this.serverService.getServersObservable()
            .subscribe(function (data) { return _this.setServersData(data); });
    };
    AppReportsViewComponent.prototype.ShowMessageOnSaveorDeleteData = function (data, action) {
        console.log("showmessageonsaveordelete");
        console.log(data);
        this.blnSavedOrDeleted = true;
        this.clsMessage = {};
        this.clsMessage = {
            successMessage: true,
            failureMessage: false
        };
        this.msgs = [];
        if (action == "save") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
            this.Message = "Data saved successfully";
        }
        else if (action == "delete") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' });
            this.Message = "Data deleted successfully";
        }
        else {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Error' });
        }
    };
    AppReportsViewComponent.prototype.cloneViewType = function (c) {
        var view = new ViewsValue();
        for (var prop in c) {
            view[prop] = c[prop];
        }
        return view;
    };
    AppReportsViewComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/reportsView/app.reportsView.component.html'
        }), 
        __metadata('design:paramtypes', [app_reportsView_service_1.ViewsService, app_server_service_1.ServerService, primeng_1.ConfirmationService])
    ], AppReportsViewComponent);
    return AppReportsViewComponent;
}());
exports.AppReportsViewComponent = AppReportsViewComponent;
var ViewsValue = (function () {
    function ViewsValue(Name, IsInUse, Url, TargetLocation, Server, LastRefreshed, RefreshDuration, RefreshState, ViewType, Created, CreatedBy, Updated, UpdatedBy, Id, $type) {
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Url === void 0) { Url = null; }
        if (TargetLocation === void 0) { TargetLocation = null; }
        if (Server === void 0) { Server = null; }
        if (LastRefreshed === void 0) { LastRefreshed = null; }
        if (RefreshDuration === void 0) { RefreshDuration = '00:00:00'; }
        if (RefreshState === void 0) { RefreshState = 0; }
        if (ViewType === void 0) { ViewType = 0; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        if ($type === void 0) { $type = null; }
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Url = Url;
        this.TargetLocation = TargetLocation;
        this.Server = Server;
        this.LastRefreshed = LastRefreshed;
        this.RefreshDuration = RefreshDuration;
        this.RefreshState = RefreshState;
        this.ViewType = ViewType;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
        this.$type = $type;
    }
    return ViewsValue;
}());
var ServersValue = (function () {
    function ServersValue(Name, Url, $type, Id) {
        if (Name === void 0) { Name = null; }
        if (Url === void 0) { Url = null; }
        if ($type === void 0) { $type = null; }
        if (Id === void 0) { Id = 0; }
        this.Name = Name;
        this.Url = Url;
        this.$type = $type;
        this.Id = Id;
    }
    return ServersValue;
}());
//# sourceMappingURL=app.reportsView.component.js.map