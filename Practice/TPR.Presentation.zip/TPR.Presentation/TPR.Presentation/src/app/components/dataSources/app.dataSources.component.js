"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var primeng_1 = require('primeng/primeng');
var app_dataSources_service_1 = require('../../service/app.dataSources.service');
var app_server_service_1 = require('../../service/app.server.service');
var app_TPRCommonService_1 = require('../../service/app.TPRCommonService');
var RefreshStatusEnum;
(function (RefreshStatusEnum) {
    RefreshStatusEnum[RefreshStatusEnum["None"] = 0] = "None";
    RefreshStatusEnum[RefreshStatusEnum["Complete"] = 1] = "Complete";
    RefreshStatusEnum[RefreshStatusEnum["Error"] = 2] = "Error";
    RefreshStatusEnum[RefreshStatusEnum["Refreshing"] = 3] = "Refreshing";
    RefreshStatusEnum[RefreshStatusEnum["NotDoneDueToDataSourceErrors"] = 4] = "NotDoneDueToDataSourceErrors";
})(RefreshStatusEnum || (RefreshStatusEnum = {}));
var AppDataSourcesComponent = (function () {
    function AppDataSourcesComponent(dataSourcesService, serverService, confirmationService, tPRcommonService) {
        this.dataSourcesService = dataSourcesService;
        this.serverService = serverService;
        this.confirmationService = confirmationService;
        this.tPRcommonService = tPRcommonService;
        this.datasource = new DataSourcesValue();
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.validationErrorMessage = "";
        this.selectedDataSourceValue = '';
        this.selectedServerValue = '';
        this.blnSavedOrDeleted = false;
        this.blnPushDataToDatabase = false;
        this.msgs = [];
        this.clsMessage = {};
        this.Message = "";
        this.selectedDataSourceTypeName = '';
        this.refds = [];
        this.blnname = false;
        this.blnserver = false;
        this.blnproject = false;
        this.submitAttempt = false;
        this.header = '';
        this.add = false;
        this.blnShowPopUp = false;
        this.Status = "";
        this.ValidationMessage = "";
        this.RefreshStatusEnum = RefreshStatusEnum;
    }
    AppDataSourcesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dataSourcesService.getDataSourcesObservable()
            .subscribe(function (data) { return _this.setDataSourcesData(data); });
        this.serverService.getServersObservable()
            .subscribe(function (data) { return _this.setServersData(data); });
    };
    AppDataSourcesComponent.prototype.setDataSourcesData = function (data) {
        this.dataSources = data.Result.TableauDataSources.$values;
        for (var i in this.dataSources) {
            this.dataSources[i].RefreshState = RefreshStatusEnum[this.dataSources[i].RefreshState];
            if (this.dataSources[i].LastRefreshed != null) {
                this.dataSources[i].LastRefreshed = this.tPRcommonService.getFormattedSystemDate(new Date(this.dataSources[i].LastRefreshed));
            }
        }
        console.log(this.dataSources);
    };
    AppDataSourcesComponent.prototype.setServersData = function (data) {
        this.servers = [];
        this.servers = data.Result.TableauServers.$values;
        this.serverValues = [];
        this.serverValues.push({ label: 'Select a server', value: '' });
        var serverData = '';
        for (var i = 0; i < this.servers.length; i++) {
            var server = this.servers[i];
            serverData = server.Name;
            this.serverValues.push({ label: serverData, value: serverData });
        }
        //this.selectedServerValue = this.servers[0].Name;
    };
    AppDataSourcesComponent.prototype.showDialogToAdd = function () {
        this.header = "Add a new Tableau data source";
        this.add = true;
        this.submitAttempt = false;
        if (this.MyForm2 != undefined && this.MyForm2 != null) {
            this.MyForm2.controls['Name'].markAsPristine();
            this.MyForm2.controls['Name'].markAsUntouched();
            this.MyForm2.controls['Project'].markAsPristine();
            this.MyForm2.controls['Project'].markAsUntouched();
        }
        this.newDataSourceType = true;
        this.selectedServerValue = '';
        this.datasource = new DataSourcesValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    };
    AppDataSourcesComponent.prototype.reload = function () {
        var _this = this;
        this.dataSourcesService.getDataSourcesObservable()
            .subscribe(function (data) { return _this.setDataSourcesData(data); });
        this.serverService.getServersObservable()
            .subscribe(function (data) { return _this.setServersData(data); });
        console.log("reload clicked");
        console.log(this.dataSources);
    };
    AppDataSourcesComponent.prototype.delete = function (event) {
        var _this = this;
        this.currentDataSourceType = event;
        this.confirmationService.confirm({
            message: 'Are you sure that you want to perform this action?',
            accept: function () {
                _this.dataSources.splice(_this.findDataSourceTypeIndexForDelete(), 1);
            }
        });
        this.datasource = null;
        console.log("delete clicked");
        console.log(this.dataSources);
    };
    AppDataSourcesComponent.prototype.findDataSourceTypeIndexForDelete = function () {
        return this.dataSources.indexOf(this.currentDataSourceType);
    };
    AppDataSourcesComponent.prototype.isinvalid = function (input) {
        if (input == null || input.trim() == "") {
            return true;
        }
        else {
            return false;
        }
    };
    AppDataSourcesComponent.prototype.save = function () {
        this.submitAttempt = true;
        console.log("Try submit" + this.submitAttempt);
        this.blnname = this.isinvalid(this.datasource.Name);
        this.blnproject = this.isinvalid(this.datasource.Project);
        this.blnserver = this.isinvalid(this.selectedServerValue);
        if (this.blnname || this.blnproject || this.blnserver) {
            this.validationErrorMessage = "Please complete all fields.";
            this.clsHighlightInvalidData = {};
            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            return false;
        }
        else {
            if (this.newDataSourceType) {
                this.datasource.Server = new ServersValue();
                var serverType_1 = new ServersValue();
                var serverTypeSelected_1 = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    var serverTypes = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected_1) {
                        serverType_1 = serverTypes;
                    }
                });
                this.datasource.Server = serverType_1;
                console.log("saved");
                this.datasource.RefreshState = RefreshStatusEnum[this.datasource.RefreshState];
                this.dataSources.push(this.datasource);
                this.displayDialog = false;
            }
            else {
                this.datasource.Server = new ServersValue();
                var serverType_2 = new ServersValue();
                var serverTypeSelected_2 = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    var serverTypes = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected_2) {
                        serverType_2 = serverTypes;
                    }
                });
                //this.datasource.RefreshState = RefreshStatusEnum[this.datasource.RefreshState];
                this.datasource.Server = serverType_2;
                this.dataSources[this.findSelectedDataSourceTypeIndex()] = this.datasource;
            }
        }
        this.datasource = null;
        this.displayDialog = false;
        console.log(this.dataSources);
        console.log("Form name value = " + this.MyForm2.controls['Name'].value);
    };
    AppDataSourcesComponent.prototype.saveDataToServer = function () {
        var action = "save";
        this.blnPushDataToDatabase = true;
        console.log("Save to server");
        this.SaveDataToDataBase(action);
    };
    // SaveDataToDataBase(action: string) {
    //     this.newdatasources = this.dataSources;
    //     this.dataSourcesService.updateDataSourcesObservable(this.newdatasources)
    //         .subscribe(
    //         (response: Response) => this.ShowMessageOnSaveorDeleteData(response, action)
    //         );
    //     console.log(this.newdatasources);
    //     console.log("Save to database");
    //     this.newdatasources = null;
    // }
    AppDataSourcesComponent.prototype.SaveDataToDataBase = function (action) {
        var _this = this;
        this.newdatasources = this.dataSources;
        this.dataSourcesService.updateDataSourcesObservable(this.newdatasources)
            .subscribe(function (response) {
            if (response.Error) {
                _this.blnShowPopUp = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
            }
            else {
                _this.blnShowPopUp = true;
                _this.Status = "Success";
                _this.ValidationMessage = "Data is saved successfully";
                _this.blnSavedOrDeleted = true;
            }
        }, function (error) {
            _this.blnShowPopUp = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
        });
        this.newdatasources = null;
    };
    AppDataSourcesComponent.prototype.findSelectedDataSourceTypeIndex = function () {
        var DataSourceName = this.selectedDataSourceTypeName;
        var indexOut;
        var tempDS;
        this.dataSources.forEach(function (item, index) {
            if (DataSourceName == item.Name) {
                tempDS = item;
            }
        });
        indexOut = this.dataSources.indexOf(tempDS);
        return indexOut;
    };
    AppDataSourcesComponent.prototype.findDataSourceIndexForRefresh = function () {
        return this.dataSources.indexOf(this.currentDataSourceType);
    };
    AppDataSourcesComponent.prototype.refreshDataSources = function () {
        var _this = this;
        var action = "refresh";
        this.dataSourcesService.refreshDataSourcesObservable(this.dataSources)
            .subscribe(function (response) {
            if (response.Error) {
                _this.blnShowPopUp = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
            }
            else {
                _this.blnShowPopUp = true;
                _this.Status = "Refreshing";
                _this.ValidationMessage = "Data sources are being refreshed";
            }
        }, function (error) {
            _this.blnShowPopUp = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
        });
        // (response: Response) => this.ShowRefreshMessage(response, action)
        // );
    };
    AppDataSourcesComponent.prototype.refreshSelectedDataSource = function (event) {
        var _this = this;
        var action = "refresh";
        this.refds = [];
        this.currentDataSourceType = event;
        this.refds.push(event);
        var index = this.findDataSourceIndexForRefresh();
        this.dataSourcesService.refreshDataSourcesObservable(this.refds)
            .subscribe(function (response) {
            if (response.Error) {
                _this.blnShowPopUp = true;
                _this.Status = "Error";
                _this.ValidationMessage = response.Error.toString();
            }
            else {
                _this.blnShowPopUp = true;
                _this.Status = "Refreshing";
                _this.ValidationMessage = "Data source is being refreshed";
            }
        }, function (error) {
            _this.blnShowPopUp = true;
            _this.Status = "Error";
            _this.ValidationMessage = error.toString();
        });
        // (response: Response) => this.ShowRefreshMessage(response, action)
        // );
    };
    AppDataSourcesComponent.prototype.onRowSelect = function (event) {
        this.add = false;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.validationErrorMessage = '';
        this.newDataSourceType = false;
        this.datasource = new DataSourcesValue();
        this.datasource = this.cloneDataSource(event.data);
        this.selectedDataSourceType = this.datasource;
        this.selectedDataSourceTypeName = this.selectedDataSourceType.Name;
        if (this.datasource.Server != null) {
            this.selectedServerValue = this.datasource.Server.Name;
        }
        else {
            this.selectedServerValue = '';
        }
        console.log("row selected");
        console.log("data source name is " + this.selectedDataSourceTypeName);
        this.header = "Edit data source " + this.selectedDataSourceTypeName + " configuration";
        this.displayDialog = true;
    };
    AppDataSourcesComponent.prototype.cloneDataSource = function (c) {
        var dsval = new DataSourcesValue();
        for (var prop in c) {
            dsval[prop] = c[prop];
        }
        console.log("row select");
        console.log(dsval);
        return dsval;
    };
    AppDataSourcesComponent.prototype.ShowMessageOnSaveorDeleteData = function (data, action) {
        this.blnSavedOrDeleted = true;
        this.clsMessage = {};
        this.clsMessage = {
            successMessage: true,
            failureMessage: false
        };
        this.msgs = [];
        if (action == "save") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data saved successfully' });
            this.Message = "Data saved successfully";
        }
        else if (action == "delete") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Data deleted successfully' });
            this.Message = "Data deleted successfully";
        }
        ;
    };
    AppDataSourcesComponent.prototype.ShowRefreshMessage = function (data, action) {
        console.log("showrefreshmessage");
        console.log(data);
        this.blnSavedOrDeleted = true;
        this.clsMessage = {};
        this.clsMessage = {
            successMessage: true,
            failureMessage: false
        };
        this.msgs = [];
        if (action == "refresh") {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Refreshing' });
            this.Message = "Refreshing";
        }
        else {
            this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Error' });
        }
    };
    __decorate([
        core_1.ViewChild('MyForm2'), 
        __metadata('design:type', forms_1.NgForm)
    ], AppDataSourcesComponent.prototype, "MyForm2", void 0);
    AppDataSourcesComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            templateUrl: 'app/components/dataSources/app.dataSources.component.html'
        }), 
        __metadata('design:paramtypes', [app_dataSources_service_1.DataSourcesService, app_server_service_1.ServerService, primeng_1.ConfirmationService, app_TPRCommonService_1.TPRCommonService])
    ], AppDataSourcesComponent);
    return AppDataSourcesComponent;
}());
exports.AppDataSourcesComponent = AppDataSourcesComponent;
var DataSourcesValue = (function () {
    function DataSourcesValue($type, Name, IsInUse, Server, LastRefreshed, 
        // public RefreshDuration: any = '00:00:00',
        RefreshDuration, RefreshState, Project, Created, CreatedBy, Updated, UpdatedBy, Id) {
        if ($type === void 0) { $type = null; }
        if (Name === void 0) { Name = null; }
        if (IsInUse === void 0) { IsInUse = false; }
        if (Server === void 0) { Server = null; }
        if (LastRefreshed === void 0) { LastRefreshed = null; }
        if (RefreshDuration === void 0) { RefreshDuration = ''; }
        if (RefreshState === void 0) { RefreshState = 0; }
        if (Project === void 0) { Project = null; }
        if (Created === void 0) { Created = null; }
        if (CreatedBy === void 0) { CreatedBy = null; }
        if (Updated === void 0) { Updated = null; }
        if (UpdatedBy === void 0) { UpdatedBy = null; }
        if (Id === void 0) { Id = 0; }
        this.$type = $type;
        this.Name = Name;
        this.IsInUse = IsInUse;
        this.Server = Server;
        this.LastRefreshed = LastRefreshed;
        this.RefreshDuration = RefreshDuration;
        this.RefreshState = RefreshState;
        this.Project = Project;
        this.Created = Created;
        this.CreatedBy = CreatedBy;
        this.Updated = Updated;
        this.UpdatedBy = UpdatedBy;
        this.Id = Id;
    }
    return DataSourcesValue;
}());
var ServersValue = (function () {
    function ServersValue(Name, Url, $type, Id) {
        if (Name === void 0) { Name = null; }
        if (Url === void 0) { Url = null; }
        if ($type === void 0) { $type = null; }
        if (Id === void 0) { Id = 0; }
        this.Name = Name;
        this.Url = Url;
        this.$type = $type;
        this.Id = Id;
    }
    return ServersValue;
}());
//# sourceMappingURL=app.dataSources.component.js.map