import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { DataSourcesService } from '../../service/app.dataSources.service';
import { ServerService } from '../../service/app.server.service';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';

import IDataSourceValue = DataSourceNamespace.IDataSourceValue;
import IServer = DataSourceNamespace.IServer;

enum RefreshStatusEnum {
    None = 0,
    Complete = 1,
    Error = 2,
    Refreshing = 3,
    NotDoneDueToDataSourceErrors = 4
}

@Component({
    selector: 'my-app',
    templateUrl: 'app.dataSources.component.html'
})
export class AppDataSourcesComponent implements OnInit {
    dataSources: IDataSourceValue[];
    servers: IServer[];
    servername: string;
    serverValues: SelectItem[];
    newdatasources: IDataSourceValue[];
    datasource: IDataSourceValue = new DataSourcesValue();
    clsHighlightInvalidData = {};
    blnValidationResult: boolean = true;
    validationErrorMessage: string = "";
    displayDialog: boolean;
    selectedDataSourceValue: string = '';
    selectedDataSourceType: IDataSourceValue;
    newDataSourceType: boolean;
    selectedServerValue: string = '';
    blnSavedOrDeleted: boolean = false;
    blnPushDataToDatabase: boolean = false;
    msgs: Message[] = [];
    clsMessage = {};
    Message: string = "";
    selectedDataSourceTypeName: string = '';
    currentDataSourceType: IDataSourceValue;
    refds: IDataSourceValue[] = [];
    blnname: boolean = false;
    blnserver: boolean = false;
    blnproject: boolean = false;
    @ViewChild('MyForm2') public MyForm2: NgForm;
    submitAttempt: boolean = false;
    header: string = '';
    add: boolean = false;
    blnShowPopUp: boolean = false;
    isRequesting: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    userRoles: string[] = [];
    constants: any;
    canEdit: boolean = false;

    RefreshStatusEnum: typeof RefreshStatusEnum = RefreshStatusEnum;

    constructor(private dataSourcesService: DataSourcesService,
        private serverService: ServerService,
        private confirmationService: ConfirmationService,
        private tPRcommonService: TPRCommonService,
        private serviceHelper: ServiceHelper) { }

    ngOnInit() {
        if (localStorage.getItem("UserRole")) {
            this.userRoles = JSON.parse(localStorage.getItem("UserRole"));
            //console.log("User Roles from Local Storage ->", this.userRoles);
        }

        this.serviceHelper.importSettings()
            .subscribe(data => this.getConstants(data));

        this.load();
    }

    public load() {
        this.isRequesting = true;

        this.dataSourcesService.getDataSourcesObservable()
            .subscribe(data => this.setDataSourcesData(data));

        this.serverService.getServersObservable()
            .subscribe(data => this.setServersData(data));
    }

    public getConstants(data: any): void {
        this.constants = data;
        this.authorizeUser();
    }

    private authorizeUser() {
        //console.log("Is User Authorized->",this.isUserAuthorised());
        this.canEdit = !this.isUserAuthorised();
    }

    public isUserAuthorised(): boolean {
        return this.userRoles != undefined && this.constants != undefined &&
            this.userRoles.some(x => x == this.constants.TPRSuperUser);
    }

    private setDataSourcesData(data: any): void {
        this.dataSources = data.Result.TableauDataSources.$values;
        for (let i in this.dataSources) {
            this.dataSources[i].RefreshState = RefreshStatusEnum[this.dataSources[i].RefreshState];
            if (this.dataSources[i].LastRefreshed != null) {
                this.dataSources[i].LastRefreshed = this.tPRcommonService.getFormattedSystemDate(new Date(this.dataSources[i].LastRefreshed));
            }
        }
        //console.log(this.dataSources);
    }

    private setServersData(data: any): void {
        this.servers = [];
        this.servers = data.Result.TableauServers.$values;
        this.serverValues = [];
        this.serverValues.push({ label: 'Select a server', value: '' });
        let serverData: string = ''
        for (var i = 0; i < this.servers.length; i++) {
            let server = this.servers[i];
            serverData = server.Name;
            this.serverValues.push({ label: serverData, value: serverData });
        }
        //this.selectedServerValue = this.servers[0].Name;
        this.stopRefreshing();
    }

    private stopRefreshing() {
        //console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    showDialogToAdd() {
        this.header = "Add a new Tableau data source";
        this.add = true;
        this.submitAttempt = false;
        if (this.MyForm2 != undefined && this.MyForm2 != null) {
            this.MyForm2.controls['Name'].markAsPristine();
            this.MyForm2.controls['Name'].markAsUntouched();
            this.MyForm2.controls['Project'].markAsPristine();
            this.MyForm2.controls['Project'].markAsUntouched();
        }
        this.newDataSourceType = true;
        this.selectedServerValue = '';
        this.datasource = new DataSourcesValue();
        this.displayDialog = true;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
    }

    delete(event: IDataSourceValue) {
        this.currentDataSourceType = event;

        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Data Source?',
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                this.dataSources.splice(this.findDataSourceTypeIndexForDelete(), 1);
            }
        });
        this.datasource = null;
    }

    findDataSourceTypeIndexForDelete(): number {
        return this.dataSources.indexOf(this.currentDataSourceType);
    }

    isinvalid(input: string) {
        if (input == null || input.trim() == "") {
            return true;
        }
        else {
            return false;
        }
    }

    save() {

        this.submitAttempt = true;
        //console.log("Try submit" + this.submitAttempt);

        this.blnname = this.isinvalid(this.datasource.Name);
        this.blnproject = this.isinvalid(this.datasource.Project);
        this.blnserver = this.isinvalid(this.selectedServerValue);

        if (this.blnname || this.blnproject || this.blnserver) {

            this.validationErrorMessage = "Please complete all fields.";
            this.clsHighlightInvalidData = {};

            this.blnValidationResult = false;
            this.clsHighlightInvalidData = {
                highlightInvalidData: true
            };
            return false;
        }
        else {
            if (this.newDataSourceType) {
                this.datasource.Server = new ServersValue();
                let serverType = new ServersValue();
                let serverTypeSelected: string = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    let serverTypes: IServer = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected) {
                        serverType = serverTypes;
                    }
                });

                this.datasource.Server = serverType;
                //console.log("saved");

                this.datasource.RefreshState = RefreshStatusEnum[this.datasource.RefreshState];

                this.dataSources.push(this.datasource);
                this.displayDialog = false;
            }
            else {
                this.datasource.Server = new ServersValue();
                let serverType = new ServersValue();
                let serverTypeSelected: string = this.selectedServerValue;
                this.servers.forEach(function (item) {
                    let serverTypes: IServer = new ServersValue();
                    serverTypes = item;
                    if (serverTypes.Name == serverTypeSelected) {
                        serverType = serverTypes;
                    }
                });
                //this.datasource.RefreshState = RefreshStatusEnum[this.datasource.RefreshState];
                this.datasource.Server = serverType;
                this.dataSources[this.findSelectedDataSourceTypeIndex()] = this.datasource;
            }
        }
        this.datasource = null;
        this.displayDialog = false;
        //console.log(this.dataSources);
        //console.log("Form name value = " + this.MyForm2.controls['Name'].value);
    }

    saveDataToServer() {
        this.isRequesting = true;
        let action: string = "save";
        this.blnPushDataToDatabase = true;
        //console.log("Save to server");
        this.SaveDataToDataBase(action);
    }

    SaveDataToDataBase(action: string) {
        this.newdatasources = this.dataSources;
        this.dataSourcesService.updateDataSourcesObservable(this.newdatasources)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                    this.stopRefreshing();
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Success";
                    this.ValidationMessage = "Data is saved successfully";
                    this.blnSavedOrDeleted = true;
                    this.load();
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
                this.stopRefreshing();
            });
        this.newdatasources = null;
    }

    findSelectedDataSourceTypeIndex(): number {
        let DataSourceName: string = this.selectedDataSourceTypeName;
        let indexOut: number;
        let tempDS: any;
        this.dataSources.forEach(function (item, index) {
            if (DataSourceName == item.Name) {
                tempDS = item;
            }
        });
        indexOut = this.dataSources.indexOf(tempDS);
        return indexOut;
    }

    findDataSourceIndexForRefresh(): number {
        return this.dataSources.indexOf(this.currentDataSourceType);
    }

    refreshDataSources() {
        let action: string = "refresh";
        this.dataSourcesService.refreshDataSourcesObservable(this.dataSources)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Refreshing";
                    this.ValidationMessage = "Data sources are being refreshed";
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
            });
    }

    refreshSelectedDataSource(event: IDataSourceValue) {
        let action: string = "refresh";
        this.refds = [];
        this.currentDataSourceType = event;
        this.refds.push(event);
        let index: number = this.findDataSourceIndexForRefresh();
        this.dataSourcesService.refreshDataSourcesObservable(this.refds)
            .subscribe(
            (response: any) => {
                if (response.Error) {
                    this.blnShowPopUp = true;
                    this.Status = "Error";
                    this.ValidationMessage = response.Error.toString();
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Refreshing";
                    this.ValidationMessage = "Data source is being refreshed";
                }
            },
            (error) => {
                this.blnShowPopUp = true;
                this.Status = "Error";
                this.ValidationMessage = error.toString();
            });
    }

    onRowSelect(event: any) {

        this.add = false;
        this.clsHighlightInvalidData = {};
        this.blnValidationResult = true;
        this.validationErrorMessage = '';
        this.newDataSourceType = false;
        this.datasource = new DataSourcesValue();
        this.datasource = this.cloneDataSource(event.data);
        this.selectedDataSourceType = this.datasource;
        this.selectedDataSourceTypeName = this.selectedDataSourceType.Name;
        if (this.datasource.Server != null) {
            this.selectedServerValue = this.datasource.Server.Name;
        }
        else {
            this.selectedServerValue = ''
        }
        // console.log("row selected");
        // console.log("data source name is " + this.selectedDataSourceTypeName);
        this.header = "Edit data source " + this.selectedDataSourceTypeName + " configuration";
        this.displayDialog = true;
    }

    cloneDataSource(c: IDataSourceValue): IDataSourceValue {
        let dsval = new DataSourcesValue();
        for (let prop in c) {
            dsval[prop] = c[prop];
        }
        // console.log("row select");
        // console.log(dsval);
        return dsval;

    }
}

class DataSourcesValue implements IDataSourceValue {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public IsInUse: boolean = false,
        public Server: IServer = null,
        public LastRefreshed: Date = null,
        // public RefreshDuration: any = '00:00:00',
        public RefreshDuration: any = '',
        public RefreshState: number = 0,
        public Project: string = null,
        public Created: Date = null,
        public CreatedBy: string = null,
        public Updated: Date = null,
        public UpdatedBy: string = null,
        public Id: number = 0) { }
}

class ServersValue implements IServer {
    constructor(
        public Name: string = null,
        public Url: string = null,
        public $type: string = null,
        public Id: number = 0
    ) { }
}