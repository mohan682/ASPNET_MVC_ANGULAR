﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { Message } from 'primeng/primeng';
import { Footer } from 'primeng/primeng';
import { SelectItem } from 'primeng/primeng';
import { DataTable } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { TPRProfitAlertGroupsService } from '../../service/app.TPRProfitAlertGroupsService';
import { CanComponentDeactivate } from '../../service/app.can-deactivate-guard.service';
import { TPRCommonService } from '../../service/app.TPRCommonService';
import { ServiceHelper } from '../../service/app.serviceHelper';

import IProfitAlertGroupsValues = PAGNameSpace.IProfitAlertGroupsValues;
import IProfitAlertGroups_Values_Alerts = PAGNameSpace.IProfitAlertGroups_Values_Alerts;
import IProfitAlertGroups_Values_Alerts_Values = PAGNameSpace.IProfitAlertGroups_Values_Alerts_Values;
import IProfitAlertGroups_Values_Alerts_Values_ActionAlerts = PAGNameSpace.IProfitAlertGroups_Values_Alerts_Values_ActionAlerts;
import IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values = PAGNameSpace.IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values;
import IProfitAlertGroups_Values_Members_Values = PAGNameSpace.IProfitAlertGroups_Values_Members_Values;
import IProfitAlertGroups_Values_Members = PAGNameSpace.IProfitAlertGroups_Values_Members;

import IProfitAlertGroups_SaveData = PAGNameSpace.IProfitAlertGroups_SaveData;
import IProfitAlertGroups_SaveData_AlertGroups = PAGNameSpace.IProfitAlertGroups_SaveData_AlertGroups;
import IProfitAlertGroups_SaveData_AlertGroups_Alerts = PAGNameSpace.IProfitAlertGroups_SaveData_AlertGroups_Alerts;

@Component({
    selector: 'my-app',
    templateUrl: 'app.profitAlertGroup.component.html'
})
export class AppProfitAlertGroupComponent implements OnInit {

    blnShowDialog: boolean = false;
    strDialogHeaderMessage: string = "";
    strDialogMessage: string = "";
    businessDate: Date;
    profitAlertGroups: IProfitAlertGroupsValues[] = [];
    selectedProfitAlertGroup: IProfitAlertGroupsValues = new clsProfitAlertGroupsValues();
    selectedProfitAlertGroupName: string = "";
    selectedProfitAlertGroupUpdateTiming: string = "";
    lstProfitAlertGroupUpdateTimings: SelectItem[] = [];
    selectedProfitAlertGroupUpdatedBy: string = "";
    selectedProfitAlertGroupUpdatedOn: string = "";
    selectedProfitAlertGroupAlert_Gain: IProfitAlertGroups_Values_Alerts_Values = new clsProfitAlertGroups_Values_Alerts_Values();
    selectedProfitAlertGroupAlert_Drawdown: IProfitAlertGroups_Values_Alerts_Values = new clsProfitAlertGroups_Values_Alerts_Values();
    selectedProfitAlertGroupTypeLimit_Gain: number;
    selectedProfitAlertGroupTypeLimit_Drawdown: number;

    newAlert_Gain: SelectItem[] = [];
    newAlert_Drawdown: SelectItem[] = [];
    selectednewAlert_Gain?: boolean;
    selectednewAlert_Drawdown?: boolean;

    triggeredAlert_Gain: SelectItem[] = [];
    triggeredAlert_Drawdown: SelectItem[] = [];
    selectedTriggeredAlert_Gain?: boolean;
    selectedTriggeredAlert_Drawdown?: boolean;

    dtSelectedTriggeredDate_Gain: Date;
    dtSelectedTriggeredDate_Drawdown: Date;
    blnDtTriggeredDateDisabled_Gain: boolean = false;
    blnDtTriggeredDateDisabled_Drawdown: boolean = false;

    dtNewActionAlertStartDate_Gain: Date;
    dtNewActionAlertStartDate_Drawdown: Date;
    dtNewActionAlertEndDate_Gain: Date;
    dtNewActionAlertEndDate_Drawdown: Date;

    NewActionAlertLimit_Gain: number;
    NewActionAlertLimit_Drawdown: number;

    NewActionAlerts_Gain: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values[] = [];
    NewActionAlerts_Drawdown: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values[] = [];

    @ViewChild('profitAlertGroupMain') dataTable: DataTable;

    blnIsNewGroupAdded: boolean = false;
    minDate: Date;

    isRequesting: boolean;

    blnShowPopUp: boolean = false;
    Status: string = "";
    ValidationMessage: string = "";
    disableSave: boolean = false;
    canEdit: boolean = false;

    constructor(
        private pagService: TPRProfitAlertGroupsService,
        private confirmationService: ConfirmationService,
        private tprCommonService: TPRCommonService,
        private serviceHelper: ServiceHelper
    ) { }

    ngOnInit() {
        this.getProfitAlertGroupDate();
        if (localStorage.getItem("disableSave")) {
            this.disableSave = JSON.parse(localStorage.getItem("disableSave"));
        }
        else {
            this.disableSave = this.serviceHelper.authorizeUserForSaving();
        }
        this.canEdit = !(this.disableSave);
    }

    private stopRefreshing() {
        //console.log("stopRefreshing -->", this.isRequesting);
        this.isRequesting = false;
    }

    getProfitAlertGroupDate() {
        this.isRequesting = true;

        this.businessDate = localStorage.getItem("BusinessDate") ? new Date(localStorage.getItem("BusinessDate")) : null;

        this.pagService.getProfitAlertGroupsObservable()
            .subscribe(data => this.setProfitAlertGroupData(data));
    }

    setProfitAlertGroupData(data: any) {
        this.profitAlertGroups = data.Result.AlertGroups.$values;

        let newDate = new Date(this.businessDate);

        this.minDate = new Date();
        this.minDate = newDate;
        this.lstProfitAlertGroupUpdateTimings = [];
        this.lstProfitAlertGroupUpdateTimings.push({ value: "-1", label: "R-1" });
        this.lstProfitAlertGroupUpdateTimings.push({ value: "-2", label: "R-2" });

        this.setDefaultSelectedProfitAlertGroup();
        this.stopRefreshing();
    }

    setDefaultSelectedProfitAlertGroup() {
        this.profitAlertGroups && this.profitAlertGroups.length > 0 ? this.selectedProfitAlertGroup = this.profitAlertGroups[0] : null;

        this.setDefaultDataForProfitAlertGroup();
    }

    setDefaultDataForProfitAlertGroup() {
        if (this.selectedProfitAlertGroup) {
            this.selectedProfitAlertGroupName = this.selectedProfitAlertGroup.Name;
            this.selectedProfitAlertGroup.UpdateTiming ? this.selectedProfitAlertGroupUpdateTiming = this.selectedProfitAlertGroup.UpdateTiming.toString()
                : this.selectedProfitAlertGroupUpdateTiming = "-1";
            this.selectedProfitAlertGroupUpdatedBy = this.selectedProfitAlertGroup.UpdatedBy;
            this.selectedProfitAlertGroup.Updated != null ? this.selectedProfitAlertGroup.Updated = this.tprCommonService.getFormattedSystemDate(new Date(this.selectedProfitAlertGroup.Updated)) : "";
            this.selectedProfitAlertGroupUpdatedOn = this.selectedProfitAlertGroup.Updated;

            this.selectedProfitAlertGroupAlert_Gain = this.selectedProfitAlertGroup.Alerts.$values.find(alert => alert.AlertGroupType == 1);
            if (!this.selectedProfitAlertGroupAlert_Gain) {
                this.selectedProfitAlertGroupAlert_Gain = new clsProfitAlertGroups_Values_Alerts_Values();
            }
            this.selectedProfitAlertGroupAlert_Drawdown = this.selectedProfitAlertGroup.Alerts.$values.find(alert => alert.AlertGroupType == 0);

            if (!this.selectedProfitAlertGroupAlert_Drawdown) {
                this.selectedProfitAlertGroupAlert_Drawdown = new clsProfitAlertGroups_Values_Alerts_Values();
            }

            this.selectedProfitAlertGroupTypeLimit_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.Level : null;
            this.selectedProfitAlertGroupTypeLimit_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.Level : null;

            this.newAlert_Gain = [];
            this.newAlert_Gain.push({ value: true, label: "Yes" });
            this.newAlert_Gain.push({ value: false, label: "No" });
            this.newAlert_Gain.push({ value: null, label: "Undefined" });
            this.selectednewAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsNew : null;

            this.newAlert_Drawdown = [];
            this.newAlert_Drawdown.push({ value: true, label: "Yes" });
            this.newAlert_Drawdown.push({ value: false, label: "No" });
            this.newAlert_Drawdown.push({ value: null, label: "Undefined" });
            this.selectednewAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsNew : null;

            this.triggeredAlert_Gain = [];
            this.triggeredAlert_Gain.push({ value: true, label: "Yes" });
            this.triggeredAlert_Gain.push({ value: false, label: "No" });
            this.triggeredAlert_Gain.push({ value: null, label: "Undefined" });
            this.selectedTriggeredAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsTriggered : null;
            this.blnDtTriggeredDateDisabled_Gain = !this.selectedTriggeredAlert_Gain;

            this.triggeredAlert_Drawdown = [];
            this.triggeredAlert_Drawdown.push({ value: true, label: "Yes" });
            this.triggeredAlert_Drawdown.push({ value: false, label: "No" });
            this.triggeredAlert_Drawdown.push({ value: null, label: "Undefined" });
            this.selectedTriggeredAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsTriggered : null;
            this.blnDtTriggeredDateDisabled_Drawdown = !this.selectedTriggeredAlert_Drawdown;

            if (this.selectedProfitAlertGroupAlert_Gain && this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate) {
                this.dtSelectedTriggeredDate_Gain = new Date(this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate);
            }
            else {
                this.dtSelectedTriggeredDate_Gain = null;
            }

            if (this.selectedProfitAlertGroupAlert_Drawdown && this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate) {
                this.dtSelectedTriggeredDate_Drawdown = new Date(this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate);
            }
            else {
                this.dtSelectedTriggeredDate_Drawdown = null;
            }

            this.dtNewActionAlertStartDate_Gain = this.businessDate;
            this.dtNewActionAlertStartDate_Drawdown = this.businessDate;
            this.dtNewActionAlertEndDate_Gain = this.businessDate;
            this.dtNewActionAlertEndDate_Drawdown = this.businessDate;

            this.NewActionAlertLimit_Gain = 0;
            this.NewActionAlertLimit_Drawdown = 0;

            this.NewActionAlerts_Gain = this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values;
            this.NewActionAlerts_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values;
        }
    }

    onRowSelectForProfitAlertGroup(event: any) {
        //console.log(event);
        this.blnIsNewGroupAdded = false;

        let selectedProfitAlertGroup: IProfitAlertGroupsValues = event.data;
        this.selectedProfitAlertGroupName = selectedProfitAlertGroup.Name;
        this.selectedProfitAlertGroupUpdateTiming = selectedProfitAlertGroup.UpdateTiming ? selectedProfitAlertGroup.UpdateTiming.toString() : "-1";
        this.selectedProfitAlertGroupUpdatedBy = selectedProfitAlertGroup.UpdatedBy;
        this.selectedProfitAlertGroupUpdatedOn = selectedProfitAlertGroup.Updated;
        this.selectedProfitAlertGroup.Updated != null ? this.selectedProfitAlertGroup.Updated = this.tprCommonService.getFormattedSystemDate(new Date(this.selectedProfitAlertGroup.Updated)) : "";

        this.selectedProfitAlertGroupAlert_Gain = this.selectedProfitAlertGroup.Alerts.$values.find(alert => alert.AlertGroupType == 1);
        if (!this.selectedProfitAlertGroupAlert_Gain) {
            this.selectedProfitAlertGroupAlert_Gain = new clsProfitAlertGroups_Values_Alerts_Values();
        }
        this.selectedProfitAlertGroupAlert_Drawdown = this.selectedProfitAlertGroup.Alerts.$values.find(alert => alert.AlertGroupType == 0);

        if (!this.selectedProfitAlertGroupAlert_Drawdown) {
            this.selectedProfitAlertGroupAlert_Drawdown = new clsProfitAlertGroups_Values_Alerts_Values();
        }

        this.selectedProfitAlertGroupTypeLimit_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.Level : null;
        this.selectedProfitAlertGroupTypeLimit_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.Level : null;

        this.selectednewAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsNew : null;
        this.selectednewAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsNew : null;

        this.selectedTriggeredAlert_Gain = this.selectedProfitAlertGroupAlert_Gain ? this.selectedProfitAlertGroupAlert_Gain.UserIsTriggered : null;
        this.selectedTriggeredAlert_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown ? this.selectedProfitAlertGroupAlert_Drawdown.UserIsTriggered : null;

        this.blnDtTriggeredDateDisabled_Gain = !this.selectedTriggeredAlert_Gain;
        this.blnDtTriggeredDateDisabled_Drawdown = !this.selectedTriggeredAlert_Drawdown;

        if (this.selectedProfitAlertGroupAlert_Gain && this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate) {
            this.dtSelectedTriggeredDate_Gain = new Date(this.selectedProfitAlertGroupAlert_Gain.UserTriggeredDate);
        }
        else {
            this.dtSelectedTriggeredDate_Gain = null;
        }

        if (this.selectedProfitAlertGroupAlert_Drawdown && this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate) {
            this.dtSelectedTriggeredDate_Drawdown = new Date(this.selectedProfitAlertGroupAlert_Drawdown.UserTriggeredDate);
        }
        else {
            this.dtSelectedTriggeredDate_Drawdown = null;
        }

        this.dtNewActionAlertStartDate_Gain = this.businessDate;
        this.dtNewActionAlertStartDate_Drawdown = this.businessDate;
        this.dtNewActionAlertEndDate_Gain = this.businessDate;
        this.dtNewActionAlertEndDate_Drawdown = this.businessDate;

        this.NewActionAlertLimit_Gain = 0;
        this.NewActionAlertLimit_Drawdown = 0;

        this.NewActionAlerts_Gain = this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values;
        this.NewActionAlerts_Drawdown = this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values;
    }

    onProfitAlertGroupUpdateTimingChange() {
        //console.log(this.selectedProfitAlertGroupUpdateTiming);
    }

    onselectednewAlert_Gain_Change() {
        //console.log(this.selectednewAlert_Gain);
    }

    onselectednewAlert_Drawdown_Change() {
        //console.log(this.selectednewAlert_Drawdown);
    }

    onselectednTriggeredAlert_Gain_Change() {
        //console.log(this.selectedTriggeredAlert_Gain);
        this.blnDtTriggeredDateDisabled_Gain = !this.selectedTriggeredAlert_Gain;
    }

    onselectednTriggeredAlert_Drawdown_Change() {
        //console.log(this.selectedTriggeredAlert_Drawdown);
        this.blnDtTriggeredDateDisabled_Drawdown = !this.selectedTriggeredAlert_Drawdown;
    }

    AddProfitAlertGroup() {
        let selectedProfitAlertGroupForDelete: IProfitAlertGroupsValues = new clsProfitAlertGroupsValues();
        this.selectedProfitAlertGroup = selectedProfitAlertGroupForDelete;
        this.setDefaultDataForProfitAlertGroup();

        ////console.log(this.selectedProfitAlertGroup);

        this.selectedProfitAlertGroup.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertGroupDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        let Gain_Alert: IProfitAlertGroups_Values_Alerts_Values = new clsProfitAlertGroups_Values_Alerts_Values();
        Gain_Alert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        Gain_Alert.AlertGroupType = 1;
        Gain_Alert.ActionAlerts = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts();
        this.selectedProfitAlertGroup.Alerts.$values.push(Gain_Alert);
        this.selectedProfitAlertGroupAlert_Gain = Gain_Alert;

        let Drawdown_Alert: IProfitAlertGroups_Values_Alerts_Values = new clsProfitAlertGroups_Values_Alerts_Values();
        Drawdown_Alert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ProfitAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        Drawdown_Alert.AlertGroupType = 0;
        Drawdown_Alert.ActionAlerts = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts();
        this.selectedProfitAlertGroup.Alerts.$values.push(Drawdown_Alert);
        this.selectedProfitAlertGroupAlert_Drawdown = Drawdown_Alert;

        this.blnIsNewGroupAdded = true;
    }

    SaveProfitAlertGroup() {
        //debugger;
        //console.log(this.selectedProfitAlertGroup);
        //console.log(this.profitAlertGroups);


        let blnValidationSuccessful: boolean = true;

        if (this.selectedProfitAlertGroup) {
            if (this.selectedProfitAlertGroup.Name == null || this.selectedProfitAlertGroup.Name == "") {
                blnValidationSuccessful = false;
                this.blnShowPopUp = true;
                this.Status = "Validation failed";
                this.ValidationMessage = "Error: Name should not be empty.";

                if (this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 1).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 0).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 1).Level.toString() == "" ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 0).Level.toString() == "") {
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Name should not be empty.\nError: Profit alert must have alert limit value.";
                }
                else if (isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 1).Level) ||
                    isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 0).Level)) {
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Name should not be empty.\nError: Profit alert must be numeric.";
                }
            }
            else {
                if (this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 1).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 0).Level == null ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 1).Level.toString() == "" ||
                    this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 0).Level.toString() == "") {
                    blnValidationSuccessful = false;
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Profit alert must have alert limit value.";
                }
                else if (isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 1).Level) ||
                    isNaN(this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 0).Level)) {
                    blnValidationSuccessful = false;
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Profit alert must be numeric.";
                }
            }
        }

        if (blnValidationSuccessful) {
            this.confirmationService.confirm({
                header: "Save",
                message: 'Saving changes to the Profit Alert Groups. Are you sure?',
                rejectVisible: true,
                acceptVisible: true,
                accept: () => {
                    if (this.blnIsNewGroupAdded) {
                        //console.log(this.selectedProfitAlertGroup);
                        this.profitAlertGroups.push(this.selectedProfitAlertGroup);
                    }

                    let objClsProfitAlertGroups_SaveData: IProfitAlertGroups_SaveData = new clsProfitAlertGroups_SaveData();

                    objClsProfitAlertGroups_SaveData = this.setProfitAlertPostDataForSaveAndDelete(objClsProfitAlertGroups_SaveData);
                    //debugger;
                    //console.log("objclsprofalgroupssave", objClsProfitAlertGroups_SaveData);
                    let blnValidAlertLevelValues: boolean = true;
                    if (objClsProfitAlertGroups_SaveData) {
                        objClsProfitAlertGroups_SaveData.AlertGroups.forEach(alertGroup => {
                            //console.log("Alert Group Name - " + alertGroup.Name, alertGroup);
                            alertGroup.Alerts.forEach(alert => {
                                if (alert.Level == null || alert.Level == undefined || alert.Level.toString().length == 0 || isNaN(alert.Level)) {
                                    blnValidAlertLevelValues = false;
                                }
                            });
                        });
                    }

                    if (!blnValidAlertLevelValues) {
                        this.blnShowPopUp = true;
                        this.Status = "Error";
                        this.ValidationMessage = "Profit alert must have valid alert limit value.";
                    }
                    else {
                        this.isRequesting = true;
                        this.pagService.updateProfitAlertGroupsObservable(objClsProfitAlertGroups_SaveData)
                            .subscribe((response: any) => {
                                //debugger;
                                //console.log(response);
                                if (response.Error) {
                                    this.stopRefreshing();
                                    this.Status = "Error";
                                    this.ValidationMessage = response.Error;
                                    this.blnShowPopUp = true;
                                }
                                else {
                                    this.blnShowPopUp = true;
                                    this.Status = "Success";
                                    this.ValidationMessage = "Data saved successfully";
                                    this.getProfitAlertGroupDate();

                                    // this will ensure that the first page will be selected upon save, only if a new record is inserted; 
                                    // else, it will be in the same page
                                    if (this.blnIsNewGroupAdded && this.selectedProfitAlertGroup) {
                                        this.setCurrentPage(1);
                                    }
                                }
                            },
                            (error) => {
                                //console.log(error)
                                this.stopRefreshing();
                                this.Status = "Error";
                                this.ValidationMessage = error;
                                this.blnShowPopUp = true;
                            });
                    }
                }
            });
        }
    }

    DeleteProfitAlertGroup() {
        //debugger;
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Profit Alert Group?',
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                this.isRequesting = true;
                let selectedProfitAlertGroupForDelete: IProfitAlertGroupsValues = new clsProfitAlertGroupsValues();
                selectedProfitAlertGroupForDelete = this.selectedProfitAlertGroup;

                this.profitAlertGroups.splice(this.profitAlertGroups.indexOf(selectedProfitAlertGroupForDelete), 1);

                //console.log(this.profitAlertGroups);

                let objClsProfitAlertGroups_SaveData: IProfitAlertGroups_SaveData = new clsProfitAlertGroups_SaveData();

                objClsProfitAlertGroups_SaveData = this.setProfitAlertPostDataForSaveAndDelete(objClsProfitAlertGroups_SaveData);

                //console.log(objClsProfitAlertGroups_SaveData);

                this.pagService.updateProfitAlertGroupsObservable(objClsProfitAlertGroups_SaveData)
                    .subscribe((response: any) => {
                        if (response.Error) {
                            this.stopRefreshing();
                            this.Status = "Error";
                            this.ValidationMessage = response.Error;
                            this.blnShowPopUp = true;
                        }
                        else {
                            this.blnShowPopUp = true;
                            this.Status = "Success";
                            this.ValidationMessage = "The selected Profit alert group is deleted successfully";

                            this.getProfitAlertGroupDate();

                            this.setCurrentPage(1);
                        }
                    },
                    (error) => {
                        //console.log(error)
                        this.stopRefreshing();
                        this.Status = "Error";
                        this.ValidationMessage = error;
                        this.blnShowPopUp = true;
                    });
            }
        });
    }

    setProfitAlertPostDataForSaveAndDelete(objClsProfitAlertGroups_SaveData: IProfitAlertGroups_SaveData): IProfitAlertGroups_SaveData {
        objClsProfitAlertGroups_SaveData.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.AlertGroupStatusCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
        objClsProfitAlertGroups_SaveData.ReportingDate = null;

        objClsProfitAlertGroups_SaveData.AlertGroups = [];

        this.profitAlertGroups.forEach(alertGroup => {
            let objClsProfitAlertGroups_SaveData_AlertGroups: IProfitAlertGroups_SaveData_AlertGroups = new clsProfitAlertGroups_SaveData_AlertGroups();
            objClsProfitAlertGroups_SaveData_AlertGroups.$type = alertGroup.$type;
            objClsProfitAlertGroups_SaveData_AlertGroups.Created = alertGroup.Created;
            objClsProfitAlertGroups_SaveData_AlertGroups.CreatedBy = alertGroup.CreatedBy;
            objClsProfitAlertGroups_SaveData_AlertGroups.IsInUse = alertGroup.IsInUse;
            objClsProfitAlertGroups_SaveData_AlertGroups.Members = [];
            objClsProfitAlertGroups_SaveData_AlertGroups.Name = alertGroup.Name;
            objClsProfitAlertGroups_SaveData_AlertGroups.ProfitAlertGroupStatusId = alertGroup.ProfitAlertGroupStatusId;
            objClsProfitAlertGroups_SaveData_AlertGroups.TradeDate = alertGroup.TradeDate;
            objClsProfitAlertGroups_SaveData_AlertGroups.UpdateTiming = alertGroup.UpdateTiming;
            objClsProfitAlertGroups_SaveData_AlertGroups.Updated = alertGroup.Updated;
            objClsProfitAlertGroups_SaveData_AlertGroups.UpdatedBy = alertGroup.UpdatedBy;
            objClsProfitAlertGroups_SaveData_AlertGroups.Id = alertGroup.Id;
            //objClsProfitAlertGroups_SaveData_AlertGroups.Alerts = alertGroup.Alerts.$values;

            alertGroup.Alerts.$values.forEach(alert => {
                let objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts: IProfitAlertGroups_SaveData_AlertGroups_Alerts = new clsProfitAlertGroups_SaveData_AlertGroups_Alerts();
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.$type = alert.$type;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Actual = alert.Actual;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.AlertGroupId = alert.AlertGroupId;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.AlertGroupType = alert.AlertGroupType;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Created = alert.Created;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.CreatedBy = alert.CreatedBy;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.CurrentActionAlertExpiryDate = alert.CurrentActionAlertExpiryDate;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.CurrentActionAlertLevel = alert.CurrentActionAlertLevel;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Id = alert.Id;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Level = alert.Level;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ReportedIsNew = alert.ReportedIsNew;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ReportedIsTriggered = alert.ReportedIsTriggered;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ReportedTriggeredDate = alert.ReportedTriggeredDate;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.StatusId = alert.StatusId;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.SystemIsNew = alert.SystemIsNew;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.SystemIsTriggered = alert.SystemIsTriggered;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.SystemTriggeredDate = alert.SystemTriggeredDate;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.Updated = alert.Updated;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UpdatedBy = alert.UpdatedBy;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UserIsNew = alert.UserIsNew;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UserIsTriggered = alert.UserIsTriggered;
                objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.UserTriggeredDate = alert.UserTriggeredDate;

                alert.ActionAlerts.$values.forEach(actionAlert => {
                    let objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values =
                        new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values();

                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.$type = actionAlert.$type;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.AlertGroupId = actionAlert.AlertGroupId;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.AlertId = actionAlert.AlertId;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Created = actionAlert.Created;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.CreatedBy = actionAlert.CreatedBy;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.EndDate = actionAlert.EndDate;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Id = actionAlert.Id;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Level = actionAlert.Level;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.StartDate = actionAlert.StartDate;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.Updated = actionAlert.Updated;
                    objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values.UpdatedBy = actionAlert.UpdatedBy;

                    objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts.ActionAlerts.push(objClsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values);
                });
                objClsProfitAlertGroups_SaveData_AlertGroups.Alerts.push(objClsIProfitAlertGroups_SaveData_AlertGroups_Alerts);
            });
            objClsProfitAlertGroups_SaveData.AlertGroups.push(objClsProfitAlertGroups_SaveData_AlertGroups);
        });

        //console.log(objClsProfitAlertGroups_SaveData);

        return objClsProfitAlertGroups_SaveData;
    }

    setCurrentPage(n: number) {
        //debugger;
        this.dataTable.reset();
        let paging = {
            first: ((n - 1) * this.dataTable.rows),
            rows: this.dataTable.rows
        };
        this.dataTable.paginate(paging);
    }

    AddNewActionAlertDrawdown() {
        //debugger;

        let blnValidActionAlert: boolean = true;

        this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.forEach(actionAlert => {
            if ((this.dtNewActionAlertStartDate_Drawdown >= new Date(actionAlert.StartDate) &&
                this.dtNewActionAlertStartDate_Drawdown <= new Date(actionAlert.EndDate)) ||
                (this.dtNewActionAlertEndDate_Drawdown >= new Date(actionAlert.StartDate) &&
                    this.dtNewActionAlertEndDate_Drawdown <= new Date(actionAlert.EndDate))) {
                blnValidActionAlert = false;
                this.blnShowPopUp = true;
                this.Status = "Validation failed";
                this.ValidationMessage = "Error: New action alert cannot overlap existing alerts.";
            }
        });

        if (this.dtNewActionAlertStartDate_Drawdown > this.dtNewActionAlertEndDate_Drawdown) {
            blnValidActionAlert = false;
            this.blnShowPopUp = true;
            this.Status = "Validation failed";
            this.ValidationMessage = "Error: Start date of alert should be less than end date.";
        }

        if (blnValidActionAlert) {
            if (!isNaN(this.NewActionAlertLimit_Drawdown)) {
                let newActionAlert: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values();

                newActionAlert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ActionAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                newActionAlert.AlertGroupId = this.selectedProfitAlertGroup.Id;
                //newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Drawdown.toLocaleString());
                //newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Drawdown.toLocaleString());
                newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Drawdown.toString());
                newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Drawdown.toString());
                newActionAlert.Level = this.NewActionAlertLimit_Drawdown;

                this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.push(newActionAlert);
            }
            else {
                this.blnShowPopUp = true;
                this.Status = "Validation failed";
                this.ValidationMessage = "Error: Please enter proper value for New Action Alert limit.";
            }
        }
    }

    AddNewActionAlertGain() {
        //debugger;

        let blnValidActionAlert: boolean = true;

        this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.forEach(actionAlert => {
            //debugger;
            if ((this.dtNewActionAlertStartDate_Gain >= new Date(actionAlert.StartDate) &&
                this.dtNewActionAlertStartDate_Gain <= new Date(actionAlert.EndDate)) ||
                (this.dtNewActionAlertEndDate_Gain >= new Date(actionAlert.StartDate) &&
                    this.dtNewActionAlertEndDate_Gain <= new Date(actionAlert.EndDate))) {
                blnValidActionAlert = false;
                this.blnShowPopUp = true;
                this.Status = "Validation failed";
                this.ValidationMessage = "Error: New action alert cannot overlap existing alerts.";
            }
        });

        //debugger;
        if (this.dtNewActionAlertStartDate_Gain > this.dtNewActionAlertEndDate_Gain) {
            blnValidActionAlert = false;
            this.blnShowPopUp = true;
            this.Status = "Validation failed";
            this.ValidationMessage = "Error: Start date of alert should be less than end date.";
        }
        try {
            if (blnValidActionAlert) {
                //debugger;
                if (!isNaN(this.NewActionAlertLimit_Gain)) {
                    let newActionAlert: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values();

                    newActionAlert.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.ActionAlertDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
                    newActionAlert.AlertGroupId = this.selectedProfitAlertGroup.Id;
                    // newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Gain.toLocaleString());
                    // newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Gain.toLocaleString());
                    newActionAlert.StartDate = this.setDate(this.dtNewActionAlertStartDate_Gain.toString());
                    newActionAlert.EndDate = this.setDate(this.dtNewActionAlertEndDate_Gain.toString());
                    newActionAlert.Level = this.NewActionAlertLimit_Gain;

                    this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.push(newActionAlert);
                    //console.log("newActionAlert", newActionAlert);
                    //console.log("Action alerts", this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values);
                }
                else {
                    this.blnShowPopUp = true;
                    this.Status = "Validation failed";
                    this.ValidationMessage = "Error: Please enter proper value for New Action Alert limit.";
                }
            }
        }
        catch (e) {
            //console.log(e);
        }
    }

    deleteDrawdownAlerts(objDrawDownAlert: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values) {
        //console.log(objDrawDownAlert);
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Action Alert?',
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                let index: number = this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.indexOf(objDrawDownAlert);
                if (index != -1) {
                    this.selectedProfitAlertGroupAlert_Drawdown.ActionAlerts.$values.splice(index, 1);
                }
            }
        });
    }

    deleteGainAlerts(objGainAlert: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values) {
        //console.log(objGainAlert);
        this.confirmationService.confirm({
            header: "Delete",
            message: 'Are you sure that you want to delete the selected Action Alert?',
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                let index: number = this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.indexOf(objGainAlert);
                if (index != -1) {
                    this.selectedProfitAlertGroupAlert_Gain.ActionAlerts.$values.splice(index, 1);
                }
            }
        });
    }

    onSelectTriggeredDate_Gain(value: any) {
        let selectedGainObject = this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 1);
        selectedGainObject.UserTriggeredDate = selectedGainObject ? this.setDate(this.dtSelectedTriggeredDate_Gain.toString()) : null;
    }

    onSelectTriggeredDate_Drawdown(value: any) {
        let selectedGainObject = this.selectedProfitAlertGroup.Alerts.$values.find(x => x.AlertGroupType == 0);
        selectedGainObject.UserTriggeredDate = selectedGainObject ? this.setDate(this.dtSelectedTriggeredDate_Drawdown.toString()) : null;
    }

    private setDate(data: string): string {
        let myDate = new Date(data);
        var output: string = "";

        var m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        var modifiedDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();

        output = myDate.getDate().toString().length > 1 ?
            myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear() :
            "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();

        return output;
    }

    private onCustomNumericValidationForPositiveandNegativeIntegers(event: any) {
        return (String.fromCharCode(event.charCode).match(/[0-9.-]/g) != null);
    }

    private onCustomNumericValidation(event: any) {
        return (String.fromCharCode(event.charCode).match(/[0-9.]/g) != null);
    }
}

class clsProfitAlertGroupsValues implements IProfitAlertGroupsValues {
    constructor(
        public $type: string = null,
        public Alerts: IProfitAlertGroups_Values_Alerts = new clsProfitAlertGroups_Values_Alerts(),
        public Name: string = null,
        public Members: IProfitAlertGroups_Values_Members = new clsProfitAlertGroups_Values_Members(),
        public IsInUse: boolean = false,
        public UpdateTiming: number = -1,
        public TradeDate: string = null,
        public ProfitAlertGroupStatusId: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsProfitAlertGroups_Values_Alerts implements IProfitAlertGroups_Values_Alerts {
    constructor(
        public $type: string = null,
        public $values: IProfitAlertGroups_Values_Alerts_Values[] = []
    ) { }
}

class clsProfitAlertGroups_Values_Members implements IProfitAlertGroups_Values_Members {
    constructor(
        public $type: string = null,
        public $values: IProfitAlertGroups_Values_Members_Values[] = []
    ) { }
}

class clsProfitAlertGroups_Values_Alerts_Values implements IProfitAlertGroups_Values_Alerts_Values {
    constructor(
        public $type: string = null,
        public ActionAlerts: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts = new clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts(),
        public AlertGroupType: number = 0,
        public Level: number = null,
        public AlertGroupId: number = 0,
        public CurrentActionAlertExpiryDate: string = null,
        public CurrentActionAlertLevel: string = null,
        public Actual: any = null,
        public StatusId: any = null,
        public SystemIsNew: boolean = false,
        public SystemIsTriggered: boolean = false,
        public SystemTriggeredDate: string = null,
        public UserIsNew: boolean = null,
        public UserIsTriggered: boolean = null,
        public UserTriggeredDate: string = null,
        public ReportedIsNew: boolean = false,
        public ReportedIsTriggered: boolean = false,
        public ReportedTriggeredDate: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts implements IProfitAlertGroups_Values_Alerts_Values_ActionAlerts {
    constructor(
        public $type: string = null,
        public $values: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values[] = []
    ) { }
}

class clsProfitAlertGroups_SaveData implements IProfitAlertGroups_SaveData {
    constructor(
        public $type: string = null,
        public AlertGroups: IProfitAlertGroups_SaveData_AlertGroups[] = [],
        public ReportingDate: string = null
    ) { }
}

class clsProfitAlertGroups_SaveData_AlertGroups implements IProfitAlertGroups_SaveData_AlertGroups {
    constructor(
        public $type: string = null,
        public Alerts: IProfitAlertGroups_SaveData_AlertGroups_Alerts[] = [],
        public Name: string = null,
        public Members: IProfitAlertGroups_Values_Members_Values[] = [],
        public IsInUse: boolean = false,
        public UpdateTiming: number = 0,
        public TradeDate: string = null,
        public ProfitAlertGroupStatusId: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsProfitAlertGroups_SaveData_AlertGroups_Alerts implements IProfitAlertGroups_SaveData_AlertGroups_Alerts {
    constructor(
        public $type: string = null,
        public ActionAlerts: IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values[] = [],
        public AlertGroupType: number = 0,
        public Level: number = 0,
        public AlertGroupId: number = 0,
        public CurrentActionAlertExpiryDate: string = null,
        public CurrentActionAlertLevel: string = null,
        public Actual: any = null,
        public StatusId: any = null,
        public SystemIsNew: boolean = false,
        public SystemIsTriggered: boolean = false,
        public SystemTriggeredDate: string = null,
        public UserIsNew: boolean = false,
        public UserIsTriggered: boolean = false,
        public UserTriggeredDate: string = null,
        public ReportedIsNew: boolean = false,
        public ReportedIsTriggered: boolean = false,
        public ReportedTriggeredDate: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}

class clsProfitAlertGroups_Values_Members_Values implements IProfitAlertGroups_Values_Members_Values {
    constructor(
        public $type: string = null,
        public Name: string = null,
        public NodeId: number = 0,
        public StructureId: number = 0,
        public Id: number = 0
    ) { }
}

class clsProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values implements IProfitAlertGroups_Values_Alerts_Values_ActionAlerts_Values {
    constructor(
        public $type: string = null,
        public AlertId: number = 0,
        public AlertGroupId: number = 0,
        public Level: number = 0,
        public StartDate: string = null,
        public EndDate: string = null,
        public Created: string = null,
        public CreatedBy: string = null,
        public Updated: string = null,
        public UpdatedBy: string = null,
        public Id: number = 0
    ) { }
}