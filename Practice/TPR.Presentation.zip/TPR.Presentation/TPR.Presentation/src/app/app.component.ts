﻿import { Component, OnInit, Input, Output, ElementRef, Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { MenuItem } from 'primeng/primeng';
import { Router, ActivatedRoute, Params, RouterModule, NavigationEnd } from '@angular/router';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { TPRCommonService } from './service/app.TPRCommonService';
import { TPRHolidayService } from './service/app.TPRHolidayService';
import { ServiceHelper } from './service/app.serviceHelper';
import { WorkDayService } from './service/app.workDayService';
import IUserRolesValue = CommonNameSpace.IUserRolesValue;
import IUserRolesValues = CommonNameSpace.IUserRolesValues;
import IUsersValue = CommonNameSpace.IUsersValue;
import IHolidayValue = HolidayNamespace.IHolidayValue;
import { AppDashboard } from './components/dashboard/app.dashboard.component';


@Component({
    selector: 'my-app',
    templateUrl: 'app.component.html'
})

@Injectable()
export class AppComponent implements OnInit {
    public date3: string;
    strEnvironment: string = '';
    strApplicationVersion: string = '';
    menuItems: MenuItem[];
    hierarchyItems: MenuItem[];
    dashboardItems: MenuItem[];
    feedsItems: MenuItem[];
    reportsItems: MenuItem[];
    UserRoles: IUserRolesValues = new UserRolesValues();
    availableRoles: string[] = [];
    strUserRoleName: string;
    serviceUrl: string = '';
    blnChangeBusinessDate: boolean = false;
    holidays: IHolidayValue[] = [];
    holiday: IHolidayValue;
    dtMinBusinessDate: Date;
    dtMaxBusinessDate: Date;
    intBusinessDatePositiveIncrement: number;
    intBusinessDateNegativeIncrement: number;
    arrGlobalHolidayDates: string[] = [];
    blnBusinessDateChangeShowDialog: boolean = false;
    strBusinessDateChangeDialogMessage: string = "";
    validDates: Date[];
    constants: any;
    disableSave: boolean = true;
    disableBusinessDate: boolean = true;
    isAccessDenied: boolean = true;
    showBusDateMessage: boolean = false;
    rollDateMessage: string = "";
    constructor(
        private tPRcommonService: TPRCommonService,
        private serviceHelper: ServiceHelper,
        private confirmationService: ConfirmationService,
        private router: Router,
        private tprHolidayService: TPRHolidayService,
        private workDayService: WorkDayService
    ) {
        this.router.events.subscribe((evt) => {
            if (evt instanceof NavigationEnd) {
                // trick the Router into believing it's last link wasn't previously loaded
                this.router.navigated = false;
                // if you need to scroll back to top, here is the right place
                window.scrollTo(0, 0);
            }
        });
    }

    ngOnInit() {

        this.blnChangeBusinessDate = false;

        this.hierarchyItems = [
            { label: 'Flat View', icon: 'fa-list-alt', routerLink: ['flatView'] },
            { label: 'Tree View', icon: 'fa-sitemap', routerLink: ['hierarchy'] },
            { label: 'Node Types', icon: 'fa-code-fork', routerLink: ['nodeTypes'] },
            { label: 'Regions', icon: 'fa-globe', routerLink: ['region'] },
            { label: 'Business Segments', icon: 'fa-institution', routerLink: ['businessSegments'] },
            { label: 'Dividend Partners', icon: 'fa-handshake-o', routerLink: ['dividendPartners'] },
            { label: 'Holidays', icon: 'fa-hotel', routerLink: ['holidays'] },
            { label: 'Tags', icon: 'fa-hashtag', routerLink: ['tags'] },
            { label: 'Profit Alert Groups', icon: 'fa-bell-o', routerLink: ['profitAlert'] }
        ];

        this.serviceHelper.importSettings()
            .subscribe(data => this.getServiceUrl(data));

        this.dashboardItems = [
            { label: 'Dashboard', icon: 'fa-tachometer', routerLink: ['dashboard'] }
        ];

        this.menuItems = [
            {
                label: 'Dashboard',
                items: [
                    { label: 'Dashboard', icon: 'fa-tachometer', routerLink: ['dashboard'] }
                ]
            },
            {
                label: 'Hierarchy',
                items: [
                    { label: 'Flat View', icon: 'fa-list-alt', routerLink: ['flatView'] },
                    { label: 'Tree View', icon: 'fa-sitemap', routerLink: ['hierarchy'] },
                    { label: 'Node Types', icon: 'fa-code-fork', routerLink: ['nodeTypes'] },
                    { label: 'Regions', icon: 'fa-globe', routerLink: ['region'] },
                    { label: 'Business Segments', icon: 'fa-institution', routerLink: ['businessSegments'] },
                    { label: 'Dividend Partners', icon: 'fa-handshake-o', routerLink: ['dividendPartners'] },
                    { label: 'Holidays', icon: 'fa-hotel', routerLink: ['holidays'] },
                    { label: 'Tags', icon: 'fa-hashtag', routerLink: ['tags'] },
                    { label: 'Profit Alert Groups', icon: 'fa-bell-o', routerLink: ['profitAlert'] }
                ]
            },
            {
                label: 'Feeds',
                items: [
                    { label: 'File Upload', icon: 'fa-cloud-upload', routerLink: ['fileUpload'] },
                    { label: 'Jobs', icon: 'fa-cogs', routerLink: ['jobs'] }
                ]
            },
            {
                label: 'Reports',
                items: [
                    { label: 'Views', icon: 'fa-pie-chart', routerLink: ['reportsView'] },
                    { label: 'Data Sources', icon: 'fa-database', routerLink: ['dataSources'] }
                ]
            }


        ];

        this.feedsItems = [
            { label: 'File Upload', icon: 'fa-cloud-upload', routerLink: ['fileUpload'] },
            { label: 'Jobs', icon: 'fa-cogs', routerLink: ['jobs'] }

        ];

        this.reportsItems = [
            { label: 'Views', icon: 'fa-pie-chart', routerLink: ['reportsView'] },
            { label: 'Data Sources', icon: 'fa-database', routerLink: ['dataSources'] }

        ];

        this.setCommonData();
    }

    private setCommonData() {
        this.workDayService.getWorkingDatesObservable()
            .subscribe(data => this.getWorkingDates(data));

        this.tPRcommonService.getEnvironmentObservable()
            .subscribe(data => {
                this.setEnvironmentData(data);
                this.tPRcommonService.getUserRolesObservable()
                    .subscribe(data => {
                        this.setUserRolesData(data);
                        this.serviceHelper.importSettings()
                            .subscribe(data => this.getConstants(data));
                    });
            });

        this.tPRcommonService.getSystemVersionObservable()
            .subscribe(data => this.setSystemVersionData(data));
    }

    public RefreshEnvironmentData() {
        this.rollDateMessage = "TPR is not yet rolled to the current business date";
        this.tPRcommonService.getEnvironmentObservable()
            .subscribe(data => this.setEnvironmentData(data));
    }

    public getConstants(data: any): void {
        this.constants = data;
        this.authorizeUser();
    }

    private authorizeUser() {
        this.isAccessDenied = !this.isUserAuthorised();
        if (this.isUserAuthorised()) {
            this.disableSave = !this.canUserSave();
            this.disableBusinessDate = !this.canUserEditBusinessDate();
            localStorage.setItem("disableSave", JSON.stringify(this.disableSave));
        }
        else {
            this.router.navigate(['/error']);
        }
    }

    public isUserAuthorised(): boolean {
        return this.availableRoles != undefined && this.constants != undefined &&
            (this.availableRoles.some(x => x == this.constants.TPRSuperUser) ||
                this.availableRoles.some(x => x == this.constants.TPRMarginManagement) ||
                this.availableRoles.some(x => x == this.constants.TPRRiskManagement) ||
                this.availableRoles.some(x => x == this.constants.TPRITSupport));
    }

    public canUserSave(): boolean {
        return this.availableRoles != undefined && this.constants != undefined &&
            this.availableRoles.some(x => x == this.constants.TPRSuperUser);
    }

    public canUserEditBusinessDate(): boolean {
        return (this.strEnvironment.toUpperCase() === "DEV" ||
            (this.availableRoles != undefined && this.constants != undefined &&
                this.availableRoles.some(x => x == this.constants.TPRITSupport)));
    }

    getWorkingDates(data: any) {
        this.validDates = data.Result.Range.$values;
        localStorage.setItem("WorkingDates", JSON.stringify(this.validDates));
    }

    private setEnvironmentData(data: any): void {
        this.strEnvironment = data.Result.StringValue;

        this.tPRcommonService.getSystemDateObservable()
            .subscribe(data => this.setSystemBusinessDateData(data));
    }

    private setSystemVersionData(data: any): void {
        this.strApplicationVersion = data.Result.ServerVersionInfo;
    }

    private getServiceUrl(data: any): void {
        this.serviceUrl = JSON.stringify(data.WCFServiceAddress);
        this.serviceUrl = this.serviceUrl.replace('"h', 'h');
        this.serviceUrl = this.serviceUrl.replace('/"', '/');
        localStorage.setItem("WCFServiceAddress", this.serviceUrl);
    }

    private setSystemBusinessDateData(data: any): void {
        let myDate = new Date(data.Result.DateValue);

        var m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        var businessDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();
        localStorage.setItem("BusinessDate", businessDate);

        let output: string = "";

        if (myDate.getDate().toString().length == 1) {
            output = "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        }
        else {
            output = myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();
        }

        this.date3 = output;

        this.tprHolidayService.getHolidaysObservable()
            .subscribe(data => this.setTPRHolidays(data));

        var utcDate = this.tPRcommonService.getFormattedSystemDate_Date(new Date());
        this.showBusDateMessage = (this.date3 != utcDate);
    }

    private setUserRolesData(data: any): void {
        this.UserRoles.$values = [];
        this.UserRoles.$values = data.Result.UserRoles.$values;

        this.UserRoles.$values.forEach((role: any) => {
            this.availableRoles.push(role.Name);
        });

        this.strUserRoleName = this.availableRoles[0];
        localStorage.setItem("UserRole", JSON.stringify(this.availableRoles));
    }

    private validateBusinessDate(): boolean {

        return true;
    }

    private changeBusinessDate(): void {
        let messageForConfirmation: string = "";
        let currentBusinessDate: Date = new Date(localStorage.getItem("BusinessDate"));
        let proposedBusinessDate: Date = new Date(this.date3);

        if (proposedBusinessDate < currentBusinessDate) {
            messageForConfirmation = "Disclaimer: \n\nChanging the reporting date will unpublish all the data from " + this.setFormattedDate(currentBusinessDate.toString()) + " ";
            messageForConfirmation += " to " + this.setFormattedDate(proposedBusinessDate.toString()) + ", thereby making data unavailable in Tableau to report for this duration. \n\n";
            messageForConfirmation += "Pressing 'Yes' confirms TPR Super Users have supported this action and the Reporting Date will be changed.\n"
            messageForConfirmation += "Pressing 'No' will close this request.";
        }
        else if (proposedBusinessDate > currentBusinessDate) {
            messageForConfirmation = "Updating System Reporting Date to " + this.setFormattedDate(this.date3.toString()) + ". Would you like to proceed?";
        }
        else if ((proposedBusinessDate.toString() == currentBusinessDate.toString())) {
            return;
        }

        this.blnChangeBusinessDate = true;
        this.confirmationService.confirm({
            header: "Update Reporting Date",
            message: messageForConfirmation,
            rejectVisible: true,
            acceptVisible: true,
            accept: () => {
                let previousBusinessDateinCaseOfIssue: Date = new Date(localStorage.getItem("BusinessDate"));
                localStorage.setItem("BusinessDate", this.setFormattedDate(this.date3));
                this.tPRcommonService.SetSystemDate(this.setFormattedDate(this.date3))
                    .subscribe((response: any) => {
                        this.blnChangeBusinessDate = false;
                        if (response.Error) {
                            this.date3 = this.setFormattedDate(previousBusinessDateinCaseOfIssue.toString());
                            localStorage.setItem("BusinessDate", this.setFormattedDate(this.date3));
                            this.setBusinessDate();
                            this.blnBusinessDateChangeShowDialog = true;
                            this.strBusinessDateChangeDialogMessage = response.Error;
                        }
                        else {
                            this.setBusinessDate();
                            this.blnBusinessDateChangeShowDialog = true;
                            this.strBusinessDateChangeDialogMessage = "Reporting Date is now changed to " + this.setFormattedDate(proposedBusinessDate.toString());
                            this.RefreshEnvironmentData();
                            this.router.navigateByUrl('/DummyComponent', { skipLocationChange: true }); //added EH 
                            this.router.navigate(['/dashboard']);
                        }
                    },
                    (error) => {
                        console.log(error)
                    });
            },
            reject: () => {
                this.date3 = this.setFormattedDate(localStorage.getItem("BusinessDate"));
            }
        });
    }

    private setFormattedDate(data: string): string {
        let myDate = new Date(data);
        var output: string = "";

        var m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        var modifiedDate = myDate.getDate() + m_names[myDate.getMonth()] + myDate.getFullYear();

        output = myDate.getDate().toString().length > 1 ?
            myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear() :
            "0" + myDate.getDate() + " " + m_names[myDate.getMonth()] + " " + myDate.getFullYear();

        return output;
    }

    private setTPRHolidays(data: any): void {
        var utcDate = this.tPRcommonService.getFormattedSystemDate_Date(new Date());

        this.holidays = data.Result.Holidays.$values;

        for (var i = 0; i < this.holidays.length; i++) {
            this.holiday = this.holidays[i];

            if (this.holiday.Region != null) {
                this.holiday.HolidayType = 'Regional';
            }
            else {
                this.holiday.HolidayType = 'Global';
                this.arrGlobalHolidayDates.push(this.setFormattedDate(this.holiday.Date));
            }
        }

        localStorage.setItem("Holidays", JSON.stringify(this.holidays));

        var nextWorkingDay = this.setFormattedDate(this.getPreviousorNextWorkingDay(new Date(utcDate), false).toString());


        if (this.holidays.some(d => (!d.Region &&
            this.setFormattedDate(d.Date).toString() == utcDate.toString()))
            && nextWorkingDay == this.date3) {
            this.showBusDateMessage = true;
            this.rollDateMessage = "TPR is rolled to business date '" + this.date3 + "' as today is a Global holiday '" + this.holiday.Name + "' in TPR.";
        }
        else if (this.date3 != utcDate) {
            this.showBusDateMessage = true;
            this.rollDateMessage = "TPR is not yet rolled to the current business date";
        }

        this.setBusinessDate();
    }

    private setBusinessDate(): void {
        if (this.strEnvironment.toLowerCase() == "prod" || this.strEnvironment.toLowerCase() == "production") {
            let currentBusinessDate: Date = new Date(this.date3);

            this.intBusinessDatePositiveIncrement = 5;
            this.intBusinessDateNegativeIncrement = -5;

            // this is to componsate for the 2 weekends i.e. saturday and sunday.
            this.intBusinessDatePositiveIncrement += 2;
            this.intBusinessDateNegativeIncrement += -2;

            let newIncrementDate: Date = currentBusinessDate;

            for (let count: number = 1; count <= 7; count++) {
                newIncrementDate.setDate(currentBusinessDate.getDate() + 1);
                let formattedNewDate: string = this.setFormattedDate(newIncrementDate.toString());

                let isHoliday: boolean = this.arrGlobalHolidayDates.find(holiday => holiday == formattedNewDate) ? true : false;

                if (isHoliday) {
                    this.intBusinessDatePositiveIncrement += 1;
                }
            }
            //reset the date to set the maximum business date
            currentBusinessDate = new Date(this.date3);

            //set the maximum business date
            this.dtMaxBusinessDate = currentBusinessDate;
            this.dtMaxBusinessDate.setDate(currentBusinessDate.getDate() + this.intBusinessDatePositiveIncrement);

            //reset the date for decrement
            currentBusinessDate = new Date(this.date3);
            let newDecrementDate: Date = currentBusinessDate;

            for (let count: number = 1; count <= 7; count++) {
                newDecrementDate.setDate(currentBusinessDate.getDate() - 1);
                let formattedNewDate: string = this.setFormattedDate(newDecrementDate.toString());

                let isHoliday: boolean = this.arrGlobalHolidayDates.find(holiday => holiday == formattedNewDate) ? true : false;

                if (isHoliday) {
                    this.intBusinessDateNegativeIncrement += -1;
                }
            }

            //reset the date to set the minimum business date
            currentBusinessDate = new Date(this.date3);
            this.dtMinBusinessDate = currentBusinessDate;
            this.dtMinBusinessDate.setDate(currentBusinessDate.getDate() + this.intBusinessDateNegativeIncrement);
        }
    }

    private onSelectSystemBusinessDate() {
        this.blnChangeBusinessDate = true;
    }

    getPreviousorNextWorkingDay(initialDate: Date, isPrevious: boolean): Date {
        let days = isPrevious ? -1 : 1;
        initialDate.setHours(0, 0, 0, 0);
        initialDate.setDate(initialDate.getDate() + days);

        if (localStorage.getItem("WorkingDates") && localStorage.getItem("Holidays")) {

            if (JSON.parse(localStorage.getItem("WorkingDates"))) {
                this.validDates = JSON.parse(localStorage.getItem("WorkingDates"));
            }

            if (JSON.parse(localStorage.getItem("Holidays"))) {
                this.holidays = JSON.parse(localStorage.getItem("Holidays"));
            }

            while (this.validDates && this.holidays && this.validDates.length > 0 && this.holidays.length > 0) {
                if (this.validDates.some(d => ((new Date(d)).setHours(0, 0, 0, 0) == initialDate.setHours(0, 0, 0, 0)))
                    && !this.holidays.some(d => (d.Region == null && this.tPRcommonService.getFormattedSystemDate_Date(new Date(d.Date)) == this.tPRcommonService.getFormattedSystemDate_Date(initialDate)))) {
                    break;
                }
                initialDate.setDate(initialDate.getDate() + days);
            }
        }
        else {
            console.log("Unable to retrieve holiday and working dates date from local storage");
        }

        return initialDate;
    }
}

class UserRolesValues implements IUserRolesValues {
    constructor(public $values: IUserRolesValue[] = null) { }
}

class UserRolesValue implements IUserRolesValue {
    constructor(
        public Name: string = null,
        public Users: IUsersValue[] = null) { }
}

class UsersValue implements IUsersValue {
    constructor(
        public LoginName: string = null,
        public Role: string = null) { }
}