declare module JobsNamespace {

     export interface IJobValue {
        $type: string;
        Name: string;
        LastExecuted: string;
        Active: boolean;
        Status: string;
        Hour: number;
        Minute: number;
        ScheduleType: string;
        JobOrder: Date;
    }

    export interface IJobCollection {
        $type: string;
        $values: IJobValue[];
    }

    export interface IJobExecutionResult{
        $type: string;
        Result: string;
        Job:IJobValue;
    }

    export interface IJobExecutionResultCollection{
        $type: string;
        Results: IJobExecutionResultCollection[];
    }
}