﻿declare module BusinessSegmentNameSpace {

    export interface IBusinessSegmentValue {
        $type: string,
        Name: string,
        IsInUse: boolean,
        Editable: boolean,
        Created: string,
        CreatedBy:string,
        Updated: string
        UpdatedBy: string,
        Id: number
    }

    export interface IBusinessSegmentsTypes {
        $type: string;
        $values: IBusinessSegmentValue[];
    }

    export interface IBusinessSegmentsTypeResult {
        $type: string;
        NodeTypes: IBusinessSegmentsTypes;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IBusinessSegmentsTypeResult;
        Error?: any;
    }

}