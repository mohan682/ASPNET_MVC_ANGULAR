﻿declare module MenuNamespace {

    export interface IMenuItems {
        label: string;
        icon?: string;
        command?: (event?: any) => void;
        url?: string;
        routerLink?: any;
        //eventEmitter?: EventEmitter<any>;
        items?: IMenuItems[];
        expanded?: boolean;
        disabled?: boolean;
    }
}