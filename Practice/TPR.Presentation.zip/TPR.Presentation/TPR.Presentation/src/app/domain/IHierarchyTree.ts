﻿declare module HierarchyNamespace {

    export interface IFavourateNode_Post {
        $type: string;
        UserName: string;
        LastSelectedNode: string;
        Favourites: string[];
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IFavouriteNodes {
        $type: string;
        $values: string[];
    }

    export interface IChild {
        name: string;
        id: number;
    }

    export interface IRootObject {
        label: string;
        NodeName: string;
        id: number;
        children: IRootObject[];
        Children: IRootObject[];
        data?: any;
        icon?: any;
        expandedIcon?: any;
        collapsedIcon?: any;
        leaf?: boolean;
        expanded?: boolean;
        type?: string;
        parent?: any;
        partialSelected?: boolean;
        $type: string;
        HasAnyOutputData: boolean;
        HasPlans: boolean;
        UpdateTiming?: any;
        NodeId: number;
        NodeType: string;
        IsActive: boolean;
        Level: number;
        ParentId: number;
        IsPnlHolder: boolean;
        MVarUpdateTiming?: number;
        SplitType: string;
        Id: number;
    }

    export interface IModifiedRootObject {
        label: string;
        NodeName: string;
        id: number;
        Children: IRootObject[];
        data?: any;
        icon?: any;
        expandedIcon?: any;
        collapsedIcon?: any;
        leaf?: boolean;
        expanded?: boolean;
        type?: string;
        parent?: IRootObject;
        partialSelected?: boolean;
        $type: string;
        HasAnyOutputData: boolean;
        HasPlans: boolean;
        UpdateTiming?: any;
        NodeId: number;
        NodeType: string;
        IsActive: boolean;
        Level: number;
        ParentId: number;
        IsPnlHolder: boolean;
        MVarUpdateTiming?: number;
        SplitType: string;
        Id: number;
    }

    export interface ITransposedRootObject {
        $type: string;
        Children: ITransposedRootObject[];
        HasAnyOutputData: boolean;
        HasPlans: boolean;
        UpdateTiming?: number;
        NodeName: string;
        NodeId: number;
        NodeType: string;
        IsActive: boolean;
        Level: number;
        ParentId: number;
        IsPnlHolder: boolean;
        MVarUpdateTiming?: number;
        SplitType: string;
        Id: number;
    }

    export interface Children {
        $type: string;
        $values: IRootObject[];
    }

    export interface NodeNames {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyResult {
        $type: string;
        Children: Children;
        NodeNames: NodeNames;
        Type: string;
        StartDate: Date;
        EndDate?: any;
        Created?: any;
        CreatedBy?: any;
        Updated?: any;
        UpdatedBy?: any;
        Id: number;
    }

    export interface IHierarchyRootObject {
        $type: string;
        ResultType: string;
        Result: IHierarchyResult;
        Error?: any;
    }

    export interface IHierarchyEditNode {
        $type: string,
        AlertGroups: IHierarchyEditNode_AlertGroups
        BusinessSegmentAllocations: any; // change later
        Created: string;
        CreatedBy: string;
        DividendPartnerAllocations: IHierarchyEditNode_DividendPartnerAllocations;
        HasChildren: boolean;
        HierarchyInstanceId: number;
        Id: number;
        IsMarkedForDeletion: boolean;
        LastUpdatedBy: string;
        Level: number;
        MVarLimit: any; // change later
        MVarRegion: IHierarchyEditNode_MVarRegion;
        MVarTemporaryLimit: any; // change later
        MVarTemporaryLimitExpiryDate: any; // change later
        MVarUpdateTiming: number;
        Node: IHierarchyEditNode_Node
        NodeType: any;//change later
        ParentId: number;
        ParentNodeId: number;
        Plans: IHierarchyEditNode_Plans,
        PnlSplitValue: any; // change later
        RegionalAllocations: IHierarchyEditNode_RegionalAllocations;
        SplitType: string;
        Tags: IHierarchyEditNode_Tags;
        Updated: string;
        UpdatedBy: string;
        UpdateTiming: number;
        WorkingCapitalRegion: IHierarchyEditNode_WorkingCapital;
    }

    export interface IHierarchyEditNode_Node {
        $type: string;
        Name: string;
        Description: string;
        IsMarkedForDeletion: boolean;
        NodeType: IHierarchyEditNode_Node_NodeType
        IsPnlHolder: boolean;
        InputYTD: any;
        InputExpectedYTD: any;
        DividendYTD: any;
        ReportedMEYTD: any;
        CanRemove: boolean;
        InputData: IHierarchyEditNode_Node_InputData
        OutputData: IHierarchyEditNode_Node_OutputData
        PreviousYTDForTrueUp: any;
        AllDatesForCurrentReportingDate: IHierarchyEditNode_Node_AllDatesForCurrentReportingDate
        AllMVarDatesForCurrentReportingDate: IHierarchyEditNode_Node_AllMVarDatesForCurrentReportingDate;
        HasPnl: boolean;
        HasMVaR: boolean;
        IsActive: boolean;
        InputNameMappings: IHierarchyEditNode_Node_InputNameMappings
        PreviousMonthEndDate: string;
        PreviousTradeDate: string;
        HasWorkingCapital: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Node_NodeType {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Node_InputData {
        $type: string;
        $values: IHierarchyEditNode_Node_InputData_Values[];
    }

    export interface IHierarchyEditNode_Node_InputData_Values {
        $type: string;
        Value: number;
        DateValue: string;
        BusinessDate: string;
        InputDataType: string;
        Published: boolean;
        InputDataTypeEnum: number;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
        CalculatedPPA: number;
        IsLocked: boolean;
    }

    export interface IHierarchyEditNode_Node_OutputData {
        $type: string;
        $values: IHierarchyEditNode_Node_OutputData_Values[];
    }

    export interface IHierarchyEditNode_Node_OutputData_Values {
        $type: string;
        Value: number;
        BusinessDate: string;
        Type: string;
        MeasureCalculationType: number;
        Id: number
    }

    export interface IHierarchyEditNode_Node_AllDatesForCurrentReportingDate {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyEditNode_Node_AllMVarDatesForCurrentReportingDate {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyEditNode_Node_InputNameMappings {
        $type: string;
        $values: IHierarchyEditNode_Node_InputNameMappings_Value[];
    }

    export interface IHierarchyEditNode_Node_InputNameMappings_Value {
        $type: string;
        Name: string;
        FeedSource: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_WorkingCapital {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_AlertGroups {
        $type: string;
        $values: IHierarchyEditNode_AlertGroups_Values[]
    }

    export interface IHierarchyEditNode_AlertGroups_Values {
        $type: string;
        Alerts: IHierarchyEditNode_AlertGroups_Values_Alerts;
        Name: string;
        Members: IHierarchyEditNode_AlertGroups_Values_Members;
        IsInUse: boolean;
        UpdateTiming: number;
        TradeDate: string;
        ProfitAlertGroupStatusId: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number
    }

    export interface IHierarchyEditNode_AlertGroups_Values_Alerts {
        $type: string;
        $values: IHierarchyEditNode_AlertGroups_Values_Alerts_Values[];
    }

    export interface IHierarchyEditNode_AlertGroups_Values_Alerts_Values {
        $type: string;
        ActionAlerts: IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts;
        AlertGroupType: number;
        Level: number;
        AlertGroupId: number;
        CurrentActionAlertExpiryDate: string;
        CurrentActionAlertLevel: string;
        Actual: any;
        StatusId: any;
        SystemIsNew: boolean;
        SystemIsTriggered: boolean;
        SystemTriggeredDate: string;
        UserIsNew: any;
        UserIsTriggered: any;
        UserTriggeredDate: any;
        ReportedIsNew: boolean;
        ReportedIsTriggered: boolean;
        ReportedTriggeredDate: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number
    }

    export interface IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts {
        $type: string;
        $values: IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values[];
    }

    export interface IHierarchyEditNode_AlertGroups_Values_Alerts_Values_ActionAlerts_Values {
        $type: string;
        AlertId: number;
        AlertGroupId: number;
        Level: number;
        StartDate: string;
        EndDate: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number
    }

    export interface IHierarchyEditNode_AlertGroups_Values_Members {
        $type: string;
        $values: IHierarchyEditNode_AlertGroups_Values_Members_Values[];
    }

    export interface IHierarchyEditNode_AlertGroups_Values_Members_Values {
        $type: string;
        Name: string;
        NodeId: number;
        StructureId: number;
        Id: number;
    }

    export interface IHierarchyEditNode_MVarRegion {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Tags {
        $type: string;
        $values: IHierarchyEditNode_Tags_Values[];
    }

    export interface IHierarchyEditNode_Tags_Values {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_RegionalAllocations {
        $type: string;
        $values: IHierarchyEditNode_RegionalAllocations_Values[];
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values {
        $type: string;
        Percentage: number;
        RegionNode: IHierarchyEditNode_RegionalAllocations_Values_RegionNode;
        DividendPartnerNode: any;
        BusinessSegmentNode: any;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode {
        $type: string;
        Region: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region;
        Name: string;
        Description: string;
        IsMarkedForDeletion: boolean;
        NodeType: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType;
        IsPnlHolder: boolean;
        InputYTD: any;
        InputExpectedYTD: any;
        DividendYTD: any;
        ReportedMEYTD: number;
        CanRemove: boolean;
        InputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData;
        OutputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData;
        PreviousYTDForTrueUp: number;
        AllDatesForCurrentReportingDate: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate;
        AllMVarDatesForCurrentReportingDate: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate;
        HasPnl: boolean;
        HasMVaR: boolean;
        IsActive: boolean;
        InputNameMappings: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings;
        PreviousMonthEndDate: string;
        PreviousTradeDate: string;
        HasWorkingCapital: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData {
        $type: string;
        $values: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData_Values[];
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData_Values {
        $type: string;
        Value: number;
        DateValue: string;
        BusinessDate: string;
        InputDataType: string;
        Published: boolean;
        InputDataTypeEnum: number;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: string;
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData {
        $type: string;
        $values: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData_Values[];
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData_Values {
        $type: string;
        Value: number;
        BusinessDate: string;
        Type: string;
        MeasureCalculationType: number;
        Id: number;
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings {
        $type: string;
        $values: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings_Values[];
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings_Values {
        $type: string;
        Name: string;
        FeedSource: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllDatesForCurrentReportingDate {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyEditNode_RegionalAllocations_Values_RegionNode_AllMVarDatesForCurrentReportingDate {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations {
        $type: string;
        $values: IHierarchyEditNode_DividendPartnerAllocations_Values[];
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values {
        $type: string;
        Percentage: number;
        RegionNode: any;
        DividendPartnerNode: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode;
        BusinessSegmentNode: any;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode {
        $type: string;
        DividendPartner: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner;
        Name: string;
        Description: string;
        IsMarkedForDeletion: boolean;
        NodeType: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType;
        IsPnlHolder: boolean;
        InputYTD: any;
        InputExpectedYTD: any;
        DividendYTD: any;
        ReportedMEYTD: number;
        CanRemove: boolean;
        InputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData;
        OutputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData;
        PreviousYTDForTrueUp: number;
        AllDatesForCurrentReportingDate: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate;
        AllMVarDatesForCurrentReportingDate: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate;
        HasPnl: boolean;
        HasMVaR: boolean;
        IsActive: boolean;
        InputNameMappings: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings;
        PreviousMonthEndDate: string;
        PreviousTradeDate: string;
        HasWorkingCapital: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner {
        $type: string;
        Name: string;
        IsInUse: boolean;
        BusinessSegment: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner_BusinessSegment {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData {
        $type: string;
        $values: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values[];
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values {
        $type: string;
        Value: number;
        DateValue: string;
        BusinessDate: string;
        InputDataType: string;
        Published: boolean;
        InputDataTypeEnum: number;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: string;
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData {
        $type: string;
        $values: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData_Values[];
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData_Values {
        $type: string;
        Value: number;
        BusinessDate: string;
        Type: string;
        MeasureCalculationType: number;
        Id: number;
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllDatesForCurrentReportingDate {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_AllMVarDatesForCurrentReportingDate {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings {
        $type: string;
        $values: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings_Values[];
    }

    export interface IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings_Values {
        $type: string;
        Name: string;
        FeedSource: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Plans {
        $type: string;
        $values: IHierarchyEditNode_Plans_Values[];
    }

    export interface IHierarchyEditNode_Plans_Values {
        $type: string;
        DividendPartner: IHierarchyEditNode_Plans_Values_DividendPartner;
        Region: IHierarchyEditNode_Plans_Values_Region;
        PlanValues: IHierarchyEditNode_Plans_Values_PlanValues;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Plans_Values_DividendPartner {
        $type: string;
        Name: string;
        IsInUse: boolean;
        BusinessSegment: IHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Plans_Values_DividendPartner_BusinessSegment {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Plans_Values_Region {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Plans_Values_PlanValues {
        $type: string;
        $values: IHierarchyEditNode_Plans_Values_PlanValues_Values[];
    }

    export interface IHierarchyEditNode_Plans_Values_PlanValues_Values {
        $type: string;
        Year: number;
        Month: number;
        Value: number;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEnterValue_DividendTrueUp {
        BusinessDate: string;
        DateValue: string;
        InputDataType: string;
        DividendPartnerName: string;
        Value: number;
        TrueUp: number;
        Updated: string;
        UpdatedBy: string;
        IsLocked: boolean;
    }

    export interface IHierarchyEnterValue_DividendPPA {
        BusinessDate: string;
        DividendPartnerName: string;
        RestatedMEDate: string;
        RestatedMEYTD: number;
        CalculatedPPA: number;
        Updated: string;
        UpdatedBy: string;
        IsLocked: boolean;
    }

    /* Post node data starts here */
    export interface IHierarchyNodePostData {
        $type: string;
        AlertGroups: IHierarchyNodePostData_Alerts[];
        BusinessSegmentAllocations: any; // change later
        Created: string;
        CreatedBy: string;
        DividendPartnerAllocations: IHierarchyNodePostData_DividendPartnerAllocations[];
        HasChildren: boolean;
        HierarchyInstanceId: number;
        Id: number;
        IsMarkedForDeletion: boolean;
        LastUpdatedBy: string;
        Level: number;
        MVarLimit: any; // change later
        MVarRegion: IHierarchyEditNode_MVarRegion;
        MVarTemporaryLimit: any; // change later
        MVarTemporaryLimitExpiryDate: any; // change later
        MVarUpdateTiming: number;
        Node: IHierarchyNodePostData_Node;
        NodeType: any;//change later
        ParentId: number;
        ParentNodeId: number;
        Plans: IHierarchyNodePostData_Plans[];
        PnlSplitValue: any; // change later
        RegionalAllocations: IHierarchyNodePostData_RegionalAllocations[];
        SplitType: string; // change later
        Tags: IHierarchyEditNode_Tags_Values[];
        Updated: string;
        UpdatedBy: string;
        UpdateTiming: number;
        WorkingCapitalRegion: IHierarchyEditNode_WorkingCapital;
    }

    export interface IHierarchyNodePostData_Alerts {
        $type: string;
        Alerts: IHierarchyEditNode_AlertGroups_Values_Alerts_Values[];
        Name: string;
        Members: IHierarchyEditNode_AlertGroups_Values_Members_Values[];
        IsInUse: boolean;
        UpdateTiming: number;
        TradeDate: string;
        ProfitAlertGroupStatusId: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyEditNode_Node_ProfitAlertGroup {
        $type: string;
        $values: IHierarchyEditNode_Node_ProfitAlertGroup_Values[];
    }

    export interface IHierarchyEditNode_Node_ProfitAlertGroup_Values {
        $type: string;
        NodeId: number;
        FormettedAlertGroups: string;
        AlertGroups: IHierarchyEditNode_Node_ProfitAlertGroup_Values_AlertGroups;
    }

    export interface IHierarchyEditNode_Node_ProfitAlertGroup_Values_AlertGroups {
        $type: string;
        $values: string[];
    }

    export interface IHierarchyNodePostData_Node {
        $type: string;
        Name: string;
        Description: string;
        IsMarkedForDeletion: boolean;
        NodeType: IHierarchyEditNode_Node_NodeType;
        IsPnlHolder: boolean;
        InputYTD: number;
        InputExpectedYTD: any;
        DividendYTD: any;
        ReportedMEYTD: any;
        CanRemove: boolean;
        InputData: IHierarchyEditNode_Node_InputData_Values[];
        OutputData: IHierarchyEditNode_Node_OutputData_Values[];
        PreviousYTDForTrueUp: number;
        AllDatesForCurrentReportingDate: string[];
        AllMVarDatesForCurrentReportingDate: string[];
        HasPnl: boolean;
        HasMVaR: boolean;
        IsActive: boolean;
        InputNameMappings: IHierarchyEditNode_Node_InputNameMappings_Value[];
        PreviousMonthEndDate: string;
        PreviousTradeDate: string;
        HasWorkingCapital: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_RegionalAllocations {
        $type: string;
        Percentage: number;
        RegionNode: IHierarchyNodePostData_RegionalAllocations_RegionNode;
        DividendPartnerNode: any;
        BusinessSegmentNode: any;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_RegionalAllocations_RegionNode {
        $type: string;
        Region: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_Region;
        Name: string;
        Description: string;
        IsMarkedForDeletion: boolean;
        NodeType: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_NodeType;
        IsPnlHolder: boolean;
        InputYTD: any;
        InputExpectedYTD: any;
        DividendYTD: any;
        ReportedMEYTD: any;
        CanRemove: boolean;
        InputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputData_Values[];
        OutputData: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_OutputData_Values[];
        PreviousYTDForTrueUp: number;
        AllDatesForCurrentReportingDate: string[];
        AllMVarDatesForCurrentReportingDate: string[];
        HasPnl: boolean;
        HasMVaR: boolean;
        IsActive: boolean;
        InputNameMappings: IHierarchyEditNode_RegionalAllocations_Values_RegionNode_InputNameMappings_Values[];
        PreviousMonthEndDate: string;
        PreviousTradeDate: string;
        HasWorkingCapital: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_DividendPartnerAllocations {
        $type: string;
        Percentage: number;
        RegionNode: any;
        DividendPartnerNode: IHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode;
        BusinessSegmentNode: any;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_DividendPartnerAllocations_DividendPartnerNode {
        $type: string;
        DividendPartner: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_DividendPartner;
        Name: string;
        Description: string;
        IsMarkedForDeletion: boolean;
        NodeType: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_NodeType;
        IsPnlHolder: boolean;
        InputYTD: any;
        InputExpectedYTD: any;
        DividendYTD: any;
        ReportedMEYTD: any;
        CanRemove: boolean;
        InputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputData_Values[];
        OutputData: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_OutputData_Values[];
        PreviousYTDForTrueUp: number;
        AllDatesForCurrentReportingDate: string[];
        AllMVarDatesForCurrentReportingDate: string[];
        HasPnl: boolean;
        HasMVaR: boolean;
        IsActive: boolean;
        InputNameMappings: IHierarchyEditNode_DividendPartnerAllocations_Values_DividendPartnerNode_InputNameMappings_Values[];
        PreviousMonthEndDate: string;
        PreviousTradeDate: string;
        HasWorkingCapital: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_Plans {
        $type: string;
        DividendPartner: IHierarchyNodePostData_Plans_DividendPartner;
        Region: IHierarchyNodePostData_Plans_Region;
        PlanValues: IHierarchyNodePostData_Plans_PlanValues[];
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_Plans_DividendPartner {
        $type: string;
        Name: string;
        IsInUse: boolean;
        BusinessSegment: IHierarchyNodePostData_Plans_DividendPartner_BusinessSegment;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_Plans_DividendPartner_BusinessSegment {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Editable: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_Plans_Region {
        $type: string;
        Name: string;
        IsInUse: boolean;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodePostData_Plans_PlanValues {
        $type: string;
        Year: number;
        Month: number;
        Value: number;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }

    export interface IHierarchyNodeEnterValuePostData {
        $type: string;
        Node: IHierarchyEditNode_Node;
        HierarchyType: string;
        UpdateData: IHierarchyNodeEnterValuePostData_UpdateData[];
    }

    export interface IHierarchyNodeEnterValuePostData_UpdateData {
        $type: string;
        DividendPartner: DividendPartnerNameSpace.IDividendPartnerValue;
        InputDataType: number;
        BusinessDate: string;
        Value: number;
        DateValue: string;
    }

    export interface IHierarchyRemoveNode_Post {
        $type: string;
        Children: IModifiedRootObject[];
        NodeNames: string[];
        Type: string;
        StartDate: string;
        EndDate: string;
        Created: string;
        CreatedBy: string;
        Updated: string;
        UpdatedBy: string;
        Id: number;
    }
    /* Post node data ends here */
}