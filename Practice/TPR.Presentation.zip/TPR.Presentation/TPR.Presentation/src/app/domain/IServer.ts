declare module ServerNamespace {

    export interface IServerValue {
        $type: string;
        Name: string;
        Url: string;
        Id: number;
    }

    export interface ITableauServers {
        $type: string;
        $values: IServerValue[];
    }

    export interface IServerResult {
        $type: string;
        TableauServers: ITableauServers;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IServerResult;
        Error?: any;
    }
}