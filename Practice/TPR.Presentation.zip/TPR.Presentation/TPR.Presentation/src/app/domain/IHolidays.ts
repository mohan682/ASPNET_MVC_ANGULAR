﻿declare module HolidayNamespace {

    export interface IHolidayValue {
        IsDeletable: boolean,
        HolidayType: string,
        $type: string,
        Date: string,
        Region: IRegionValue,
        MarkAsDeleted: boolean,
        Name: string,
        IsUpdateTimingException: boolean,
        Created: string,
        CreatedBy: string,
        Updated: string,
        UpdatedBy: string,
        Id: number
    }

    export interface IRegionValue {
        $type: string,
        Name: string,
        IsInUse: boolean,
        Created: string,
        CreatedBy: string,
        Updated: string,
        UpdatedBy: string,
        Id: number
    }

    export interface IHolidayTypes {
        $type: string;
        $values: IHolidayValue[];
    }

    export interface IHolidayTypeResult {
        $type: string;
        NodeTypes: IHolidayTypes;
    }

    export interface IRootObject {
        $type: string;
        ResultType: string;
        Result: IHolidayTypeResult;
        Error?: any;
    }
}