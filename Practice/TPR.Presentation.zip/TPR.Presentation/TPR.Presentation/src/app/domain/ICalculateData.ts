﻿    declare module Calcnamespace {

        export interface ICalcErrors {
            $type: string;
            $values: any[];
        }

        export interface ICalcResult {
            $type: string;
            IsPublished: boolean;
            BusinessDate: Date;
            Errors: ICalcErrors;
            Created: Date;
            CreatedBy: string;
            Updated: Date;
            UpdatedBy: string;
            Id: number;
        }

        export interface ICalcDataRootObject {
            $type: string;
            ResultType: string;
            Result: ICalcResult;
            Error?: any;
        }

    }
