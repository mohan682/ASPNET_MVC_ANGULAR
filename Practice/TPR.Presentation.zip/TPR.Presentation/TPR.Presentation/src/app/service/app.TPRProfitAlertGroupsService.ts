﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import IProfitAlertGroupsValues = PAGNameSpace.IProfitAlertGroupsValues;
import IProfitAlertGroups_SaveData = PAGNameSpace.IProfitAlertGroups_SaveData;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class TPRProfitAlertGroupsService {

    constructor(private http: Http, private serviceHelper : ServiceHelper) { }

    getProfitAlertGroupsObservable(): Observable<any> {

        let _url =  this.serviceHelper.combineUrl("AlertWCFService.svc/AlertGroups");

        return this.http.get(_url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateProfitAlertGroupsObservable(objClsProfitAlertGroups_SaveData:IProfitAlertGroups_SaveData): Observable<any> {
        let _url =  this.serviceHelper.combineUrl("AlertWCFService.svc/AlertGroupStatus/update");

        let body = JSON.stringify(objClsProfitAlertGroups_SaveData);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}