﻿import { Injectable, Inject } from '@angular/core';
import { Http, Headers, Response, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class DashboardDataService {

    constructor(private http: Http, private serviceHelper: ServiceHelper) { }

    getDashboardDataObservable(date3: string): Observable<any> {
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Dashboard?BusinessDate=' + date3);
        
        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getCalculateObservable(date: string): Observable<any> {
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Process');

        let data = { "$type": "BP.IST.Finance.TPR.Common.Domain.DTO.Calculation.CalculationRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO", "HierarchyType": "Main", "ReportingDate": date }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getLastCalculatedObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/LastCalculated');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getResetCalculationFlagObservable(date: string): Observable<any> {
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/ResetCalculationFlag=06Jul2017');

        let data = { "$type": "BP.IST.Finance.TPR.Common.Domain.DTO.ResponseDTO, BP.IST.Finance.TPR.Common.Domain.DTO" };
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    rollBusinessDateObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/RollSystemDate');

        return this.http.post(url,"",{ withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getIsCalculatingObservable(date: string): Observable<any> {

        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Calculation/IsCalculating?businessDate=' + date + '&HierarchyType=Main');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getPublishObservable(date: string): Observable<any> {
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Calculation/Publish?BusinessDate=' + date + '&HierarchyType=Main');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getUnPublishObservable(date: string): Observable<any> {
        let url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/Calculation/Unpublish?BusinessDate=' + date + '&HierarchyType=Main');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getPublishStatusObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/DataPublished');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getLockedStatusObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/SystemDateLocked');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);

    }

    getLockedObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/update');

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.SystemVariableDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            Name: "SystemDateLocked",
            NumericValue: 1.0
        };
        let body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getUnLockedObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/update');

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.SystemVariableDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            Name: "SystemDateLocked",
            NumericValue: 0.0
        };
        let body = JSON.stringify(data);
        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}