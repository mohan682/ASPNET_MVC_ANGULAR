"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var app_serviceHelper_1 = require('./app.serviceHelper');
var WorkDayService = (function () {
    function WorkDayService(http, serviceHelper) {
        this.http = http;
        this.serviceHelper = serviceHelper;
    }
    WorkDayService.prototype.getWorkingDatesObservable = function () {
        var url = this.serviceHelper.combineUrl('UtilWCFService.svc/WorkingDates');
        //{"$type":"BP.IST.Finance.TPR.Common.Domain.DTO.Util.WorkingDatesRangeDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
        //"Start":"2017-06-26T00:00:00Z","End":"2017-08-25T00:00:00Z","Range":[]}
        var startDate = new Date();
        startDate.setDate(startDate.getDate() - 30);
        console.log("Start Date ->", startDate);
        var endDate = new Date();
        endDate.setDate(endDate.getDate() + 30);
        console.log("End Date ->", endDate);
        var data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Util.WorkingDatesRangeDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            Start: startDate,
            End: endDate
        };
        var body = JSON.stringify(data);
        console.log("Send request ->", url);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    WorkDayService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, app_serviceHelper_1.ServiceHelper])
    ], WorkDayService);
    return WorkDayService;
}());
exports.WorkDayService = WorkDayService;
//# sourceMappingURL=app.workDayService.js.map