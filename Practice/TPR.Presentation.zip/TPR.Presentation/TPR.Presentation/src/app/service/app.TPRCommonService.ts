﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import IEnvironmentValue = CommonNameSpace.IEnvironmentValue;
import ISystemVersionValue = CommonNameSpace.ISystemVersionValue;
import ISystemDateValue = CommonNameSpace.ISystemDateValue;
import IUserRolesValue = CommonNameSpace.IUserRolesValue;
import IUserRolesValues = CommonNameSpace.IUserRolesValues;
import IUsersValue = CommonNameSpace.IUsersValue;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class TPRCommonService {

    constructor(private http: Http, private serviceHelper: ServiceHelper) { }

    getEnvironmentObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/Environment');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getSystemVersionObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('UtilWCFService.svc/SystemVersion');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getSystemDateObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SystemVariableWCFService.svc/SysVar/SystemDate');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getUserRolesObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('SecurityWCFService.svc/UserRoles/LoadAll');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    SetSystemDate(updatedSystemDate: string): Observable<any> {
        let _serviceName = "SystemVariableWCFService.svc/SysVar/SetSystemDate";
        let _url = this.serviceHelper.combineUrl(_serviceName);

        let body = JSON.stringify(updatedSystemDate);

        return this.http.post(_url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    getFormattedSystemDate(unFormattedDate: Date): string {

        let formattedDateString: string = "";

        let m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        let year: string = unFormattedDate.getUTCFullYear().toString();
        let month: string = m_names[(unFormattedDate.getUTCMonth())];
        let day: string = unFormattedDate.getUTCDate().toString().length > 1 ? unFormattedDate.getUTCDate().toString() : "0" + unFormattedDate.getUTCDate().toString();
        let hours: string = unFormattedDate.getUTCHours().toString().length > 1 ? unFormattedDate.getUTCHours().toString() : "0" + unFormattedDate.getUTCHours().toString();
        let minutes: string = unFormattedDate.getUTCMinutes().toString().length > 1 ? unFormattedDate.getUTCMinutes().toString() : "0" + unFormattedDate.getUTCMinutes().toString();
        let seconds: string = unFormattedDate.getUTCSeconds().toString().length > 1 ? unFormattedDate.getUTCSeconds().toString() : "0" + unFormattedDate.getUTCSeconds().toString();

        formattedDateString = day + " " + month + " " + year + " " + hours + ":" + minutes + ":" + seconds;

        return formattedDateString;

    }

    getFormattedSystemDate_Date(unFormattedDate: Date): string {
        
        let formattedDateString: string = "";

        let m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        let year: string = unFormattedDate.getUTCFullYear().toString();
        let month: string = m_names[(unFormattedDate.getUTCMonth())];
        let day: string = unFormattedDate.getUTCDate().toString().length > 1 ? unFormattedDate.getUTCDate().toString() : "0" + unFormattedDate.getUTCDate().toString();

        formattedDateString = day + " " + month + " " + year;

        return formattedDateString;
    }

    getFormattedSystemDate_NonUTC(unFormattedDate: Date): string {
        
        let formattedDateString: string = "";

        let m_names = new Array("Jan", "Feb", "Mar",
            "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec");

        let year: string = unFormattedDate.getFullYear().toString();
        let month: string = m_names[(unFormattedDate.getMonth())];
        let day: string = unFormattedDate.getDate().toString().length > 1 ? unFormattedDate.getDate().toString() : "0" + unFormattedDate.getDate().toString();

        formattedDateString = day + " " + month + " " + year;

        return formattedDateString;
    }

}