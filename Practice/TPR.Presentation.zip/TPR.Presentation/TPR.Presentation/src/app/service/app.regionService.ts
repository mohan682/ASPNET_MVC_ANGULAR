﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { ServiceHelper } from './app.serviceHelper';

import IRegionValue = RegionNamespace.IRegionValue;

@Injectable()
export class RegionsService {

    constructor(private http: Http, private serviceHelper : ServiceHelper) { 
        
    }

    getRegionsObservable(): Observable<any> {
        let url =  this.serviceHelper.combineUrl('HierarchyWCFService.svc/Regions');
        console.log("Send request ->", url);
        return this.http.get( url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateRegionsObservable(regionsArray: IRegionValue[]): Observable<any> {
        let url =  this.serviceHelper.combineUrl('HierarchyWCFService.svc/Regions/update');
        console.log("Send request ->", url);
        regionsArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionDTO, BP.IST.Finance.TPR.Common.Domain.DTO"
        });

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Static.RegionCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            Regions: regionsArray
        }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }
}