import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class WorkDayService {

    constructor(private http: Http, private serviceHelper: ServiceHelper) { }

    getWorkingDatesObservable(): Observable<any> {
        let url = this.serviceHelper.combineUrl('UtilWCFService.svc/WorkingDates');

        let startDate = new Date();
        startDate.setDate(startDate.getDate() - 30);

        let endDate = new Date();
        endDate.setDate(endDate.getDate() + 30);

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Util.WorkingDatesRangeDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            Start: startDate,
            End: endDate
        }

        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}