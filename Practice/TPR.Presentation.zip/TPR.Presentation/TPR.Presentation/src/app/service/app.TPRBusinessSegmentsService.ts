﻿import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import IBusinessSegmentsValue = BusinessSegmentNameSpace.IBusinessSegmentValue;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class TPRBusinessSegmentsService {

    constructor(private http: Http, private serviceHelper : ServiceHelper) { }

    getBusinessSegmentsObservable(): Observable<any> {
        let url =  this.serviceHelper.combineUrl('HierarchyWCFService.svc/BusinessSegments');

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    updateBusinessSegmentsObservable(businessSegmentsArray: IBusinessSegmentsValue[]): Observable<any> {   
        let url =  this.serviceHelper.combineUrl('HierarchyWCFService.svc/BusinessSegments/update');

        businessSegmentsArray.forEach(function (item){
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Static.BusinessSegmentDTO, BP.IST.Finance.TPR.Common.Domain.DTO"
        });

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Static.BusinessSegmentCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            BusinessSegments: businessSegmentsArray
        }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}