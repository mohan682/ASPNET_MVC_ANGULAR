import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import IServerValue = ServerNamespace.IServerValue;
import { ServiceHelper } from './app.serviceHelper';

@Injectable()
export class ServerService {

    constructor(private http: Http, private serviceHelper : ServiceHelper) { }

    getServersObservable(): Observable<any> {
        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/Servers');
        console.log("Send request ->", url);

        return this.http.get(url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

}