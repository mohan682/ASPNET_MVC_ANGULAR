"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
require('rxjs/add/operator/catch');
var app_serviceHelper_1 = require('./app.serviceHelper');
var FileUploadService = (function () {
    function FileUploadService(http, serviceHelper) {
        this.http = http;
        this.serviceHelper = serviceHelper;
    }
    FileUploadService.prototype.getFileUploadDetails = function () {
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/LoadedFiles');
        //console.log("get request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    FileUploadService.prototype.getErrorDetails = function (id) {
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/GetErrors=');
        url = url + id.toString();
        //debugger;
        //console.log("get request ->", url);
        return this.http.get(url, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    FileUploadService.prototype.uploadFile = function (clsFileUploadModelObj) {
        //debugger;
        var url = this.serviceHelper.combineUrl('DataWCFService.svc/Data/LoadFile');
        //console.log("post request ->", url);
        var body = JSON.stringify(clsFileUploadModelObj);
        //console.log("body ->", body);
        return this.http.post(url, body, { withCredentials: true })
            .map(function (res) { return res.json(); })
            .catch(this.serviceHelper.handleError);
    };
    FileUploadService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, app_serviceHelper_1.ServiceHelper])
    ], FileUploadService);
    return FileUploadService;
}());
exports.FileUploadService = FileUploadService;
//# sourceMappingURL=app.fileUpload.service.js.map