import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { ServiceHelper } from './app.serviceHelper';

import IDataSourceValue = DataSourceNamespace.IDataSourceValue;

@Injectable()
export class DataSourcesService {


    constructor(private http: Http, private serviceHelper : ServiceHelper) {}

    getDataSourcesObservable(): Observable<any> {
        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources');
        console.log("Send request ->", url);
        return this.http.get( url, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

        updateDataSourcesObservable(datasourcesArray: IDataSourceValue[]): Observable<any> {

        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources/update');
        console.log("Send request ->", url);

        datasourcesArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceDTO, BP.IST.Finance.TPR.Common.Domain.DTO"

            if (item.Server != null) {
                item.Server.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauServerDTO, BP.IST.Finance.TPR.Common.Domain.DTO";
            }
        });
                
        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceCollectionDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            TableauDataSources: datasourcesArray
        }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);
    }

    refreshDataSourcesObservable(datasourcesArray: IDataSourceValue[]): Observable<any> {
        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources/refresh');
        console.log("Send request ->", url);
        datasourcesArray.forEach(function (item) {
            item.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceDTO, BP.IST.Finance.TPR.Common.Domain.DTO"
        });

        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceRefreshRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            DataSourcesToRefresh: datasourcesArray
        }
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);

    }

        refreshSelectedDataSourcesObservable(datasource: IDataSourceValue): Observable<any> {
        let url =  this.serviceHelper.combineUrl('TableauWCFService.svc/DataSources/refresh');
        console.log("Send request ->", url);
        datasource.$type = "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauViewDTO, BP.IST.Finance.TPR.Common.Domain.DTO"
        let data = {
            $type: "BP.IST.Finance.TPR.Common.Domain.DTO.Tableau.TableauDataSourceRefreshRequestDTO, BP.IST.Finance.TPR.Common.Domain.DTO",
            DataSourcesToRefresh: datasource
        }
        
        let body = JSON.stringify(data);

        return this.http.post(url, body, { withCredentials: true })
            .map((res: any) => res.json())
            .catch(this.serviceHelper.handleError);

    }
}